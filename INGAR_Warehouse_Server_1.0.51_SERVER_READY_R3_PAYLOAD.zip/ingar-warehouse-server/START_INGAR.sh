#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$HOME/.ingar-warehouse-server.env"
PID_FILE="$HOME/.ingar-warehouse-server.pid"
LOG_FILE="$HOME/.ingar-warehouse-server.log"
if [[ -s /usr/local/share/nvm/nvm.sh ]]; then source /usr/local/share/nvm/nvm.sh; fi
if command -v nvm >/dev/null 2>&1; then nvm use 22 >/dev/null || { nvm install 22 >/dev/null; nvm use 22 >/dev/null; }; fi
MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
ABI="$(node -p 'process.versions.modules')"
if [[ "$MAJOR" != "22" || "$ABI" != "127" ]]; then echo "ERROR: se requiere Node 22 / ABI 127. Actual: $(node -v) / ABI $ABI" >&2; exit 2; fi
if [[ ! -f "$ENV_FILE" ]]; then echo "Servidor no instalado. Ejecutá ./INSTALL_SERVER.sh" >&2; exit 3; fi
if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  if curl -fsS "http://127.0.0.1:4317/api/v1/health/live" >/dev/null 2>&1; then echo "INGAR Warehouse ya está activo. PID $(cat "$PID_FILE")"; exit 0; fi
  kill "$(cat "$PID_FILE")" 2>/dev/null || true
  rm -f "$PID_FILE"
fi
set -a; source "$ENV_FILE"; set +a
: > "$LOG_FILE"
echo "Iniciando INGAR Warehouse con $(node -v) / ABI $(node -p process.versions.modules)..."
nohup "$(command -v node)" "$ROOT/scripts/start-server.js" >>"$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"
for i in {1..30}; do
  if ! kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then echo "ERROR: el proceso terminó." >&2; tail -n 120 "$LOG_FILE" >&2 || true; exit 4; fi
  if curl -fsS "http://127.0.0.1:${IWC_PORT:-4317}/api/v1/health/live" >/dev/null 2>&1; then echo "INGAR Warehouse ACTIVO en puerto ${IWC_PORT:-4317}. PID $(cat "$PID_FILE")"; echo "Log: $LOG_FILE"; exit 0; fi
  echo "healthcheck $i/30..."
  sleep 1
done
echo "ERROR: Warehouse no respondió al healthcheck." >&2
tail -n 120 "$LOG_FILE" >&2 || true
exit 5
