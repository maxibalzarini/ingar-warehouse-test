async function ensureAssetCatalogs() {
  const requests = [];
  if (!state.categories.length) requests.push(api('/api/v1/asset-categories').then((data) => { state.categories = data.items; }));
  if (!state.locations.locations.length) requests.push(api('/api/v1/config/locations').then((data) => { state.locations = data; }));
  await Promise.all(requests);
}

function activeLocations() {
  const activeSites = new Set(state.locations.sites.filter((item) => item.active).map((item) => item.id));
  return state.locations.locations.filter((item) => item.active && activeSites.has(item.site_id));
}

function assetStatusClass(status) {
  return status === 'DISPONIBLE' ? 'ok' : ['BLOQUEADO', 'PERDIDO', 'BAJA'].includes(status) ? 'danger' : 'neutral';
}

async function loadAssets() {
  await ensureAssetCatalogs();
  const selectedCategory = $('#asset-category-filter').value;
  const selectedLocation = $('#asset-location-filter').value;
  $('#asset-category-filter').innerHTML = '<option value="">Todas las categorías</option>' + state.categories.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('');
  if (state.categories.some((item) => item.id === selectedCategory)) $('#asset-category-filter').value = selectedCategory;
  const siteNames = new Map(state.locations.sites.map((item) => [item.id, item.code]));
  $('#asset-location-filter').innerHTML = '<option value="">Todas las ubicaciones</option>' + state.locations.locations.map((item) => `<option value="${item.id}">${escapeHtml(siteNames.get(item.site_id) || '')}/${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('');
  if (state.locations.locations.some((item) => item.id === selectedLocation)) $('#asset-location-filter').value = selectedLocation;
  const params = dashboardFilterParams('assets');
  params.set('search', $('#asset-search').value); params.set('status', $('#asset-status').value); params.set('categoryId', $('#asset-category-filter').value); params.set('locationId', $('#asset-location-filter').value); params.set('limit', '500');
  if ($('#asset-active').value) params.set('active', $('#asset-active').value);
  params.set('includeAvailabilityDiagnosis', 'true');
  const data = await api(`/api/v1/assets?${params}`);
  state.assets = data.items;
  $('#assets-body').innerHTML = data.items.map((asset) => `<tr>
    <td><span class="asset-code">${escapeHtml(asset.internal_code)}</span>${asset.photo_evidence_id ? `<div><img class="asset-photo" src="/api/v1/evidence/${asset.photo_evidence_id}" alt=""></div>` : ''}</td>
    <td><strong>${escapeHtml(asset.description)}</strong><div class="small">${escapeHtml([asset.brand, asset.model].filter(Boolean).join(' · '))}</div></td>
    <td>${escapeHtml(asset.category_code)}<div class="small">${escapeHtml(uiCodeLabel(asset.category_nature))}</div>${asset.requires_work_order ? '<div class="small"><strong>OT obligatoria</strong></div>' : ''}</td>
    <td>${escapeHtml(asset.serial_number || asset.license_plate || '—')}</td>
    <td>${escapeHtml(asset.site_code)}/${escapeHtml(asset.location_code)}<div class="small">${escapeHtml(asset.location_name)}</div></td>
    <td class="quantity">${Number(asset.quantity_available).toLocaleString()} / ${Number(asset.quantity_total).toLocaleString()} ${escapeHtml(asset.unit_of_measure || 'u')}<div class="small">${asset.requestAvailability?.requestVisible ? 'Pedible: Sí' : `Pedible: No · ${escapeHtml((asset.requestAvailability?.blockers || []).map((item) => item.code).join(', ') || 'SIN_DIAGNÓSTICO')}`}</div></td>
    <td><span class="status ${assetStatusClass(asset.status)}">${escapeHtml(uiCodeLabel(asset.status))}</span><div class="small">${asset.active ? 'Activo' : 'Inactivo'}</div></td>
    <td class="actions"><button data-asset-action="availability" data-id="${asset.id}">Diagnóstico</button>${can('Assets.Update') ? `<button data-asset-action="edit" data-id="${asset.id}">Editar</button>${asset.active ? `<button data-asset-action="move" data-id="${asset.id}">Mover</button>` : ''}<button data-asset-action="toggle" data-id="${asset.id}">${asset.active ? 'Dar de baja' : 'Reactivar'}</button>${asset.status === 'DISPONIBLE' && Number(asset.quantity_available) === 0 ? `<button data-asset-action="availability-review" data-id="${asset.id}">Revisar disponibilidad</button>` : ''}` : ''}${can('Assets.ReleaseBlocked') && asset.status === 'BLOQUEADO' && asset.active ? `<button class="danger" data-asset-action="release" data-id="${asset.id}">Habilitar bien</button>` : ''}${can('Assets.Create') && asset.category_nature !== 'KIT' ? `<button data-asset-action="duplicate" data-id="${asset.id}">Duplicar</button>` : ''}</td>
  </tr>`).join('');
}

function enabledCategoryIdsForSite(siteId) {
  return new Set((state.locations.siteCategories || []).filter((item) => item.site_id === siteId && item.active).map((item) => item.category_id));
}

function siteIdForLocation(locationId) {
  return state.locations.locations.find((item) => item.id === locationId)?.site_id || null;
}

function categoriesForLocation(locationId, asset = null) {
  const siteId = siteIdForLocation(locationId);
  const enabled = enabledCategoryIdsForSite(siteId);
  return state.categories.filter((item) => {
    const current = Boolean(asset && item.id === asset.category_id);
    if (!current && (!item.active || !enabled.has(item.id))) return false;
    if (!asset && ['VEHICULO','KIT'].includes(item.nature)) return false;
    if (asset && item.nature !== asset.category_nature && !current) return false;
    return true;
  });
}

function refillAssetCategorySelect(asset = null, preferredCategoryId = null) {
  const locationId = $('#asset-location').value;
  const categories = categoriesForLocation(locationId, asset);
  $('#asset-category').innerHTML = categories.length
    ? categories.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)} (${escapeHtml(uiCodeLabel(item.nature))})</option>`).join('')
    : '<option value="" disabled selected>No hay categorías habilitadas para esta ubicación</option>';
  const preferred = preferredCategoryId || asset?.category_id;
  if (preferred && categories.some((item) => item.id === preferred)) $('#asset-category').value = preferred;
}

function fillAssetSelects(asset = null) {
  const locations = activeLocations();
  const siteNames = new Map(state.locations.sites.map((item) => [item.id, item.code]));
  $('#asset-location').innerHTML = locations.map((item) => `<option value="${item.id}">${escapeHtml(siteNames.get(item.site_id) || '')}/${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('');
  if (asset && locations.some((item) => item.id === asset.location_id)) {
    $('#asset-location').value = asset.location_id;
  } else if (!asset && locations.length) {
    // En alta, no elegir por accidente una sede que sólo admite VEHICULO/KIT: eso
    // dejaba el selector Categoría vacío aunque existieran herramientas habilitadas
    // en otra sede. Respetamos primero el filtro de ubicación actual si es elegible.
    const requestedLocationId = $('#asset-location-filter')?.value || '';
    const requested = locations.find((item) => item.id === requestedLocationId && categoriesForLocation(item.id, null).length > 0);
    const eligible = requested || locations.find((item) => categoriesForLocation(item.id, null).length > 0);
    if (eligible) $('#asset-location').value = eligible.id;
  }
  refillAssetCategorySelect(asset, asset?.category_id || null);
}

function renderAssetDocuments(asset) {
  $('#asset-documents-section').classList.toggle('hidden', !asset);
  if (!asset) return;
  $('#asset-documents-body').innerHTML = (asset.documents || []).map((document) => {
    const expired = document.expires_at && new Date(document.expires_at) < new Date();
    return `<tr><td>${escapeHtml(uiCodeLabel(document.type))}</td><td>${escapeHtml(document.title)}</td><td class="${expired ? 'expired' : ''}">${escapeHtml(document.expires_at || '—')}</td><td><span class="status ${document.status === 'VIGENTE' && !expired ? 'ok' : 'danger'}">${escapeHtml(uiCodeLabel(document.status))}</span></td><td><a href="/api/v1/evidence/${document.evidence_id}" target="_blank" rel="noopener">${escapeHtml(document.filename)}</a></td><td class="actions">${can('Assets.Documents') ? `<button type="button" data-document-action="edit" data-id="${document.id}">Editar</button><button type="button" data-document-action="remove" data-id="${document.id}">Anular</button>` : ''}</td></tr>`;
  }).join('');
}


function renderAssetReleaseHistory(asset) {
  const section=$('#asset-release-history-section');
  const body=$('#asset-release-history-body');
  const warning=$('#asset-release-active-warning');
  if (!section || !body || !warning) return;
  section.classList.toggle('hidden', !asset);
  if (!asset) return;
  const blocks=asset.activeBlocks || [];
  const incidents=asset.activeIncidents || [];
  warning.innerHTML = asset.status === 'BLOQUEADO'
    ? `<strong>Bien bloqueado.</strong> ${blocks.length} bloqueo(s) operativo(s) activo(s) · ${incidents.length} incidente(s) abierto/resuelto sin cerrar.`
    : incidents.length ? `<strong>Bien habilitado con incidentes todavía abiertos:</strong> ${incidents.map(x=>escapeHtml(x.incident_number)).join(', ')}` : 'Sin bloqueos operativos activos.';
  body.innerHTML=(asset.manualReleaseHistory||[]).map((row)=>`<tr><td>${escapeHtml(formatDateTime(row.released_at))}</td><td>${escapeHtml(row.actor_name || row.actor_username || row.actor_user_id)}</td><td>${escapeHtml(row.reason)}</td><td>${escapeHtml(row.prior_status)} → Disponible</td><td>${Number(row.active_incident_count||0)}</td></tr>`).join('') || '<tr><td colspan="5">Sin habilitaciones manuales registradas.</td></tr>';
}

async function openAsset(assetId = null) {
  await ensureAssetCatalogs();
  $('#asset-form').reset(); $('#asset-id').value = ''; $('#asset-version').value = ''; state.currentAsset = null; const availableOption=$('#asset-master-status option[value="DISPONIBLE"]'); if (availableOption) availableOption.disabled=false;
  let asset = null;
  if (assetId) { asset = (await api(`/api/v1/assets/${assetId}`)).asset; state.currentAsset = asset; }
  fillAssetSelects(asset);
  $('#asset-dialog-title').textContent = asset ? `Editar ${asset.internal_code}` : 'Nuevo bien';
  clearAssetFormError();
  const photoPreview = $('#asset-photo-preview');
  const photoHelp = $('#asset-photo-help');
  $('#asset-photo').value = '';
  if (photoPreview) {
    if (asset?.photo_evidence_id) {
      photoPreview.src = `/api/v1/evidence/${encodeURIComponent(asset.photo_evidence_id)}?v=${encodeURIComponent(asset.version)}`;
      photoPreview.classList.remove('hidden');
      if (photoHelp) photoHelp.textContent = 'Foto actual. Elegí otra imagen para reemplazarla.';
    } else {
      photoPreview.removeAttribute('src'); photoPreview.classList.add('hidden');
      if (photoHelp) photoHelp.textContent = 'Opcional. Se mostrará al técnico para identificar la herramienta.';
    }
  }
  if (asset) {
    $('#asset-id').value = asset.id; $('#asset-version').value = asset.version; $('#asset-internal-code').value = asset.internal_code;
    $('#asset-category').value = asset.category_id; $('#asset-description').value = asset.description; $('#asset-serial-number').value = asset.serial_number || '';
    $('#asset-license-plate').value = asset.license_plate || ''; $('#asset-brand').value = asset.brand || ''; $('#asset-model').value = asset.model || '';
    $('#asset-location').value = asset.location_id; $('#asset-master-status').value = asset.status;
    const availableOption=$('#asset-master-status option[value="DISPONIBLE"]'); if (availableOption) availableOption.disabled = asset.status === 'BLOQUEADO';
    $('#asset-quantity-total').value = asset.quantity_total;
    $('#asset-quantity-available').value = asset.quantity_available; $('#asset-unit').value = asset.unit_of_measure || ''; $('#asset-odometer').value = asset.odometer ?? '';
    $('#asset-fuel-type').value = asset.fuel_type || ''; $('#asset-notes').value = asset.notes || ''; $('#asset-requires-work-order').checked = Boolean(asset.requires_work_order);
  } else { $('#asset-master-status').value = 'DISPONIBLE'; $('#asset-quantity-total').value = '1'; $('#asset-quantity-available').value = '1'; $('#asset-requires-work-order').checked = false; }
  $('#asset-location').disabled = Boolean(asset && asset.active);
  const more = $('#asset-more-data'); if (more) more.open = false;
  updateAssetFormForNature();
  renderAssetDocuments(asset); renderAssetReleaseHistory(asset); $('#asset-dialog').showModal();
}

function selectedAssetNature() {
  const category = state.categories.find((item) => item.id === $('#asset-category')?.value);
  return String(category?.nature || '').toUpperCase();
}

function showAssetFormError(message, focusNode = null) {
  const node = $('#asset-form-error');
  if (node) {
    node.textContent = message || 'No se pudo guardar el bien.';
    node.classList.remove('hidden');
    node.setAttribute('tabindex', '-1');
    node.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    node.focus({ preventScroll: true });
  }
  if (focusNode) {
    $('#asset-more-data')?.setAttribute('open', '');
    focusNode.focus();
  }
}

function clearAssetFormError() {
  const node = $('#asset-form-error');
  if (!node) return;
  node.textContent = '';
  node.classList.add('hidden');
  node.removeAttribute('tabindex');
}

function updateAssetFormForNature() {
  const nature = selectedAssetNature();
  $$('[data-asset-natures]').forEach((node) => {
    const allowed = String(node.dataset.assetNatures || '').split(',').map((item) => item.trim().toUpperCase()).filter(Boolean);
    node.classList.toggle('hidden', Boolean(allowed.length && !allowed.includes(nature)));
  });
  $('#asset-serial-number').required = ['SERIADO','KIT'].includes(nature);
  $('#asset-license-plate').required = nature === 'VEHICULO';
  const unitRequired = ['CANTIDAD','CONSUMIBLE'].includes(nature);
  $('#asset-unit').required = unitRequired;
  if (unitRequired && !$('#asset-unit').value.trim()) $('#asset-more-data').open = true;
  const workOrderCheckbox = $('#asset-requires-work-order');
  const workOrderLabel = workOrderCheckbox?.closest('label');
  const workOrderAllowed = nature !== 'VEHICULO';
  if (workOrderCheckbox) {
    workOrderCheckbox.disabled = !workOrderAllowed;
    if (!workOrderAllowed) workOrderCheckbox.checked = false;
  }
  workOrderLabel?.classList.toggle('hidden', !workOrderAllowed);
  const quantityFixed = ['VEHICULO','SERIADO','KIT'].includes(nature);
  if (quantityFixed && !$('#asset-id').value) {
    $('#asset-quantity-total').value = '1';
    $('#asset-quantity-available').value = $('#asset-master-status').value === 'DISPONIBLE' ? '1' : '0';
  }
  const hint = $('#asset-nature-hint');
  if (hint) hint.textContent = nature ? `Tipo: ${natureLabel(nature)}. Sólo se muestran los datos que aplican.` : '';
}

$('#asset-refresh').addEventListener('click', () => loadAssets().catch((error) => flash(error.message, 'error')));
$('#asset-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadAssets().catch((error) => flash(error.message, 'error')); });
$('#asset-create').addEventListener('click', () => openAsset().catch((error) => flash(error.message, 'error')));
$('#asset-category')?.addEventListener('change', () => { clearAssetFormError(); updateAssetFormForNature(); });
$('#asset-location')?.addEventListener('change', () => {
  const asset = state.currentAsset;
  const previous = $('#asset-category').value;
  refillAssetCategorySelect(asset, previous);
  clearAssetFormError();
  updateAssetFormForNature();
});
$('#asset-master-status')?.addEventListener('change', updateAssetFormForNature);
$('#asset-availability-bulk')?.addEventListener('click', async () => {
  try {
    const reviewable = state.assets.filter((asset) => {
      const codes = (asset.requestAvailability?.blockers || []).map((item) => item.code);
      return asset.active && asset.status === 'DISPONIBLE' && Number(asset.quantity_available) === 0 && codes.length > 0 && codes.every((code) => ['QUANTITY_ZERO','PREVENTIVE_REVIEW_REQUIRED'].includes(code));
    });
    if (!reviewable.length) throw new Error('No hay bienes habilitables de forma segura en la vista actual.');
    const values = await askFields('Habilitación masiva segura', [{ name: 'reason', label: 'Confirmación física y motivo común', type: 'textarea' }], {
      message: `${reviewable.length} bien(es) cumplen exclusivamente la condición de disponibilidad cero sin reservas, custodia, bloqueos, mantenimiento, incidentes ni kits personales. El backend volverá a validar cada uno dentro de una única transacción.`,
      confirmText: `Habilitar ${reviewable.length}`
    });
    if (!values) return;
    await api('/api/v1/assets/availability/preventive-import-review', { method: 'POST', body: JSON.stringify({ assetIds: reviewable.map((asset) => asset.id), reason: values.reason }) });
    flash(`${reviewable.length} bien(es) habilitados con trazabilidad.`);
    await loadAssets();
  } catch (error) { flash(error.message, 'error'); }
});
$('#asset-export-excel').addEventListener('click', async () => {
  try {
    const params = new URLSearchParams({ search: $('#asset-search').value, status: $('#asset-status').value, categoryId: $('#asset-category-filter').value, locationId: $('#asset-location-filter').value });
    if ($('#asset-active').value) params.set('active', $('#asset-active').value);
    await downloadFile(`/api/v1/assets/export.xlsx?${params}`, `INGAR_Bienes_${new Date().toISOString().slice(0, 10)}.xlsx`);
  } catch (error) { flash(error.message, 'error'); }
});
$('#asset-export').addEventListener('click', async () => {
  try { const params = new URLSearchParams({ search: $('#asset-search').value, status: $('#asset-status').value, categoryId: $('#asset-category-filter').value, locationId: $('#asset-location-filter').value }); if ($('#asset-active').value) params.set('active', $('#asset-active').value); await downloadFile(`/api/v1/assets/export?${params}`, `iwc-bienes-${new Date().toISOString().slice(0, 10)}.csv`); } catch (error) { flash(error.message, 'error'); }
});
$('#assets-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-asset-action]'); if (!button) return;
  const asset = state.assets.find((item) => item.id === button.dataset.id); if (!asset) return;
  try {
    if (button.dataset.assetAction === 'availability') {
      const diagnosis = (await api(`/api/v1/assets/${asset.id}/availability-diagnosis`)).diagnosis;
      const details = diagnosis.blockers.length
        ? diagnosis.blockers.map((item) => `${item.code}: ${item.detail}`).join('\n')
        : 'Sin bloqueos: el bien está visible para pedidos.';
      await askConfirm(`${asset.internal_code}\nEstado maestro: ${diagnosis.physicalStatus}\nCantidad: ${diagnosis.quantityAvailable} / ${diagnosis.quantityTotal}\nVisible para pedidos: ${diagnosis.requestVisible ? 'Sí' : 'No'}\n\n${details}`, { title: 'Diagnóstico de disponibilidad', confirmText: 'Cerrar' });
      return;
    }
    if (button.dataset.assetAction === 'availability-review') {
      const values = await askFields(`Revisar disponibilidad ${asset.internal_code}`, [{ name: 'reason', label: 'Confirmación física y motivo', type: 'textarea' }], {
        message: 'Sólo se habilitará si el backend confirma que no existen reservas, custodia, bloqueo, mantenimiento, incidente, kit personal u otro impedimento operativo.',
        confirmText: 'Habilitar tras revisión'
      });
      if (!values) return;
      await api('/api/v1/assets/availability/preventive-import-review', { method: 'POST', body: JSON.stringify({ assetIds: [asset.id], reason: values.reason }) });
      flash('Disponibilidad habilitada y auditada.');
      await loadAssets();
      return;
    }
    if (button.dataset.assetAction === 'edit') {
      if (asset.category_nature === 'VEHICULO' && typeof openVehicleEdit === 'function') await openVehicleEdit(asset.id);
      else await openAsset(asset.id);
    }
    if (button.dataset.assetAction === 'move') {
      if (asset.category_nature === 'VEHICULO') {
        if (typeof moveVehicle === 'function') { await moveVehicle(asset.id); return; }
        throw new Error('Los vehículos se mueven desde el módulo Vehículos.');
      }
      const destinations = activeLocations().filter((location) => location.id !== asset.location_id);
      if (!destinations.length) throw new Error('No hay otra ubicación activa disponible para mover el bien.');
      const values = await askFields(`Mover ${asset.internal_code}`, [
        { name: 'destinationLocationId', label: 'Ubicación destino', type: 'select', options: destinations.map((location) => ({ value: location.id, label: `${state.locations.sites.find((site) => site.id === location.site_id)?.code || ''}/${location.code} · ${location.name}` })) },
        { name: 'reason', label: 'Motivo (opcional)', type: 'textarea', required: false }
      ], { message: 'El movimiento se registrará con su transferencia, stock, auditoría e histórico.', confirmText: 'Mover' });
      if (!values) return;
      await api(`/api/v1/assets/${asset.id}/move`, { method: 'POST', body: JSON.stringify({ assetVersion: asset.version, destinationLocationId: values.destinationLocationId, reason: values.reason || null }) });
      flash('Bien movido y registrado en el ledger.');
      await loadAssets();
    }
    if (button.dataset.assetAction === 'duplicate') {
      if (asset.category_nature === 'KIT') throw new Error('Los kits personales no se duplican: cree un kit nuevo y seleccione sus herramientas físicas.');
      const fields = [{ name: 'internalCode', label: 'Nuevo código interno' }];
      if (['SERIADO', 'KIT'].includes(asset.category_nature)) fields.push({ name: 'serialNumber', label: 'Nuevo número de serie' });
      if (asset.category_nature === 'VEHICULO') {
        fields.push({ name: 'licensePlate', label: 'Nueva patente' });
        fields.push({ name: 'vin', label: 'Nuevo VIN', required: false });
        fields.push({ name: 'chassisNumber', label: 'Nuevo número de chasis', required: false });
        fields.push({ name: 'engineNumber', label: 'Nuevo número de motor', required: false });
      }
      const specialized = ['VEHICULO', 'KIT'].includes(asset.category_nature);
      const values = await askFields(`Duplicar ${asset.internal_code}`, fields, {
        message: specialized
          ? `Se duplicará el ${asset.category_nature === 'VEHICULO' ? 'perfil vehicular' : 'kit con toda su composición'} sin copiar identificadores únicos.`
          : 'Se creará un bien nuevo tomando este registro como base.',
        confirmText: 'Duplicar'
      });
      if (!values) return;
      await api(`/api/v1/assets/${asset.id}/duplicate`, { method: 'POST', body: JSON.stringify({
        internalCode: values.internalCode,
        serialNumber: values.serialNumber || null,
        licensePlate: values.licensePlate || null,
        vin: values.vin || null,
        chassisNumber: values.chassisNumber || null,
        engineNumber: values.engineNumber || null
      }) });
      flash(specialized ? 'Duplicación completa realizada.' : 'Bien duplicado.');
      await loadAssets();
    }
    if (button.dataset.assetAction === 'release') {
      const values = await askFields(`Habilitar ${asset.internal_code}`, [{ name: 'reason', label: 'Motivo obligatorio de habilitación', type: 'textarea' }], {
        message: 'Esta acción es exclusiva del Super Administrador. Levantará los bloqueos activos del bien y lo pondrá Disponible, pero NO borrará incidentes ni su trazabilidad.',
        confirmText: 'Habilitar bien', danger: true
      });
      if (!values) return;
      const result=await api(`/api/v1/assets/${asset.id}/manual-release`, { method:'POST', body:JSON.stringify({version:asset.version,reason:values.reason}) });
      const suffix=result.activeIncidents ? ` · ${result.activeIncidents} incidente(s) permanecen abiertos en el historial.` : '';
      flash(`Bien habilitado manualmente.${suffix}`);
      await loadAssets();
    }
    if (button.dataset.assetAction === 'toggle') {
      if (!await askConfirm(`${asset.active ? 'Inactivar' : 'Reactivar'} el bien ${asset.internal_code}?`, { title: 'Cambiar estado del bien', confirmText: asset.active ? 'Inactivar' : 'Reactivar', danger: asset.active })) return;
      await api(`/api/v1/assets/${asset.id}/${asset.active ? 'inactivate' : 'reactivate'}`, { method: 'POST', body: JSON.stringify({ version: asset.version }) }); flash('Estado actualizado.'); await loadAssets();
    }
  } catch (error) { flash(error.message, 'error'); }
});

async function prepareAssetPhotoPayload(file) {
  if (!file) return null;
  if (!['image/png','image/jpeg','image/webp'].includes(String(file.type || '').toLowerCase())) throw new Error('La fotografía debe ser PNG, JPG o WEBP.');
  try {
    const bitmap = await createImageBitmap(file);
    const maxSide = 1600;
    const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    let blob = null;
    for (const quality of [0.86,0.74,0.62,0.5]) {
      blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
      if (blob && blob.size <= 1850000) break;
    }
    if (!blob || blob.size > 2000000) throw new Error('La fotografía sigue siendo demasiado grande.');
    return { originalFilename: `${String(file.name || 'herramienta').replace(/\.[^.]+$/, '')}.jpg`, dataUrl: await fileToDataUrl(blob) };
  } catch (error) {
    if (file.size <= 1850000) return { originalFilename: file.name, dataUrl: await fileToDataUrl(file) };
    throw error;
  }
}

$('#asset-photo').addEventListener('change', async () => {
  const file = $('#asset-photo').files?.[0];
  const preview = $('#asset-photo-preview');
  const help = $('#asset-photo-help');
  if (!file) return;
  if (!String(file.type || '').startsWith('image/')) { $('#asset-photo').value=''; if (help) help.textContent='Elegí una imagen válida.'; return; }
  if (preview) { const objectUrl=URL.createObjectURL(file); preview.src=objectUrl; preview.classList.remove('hidden'); preview.onload=()=>URL.revokeObjectURL(objectUrl); }
  if (help) help.textContent = 'Nueva foto lista. Se guardará junto con el bien.';
});

$('#asset-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    clearAssetFormError();
    const nature = selectedAssetNature();
    if (['CANTIDAD','CONSUMIBLE'].includes(nature) && !$('#asset-unit').value.trim()) {
      showAssetFormError('La unidad de medida es obligatoria para bienes por cantidad y consumibles.', $('#asset-unit'));
      return;
    }
    const id = $('#asset-id').value;
    const payload = { categoryId: $('#asset-category').value, internalCode: $('#asset-internal-code').value, description: $('#asset-description').value, serialNumber: $('#asset-serial-number').value, licensePlate: $('#asset-license-plate').value, brand: $('#asset-brand').value, model: $('#asset-model').value, status: $('#asset-master-status').value, quantityTotal: $('#asset-quantity-total').value, quantityAvailable: $('#asset-quantity-available').value, unitOfMeasure: $('#asset-unit').value, odometer: $('#asset-odometer').value, fuelType: $('#asset-fuel-type').value, notes: $('#asset-notes').value, requiresWorkOrder: $('#asset-requires-work-order').checked, active: $('#asset-master-status').value !== 'BAJA', version: id ? Number($('#asset-version').value) : undefined };
    if (!id || !state.currentAsset?.active) payload.locationId = $('#asset-location').value;
    let result = await api(id ? `/api/v1/assets/${id}` : '/api/v1/assets', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    const file = $('#asset-photo').files[0];
    if (file) {
      const photoPayload = await prepareAssetPhotoPayload(file);
      result = await api(`/api/v1/assets/${result.asset.id}/photo`, { method: 'POST', body: JSON.stringify({ version: result.asset.version, ...photoPayload }) });
    }
    $('#asset-dialog').close(); clearAssetFormError(); flash('Bien guardado.'); await loadAssets();
  } catch (error) {
    showAssetFormError(error.message || 'No se pudo guardar el bien.');
    flash(error.message, 'error');
  }
});

$('#asset-document-create').addEventListener('click', () => { $('#document-form').reset(); $('#document-id').value = ''; $('#document-version').value = ''; $('#document-dialog').showModal(); });
$('#asset-documents-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-document-action]'); if (!button || !state.currentAsset) return;
  const document = state.currentAsset.documents.find((item) => item.id === button.dataset.id); if (!document) return;
  if (button.dataset.documentAction === 'edit') {
    $('#document-form').reset(); $('#document-id').value = document.id; $('#document-version').value = document.version; $('#document-type').value = document.type; $('#document-title').value = document.title; $('#document-issued').value = document.issued_at || ''; $('#document-expires').value = document.expires_at || ''; $('#document-status').value = document.status; $('#document-notes').value = document.notes || ''; $('#document-dialog').showModal();
  }
  if (button.dataset.documentAction === 'remove') {
    if (!await askConfirm(`Anular el documento ${document.title}?`, { title: 'Anular documento', confirmText: 'Anular', danger: true })) return;
    try {
      await api(`/api/v1/assets/${state.currentAsset.id}/documents/${document.id}`, { method: 'DELETE', body: JSON.stringify({ version: document.version, reason: 'Anulación desde interfaz administrativa' }) });
      state.currentAsset = (await api(`/api/v1/assets/${state.currentAsset.id}`)).asset;
      renderAssetDocuments(state.currentAsset);
      flash('Documento anulado.');
    } catch (error) { flash(error.message, 'error'); }
  }
});
$('#document-form').addEventListener('submit', async (event) => {
  event.preventDefault(); if (!state.currentAsset) return;
  try {
    const id = $('#document-id').value;
    const payload = { type: $('#document-type').value, title: $('#document-title').value, issuedAt: $('#document-issued').value, expiresAt: $('#document-expires').value, status: $('#document-status').value, notes: $('#document-notes').value, version: id ? Number($('#document-version').value) : undefined };
    if (!id) { const file = $('#document-file').files[0]; if (!file) throw new Error('Seleccione el archivo documental.'); payload.originalFilename = file.name; payload.dataUrl = await fileToDataUrl(file); }
    await api(id ? `/api/v1/assets/${state.currentAsset.id}/documents/${id}` : `/api/v1/assets/${state.currentAsset.id}/documents`, { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    state.currentAsset = (await api(`/api/v1/assets/${state.currentAsset.id}`)).asset; renderAssetDocuments(state.currentAsset); $('#document-dialog').close(); flash('Documento guardado.');
  } catch (error) { flash(error.message, 'error'); }
});

async function loadCategories() {
  const data = await api('/api/v1/asset-categories'); state.categories = data.items;
  const search = $('#category-search').value.trim().toLowerCase(); const nature = $('#category-nature').value;
  const items = data.items.filter((item) => (!search || item.code.toLowerCase().includes(search) || item.name.toLowerCase().includes(search)) && (!nature || item.nature === nature));
  $('#categories-body').innerHTML = items.map((item) => {
    const actions = can('Assets.Update')
      ? `<button data-category-action="edit" data-category-id="${item.id}">Editar</button> <button data-category-action="${item.active ? 'deactivate' : 'reactivate'}" data-category-id="${item.id}" data-category-version="${item.version}">${item.active ? 'Desactivar' : 'Reactivar'}</button> <button class="danger" data-category-action="delete" data-category-id="${item.id}" data-category-version="${item.version}">Eliminar categoría</button>`
      : '';
    return `<tr><td><code>${escapeHtml(item.code)}</code></td><td>${escapeHtml(item.name)}</td><td>${escapeHtml(uiCodeLabel(item.nature))}</td><td>${item.serialized ? 'Individual/serializado' : `Por cantidad · ${escapeHtml(item.default_unit || 'sin unidad')}`}</td><td>${item.requires_inspection ? 'Sí' : 'No'}</td><td>${item.requires_return ? 'Sí' : 'No'}</td><td><span class="status ${item.active ? 'ok' : 'danger'}">${item.active ? 'Activa' : 'Inactiva'}</span></td><td class="actions">${actions}</td></tr>`;
  }).join('');
}
$('#category-refresh').addEventListener('click', () => loadCategories().catch((error) => flash(error.message, 'error')));
$('#category-create').addEventListener('click', () => {
  $('#category-form').reset();
  $('#category-id').value = '';
  $('#category-version').value = '';
  $('#category-serialized').checked = true;
  $('#category-inspection').checked = true;
  $('#category-return').checked = true;
  $('#category-state-note').textContent = 'La categoría se creará activa. Luego podrá desactivarse o reactivarse desde la tabla.';
  $('#category-dialog-title').textContent = 'Nueva categoría';
  $('#category-dialog').showModal();
});
$('#categories-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-category-action]');
  if (!button) return;
  const category = state.categories.find((item) => item.id === button.dataset.categoryId);
  if (!category) return;
  try {
    if (button.dataset.categoryAction === 'edit') {
      $('#category-form').reset();
      $('#category-id').value = category.id;
      $('#category-version').value = category.version;
      $('#category-code').value = category.code;
      $('#category-name').value = category.name;
      $('#category-nature-edit').value = category.nature;
      $('#category-default-unit').value = category.default_unit || '';
      $('#category-serialized').checked = Boolean(category.serialized);
      $('#category-inspection').checked = Boolean(category.requires_inspection);
      $('#category-return').checked = Boolean(category.requires_return);
      $('#category-state-note').textContent = `Estado actual: ${category.active ? 'activa' : 'inactiva'}. El estado se modifica únicamente desde la tabla.`;
      $('#category-dialog-title').textContent = `Editar ${category.code}`;
      $('#category-dialog').showModal();
      return;
    }
    if (button.dataset.categoryAction === 'delete') {
      if (!await askConfirm(`Eliminar lógicamente la categoría ${category.code}? La operación sólo se permitirá si no tiene bienes asociados.`, { title: 'Eliminar categoría', confirmText: 'Eliminar categoría', danger: true })) return;
      await api(`/api/v1/asset-categories/${category.id}`, { method: 'DELETE', body: JSON.stringify({ version: Number(button.dataset.categoryVersion), reason: 'Eliminación lógica desde interfaz de categorías' }) });
      state.categories = [];
      flash('Categoría eliminada lógicamente.');
      await loadCategories();
      return;
    }
    const active = button.dataset.categoryAction === 'reactivate';
    if (!await askConfirm(`${active ? 'Reactivar' : 'Desactivar'} la categoría ${category.code}?`, { title: `${active ? 'Reactivar' : 'Desactivar'} categoría`, confirmText: active ? 'Reactivar' : 'Desactivar', danger: !active })) return;
    await api(`/api/v1/asset-categories/${category.id}/${active ? 'reactivate' : 'deactivate'}`, { method: 'POST', body: JSON.stringify({ version: Number(button.dataset.categoryVersion) }) });
    state.categories = [];
    flash(`Categoría ${active ? 'reactivada' : 'desactivada'}.`);
    await loadCategories();
  } catch (error) { flash(error.message, 'error'); }
});
$('#category-nature-edit').addEventListener('change', () => { const nature = $('#category-nature-edit').value; $('#category-serialized').checked = ['SERIADO', 'KIT', 'VEHICULO'].includes(nature); $('#category-return').checked = nature !== 'CONSUMIBLE'; });
$('#category-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('#category-id').value;
    const payload = { code: $('#category-code').value, name: $('#category-name').value, nature: $('#category-nature-edit').value, defaultUnit: $('#category-default-unit').value, serialized: $('#category-serialized').checked, requiresInspection: $('#category-inspection').checked, requiresReturn: $('#category-return').checked, version: id ? Number($('#category-version').value) : undefined };
    await api(id ? `/api/v1/asset-categories/${id}` : '/api/v1/asset-categories', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    state.categories = [];
    $('#category-dialog').close();
    flash('Categoría guardada.');
    await loadCategories();
  } catch (error) { flash(error.message, 'error'); }
});


function formatDateTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? date.toLocaleString() : String(value);
}

function requestStatusClass(status) {
  if (['APROBADA', 'ENTREGADA', 'LISTA_PARA_ENTREGA'].includes(status)) return 'ok';
  if (['BLOQUEADA', 'CANCELADA', 'EXPIRADA'].includes(status)) return 'danger';
  return 'neutral';
}

function requestStatusLabel(status) {
  const code = String(status || '').toUpperCase();
  return ({
    INICIO: 'Inicio', BORRADOR: 'Borrador', PENDIENTE_AUTORIZACION: 'Por autorizar', APROBADA: 'Aprobada',
    PREPARANDO: 'En preparación', LISTA_PARA_ENTREGA: 'Lista para entregar', ENTREGADA: 'Entregada',
    BLOQUEADA: 'Bloqueada', CANCELADA: 'Cancelada', EXPIRADA: 'Vencida', VALIDADO: 'Validado',
    RESERVADO: 'Reservado', CANCELADO: 'Cancelado', LIBERADA: 'Liberada'
  })[code] || String(status || '—').replaceAll('_', ' ').toLowerCase().replace(/^./, (c) => c.toUpperCase());
}

function custodyStatusLabel(status) {
  const code = String(status || '').toUpperCase();
  return ({
    ABIERTA: 'Fuera del pañol', DEVOLUCION_DECLARADA: 'Pendiente de recibir', RECEPCION_PENDIENTE: 'Recibiendo',
    TRANSFERENCIA_PENDIENTE: 'Transferencia pendiente', INCIDENTE: 'Con problema', CERRADA: 'Recibida'
  })[code] || requestStatusLabel(status);
}

function conditionLabel(condition) {
  const code = String(condition || '').toUpperCase();
  return ({ CONFORME: 'Conforme', OBSERVADO: 'Con observación', DANADO: 'Dañado', INCOMPLETO: 'Incompleto', CONDICION_INSEGURA: 'Condición insegura' })[code]
    || requestStatusLabel(condition);
}

function natureLabel(nature) {
  const code = String(nature || '').toUpperCase();
  return ({ VEHICULO: 'Vehículo', SERIADO: 'Bien serializado', KIT: 'Kit', CONSUMIBLE: 'Consumible', CANTIDAD: 'Herramienta / cantidad' })[code]
    || requestStatusLabel(nature);
}
