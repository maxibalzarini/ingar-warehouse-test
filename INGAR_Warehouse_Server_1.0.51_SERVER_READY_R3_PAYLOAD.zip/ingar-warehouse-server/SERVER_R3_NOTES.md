# INGAR Warehouse Server Edition 1.0.51 R3

- Base: Server R2 estable + F7.1 Electron funcional.
- Schema máximo 053. No migración 054.
- Node Linux fijado a 22 / ABI 127 en launcher.
- Ruta de importación validada en self-test: POST /api/v1/imports/assets/validate no puede devolver 404.
- Documento real opcional con identidad técnica INTERNO/AUTO-* cuando se omite.
- Exportación Excel directa del maestro de bienes incluida.
- Datos operativos externos al código y preservados en actualización.
