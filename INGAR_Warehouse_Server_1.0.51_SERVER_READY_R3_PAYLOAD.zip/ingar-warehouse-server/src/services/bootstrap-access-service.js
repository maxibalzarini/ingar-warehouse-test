'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID, randomBytes } = require('node:crypto');
const { openDatabase, closeDatabase, getDb, transaction } = require('../db/database');
const { seedBase } = require('./seed-service');
const { hashPassword, validatePassword } = require('../security/password');
const { appendAudit } = require('./audit-service');
const { requiredString } = require('../security/validation');

const BOOTSTRAP_USERNAME = 'administrador';
const BOOTSTRAP_REVISION = 'F2-DIRECT-SELF-SETUP-R3';
const BOOTSTRAP_STATE_KEY = 'security.initialAccessState';
const FIRST_ACCESS_FILENAME = 'PRIMER_ACCESO.txt';

const LOCAL_RECOVERY_TTL_MS = 10 * 60 * 1000;
const localRecoverySessions = new Map();

function listRecoverableAdministrators(db = getDb()) {
  return db.prepare(`SELECT
      ua.id,
      ua.username,
      ua.active,
      ua.deleted_at,
      ua.must_change_password,
      p.full_name,
      p.status AS person_status,
      p.deleted_at AS person_deleted_at
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL'
    GROUP BY ua.id, ua.username, ua.active, ua.deleted_at, ua.must_change_password,
      p.full_name, p.status, p.deleted_at, ua.created_at
    ORDER BY
      CASE WHEN ua.active = 1 AND ua.deleted_at IS NULL AND p.status = 'ACTIVA' AND p.deleted_at IS NULL THEN 0 ELSE 1 END,
      COALESCE(NULLIF(p.full_name, ''), ua.username) COLLATE NOCASE,
      ua.created_at`).all().map((row) => ({
        id: row.id,
        username: row.username,
        fullName: row.full_name || 'Administrador General',
        active: Boolean(row.active) && !row.deleted_at && row.person_status === 'ACTIVA' && !row.person_deleted_at,
        setupPending: Boolean(row.must_change_password)
      }));
}

function pruneLocalRecoverySessions() {
  const now = Date.now();
  for (const [token, session] of localRecoverySessions.entries()) {
    if (!session || Number(session.expiresAtMs) <= now) localRecoverySessions.delete(token);
  }
}

function startLocalAdministratorRecovery(requestContext = {}) {
  pruneLocalRecoverySessions();
  const accounts = listRecoverableAdministrators();
  if (!accounts.length) {
    throw Object.assign(new Error('No hay una cuenta Administrador General disponible para recuperar.'), {
      status: 409,
      code: 'LOCAL_RECOVERY_NO_ADMIN_ACCOUNT'
    });
  }
  const recoveryToken = randomBytes(32).toString('hex');
  const expiresAtMs = Date.now() + LOCAL_RECOVERY_TTL_MS;
  localRecoverySessions.set(recoveryToken, {
    expiresAtMs,
    ip: requestContext.ip || null,
    userAgent: requestContext.userAgent || null
  });
  appendAudit({
    action: 'SECURITY.LOCAL_ADMIN_RECOVERY_STARTED',
    entityType: 'user_account',
    entityId: null,
    after: { accountsAvailable: accounts.length, expiresAt: new Date(expiresAtMs).toISOString() },
    correlationId: requestContext.correlationId || randomUUID(),
    source: 'LOCAL_LOGIN_RECOVERY',
    ipAddress: requestContext.ip || null,
    equipment: requestContext.userAgent || null,
    reason: 'FORGOT_CREDENTIALS',
    result: 'SUCCESS'
  });
  return { recoveryToken, expiresAt: new Date(expiresAtMs).toISOString(), accounts };
}

function validateLocalRecoverySession(recoveryToken, requestContext = {}) {
  pruneLocalRecoverySessions();
  const token = String(recoveryToken || '').trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(token)) {
    throw Object.assign(new Error('La recuperación venció. Inicie nuevamente el proceso.'), {
      status: 410,
      code: 'LOCAL_RECOVERY_SESSION_INVALID'
    });
  }
  const session = localRecoverySessions.get(token);
  if (!session || session.expiresAtMs <= Date.now()) {
    localRecoverySessions.delete(token);
    throw Object.assign(new Error('La recuperación venció. Inicie nuevamente el proceso.'), {
      status: 410,
      code: 'LOCAL_RECOVERY_SESSION_EXPIRED'
    });
  }
  if ((session.ip || null) !== (requestContext.ip || null) ||
      (session.userAgent || null) !== (requestContext.userAgent || null)) {
    throw Object.assign(new Error('La recuperación sólo puede completarse desde la misma ventana local que la inició.'), {
      status: 403,
      code: 'LOCAL_RECOVERY_CONTEXT_MISMATCH'
    });
  }
  return { token, session };
}

async function completeLocalAdministratorRecovery(payload = {}, requestContext = {}) {
  const { token } = validateLocalRecoverySession(payload.recoveryToken, requestContext);
  if (payload.confirmation !== 'BLANQUEAR') {
    throw Object.assign(new Error('Debe confirmar expresamente el blanqueo de credenciales.'), {
      status: 422,
      code: 'LOCAL_RECOVERY_CONFIRMATION_REQUIRED'
    });
  }

  const accountId = String(payload.accountId || '').trim();
  const desiredUsername = String(payload.username || '').trim().toLowerCase();
  const credential = String(payload.password || '');
  const confirmation = String(payload.confirmPassword || '');
  if (!accountId) throw Object.assign(new Error('Seleccione la cuenta administrativa a recuperar.'), { status: 422, code: 'LOCAL_RECOVERY_ACCOUNT_REQUIRED' });
  if (!/^[a-z0-9._-]{3,40}$/i.test(desiredUsername)) {
    throw Object.assign(new Error('El usuario debe tener entre 3 y 40 caracteres y usar sólo letras, números, punto, guion o guion bajo.'), { status: 422, code: 'LOCAL_RECOVERY_USERNAME_INVALID' });
  }
  if (credential !== confirmation) {
    throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'LOCAL_RECOVERY_PASSWORD_MISMATCH' });
  }
  const errors = validatePassword(credential, 4, 8);
  if (errors.length) throw Object.assign(new Error(errors[0]), { status: 422, code: 'LOCAL_RECOVERY_PASSWORD_POLICY' });

  const db = getDb();
  const account = db.prepare(`SELECT ua.*, p.full_name, p.status AS person_status, p.deleted_at AS person_deleted_at
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE ua.id = ? AND r.code = 'ADMIN_GENERAL'
    ORDER BY ua.created_at
    LIMIT 1`).get(accountId);
  if (!account) {
    throw Object.assign(new Error('La cuenta administrativa ya no está disponible para recuperar.'), {
      status: 409,
      code: 'LOCAL_RECOVERY_ACCOUNT_NOT_AVAILABLE'
    });
  }
  const conflict = db.prepare('SELECT id FROM user_account WHERE username = ? COLLATE NOCASE AND id <> ? AND deleted_at IS NULL LIMIT 1').get(desiredUsername, account.id);
  if (conflict) throw Object.assign(new Error('Ese nombre de usuario ya está en uso.'), { status: 409, code: 'LOCAL_RECOVERY_USERNAME_TAKEN' });

  const passwordHash = await hashPassword(credential);
  const now = new Date().toISOString();
  const state = getBootstrapState(db);
  transaction((tx) => {
    tx.prepare(`UPDATE person SET status = 'ACTIVA', deleted_at = NULL,
        version = version + 1, updated_at = ? WHERE id = ?`).run(now, account.person_id);
    tx.prepare(`UPDATE user_account SET username = ?, password_hash = ?, failed_attempts = 0,
        locked_until = NULL, active = 1, must_change_password = 0, credential_setup_reason = 'NONE', deleted_at = NULL,
        last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?`)
      .run(desiredUsername, passwordHash, now, now, account.id);
    tx.prepare(`UPDATE user_session SET revoked_at = COALESCE(revoked_at, ?),
        revocation_reason = COALESCE(revocation_reason, 'LOCAL_FORGOT_CREDENTIALS_RECOVERY')
        WHERE user_id = ? AND revoked_at IS NULL`).run(now, account.id);
    tx.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), account.id, passwordHash, now);
    setBootstrapState(tx, {
      ...(state || {}),
      revision: BOOTSTRAP_REVISION,
      status: 'COMPLETED',
      bootstrapUserId: account.id,
      username: desiredUsername,
      recoveredAt: now,
      recoveryMode: 'LOCAL_LOGIN_FORGOT_CREDENTIALS',
      credentialFile: null
    });
    appendAudit({
      actorUserId: null,
      actorRole: null,
      action: 'SECURITY.LOCAL_ADMIN_CREDENTIALS_RESET',
      entityType: 'user_account',
      entityId: account.id,
      before: { username: account.username, active: Boolean(account.active), deleted: Boolean(account.deleted_at) },
      after: { username: desiredUsername, active: true, deleted: false, sessionsRevoked: true, passwordPolicy: 'ALPHANUMERIC_4_8', expires: false },
      correlationId: requestContext.correlationId || randomUUID(),
      source: 'LOCAL_LOGIN_RECOVERY',
      ipAddress: requestContext.ip || null,
      equipment: requestContext.userAgent || null,
      reason: 'FORGOT_CREDENTIALS_CONFIRMED',
      result: 'SUCCESS'
    }, tx);
  });
  localRecoverySessions.delete(token);
  removeFirstAccessFile(path.join(path.dirname(require('../config/runtime').dataDir), FIRST_ACCESS_FILENAME));
  return { recovered: true, username: desiredUsername, userId: account.id };
}

function removeFirstAccessFile(firstAccessFile) {
  fs.rmSync(firstAccessFile, { force: true });
}

function getBootstrapState(db = getDb()) {
  const row = db.prepare(`SELECT value_json FROM system_setting
    WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' AND key = ? LIMIT 1`).get(BOOTSTRAP_STATE_KEY);
  if (!row) return null;
  try { return JSON.parse(row.value_json); } catch { return { status: 'INVALID_STATE' }; }
}

function setBootstrapState(db, state) {
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO system_setting(
      id, scope_type, scope_id, key, value_json, version, updated_by, created_at, updated_at
    ) VALUES (?, 'SYSTEM', 'GLOBAL', ?, ?, 1, NULL, ?, ?)
    ON CONFLICT(scope_type, scope_id, key) DO UPDATE SET
      value_json = excluded.value_json,
      version = system_setting.version + 1,
      updated_by = NULL,
      updated_at = excluded.updated_at`)
    .run(randomUUID(), BOOTSTRAP_STATE_KEY, JSON.stringify(state), now, now);
  return state;
}

function findActiveAdministrator(db) {
  return db.prepare(`SELECT ua.*, p.status AS person_status
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL'
      AND ua.active = 1
      AND ua.deleted_at IS NULL
      AND p.status = 'ACTIVA'
      AND p.deleted_at IS NULL
    ORDER BY ua.created_at
    LIMIT 1`).get();
}

function findRecoverableAdministrator(db, username = BOOTSTRAP_USERNAME) {
  return db.prepare(`SELECT ua.*, p.status AS person_status, p.deleted_at AS person_deleted_at
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id AND r.code = 'ADMIN_GENERAL'
    WHERE ua.username = ? COLLATE NOCASE
    ORDER BY ua.created_at
    LIMIT 1`).get(username);
}

function createInitialAdministrator(db, passwordHash, now, identity) {
  const adminRole = db.prepare("SELECT id FROM role WHERE code = 'ADMIN_GENERAL' AND active = 1 LIMIT 1").get();
  if (!adminRole) throw Object.assign(new Error('No existe el rol ADMIN_GENERAL requerido para el acceso inicial.'), { code: 'ADMIN_ROLE_MISSING' });
  const personId = randomUUID();
  const userId = randomUUID();
  db.prepare(`INSERT INTO person(
      id, document_type, document_number, full_name, email, phone, status,
      version, created_at, updated_at, deleted_at
    ) VALUES (?, ?, ?, ?, NULL, NULL, 'ACTIVA', 1, ?, ?, NULL)`)
    .run(personId, identity.documentType, identity.documentNumber, identity.fullName, now, now);
  db.prepare(`INSERT INTO user_account(
      id, person_id, username, password_hash, failed_attempts, locked_until,
      active, must_change_password, credential_setup_reason, last_login_at, last_password_change_at,
      version, created_at, updated_at, deleted_at
    ) VALUES (?, ?, ?, ?, 0, NULL, 1, 0, 'NONE', NULL, ?, 1, ?, ?, NULL)`)
    .run(userId, personId, identity.username, passwordHash, now, now, now);
  db.prepare(`INSERT INTO user_role_scope(
      id, user_id, role_id, site_id, location_id, valid_from, valid_to, created_at, updated_at
    ) VALUES (?, ?, ?, NULL, NULL, ?, NULL, ?, ?)`)
    .run(randomUUID(), userId, adminRole.id, now, now, now);
  return { userId, personId, roleId: adminRole.id };
}

async function migrateExistingAdministratorToF2SelfSetup(db, activeAdmin, firstAccessFile, state) {
  if (state?.revision === BOOTSTRAP_REVISION) return null;
  const internalSecret = `${randomUUID()}${randomUUID()}`;
  const passwordHash = await hashPassword(internalSecret);
  const now = new Date().toISOString();
  transaction((tx) => {
    tx.prepare(`UPDATE user_account SET password_hash = ?, must_change_password = 1, credential_setup_reason = 'INITIAL_SETUP', failed_attempts = 0,
      locked_until = NULL, last_password_change_at = NULL, version = version + 1, updated_at = ? WHERE id = ?`)
      .run(passwordHash, now, activeAdmin.id);
    tx.prepare(`UPDATE user_session SET revoked_at = COALESCE(revoked_at, ?),
      revocation_reason = COALESCE(revocation_reason, 'F2_ACCESS_MIGRATION')
      WHERE user_id = ? AND revoked_at IS NULL`).run(now, activeAdmin.id);

    // F2-R2: cualquier solicitante puramente operativo debe definir su propio acceso
    // en la tablet. Esto corrige instalaciones F2 anteriores que ya habian grabado
    // PINes o credenciales generadas y por eso saltaban directamente al login viejo.
    const operationalRequesterIds = tx.prepare(`SELECT ua.id
      FROM user_account ua
      JOIN user_role_scope urs ON urs.user_id = ua.id
      JOIN role r ON r.id = urs.role_id
      WHERE ua.active = 1 AND ua.deleted_at IS NULL
      GROUP BY ua.id
      HAVING SUM(CASE WHEN r.code = 'SOLICITANTE' THEN 1 ELSE 0 END) > 0
         AND SUM(CASE WHEN r.code NOT IN ('SOLICITANTE','PANOLERO') THEN 1 ELSE 0 END) = 0`).all().map((row) => row.id);
    for (const userId of operationalRequesterIds) {
      tx.prepare(`UPDATE user_account SET must_change_password = 1, credential_setup_reason = 'INITIAL_SETUP', failed_attempts = 0,
        locked_until = NULL, last_password_change_at = NULL, version = version + 1, updated_at = ?
        WHERE id = ?`).run(now, userId);
      tx.prepare(`UPDATE user_session SET revoked_at = COALESCE(revoked_at, ?),
        revocation_reason = COALESCE(revocation_reason, 'F2_R2_REQUESTER_SELF_SETUP')
        WHERE user_id = ? AND revoked_at IS NULL`).run(now, userId);
    }

    setBootstrapState(tx, {
      revision: BOOTSTRAP_REVISION,
      status: 'AWAITING_SELF_SETUP',
      bootstrapUserId: activeAdmin.id,
      username: activeAdmin.username,
      migratedAt: now,
      migration: 'LEGACY_ACCESS_TO_DIRECT_SELF_SETUP',
      requesterSelfSetupCount: operationalRequesterIds.length,
      credentialFile: null
    });
    appendAudit({
      actorUserId: activeAdmin.id, actorRole: 'ADMIN_GENERAL',
      action: 'SECURITY.F2_ACCESS_MIGRATION', entityType: 'user_account', entityId: activeAdmin.id,
      before: { username: activeAdmin.username, legacyRevision: state?.revision || null },
      after: { setupRequired: true, passwordPolicy: 'ALPHANUMERIC_4_8', requesterSelfSetupCount: operationalRequesterIds.length },
      correlationId: randomUUID(), source: 'SYSTEM', reason: BOOTSTRAP_REVISION, result: 'SUCCESS'
    }, tx);
  });
  removeFirstAccessFile(firstAccessFile);
  return {
    applied: true, created: false, migratedExistingInstallation: true, preservedOperationalData: true,
    username: null, password: null, mustChangePassword: true, credentialFileAvailable: false,
    recoveryRequired: false, firstAccessFile: null, state: getBootstrapState(db)
  };
}

async function repairIncompleteInitialCredential(db, activeAdmin, firstAccessFile, state) {
  // Compatibilidad con paquetes anteriores: cualquier acceso inicial pendiente se
  // convierte al nuevo flujo de alta directa y autoconfiguración.
  const isBootstrapAccount = state?.bootstrapUserId === activeAdmin.id;
  const pending = Boolean(activeAdmin.must_change_password) && (!state || isBootstrapAccount || ['AWAITING_PASSWORD_CHANGE','RECOVERY_REQUIRED','AWAITING_SELF_SETUP'].includes(state.status));
  if (!pending) return null;
  removeFirstAccessFile(firstAccessFile);
  const now = new Date().toISOString();
  const nextState = setBootstrapState(db, {
    ...(state || {}),
    revision: BOOTSTRAP_REVISION,
    status: 'AWAITING_SELF_SETUP',
    bootstrapUserId: activeAdmin.id,
    username: activeAdmin.username,
    migratedAt: now,
    reason: null,
    credentialFile: null
  });
  return {
    applied: true,
    created: false,
    migratedLegacyBootstrap: true,
    preservedExistingAccount: false,
    username: activeAdmin.username,
    password: null,
    mustChangePassword: true,
    credentialFileAvailable: false,
    recoveryRequired: false,
    firstAccessFile: null,
    state: nextState
  };
}

async function ensureInitialAccess(userDataRoot) {
  const firstAccessFile = path.join(userDataRoot, FIRST_ACCESS_FILENAME);
  openDatabase();
  seedBase();
  try {
    const db = getDb();
    const state = getBootstrapState(db);
    const activeAdmin = findActiveAdministrator(db);

    if (activeAdmin) {
      const upgraded = await migrateExistingAdministratorToF2SelfSetup(db, activeAdmin, firstAccessFile, state);
      if (upgraded) return upgraded;
      const migrated = await repairIncompleteInitialCredential(db, activeAdmin, firstAccessFile, state);
      if (migrated) return migrated;
      removeFirstAccessFile(firstAccessFile);
      if (!state) {
        setBootstrapState(db, {
          revision: BOOTSTRAP_REVISION,
          status: 'EXISTING_ADMIN_PRESERVED',
          preservedUserId: activeAdmin.id,
          username: activeAdmin.username,
          recordedAt: new Date().toISOString()
        });
      }
      return {
        applied: false,
        created: false,
        preservedExistingAccount: true,
        username: activeAdmin.username,
        password: null,
        mustChangePassword: false,
        credentialFileAvailable: false,
        recoveryRequired: false,
        firstAccessFile: null,
        state: getBootstrapState(db)
      };
    }

    const accountCount = Number(db.prepare('SELECT COUNT(*) AS count FROM user_account').get().count);
    const pendingFreshAdministratorSetup = Boolean(
      accountCount === 0
      && state?.status === 'AWAITING_SELF_SETUP'
      && state.pendingAdministratorCreation === true
    );
    if (pendingFreshAdministratorSetup) {
      removeFirstAccessFile(firstAccessFile);
      return {
        applied: false,
        created: false,
        pendingAdministratorCreation: true,
        preservedExistingAccount: false,
        username: null,
        password: null,
        mustChangePassword: true,
        credentialFileAvailable: false,
        recoveryRequired: false,
        firstAccessFile: null,
        state
      };
    }
    if (accountCount > 0 || state) {
      removeFirstAccessFile(firstAccessFile);
      const recoveryState = {
        ...(state || {}),
        revision: BOOTSTRAP_REVISION,
        status: 'RECOVERY_REQUIRED',
        detectedAt: new Date().toISOString(),
        reason: 'NO_ACTIVE_ADMIN_WITH_EXISTING_SECURITY_STATE'
      };
      setBootstrapState(db, recoveryState);
      const error = new Error('No existe un Administrador General activo. Ejecute RECUPERAR_ADMINISTRADOR.bat.');
      error.code = 'ADMIN_RECOVERY_REQUIRED';
      throw error;
    }

    const now = new Date().toISOString();
    transaction((tx) => {
      setBootstrapState(tx, {
        revision: BOOTSTRAP_REVISION,
        status: 'AWAITING_SELF_SETUP',
        pendingAdministratorCreation: true,
        createdAt: now,
        credentialFile: null
      });
      appendAudit({
        action: 'SECURITY.INITIAL_ADMIN_SETUP_PENDING',
        entityType: 'system_setting',
        entityId: BOOTSTRAP_STATE_KEY,
        after: { setupRequired: true, identityRequired: true, credentialType: 'SELF_SETUP' },
        correlationId: randomUUID(),
        source: 'SYSTEM',
        reason: BOOTSTRAP_REVISION,
        result: 'SUCCESS'
      }, tx);
    });
    removeFirstAccessFile(firstAccessFile);
    return {
      applied: true,
      created: false,
      pendingAdministratorCreation: true,
      preservedExistingAccount: false,
      username: null,
      password: null,
      mustChangePassword: true,
      credentialFileAvailable: false,
      recoveryRequired: false,
      firstAccessFile: null,
      state: getBootstrapState(db)
    };
  } finally {
    closeDatabase();
  }
}

function initialAdministratorSetupStatus(db = getDb()) {
  const state = getBootstrapState(db);
  const admin = findActiveAdministrator(db);
  const pendingCreation = Boolean(!admin && state?.pendingAdministratorCreation && state.status === 'AWAITING_SELF_SETUP');
  const pendingExisting = Boolean(admin && admin.must_change_password && state && state.bootstrapUserId === admin.id && ['AWAITING_SELF_SETUP', 'AWAITING_PASSWORD_CHANGE'].includes(state.status));
  const required = pendingCreation || pendingExisting;
  return {
    required,
    username: required ? null : (admin?.username || null),
    mode: required ? 'DIRECT_SELF_SETUP' : 'NORMAL_LOGIN',
    requiresIdentity: pendingCreation
  };
}

async function completeInitialAdministratorSetup({ username, password, confirmPassword, fullName, documentType, documentNumber }, requestContext = {}) {
  const desiredUsername = String(username || '').trim().toLowerCase();
  const credential = String(password || '');
  const confirmation = String(confirmPassword || '');
  if (!/^[a-z0-9._-]{3,40}$/i.test(desiredUsername)) {
    throw Object.assign(new Error('El usuario debe tener entre 3 y 40 caracteres y usar sólo letras, números, punto, guion o guion bajo.'), { status: 422, code: 'INITIAL_SETUP_USERNAME_INVALID' });
  }
  if (credential !== confirmation) {
    throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'INITIAL_SETUP_PASSWORD_MISMATCH' });
  }
  const errors = validatePassword(credential, 4, 8);
  if (errors.length) throw Object.assign(new Error(errors[0]), { status: 422, code: 'INITIAL_SETUP_PASSWORD_POLICY' });

  const db = getDb();
  const state = getBootstrapState(db);
  const admin = findActiveAdministrator(db);
  const pendingCreation = Boolean(!admin && state?.pendingAdministratorCreation && state.status === 'AWAITING_SELF_SETUP');
  const pendingExisting = Boolean(admin && state && state.bootstrapUserId === admin.id && admin.must_change_password && ['AWAITING_SELF_SETUP', 'AWAITING_PASSWORD_CHANGE'].includes(state.status));
  if (!pendingCreation && !pendingExisting) throw Object.assign(new Error('El acceso inicial ya fue configurado.'), { status: 409, code: 'INITIAL_SETUP_ALREADY_COMPLETED' });
  const conflict = pendingCreation
    ? db.prepare('SELECT id FROM user_account WHERE username = ? COLLATE NOCASE AND deleted_at IS NULL LIMIT 1').get(desiredUsername)
    : db.prepare('SELECT id FROM user_account WHERE username = ? COLLATE NOCASE AND id <> ? AND deleted_at IS NULL LIMIT 1').get(desiredUsername, admin.id);
  if (conflict) throw Object.assign(new Error('Ese nombre de usuario ya está en uso.'), { status: 409, code: 'INITIAL_SETUP_USERNAME_TAKEN' });

  const passwordHash = await hashPassword(credential);
  const now = new Date().toISOString();
  const suppliedDocumentType = String(documentType || '').trim();
  const suppliedDocumentNumber = String(documentNumber || '').trim();
  if (pendingCreation && Boolean(suppliedDocumentType) !== Boolean(suppliedDocumentNumber)) {
    throw Object.assign(new Error('Si informás documento, completá tipo y número. Ambos campos son opcionales.'), { status: 422, code: 'INITIAL_SETUP_DOCUMENT_PAIR_INCOMPLETE' });
  }
  const identity = pendingCreation ? {
    username: desiredUsername,
    fullName: requiredString(fullName, 'fullName', { min: 3, max: 160 }),
    documentType: suppliedDocumentType ? requiredString(suppliedDocumentType, 'documentType', { min: 2, max: 30 }).toUpperCase() : 'INTERNO',
    documentNumber: suppliedDocumentNumber ? requiredString(suppliedDocumentNumber, 'documentNumber', { min: 3, max: 60 }) : `AUTO-${randomUUID()}`
  } : null;
  if (identity && db.prepare('SELECT id FROM person WHERE document_type = ? AND document_number = ? AND deleted_at IS NULL LIMIT 1').get(identity.documentType, identity.documentNumber)) {
    throw Object.assign(new Error('Ya existe una persona con ese documento.'), { status: 409, code: 'INITIAL_SETUP_DOCUMENT_TAKEN' });
  }
  let configuredAdmin = admin;
  transaction((tx) => {
    // Revalidar la precondición dentro del lock de escritura. El hash de contraseña
    // ocurre antes de BEGIN IMMEDIATE y dos solicitudes de setup pueden solaparse.
    const currentState = getBootstrapState(tx);
    const currentAdmin = findActiveAdministrator(tx);
    const currentPendingCreation = Boolean(!currentAdmin && currentState?.pendingAdministratorCreation && currentState.status === 'AWAITING_SELF_SETUP');
    const currentPendingExisting = Boolean(currentAdmin && currentState && currentState.bootstrapUserId === currentAdmin.id && currentAdmin.must_change_password && ['AWAITING_SELF_SETUP', 'AWAITING_PASSWORD_CHANGE'].includes(currentState.status));

    if (pendingCreation) {
      if (!currentPendingCreation) {
        throw Object.assign(new Error('El acceso inicial ya fue configurado.'), { status: 409, code: 'INITIAL_SETUP_ALREADY_COMPLETED' });
      }
      if (tx.prepare('SELECT id FROM user_account WHERE username = ? COLLATE NOCASE AND deleted_at IS NULL LIMIT 1').get(desiredUsername)) {
        throw Object.assign(new Error('Ese nombre de usuario ya está en uso.'), { status: 409, code: 'INITIAL_SETUP_USERNAME_TAKEN' });
      }
      if (tx.prepare('SELECT id FROM person WHERE document_type = ? AND document_number = ? AND deleted_at IS NULL LIMIT 1').get(identity.documentType, identity.documentNumber)) {
        throw Object.assign(new Error('Ya existe una persona con ese documento.'), { status: 409, code: 'INITIAL_SETUP_DOCUMENT_TAKEN' });
      }
      configuredAdmin = createInitialAdministrator(tx, passwordHash, now, identity);
    } else {
      if (!currentPendingExisting || currentAdmin.id !== admin.id) {
        throw Object.assign(new Error('El acceso inicial ya fue configurado.'), { status: 409, code: 'INITIAL_SETUP_ALREADY_COMPLETED' });
      }
      if (tx.prepare('SELECT id FROM user_account WHERE username = ? COLLATE NOCASE AND id <> ? AND deleted_at IS NULL LIMIT 1').get(desiredUsername, currentAdmin.id)) {
        throw Object.assign(new Error('Ese nombre de usuario ya está en uso.'), { status: 409, code: 'INITIAL_SETUP_USERNAME_TAKEN' });
      }
      configuredAdmin = currentAdmin;
      tx.prepare(`UPDATE user_account SET username = ?, password_hash = ?, must_change_password = 0, credential_setup_reason = 'NONE',
          failed_attempts = 0, locked_until = NULL, last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?`)
        .run(desiredUsername, passwordHash, now, now, currentAdmin.id);
    }
    tx.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), configuredAdmin.userId || configuredAdmin.id, passwordHash, now);
    if (!pendingCreation) tx.prepare(`UPDATE user_session SET revoked_at = COALESCE(revoked_at, ?),
        revocation_reason = COALESCE(revocation_reason, 'INITIAL_SELF_SETUP')
        WHERE user_id = ? AND revoked_at IS NULL`).run(now, configuredAdmin.id);
    setBootstrapState(tx, {
      ...currentState,
      revision: BOOTSTRAP_REVISION,
      status: 'COMPLETED',
      pendingAdministratorCreation: false,
      bootstrapUserId: configuredAdmin.userId || configuredAdmin.id,
      username: desiredUsername,
      completedAt: now,
      credentialFile: null,
      credentialFileRemoved: true
    });
    appendAudit({
      actorUserId: configuredAdmin.userId || configuredAdmin.id,
      actorRole: 'ADMIN_GENERAL',
      action: 'SECURITY.INITIAL_ADMIN_SELF_SETUP_COMPLETED',
      entityType: 'user_account',
      entityId: configuredAdmin.userId || configuredAdmin.id,
      after: { username: desiredUsername, identityCreatedFromOperatorInput: pendingCreation, passwordPolicy: 'ALPHANUMERIC_4_8', expires: false },
      correlationId: requestContext.correlationId || randomUUID(),
      source: 'LOCAL_INITIAL_SETUP',
      ipAddress: requestContext.ip || '127.0.0.1',
      equipment: requestContext.userAgent || null,
      result: 'SUCCESS'
    }, tx);
  });
  removeFirstAccessFile(path.join(path.dirname(require('../config/runtime').dataDir), FIRST_ACCESS_FILENAME));
  return { configured: true, username: desiredUsername, userId: configuredAdmin.userId || configuredAdmin.id };
}

function markInitialAccessCompleted(userId, userDataRoot, db = getDb()) {
  const state = getBootstrapState(db);
  if (!state || state.bootstrapUserId !== userId) return false;
  let credentialFileRemoved = true;
  try {
    removeFirstAccessFile(path.join(userDataRoot, FIRST_ACCESS_FILENAME));
  } catch {
    credentialFileRemoved = false;
  }
  setBootstrapState(db, {
    ...state,
    status: 'COMPLETED',
    completedAt: new Date().toISOString(),
    credentialFileRemoved
  });
  return true;
}

async function recoverAdministratorAccess(userDataRoot, options = {}) {
  const username = String(options.username || BOOTSTRAP_USERNAME).trim().toLowerCase();
  const requiredConfirmation = `RECUPERAR:${username}`;
  if (options.confirmation !== requiredConfirmation) {
    const error = new Error(`Confirmación inválida. Se requiere exactamente ${requiredConfirmation}.`);
    error.code = 'RECOVERY_CONFIRMATION_REQUIRED';
    throw error;
  }

  const firstAccessFile = path.join(userDataRoot, FIRST_ACCESS_FILENAME);
  openDatabase();
  seedBase();
  try {
    const db = getDb();
    const account = findRecoverableAdministrator(db, username);
    if (!account) {
      const error = new Error(`No existe la cuenta ${username}.`);
      error.code = 'RECOVERY_ACCOUNT_NOT_FOUND';
      throw error;
    }
    const internalSecret = `${randomUUID()}${randomUUID()}`;
    const passwordHash = await hashPassword(internalSecret);
    const now = new Date().toISOString();
    transaction((tx) => {
      const adminRole = tx.prepare("SELECT id FROM role WHERE code = 'ADMIN_GENERAL' AND active = 1 LIMIT 1").get();
      if (!adminRole) throw Object.assign(new Error('No existe el rol ADMIN_GENERAL.'), { code: 'ADMIN_ROLE_MISSING' });
      tx.prepare(`UPDATE person SET status = 'ACTIVA', deleted_at = NULL,
          version = version + 1, updated_at = ? WHERE id = ?`).run(now, account.person_id);
      tx.prepare(`UPDATE user_account SET password_hash = ?, failed_attempts = 0,
          locked_until = NULL, active = 1, must_change_password = 1, credential_setup_reason = 'INITIAL_SETUP',
          deleted_at = NULL, last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?`)
        .run(passwordHash, now, now, account.id);
      const hasRole = tx.prepare('SELECT 1 FROM user_role_scope WHERE user_id = ? AND role_id = ? LIMIT 1').get(account.id, adminRole.id);
      if (!hasRole) tx.prepare(`INSERT INTO user_role_scope(id, user_id, role_id, site_id, location_id, valid_from, valid_to, created_at, updated_at)
        VALUES (?, ?, ?, NULL, NULL, ?, NULL, ?, ?)`).run(randomUUID(), account.id, adminRole.id, now, now, now);
      tx.prepare(`UPDATE user_session SET revoked_at = COALESCE(revoked_at, ?), revocation_reason = COALESCE(revocation_reason, 'EXPLICIT_ADMIN_RECOVERY') WHERE user_id = ? AND revoked_at IS NULL`).run(now, account.id);
      tx.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)').run(randomUUID(), account.id, passwordHash, now);
      setBootstrapState(tx, {
        revision: BOOTSTRAP_REVISION,
        status: 'AWAITING_SELF_SETUP',
        bootstrapUserId: account.id,
        username,
        recoveredAt: now,
        recoveryMode: 'EXPLICIT_CONFIRMED',
        credentialFile: null
      });
      appendAudit({
        action: 'SECURITY.ADMIN_RECOVERY_TO_SELF_SETUP', entityType: 'user_account', entityId: account.id,
        before: { active: Boolean(account.active), deleted: Boolean(account.deleted_at), mustChangePassword: Boolean(account.must_change_password) },
        after: { active: true, deleted: false, setupRequired: true, credentialType: 'SELF_SETUP' },
        correlationId: randomUUID(), source: 'LOCAL_RECOVERY', reason: 'EXPLICIT_OPERATOR_CONFIRMATION', result: 'SUCCESS'
      }, tx);
    });
    removeFirstAccessFile(firstAccessFile);
    return { recovered: true, username, selfSetupRequired: true, firstAccessFile: null, state: getBootstrapState(db) };
  } finally {
    closeDatabase();
  }
}

module.exports = {
  ensureInitialAccess,
  initialAdministratorSetupStatus,
  completeInitialAdministratorSetup,
  markInitialAccessCompleted,
  recoverAdministratorAccess,
  listRecoverableAdministrators,
  startLocalAdministratorRecovery,
  completeLocalAdministratorRecovery,
  getBootstrapState,
  BOOTSTRAP_USERNAME,
  BOOTSTRAP_REVISION,
  BOOTSTRAP_STATE_KEY,
  FIRST_ACCESS_FILENAME
};
