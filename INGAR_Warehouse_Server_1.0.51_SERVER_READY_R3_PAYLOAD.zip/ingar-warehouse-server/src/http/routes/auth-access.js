'use strict';

const runtime = require('../../config/runtime');
const { login, accessState, firstAccess, completePasswordReset, rotateCsrfToken, logout, changePassword } = require('../../services/auth-service');
const { initialAdministratorSetupStatus, completeInitialAdministratorSetup, startLocalAdministratorRecovery, completeLocalAdministratorRecovery } = require('../../services/bootstrap-access-service');
const { isRemoteLanRequest } = require('../../security/lan-access-control');
const { listUsers, getUser, listSupervisorCandidates, createUser, updateUser, setUserActive, softDeleteUser, resetPassword, resetOperationalPins } = require('../../services/user-service');
const { createLifecyclePreflight, generateLifecycleExport, generateLifecycleClearancePdf } = require('../../services/user-lifecycle-service');
const { listRoles, listPermissions, createRole, updateRole, getUserPermissionOverrides, setUserPermissionOverrides } = require('../../services/permission-service');
const { resolveUserExperience } = require('../../services/experience-service');
const { getAccessContract } = require('../../services/access-contract-service');
const { json, binary, readJson, setSessionCookie, clearSessionCookie } = require('../http-utils');
const { match, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;

  if (pathname === '/api/v1/auth/initial-setup' && (req.method === 'GET' || req.method === 'POST')) {
    if (isRemoteLanRequest(req) && !runtime.serverMode) {
      json(res, 403, { code: 'INITIAL_SETUP_LOCAL_ONLY', message: 'La configuración inicial sólo puede realizarse desde la PC donde está instalado Warehouse.' }, baseContext.correlationId);
      return true;
    }
    if (req.method === 'GET') {
      json(res, 200, initialAdministratorSetupStatus(), baseContext.correlationId);
      return true;
    }
    const body = await readJson(req);
    await completeInitialAdministratorSetup(body, baseContext);
    const result = await login({ username: body.username, password: body.password, remember: false }, baseContext);
    const maxAge = Math.max(1, Math.floor((new Date(result.expiresAt).getTime() - Date.now()) / 1000));
    setSessionCookie(res, result.sessionToken, maxAge);
    json(res, 200, { configured: true, user: result.user, csrfToken: result.csrfToken, expiresAt: result.expiresAt }, baseContext.correlationId);
    return true;
  }
  if (pathname === '/api/v1/auth/local-admin-recovery' && (req.method === 'GET' || req.method === 'POST')) {
    // F14: recuperación administrativa deliberadamente local. La ruta no está en la
    // allowlist LAN y además se vuelve a validar aquí como defensa en profundidad.
    if (isRemoteLanRequest(req)) {
      json(res, 403, { code: 'LOCAL_RECOVERY_LOCAL_ONLY', message: 'La recuperación de credenciales sólo está disponible desde la PC donde está instalado INGAR Warehouse.' }, baseContext.correlationId);
      return true;
    }
    if (req.method === 'GET') {
      json(res, 200, startLocalAdministratorRecovery(baseContext), baseContext.correlationId);
      return true;
    }
    const body = await readJson(req);
    const recovered = await completeLocalAdministratorRecovery(body, baseContext);
    const result = await login({ username: recovered.username, password: body.password, remember: false }, baseContext);
    const maxAge = Math.max(1, Math.floor((new Date(result.expiresAt).getTime() - Date.now()) / 1000));
    setSessionCookie(res, result.sessionToken, maxAge);
    json(res, 200, { recovered: true, user: result.user, csrfToken: result.csrfToken, expiresAt: result.expiresAt }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/access-state') {
    const body = await readJson(req);
    json(res, 200, accessState(body.identifier || body.username, baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/first-access') {
    json(res, 200, await firstAccess(await readJson(req), baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/password-reset') {
    json(res, 200, await completePasswordReset(await readJson(req), baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/login') {
    const body = await readJson(req);
    const result = await login(body, baseContext);
    const maxAge = Math.max(1, Math.floor((new Date(result.expiresAt).getTime() - Date.now()) / 1000));
    setSessionCookie(res, result.sessionToken, maxAge);
    json(res, 200, { user: result.user, csrfToken: result.csrfToken, expiresAt: result.expiresAt }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/logout') {
    const auth = requireAuth(req, 'Auth.Self'); requireCsrf(req, auth);
    logout(auth, baseContext); clearSessionCookie(res);
    json(res, 200, { loggedOut: true }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/auth/me') {
    const auth = requireAuth(req, 'Auth.Self');
    json(res, 200, { user: auth.user }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/auth/experience') {
    const auth = requireAuth(req, 'Auth.Self');
    json(res, 200, { experience: resolveUserExperience(auth.user) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/auth/access-contract') {
    requireAnyPermission(req, ['Roles.Read', 'Audit.Read']);
    json(res, 200, { contract: getAccessContract() }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/auth/csrf') {
    const auth = requireAuth(req, 'Auth.Self');
    const csrfToken = rotateCsrfToken(auth);
    json(res, 200, { csrfToken }, baseContext.correlationId); return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/auth/change-password') {
    const auth = requireAuth(req, 'Auth.Self'); requireCsrf(req, auth);
    const body = await readJson(req);
    const result = await changePassword(auth, body.currentPassword, body.newPassword, baseContext);
    json(res, 200, result, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/users') {
    requireAuth(req, 'Users.Read');
    const active = searchParams.has('active') ? searchParams.get('active') === 'true' : undefined;
    json(res, 200, { items: listUsers({ search: searchParams.get('search'), active, status: searchParams.get('status'), lifecycle: searchParams.get('lifecycle'), limit: searchParams.get('limit'), offset: searchParams.get('offset') }) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/users/supervisor-candidates') {
    requireAuth(req, 'Users.Read');
    json(res, 200, { items: listSupervisorCandidates() }, baseContext.correlationId); return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/users/operational-pins/reset') {
    const auth = requireAuth(req, 'Users.ResetPassword'); requireCsrf(req, auth);
    const body = await readJson(req);
    if (body.confirm !== true) throw Object.assign(new Error('Confirmación explícita requerida.'), { status: 422, code: 'CONFIRMATION_REQUIRED' });
    json(res, 200, await resetOperationalPins(contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/users') {
    const auth = requireAuth(req, 'Users.Create'); requireCsrf(req, auth);
    const result = await createUser(await readJson(req), contextWithUser(baseContext, auth));
    json(res, 201, result, baseContext.correlationId); return true;
  }

  let params = match(pathname, '/api/v1/users/:id');
  if (params && req.method === 'GET') {
    requireAuth(req, 'Users.Read');
    const user = getUser(params.id, { includeTerminated: searchParams.get('includeTerminated') === 'true' });
    if (!user) throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
    json(res, 200, { user }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Users.Update'); requireCsrf(req, auth);
    json(res, 200, await updateUser(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  if (params && req.method === 'DELETE') {
    const auth = requireAuth(req, 'Users.Delete'); requireCsrf(req, auth);
    const body = await readJson(req);
    json(res, 200, softDeleteUser(params.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  params = match(pathname, '/api/v1/users/:id/lifecycle-preflight');
  if (params && req.method === 'POST') {
    const body = await readJson(req);
    const action = String(body.action || '').toUpperCase();
    const auth = requireAuth(req, action === 'TERMINATE' ? 'Users.Delete' : 'Users.Disable'); requireCsrf(req, auth);
    json(res, 200, createLifecyclePreflight(params.id, action, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/users/:id/lifecycle-export');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Users.Read'); requireCsrf(req, auth);
    const body = await readJson(req);
    // El evento fue creado con el permiso correspondiente y además queda ligado al mismo actor.
    const file = generateLifecycleExport(params.id, body, contextWithUser(baseContext, auth));
    binary(res, 200, file.bytes, file.mimeType, baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="${file.filename}"`,
      'X-Content-SHA256': file.sha256,
      'X-IWC-Export-Id': file.exportId,
      'X-IWC-Row-Count': String(file.rowCount)
    }); return true;
  }
  params = match(pathname, '/api/v1/users/:id/lifecycle-clearance-pdf');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Users.Read'); requireCsrf(req, auth);
    const body = await readJson(req);
    const file = generateLifecycleClearancePdf(params.id, body, contextWithUser(baseContext, auth));
    binary(res, 200, file.bytes, file.mimeType, baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="${file.filename}"`,
      'X-Content-SHA256': file.sha256,
      'X-IWC-Snapshot-SHA256': file.snapshotSha256,
      'X-IWC-Export-Id': file.exportId,
      'X-IWC-Clearance-Ready': file.clearanceReady ? 'true' : 'false',
      'X-IWC-Pending-Count': String(file.pendingTotal)
    }); return true;
  }

  params = match(pathname, '/api/v1/users/:id/enable');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Users.Disable'); requireCsrf(req, auth);
    json(res, 200, { user: setUserActive(params.id, true, contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/users/:id/disable');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Users.Disable'); requireCsrf(req, auth);
    const body = await readJson(req);
    json(res, 200, { user: setUserActive(params.id, false, contextWithUser(baseContext, auth), body) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/users/:id/reset-password');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Users.ResetPassword'); requireCsrf(req, auth);
    json(res, 200, await resetPassword(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/users/:id/permission-overrides');
  if (params && req.method === 'GET') {
    requireAuth(req, 'Roles.Read');
    json(res, 200, { items: getUserPermissionOverrides(params.id) }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'PUT') {
    const auth = requireAuth(req, 'Roles.Update'); requireCsrf(req, auth);
    const body = await readJson(req);
    json(res, 200, { items: setUserPermissionOverrides(params.id, body.overrides || [], contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/roles') {
    requireAuth(req, 'Roles.Read'); json(res, 200, { items: listRoles() }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/roles') {
    const auth = requireAuth(req, 'Roles.Create'); requireCsrf(req, auth);
    json(res, 201, { role: createRole(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/roles/:id');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Roles.Update'); requireCsrf(req, auth);
    json(res, 200, { role: updateRole(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/permissions') {
    requireAuth(req, 'Roles.Read'); json(res, 200, { items: listPermissions() }, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
