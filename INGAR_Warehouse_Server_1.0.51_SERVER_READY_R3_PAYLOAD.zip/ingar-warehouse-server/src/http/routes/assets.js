'use strict';

const { listCategories, createCategory, updateCategory, setCategoryActive, deleteCategory } = require('../../services/asset-category-service');
const { listAssets, getAsset, getAssetAvailabilityDiagnosis, enableAvailabilityAfterPreventiveReview, createAsset, updateAsset, duplicateAsset, setAssetActive, manualReleaseBlockedAsset, listAssetManualReleaseHistory, setAssetPhoto, listAssetDocuments, addAssetDocument, updateAssetDocument, removeAssetDocument } = require('../../services/asset-service');
const { validateAssetImport, listImportBatches, getImportBatch, applyAssetImport, reverseAssetImport, template: importTemplate, importReportCsv } = require('../../services/import-service');
const { duplicateVehicle, duplicateKit } = require('../../services/specialized-asset-registration-service');
const { transferSingleAssetLocation } = require('../../services/location-service');
const { json, text, binary, readJson, csvEscape } = require('../http-utils');
const { match, protectedDownload, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');
const { createXlsx } = require('../../services/spreadsheet-service');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  let params;
  if (req.method === 'GET' && pathname === '/api/v1/asset-categories') {
    const auth = requireAuth(req, 'Assets.Read');
    const active = searchParams.has('active') ? searchParams.get('active') === 'true' : undefined;
    json(res, 200, { items: listCategories({ search: searchParams.get('search'), nature: searchParams.get('nature'), active, siteId: searchParams.get('siteId') }) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/asset-categories') {
    const auth = requireAuth(req, 'Assets.Create'); requireCsrf(req, auth);
    json(res, 201, { category: createCategory(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/asset-categories/:id');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { category: updateCategory(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'DELETE') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { category: deleteCategory(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/asset-categories/:id/deactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { category: setCategoryActive(params.id, false, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/asset-categories/:id/reactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { category: setCategoryActive(params.id, true, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/assets/export') {
    const auth = requireAuth(req, 'Assets.Export');
    const items = listAssets({ search: searchParams.get('search'), status: searchParams.get('status'), categoryId: searchParams.get('categoryId'), locationId: searchParams.get('locationId'), active: searchParams.has('active') ? searchParams.get('active') === 'true' : undefined, limit: 1000 }, auth.user, 'Assets.Export');
    const columns = ['internal_code', 'category_code', 'description', 'serial_number', 'brand', 'model', 'status', 'site_code', 'location_code', 'quantity_total', 'quantity_available', 'unit_of_measure', 'license_plate', 'odometer', 'fuel_type', 'requires_work_order', 'active', 'version'];
    const csv = ['\uFEFF' + columns.map(csvEscape).join(';'), ...items.map((item) => columns.map((column) => csvEscape(item[column])).join(';'))].join('\r\n');
    protectedDownload(res, csv, `iwc-bienes-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv; charset=utf-8', baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/assets/export.xlsx') {
    const auth = requireAuth(req, 'Assets.Export');
    const filters = {
      search: searchParams.get('search'),
      status: searchParams.get('status'),
      categoryId: searchParams.get('categoryId'),
      nature: searchParams.get('nature'),
      locationId: searchParams.get('locationId'),
      active: searchParams.has('active') ? searchParams.get('active') === 'true' : undefined,
      limit: 25000
    };
    const items = listAssets(filters, auth.user, 'Assets.Export');
    const generatedAt = new Date();
    const headers = ['Código interno', 'Categoría', 'Naturaleza', 'Descripción', 'N° de serie', 'Marca', 'Modelo', 'Estado', 'Sede', 'Ubicación', 'Cantidad total', 'Cantidad disponible', 'Unidad', 'Patente', 'Odómetro', 'Combustible', 'Requiere OT', 'Activo', 'Versión'];
    const matrix = [
      ['INGAR Warehouse · Maestro de bienes'],
      [`Generado: ${generatedAt.toLocaleString('es-AR')}`],
      [`Registros exportados: ${items.length}`],
      [],
      headers,
      ...items.map((item) => [
        item.internal_code || '', item.category_code || '', item.category_nature || '', item.description || '',
        item.serial_number || '', item.brand || '', item.model || '', item.status || '', item.site_code || '',
        item.location_code || '', Number(item.quantity_total || 0), Number(item.quantity_available || 0), item.unit_of_measure || '',
        item.license_plate || '', item.odometer == null ? '' : Number(item.odometer), item.fuel_type || '',
        item.requires_work_order ? 'Sí' : 'No', item.active ? 'Sí' : 'No', Number(item.version || 0)
      ])
    ];
    const bytes = createXlsx(matrix, {
      sheetName: 'Bienes', titleRow: 1, metadataRows: [2, 3], headerRow: 5, freezeRow: 6,
      autoFilter: true,
      columnWidths: [16, 16, 14, 34, 20, 18, 18, 16, 14, 18, 14, 16, 12, 14, 12, 14, 12, 10, 10]
    });
    binary(res, 200, bytes, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="INGAR_Bienes_${generatedAt.toISOString().slice(0, 10)}.xlsx"`
    });
    return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/assets') {
    const auth = requireAuth(req, 'Assets.Read');
    const active = searchParams.has('active') ? searchParams.get('active') === 'true' : undefined;
    json(res, 200, { items: listAssets({ search: searchParams.get('search'), status: searchParams.get('status'), categoryId: searchParams.get('categoryId'), nature: searchParams.get('nature'), excludeNature: searchParams.get('excludeNature'), locationId: searchParams.get('locationId'), active, availableOnly: searchParams.get('availableOnly') === 'true', includeAvailabilityDiagnosis: searchParams.get('includeAvailabilityDiagnosis') === 'true', limit: searchParams.get('limit'), offset: searchParams.get('offset') }, auth.user, 'Assets.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/assets') {
    const auth = requireAuth(req, 'Assets.Create'); requireCsrf(req, auth);
    json(res, 201, { asset: createAsset(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/assets/availability/preventive-import-review') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, enableAvailabilityAfterPreventiveReview(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Assets.Read');
    const asset = getAsset(params.id, auth.user, 'Assets.Read');
    if (!asset) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
    json(res, 200, { asset }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { asset: updateAsset(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/availability-diagnosis');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Assets.Read');
    json(res, 200, { diagnosis: getAssetAvailabilityDiagnosis(params.id, auth.user, 'Assets.Read') }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/move');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, transferSingleAssetLocation(params.id, await readJson(req), contextWithUser(baseContext, auth), { permission: 'Assets.Update', forbiddenNature: 'VEHICULO' }), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/duplicate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Create'); requireCsrf(req, auth);
    const body = await readJson(req);
    const source = getAsset(params.id, auth.user, 'Assets.Create');
    if (!source) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
    const context = contextWithUser(baseContext, auth);
    const duplicated = source.category_nature === 'VEHICULO'
      ? duplicateVehicle(params.id, body, context)
      : source.category_nature === 'KIT'
        ? duplicateKit(params.id, body, context)
        : duplicateAsset(params.id, body, context);
    json(res, 201, { asset: duplicated.asset || duplicated, specialized: duplicated.asset ? duplicated : null }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/inactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { asset: setAssetActive(params.id, false, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/reactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Update'); requireCsrf(req, auth);
    json(res, 200, { asset: setAssetActive(params.id, true, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/manual-release');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.ReleaseBlocked'); requireCsrf(req, auth);
    json(res, 200, manualReleaseBlockedAsset(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/manual-release-history');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Assets.Read');
    json(res, 200, { items: listAssetManualReleaseHistory(params.id, auth.user, 'Assets.Read') }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/photo');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Documents'); requireCsrf(req, auth);
    json(res, 201, setAssetPhoto(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:id/documents');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Assets.Read'); json(res, 200, { items: listAssetDocuments(params.id, auth.user, 'Assets.Read') }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Assets.Documents'); requireCsrf(req, auth);
    json(res, 201, { document: addAssetDocument(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/assets/:assetId/documents/:documentId');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Assets.Documents'); requireCsrf(req, auth);
    json(res, 200, { document: updateAssetDocument(params.assetId, params.documentId, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'DELETE') {
    const auth = requireAuth(req, 'Assets.Documents'); requireCsrf(req, auth);
    json(res, 200, removeAssetDocument(params.assetId, params.documentId, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/imports/assets/template') {
    requireAuth(req, 'Import.Read');
    const file = importTemplate(searchParams.get('format') === 'xlsx' ? 'xlsx' : 'csv', searchParams.get('kind') || 'ASSET');
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    text(res, 200, file.bytes, file.mimeType, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/imports/assets/validate') {
    const auth = requireAuth(req, 'Import.Create'); requireCsrf(req, auth);
    json(res, 201, { batch: validateAssetImport(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/imports') {
    const auth = requireAuth(req, 'Import.Read');
    json(res, 200, { items: listImportBatches({ status: searchParams.get('status'), limit: searchParams.get('limit') }, auth.user, 'Import.Read') }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/imports/:id/report');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Import.Read');
    protectedDownload(res, importReportCsv(params.id, auth.user, 'Import.Read'), `reporte-importacion-${params.id}.csv`, 'text/csv; charset=utf-8', baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/imports/:id/apply');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Import.Apply'); requireCsrf(req, auth);
    json(res, 200, { batch: applyAssetImport(params.id, contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/imports/:id/reverse');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Import.Reverse'); requireCsrf(req, auth);
    json(res, 200, { batch: reverseAssetImport(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/imports/:id');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req, 'Import.Read');
    const batch = getImportBatch(params.id, auth.user, 'Import.Read', { limit: searchParams.get('limit'), offset: searchParams.get('offset') });
    if (!batch) throw Object.assign(new Error('Lote no encontrado.'), { status: 404, code: 'IMPORT_NOT_FOUND' });
    json(res, 200, { batch }, baseContext.correlationId); return true;
  }


  return false;
}

module.exports = { handle };
