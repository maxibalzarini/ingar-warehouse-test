'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'iwc-server-selftest-'));
process.env.IWC_SERVER_MODE = '1';
process.env.IWC_HOST = '127.0.0.1';
process.env.IWC_PORT = '0';
process.env.IWC_DATA_DIR = temp;
process.env.IWC_MASTER_WRAP_SECRET = 'IWC_SELFTEST_ONLY_0123456789abcdef0123456789abcdef';

function get(port, pathname, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host:'127.0.0.1', port, path:pathname, method:'GET', headers }, (res) => {
      const chunks=[]; res.on('data', c=>chunks.push(c)); res.on('end',()=>resolve({status:res.statusCode, headers:res.headers, body:Buffer.concat(chunks).toString('utf8')}));
    });
    req.on('error', reject); req.end();
  });
}

function request(port, method, pathname, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const payload = body == null ? null : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
    const merged = { ...headers };
    if (payload) {
      merged['content-type'] = merged['content-type'] || 'application/json';
      merged['content-length'] = payload.length;
    }
    const req = http.request({ host:'127.0.0.1', port, path:pathname, method, headers:merged }, (res) => {
      const chunks=[]; res.on('data', c=>chunks.push(c)); res.on('end',()=>resolve({status:res.statusCode, headers:res.headers, body:Buffer.concat(chunks).toString('utf8')}));
    });
    req.on('error', reject); if (payload) req.write(payload); req.end();
  });
}

(async()=>{
  try {
    assert.equal(process.platform, 'linux', 'Self-test Server Edition requiere Linux');
    const { startServer, stopServer } = require('../src/server');
    const { currentSchemaVersion } = require('../src/db/database');
    const { ensureInitialAccess } = require('../src/services/bootstrap-access-service');
    await ensureInitialAccess(temp);
    const server = await startServer({serverMode:true, host:'127.0.0.1', port:0, requireAdmin:false});
    const port = server.address().port;
    const live = await get(port, '/api/v1/health/live', {'x-forwarded-proto':'https'});
    assert.equal(live.status, 200, `health/live devolvió ${live.status}`);
    const setup = await get(port, '/api/v1/auth/initial-setup', {'x-forwarded-proto':'https','x-forwarded-for':'198.51.100.10'});
    assert.equal(setup.status, 200, `initial-setup remoto en serverMode devolvió ${setup.status}`);
    const parsed = JSON.parse(setup.body);
    assert.equal(parsed.required, true, 'Una DB nueva debe requerir configuración inicial');
    const importRoute = await request(port, 'POST', '/api/v1/imports/assets/validate', {}, {'x-forwarded-proto':'https'});
    assert.notEqual(importRoute.status, 404, 'La ruta POST /api/v1/imports/assets/validate no puede devolver 404');
    assert.equal(importRoute.status, 401, `Import validate sin sesión debe devolver 401, devolvió ${importRoute.status}`);
    const importTemplateRoute = await get(port, '/api/v1/imports/assets/template?format=xlsx&kind=ASSET', {'x-forwarded-proto':'https'});
    assert.notEqual(importTemplateRoute.status, 404, 'La ruta GET /api/v1/imports/assets/template no puede devolver 404');
    assert.equal(importTemplateRoute.status, 401, `Import template sin sesión debe devolver 401, devolvió ${importTemplateRoute.status}`);
    assert.equal(currentSchemaVersion(), 53, 'Schema final debe ser 053');
    await stopServer();
    const binding = require('../src/security/sqlite-encryption').bindingPath();
    assert.ok(fs.existsSync(binding), 'Binding SQLite Linux ausente');
    assert.ok(fs.existsSync(path.join(temp,'iwc.sqlite')), 'DB cifrada no creada');
    console.log('SERVER SELFTEST PASS');
    console.log(JSON.stringify({platform:process.platform,arch:process.arch,node:process.version,abi:process.versions.modules,schema:53,remoteInitialSetup:true,httpsProxyAware:true,binding:path.basename(binding)},null,2));
  } catch (error) {
    console.error('SERVER SELFTEST FAIL');
    console.error(error?.stack || error);
    process.exitCode=1;
  } finally {
    try { const { stopServer } = require('../src/server'); await stopServer(); } catch {}
    try { fs.rmSync(temp,{recursive:true,force:true}); } catch {}
  }
})();
