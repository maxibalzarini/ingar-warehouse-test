'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const {
  randomBytes,
  createCipheriv,
  createDecipheriv,
  scryptSync,
  createHash
} = require('node:crypto');
const runtime = require('../config/runtime');

const KEY_BYTES = 32;
const WINDOWS_PROVIDER = 'WINDOWS_DPAPI_CURRENT_USER';
const PORTABLE_PROVIDER = 'MACHINE_USER_AES_256_GCM';
let cachedMasterKey = null;

function atomicWrite(filePath, bytes, mode = 0o600) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
  const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, bytes, { flag: 'wx', mode });
  fs.renameSync(temporary, filePath);
  try { fs.chmodSync(filePath, mode); } catch {}
}

function parseMasterKey(value) {
  const text = String(value || '').trim();
  if (!/^[A-Za-z0-9+/]{43}=$/.test(text)) throw new Error('El proveedor local devolvió una clave inválida.');
  const key = Buffer.from(text, 'base64');
  if (key.length !== KEY_BYTES) throw new Error('La clave maestra local tiene una longitud inválida.');
  return key;
}

function windowsKey() {
  const script = path.join(runtime.projectRoot, 'build', 'protect-data-key.ps1');
  if (!fs.existsSync(script)) throw new Error('Falta el proveedor DPAPI de protección de datos.');
  fs.mkdirSync(runtime.securityDir, { recursive: true });
  const operation = fs.existsSync(runtime.masterKeyPath) ? 'Unprotect' : 'Create';
  const result = spawnSync('powershell.exe', [
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy', 'Bypass',
    '-File', script,
    '-Operation', operation,
    '-KeyFile', runtime.masterKeyPath
  ], {
    encoding: 'utf8',
    windowsHide: true,
    timeout: 30_000,
    maxBuffer: 64 * 1024
  });
  if (result.error || result.status !== 0) {
    const error = new Error('Windows no pudo desbloquear la clave local de protección de datos.');
    error.code = 'DATA_KEY_UNAVAILABLE';
    throw error;
  }
  return parseMasterKey(result.stdout);
}

function readMachineBinding() {
  let machine = '';
  for (const candidate of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
    try {
      machine = fs.readFileSync(candidate, 'utf8').trim();
      if (machine) break;
    } catch {}
  }
  const user = os.userInfo();
  const binding = [
    'INGAR_WAREHOUSE_CONTROLLER',
    machine || os.hostname(),
    String(user.uid ?? user.username),
    user.username,
    user.homedir
  ].join('\0');
  return createHash('sha256').update(binding, 'utf8').digest();
}

function createPortableWrappedKey() {
  const masterKey = randomBytes(KEY_BYTES);
  const salt = randomBytes(32);
  const iv = randomBytes(12);
  const wrappingKey = scryptSync(readMachineBinding(), salt, 32);
  const cipher = createCipheriv('aes-256-gcm', wrappingKey, iv);
  cipher.setAAD(Buffer.from('IWC_MASTER_KEY_V1', 'utf8'));
  const ciphertext = Buffer.concat([cipher.update(masterKey), cipher.final()]);
  const document = {
    format: 'IWC_MASTER_KEY_V1',
    provider: PORTABLE_PROVIDER,
    kdf: 'SCRYPT',
    cipher: 'AES-256-GCM',
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    authTag: cipher.getAuthTag().toString('base64'),
    ciphertext: ciphertext.toString('base64'),
    createdAt: new Date().toISOString()
  };
  atomicWrite(runtime.masterKeyPath, Buffer.from(`${JSON.stringify(document, null, 2)}\n`, 'utf8'));
  return masterKey;
}

function readPortableWrappedKey() {
  const document = JSON.parse(fs.readFileSync(runtime.masterKeyPath, 'utf8'));
  if (document?.format !== 'IWC_MASTER_KEY_V1' || document.provider !== PORTABLE_PROVIDER) {
    throw new Error('El archivo de clave local no corresponde al proveedor esperado.');
  }
  const salt = Buffer.from(document.salt || '', 'base64');
  const iv = Buffer.from(document.iv || '', 'base64');
  const tag = Buffer.from(document.authTag || '', 'base64');
  const ciphertext = Buffer.from(document.ciphertext || '', 'base64');
  if (salt.length !== 32 || iv.length !== 12 || tag.length !== 16 || ciphertext.length !== KEY_BYTES) {
    throw new Error('El archivo de clave local está incompleto.');
  }
  const wrappingKey = scryptSync(readMachineBinding(), salt, 32);
  const decipher = createDecipheriv('aes-256-gcm', wrappingKey, iv);
  decipher.setAAD(Buffer.from('IWC_MASTER_KEY_V1', 'utf8'));
  decipher.setAuthTag(tag);
  const key = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  if (key.length !== KEY_BYTES) throw new Error('La clave maestra local no pudo recuperarse.');
  return key;
}

function nonWindowsKey() {
  fs.mkdirSync(runtime.securityDir, { recursive: true, mode: 0o700 });
  return fs.existsSync(runtime.masterKeyPath) ? readPortableWrappedKey() : createPortableWrappedKey();
}

function getMasterKey() {
  if (!cachedMasterKey) cachedMasterKey = process.platform === 'win32' ? windowsKey() : nonWindowsKey();
  return Buffer.from(cachedMasterKey);
}

function keyProtectionStatus() {
  return {
    enabled: true,
    provider: process.platform === 'win32' ? WINDOWS_PROVIDER : PORTABLE_PROVIDER,
    keyStoredInConfiguration: false,
    keyWrittenToLogs: false,
    keyFile: path.basename(runtime.masterKeyPath)
  };
}

function clearCachedMasterKey() {
  if (cachedMasterKey) cachedMasterKey.fill(0);
  cachedMasterKey = null;
}

module.exports = {
  getMasterKey,
  keyProtectionStatus,
  clearCachedMasterKey,
  WINDOWS_PROVIDER,
  PORTABLE_PROVIDER
};
