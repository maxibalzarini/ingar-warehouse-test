'use strict';
const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const root = path.resolve(__dirname, '..');
const abi = String(process.versions.modules || '');
const platformArch = `${process.platform}-${process.arch}`;
const targetDir = path.join(root, 'vendor', 'sqlite-driver', 'native', platformArch, `node-v${abi}`);
const target = path.join(targetDir, 'better_sqlite3.node');
const packageRoot = path.dirname(require.resolve('better-sqlite3-multiple-ciphers/package.json'));
const candidates = [
  path.join(packageRoot, 'build', 'Release', 'better_sqlite3.node'),
  path.join(packageRoot, 'build', 'Debug', 'better_sqlite3.node')
];
let source = candidates.find(fs.existsSync);
if (!source) {
  const result = cp.spawnSync(process.execPath, ['-e', `const p=require('path'),fs=require('fs'); const r=${JSON.stringify(packageRoot)}; function walk(d){for(const n of fs.readdirSync(d)){const x=p.join(d,n);const s=fs.statSync(x);if(s.isDirectory())walk(x);else if(n==='better_sqlite3.node')console.log(x)}} walk(r)`], {encoding:'utf8'});
  source = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean)[0];
}
if (!source || !fs.existsSync(source)) {
  console.error('No se encontró el binding Linux de better-sqlite3-multiple-ciphers.');
  process.exit(1);
}
fs.mkdirSync(targetDir, {recursive:true});
fs.copyFileSync(source, target);
console.log(`SQLite binding preparado: ${target}`);
