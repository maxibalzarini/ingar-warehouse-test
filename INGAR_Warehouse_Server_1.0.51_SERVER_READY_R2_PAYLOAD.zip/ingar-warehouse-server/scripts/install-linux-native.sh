#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="12.11.1"
ABI="$(node -p 'process.versions.modules')"
ARCH="$(uname -m)"
if [[ "$ABI" != "127" ]]; then
  echo "ERROR: este Server Edition está fijado a Node.js 22 (ABI 127). Actual: $(node -v), ABI $ABI" >&2
  exit 2
fi
case "$ARCH" in
  x86_64|amd64)
    PLATFORM_ARCH="linux-x64"
    SHA="46a4933d6962aa75cee61657b99931dd23cc040fc81094a3ec33b3b09328cdea"
    ;;
  aarch64|arm64)
    PLATFORM_ARCH="linux-arm64"
    SHA="ecbbf8aabc265f58fc22f52c09d4375f91873479ba007c4fe2380ec37c604597"
    ;;
  *) echo "ERROR: arquitectura Linux no soportada: $ARCH" >&2; exit 3;;
esac
NAME="better-sqlite3-multiple-ciphers-v${VERSION}-node-v${ABI}-${PLATFORM_ARCH}.tar.gz"
URL="https://github.com/m4heshd/better-sqlite3-multiple-ciphers/releases/download/v${VERSION}/${NAME}"
TARGET_DIR="$ROOT/vendor/sqlite-driver/native/${PLATFORM_ARCH}/node-v${ABI}"
TARGET="$TARGET_DIR/better_sqlite3.node"
if [[ -f "$TARGET" ]]; then
  echo "SQLite native ya instalado: $TARGET"
  exit 0
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
curl --fail --location --silent --show-error "$URL" -o "$TMP/$NAME"
printf '%s  %s\n' "$SHA" "$TMP/$NAME" | sha256sum -c -
mkdir -p "$TMP/extract" "$TARGET_DIR"
tar -xzf "$TMP/$NAME" -C "$TMP/extract"
SRC="$(find "$TMP/extract" -type f -name better_sqlite3.node | head -n1)"
if [[ -z "$SRC" || ! -f "$SRC" ]]; then
  echo "ERROR: el prebuild descargado no contiene better_sqlite3.node" >&2
  exit 4
fi
cp "$SRC" "$TARGET"
chmod 755 "$TARGET"
echo "SQLite native instalado y verificado: $TARGET"
