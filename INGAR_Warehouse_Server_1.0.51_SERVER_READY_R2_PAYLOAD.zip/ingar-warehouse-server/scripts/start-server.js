'use strict';
process.env.IWC_SERVER_MODE = '1';
process.env.IWC_HOST = process.env.IWC_HOST || '0.0.0.0';
process.env.IWC_PORT = process.env.PORT || process.env.IWC_PORT || '4317';
process.env.IWC_DATA_DIR = process.env.IWC_DATA_DIR || require('node:path').resolve(__dirname, '..', 'data');
const { startServer, stopServer } = require('../src/server');
const { ensureInitialAccess } = require('../src/services/bootstrap-access-service');
(async () => {
  await ensureInitialAccess(process.env.IWC_DATA_DIR);
  const server = await startServer({ serverMode: true, host: '0.0.0.0', port: Number(process.env.IWC_PORT), requireAdmin: false });
  const a = server.address();
  process.stdout.write(`INGAR Warehouse Server 1.0.51 listo en 0.0.0.0:${a.port}\n`);
})().catch((error) => {
  console.error(error?.stack || error);
  process.exit(1);
});
const shutdown = async () => { try { await stopServer(); } finally { process.exit(0); } };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
