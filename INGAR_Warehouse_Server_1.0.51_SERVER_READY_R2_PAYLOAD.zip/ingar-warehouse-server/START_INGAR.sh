#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$HOME/.ingar-warehouse-server.env"
PID_FILE="$HOME/.ingar-warehouse-server.pid"
LOG_FILE="$HOME/.ingar-warehouse-server.log"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "Servidor no instalado. Ejecutá ./INSTALL_SERVER.sh" >&2
  exit 2
fi
if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo "INGAR Warehouse ya está activo. PID $(cat "$PID_FILE")"
  exit 0
fi
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a
nohup node "$ROOT/scripts/start-server.js" >>"$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"
for _ in {1..30}; do
  if curl -fsS "http://127.0.0.1:${IWC_PORT:-4317}/api/v1/health/live" >/dev/null 2>&1; then
    echo "INGAR Warehouse ACTIVO en puerto ${IWC_PORT:-4317}. PID $(cat "$PID_FILE")"
    echo "Log: $LOG_FILE"
    exit 0
  fi
  sleep 1
done
echo "ERROR: Warehouse no respondió al healthcheck." >&2
tail -n 80 "$LOG_FILE" >&2 || true
exit 1
