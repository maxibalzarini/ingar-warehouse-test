# INGAR Warehouse Controller 1.0.51 — Server Edition

Servidor Linux centralizado. No incluye Electron ni binarios Windows.

## Codespaces
1. Subir este contenido a un repositorio.
2. `Code -> Codespaces -> Create codespace on main`.
3. El `postCreateCommand` instala el binding SQLite Linux, verifica SHA-256 y ejecuta el self-test completo.
4. El `postStartCommand` inicia Warehouse automáticamente en el puerto 4317.
5. En `PORTS`, abrir el puerto 4317. **Mantenerlo Private durante la creación del primer Administrador.**
6. Crear el Administrador General desde la pantalla inicial.
7. Recién después, si se necesita compartir la prueba, cambiar `Port Visibility` a `Public`.

## Comandos
- `./INSTALL_SERVER.sh` — instala binding nativo + genera secreto local + ejecuta self-test.
- `./START_INGAR.sh` — inicia en background.
- `./STOP_INGAR.sh` — detiene.
- `./STATUS_INGAR.sh` — healthcheck.

## Persistencia
Datos: `~/.ingar-warehouse-data/`
Clave de wrapping servidor: `~/.ingar-warehouse-server.env` (modo 600, no se versiona).

## Invariantes
- Schema máximo 053.
- Migración 054 ausente.
- SQLite cifrada.
- Backend/frontend reales.
- Sin fixtures/mocks/datos operativos sintéticos.

## Requisito
Node.js 22 (ABI 127). El devcontainer lo fija explícitamente.
