#!/usr/bin/env bash
set -euo pipefail
ENV_FILE="$HOME/.ingar-warehouse-server.env"
PID_FILE="$HOME/.ingar-warehouse-server.pid"
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
PORT="${IWC_PORT:-4317}"
if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  if curl -fsS "http://127.0.0.1:$PORT/api/v1/health/live" >/dev/null; then echo "ACTIVO · PID $(cat "$PID_FILE") · puerto $PORT"; exit 0; fi
fi
echo "DETENIDO"
exit 1
