'use strict';
/* F12: microinteracciones puramente visuales. No modifica estado ni negocio. */
(() => {
  const countIds = [
    'workbench-count-prepare','workbench-count-deliver','workbench-count-receive','workbench-count-problems',
    'workbench-lane-count-prepare','workbench-lane-count-deliver','workbench-lane-count-receive','workbench-lane-count-problems','workbench-lane-count-scheduled',
    'workbench-loaned-vehicles','workbench-loaned-tools','workbench-loaned-serialized','workbench-loaned-due-today'
  ];
  const pulse = (node) => {
    if (!node) return;
    node.classList.remove('f12-value-pop');
    void node.offsetWidth;
    node.classList.add('f12-value-pop');
  };
  const attach = (node) => {
    if (!node || node.dataset.f12Observed === '1') return;
    node.dataset.f12Observed = '1';
    let previous = node.textContent;
    new MutationObserver(() => {
      const next = node.textContent;
      if (next !== previous) { previous = next; pulse(node); }
    }).observe(node,{childList:true,characterData:true,subtree:true});
  };
  const syncOperationalScope = () => {
    const app = document.getElementById('app-view');
    document.body.classList.toggle('f13-operational', Boolean(app && !app.classList.contains('hidden')));
  };
  const init = () => {
    countIds.forEach((id) => attach(document.getElementById(id)));
    const app = document.getElementById('app-view');
    if (app) new MutationObserver(syncOperationalScope).observe(app,{attributes:true,attributeFilter:['class']});
    syncOperationalScope();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();
