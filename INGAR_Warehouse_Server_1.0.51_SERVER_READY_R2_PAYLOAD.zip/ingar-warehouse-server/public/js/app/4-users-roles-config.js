function userHasTechnicalInternalDocument(user) {
  return String(user?.person?.documentType || '').toUpperCase() === 'INTERNO'
    && String(user?.person?.documentNumber || '').toUpperCase().startsWith('AUTO-');
}

function userDocumentDisplay(user) {
  if (!user || userHasTechnicalInternalDocument(user)) return '';
  return [user.person?.documentType, user.person?.documentNumber].filter(Boolean).join(' ').trim();
}

function userUsesSimpleOperationalCredential(roleCodes) {
  const normalized = [...new Set((roleCodes || []).map((code) => String(code || '').toUpperCase()).filter(Boolean))];
  return normalized.length > 0 && normalized.every((code) => ['SOLICITANTE', 'PANOLERO'].includes(code));
}


function technicalUsernameBaseFromName(fullName) {
  const normalized = String(fullName || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const parts = normalized.trim().split(/\s+/).map((part) => part.replace(/[^a-z0-9]/g, '')).filter(Boolean);
  return parts.length >= 2 ? `${parts[0]}.${parts[parts.length - 1]}` : '';
}

function selectedUserRoleCodes() {
  const selectedIds = new Set($$('#user-role-options input:checked').map((input) => input.value));
  return state.roles.filter((role) => selectedIds.has(role.id)).map((role) => role.code);
}

function evidenceImageUrl(evidenceId) { return evidenceId ? `/api/v1/evidence/${encodeURIComponent(evidenceId)}` : ''; }
function initialsFromName(fullName) { const parts=String(fullName||'').trim().split(/\s+/).filter(Boolean); return (parts.slice(0,2).map((x)=>x[0]?.toUpperCase()||'').join('')||'US').slice(0,2); }
function renderUserIdentityCell(user) {
  const avatar = user?.person?.photoEvidenceId ? `<img class="user-identity-avatar" src="${escapeHtml(evidenceImageUrl(user.person.photoEvidenceId))}" alt="Avatar de ${escapeHtml(user.person.fullName)}">` : `<span class="user-identity-avatar-fallback" aria-hidden="true">${escapeHtml(initialsFromName(user?.person?.fullName))}</span>`;
  return `<div class="user-identity-cell">${avatar}<div class="user-identity-copy"><strong>${escapeHtml(user.person.fullName)}</strong><div class="small">${escapeHtml(user.person.email || '')}</div></div></div>`;
}
function setUserPhotoPreview(url) {
  const image=$('#user-photo-preview'), fallback=$('#user-photo-preview-fallback'); if(!image||!fallback)return;
  if(!url){ image.classList.add('hidden'); image.removeAttribute('src'); fallback.classList.remove('hidden'); return; }
  image.src=url; image.classList.remove('hidden'); fallback.classList.add('hidden');
}
async function updateUserPhotoPreviewFromInput(){ const file=$('#user-photo')?.files?.[0]; if(!file){ const existing=state.users.find((u)=>u.id===$('#user-id').value); setUserPhotoPreview(existing?.person?.photoEvidenceId?evidenceImageUrl(existing.person.photoEvidenceId):''); return;} setUserPhotoPreview(await fileToDataUrl(file)); }

function refreshTechnicalUsernameRule({ force = false } = {}) {
  const technical = selectedUserRoleCodes().includes('SOLICITANTE');
  const rule = $('#user-username-rule');
  if (rule) rule.textContent = technical ? 'Obligatorio para técnico: nombre.apellido.' : 'Usuario de acceso.';
  const input = $('#user-username');
  if (!input) return;
  input.pattern = technical ? '[a-zA-Z][a-zA-Z0-9]*\.[a-zA-Z][a-zA-Z0-9]*(?:\.[0-9]+)?' : '[A-Za-z0-9._-]{3,60}';
  const base = technicalUsernameBaseFromName($('#user-full-name')?.value || '');
  if (technical && base && (force || !input.value)) input.value = base;
}

async function loadUsers() {
  const batchReset = $('#user-operational-pins');
  if (batchReset) batchReset.hidden = !(state.user?.roleCodes || []).some((code) => ['ADMIN_GENERAL','ADMINISTRADOR'].includes(String(code).toUpperCase()));
  const search = encodeURIComponent($('#user-search').value || '');
  const lifecycle = encodeURIComponent($('#user-lifecycle-filter')?.value || 'ALL');
  const data = await api(`/api/v1/users?search=${search}&lifecycle=${lifecycle}&limit=250`);
  state.users = data.items;
  $('#users-body').innerHTML = data.items.map((user) => {
    const terminated = user.lifecycleStatus === 'BAJA';
    const statusLabel = terminated ? 'Baja' : user.active ? 'Activo' : 'Deshabilitado';
    const statusTone = user.active && !terminated ? 'ok' : 'danger';
    return `<tr>
    <td>${renderUserIdentityCell(user)}</td>
    <td>${escapeHtml(user.username)}</td><td>${escapeHtml(userDocumentDisplay(user) || 'Sin documento')}</td>
    <td>${escapeHtml(user.person.supervisorName || (user.roleCodes.includes('ADMIN_GENERAL') ? '—' : 'Sin asignar'))}</td>
    <td>${user.roleCodes.map((role) => `<span class="chip">${escapeHtml(role)}</span>`).join(' ')}</td>
    <td><span class="status ${statusTone}">${escapeHtml(statusLabel)}</span>${terminated && user.deletedAt ? `<div class="small">${escapeHtml(new Date(user.deletedAt).toLocaleString())}</div>` : ''}</td>
    <td class="actions">
      ${can('Users.Update') && !terminated ? `<button data-action="edit" data-id="${user.id}">Editar</button>` : ''}
      ${can('Users.Disable') && !terminated ? `<button data-action="toggle" data-id="${user.id}">${user.active ? 'Deshabilitar' : 'Habilitar'}</button>` : ''}
      ${can('Users.ResetPassword') && !terminated && user.id !== state.user?.id && ((state.user?.roleCodes || []).some((code) => ['ADMIN_GENERAL','ADMINISTRADOR'].includes(String(code).toUpperCase())) || user.person.supervisorUserId === state.user?.id) ? `<button data-action="reset" data-id="${user.id}">Blanquear contraseña</button>` : ''}
      ${can('Users.Delete') && !terminated ? `<button data-action="delete" data-id="${user.id}">Baja</button>` : ''}
    </td></tr>`;
  }).join('');
}

$('#user-search-button').addEventListener('click', () => loadUsers().catch((error) => flash(error.message, 'error')));
$('#user-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadUsers().catch((error) => flash(error.message, 'error')); });
$('#user-lifecycle-filter')?.addEventListener('change', () => loadUsers().catch((error) => flash(error.message, 'error')));
$('#user-operational-pins').addEventListener('click', async () => {
  if (!(state.user?.roleCodes || []).some((code) => ['ADMIN_GENERAL','ADMINISTRADOR'].includes(String(code).toUpperCase()))) { flash('El blanqueo masivo está reservado a Administradores.', 'error'); return; }
  if (!await askConfirm('Esto blanqueará únicamente las contraseñas de los usuarios operativos activos y cerrará sus sesiones. Los usuarios, IDs, supervisores e históricos no cambian. ¿Continuar?', { title: 'Blanquear contraseñas operativas', confirmText: 'Blanquear', danger: true })) return;
  try {
    const result = await api('/api/v1/users/operational-pins/reset', { method: 'POST', body: JSON.stringify({ confirm: true }) });
    await showNotice('Contraseñas blanqueadas', `${result.count} usuarios deberán definir solamente una nueva contraseña. Su usuario e historial se conservan.`);
    await loadUsers();
  } catch (error) { flash(error.message, 'error'); }
});
$('#user-create-button').addEventListener('click', async () => {
  await ensureRoles();
  $('#user-form').reset(); $('#user-id').value = ''; $('#user-version').value = ''; $('#user-password').value = ''; $('#user-confirm-password').value = '';
  $('#user-dialog-title').textContent = 'Nuevo usuario'; renderUserRoleOptions([]); renderSupervisorOptions('', null); renderPermissionOverrides([]); refreshTechnicalUsernameRule(); setUserPhotoPreview(''); const more = $('#user-more-data'); if (more) more.open = false; $('#user-dialog').showModal();
});

$('#users-body').addEventListener('click', async (event) => {
  const button = event.target.closest('button[data-action]'); if (!button) return;
  const user = state.users.find((item) => item.id === button.dataset.id); if (!user) return;
  try {
    if (button.dataset.action === 'edit') {
      await ensureRoles(); await fillUserForm(user); $('#user-dialog').showModal();
    } else if (button.dataset.action === 'toggle') {
      if (user.active) {
        await openUserLifecycleAction(user, 'DISABLE');
      } else {
        if (!await askConfirm(`Habilitar nuevamente a ${user.person.fullName}?`, { title: 'Habilitar usuario', confirmText: 'Habilitar' })) return;
        await api(`/api/v1/users/${user.id}/enable`, { method: 'POST', body: '{}' });
        flash('Usuario habilitado.'); await loadUsers();
      }
    } else if (button.dataset.action === 'reset') {
      const simple = userUsesSimpleOperationalCredential(user.roleCodes);
      if (simple) {
        if (!await askConfirm(`Blanquear la contraseña de ${user.person.fullName}? El usuario ${user.username} y todo su historial permanecerán sin cambios.`, { title: 'Blanquear contraseña', confirmText: 'Blanquear', danger: true })) return;
        await api(`/api/v1/users/${user.id}/reset-password`, { method: 'POST', body: JSON.stringify({ userSetup: true }) });
        await showNotice('Contraseña blanqueada', `En el próximo ingreso ${user.username} deberá definir solamente una nueva contraseña.`);
      } else {
        const values = await askFields('Blanquear contraseña', [
          { name: 'password', label: 'Nueva contraseña (4 a 8 letras o números)', type: 'password', minLength: 4, maxLength: 8, pattern: '[A-Za-z0-9]{4,8}', autocomplete: 'new-password' },
          { name: 'confirmPassword', label: 'Repetir nueva contraseña', type: 'password', minLength: 4, maxLength: 8, pattern: '[A-Za-z0-9]{4,8}', autocomplete: 'new-password' }
        ], { message: `Usuario: ${user.username}. Se conserva la persona, sus asignaciones y todo el historial.`, confirmText: 'Actualizar contraseña' });
        if (!values) return;
        if (values.password !== values.confirmPassword) throw new Error('Las contraseñas no coinciden.');
        await api(`/api/v1/users/${user.id}/reset-password`, { method: 'POST', body: JSON.stringify(values) });
        await showNotice('Contraseña actualizada', 'La nueva contraseña quedó activa. No vence y no requiere cambio posterior.');
      }
      await loadUsers();
    } else if (button.dataset.action === 'delete') {
      await openUserLifecycleAction(user, 'TERMINATE');
    }
  } catch (error) { flash(error.message, 'error'); }
});

let pendingUserLifecycle = null;

async function openUserLifecycleAction(user, action) {
  const preflight = await api(`/api/v1/users/${user.id}/lifecycle-preflight`, { method: 'POST', body: JSON.stringify({ action }) });
  pendingUserLifecycle = { user, action, eventId: preflight.eventId, summary: preflight.summary, clearance: preflight.summary?.clearance || { tools: 0, kits: 0, vehicles: 0, incidents: 0, ready: true } };
  $('#user-lifecycle-user-id').value = user.id;
  $('#user-lifecycle-event-id').value = preflight.eventId;
  $('#user-lifecycle-action').value = action;
  $('#user-lifecycle-title').textContent = action === 'TERMINATE' ? 'Baja de usuario' : 'Deshabilitar usuario';
  $('#user-lifecycle-identity').textContent = `${user.person.fullName} · ${user.username}${user.person.supervisorName ? ` · Supervisor: ${user.person.supervisorName}` : ''}`;
  $('#user-lifecycle-request-count').value = String(preflight.summary.requestCount || 0);
  $('#user-lifecycle-active-request-count').value = String(preflight.summary.activeRequestCount || 0);
  $('#user-lifecycle-open-custody-count').value = String(preflight.summary.openCustodyCount || 0);
  $('#user-lifecycle-pending-return-count').value = String(preflight.summary.pendingWarehouseReturnCount || 0);
  const clearance = pendingUserLifecycle.clearance;
  $('#user-lifecycle-tool-count').value = String(clearance.tools || 0);
  $('#user-lifecycle-kit-count').value = String(clearance.kits || 0);
  $('#user-lifecycle-vehicle-count').value = String(clearance.vehicles || 0);
  $('#user-lifecycle-incident-count').value = String(clearance.incidents || 0);
  const status = $('#user-lifecycle-clearance-status');
  status.className = `user-clearance-status ${clearance.ready ? 'ready' : 'pending'}`;
  status.textContent = action !== 'TERMINATE'
    ? 'La deshabilitación conserva íntegra la situación patrimonial y no cierra custodias.'
    : clearance.ready
      ? 'Visto Bueno patrimonial: sin herramientas/equipos, kits ni vehículos pendientes.'
      : `Baja patrimonial pendiente: ${clearance.tools || 0} herramienta(s)/equipo(s), ${clearance.kits || 0} kit(s) y ${clearance.vehicles || 0} vehículo(s) requieren devolución.`;
  const summary = pendingUserLifecycle.summary || {};
  $('#user-lifecycle-warning').textContent = action === 'DISABLE'
    ? ((clearance.tools || clearance.kits || clearance.vehicles || summary.openCustodyCount)
      ? `Advertencia: la cuenta se quedará sin acceso, pero conserva ${clearance.tools || 0} herramienta(s)/equipo(s), ${clearance.kits || 0} kit(s), ${clearance.vehicles || 0} vehículo(s) y ${summary.openCustodyCount || 0} custodia(s) abierta(s). Deshabilitar NO cierra ni reasigna estas responsabilidades.`
      : 'Deshabilitar suspende únicamente el acceso. La identidad y el histórico permanecen preservados.')
    : (preflight.warning || 'Sin observaciones de prechequeo.');
  $('#user-lifecycle-reason').value = '';
  const pdfRemito = $('#user-lifecycle-pdf-remito'); const pdfHr = $('#user-lifecycle-pdf-hr'); const pdfBoth = $('#user-lifecycle-pdf-both');
  if (pdfRemito) pdfRemito.classList.toggle('hidden', action !== 'TERMINATE');
  if (pdfHr) pdfHr.classList.toggle('hidden', action !== 'TERMINATE');
  if (pdfBoth) pdfBoth.classList.toggle('hidden', action !== 'TERMINATE');
  const pdfState = $('#user-lifecycle-pdf-state'); if (pdfState) pdfState.textContent = action === 'TERMINATE' ? 'Remito patrimonial + Acta de liberación, ambos A4.' : 'Los PDF de RR.HH. se habilitan únicamente para una baja.';
  const overrideWrap = $('#user-lifecycle-override-wrap'); const override = $('#user-lifecycle-clearance-override');
  if (override) override.checked = false;
  if (overrideWrap) overrideWrap.classList.add('hidden');
  const confirm = $('#user-lifecycle-confirm');
  confirm.textContent = action === 'TERMINATE' ? (clearance.ready ? 'Generar PDF y aplicar baja' : 'Baja bloqueada por pendientes') : 'Deshabilitar';
  confirm.disabled = action === 'TERMINATE' && !clearance.ready;
  confirm.classList.add('danger');
  $('#user-lifecycle-dialog').showModal();
}

async function downloadLifecycleExport(scope) {
  if (!pendingUserLifecycle) return;
  const blob = await api(`/api/v1/users/${pendingUserLifecycle.user.id}/lifecycle-export`, {
    method: 'POST',
    body: JSON.stringify({ eventId: pendingUserLifecycle.eventId, scope })
  });
  const stamp = new Date().toISOString().slice(0,10);
  const username = String(pendingUserLifecycle.user.username || 'usuario').replace(/[^A-Za-z0-9._-]+/g, '-');
  const filename = scope === 'REQUEST_HISTORY'
    ? `historial-pedidos-${username}-${stamp}.xlsx`
    : scope === 'PENDING_WAREHOUSE_RETURNS'
      ? `devoluciones-pendientes-panio-${username}-${stamp}.xlsx`
      : `expediente-completo-${username}-${stamp}.zip`;
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = objectUrl; link.download = filename; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(objectUrl);
  flash('Exportación generada y registrada.');
}

$('#user-lifecycle-export-history')?.addEventListener('click', () => downloadLifecycleExport('REQUEST_HISTORY').catch((error) => flash(error.message, 'error')));
$('#user-lifecycle-export-pending')?.addEventListener('click', () => downloadLifecycleExport('PENDING_WAREHOUSE_RETURNS').catch((error) => flash(error.message, 'error')));
$('#user-lifecycle-export-all')?.addEventListener('click', () => downloadLifecycleExport('ALL').catch((error) => flash(error.message, 'error')));

async function downloadLifecycleClearancePdf(kind) {
  if (!pendingUserLifecycle || pendingUserLifecycle.action !== 'TERMINATE') return;
  const blob = await api(`/api/v1/users/${pendingUserLifecycle.user.id}/lifecycle-clearance-pdf`, {
    method: 'POST',
    body: JSON.stringify({ eventId: pendingUserLifecycle.eventId, kind })
  });
  const stamp = new Date().toISOString().slice(0,10);
  const username = String(pendingUserLifecycle.user.username || 'usuario').replace(/[^A-Za-z0-9._-]+/g, '-');
  const filename = kind === 'PATRIMONIAL_RECEIPT' ? `remito-devolucion-patrimonial-${username}-${stamp}.pdf` : `acta-liberacion-rrhh-${username}-${stamp}.pdf`;
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = objectUrl; link.download = filename; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(objectUrl);
  flash('PDF A4 generado desde la situación patrimonial actual y registrado con SHA-256.');
}

$('#user-lifecycle-pdf-remito')?.addEventListener('click', () => downloadLifecycleClearancePdf('PATRIMONIAL_RECEIPT').catch((error) => flash(error.message, 'error')));
$('#user-lifecycle-pdf-hr')?.addEventListener('click', () => downloadLifecycleClearancePdf('HR_RELEASE').catch((error) => flash(error.message, 'error')));
$('#user-lifecycle-pdf-both')?.addEventListener('click', async () => {
  const button = $('#user-lifecycle-pdf-both'); const status = $('#user-lifecycle-pdf-state');
  if (!pendingUserLifecycle || pendingUserLifecycle.action !== 'TERMINATE') return;
  button.disabled = true; if (status) status.textContent = 'Generando Remito patrimonial…';
  try {
    await downloadLifecycleClearancePdf('PATRIMONIAL_RECEIPT');
    if (status) status.textContent = 'Generando Acta de liberación RR.HH.…';
    await downloadLifecycleClearancePdf('HR_RELEASE');
    if (status) { status.textContent = 'Los 2 PDF A4 fueron generados y registrados.'; status.classList.add('ok'); }
  } catch (error) {
    if (status) status.textContent = 'No se pudieron generar ambos documentos. Revisá el mensaje e intentá nuevamente.';
    flash(error.message, 'error');
  } finally { button.disabled = false; }
});

$('#user-lifecycle-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!pendingUserLifecycle) return;
  const reason = String($('#user-lifecycle-reason').value || '').trim();
  if (reason.length < 5) { flash('Ingresá un motivo de al menos 5 caracteres.', 'error'); return; }
  const current = pendingUserLifecycle;
  try {
    if (current.action === 'TERMINATE') {
      if (!current.clearance?.ready) { flash('Primero deben resolverse las herramientas/equipos, kits o vehículos pendientes.', 'error'); return; }
      const confirm = $('#user-lifecycle-confirm');
      const previousText = confirm.textContent;
      confirm.disabled = true; confirm.textContent = 'GENERANDO PDF…';
      try {
        await downloadLifecycleClearancePdf('PATRIMONIAL_RECEIPT');
        await downloadLifecycleClearancePdf('HR_RELEASE');
      } catch (pdfError) {
        confirm.disabled = false; confirm.textContent = previousText;
        throw pdfError;
      }
      confirm.textContent = 'APLICANDO BAJA…';
      await api(`/api/v1/users/${current.user.id}`, { method: 'DELETE', body: JSON.stringify({ lifecycleEventId: current.eventId, reason }) });
      $('#user-lifecycle-dialog').close(); pendingUserLifecycle = null;
      await showNotice('Baja aplicada', 'La baja quedó aplicada con clearance patrimonial confirmado y los dos PDF obligatorios generados. Usuario, persona e históricos permanecen preservados.');
    } else {
      await api(`/api/v1/users/${current.user.id}/disable`, { method: 'POST', body: JSON.stringify({ lifecycleEventId: current.eventId, reason }) });
      $('#user-lifecycle-dialog').close(); pendingUserLifecycle = null;
      await showNotice('Usuario deshabilitado', 'La cuenta quedó sin acceso. La identidad y todo su histórico permanecen sin cambios.');
    }
    await loadUsers();
  } catch (error) { flash(error.message, 'error'); }
});

async function ensureRoles() {
  const jobs = [api('/api/v1/users/supervisor-candidates').then((data) => { state.supervisorCandidates = data.items; })];
  if (!state.roles.length || !state.permissions.length) {
    jobs.push(Promise.all([api('/api/v1/roles'), api('/api/v1/permissions')]).then(([roles, permissions]) => {
      state.roles = roles.items; state.permissions = permissions.items;
    }));
  }
  await Promise.all(jobs);
}
function renderUserRoleOptions(selected) {
  $('#user-role-options').innerHTML = state.roles.filter((role) => role.active).map((role) => `<label><input type="checkbox" value="${role.id}" ${selected.includes(role.id) ? 'checked' : ''}> ${escapeHtml(role.name)}</label>`).join('');
}
function renderSupervisorOptions(selected, currentUserId) {
  const candidates = state.supervisorCandidates.filter((item) => item.id !== currentUserId);
  const selectedExists = candidates.some((item) => item.personId === selected);
  const effectiveSelected = selectedExists ? selected : (currentUserId ? '' : (candidates.find((item) => item.isDefault)?.personId || ''));
  const emptyOption = currentUserId && !selected ? '<option value="" selected>Sin supervisor (raíz administrativa)</option>' : '';
  const options = candidates.map((item) => `<option value="${item.personId}" ${item.personId === effectiveSelected ? 'selected' : ''}>${escapeHtml(item.fullName)} · ${escapeHtml(item.roleCodes.join(' / '))}</option>`).join('');
  $('#user-supervisor').innerHTML = emptyOption + options || '<option value="">Sin supervisor disponible</option>';
}
function renderPermissionOverrides(overrides) {
  const map = new Map(overrides.map((item) => [item.code, item.effect]));
  $('#user-permission-overrides').innerHTML = state.permissions.map((permission) => `<div class="override-item"><span><strong>${escapeHtml(permission.code)}</strong><br><span class="small">${escapeHtml(permission.name)}</span></span><select data-override-code="${escapeHtml(permission.code)}" ${can('Roles.Update') ? '' : 'disabled'}><option value="">Heredado</option><option value="ALLOW" ${map.get(permission.code) === 'ALLOW' ? 'selected' : ''}>Permitir</option><option value="DENY" ${map.get(permission.code) === 'DENY' ? 'selected' : ''}>Denegar</option></select></div>`).join('');
}
async function fillUserForm(user) {
  $('#user-id').value = user.id; $('#user-version').value = user.version; $('#user-dialog-title').textContent = 'Editar usuario';
  $('#user-full-name').value = user.person.fullName; $('#user-username').value = user.username; $('#user-password').value = ''; $('#user-confirm-password').value = '';
  const visibleDocument = userHasTechnicalInternalDocument(user) ? { type: '', number: '' } : { type: user.person.documentType || '', number: user.person.documentNumber || '' };
  $('#user-document-type').value = visibleDocument.type; $('#user-document-number').value = visibleDocument.number;
  $('#user-email').value = user.person.email || ''; $('#user-phone').value = user.person.phone || '';
  $('#user-photo').value = ''; setUserPhotoPreview(user.person.photoEvidenceId ? evidenceImageUrl(user.person.photoEvidenceId) : '');
  $('#user-sector').value = user.person.sector || ''; $('#user-cost-center').value = user.person.costCenter || '';
  $('#user-employee-number').value = user.person.employeeNumber || ''; $('#user-observations').value = user.person.observations || '';
  renderUserRoleOptions(user.roles.map((role) => role.id)); renderSupervisorOptions(user.person.supervisorPersonId || '', user.id); refreshTechnicalUsernameRule();
  const overrides = can('Roles.Read') ? (await api(`/api/v1/users/${user.id}/permission-overrides`)).items : [];
  renderPermissionOverrides(overrides);
  const more = $('#user-more-data'); if (more) more.open = false;
}
async function fileToDataUrl(file) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); }); }
async function uploadImage(input) {
  const file = input.files[0]; if (!file) return null;
  const result = await api('/api/v1/evidence/images', { method: 'POST', body: JSON.stringify({ originalFilename: file.name, dataUrl: await fileToDataUrl(file) }) });
  return result.evidence.id;
}


$('#user-full-name').addEventListener('input', () => {
  if (!$('#user-id').value && selectedUserRoleCodes().includes('SOLICITANTE')) refreshTechnicalUsernameRule({ force: true });
});
$('#user-role-options').addEventListener('change', () => refreshTechnicalUsernameRule({ force: !$('#user-id').value }));

$('#user-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('#user-id').value;
    const existing = state.users.find((user) => user.id === id);
    const photoEvidenceId = await uploadImage($('#user-photo')) || existing?.person.photoEvidenceId || null;
    const signatureEvidenceId = await uploadImage($('#user-signature')) || existing?.person.signatureEvidenceId || null;
    const payload = {
      username: $('#user-username').value,
      version: id ? Number($('#user-version').value) : undefined,
      password: $('#user-password').value || undefined,
      confirmPassword: $('#user-confirm-password').value || undefined,
      roleIds: $$('#user-role-options input:checked').map((input) => input.value),
      person: {
        fullName: $('#user-full-name').value, documentType: $('#user-document-type').value,
        documentNumber: $('#user-document-number').value, email: $('#user-email').value,
        phone: $('#user-phone').value, sector: $('#user-sector').value, supervisorPersonId: $('#user-supervisor').value || null,
        costCenter: $('#user-cost-center').value, employeeNumber: $('#user-employee-number').value,
        observations: $('#user-observations').value, photoEvidenceId, signatureEvidenceId
      }
    };
    const result = await api(id ? `/api/v1/users/${id}` : '/api/v1/users', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    if (state.user?.id === result.user.id) { state.user.photoEvidenceId = result.user?.person?.photoEvidenceId || photoEvidenceId || null; if (typeof applySessionAvatar === 'function') applySessionAvatar(); }
    if (can('Roles.Update')) {
      const overrides = $$('#user-permission-overrides select').filter((select) => select.value).map((select) => ({ code: select.dataset.overrideCode, effect: select.value }));
      await api(`/api/v1/users/${result.user.id}/permission-overrides`, { method: 'PUT', body: JSON.stringify({ overrides }) });
    }
    $('#user-dialog').close(); flash('Usuario guardado.');
    await loadUsers();
  } catch (error) { flash(error.message, 'error'); }
});

async function loadRoles() {
  const [roles, permissions] = await Promise.all([api('/api/v1/roles'), api('/api/v1/permissions')]);
  state.roles = roles.items; state.permissions = permissions.items;
  $('#roles-grid').innerHTML = state.roles.map((role) => `<article class="card role-card"><h3>${escapeHtml(role.name)}</h3><code>${escapeHtml(role.code)}</code><p class="small">${role.active ? 'Activo' : 'Inactivo'} · ${role.system_role ? 'Rol del sistema' : 'Rol personalizado'}</p><div class="chips">${role.permissions.map((permission) => `<span class="chip">${escapeHtml(permission)}</span>`).join('')}</div>${can('Roles.Update') ? `<p><button data-role-edit="${role.id}">Editar</button></p>` : ''}</article>`).join('');
}
$('#role-create-button').addEventListener('click', async () => { await loadRoles(); fillRoleForm(null); $('#role-dialog').showModal(); });
$('#roles-grid').addEventListener('click', (event) => { const button = event.target.closest('[data-role-edit]'); if (!button) return; fillRoleForm(state.roles.find((role) => role.id === button.dataset.roleEdit)); $('#role-dialog').showModal(); });
function fillRoleForm(role) {
  $('#role-form').reset(); $('#role-id').value = role?.id || ''; $('#role-code').value = role?.code || ''; $('#role-code').disabled = Boolean(role);
  $('#role-name').value = role?.name || ''; $('#role-active').checked = role ? Boolean(role.active) : true;
  $('#role-parent').innerHTML = '<option value="">Sin herencia</option>' + state.roles.filter((item) => item.id !== role?.id && item.active).map((item) => `<option value="${item.id}" ${item.id === role?.parent_role_id ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('');
  $('#role-dialog-title').textContent = role ? 'Editar rol' : 'Nuevo rol';
  $('#role-permission-options').innerHTML = state.permissions.map((permission) => `<label><input type="checkbox" value="${escapeHtml(permission.code)}" ${role?.permissions.includes(permission.code) ? 'checked' : ''}> <span><strong>${escapeHtml(permission.code)}</strong><br><span class="small">${escapeHtml(permission.name)}</span></span></label>`).join('');
}
$('#role-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('#role-id').value;
    const currentRole = state.roles.find((role) => role.id === id);
    const payload = { code: $('#role-code').value, name: $('#role-name').value, version: currentRole?.version, parentRoleId: $('#role-parent').value || null, active: $('#role-active').checked, permissions: $$('#role-permission-options input:checked').map((input) => input.value) };
    await api(id ? `/api/v1/roles/${id}` : '/api/v1/roles', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    $('#role-dialog').close(); flash('Rol guardado.'); await loadRoles();
  } catch (error) { flash(error.message, 'error'); }
});

let configOriginalValues = new Map();

function configUiValue(input, rawValue) {
  const scale = Number(input.dataset.scale || 1);
  if (input.type === 'number' && Number.isFinite(Number(rawValue))) return String(Number(rawValue) / scale);
  return typeof rawValue === 'boolean' ? String(rawValue) : (rawValue ?? '');
}

function configApiValue(input) {
  const isBooleanSelect = input.tagName === 'SELECT'
    && [...input.options].every((option) => option.value === 'true' || option.value === 'false');
  if (input.type === 'number') { const scaled = Number(input.value) * Number(input.dataset.scale || 1); return input.dataset.decimal === 'true' ? Number(scaled.toFixed(6)) : Math.round(scaled); }
  if (isBooleanSelect) return input.value === 'true';
  return input.dataset.setting === 'locale.currency' ? input.value.trim().toUpperCase() : input.value.trim();
}

async function loadConfig() {
  const [data, locationData] = await Promise.all([api('/api/v1/config'), api('/api/v1/config/locations')]);
  state.locations = locationData;
  const logoEvidenceId = data.settings['organization.logoEvidenceId']?.value;
  const logoPreview = $('#organization-logo-preview');
  if (logoEvidenceId) { logoPreview.src = `/api/v1/evidence/${logoEvidenceId}`; logoPreview.classList.remove('hidden'); }
  else { logoPreview.removeAttribute('src'); logoPreview.classList.add('hidden'); }
  $('#organization-logo').disabled = !can('Config.Update');
  configOriginalValues = new Map();
  $$('[data-setting]').forEach((input) => {
    const value = data.settings[input.dataset.setting]?.value;
    input.value = configUiValue(input, value);
    configOriginalValues.set(input.dataset.setting, JSON.stringify(value));
    input.disabled = !can('Config.Update');
  });
  const status = $('#config-save-status'); if (status) status.textContent = '';
  renderLocations();
}

$('#config-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const changes = {};
  $$('[data-setting]').forEach((input) => {
    const value = configApiValue(input);
    if (JSON.stringify(value) !== configOriginalValues.get(input.dataset.setting)) changes[input.dataset.setting] = value;
  });
  const status = $('#config-save-status');
  if (!Object.keys(changes).length) {
    if (status) status.textContent = 'No hay cambios pendientes.';
    return;
  }
  try {
    await api('/api/v1/config', { method: 'PUT', body: JSON.stringify({ changes }) });
    if (status) status.textContent = 'Guardado.';
    flash('Configuración guardada.'); await loadConfig();
  } catch (error) { if (status) status.textContent = ''; flash(error.message, 'error'); }
});

$('#organization-logo-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const file = $('#organization-logo').files[0];
  if (!file) { flash('Elegí una imagen para actualizar el logo.', 'error'); return; }
  try {
    await api('/api/v1/config/logo', { method: 'POST', body: JSON.stringify({ originalFilename: file.name, dataUrl: await fileToDataUrl(file) }) });
    $('#organization-logo').value = '';
    $('#organization-logo-status').textContent = 'Sin archivo seleccionado';
    if (window.iwcBranding?.refresh) await window.iwcBranding.refresh().catch(() => {});
    flash('Logo del cliente actualizado.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

function siteEnabledCategoryIds(siteId) {
  return new Set((state.locations.siteCategories || []).filter((item) => item.site_id === siteId && item.active).map((item) => item.category_id));
}

function renderSiteCategoryOptions(containerId, selectedIds = null) {
  const container = $(containerId);
  if (!container) return;
  const categories = state.locations.categories || [];
  const selected = selectedIds === null
    ? new Set(categories.filter((item) => item.active).map((item) => item.id))
    : new Set(selectedIds);
  container.innerHTML = categories.map((category) => `<label><input type="checkbox" value="${escapeHtml(category.id)}" ${selected.has(category.id) ? 'checked' : ''} ${!category.active && !selected.has(category.id) ? 'disabled' : ''}><span><strong>${escapeHtml(category.code)} · ${escapeHtml(category.name)}</strong><small>${escapeHtml(uiCodeLabel(category.nature))}${category.active ? '' : ' · categoría global inactiva'}</small></span></label>`).join('') || '<span class="small">No hay categorías creadas.</span>';
}

function checkedSiteCategories(containerId) {
  return $$(`${containerId} input[type="checkbox"]:checked`).map((input) => input.value);
}

function locationTypeLabel(value) {
  return { PANOL:'Pañol', GARAJE:'Garaje', ESTACIONAMIENTO:'Estacionamiento', TALLER:'Taller', DEPOSITO:'Depósito', OFICINA:'Oficina', OTRO:'Otra' }[String(value || '').toUpperCase()] || uiCodeLabel(value || 'OTRO');
}

function openNewLocationForSite(siteId) {
  const panel = $('#location-form')?.closest('details');
  if (panel) panel.open = true;
  $('#location-site').value = siteId || '';
  $('#location-type').value = 'PANOL';
  $('#location-name').focus();
  panel?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function renderLocations() {
  const primaryOrganization = state.locations.organizations.find((item) => item.active) || state.locations.organizations[0] || null;
  $('#site-organization').value = primaryOrganization?.id || '';
  $('#site-organization-name').textContent = primaryOrganization?.name || 'Sin organización';
  const orgSummary = $('#organization-admin-summary');
  if (orgSummary) orgSummary.innerHTML = primaryOrganization
    ? `<div class="organization-inline-admin"><span><strong>${escapeHtml(primaryOrganization.name)}</strong></span>${can('Config.Update') ? `<button type="button" data-organization-edit-id="${escapeHtml(primaryOrganization.id)}">Editar organización</button>` : ''}</div>`
    : '<span class="status danger">Sin organización</span>';

  const activeSites = state.locations.sites.filter((item) => item.active);
  $('#location-site').innerHTML = activeSites.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`).join('');
  renderSiteCategoryOptions('#site-category-options');
  const siteNames = new Map(state.locations.sites.map((item) => [item.id, item.name]));
  const categoriesById = new Map((state.locations.categories || []).map((item) => [item.id, item]));

  const sitesBody = $('#sites-body');
  if (sitesBody) sitesBody.innerHTML = state.locations.sites.map((site) => {
    const categoryNames = [...siteEnabledCategoryIds(site.id)].map((id) => categoriesById.get(id)).filter(Boolean).map((category) => category.code);
    const usage = `${Number(site.locationCount || 0)} ubic. · ${Number(site.assetCount || 0)} bienes`;
    const canDeleteSite = Number(site.activeAssetCount || 0) === 0;
    const siteActions = can('Config.Update') ? `<button type="button" class="primary" data-site-add-location-id="${escapeHtml(site.id)}">Agregar ubicación</button><button type="button" data-site-edit-id="${escapeHtml(site.id)}">Editar</button>${canDeleteSite ? `<button type="button" class="danger" data-site-delete-id="${escapeHtml(site.id)}">Eliminar</button>` : ''}` : '';
    return `<tr>
      <td><strong>${escapeHtml(site.name)}</strong><div class="small">${site.active ? 'Activa' : 'Inactiva'}</div></td>
      <td>${escapeHtml(site.code || '—')}</td>
      <td>${site.is_primary ? '<span class="status ok">Sí</span>' : 'No'}</td>
      <td>${escapeHtml(categoryNames.join(', ') || 'Sin categorías')}</td>
      <td>${escapeHtml(usage)}</td>
      <td class="actions">${siteActions}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="6">No hay sedes creadas.</td></tr>';

  const locationsBody = $('#locations-body');
  if (locationsBody) locationsBody.innerHTML = state.locations.locations.map((location) => {
    const count = Number(location.activeAssetCount ?? location.assetCount ?? 0);
    let actions = '';
    if (can('Config.Update')) {
      if (location.active) {
        actions = `<button type="button" data-location-edit-id="${escapeHtml(location.id)}">Editar</button>
          ${count > 0 ? `<button type="button" class="primary" data-location-transfer-id="${escapeHtml(location.id)}">Transferir bienes</button><button type="button" data-location-empty-id="${escapeHtml(location.id)}">Vaciar y eliminar</button>` : `<button type="button" class="danger" data-location-delete-id="${escapeHtml(location.id)}">Eliminar</button>`}`;
      } else {
        actions = `<button type="button" data-location-reactivate-id="${escapeHtml(location.id)}" data-location-version="${Number(location.version)}">Reactivar</button><button type="button" class="danger" data-location-delete-id="${escapeHtml(location.id)}">Eliminar</button>`;
      }
    }
    return `<tr>
      <td><strong>${escapeHtml(location.name)}</strong><div class="small">${escapeHtml(location.code)}</div></td>
      <td>${escapeHtml(locationTypeLabel(location.type))}</td>
      <td>${escapeHtml(siteNames.get(location.site_id) || '—')}</td>
      <td><strong>${count}</strong><div class="small">${count === 1 ? 'bien activo' : 'bienes activos'}</div></td>
      <td><span class="status ${location.active ? 'ok' : 'neutral'}">${location.active ? 'Activa' : 'Inactiva'}</span></td>
      <td class="actions location-row-actions">${actions}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="6">No hay ubicaciones creadas.</td></tr>';
}

$('#site-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api('/api/v1/config/sites', { method: 'POST', body: JSON.stringify({
      organizationId: $('#site-organization').value,
      code: $('#site-code').value,
      name: $('#site-name').value,
      description: $('#site-description').value,
      isPrimary: $('#site-primary').checked,
      categoryIds: checkedSiteCategories('#site-category-options')
    }) });
    event.target.reset(); event.target.closest('details')?.removeAttribute('open');
    flash('Sede creada.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

$('#location-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const locationName = $('#location-name').value.trim();
    await api('/api/v1/config/locations', { method: 'POST', body: JSON.stringify({ siteId: $('#location-site').value, name: locationName, type: $('#location-type').value }) });
    event.target.reset(); $('#location-type').value = 'PANOL'; event.target.closest('details')?.removeAttribute('open');
    flash('Ubicación creada.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

$('#organization-admin-summary')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-organization-edit-id]');
  if (!button) return;
  const organization = state.locations.organizations.find((item) => item.id === button.dataset.organizationEditId);
  if (!organization) return;
  $('#organization-edit-id').value = organization.id;
  $('#organization-edit-version').value = organization.version;
  $('#organization-edit-name').value = organization.name || '';
  $('#organization-edit-dialog').showModal();
});

$('#organization-edit-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const id = $('#organization-edit-id').value;
  try {
    await api(`/api/v1/config/organizations/${id}`, { method: 'PATCH', body: JSON.stringify({ version: Number($('#organization-edit-version').value), name: $('#organization-edit-name').value }) });
    $('#organization-edit-dialog').close(); flash('Organización actualizada.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

$('#site-edit-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const id = $('#site-edit-id').value;
  if (!id) return;
  try {
    await api(`/api/v1/config/sites/${id}`, { method: 'PATCH', body: JSON.stringify({
      version: Number($('#site-edit-version').value),
      code: $('#site-edit-code').value,
      name: $('#site-edit-name').value,
      description: $('#site-edit-description').value,
      active: $('#site-edit-active').checked,
      isPrimary: $('#site-edit-primary').checked,
      categoryIds: checkedSiteCategories('#site-edit-category-options')
    }) });
    $('#site-edit-dialog').close(); flash('Sede actualizada.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

$('#location-edit-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const id = $('#location-edit-id').value;
  try {
    await api(`/api/v1/config/locations/${id}`, { method: 'PATCH', body: JSON.stringify({ version: Number($('#location-edit-version').value), name: $('#location-edit-name').value, type: $('#location-edit-type').value }) });
    $('#location-edit-dialog').close(); flash('Ubicación actualizada.'); await loadConfig();
  } catch (error) { flash(error.message, 'error'); }
});

let currentLocationTransferOverview = null;
let currentLocationTransferSelection = new Map();
let locationTransferSearchTimer = null;

function locationTransferChoice() {
  return document.querySelector('input[name="location-transfer-choice"]:checked')?.value || 'AVAILABLE';
}

function renderTransferSelected() {
  const items = [...currentLocationTransferSelection.values()];
  $('#location-transfer-selected-count').textContent = `${items.length} seleccionado${items.length === 1 ? '' : 's'}`;
  $('#location-transfer-selected-list').innerHTML = items.length
    ? items.slice(0, 12).map((item) => `<button type="button" data-transfer-remove-id="${escapeHtml(item.id)}">${escapeHtml(item.internalCode)} ×</button>`).join('') + (items.length > 12 ? `<span class="small">+${items.length - 12} más</span>` : '')
    : '<span class="small">Todavía no elegiste bienes.</span>';
}

function renderTransferSearchResults(items) {
  $('#location-transfer-items').innerHTML = items.length ? items.map((item) => {
    const checked = currentLocationTransferSelection.has(item.id) ? 'checked' : '';
    return `<label class="transfer-search-row"><input type="checkbox" data-transfer-result-id="${escapeHtml(item.id)}" ${checked}><span><strong>${escapeHtml(item.internalCode)} · ${escapeHtml(item.description)}</strong><small>${escapeHtml(item.categoryName || '')}${Number(item.groupAssetCount || 1) > 1 ? ` · kit de ${Number(item.groupAssetCount)} componentes` : ''}</small></span></label>`;
  }).join('') : '<div class="empty-state">No hay bienes transferibles para esa búsqueda.</div>';
}

function updateLocationTransferUi() {
  const operation = $('#location-transfer-operation').value;
  const summary = currentLocationTransferOverview?.summary || { transferable: 0, blocked: 0 };
  const choice = locationTransferChoice();
  const isEmpty = operation === 'EMPTY_AND_DELETE';
  $('#location-transfer-mode-panel').classList.toggle('hidden', isEmpty);
  $('#location-transfer-selection').classList.toggle('hidden', isEmpty || choice !== 'SELECTED');
  $('#location-transfer-empty-note').classList.toggle('hidden', !isEmpty);
  if (isEmpty) {
    const blocked = Number(summary.blocked || 0);
    $('#location-transfer-empty-note').innerHTML = blocked
      ? `<strong>Se moverán ${Number(summary.transferable || 0)} disponibles.</strong><span>${blocked} no se pueden mover ahora; quedarán en origen y la ubicación seguirá activa.</span>`
      : `<strong>Se moverán ${Number(summary.transferable || 0)} bienes.</strong><span>Al quedar vacía, la ubicación se eliminará de la operación automáticamente.</span>`;
    $('#location-transfer-submit').textContent = blocked ? `MOVER ${Number(summary.transferable || 0)} DISPONIBLES` : 'VACIAR Y ELIMINAR';
    $('#location-transfer-submit').disabled = Number(summary.transferable || 0) === 0 && Number(summary.blocked || 0) > 0;
  } else if (choice === 'AVAILABLE') {
    $('#location-transfer-submit').textContent = `TRANSFERIR ${Number(summary.transferable || 0)} BIEN${Number(summary.transferable || 0) === 1 ? '' : 'ES'}`;
    $('#location-transfer-submit').disabled = Number(summary.transferable || 0) === 0;
  } else {
    const count = currentLocationTransferSelection.size;
    $('#location-transfer-submit').textContent = `TRANSFERIR ${count} BIEN${count === 1 ? '' : 'ES'}`;
    $('#location-transfer-submit').disabled = count === 0;
  }
  $('#location-transfer-available-note').textContent = `${Number(summary.transferable || 0)} disponibles para mover ahora.`;
  renderTransferSelected();
}

async function refreshLocationTransferOverview({ includeItems = false } = {}) {
  const sourceId = $('#location-transfer-source-id').value;
  const destinationId = $('#location-transfer-destination').value;
  if (!sourceId || !destinationId) return;
  const params = new URLSearchParams({ destinationLocationId: destinationId, includeItems: String(includeItems), limit: '50' });
  if (includeItems) params.set('q', $('#location-transfer-search').value.trim());
  currentLocationTransferOverview = await api(`/api/v1/config/locations/${sourceId}/transfer-overview?${params}`);
  const summary = currentLocationTransferOverview.summary || {};
  $('#location-transfer-summary').innerHTML = `<strong>${Number(summary.transferable || 0)} disponibles para transferir</strong><span>${Number(summary.blocked || 0)} no disponibles ahora</span>`;
  if (includeItems) renderTransferSearchResults(currentLocationTransferOverview.items || []);
  updateLocationTransferUi();
}

async function openLocationTransferDialog(location, operation = 'TRANSFER') {
  if (operation === 'EMPTY_AND_DELETE' && Number(location.activeAssetCount || 0) === 0) {
    if (!await askConfirm(`La ubicación ${location.name} está vacía. ¿Eliminarla?`, { title: 'Eliminar ubicación vacía', confirmText: 'Eliminar' })) return;
    await api(`/api/v1/config/locations/${location.id}`, { method: 'DELETE', body: JSON.stringify({ version: Number(location.version) }) });
    flash('Ubicación eliminada.'); await loadConfig(); return;
  }
  const destinationOptions = state.locations.locations.filter((item) => item.active && item.id !== location.id);
  if (!destinationOptions.length) throw new Error('Creá o activá otra ubicación para usarla como destino.');
  currentLocationTransferSelection = new Map();
  currentLocationTransferOverview = null;
  $('#location-transfer-source-id').value = location.id;
  $('#location-transfer-source-version').value = location.version;
  $('#location-transfer-operation').value = operation;
  $('#location-transfer-title').textContent = operation === 'EMPTY_AND_DELETE' ? 'Vaciar y eliminar' : 'Transferir bienes';
  $('#location-transfer-source').textContent = `Origen: ${location.name} · ${location.code}`;
  $('#location-transfer-destination').innerHTML = destinationOptions.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)} · ${escapeHtml(locationTypeLabel(item.type))} · ${escapeHtml(state.locations.sites.find((site) => site.id === item.site_id)?.name || '')}</option>`).join('');
  document.querySelector('input[name="location-transfer-choice"][value="AVAILABLE"]').checked = true;
  $('#location-transfer-search').value = '';
  $('#location-transfer-error').textContent = ''; $('#location-transfer-error').classList.add('hidden');
  $('#location-transfer-items').innerHTML = '<div class="empty-state">Elegí “Elegir algunos” para buscar bienes.</div>';
  renderTransferSelected();
  await refreshLocationTransferOverview({ includeItems: false });
  $('#location-transfer-dialog').showModal();
}

$('#location-transfer-destination')?.addEventListener('change', async () => {
  currentLocationTransferSelection.clear();
  try {
    await refreshLocationTransferOverview({ includeItems: locationTransferChoice() === 'SELECTED' });
  } catch (error) { flash(error.message, 'error'); }
});

document.querySelectorAll('input[name="location-transfer-choice"]').forEach((input) => input.addEventListener('change', async () => {
  try { await refreshLocationTransferOverview({ includeItems: input.value === 'SELECTED' }); }
  catch (error) { flash(error.message, 'error'); }
}));

$('#location-transfer-search')?.addEventListener('input', () => {
  clearTimeout(locationTransferSearchTimer);
  locationTransferSearchTimer = setTimeout(() => refreshLocationTransferOverview({ includeItems: true }).catch((error) => flash(error.message, 'error')), 220);
});

$('#location-transfer-items')?.addEventListener('change', (event) => {
  const input = event.target.closest('[data-transfer-result-id]'); if (!input) return;
  const item = (currentLocationTransferOverview?.items || []).find((row) => row.id === input.dataset.transferResultId);
  if (!item) return;
  if (input.checked) currentLocationTransferSelection.set(item.id, item); else currentLocationTransferSelection.delete(item.id);
  updateLocationTransferUi();
});

$('#location-transfer-selected-list')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-transfer-remove-id]'); if (!button) return;
  currentLocationTransferSelection.delete(button.dataset.transferRemoveId);
  const visible = $$('#location-transfer-items input[data-transfer-result-id]').find((input) => input.dataset.transferResultId === button.dataset.transferRemoveId); if (visible) visible.checked = false;
  updateLocationTransferUi();
});

$('#location-transfer-clear')?.addEventListener('click', () => {
  currentLocationTransferSelection.clear();
  $$('#location-transfer-items input[data-transfer-result-id]').forEach((input) => { input.checked = false; });
  updateLocationTransferUi();
});

$('#location-transfer-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const sourceId = $('#location-transfer-source-id').value;
  const version = Number($('#location-transfer-source-version').value);
  const destinationLocationId = $('#location-transfer-destination').value;
  const operation = $('#location-transfer-operation').value;
  const errorNode = $('#location-transfer-error'); errorNode.textContent = ''; errorNode.classList.add('hidden');
  try {
    let result;
    if (operation === 'EMPTY_AND_DELETE') {
      result = await api(`/api/v1/config/locations/${sourceId}/empty-and-delete`, { method: 'POST', body: JSON.stringify({ version, destinationLocationId }) });
      $('#location-transfer-dialog').close();
      if (result.deleted) flash(`Ubicación vaciada y eliminada. ${result.moved?.length || 0} bienes transferidos.`);
      else flash(`Se transfirieron ${result.moved?.length || 0} bienes. Quedan ${result.remainingCount || 0} ocupados o bloqueados; la ubicación sigue activa hasta resolverlos.`);
    } else {
      const mode = locationTransferChoice();
      const payload = { version, destinationLocationId, mode };
      if (mode === 'SELECTED') payload.assetIds = [...currentLocationTransferSelection.keys()];
      result = await api(`/api/v1/config/locations/${sourceId}/transfer-assets`, { method: 'POST', body: JSON.stringify(payload) });
      $('#location-transfer-dialog').close();
      flash(`${result.moved?.length || 0} bienes transferidos.`);
    }
    await loadConfig();
  } catch (error) {
    const blockers = Array.isArray(error.details?.blockers) ? error.details.blockers : [];
    errorNode.innerHTML = blockers.length
      ? `<strong>${escapeHtml(error.message)}</strong><div class="small">${blockers.slice(0, 6).map((item) => `${escapeHtml(item.internalCode || 'Bien')}: ${escapeHtml(item.message || item.code)}`).join('<br>')}</div>`
      : escapeHtml(error.message);
    errorNode.classList.remove('hidden');
    try { await refreshLocationTransferOverview({ includeItems: locationTransferChoice() === 'SELECTED' }); } catch {}
  }
});

$('#sites-body')?.addEventListener('click', async (event) => {
  const addButton = event.target.closest('[data-site-add-location-id]');
  if (addButton) { openNewLocationForSite(addButton.dataset.siteAddLocationId); return; }
  const deleteButton = event.target.closest('[data-site-delete-id]');
  if (deleteButton) {
    const site = state.locations.sites.find((item) => item.id === deleteButton.dataset.siteDeleteId); if (!site) return;
    if (!await askConfirm(`¿Eliminar la sede “${site.name}”? Las ubicaciones vacías se eliminarán con ella.`, { title: 'Eliminar sede', confirmText: 'Eliminar', danger: true })) return;
    try { await api(`/api/v1/config/sites/${site.id}`, { method: 'DELETE', body: JSON.stringify({ version: Number(site.version), reason: 'Eliminación desde Configuración' }) }); flash('Sede eliminada.'); await loadConfig(); }
    catch (error) { flash(error.message, 'error'); }
    return;
  }
  const button = event.target.closest('[data-site-edit-id]'); if (!button) return;
  const site = state.locations.sites.find((item) => item.id === button.dataset.siteEditId); if (!site) return;
  $('#site-edit-id').value = site.id; $('#site-edit-version').value = site.version;
  $('#site-edit-code').value = site.code || ''; $('#site-edit-name').value = site.name || ''; $('#site-edit-description').value = site.description || '';
  $('#site-edit-active').checked = Boolean(site.active); $('#site-edit-primary').checked = Boolean(site.is_primary);
  renderSiteCategoryOptions('#site-edit-category-options', [...siteEnabledCategoryIds(site.id)]);
  $('#site-edit-dialog').showModal();
});

$('#locations-body')?.addEventListener('click', async (event) => {
  const editButton = event.target.closest('[data-location-edit-id]');
  if (editButton) {
    const location = state.locations.locations.find((item) => item.id === editButton.dataset.locationEditId); if (!location) return;
    $('#location-edit-id').value = location.id; $('#location-edit-version').value = location.version;
    $('#location-edit-name').value = location.name || ''; $('#location-edit-type').value = String(location.type || 'OTRO').toUpperCase();
    $('#location-edit-dialog').showModal(); return;
  }
  const transferButton = event.target.closest('[data-location-transfer-id]');
  if (transferButton) {
    const location = state.locations.locations.find((item) => item.id === transferButton.dataset.locationTransferId); if (!location) return;
    try { await openLocationTransferDialog(location, 'TRANSFER'); } catch (error) { flash(error.message, 'error'); } return;
  }
  const emptyButton = event.target.closest('[data-location-empty-id]');
  if (emptyButton) {
    const location = state.locations.locations.find((item) => item.id === emptyButton.dataset.locationEmptyId); if (!location) return;
    try { await openLocationTransferDialog(location, 'EMPTY_AND_DELETE'); } catch (error) { flash(error.message, 'error'); } return;
  }
  const deleteButton = event.target.closest('[data-location-delete-id]');
  if (deleteButton) {
    const location = state.locations.locations.find((item) => item.id === deleteButton.dataset.locationDeleteId); if (!location) return;
    if (!await askConfirm(`¿Eliminar la ubicación “${location.name}”?`, { title: 'Eliminar ubicación', confirmText: 'Eliminar', danger: true })) return;
    try { await api(`/api/v1/config/locations/${location.id}`, { method: 'DELETE', body: JSON.stringify({ version: Number(location.version), reason: 'Eliminación desde Configuración' }) }); flash('Ubicación eliminada.'); await loadConfig(); }
    catch (error) { flash(error.message, 'error'); }
    return;
  }
  const reactivateButton = event.target.closest('[data-location-reactivate-id]');
  if (reactivateButton) {
    const location = state.locations.locations.find((item) => item.id === reactivateButton.dataset.locationReactivateId); if (!location) return;
    try {
      await api(`/api/v1/config/locations/${location.id}/reactivate`, { method: 'POST', body: JSON.stringify({ version: Number(reactivateButton.dataset.locationVersion) }) });
      flash('Ubicación reactivada.'); await loadConfig();
    } catch (error) { flash(error.message, 'error'); }
  }
});

$('#organization-logo')?.addEventListener('change', () => {
  $('#organization-logo-status').textContent = $('#organization-logo').files?.[0]?.name || 'Sin archivo seleccionado';
});
$('#user-photo')?.addEventListener('change', () => updateUserPhotoPreviewFromInput().catch(() => setUserPhotoPreview('')));
