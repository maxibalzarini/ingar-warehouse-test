'use strict';


let dashboardAutoRefreshTimer = null;
let dashboardRefreshInFlight = false;
const DASHBOARD_REFRESH_MS = 30_000;

let requestsAutoRefreshTimer = null;
let requestsRefreshInFlight = false;
const REQUESTS_REFRESH_MS = 5_000;

let notificationsAutoRefreshTimer = null;
let notificationsRefreshInFlight = false;
const NOTIFICATIONS_REFRESH_MS = 5_000;

let incidentAssetSearchTimer = null;
let incidentAssetSearchSequence = 0;
const INCIDENT_ASSET_SEARCH_DELAY_MS = 250;

function renderNotificationCount(items) {
  const count = (items || []).filter((item) => !item.read_at).length;
  const badge = $('#notifications-nav-count');
  if (!badge) return;
  badge.textContent = String(count);
  badge.hidden = count === 0;
}

async function refreshNotificationsBackground() {
  if (!state.user || !can('Notifications.Read') || notificationsRefreshInFlight || document.hidden) return;
  notificationsRefreshInFlight = true;
  try {
    const data = await api('/api/v1/notifications?limit=500&unread=true');
    renderNotificationCount(data.items);
    if (state.currentView === 'notifications') await loadNotifications();
  } catch (error) {
    if (error.status === 401) stopNotificationsAutoRefresh();
  } finally {
    notificationsRefreshInFlight = false;
  }
}

function startNotificationsAutoRefresh() {
  stopNotificationsAutoRefresh();
  if (!state.user || !can('Notifications.Read')) return;
  refreshNotificationsBackground().catch(() => {});
  notificationsAutoRefreshTimer = setInterval(() => refreshNotificationsBackground().catch(() => {}), NOTIFICATIONS_REFRESH_MS);
}

function stopNotificationsAutoRefresh() {
  if (notificationsAutoRefreshTimer) clearInterval(notificationsAutoRefreshTimer);
  notificationsAutoRefreshTimer = null;
}

// Registrado aca (primer archivo cargado) en vez de en 17-system-status.js para que
// capture errores de CUALQUIER modulo, incluidos los que se ejecutan antes de que el 17
// llegue a cargar. Reporta a /api/v1/logs/client -> visible en la pantalla "Logs" de la
// app, sin depender de las herramientas de desarrollador del navegador (no disponibles
// en el empaquetado de Electron).
async function reportClientError(message, details) {
  if (!state.user || !state.csrfToken) return;
  try { await api('/api/v1/logs/client', { method: 'POST', body: JSON.stringify({ level: 'ERROR', message, details }) }); } catch { /* el error ya no puede reportarse de forma segura */ }
}
window.addEventListener('error', (event) => reportClientError(event.message, { source: event.filename, line: event.lineno, column: event.colno }));
window.addEventListener('unhandledrejection', (event) => reportClientError('Unhandled promise rejection', { reason: String(event.reason) }));

const state = { currentView: 'dashboard', workbench: { requests: [], custodies: [], incidents: [], lanes: { prepare: [], deliver: [], receive: [], problems: [] }, loanedNow: { summary: { vehiclesOut: 0, toolsLoaned: 0, serializedOut: 0, dueToday: 0, overdue: 0, totalOut: 0 }, items: [], total: 0, timeZone: null }, seen: new Set(), loaded: false, error: null, generatedAt: null }, user: null, csrfToken: sessionStorage.getItem('iwc_csrf') || '', roles: [], permissions: [], users: [], supervisorCandidates: [], locations: { organizations: [], sites: [], locations: [] }, categories: [], assets: [], imports: [], requests: [], portalQrs: [], requestPolicies: [], custodies: [], transfers: [], custodyPeople: [], custodyIntegrityAnomalies: [], currentReturnCustody: null, currentAsset: null, currentImport: null, currentRequest: null, currentCustody: null, currentTransfer: null, importPageOffset: 0, incidents: [], blocks: [], exceptions: [], currentIncident: null, vehicles: [], kits: [], stockLots: [], inventoryCounts: [], inventoryTransfers: [], maintenancePlans: [], maintenanceOrders: [], notifications: [], schedulerJobs: [], resilience: null, dashboard: null, reportCatalog: null, currentReport: null, reportResult: null, reportPage: 1, reportExportInFlight: false, dashboardViewFilters: {}, stockMovements: [], managementModel: null, managementResult: null, managementDashboard: null, managementEntityType: 'PERSON', managementEntities: [], managementProfile: null, financeOptions: null, financeSummary: null, financeBudgets: [], financeCosts: [], financePurchases: [], financeConsumables: [], financeAssets: [], financeTab: 'summary', actionOptions: null, actions: [], myActions: [], overdueActions: [], meetings: [], weeklyAgenda: null, monthlyAgenda: null, actionsTab: 'actions', systemStatus: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];


const UI_CODE_LABELS = Object.freeze({
  DISPONIBLE: 'Disponible', BLOQUEADO: 'Bloqueado', MANTENIMIENTO: 'En mantenimiento', PERDIDO: 'Perdido', BAJA: 'Baja',
  SERIADO: 'Bien serializado', CANTIDAD: 'Por cantidad', CONSUMIBLE: 'Consumible', KIT: 'Kit', VEHICULO: 'Vehículo',
  CARGADA: 'Cargada', VALIDADA_CON_ERRORES: 'Validada con errores', VALIDADA: 'Validada', APLICADA: 'Aplicada', REVERTIDA: 'Revertida', FALLIDA: 'Fallida',
  PENDIENTE_AUTORIZACION: 'Por autorizar', APROBADA: 'Aprobada', BLOQUEADA: 'Bloqueada', CANCELADA: 'Cancelada', EXPIRADA: 'Expirada', PREPARANDO: 'En preparación', LISTA_PARA_ENTREGA: 'Lista para entregar', ENTREGADA: 'Entregada',
  ABIERTA: 'Fuera del pañol', DEVOLUCION_DECLARADA: 'Pendiente de recibir', RECEPCION_PENDIENTE: 'Recepción pendiente', TRANSFERENCIA_PENDIENTE: 'Transferencia pendiente', INCIDENTE: 'Con problema', CERRADA: 'Recibida',
  ABIERTO: 'Abierto', EN_INVESTIGACION: 'En investigación', RESUELTO: 'Resuelto', CERRADO: 'Cerrado',
  CRITICA: 'Crítica', ALTA: 'Alta', MEDIA: 'Media',
  DANO: 'Daño', FALTANTE: 'Faltante', CONDICION_INSEGURA: 'Condición insegura', PERDIDA: 'Pérdida', ROBO: 'Robo', INCUMPLIMIENTO: 'Incumplimiento', OTRO: 'Otro',
  ACTIVO: 'Activo', LEVANTADO: 'Levantado', EXPIRADO: 'Vencido', PERSONA: 'Persona', CATEGORIA: 'Categoría',
  ENTRADA: 'Entrada', SALIDA: 'Salida', CONSUMO: 'Consumo', DEVOLUCION: 'Devolución', RESERVA: 'Reserva', LIBERACION: 'Liberación',
  PLANIFICADO: 'Planificado', CONTEO: 'En conteo', CONCILIACION: 'En conciliación', BORRADOR: 'Borrador', EN_TRANSITO: 'En tránsito', RECIBIDA: 'Recibida',
  PROGRAMADA: 'Programada', VENCIDA: 'Vencida', EN_PROGRESO: 'En progreso', COMPLETADA: 'Completada',
  EXPLICITA: 'Explícita', PIN: 'PIN', FIRMA: 'Firma', VIGENTE: 'Vigente', VENCIDO: 'Vencido', ANULADO: 'Anulado',
  RETIRO: 'Retiro', TRANSFERENCIA: 'Transferencia',
  FOTO: 'Foto', DOCUMENTO: 'Documento', DENUNCIA: 'Denuncia', INFORME: 'Informe', ACTA: 'Acta',
  RECUPERADO_CONFORME: 'Recuperado conforme', RECUPERADO_BLOQUEADO: 'Recuperado y bloqueado', REPARACION_REQUERIDA: 'Requiere reparación', BAJA_DEFINITIVA: 'Baja definitiva', SIN_RECUPERACION: 'Sin recuperación', SIN_RESPONSABILIDAD: 'Sin responsabilidad', RESPONSABILIDAD_DETERMINADA: 'Responsabilidad determinada', OTRA: 'Otra',
  CONFORME: 'Conforme', OBSERVADO: 'Con observación', DANADO: 'Dañado', INCOMPLETO: 'Incompleto',
  TOTAL: 'Total', SEDE: 'Sede', UBICACION: 'Ubicación', OPERACION: 'Operación',
  INFO: 'Información', WARN: 'Advertencia', ERROR: 'Error',
  EJECUTADO: 'Ejecutado', REVERSADO: 'Reversado', COMPROMETIDA: 'Comprometida', PARCIAL: 'Parcial', VERIFICADO: 'Verificado', FALLIDO: 'Fallido',
  PENDIENTE: 'Pendiente', ACEPTADA: 'Aceptada', RECHAZADA: 'Rechazada', REQUIERE_REVISION: 'Requiere revisión', REPARADA: 'Reparada',
  ENTREGA: 'Entrega', RECEPCION: 'Recepción', VALIDADO: 'Validado', OBSERVACION: 'Con observación',
  FUERA_DE_TERMINO: 'Fuera de término', EN_TERMINO: 'En término', SIN_VENCIMIENTO: 'Sin vencimiento',
  VALORIZADO: 'Valorizado', SIN_PRECIO: 'Sin precio', SUCCESS: 'Correcto', FAILURE: 'Fallido',
  CREATE_OR_UPDATE: 'Alta o actualización', CREATE_ONLY: 'Solo altas', UPDATE_ONLY: 'Solo actualizaciones',
  ASSET: 'Bienes y herramientas', VEHICLE: 'Vehículos', AUTO: 'Automática', LANDSCAPE: 'Horizontal', PORTRAIT: 'Vertical'
});

function uiCodeLabel(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '';
  return UI_CODE_LABELS[raw.toUpperCase()] || raw;
}

