function percentClass(prefix, value) {
  const number = Number(value);
  const bounded = Number.isFinite(number) ? Math.max(0, Math.min(100, number)) : 0;
  return `f61-${prefix}-${Math.round(bounded * 10)}`;
}

function can(permission) {
  return Boolean(state.user && (state.user.permissions.includes('*') || state.user.permissions.includes(permission)));
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}

function friendlyApiErrorMessage(data, status) {
  const code = String(data?.code || '');
  const messages = {
    AUTH_REQUIRED: 'La sesión terminó. Volvé a ingresar.',
    CSRF_INVALID: 'La sesión cambió. Reintentá la acción.',
    CONCURRENCY_CONFLICT: 'La información cambió mientras trabajabas. Actualizá y volvé a intentar.',
    VERSION_CONFLICT: 'La información cambió mientras trabajabas. Actualizá y volvé a intentar.',
    SCOPE_FORBIDDEN: 'Este registro está fuera de tu ubicación o alcance asignado.',
    FORBIDDEN: 'Tu usuario no tiene permiso para realizar esta acción.'
  };
  if (messages[code]) return messages[code];
  const raw = typeof data?.message === 'string' ? data.message.trim() : '';
  if (raw && !/^(SQLITE_|Error:|TypeError:|ReferenceError:)/i.test(raw)) return raw;
  if (status === 401) return 'La sesión terminó. Volvé a ingresar.';
  if (status === 403) return 'Tu usuario no tiene permiso para realizar esta acción.';
  if (status >= 500) return 'No se pudo completar la operación. Reintentá; si continúa, revisá el Server.';
  return `No se pudo completar la operación (${status}).`;
}

async function api(path, options = {}) {
  const { _csrfRetried = false, ...requestOptions } = options;
  const headers = { Accept: 'application/json', ...(requestOptions.headers || {}) };
  if (requestOptions.body && !(requestOptions.body instanceof Blob)) headers['Content-Type'] = 'application/json';
  const unsafeRequest = !['GET', 'HEAD'].includes(requestOptions.method || 'GET');
  if (unsafeRequest && state.csrfToken) headers['X-CSRF-Token'] = state.csrfToken;
  const response = await fetch(path, { credentials: 'same-origin', ...requestOptions, headers });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.blob();
  if (!response.ok) {
    if (
      response.status === 403 &&
      data?.code === 'CSRF_INVALID' &&
      unsafeRequest &&
      !_csrfRetried &&
      path !== '/api/v1/auth/csrf'
    ) {
      const refreshed = await api('/api/v1/auth/csrf');
      if (refreshed.csrfToken) {
        state.csrfToken = refreshed.csrfToken;
        sessionStorage.setItem('iwc_csrf', state.csrfToken);
        return api(path, { ...requestOptions, _csrfRetried: true });
      }
    }
    if (response.status === 401) showLogin();
    const error = new Error(friendlyApiErrorMessage(data, response.status));
    error.code = data.code; error.status = response.status; error.fieldErrors = data.fieldErrors || []; error.details = data.details || null;
    throw error;
  }
  return data;
}

async function requestWorkflowApi(path, options = {}) {
  try {
    return await api(path, options);
  } catch (error) {
    if (error.code !== 'CSRF_INVALID') throw error;
    const refreshed = await api('/api/v1/auth/csrf');
    if (!refreshed.csrfToken) throw error;
    state.csrfToken = refreshed.csrfToken;
    sessionStorage.setItem('iwc_csrf', state.csrfToken);
    return api(path, options);
  }
}

function flash(message, type = 'ok') {
  const node = $('#flash');
  node.textContent = message;
  node.className = `flash ${type}`;
  clearTimeout(flash.timer);
  flash.timer = setTimeout(() => node.classList.add('hidden'), 5000);
}


let interactionResolver = null;

function closeInteraction(result) {
  const dialog = $('#ui-interaction-dialog');
  const resolver = interactionResolver;
  interactionResolver = null;
  if (dialog.open) dialog.close();
  if (resolver) resolver(result);
}

function openInteraction({
  title = 'Confirmar acción',
  message = '',
  fields = [],
  details = null,
  confirmText = 'Continuar',
  cancelText = 'Cancelar',
  showCancel = true,
  danger = false
} = {}) {
  const dialog = $('#ui-interaction-dialog');
  const form = $('#ui-interaction-form');
  $('#ui-interaction-title').textContent = title;
  $('#ui-interaction-message').textContent = message;
  const fieldsNode = $('#ui-interaction-fields');
  fieldsNode.innerHTML = fields.map((field) => {
    const required = field.required === false ? '' : ' required';
    const value = escapeHtml(field.value ?? '');
    const placeholder = field.placeholder ? ` placeholder="${escapeHtml(field.placeholder)}"` : '';
    const constraints = [
      field.min !== undefined ? ` min="${escapeHtml(field.min)}"` : '',
      field.max !== undefined ? ` max="${escapeHtml(field.max)}"` : '',
      field.step !== undefined ? ` step="${escapeHtml(field.step)}"` : '',
      field.minLength !== undefined ? ` minlength="${escapeHtml(field.minLength)}"` : '',
      field.maxLength !== undefined ? ` maxlength="${escapeHtml(field.maxLength)}"` : '',
      field.pattern ? ` pattern="${escapeHtml(field.pattern)}"` : '',
      field.autocomplete ? ` autocomplete="${escapeHtml(field.autocomplete)}"` : ''
    ].join('');
    if (field.type === 'select') {
      return `<label>${escapeHtml(field.label)}<select name="${escapeHtml(field.name)}"${required}>${(field.options || []).map((option) => {
        const item = typeof option === 'string' ? { value: option, label: option } : option;
        return `<option value="${escapeHtml(item.value)}" ${String(item.value) === String(field.value ?? '') ? 'selected' : ''}>${escapeHtml(item.label)}</option>`;
      }).join('')}</select></label>`;
    }
    if (field.type === 'textarea') return `<label>${escapeHtml(field.label)}<textarea name="${escapeHtml(field.name)}"${placeholder}${constraints}${required}>${value}</textarea></label>`;
    return `<label>${escapeHtml(field.label)}<input name="${escapeHtml(field.name)}" type="${escapeHtml(field.type || 'text')}" value="${value}"${placeholder}${constraints}${required}></label>`;
  }).join('');
  const detailsNode = $('#ui-interaction-details');
  if (details === null || details === undefined) {
    detailsNode.textContent = '';
    detailsNode.classList.add('hidden');
  } else {
    detailsNode.textContent = typeof details === 'string' ? details : JSON.stringify(details, null, 2);
    detailsNode.classList.remove('hidden');
  }
  const cancel = $('#ui-interaction-cancel');
  cancel.textContent = cancelText;
  cancel.hidden = !showCancel;
  const confirm = $('#ui-interaction-confirm');
  confirm.textContent = confirmText;
  confirm.classList.toggle('danger', danger);
  confirm.classList.toggle('primary', !danger);
  form.reset();
  return new Promise((resolve) => {
    interactionResolver = resolve;
    dialog.showModal();
    const first = fieldsNode.querySelector('input,select,textarea');
    if (first) setTimeout(() => first.focus(), 30);
  });
}

async function askConfirm(message, options = {}) {
  const result = await openInteraction({ message, ...options });
  return Boolean(result?.confirmed);
}

async function askFields(title, fields, options = {}) {
  const result = await openInteraction({ title, fields, ...options });
  return result?.confirmed ? result.values : null;
}

async function showNotice(title, message, details = null) {
  await openInteraction({ title, message, details, confirmText: 'Cerrar', showCancel: false });
}

async function showDetails(title, details) {
  await showNotice(title, 'Información registrada en el sistema.', details);
}


