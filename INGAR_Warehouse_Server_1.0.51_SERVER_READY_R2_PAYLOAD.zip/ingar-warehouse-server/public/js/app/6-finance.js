function financeMoney(value, currency) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
  return `${Number(value).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency || ''}`.trim();
}

function financeDate(value) {
  if (!value) return '—';
  return String(value).slice(0, 10).split('-').reverse().join('/');
}

function financeQueryParams() {
  const params = new URLSearchParams({
    dateFrom: $('#finance-date-from').value,
    dateTo: $('#finance-date-to').value,
    pageSize: '200'
  });
  if ($('#finance-site').value) params.set('siteId', $('#finance-site').value);
  if ($('#finance-location').value) params.set('locationId', $('#finance-location').value);
  if ($('#finance-sector').value) params.set('sector', $('#finance-sector').value);
  return params;
}

function populateFinanceLocations() {
  const siteId = $('#finance-site').value;
  const current = $('#finance-location').value;
  const items = (state.financeOptions?.locations || []).filter((item) => !siteId || item.site_id === siteId);
  $('#finance-location').innerHTML = `<option value="">Todas</option>${items.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  if (items.some((item) => item.id === current)) $('#finance-location').value = current;
}

function populateFinanceOptions() {
  const options = state.financeOptions || { sites: [], locations: [], sectors: [], currencies: [] };
  const selectedSite = $('#finance-site').value;
  $('#finance-site').innerHTML = `<option value="">Toda la organización</option>${options.sites.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  if (options.sites.some((item) => item.id === selectedSite)) $('#finance-site').value = selectedSite;
  $('#finance-sector').innerHTML = `<option value="">Todos</option>${options.sectors.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join('')}`;
  $('#finance-decision-currency').innerHTML = `<option value="">La registrada en el activo</option>${options.currencies.map((item) => `<option value="${escapeHtml(item.code)}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  $('#finance-valuation-method').textContent = options.valuationMethod || 'LOTE';
  populateFinanceLocations();
}

function renderFinanceSummary() {
  const data = state.financeSummary || { byCurrency: [], topCosts: [], sectorCosts: [], assetCosts: [] };
  $('#finance-status').textContent = `Actualizado ${new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`;
  $('#finance-status').className = 'status ok';
  $('#finance-currency-warning').textContent = data.message || 'Las monedas se muestran por separado.';
  const grid = $('#finance-summary-grid');
  grid.innerHTML = data.byCurrency.length ? data.byCurrency.map((item) => `<article class="finance-currency-card ${item.available < 0 ? 'danger' : item.utilizationPercent >= 80 ? 'warn' : 'ok'}">
    <header><strong>${escapeHtml(item.currency)}</strong><span>${item.utilizationPercent === null ? 'Sin presupuesto' : `${escapeHtml(item.utilizationPercent)} % utilizado`}</span></header>
    <dl><div><dt>Presupuesto</dt><dd>${financeMoney(item.approved, item.currency)}</dd></div><div><dt>Ejecutado</dt><dd>${financeMoney(item.executed, item.currency)}</dd></div><div><dt>Comprometido</dt><dd>${financeMoney(item.committed, item.currency)}</dd></div><div><dt>Disponible</dt><dd>${financeMoney(item.available, item.currency)}</dd></div></dl>
  </article>`).join('') : '<div class="dashboard-empty compact"><strong>Sin movimientos económicos.</strong><span>No hay presupuesto, costos ni compromisos para el período seleccionado.</span></div>';
  $('#finance-top-costs').innerHTML = data.topCosts.length ? data.topCosts.map((item) => `<tr><td>${escapeHtml(uiCodeLabel(item.cost_type))}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(item.amount, item.currency_code)}</td></tr>`).join('') : '<tr><td colspan="3">Sin costos ejecutados.</td></tr>';
  $('#finance-sector-costs').innerHTML = data.sectorCosts.length ? data.sectorCosts.map((item) => `<tr><td>${escapeHtml(item.sector)}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(item.amount, item.currency_code)}</td></tr>`).join('') : '<tr><td colspan="3">Sin costos por sector.</td></tr>';
  $('#finance-alerts').innerHTML = [
    { value: data.unclassifiedCount, label: 'Gastos sin clasificar', message: 'Registros sin presupuesto o sector.' },
    { value: data.consumptionsWithoutPrice, label: 'Consumos sin precio', message: 'No se utiliza cero como costo real.' }
  ].map((item) => `<article class="finance-alert ${item.value ? 'warn' : 'ok'}"><strong>${escapeHtml(item.value)}</strong><span>${escapeHtml(item.label)}</span><small>${escapeHtml(item.message)}</small></article>`).join('');
  $('#finance-assets-body').innerHTML = data.assetCosts.length ? data.assetCosts.map((item) => `<tr><td>${escapeHtml(item.internal_code)}</td><td>${escapeHtml(item.description)}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(item.amount, item.currency_code)}</td><td><button type="button" data-finance-analyze-asset="${escapeHtml(item.id)}">Analizar</button></td></tr>`).join('') : '<tr><td colspan="5">No hay costos vinculados con activos.</td></tr>';
}

function renderFinanceBudgets() {
  $('#finance-budgets-body').innerHTML = state.financeBudgets.length ? state.financeBudgets.map((item) => `<tr><td><strong>${escapeHtml(item.name)}</strong><div class="small">${escapeHtml(item.category)}</div></td><td>${escapeHtml(item.location_name || item.site_name || item.scope_type || 'Organización')}<div class="small">${escapeHtml(item.sector || item.cost_center || '')}</div></td><td>${financeDate(item.period_start)} al ${financeDate(item.period_end)}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(item.approved_amount, item.currency_code)}</td><td><span class="status ${item.status === 'ACTIVO' ? 'ok' : item.status === 'CERRADO' ? 'neutral' : 'warn'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${escapeHtml(item.version)}</td></tr>`).join('') : '<tr><td colspan="7">No hay presupuestos registrados.</td></tr>';
}

function renderFinanceCosts() {
  $('#finance-costs-body').innerHTML = state.financeCosts.length ? state.financeCosts.map((item) => `<tr><td>${financeDate(item.occurred_on)}</td><td><strong>${escapeHtml(item.description)}</strong><div class="small">${escapeHtml(item.provider || item.asset_code || item.document_reference || '')}</div></td><td>${escapeHtml(uiCodeLabel(item.cost_type))}</td><td>${escapeHtml(item.sector || 'Sin clasificar')}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(Number(item.sign || 1) * Number(item.amount || 0), item.currency_code)}</td><td><span class="status ${item.status === 'EJECUTADO' ? 'ok' : item.status === 'REVERSADO' ? 'neutral' : 'warn'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${can('Finance.RecordCost') && item.status === 'EJECUTADO' && item.entry_kind !== 'REVERSA' ? `<button type="button" data-finance-reverse-cost="${escapeHtml(item.id)}">Revertir</button>` : '—'}</td></tr>`).join('') : '<tr><td colspan="8">No hay costos registrados.</td></tr>';
}

function renderFinancePurchases() {
  $('#finance-purchases-body').innerHTML = state.financePurchases.length ? state.financePurchases.map((item) => `<tr><td><strong>${escapeHtml(item.concept)}</strong><div class="small">${financeDate(item.requested_at)}</div></td><td>${escapeHtml(item.provider || '—')}</td><td>${escapeHtml(item.currency_code)}</td><td>${financeMoney(item.estimated_amount, item.currency_code)}</td><td>${financeMoney(item.committed_amount, item.currency_code)}<div class="small">Pendiente: ${financeMoney(item.remaining_commitment, item.currency_code)}</div></td><td>${financeMoney(item.executed_amount, item.currency_code)}</td><td><span class="status ${item.status === 'RECIBIDA' || item.status === 'CERRADA' ? 'ok' : item.status === 'CANCELADA' ? 'neutral' : 'warn'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${can('Finance.Commit') && can('Finance.RecordCost') && ['COMPROMETIDA','PARCIAL','RECIBIDA'].includes(item.status) && Number(item.remaining_commitment || 0) > 0 ? `<button type="button" data-finance-execute-purchase="${escapeHtml(item.id)}">Registrar factura</button>` : '—'}</td></tr>`).join('') : '<tr><td colspan="8">No hay compras registradas.</td></tr>';
}

function renderFinanceConsumables() {
  $('#finance-consumables-body').innerHTML = state.financeConsumables.length ? state.financeConsumables.map((item) => `<tr><td>${financeDate(item.occurred_at)}</td><td><strong>${escapeHtml(item.internal_code)}</strong><div class="small">${escapeHtml(item.asset_description)}</div></td><td>${escapeHtml(item.lot_code)}</td><td>${escapeHtml(uiCodeLabel(item.reference_type || 'Sin referencia'))}</td><td>${Number(item.quantity).toLocaleString('es-AR')}</td><td>${escapeHtml(item.currency_code || '—')}</td><td>${item.consumed_cost === null ? '<strong>SIN PRECIO</strong>' : financeMoney(item.consumed_cost, item.currency_code)}</td><td><span class="status ${item.price_status === 'VALORIZADO' ? 'ok' : 'warn'}">${escapeHtml(uiCodeLabel(item.price_status))}</span><div class="small">${item.unit_cost === null ? '—' : financeMoney(item.unit_cost, item.currency_code)}</div></td></tr>`).join('') : '<tr><td colspan="8">No hay consumos en el período.</td></tr>';
}

function renderFinanceAssetSelect() {
  const current = $('#finance-decision-asset').value;
  $('#finance-decision-asset').innerHTML = `<option value="">Seleccionar</option>${state.financeAssets.map((asset) => `<option value="${escapeHtml(asset.id)}">${escapeHtml(asset.internal_code)} · ${escapeHtml(asset.description)}</option>`).join('')}`;
  if (state.financeAssets.some((asset) => asset.id === current)) $('#finance-decision-asset').value = current;
}

async function loadFinance() {
  if (!can('Finance.Read')) return;
  $('#finance-status').textContent = 'Consultando…';
  $('#finance-status').className = 'status neutral';
  if (!$('#finance-date-to').value) {
    const today = new Date();
    const from = new Date(today.getFullYear(), today.getMonth(), 1);
    $('#finance-date-from').value = from.toISOString().slice(0, 10);
    $('#finance-date-to').value = today.toISOString().slice(0, 10);
  }
  if (!state.financeOptions) {
    const [options, assets] = await Promise.all([
      api('/api/v1/finance/options'),
      api('/api/v1/assets?limit=500').catch(() => ({ items: [] }))
    ]);
    state.financeOptions = options;
    state.financeAssets = assets.items || [];
    populateFinanceOptions();
    renderFinanceAssetSelect();
  }
  const params = financeQueryParams();
  const [summary, budgets, costs, purchases, consumables] = await Promise.all([
    api(`/api/v1/finance/summary?${params}`),
    api(`/api/v1/finance/budgets?${params}`),
    api(`/api/v1/finance/costs?${params}`),
    api(`/api/v1/finance/purchases?${params}`),
    api(`/api/v1/finance/consumables?${params}`)
  ]);
  state.financeSummary = summary;
  state.financeBudgets = budgets.rows || [];
  state.financeCosts = costs.rows || [];
  state.financePurchases = purchases.rows || [];
  state.financeConsumables = consumables.rows || [];
  renderFinanceSummary();
  renderFinanceBudgets();
  renderFinanceCosts();
  renderFinancePurchases();
  renderFinanceConsumables();
}

function setFinanceTab(tab) {
  state.financeTab = tab;
  $$('[data-finance-tab]').forEach((button) => button.classList.toggle('active', button.dataset.financeTab === tab));
  $$('[data-finance-pane]').forEach((pane) => { const active = pane.dataset.financePane === tab; pane.classList.toggle('active', active); pane.hidden = !active; });
}

function financeLocationOptions(siteId, includeAll = true) {
  const options = (state.financeOptions?.locations || []).filter((item) => !siteId || item.site_id === siteId).map((item) => ({ value: item.id, label: `${item.code} · ${item.name}` }));
  return includeAll ? [{ value: '', label: 'Sin ubicación específica' }, ...options] : options;
}

async function createFinanceBudgetUi() {
  const options = state.financeOptions;
  const values = await askFields('Nuevo presupuesto', [
    { name: 'name', label: 'Nombre del presupuesto' },
    { name: 'category', label: 'Categoría', value: 'OPERACION' },
    { name: 'siteId', label: 'Sede', type: 'select', value: $('#finance-site').value, options: [{ value: '', label: options.allowGlobal ? 'Toda la organización' : 'Seleccionar sede' }, ...options.sites.map((item) => ({ value: item.id, label: `${item.code} · ${item.name}` }))] },
    { name: 'sector', label: 'Sector (opcional)', required: false, value: $('#finance-sector').value },
    { name: 'periodStart', label: 'Fecha inicial', type: 'date', value: $('#finance-date-from').value },
    { name: 'periodEnd', label: 'Fecha final', type: 'date', value: $('#finance-date-to').value },
    { name: 'currency', label: 'Moneda', type: 'select', value: options.currencies.some((item) => item.code === options.defaultCurrency) ? options.defaultCurrency : (options.currencies[0]?.code || ''), options: options.currencies.map((item) => ({ value: item.code, label: `${item.code} · ${item.name}` })) },
    { name: 'approvedAmount', label: 'Importe aprobado', type: 'number', value: '0' },
    { name: 'status', label: 'Estado', type: 'select', options: can('Finance.ApproveBudget') ? ['BORRADOR','ACTIVO'] : ['BORRADOR'] },
    { name: 'observations', label: 'Observaciones', type: 'textarea', required: false }
  ], { message: 'No se mezclarán monedas ni se borrarán correcciones.', confirmText: 'Crear presupuesto' });
  if (!values) return;
  await api('/api/v1/finance/budgets', { method: 'POST', body: JSON.stringify({ ...values, approvedAmount: Number(values.approvedAmount), siteId: values.siteId || null, sector: values.sector || null }) });
  flash('Presupuesto creado.'); await loadFinance(); setFinanceTab('budgets');
}

async function createFinanceCostUi() {
  const options = state.financeOptions;
  const activeBudgets = state.financeBudgets.filter((item) => item.status === 'ACTIVO');
  const values = await askFields('Registrar costo', [
    { name: 'description', label: 'Qué se pagó' },
    { name: 'costType', label: 'Tipo de costo', type: 'select', options: options.costTypes },
    { name: 'siteId', label: 'Sede', type: 'select', value: $('#finance-site').value || options.sites[0]?.id || '', options: options.sites.map((item) => ({ value: item.id, label: `${item.code} · ${item.name}` })) },
    { name: 'sector', label: 'Sector (opcional)', required: false, value: $('#finance-sector').value },
    { name: 'occurredOn', label: 'Fecha', type: 'date', value: new Date().toISOString().slice(0, 10) },
    { name: 'currency', label: 'Moneda', type: 'select', value: options.currencies.some((item) => item.code === options.defaultCurrency) ? options.defaultCurrency : (options.currencies[0]?.code || ''), options: options.currencies.map((item) => ({ value: item.code, label: `${item.code} · ${item.name}` })) },
    { name: 'amount', label: 'Importe', type: 'number', value: '0' },
    { name: 'budgetId', label: 'Presupuesto (opcional)', type: 'select', required: false, options: [{ value: '', label: 'Sin presupuesto relacionado' }, ...activeBudgets.map((item) => ({ value: item.id, label: `${item.name} · ${item.currency_code}` }))] },
    { name: 'provider', label: 'Proveedor (opcional)', required: false },
    { name: 'documentReference', label: 'Factura o referencia (opcional)', required: false }
  ], { message: 'El importe debe ser positivo. Las correcciones se realizan por reversión.', confirmText: 'Registrar costo' });
  if (!values) return;
  await api('/api/v1/finance/costs', { method: 'POST', body: JSON.stringify({ ...values, amount: Number(values.amount), budgetId: values.budgetId || null, sector: values.sector || null }) });
  flash('Costo registrado.'); await loadFinance(); setFinanceTab('costs');
}

async function createFinancePurchaseUi() {
  const options = state.financeOptions;
  const activeBudgets = state.financeBudgets.filter((item) => item.status === 'ACTIVO');
  const values = await askFields('Nueva compra o compromiso', [
    { name: 'concept', label: 'Qué se necesita comprar' },
    { name: 'provider', label: 'Proveedor (opcional)', required: false },
    { name: 'siteId', label: 'Sede', type: 'select', value: $('#finance-site').value || options.sites[0]?.id || '', options: options.sites.map((item) => ({ value: item.id, label: `${item.code} · ${item.name}` })) },
    { name: 'sector', label: 'Sector (opcional)', required: false, value: $('#finance-sector').value },
    { name: 'requestedAt', label: 'Fecha', type: 'date', value: new Date().toISOString().slice(0, 10) },
    { name: 'currency', label: 'Moneda', type: 'select', value: options.currencies.some((item) => item.code === options.defaultCurrency) ? options.defaultCurrency : (options.currencies[0]?.code || ''), options: options.currencies.map((item) => ({ value: item.code, label: `${item.code} · ${item.name}` })) },
    { name: 'estimatedAmount', label: 'Importe estimado', type: 'number', value: '0' },
    { name: 'committedAmount', label: 'Importe comprometido', type: 'number', value: '0' },
    { name: 'budgetId', label: 'Presupuesto (opcional)', type: 'select', required: false, options: [{ value: '', label: 'Sin presupuesto relacionado' }, ...activeBudgets.map((item) => ({ value: item.id, label: `${item.name} · ${item.currency_code}` }))] },
    { name: 'status', label: 'Estado', type: 'select', options: ['BORRADOR','SOLICITADA','COMPROMETIDA'] },
    { name: 'documentReference', label: 'Orden o referencia (opcional)', required: false }
  ], { message: 'El gasto ejecutado se descontará del compromiso pendiente.', confirmText: 'Crear compra' });
  if (!values) return;
  await api('/api/v1/finance/purchases', { method: 'POST', body: JSON.stringify({ ...values, estimatedAmount: Number(values.estimatedAmount), committedAmount: Number(values.committedAmount), budgetId: values.budgetId || null, sector: values.sector || null }) });
  flash('Compra registrada.'); await loadFinance(); setFinanceTab('purchases');
}

async function reverseFinanceCostUi(id) {
  const values = await askFields('Revertir costo', [{ name: 'reason', label: 'Motivo obligatorio', type: 'textarea' }, { name: 'occurredOn', label: 'Fecha de reversión', type: 'date', value: new Date().toISOString().slice(0, 10) }], { message: 'El registro original permanecerá visible y auditado.', confirmText: 'Crear reversión', danger: true });
  if (!values) return;
  await api(`/api/v1/finance/costs/${encodeURIComponent(id)}/reverse`, { method: 'POST', body: JSON.stringify(values) });
  flash('Reversión registrada.'); await loadFinance(); setFinanceTab('costs');
}

async function executeFinancePurchaseUi(id) {
  const purchase = state.financePurchases.find((item) => item.id === id);
  if (!purchase) return;
  const values = await askFields('Registrar gasto de la compra', [
    { name: 'amount', label: `Importe a ejecutar (${purchase.currency_code})`, type: 'number', value: String(purchase.remaining_commitment || 0) },
    { name: 'occurredOn', label: 'Fecha', type: 'date', value: new Date().toISOString().slice(0, 10) },
    { name: 'description', label: 'Descripción', value: purchase.concept },
    { name: 'documentReference', label: 'Factura o referencia (opcional)', required: false, value: purchase.document_reference || '' }
  ], { message: `Compromiso pendiente: ${financeMoney(purchase.remaining_commitment, purchase.currency_code)}.`, confirmText: 'Registrar gasto' });
  if (!values) return;
  await api(`/api/v1/finance/purchases/${encodeURIComponent(id)}/execute`, { method: 'POST', body: JSON.stringify({ ...values, amount: Number(values.amount) }) });
  flash('Gasto ejecutado sin duplicar el compromiso.'); await loadFinance(); setFinanceTab('purchases');
}

async function analyzeFinanceAsset(assetId = null) {
  const id = assetId || $('#finance-decision-asset').value;
  if (!id) throw new Error('Seleccioná un activo.');
  $('#finance-decision-asset').value = id;
  const params = new URLSearchParams();
  if ($('#finance-decision-repair').value !== '') params.set('estimatedRepairAmount', $('#finance-decision-repair').value);
  if ($('#finance-decision-currency').value) params.set('currency', $('#finance-decision-currency').value);
  if ($('#finance-decision-available').value !== '') params.set('replacementAvailable', $('#finance-decision-available').value);
  const data = await api(`/api/v1/finance/assets/${encodeURIComponent(id)}/repair-replace?${params}`);
  const tone = data.recommendation === 'EVALUAR REEMPLAZO' ? 'danger' : data.recommendation === 'REVISAR ANTES DE DECIDIR' ? 'warn' : data.recommendation === 'REPARAR PARECE CONVENIENTE' ? 'ok' : 'neutral';
  const available = Object.entries(data.dataAvailable || {}).map(([key, value]) => `<div><dt>${escapeHtml(key)}</dt><dd>${value === null ? 'Sin dato' : escapeHtml(value)}</dd></div>`).join('');
  $('#finance-decision-result').innerHTML = `<article class="finance-decision-card ${tone}"><span class="dashboard-kicker">RECOMENDACIÓN ORIENTATIVA</span><h3>${escapeHtml(data.recommendation)}</h3><p>${escapeHtml(data.notice)}</p><div class="finance-decision-ratio"><strong>${data.economicRatio === null ? '—' : `${Number(data.economicRatio * 100).toLocaleString('es-AR')} %`}</strong><span>reparación y acumulado / reposición</span></div><dl>${available}</dl><h4>Datos faltantes</h4><p>${data.missingData.length ? escapeHtml(data.missingData.join(' · ')) : 'Ninguno para el criterio económico configurado.'}</p><small>Decide: ${escapeHtml(data.responsibleToDecide)}</small></article>`;
  setFinanceTab('decision');
}

$$('[data-finance-tab]').forEach((button) => button.addEventListener('click', () => setFinanceTab(button.dataset.financeTab)));
$('#finance-filter-form').addEventListener('submit', (event) => { event.preventDefault(); loadFinance().catch((error) => flash(error.message, 'error')); });
$('#finance-site').addEventListener('change', () => { populateFinanceLocations(); $('#finance-location').value = ''; loadFinance().catch((error) => flash(error.message, 'error')); });
$('#finance-location').addEventListener('change', () => loadFinance().catch((error) => flash(error.message, 'error')));
$('#finance-sector').addEventListener('change', () => loadFinance().catch((error) => flash(error.message, 'error')));
$('#finance-add-budget').addEventListener('click', () => createFinanceBudgetUi().catch((error) => flash(error.message, 'error')));
$('#finance-add-cost').addEventListener('click', () => createFinanceCostUi().catch((error) => flash(error.message, 'error')));
$('#finance-add-purchase').addEventListener('click', () => createFinancePurchaseUi().catch((error) => flash(error.message, 'error')));
$('#finance-costs-body').addEventListener('click', (event) => { const button = event.target.closest('[data-finance-reverse-cost]'); if (button) reverseFinanceCostUi(button.dataset.financeReverseCost).catch((error) => flash(error.message, 'error')); });
$('#finance-purchases-body').addEventListener('click', (event) => { const button = event.target.closest('[data-finance-execute-purchase]'); if (button) executeFinancePurchaseUi(button.dataset.financeExecutePurchase).catch((error) => flash(error.message, 'error')); });
$('#finance-assets-body').addEventListener('click', (event) => { const button = event.target.closest('[data-finance-analyze-asset]'); if (button) analyzeFinanceAsset(button.dataset.financeAnalyzeAsset).catch((error) => flash(error.message, 'error')); });
$('#finance-decision-form').addEventListener('submit', (event) => { event.preventDefault(); analyzeFinanceAsset().catch((error) => flash(error.message, 'error')); });


