function populateReportLocationFilter() {
  const siteId = $('#report-site').value;
  const locations = (state.reportFilterOptions?.locations || []).filter((item) => !siteId || item.site_id === siteId);
  const current = $('#report-location').value;
  $('#report-location').innerHTML = `<option value="">Todas</option>${locations.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  if (locations.some((item) => item.id === current)) $('#report-location').value = current;
}

function prepareReportFilters() {
  const options = state.reportCatalog?.options || { sites: [], locations: [], categories: [] };
  state.reportFilterOptions = options;
  $('#report-site').innerHTML = `<option value="">Todas</option>${options.sites.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  $('#report-asset-category').innerHTML = `<option value="">Todas</option>${options.categories.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  populateReportLocationFilter();
}

function renderReportCatalog() {
  const list = $('#report-catalog-list');
  const reports = state.reportCatalog?.reports || [];
  $('#report-catalog-count').textContent = `${reports.length} disponibles`;
  if (!reports.length) {
    list.innerHTML = '<div class="dashboard-empty"><strong>Sin informes disponibles.</strong><span>El rol actual no posee acceso a fuentes habilitadas para informes.</span></div>';
    return;
  }
  list.innerHTML = (state.reportCatalog.categories || []).map((category) => {
    const categoryReports = reports.filter((report) => report.category === category.code);
    if (!categoryReports.length) return '';
    return `<section class="report-category-group" data-report-category="${escapeHtml(category.code)}"><h4>${escapeHtml(category.name)}</h4><p>${escapeHtml(category.description)}</p>${categoryReports.map((report) => `<button type="button" role="listitem" class="report-catalog-item ${state.currentReport?.code === report.code ? 'active' : ''}" data-report-code="${escapeHtml(report.code)}"><svg class="ui-icon"><use href="/assets/icons.svg#icon-report"></use></svg><span><strong>${escapeHtml(report.name)}</strong><small>${escapeHtml(report.description)}</small></span></button>`).join('')}</section>`;
  }).join('');
}

function selectReport(code) {
  const report = state.reportCatalog?.reports?.find((item) => item.code === code);
  if (!report) return;
  state.currentReport = report;
  state.reportResult = null;
  state.reportPage = 1;
  $('#report-category').textContent = reportCategoryName(report.category).toUpperCase();
  $('#report-name').textContent = report.name;
  $('#report-description').textContent = report.description;
  $('#report-execution-status').textContent = 'Preparado';
  $('#report-execution-status').className = 'status neutral';
  const filters = reportFilterKeys();
  $$('[data-report-filter]').forEach((label) => { label.hidden = !filters.has(label.dataset.reportFilter); });
  $('#report-preview-head').innerHTML = report.columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join('');
  $('#report-preview-body').innerHTML = `<tr><td colspan="${Math.max(1, report.columns.length)}">Aplicá filtros y generá la vista previa.</td></tr>`;
  $('#report-preview-meta').textContent = 'Todavía no se ejecutó el informe seleccionado.';
  $('#report-applied-filters').textContent = 'Sin filtros aplicados.';
  $('#report-page-label').textContent = 'Página 1 de 1';
  $('#report-prev').disabled = true;
  $('#report-next').disabled = true;
  $('#report-management-card').hidden = true;
  $('#report-chart').innerHTML = '';
  $('#report-summary-grid').innerHTML = '';
  $('#report-page-size').value = report.category === 'GESTION' ? '100' : '25';
  renderReportCatalog();
}

function reportFilterPayload() {
  const keys = reportFilterKeys();
  const values = {
    dateFrom: $('#report-date-from').value,
    dateTo: $('#report-date-to').value,
    siteId: $('#report-site').value,
    locationId: $('#report-location').value,
    categoryId: $('#report-asset-category').value,
    status: $('#report-status-filter').value,
    search: $('#report-search').value
  };
  return Object.fromEntries(Object.entries(values).filter(([key, value]) => keys.has(key) && String(value || '').trim()));
}

function reportStatusClass(value) {
  const text = String(value || '').toUpperCase();
  if (['SUCCESS','CONFORME','DISPONIBLE','CERRADA','COMPLETADA','RESUELTO','EN_TERMINO'].includes(text)) return 'ok';
  if (['FAILED','CRITICA','BLOQUEADO','VENCIDA','INCIDENTE','DANADO','INCOMPLETO','FUERA_DE_TERMINO'].includes(text)) return 'danger';
  if (['ALTA','PENDIENTE_AUTORIZACION','EN_INVESTIGACION','OBSERVADO','SIN_VENCIMIENTO'].includes(text)) return 'warn';
  return 'neutral';
}

function formatReportValue(column, value) {
  if (value === null || value === undefined || value === '') return '—';
  if (column.type === 'datetime') return escapeHtml(formatDateTime(value));
  if (column.type === 'boolean') return value ? '<span class="status danger">Sí</span>' : '<span class="status ok">No</span>';
  if (column.type === 'status') return `<span class="status ${reportStatusClass(value)}">${escapeHtml(value)}</span>`;
  if (column.type === 'number') return escapeHtml(new Intl.NumberFormat('es-AR', { maximumFractionDigits: 2 }).format(Number(value)));
  if (column.type === 'code') return `<code class="report-code-value">${escapeHtml(value)}</code>`;
  return escapeHtml(value);
}


function managementNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function managementAggregate(rows, definition) {
  const values = rows.map((row) => managementNumber(row[definition.key]));
  if (!values.length) return 0;
  if (definition.aggregate === 'average') return values.reduce((sum, value) => sum + value, 0) / values.length;
  if (definition.aggregate === 'max') return Math.max(...values);
  return values.reduce((sum, value) => sum + value, 0);
}

function managementMetricText(value) {
  return new Intl.NumberFormat('es-AR', { maximumFractionDigits: 2 }).format(managementNumber(value));
}

function highlightReportRow(index) {
  $$('#report-preview-body tr').forEach((row) => row.classList.toggle('report-row-linked', Number(row.dataset.reportRowIndex) === Number(index)));
  const selected = $(`#report-preview-body tr[data-report-row-index="${Number(index)}"]`);
  selected?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function renderReportSummary(report, rows) {
  const grid = $('#report-summary-grid');
  const definitions = report.summary || [];
  grid.innerHTML = definitions.map((definition) => `<div class="report-summary-item"><span>${escapeHtml(definition.label)}</span><strong>${escapeHtml(managementMetricText(managementAggregate(rows, definition)))}</strong></div>`).join('');
}

function renderReportBarChart(report, rows) {
  const chart = report.chart;
  const series = chart.series?.[0];
  const limited = rows.slice(0, Math.min(Number(chart.limit) || 15, 25));
  const max = Math.max(1, ...limited.map((row) => managementNumber(row[series.key])));
  return `<div class="report-bar-chart">${limited.map((row, index) => {
    const value = managementNumber(row[series.key]);
    const label = row[chart.categoryKey] ?? 'Sin categoría';
    return `<button type="button" class="report-bar-row" data-report-row-index="${index}" title="${escapeHtml(`${label}: ${managementMetricText(value)}`)}"><span class="report-bar-label">${escapeHtml(label)}</span><span class="report-bar-track"><span class="report-bar-fill ${percentClass('w', Math.max(1.5, value / max * 100))}"></span></span><span class="report-bar-value">${escapeHtml(managementMetricText(value))}</span></button>`;
  }).join('')}</div>`;
}

function renderReportLineChart(report, rows) {
  const chart = report.chart;
  const series = (chart.series || []).slice(0, 4);
  const limited = rows.slice(0, Math.min(Number(chart.limit) || 36, 60));
  const width = 820; const height = 270; const left = 48; const right = 18; const top = 18; const bottom = 45;
  const plotWidth = width - left - right; const plotHeight = height - top - bottom;
  const max = Math.max(1, ...limited.flatMap((row) => series.map((item) => managementNumber(row[item.key]))));
  const x = (index) => left + (limited.length <= 1 ? plotWidth / 2 : index * plotWidth / (limited.length - 1));
  const y = (value) => top + plotHeight - managementNumber(value) / max * plotHeight;
  const grids = Array.from({ length: 5 }, (_, index) => {
    const value = max * (4 - index) / 4;
    const py = top + plotHeight * index / 4;
    return `<line class="report-chart-grid" x1="${left}" y1="${py}" x2="${left + plotWidth}" y2="${py}"></line><text class="report-chart-label" x="${left - 7}" y="${py + 3}" text-anchor="end">${escapeHtml(managementMetricText(value))}</text>`;
  }).join('');
  const labelStep = Math.max(1, Math.ceil(limited.length / 8));
  const labels = limited.map((row, index) => index % labelStep === 0 || index === limited.length - 1 ? `<text class="report-chart-label" x="${x(index)}" y="${height - 18}" text-anchor="middle">${escapeHtml(row[chart.categoryKey] ?? '')}</text>` : '').join('');
  const paths = series.map((item, seriesIndex) => {
    const points = limited.map((row, index) => `${x(index)},${y(row[item.key])}`).join(' ');
    const circles = limited.map((row, index) => `<circle class="report-chart-point series-${seriesIndex}" cx="${x(index)}" cy="${y(row[item.key])}" r="4" tabindex="0" data-report-row-index="${index}"><title>${escapeHtml(`${row[chart.categoryKey] ?? ''} · ${item.label}: ${managementMetricText(row[item.key])}`)}</title></circle>`).join('');
    return `<polyline class="report-chart-line series-${seriesIndex}" points="${points}"></polyline>${circles}`;
  }).join('');
  return `<div class="report-line-chart"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(chart.title || report.name)}">${grids}<line class="report-chart-axis" x1="${left}" y1="${top + plotHeight}" x2="${left + plotWidth}" y2="${top + plotHeight}"></line>${labels}${paths}</svg></div>`;
}

function renderReportManagement(report, rows) {
  const card = $('#report-management-card');
  if (!report?.chart) {
    card.hidden = true;
    return;
  }
  card.hidden = false;
  $('#report-chart-title').textContent = report.chart.title || report.name;
  $('#report-chart-description').textContent = `Gráfico vinculado con ${rows.length} fila(s) visibles de la vista previa. Seleccioná una barra o punto para ubicar el detalle.`;
  const detail = $('#report-open-detail');
  detail.hidden = !report.detailView;
  detail.dataset.reportDetailView = report.detailView || '';
  renderReportSummary(report, rows);
  $('#report-chart').innerHTML = rows.length ? (report.chart.type === 'line' ? renderReportLineChart(report, rows) : renderReportBarChart(report, rows)) : '<div class="report-chart-empty">No hay datos para representar con los filtros seleccionados.</div>';
  $('#report-chart-legend').innerHTML = (report.chart.series || []).map((item) => `<span class="report-chart-legend-item"><span class="report-chart-legend-swatch"></span>${escapeHtml(item.label)}</span>`).join('');
}

function renderReportResult(result) {
  const columns = result.report.columns || [];
  const rows = result.rows || [];
  $('#report-preview-head').innerHTML = columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join('');
  $('#report-preview-body').innerHTML = rows.length ? rows.map((row, index) => `<tr data-report-row-index="${index}">${columns.map((column) => `<td>${formatReportValue(column, row[column.key])}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${Math.max(1, columns.length)}">No hay registros para los filtros seleccionados.</td></tr>`;
  const pagination = result.pagination;
  $('#report-preview-meta').textContent = `${pagination.total} registro(s) · ejecución ${result.executionId.slice(0, 8)} · ${formatDateTime(result.generatedAt)}`;
  $('#report-page-label').textContent = `Página ${pagination.page} de ${pagination.pages}`;
  $('#report-prev').disabled = pagination.page <= 1;
  $('#report-next').disabled = pagination.page >= pagination.pages;
  const filterEntries = Object.entries(result.filters || {});
  const filterLabels = Object.fromEntries((state.currentReport?.filters || []).map((filter) => [filter.key, filter.label]));
  $('#report-applied-filters').textContent = filterEntries.length ? `Filtros aplicados: ${filterEntries.map(([key, value]) => `${filterLabels[key] || key}=${value}`).join(' · ')}` : 'Sin filtros aplicados.';
  $('#report-execution-status').textContent = 'Generado';
  $('#report-execution-status').className = 'status ok';
  renderReportManagement(result.report, rows);
}

async function generateReportPreview(page = 1) {
  if (!state.currentReport) throw new Error('Seleccioná un informe del catálogo.');
  $('#report-execution-status').textContent = 'Generando…';
  $('#report-execution-status').className = 'status neutral';
  const result = await api(`/api/v1/reports/${encodeURIComponent(state.currentReport.code)}/preview`, {
    method: 'POST',
    body: JSON.stringify({ filters: reportFilterPayload(), page, pageSize: Number($('#report-page-size').value) || 25 })
  });
  state.reportResult = result;
  state.reportPage = result.pagination.page;
  renderReportResult(result);
}

async function loadReports() {
  const catalog = await api('/api/v1/reports/catalog');
  state.reportCatalog = catalog;
  prepareReportFilters();
  if (!state.currentReport || !catalog.reports.some((report) => report.code === state.currentReport.code)) {
    state.currentReport = null;
    if (catalog.reports.length) selectReport(catalog.reports[0].code);
    else renderReportCatalog();
  } else {
    const code = state.currentReport.code;
    state.currentReport = catalog.reports.find((report) => report.code === code);
    selectReport(code);
  }
}

$('#report-catalog-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-report-code]');
  if (button) selectReport(button.dataset.reportCode);
});
$('#report-filter-form').addEventListener('submit', (event) => {
  event.preventDefault();
  generateReportPreview(1).catch((error) => { $('#report-execution-status').textContent = 'Error'; $('#report-execution-status').className = 'status danger'; flash(error.message, 'error'); });
});
$('#report-site').addEventListener('change', populateReportLocationFilter);
$('#report-prev').addEventListener('click', () => generateReportPreview(Math.max(1, state.reportPage - 1)).catch((error) => flash(error.message, 'error')));
$('#report-next').addEventListener('click', () => generateReportPreview(state.reportPage + 1).catch((error) => flash(error.message, 'error')));

$('#report-chart').addEventListener('click', (event) => {
  const target = event.target.closest('[data-report-row-index]');
  if (target) highlightReportRow(target.dataset.reportRowIndex);
});
$('#report-chart').addEventListener('keydown', (event) => {
  if (!['Enter', ' '].includes(event.key)) return;
  const target = event.target.closest('[data-report-row-index]');
  if (target) { event.preventDefault(); highlightReportRow(target.dataset.reportRowIndex); }
});
$('#report-open-detail').addEventListener('click', () => {
  const view = $('#report-open-detail').dataset.reportDetailView;
  if (view) setView(view);
});

function filenameFromDisposition(value, fallback) {
  const utf = String(value || '').match(/filename\*=UTF-8''([^;]+)/i);
  if (utf) { try { return decodeURIComponent(utf[1]); } catch {} }
  const basic = String(value || '').match(/filename="?([^";]+)"?/i);
  return basic?.[1] || fallback;
}

async function exportCurrentReport(format) {
  if (!state.currentReport) throw new Error('Seleccioná un informe del catálogo.');
  if (state.reportExportInFlight) return;
  state.reportExportInFlight = true;
  const buttons = $$('[data-report-export]');
  buttons.forEach((button) => { button.disabled = true; });
  $('#report-execution-status').textContent = `Exportando ${format}…`;
  $('#report-execution-status').className = 'status neutral';
  try {
    const response = await fetch(`/api/v1/reports/${encodeURIComponent(state.currentReport.code)}/export/${encodeURIComponent(format)}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': state.csrfToken, Accept: '*/*' },
      body: JSON.stringify({ filters: reportFilterPayload(), options: { orientation: $('#report-pdf-orientation').value } })
    });
    if (!response.ok) {
      const contentType = response.headers.get('content-type') || '';
      const detail = contentType.includes('application/json') ? await response.json() : { message: `Error HTTP ${response.status}` };
      const error = new Error(detail.message || `No fue posible exportar ${format}.`);
      error.code = detail.code; error.status = response.status; throw error;
    }
    const blob = await response.blob();
    const extension = format === 'XLSX' ? 'xlsx' : format.toLowerCase();
    const fallback = `ingar-${state.currentReport.code.toLowerCase()}-${new Date().toISOString().slice(0, 10)}.${extension}`;
    const filename = filenameFromDisposition(response.headers.get('content-disposition'), fallback);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    const rows = response.headers.get('x-report-row-count') || '0';
    $('#report-execution-status').textContent = `${format} · ${rows} filas`;
    $('#report-execution-status').className = 'status ok';
    flash(`${filename} generado.`);
  } finally {
    state.reportExportInFlight = false;
    buttons.forEach((button) => { button.disabled = false; });
  }
}

$$('[data-report-export]').forEach((button) => button.addEventListener('click', () => exportCurrentReport(button.dataset.reportExport).catch((error) => {
  $('#report-execution-status').textContent = 'Error de exportación';
  $('#report-execution-status').className = 'status danger';
  flash(error.message, 'error');
})));
$('#report-print-preview').addEventListener('click', () => window.print());

