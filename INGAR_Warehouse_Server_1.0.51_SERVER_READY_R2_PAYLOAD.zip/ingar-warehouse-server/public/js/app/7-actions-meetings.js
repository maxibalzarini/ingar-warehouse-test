function actionScopeParams(extra = {}) {
  const params = new URLSearchParams();
  if ($('#management-date-from')?.value) params.set('dateFrom', $('#management-date-from').value);
  if ($('#management-date-to')?.value) params.set('dateTo', $('#management-date-to').value);
  if ($('#management-site')?.value) params.set('siteId', $('#management-site').value);
  if ($('#management-location')?.value) params.set('locationId', $('#management-location').value);
  for (const [key, value] of Object.entries(extra)) if (value !== null && value !== undefined && value !== '') params.set(key, value);
  return params;
}

function actionStatusText(value) {
  return String(value || 'PENDIENTE').replaceAll('_', ' ');
}

function actionAssignee(item) {
  return item.assigned_person_name || item.assigned_role_name || item.assigned_sector || 'Sin responsable';
}

function actionTone(item) {
  if (item.effective_status === 'VENCIDA') return 'danger';
  if (item.status === 'CERRADA') return 'ok';
  if (item.priority === 'URGENTE' || item.priority === 'ALTA') return 'warn';
  return 'neutral';
}

function actionDaysText(item) {
  if (item.status === 'CERRADA') return 'Cerrada';
  const days = Number(item.days_remaining);
  if (days < 0) return `${Math.abs(days)} día${Math.abs(days) === 1 ? '' : 's'} de atraso`;
  if (days === 0) return 'Vence hoy';
  return `${days} día${days === 1 ? '' : 's'}`;
}

function actionButtons(item, compact = false) {
  const buttons = [`<button type="button" data-action-view="${escapeHtml(item.id)}">Ver</button>`];
  if (item.status !== 'CERRADA' && (can('Actions.EditOwn') || can('Actions.Assign'))) buttons.push(`<button type="button" data-action-edit="${escapeHtml(item.id)}">${compact ? 'Actualizar' : 'Editar'}</button>`);
  if (item.status !== 'CERRADA' && can('Actions.Close')) buttons.push(`<button type="button" class="primary" data-action-close="${escapeHtml(item.id)}">Cerrar</button>`);
  return buttons.join('');
}

function renderActionRows(rows, targetId, mode = 'all') {
  const body = $(targetId);
  if (!body) return;
  const columns = mode === 'mine' ? 7 : mode === 'overdue' ? 7 : 8;
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="${columns}">No hay acciones para mostrar.</td></tr>`;
    return;
  }
  body.innerHTML = rows.map((item) => {
    if (mode === 'mine') return `<tr><td><strong>${escapeHtml(item.code)}</strong><div class="small">${escapeHtml(item.priority)}</div></td><td>${escapeHtml(item.problem)}</td><td>${escapeHtml(item.action_text)}</td><td>${escapeHtml(financeDate(item.target_date))}<div class="small">${escapeHtml(actionDaysText(item))}</div></td><td><span class="status ${actionTone(item)}">${escapeHtml(actionStatusText(item.effective_status))}</span></td><td>${escapeHtml(item.progress_percent)} %</td><td class="actions">${actionButtons(item, true)}</td></tr>`;
    if (mode === 'overdue') return `<tr><td><strong>${escapeHtml(item.code)}</strong></td><td>${escapeHtml(item.problem)}</td><td>${escapeHtml(actionAssignee(item))}</td><td>${escapeHtml(financeDate(item.target_date))}</td><td><span class="status danger">${escapeHtml(actionDaysText(item))}</span></td><td>${escapeHtml(item.priority)}</td><td class="actions">${actionButtons(item, true)}</td></tr>`;
    return `<tr><td><strong>${escapeHtml(item.code)}</strong><div class="small">${escapeHtml(item.priority)}</div></td><td>${escapeHtml(item.problem)}</td><td>${escapeHtml(item.action_text)}</td><td>${escapeHtml(actionAssignee(item))}</td><td>${escapeHtml(financeDate(item.target_date))}<div class="small">${escapeHtml(actionDaysText(item))}</div></td><td><span class="status ${actionTone(item)}">${escapeHtml(actionStatusText(item.effective_status))}</span></td><td>${escapeHtml(item.progress_percent)} %</td><td class="actions">${actionButtons(item)}</td></tr>`;
  }).join('');
}

function renderActionsSummary() {
  const rows = state.actions || [];
  const cards = [
    ['Abiertas', rows.filter((x) => x.status !== 'CERRADA').length, 'neutral'],
    ['En curso', rows.filter((x) => x.status === 'EN_CURSO').length, 'warn'],
    ['Vencidas', state.overdueActions.length, state.overdueActions.length ? 'danger' : 'ok'],
    ['Cerradas', rows.filter((x) => x.status === 'CERRADA').length, 'ok']
  ];
  $('#actions-summary').innerHTML = cards.map(([label, value, tone]) => `<article class="actions-summary-card ${tone}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></article>`).join('');
  $('#actions-overdue-count').textContent = String(state.overdueActions.length);
  $('#actions-overdue-count').className = `status ${state.overdueActions.length ? 'danger' : 'ok'}`;
}

function renderActionsByIndicator() {
  const definitions = state.actionOptions?.indicators || [];
  const groups = new Map();
  for (const action of state.actions) if (action.indicator_code) {
    if (!groups.has(action.indicator_code)) groups.set(action.indicator_code, []);
    groups.get(action.indicator_code).push(action);
  }
  const codes = new Set([...definitions.map((x) => x.code), ...groups.keys()]);
  $('#actions-indicator-list').innerHTML = codes.size ? [...codes].map((code) => {
    const definition = definitions.find((x) => x.code === code);
    const actions = groups.get(code) || [];
    const open = actions.filter((x) => x.status !== 'CERRADA').length;
    return `<article class="actions-indicator-card"><header><div><strong>${escapeHtml(definition?.name || code)}</strong><small>${escapeHtml(code)}${definition?.category ? ` · ${escapeHtml(definition.category)}` : ''}</small></div><span class="status ${open ? 'warn' : 'ok'}">${open} abiertas</span></header><div class="actions-indicator-actions">${actions.length ? actions.slice(0, 8).map((item) => `<button type="button" data-action-view="${escapeHtml(item.id)}"><strong>${escapeHtml(item.code)}</strong><span>${escapeHtml(item.title)}</span></button>`).join('') : '<span class="small">Sin acciones registradas.</span>'}</div>${can('Actions.Create') ? `<button type="button" data-action-create-indicator="${escapeHtml(code)}">Crear acción confirmada</button>` : ''}</article>`;
  }).join('') : '<div class="dashboard-empty compact">No hay indicadores configurados.</div>';
}

function agendaSummaryHtml(agenda, monthly = false) {
  if (!agenda) return '<div class="dashboard-empty compact">Sin agenda disponible.</div>';
  const cards = [
    ['Información', agenda.summary?.information || 0, 'neutral'],
    ['Decisiones', agenda.summary?.decisions || 0, 'warn'],
    ['Acciones', agenda.summary?.actions || 0, agenda.summary?.actions ? 'danger' : 'ok'],
    ['Total', agenda.summary?.total || 0, 'neutral']
  ];
  if (monthly && agenda.comparison) cards.push(['Cerradas período', agenda.comparison.current?.closed || 0, 'ok']);
  return cards.map(([label, value, tone]) => `<article class="actions-summary-card ${tone}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></article>`).join('');
}

function renderAgenda(agenda, summaryId, topicsId, monthly = false) {
  $(summaryId).innerHTML = agendaSummaryHtml(agenda, monthly);
  const topics = agenda?.topics || [];
  $(topicsId).innerHTML = topics.length ? topics.map((topic) => {
    const tone = topic.topicType === 'ACCION_REQUERIDA' ? 'danger' : topic.topicType === 'DECISION_REQUERIDA' ? 'warn' : 'neutral';
    return `<article class="meeting-topic ${tone}"><span class="status ${tone}">${escapeHtml(actionStatusText(topic.topicType))}</span><div><strong>${escapeHtml(topic.title)}</strong><p>${escapeHtml(topic.detail)}</p><small>${escapeHtml(topic.sourceType || 'SISTEMA')}</small></div></article>`;
  }).join('') : '<div class="dashboard-empty compact"><strong>Sin desvíos pendientes.</strong><span>La agenda no encontró temas dentro del período y alcance seleccionados.</span></div>';
}

function renderMeetings() {
  const body = $('#meetings-body');
  const rows = state.meetings || [];
  body.innerHTML = rows.length ? rows.map((item) => `<tr><td><strong>${escapeHtml(item.code)}</strong><div class="small">${escapeHtml(item.title)}</div></td><td>${escapeHtml(uiCodeLabel(item.meeting_type))}</td><td>${escapeHtml(financeDate(item.meeting_date))}</td><td>${escapeHtml(financeDate(item.period_from))} al ${escapeHtml(financeDate(item.period_to))}</td><td><span class="status ${item.status === 'CERRADA' ? 'ok' : 'warn'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${item.status === 'CERRADA' ? `<span class="status ${item.integrity_hash ? 'ok' : 'danger'}">${item.integrity_hash ? 'Con hash' : 'Sin hash'}</span>` : 'Pendiente'}</td><td class="actions"><button type="button" data-meeting-view="${escapeHtml(item.id)}">Ver</button>${item.status !== 'CERRADA' && can('Meetings.Create') ? `<button type="button" data-meeting-decision="${escapeHtml(item.id)}">Decisión</button><button type="button" data-meeting-action="${escapeHtml(item.id)}">Crear acción</button>` : ''}${item.status !== 'CERRADA' && can('Meetings.Close') ? `<button type="button" class="primary" data-meeting-close="${escapeHtml(item.id)}">Cerrar acta</button>` : ''}${can('Meetings.Close') ? `<button type="button" data-meeting-resolve="${escapeHtml(item.id)}">Resolver decisión</button>` : ''}${item.status === 'CERRADA' ? `<button type="button" data-meeting-minutes="${escapeHtml(item.id)}">Acta</button>${can('Meetings.Close') ? `<button type="button" data-meeting-correct="${escapeHtml(item.id)}">Corregir</button>` : ''}` : ''}</td></tr>`).join('') : '<tr><td colspan="7">No hay reuniones registradas.</td></tr>';
}

function setActionsTab(tab) {
  state.actionsTab = tab;
  $$('[data-actions-tab]').forEach((button) => button.classList.toggle('active', button.dataset.actionsTab === tab));
  $$('[data-actions-pane]').forEach((pane) => { const active = pane.dataset.actionsPane === tab; pane.classList.toggle('active', active); pane.hidden = !active; });
}

async function loadActionsMeetings() {
  if (!can('Actions.Read')) return;
  $('#actions-status').textContent = 'Consultando…';
  $('#actions-status').className = 'status neutral';
  if (!state.actionOptions) state.actionOptions = await api('/api/v1/actions/options');
  const params = actionScopeParams({ pageSize: 250 });
  const tasks = [
    api(`/api/v1/actions?${params}`),
    api(`/api/v1/actions?${actionScopeParams({ pageSize: 250, mine: true })}`),
    api(`/api/v1/actions?${actionScopeParams({ pageSize: 250, status: 'VENCIDA' })}`)
  ];
  const meetingCapable = can('Meetings.Minutes.Read');
  if (meetingCapable) tasks.push(api(`/api/v1/meetings?${actionScopeParams({ pageSize: 250 })}`));
  if (can('Meetings.Create')) {
    tasks.push(api(`/api/v1/meetings/agenda/weekly?${actionScopeParams()}`));
    tasks.push(api(`/api/v1/meetings/agenda/monthly?${actionScopeParams()}`));
  }
  const result = await Promise.all(tasks);
  state.actions = result[0].rows || [];
  state.myActions = result[1].rows || [];
  state.overdueActions = result[2].rows || [];
  let index = 3;
  state.meetings = meetingCapable ? (result[index++].rows || []) : [];
  state.weeklyAgenda = can('Meetings.Create') ? result[index++] : null;
  state.monthlyAgenda = can('Meetings.Create') ? result[index++] : null;
  renderActionsSummary();
  renderActionRows(state.actions, '#actions-body');
  renderActionRows(state.myActions, '#actions-mine-body', 'mine');
  renderActionRows(state.overdueActions, '#actions-overdue-body', 'overdue');
  renderActionsByIndicator();
  renderAgenda(state.weeklyAgenda, '#weekly-agenda-summary', '#weekly-agenda-topics');
  renderAgenda(state.monthlyAgenda, '#monthly-agenda-summary', '#monthly-agenda-topics', true);
  renderMeetings();
  $('#actions-status').textContent = `${state.actions.length} acciones`;
  $('#actions-status').className = `status ${state.overdueActions.length ? 'warn' : 'ok'}`;
}

function assignmentOptions(selected = '') {
  const options = [];
  for (const person of state.actionOptions?.people || []) options.push({ value: `PERSON:${person.id}`, label: `Persona · ${person.full_name}` });
  for (const role of state.actionOptions?.roles || []) options.push({ value: `ROLE:${role.id}`, label: `Rol · ${role.name}` });
  for (const sector of state.actionOptions?.sectors || []) options.push({ value: `SECTOR:${sector}`, label: `Sector · ${sector}` });
  return options.map((item) => ({ ...item, selected: item.value === selected }));
}

function assignmentPayload(value) {
  const [type, ...parts] = String(value || '').split(':');
  const id = parts.join(':');
  return { assignedPersonId: type === 'PERSON' ? id : null, assignedRoleId: type === 'ROLE' ? id : null, assignedSector: type === 'SECTOR' ? id : null };
}

async function createActionUi(indicatorCode = '') {
  const options = state.actionOptions;
  const defaultPerson = state.user?.personId ? `PERSON:${state.user.personId}` : '';
  const values = await askFields(indicatorCode ? `Nueva acción para ${indicatorCode}` : 'Nueva acción', [
    { name: 'title', label: 'Título claro' },
    { name: 'problem', label: 'Qué pasa', type: 'textarea' },
    { name: 'actionText', label: 'Qué vamos a hacer', type: 'textarea' },
    { name: 'expectedResult', label: 'Qué resultado esperamos', type: 'textarea' },
    { name: 'causeCode', label: 'Causa', type: 'select', value: 'PENDIENTE_ANALISIS', options: options.causes.map((value) => ({ value, label: actionStatusText(value) })) },
    { name: 'priority', label: 'Prioridad', type: 'select', value: 'MEDIA', options: options.priorities.map((value) => ({ value, label: value })) },
    { name: 'assignment', label: 'Quién lo hace', type: 'select', value: defaultPerson, options: assignmentOptions(defaultPerson) },
    { name: 'targetDate', label: 'Cuándo debe terminar', type: 'date', value: $('#management-date-to').value || new Date().toISOString().slice(0, 10) }
  ], { confirmText: 'Crear acción' });
  if (!values) return;
  const body = { siteId: $('#management-site').value || null, locationId: $('#management-location').value || null, title: values.title, problem: values.problem, actionText: values.actionText, expectedResult: values.expectedResult, causeCode: values.causeCode, priority: values.priority, targetDate: values.targetDate, indicatorCode: indicatorCode || null, ...assignmentPayload(values.assignment) };
  await api(indicatorCode ? '/api/v1/actions/from-indicator' : '/api/v1/actions', { method: 'POST', body: JSON.stringify(body) });
  flash('Acción creada y auditada.');
  await loadActionsMeetings();
  setActionsTab(indicatorCode ? 'indicator' : 'actions');
}

async function viewActionUi(id) {
  const { action: item } = await api(`/api/v1/actions/${id}`);
  await showDetails(`${item.code} · ${item.title}`, {
    problema: item.problem,
    causa: actionStatusText(item.cause_code),
    accion: item.action_text,
    resultadoEsperado: item.expected_result,
    resultadoReal: item.actual_result || null,
    responsable: actionAssignee(item),
    fechaObjetivo: item.target_date,
    estado: item.effective_status,
    avance: `${item.progress_percent} %`,
    evidencia: (item.evidence || []).map((x) => ({ tipo: x.evidence_type, nota: x.description, referencia: x.reference_value, archivo: x.filename, sha256: x.sha256 })),
    relaciones: item.relations,
    historial: item.events
  });
}

async function editActionUi(id) {
  const { action: item } = await api(`/api/v1/actions/${id}`);
  const currentAssignment = item.assigned_person_id ? `PERSON:${item.assigned_person_id}` : item.assigned_role_id ? `ROLE:${item.assigned_role_id}` : `SECTOR:${item.assigned_sector || ''}`;
  const fields = [
    { name: 'status', label: 'Estado', type: 'select', value: item.status, options: [{ value: 'PENDIENTE', label: 'Pendiente' }, { value: 'EN_CURSO', label: 'En curso' }] },
    { name: 'progressPercent', label: 'Avance de 0 a 99', type: 'number', value: item.progress_percent },
    { name: 'targetDate', label: 'Fecha objetivo', type: 'date', value: item.target_date },
    { name: 'priority', label: 'Prioridad', type: 'select', value: item.priority, options: state.actionOptions.priorities.map((value) => ({ value, label: value })) }
  ];
  if (can('Actions.Assign')) fields.push({ name: 'assignment', label: 'Responsable', type: 'select', value: currentAssignment, options: assignmentOptions(currentAssignment) });
  const values = await askFields(`Actualizar ${item.code}`, fields, { confirmText: 'Guardar' });
  if (!values) return;
  const body = { version: item.version, status: values.status, progressPercent: Number(values.progressPercent), targetDate: values.targetDate, priority: values.priority };
  if (values.assignment) Object.assign(body, assignmentPayload(values.assignment));
  await api(`/api/v1/actions/${id}`, { method: 'PUT', body: JSON.stringify(body) });
  flash('Acción actualizada.');
  await loadActionsMeetings();
}

async function closeActionUi(id) {
  const { action: item } = await api(`/api/v1/actions/${id}`);
  const values = await askFields(`Cerrar ${item.code}`, [
    { name: 'actualResult', label: 'Qué resultado se obtuvo', type: 'textarea' },
    { name: 'evidenceNote', label: 'Evidencia u observación técnica', type: 'textarea', required: false },
    { name: 'noEvidenceJustification', label: 'Justificación si no existe evidencia', type: 'textarea', required: false }
  ], { confirmText: 'Cerrar acción' });
  if (!values) return;
  let version = item.version;
  if (values.evidenceNote) {
    await api(`/api/v1/actions/${id}/evidence`, { method: 'POST', body: JSON.stringify({ evidenceType: 'NOTE', referenceValue: values.evidenceNote, description: 'Observación técnica de cierre' }) });
    version = (await api(`/api/v1/actions/${id}`)).action.version;
  }
  await api(`/api/v1/actions/${id}/close`, { method: 'POST', body: JSON.stringify({ version, actualResult: values.actualResult, noEvidenceJustification: values.noEvidenceJustification || null }) });
  flash('Acción cerrada con resultado y trazabilidad.');
  await loadActionsMeetings();
}

async function createMeetingUi(type) {
  const agenda = type === 'SEMANAL' ? state.weeklyAgenda : state.monthlyAgenda;
  const participant = state.user?.personId ? { personId: state.user.personId, displayName: state.user.fullName, roleInMeeting: 'Responsable de reunión' } : { displayName: state.user?.fullName || 'Usuario actual', roleInMeeting: 'Responsable de reunión' };
  const values = await askFields(type === 'SEMANAL' ? 'Crear reunión semanal' : 'Crear revisión mensual', [
    { name: 'title', label: 'Título', value: type === 'SEMANAL' ? 'Reunión semanal del pañol' : 'Revisión mensual de gestión' },
    { name: 'meetingDate', label: 'Fecha de reunión', type: 'date', value: new Date().toISOString().slice(0, 10) },
    { name: 'observations', label: 'Observaciones iniciales', type: 'textarea', required: false }
  ], { confirmText: 'Crear reunión' });
  if (!values) return;
  await api('/api/v1/meetings', { method: 'POST', body: JSON.stringify({ meetingType: type, title: values.title, meetingDate: values.meetingDate, dateFrom: agenda?.period?.dateFrom || $('#management-date-from').value, dateTo: agenda?.period?.dateTo || $('#management-date-to').value, siteId: $('#management-site').value || null, locationId: $('#management-location').value || null, observations: values.observations || null, participants: [participant] }) });
  flash('Reunión creada con agenda real.');
  await loadActionsMeetings();
  setActionsTab('minutes');
}

async function viewMeetingUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  await showDetails(`${meeting.code} · ${meeting.title}`, {
    estado: meeting.status,
    fecha: meeting.meeting_date,
    periodo: `${meeting.period_from} a ${meeting.period_to}`,
    participantes: meeting.participants,
    temas: meeting.topics,
    decisiones: meeting.decisions,
    correcciones: meeting.corrections
  });
}

async function addMeetingDecisionUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  const defaultPerson = state.user?.personId ? `PERSON:${state.user.personId}` : '';
  const values = await askFields(`Decisión de ${meeting.code}`, [
    { name: 'decisionText', label: 'Qué se decidió', type: 'textarea' },
    { name: 'assignment', label: 'Quién es responsable', type: 'select', value: defaultPerson, options: assignmentOptions(defaultPerson) },
    { name: 'targetDate', label: 'Fecha objetivo', type: 'date', value: meeting.period_to }
  ], { confirmText: 'Registrar decisión' });
  if (!values) return;
  const assignment = assignmentPayload(values.assignment);
  await api(`/api/v1/meetings/${id}/decisions`, { method: 'POST', body: JSON.stringify({ decisionText: values.decisionText, responsiblePersonId: assignment.assignedPersonId, responsibleRoleId: assignment.assignedRoleId, responsibleSector: assignment.assignedSector, targetDate: values.targetDate }) });
  flash('Decisión registrada.');
  await loadActionsMeetings();
}

async function createActionFromMeetingUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  const candidates = (meeting.decisions || []).filter((x) => !x.action_id);
  if (!candidates.length) return showNotice('Sin decisiones pendientes', 'Primero registre una decisión que todavía no tenga acción vinculada.');
  const values = await askFields(`Crear acción desde ${meeting.code}`, [
    { name: 'decisionId', label: 'Decisión', type: 'select', options: candidates.map((x) => ({ value: x.id, label: x.decision_text })) },
    { name: 'priority', label: 'Prioridad', type: 'select', value: 'MEDIA', options: state.actionOptions.priorities.map((value) => ({ value, label: value })) }
  ], { confirmText: 'Crear acción' });
  if (!values) return;
  await api(`/api/v1/meetings/${id}/decisions/${values.decisionId}/action`, { method: 'POST', body: JSON.stringify({ priority: values.priority }) });
  flash('Acción creada desde la decisión.');
  await loadActionsMeetings();
}

async function resolveMeetingDecisionUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  const candidates = (meeting.decisions || []).filter((item) => item.status === 'PENDIENTE');
  if (!candidates.length) return showNotice('Sin decisiones pendientes', 'Todas las decisiones del acta ya fueron ejecutadas o canceladas.');
  const values = await askFields(`Resolver decisión de ${meeting.code}`, [
    { name: 'decisionId', label: 'Decisión pendiente', type: 'select', options: candidates.map((item) => ({ value: item.id, label: item.decision_text })) },
    { name: 'status', label: 'Resultado', type: 'select', value: 'EJECUTADA', options: [{ value: 'EJECUTADA', label: 'Ejecutada' }, { value: 'CANCELADA', label: 'Cancelada' }] },
    { name: 'resolutionNote', label: 'Resultado o motivo documentado', type: 'textarea' }
  ], { confirmText: 'Resolver decisión' });
  if (!values) return;
  await api(`/api/v1/meetings/${id}/decisions/${values.decisionId}/resolve`, {
    method: 'POST',
    body: JSON.stringify({ status: values.status, resolutionNote: values.resolutionNote })
  });
  flash(values.status === 'EJECUTADA' ? 'Decisión marcada como ejecutada.' : 'Decisión cancelada con motivo documentado.');
  await loadActionsMeetings();
}

async function closeMeetingUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  const values = await askFields(`Cerrar acta ${meeting.code}`, [
    { name: 'executiveSummary', label: 'Resumen de lo revisado', type: 'textarea', value: meeting.executive_summary || '' },
    { name: 'observations', label: 'Observaciones finales', type: 'textarea', required: false, value: meeting.observations || '' }
  ], { confirmText: 'Cerrar acta' });
  if (!values) return;
  await api(`/api/v1/meetings/${id}/close`, { method: 'POST', body: JSON.stringify({ version: meeting.version, executiveSummary: values.executiveSummary, observations: values.observations || null }) });
  flash('Acta cerrada con hash de integridad.');
  await loadActionsMeetings();
}

async function showMeetingMinutesUi(id) {
  const { minutes } = await api(`/api/v1/meetings/${id}/minutes`);
  await showDetails(`${minutes.code} · Acta cerrada`, { integridad: minutes.integrity, acta: minutes.printable, correcciones: minutes.corrections });
}

async function correctMeetingUi(id) {
  const { meeting } = await api(`/api/v1/meetings/${id}`);
  const values = await askFields(`Corrección de ${meeting.code}`, [
    { name: 'reason', label: 'Motivo de la corrección', type: 'textarea' },
    { name: 'correctionText', label: 'Corrección registrada', type: 'textarea' }
  ], { confirmText: 'Registrar corrección' });
  if (!values) return;
  await api(`/api/v1/meetings/${id}/corrections`, { method: 'POST', body: JSON.stringify(values) });
  flash('Corrección agregada sin alterar el acta original.');
  await loadActionsMeetings();
}

$$('[data-actions-tab]').forEach((button) => button.addEventListener('click', () => setActionsTab(button.dataset.actionsTab)));
$('#actions-add')?.addEventListener('click', () => createActionUi().catch((error) => flash(error.message, 'error')));
$('#meeting-create-weekly')?.addEventListener('click', () => createMeetingUi('SEMANAL').catch((error) => flash(error.message, 'error')));
$('#meeting-create-monthly')?.addEventListener('click', () => createMeetingUi('MENSUAL').catch((error) => flash(error.message, 'error')));
$('#actions-meetings-card')?.addEventListener('click', (event) => {
  const view = event.target.closest('[data-action-view]');
  const edit = event.target.closest('[data-action-edit]');
  const close = event.target.closest('[data-action-close]');
  const createIndicator = event.target.closest('[data-action-create-indicator]');
  const meetingView = event.target.closest('[data-meeting-view]');
  const meetingDecision = event.target.closest('[data-meeting-decision]');
  const meetingAction = event.target.closest('[data-meeting-action]');
  const meetingClose = event.target.closest('[data-meeting-close]');
  const meetingResolve = event.target.closest('[data-meeting-resolve]');
  const meetingMinutes = event.target.closest('[data-meeting-minutes]');
  const meetingCorrect = event.target.closest('[data-meeting-correct]');
  const task = view ? viewActionUi(view.dataset.actionView) : edit ? editActionUi(edit.dataset.actionEdit) : close ? closeActionUi(close.dataset.actionClose) : createIndicator ? createActionUi(createIndicator.dataset.actionCreateIndicator) : meetingView ? viewMeetingUi(meetingView.dataset.meetingView) : meetingDecision ? addMeetingDecisionUi(meetingDecision.dataset.meetingDecision) : meetingAction ? createActionFromMeetingUi(meetingAction.dataset.meetingAction) : meetingClose ? closeMeetingUi(meetingClose.dataset.meetingClose) : meetingResolve ? resolveMeetingDecisionUi(meetingResolve.dataset.meetingResolve) : meetingMinutes ? showMeetingMinutesUi(meetingMinutes.dataset.meetingMinutes) : meetingCorrect ? correctMeetingUi(meetingCorrect.dataset.meetingCorrect) : null;
  task?.catch((error) => flash(error.message, 'error'));
});

