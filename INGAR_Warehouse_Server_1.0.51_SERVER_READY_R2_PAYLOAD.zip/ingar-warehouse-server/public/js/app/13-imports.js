const IMPORT_DETAIL_PAGE_SIZE = 100;
const IMPORT_KIND_LABELS = Object.freeze({ ASSET: 'Bienes', VEHICLE: 'Vehículos', KIT: 'Kits' });
const IMPORT_TEMPLATE_STEMS = Object.freeze({ ASSET: 'plantilla_bienes_ingar', VEHICLE: 'plantilla_vehiculos_ingar', KIT: 'plantilla_kits_componentes_ingar' });

function selectedImportKind() { return String($('#import-kind')?.value || 'ASSET').toUpperCase(); }
function importKindLabel(kind) { return IMPORT_KIND_LABELS[String(kind || 'ASSET').toUpperCase()] || String(kind || 'ASSET'); }
function importNormalizedAsset(row) { return row.normalized?.asset || row.normalized || null; }

function updateImportFileState() {
  const file = $('#import-file')?.files?.[0] || null;
  const stateNode = $('#import-file-state');
  const validate = $('#import-validate');
  if (validate) validate.disabled = !file;
  if (!stateNode) return;
  stateNode.className = `small pe-file-state${file ? ' ready' : ''}`;
  stateNode.textContent = file ? `${file.name} · ${(file.size / 1024).toLocaleString('es-AR',{maximumFractionDigits:0})} KiB · listo para validar.` : 'Todavía no seleccionaste un archivo.';
}
function updateImportKindHelp() {
  const kind = selectedImportKind();
  const messages = {
    ASSET: 'Bienes generales. Las categorías VEHICULO y KIT se rechazan en esta plantilla.',
    VEHICLE: 'Alta o actualización atómica del bien y su perfil vehicular. Las celdas vacías conservan estado, vigencia y datos existentes.',
    KIT: 'Cada fila representa un componente. Las filas con el mismo kit_codigo_interno forman una única composición transaccional.'
  };
  $('#import-kind-help').textContent = messages[kind];
}

async function loadImports() {
  const params = new URLSearchParams({ status: $('#import-status').value, limit: '200' });
  const data = await api(`/api/v1/imports?${params}`);
  state.imports = data.items;
  $('#imports-body').innerHTML = data.items.map((item) => `<tr><td>${escapeHtml(new Date(item.created_at).toLocaleString())}</td><td><strong>${escapeHtml(item.filename)}</strong><div class="small">${escapeHtml(item.created_by_username)}</div></td><td>${escapeHtml(importKindLabel(item.import_kind))}</td><td>${escapeHtml(uiCodeLabel(item.mode))}</td><td>${item.total_rows}</td><td>${item.valid_rows}</td><td>${item.invalid_rows}</td><td><span class="status ${item.status === 'VALIDADA' || item.status === 'APLICADA' ? 'ok' : item.status === 'VALIDADA_CON_ERRORES' || item.status === 'FALLIDA' ? 'danger' : 'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td class="actions"><button data-import-action="detail" data-id="${item.id}">Detalle</button><button data-import-action="report" data-id="${item.id}">Reporte</button>${can('Import.Apply') && item.status === 'VALIDADA' ? `<button data-import-action="apply" data-id="${item.id}">Aplicar</button>` : ''}${can('Import.Reverse') && item.status === 'APLICADA' ? `<button data-import-action="reverse" data-id="${item.id}">Revertir</button>` : ''}</td></tr>`).join('');
}

function renderImportDetail(batch) {
  state.currentImport = batch;
  state.importPageOffset = Number(batch.rowPage?.offset || 0);
  $('#import-detail').classList.remove('hidden');
  $('#import-detail-title').textContent = `${batch.filename} · ${importKindLabel(batch.importKind)} · ${uiCodeLabel(batch.status)}`;
  const page = batch.rowPage || { offset: 0, returned: batch.rows?.length || 0, total: batch.total_rows, hasPrevious: false, hasMore: false };
  const first = page.total ? page.offset + 1 : 0;
  const last = page.offset + page.returned;
  const sourceRows = Number(batch.mapping?.__sourceRows || batch.total_rows);
  const sourceSummary = batch.importKind === 'KIT' && sourceRows !== batch.total_rows ? ` · ${sourceRows} filas de componentes` : '';
  $('#import-detail-summary').textContent = `${batch.total_rows} registros${sourceSummary} · ${batch.valid_rows} válidos · ${batch.invalid_rows} inválidos · SHA-256 ${batch.sha256}`;
  const apply = $('#import-detail-apply'); const reverse = $('#import-detail-reverse'); const report = $('#import-detail-report'); const guidance = $('#import-detail-guidance');
  if (apply) { apply.hidden = !(can('Import.Apply') && batch.status === 'VALIDADA'); apply.disabled = batch.invalid_rows > 0; }
  if (reverse) reverse.hidden = !(can('Import.Reverse') && batch.status === 'APLICADA');
  if (report) report.hidden = !batch.id;
  if (guidance) {
    guidance.className = `notice ${batch.status === 'VALIDADA' ? 'ok' : batch.invalid_rows ? 'danger' : 'neutral'}`;
    guidance.textContent = batch.status === 'VALIDADA' ? 'Validación correcta. Revisá el lote y aplicalo desde acá cuando estés conforme.' : batch.status === 'APLICADA' ? 'Este lote ya fue aplicado. La reversión queda disponible sólo para usuarios autorizados.' : batch.invalid_rows ? 'Hay errores. No se aplicó ningún cambio: corregí el archivo y validalo nuevamente.' : `Estado del lote: ${uiCodeLabel(batch.status)}.`;
  }
  $('#import-page-status').textContent = page.total ? `Registros ${first}–${last} de ${page.total}` : 'Sin registros';
  $('#import-page-prev').disabled = !page.hasPrevious;
  $('#import-page-next').disabled = !page.hasMore;
  $('#import-rows-body').innerHTML = (batch.rows || []).map((row) => {
    const asset = importNormalizedAsset(row);
    const code = asset?.internalCode || row.raw.kit_codigo_interno || row.raw.codigo_interno || row.raw.CODIGO || '—';
    const description = asset?.description || row.raw.descripcion || row.raw.Herramienta || row.raw['Herramienta '] || '—';
    return `<tr><td>${row.row_number}</td><td>${escapeHtml(uiCodeLabel(row.operation || '—'))}</td><td>${escapeHtml(uiCodeLabel(row.validation_status))}</td><td>${escapeHtml(code)}</td><td>${escapeHtml(description)}</td><td>${row.errors.length ? `<ul class="import-error-list">${row.errors.map((error) => `<li>${escapeHtml(error.code)} · ${escapeHtml(error.message)}</li>`).join('')}</ul>` : '—'}</td></tr>`;
  }).join('');
}

async function loadImportDetail(id, offset = 0) {
  const params = new URLSearchParams({ limit: String(IMPORT_DETAIL_PAGE_SIZE), offset: String(Math.max(0, offset)) });
  const result = await api(`/api/v1/imports/${id}?${params}`);
  renderImportDetail(result.batch);
}

function importErrorDetails(error) {
  const details = [];
  if (error.details?.detectedHeaders?.length) details.push(`Columnas detectadas: ${error.details.detectedHeaders.join(', ')}`);
  if (error.details?.missingColumns?.length) details.push(`Columnas faltantes: ${error.details.missingColumns.join(', ')}`);
  if (error.fieldErrors?.length) details.push(...error.fieldErrors.map((item) => `${item.field}: ${item.message}`));
  return details.length ? details.join('\n') : null;
}

async function downloadSelectedImportTemplate(format) {
  const kind = selectedImportKind();
  const extension = format === 'xlsx' ? 'xlsx' : 'csv';
  const params = new URLSearchParams({ format: extension, kind });
  await downloadFile(`/api/v1/imports/assets/template?${params}`, `${IMPORT_TEMPLATE_STEMS[kind]}.${extension}`);
}

$('#import-kind').addEventListener('change', updateImportKindHelp);
$('#import-file').addEventListener('change', updateImportFileState);
$('#import-refresh').addEventListener('click', () => loadImports().catch((error) => flash(error.message, 'error')));
$('#import-template-csv').addEventListener('click', () => downloadSelectedImportTemplate('csv').catch((error) => flash(error.message, 'error')));
$('#import-template-xlsx').addEventListener('click', () => downloadSelectedImportTemplate('xlsx').catch((error) => flash(error.message, 'error')));
$('#import-validate').addEventListener('click', async () => {
  const button = $('#import-validate');
  const originalText = button.textContent;
  try {
    const file = $('#import-file').files[0];
    if (!file) throw new Error('Seleccione un archivo CSV o XLSX.');
    if (file.size > 5 * 1024 * 1024) throw Object.assign(new Error('El archivo supera el límite de 5 MiB.'), { code: 'IMPORT_TOO_LARGE' });
    button.disabled = true;
    button.textContent = 'Leyendo y validando…';
    $('#view-imports').classList.add('is-busy');
    const result = await api('/api/v1/imports/assets/validate', { method: 'POST', body: JSON.stringify({ filename: file.name, kind: selectedImportKind(), mode: $('#import-mode').value, dataUrl: await fileToDataUrl(file) }) });
    $('#import-file').value = '';
    updateImportFileState();
    renderImportDetail(result.batch);
    $('#import-detail')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    flash(result.batch.invalid_rows ? 'Lote validado con errores. No se aplicaron cambios.' : 'Lote validado sin errores. Puede aplicarse desde el detalle.');
    await loadImports();
  } catch (error) {
    if (error.code === 'IMPORT_MAPPING_INCOMPLETE') await showNotice('El archivo no corresponde a la plantilla seleccionada', error.message, importErrorDetails(error));
    else await showNotice('No fue posible validar la importación', error.message, importErrorDetails(error));
  } finally {
    button.disabled = false;
    button.textContent = originalText;
    $('#view-imports').classList.remove('is-busy');
  }
});

async function applyImportBatch(id) {
  if (!id) return;
  if (!await askConfirm('Aplicar el lote completo de forma transaccional?', { title: 'Aplicar importación', confirmText: 'Aplicar lote' })) return;
  await api(`/api/v1/imports/${id}/apply`, { method: 'POST', body: '{}' });
  await loadImportDetail(id, 0); flash('Lote aplicado.'); await loadImports();
}
async function reverseImportBatch(id) {
  if (!id) return;
  const values = await askFields('Revertir lote importado', [{ name: 'confirmation', label: `Confirmación obligatoria: REVERTIR:${id}`, placeholder: `REVERTIR:${id}` }], { message: 'Se revertirán los cambios asociados al lote.', confirmText: 'Revertir', danger: true });
  if (!values) return;
  await api(`/api/v1/imports/${id}/reverse`, { method: 'POST', body: JSON.stringify({ confirmation: values.confirmation, reason: 'Reversión administrativa confirmada' }) });
  await loadImportDetail(id, 0); flash('Lote revertido.'); await loadImports();
}
$('#imports-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-import-action]');
  if (!button) return;
  try {
    if (button.dataset.importAction === 'detail') await loadImportDetail(button.dataset.id, 0);
    if (button.dataset.importAction === 'report') await downloadFile(`/api/v1/imports/${button.dataset.id}/report`, `reporte-importacion-${button.dataset.id}.csv`);
    if (button.dataset.importAction === 'apply') await applyImportBatch(button.dataset.id);
    if (button.dataset.importAction === 'reverse') await reverseImportBatch(button.dataset.id);
  } catch (error) { await showNotice('No fue posible completar la operación', error.message, importErrorDetails(error)); }
});

$('#import-page-prev').addEventListener('click', () => {
  if (!state.currentImport) return;
  loadImportDetail(state.currentImport.id, Math.max(0, state.importPageOffset - IMPORT_DETAIL_PAGE_SIZE)).catch((error) => showNotice('No fue posible cambiar de página', error.message));
});
$('#import-page-next').addEventListener('click', () => {
  if (!state.currentImport) return;
  loadImportDetail(state.currentImport.id, state.importPageOffset + IMPORT_DETAIL_PAGE_SIZE).catch((error) => showNotice('No fue posible cambiar de página', error.message));
});
$('#import-detail-report').addEventListener('click', () => { if (state.currentImport?.id) downloadFile(`/api/v1/imports/${state.currentImport.id}/report`, `reporte-importacion-${state.currentImport.id}.csv`).catch((error) => flash(error.message,'error')); });
$('#import-detail-apply').addEventListener('click', () => applyImportBatch(state.currentImport?.id).catch((error) => showNotice('No fue posible aplicar el lote', error.message, importErrorDetails(error))));
$('#import-detail-reverse').addEventListener('click', () => reverseImportBatch(state.currentImport?.id).catch((error) => showNotice('No fue posible revertir el lote', error.message, importErrorDetails(error))));
$('#import-detail-close').addEventListener('click', () => { $('#import-detail').classList.add('hidden'); state.currentImport = null; state.importPageOffset = 0; });
updateImportKindHelp(); updateImportFileState();
