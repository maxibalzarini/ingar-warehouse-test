'use strict';

let adminWarehouseOpsLoading = false;

function isAdminGeneralWarehouseControl() {
  const roles = (state.user?.roleCodes || []).map((code) => String(code || '').toUpperCase());
  return roles.includes('ADMIN_GENERAL') && can('Warehouse.Operate') && can('Custody.ReadAll');
}

function adminOpsIsActiveCustody(custody) {
  return ['ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE'].includes(String(custody?.status || '').toUpperCase());
}

function adminOpsIsOverdue(custody) {
  if (!adminOpsIsActiveCustody(custody) || !custody?.due_at) return false;
  const due = new Date(custody.due_at).getTime();
  return Number.isFinite(due) && due < Date.now();
}

function renderAdminWarehouseOperations() {
  const section = $('#admin-warehouse-operations');
  if (!section) return;
  const enabled = isAdminGeneralWarehouseControl();
  section.classList.toggle('hidden', !enabled);
  if (!enabled) return;
  const lanes = state.workbench.lanes || { prepare: [], deliver: [], receive: [], problems: [] };
  for (const lane of ['prepare','deliver','receive','problems']) {
    const target = $(`#admin-ops-count-${lane}`);
    if (target) target.textContent = String(typeof workbenchLaneUnitCount === 'function' ? workbenchLaneUnitCount(lanes[lane] || []) : (lanes[lane] || []).length);
  }
  const activeCustodies = (state.workbench.custodies || []).filter(adminOpsIsActiveCustody);
  const overdue = activeCustodies.filter(adminOpsIsOverdue);
  $('#admin-ops-count-overdue').textContent = String(overdue.length);
  $('#admin-ops-count-held').textContent = String(activeCustodies.length);
}

async function loadAdminWarehouseOperations({ silent = false } = {}) {
  const section = $('#admin-warehouse-operations');
  if (!section) return;
  if (!isAdminGeneralWarehouseControl()) { section.classList.add('hidden'); return; }
  section.classList.remove('hidden');
  if (adminWarehouseOpsLoading) return;
  adminWarehouseOpsLoading = true;
  try {
    const feed = await refreshWarehouseWorkbenchFeed({ silent });
    if (!feed) return;
    renderAdminWarehouseOperations();
    const tasks = Object.values(state.workbench.lanes || {}).reduce((sum, rows) => sum + (typeof workbenchLaneUnitCount === 'function' ? workbenchLaneUnitCount(rows || []) : (rows || []).length), 0);
    const activeCustodies = (state.workbench.custodies || []).filter(adminOpsIsActiveCustody);
    const overdue = activeCustodies.filter(adminOpsIsOverdue).length;
    const updated = $('#admin-ops-updated');
    if (updated) updated.textContent = `${tasks} tareas pendientes · ${activeCustodies.length} activos afuera · ${overdue} atrasados · actualizado ${new Date(feed.generatedAt || Date.now()).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}${feed.truncated ? ' · VISTA PARCIAL' : ''}`;
  } finally {
    adminWarehouseOpsLoading = false;
  }
}

$('#admin-ops-open-workbench')?.addEventListener('click', () => {
  document.querySelector('[data-view="workbench"]')?.click();
});

const f71OriginalLoadDashboard = loadDashboard;
loadDashboard = async function loadDashboardWithAdminWarehouseSummary(options = {}) {
  await f71OriginalLoadDashboard(options);
  if (isAdminGeneralWarehouseControl()) {
    try { await loadAdminWarehouseOperations({ silent: Boolean(options.silent) }); }
    catch (error) { if (!options.silent) flash(error.message, 'error'); }
  } else {
    $('#admin-warehouse-operations')?.classList.add('hidden');
  }
};

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.currentView === 'dashboard' && isAdminGeneralWarehouseControl()) loadAdminWarehouseOperations({ silent: true }).catch(() => {});
});
