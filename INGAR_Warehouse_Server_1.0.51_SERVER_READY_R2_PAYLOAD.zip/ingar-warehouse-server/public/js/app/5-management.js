function reportFilterKeys() {
  return new Set((state.currentReport?.filters || []).map((filter) => filter.key));
}

function reportCategoryName(code) {
  return state.reportCatalog?.categories?.find((category) => category.code === code)?.name || code || 'Informe';
}


function managementQueryParams() {
  const params = new URLSearchParams();
  if ($('#management-date-from')?.value) params.set('dateFrom', $('#management-date-from').value);
  if ($('#management-date-to')?.value) params.set('dateTo', $('#management-date-to').value);
  if ($('#management-site')?.value) params.set('siteId', $('#management-site').value);
  if ($('#management-location')?.value) params.set('locationId', $('#management-location').value);
  if ($('#management-trend-code')?.value) params.set('trendCode', $('#management-trend-code').value);
  return params;
}

function populateManagementLocations() {
  const options = state.managementModel?.options || state.managementDashboard?.options || { locations: [] };
  const siteId = $('#management-site').value;
  const current = $('#management-location').value;
  const locations = options.locations.filter((item) => !siteId || item.site_id === siteId);
  $('#management-location').innerHTML = `<option value="">Todas</option>${locations.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  if (locations.some((item) => item.id === current)) $('#management-location').value = current;
}

function populateManagementOptions(model) {
  const options = model.options || { sites: [], locations: [] };
  const selectedSite = model.scope?.siteId || '';
  const selectedLocation = model.scope?.locationId || '';
  const globalLabel = options.canUseGlobalScope ? 'Toda la organización' : 'Elegí una sede';
  $('#management-site').innerHTML = `<option value="">${globalLabel}</option>${options.sites.map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('')}`;
  $('#management-site').value = selectedSite;
  populateManagementLocations();
  $('#management-location').value = selectedLocation;
  $('#management-date-from').value = model.period?.dateFrom || '';
  $('#management-date-to').value = model.period?.dateTo || '';
}

function managementStatusClass(status) {
  if (status === 'BIEN') return 'ok';
  if (status === 'ATENCION') return 'warn';
  if (status === 'URGENTE') return 'danger';
  return 'neutral';
}

function managementStatusLabel(status) {
  return ({ BIEN: 'Bien', ATENCION: 'Atención', URGENTE: 'Urgente', SIN_DATOS: 'Sin datos' })[status] || 'Sin datos';
}

function managementTrendLabel(trend) {
  return ({ MEJORA: 'Mejoró', EMPEORA: 'Empeoró', ESTABLE: 'Sin cambio', SIN_DATOS: 'Sin comparación' })[trend] || 'Sin comparación';
}

function managementTrendClass(trend) {
  return trend === 'MEJORA' ? 'ok' : trend === 'EMPEORA' ? 'danger' : trend === 'ESTABLE' ? 'neutral' : 'neutral';
}

function managementValue(value, unit) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return '—';
  const formatted = new Intl.NumberFormat('es-AR', { maximumFractionDigits: 2 }).format(Number(value));
  if (unit === 'PERCENT') return `${formatted} %`;
  if (unit === 'HOURS') return `${formatted} h`;
  if (unit === 'DAYS') return `${formatted} días`;
  if (unit === 'CURRENCY') return `$ ${formatted}`;
  return formatted;
}

function managementTargetDescription(indicator) {
  const target = indicator.target;
  if (!target) return 'Sin objetivo';
  const targetText = managementValue(target.targetValue, indicator.unit);
  const warningText = managementValue(target.warningValue, indicator.unit);
  return indicator.direction === 'HIGHER_BETTER'
    ? `Bien: ${targetText} o más · Atención desde ${warningText}`
    : `Bien: ${targetText} o menos · Atención hasta ${warningText}`;
}

function managementResponsible(target) {
  if (!target) return 'Sin responsable';
  if (target.responsibleUserName) return `${target.responsibleUserName}${target.responsibleRoleName ? ` · ${target.responsibleRoleName}` : ''}`;
  return target.responsibleRoleName || 'Sin responsable';
}

function managementPeriodicity(value) {
  return ({ DAILY: 'Diaria', WEEKLY: 'Semanal', MONTHLY: 'Mensual' })[value] || value || '—';
}

function managementCategoryLabel(code) {
  return ({ SOLICITUDES: 'Pedidos', DEVOLUCIONES: 'Devoluciones', ACTIVOS: 'Herramientas', INCIDENTES: 'Problemas', MANTENIMIENTO: 'Mantenimiento', STOCK: 'Consumibles' })[code] || code;
}

function filteredManagementIndicators() {
  const category = $('#management-category').value;
  return (state.managementDashboard?.indicators || []).filter((item) => !category || item.category === category);
}

function renderManagementTrend() {
  const trend = state.managementDashboard?.trend;
  const chart = $('#management-trend-chart');
  const summary = $('#management-trend-summary');
  if (!trend || !trend.points?.length) {
    summary.innerHTML = '<span class="status neutral">Sin datos</span>';
    chart.innerHTML = '<div class="dashboard-empty compact">Todavía no hay mediciones para mostrar.</div>';
    return;
  }
  const indicator = state.managementDashboard.indicators.find((item) => item.code === trend.code);
  summary.innerHTML = `<strong>${escapeHtml(trend.name)}</strong><span class="status ${managementTrendClass(indicator?.comparison?.trend)}">${escapeHtml(managementTrendLabel(indicator?.comparison?.trend))}</span><small>Actual: ${escapeHtml(managementValue(indicator?.current?.value, trend.unit))} · Anterior: ${escapeHtml(managementValue(indicator?.previous?.value, trend.unit))}</small>`;
  const values = trend.points.map((point) => Number(point.value)).filter(Number.isFinite);
  const targets = trend.points.map((point) => Number(point.targetValue)).filter(Number.isFinite);
  const max = Math.max(1, ...values, ...targets);
  chart.innerHTML = `<div class="management-trend-bars">${trend.points.map((point) => {
    const value = Number(point.value);
    const height = Number.isFinite(value) ? (value === 0 ? 0 : Math.max(2, value / max * 100)) : 0;
    const targetHeight = Number.isFinite(Number(point.targetValue)) ? Number(point.targetValue) / max * 100 : 0;
    return `<div class="management-trend-point" title="${escapeHtml(`${point.periodStart} al ${point.periodEnd}: ${managementValue(point.value, trend.unit)}`)}"><div class="management-trend-column"><span class="management-trend-target ${percentClass('b', targetHeight)}"></span><span class="management-trend-value ${managementStatusClass(point.status)} ${percentClass('h', height)}"></span></div><small>${escapeHtml(point.label.slice(5))}</small></div>`;
  }).join('')}</div><div class="management-trend-legend"><span><i class="value"></i>Resultado</span><span><i class="target"></i>Objetivo</span></div>`;
}

function renderManagementDashboard() {
  const dashboard = state.managementDashboard;
  if (!dashboard) return;
  const indicators = filteredManagementIndicators();
  const summary = dashboard.summary || {};
  $('#management-role-view').textContent = dashboard.view?.label || 'Vista gerencial';
  $('#management-role-view').title = dashboard.view?.description || '';
  $('#management-role-view').className = `status ${managementStatusClass(summary.overallStatus)}`;
  $('#management-status-summary').innerHTML = [
    ['URGENTE', 'Urgente', summary.urgent || 0], ['ATENCION', 'Atención', summary.attention || 0],
    ['BIEN', 'Bien', summary.good || 0], ['EMPEORA', 'Empeoraron', summary.worsened || 0]
  ].map(([status, label, value]) => `<div class="management-status-card ${status === 'EMPEORA' ? 'danger' : managementStatusClass(status)}"><span>${label}</span><strong>${value}</strong></div>`).join('');
  $('#management-priority-count').textContent = `${dashboard.priorities?.length || 0} visibles`;
  $('#management-priority-count').className = `status ${(summary.urgent || 0) ? 'danger' : (summary.attention || 0) ? 'warn' : 'ok'}`;
  $('#management-priority-list').innerHTML = dashboard.priorities?.length ? dashboard.priorities.map((item) => `<article class="management-priority-item ${managementStatusClass(item.status)}"><span class="status ${managementStatusClass(item.status)}">${escapeHtml(managementStatusLabel(item.status))}</span><div><strong>${escapeHtml(item.name)}</strong><p>${escapeHtml(item.actionText)}</p><small>Responsable: ${escapeHtml(item.responsible)}</small></div>${item.detail ? `<button type="button" data-management-detail="${escapeHtml(item.code)}">${escapeHtml(item.detail.label || 'Abrir')}</button>` : ''}</article>`).join('') : '<div class="dashboard-empty"><strong>Sin prioridades abiertas.</strong><span>Los indicadores visibles están dentro del objetivo o todavía no tienen datos.</span></div>';
  const trendSelect = $('#management-trend-code');
  const selected = dashboard.trend?.code || trendSelect.value;
  trendSelect.innerHTML = indicators.map((item) => `<option value="${escapeHtml(item.code)}">${escapeHtml(item.name)}</option>`).join('');
  if (indicators.some((item) => item.code === selected)) trendSelect.value = selected;
  $('#management-indicator-count').textContent = `${indicators.length} indicador${indicators.length === 1 ? '' : 'es'}`;
  $('#management-indicator-grid').innerHTML = indicators.length ? indicators.map((item) => `<article class="management-indicator-tile ${managementStatusClass(item.current.status)}"><header><span class="management-category-tag">${escapeHtml(managementCategoryLabel(item.category))}</span><span class="status ${managementStatusClass(item.current.status)}">${escapeHtml(managementStatusLabel(item.current.status))}</span></header><h4>${escapeHtml(item.name)}</h4><strong>${escapeHtml(managementValue(item.current.value, item.unit))}</strong><div class="management-indicator-meta"><span>Objetivo: ${escapeHtml(managementValue(item.target.targetValue, item.unit))}</span><span class="status ${managementTrendClass(item.comparison.trend)}">${escapeHtml(managementTrendLabel(item.comparison.trend))}</span></div><small>Responsable: ${escapeHtml(managementResponsible(item.target))}</small>${item.detail ? `<button type="button" data-management-detail="${escapeHtml(item.code)}">${escapeHtml(item.detail.label || 'Ver detalle')}</button>` : ''}</article>`).join('') : '<div class="dashboard-empty">No hay indicadores para el grupo seleccionado.</div>';
  renderManagementTrend();
}

function renderManagementModel() {
  const model = state.managementModel;
  if (!model) return;
  const dashboardMap = new Map((state.managementDashboard?.indicators || []).map((item) => [item.code, item]));
  const category = $('#management-category').value;
  const indicators = (model.indicators || []).filter((item) => !category || item.category === category);
  $('#management-scope-note').innerHTML = `<strong>Alcance:</strong> ${escapeHtml(model.scope?.label || '—')} · <strong>Período actual:</strong> ${escapeHtml(model.period?.dateFrom || '—')} al ${escapeHtml(model.period?.dateTo || '—')} · <strong>Comparación:</strong> ${escapeHtml(state.managementDashboard?.comparisonPeriod?.dateFrom || '—')} al ${escapeHtml(state.managementDashboard?.comparisonPeriod?.dateTo || '—')}`;
  const latestAt = state.managementDashboard?.generatedAt || null;
  $('#management-last-run').textContent = latestAt ? `Actualizado: ${formatDateTime(latestAt)}` : 'Sin cálculo';
  $('#management-last-run').className = `status ${latestAt ? 'ok' : 'neutral'}`;
  $('#management-body').innerHTML = indicators.length ? indicators.map((item) => {
    const live = dashboardMap.get(item.code);
    const result = live?.current || item.result || item.latest;
    const status = result?.status || 'SIN_DATOS';
    return `<tr><td><strong>${escapeHtml(item.name)}</strong><div class="small">${escapeHtml(item.description)}</div><span class="management-category-tag">${escapeHtml(managementCategoryLabel(item.category))}</span></td><td>${escapeHtml(item.formulaDescription)}<div class="small">Fuente: ${escapeHtml((item.sources || []).join(', '))}</div></td><td class="management-result"><strong>${managementValue(result?.value, item.unit)}</strong><div class="small">Comparación: ${escapeHtml(managementTrendLabel(live?.comparison?.trend))}</div></td><td>${escapeHtml(managementTargetDescription(item))}<div class="small">Configuración: ${escapeHtml(item.target?.scopeType || '—')}</div></td><td><span class="status ${managementStatusClass(status)}">${escapeHtml(managementStatusLabel(status))}</span></td><td>${escapeHtml(managementResponsible(item.target))}</td><td>${escapeHtml(managementPeriodicity(item.target?.periodicity))}</td><td class="actions">${can('Management.Configure') ? `<button type="button" data-management-configure="${escapeHtml(item.code)}">Configurar</button>` : '—'}</td></tr>`;
  }).join('') : '<tr><td colspan="8">No hay indicadores en el grupo seleccionado.</td></tr>';
}


function managementProfileTypeLabel(type) {
  return ({ PERSON: 'Personas', SECTOR: 'Sectores', ASSET: 'Herramientas' })[type] || 'Fichas';
}

function managementProfileParams(extra = {}) {
  const params = managementQueryParams();
  params.delete('trendCode');
  params.set('type', extra.type || state.managementEntityType || 'PERSON');
  if (extra.id) params.set('id', extra.id);
  const search = extra.search !== undefined ? extra.search : $('#management-profile-search')?.value;
  if (search) params.set('search', search);
  params.set('limit', String(extra.limit || 100));
  return params;
}

function managementProfileValue(value, unit) {
  if (value === null || value === undefined || value === '') return '—';
  if (unit === 'TEXT') return String(value).replaceAll('_', ' ');
  return managementValue(value, unit);
}

function managementProfileToneClass(tone) {
  return ['ok', 'warn', 'danger'].includes(tone) ? tone : 'neutral';
}

function renderManagementEntityList() {
  const items = state.managementEntities || [];
  $('#management-entity-title').textContent = managementProfileTypeLabel(state.managementEntityType);
  $('#management-entity-count').textContent = String(items.length);
  $$('[data-management-profile-type]').forEach((button) => button.classList.toggle('active', button.dataset.managementProfileType === state.managementEntityType));
  $('#management-entity-list').innerHTML = items.length ? items.map((item) => {
    const selected = state.managementProfile?.type === item.type && String(state.managementProfile?.id) === String(item.id);
    const metrics = item.metrics || {};
    const metricText = item.type === 'PERSON'
      ? `${metrics.activeTools || 0} herramientas · ${metrics.overdueTools || 0} atrasadas`
      : item.type === 'SECTOR'
        ? `${metrics.activeTools || 0} herramientas · ${metrics.requests || 0} pedidos`
        : `${metrics.activeCustodies || 0} entregada · ${metrics.openIncidents || 0} problemas`;
    return `<button type="button" class="management-entity-item ${managementProfileToneClass(item.tone)} ${selected ? 'active' : ''}" data-management-entity-id="${escapeHtml(item.id)}" data-management-entity-type="${escapeHtml(item.type)}"><span><strong>${escapeHtml(item.label)}</strong><small>${escapeHtml(item.subtitle || '')}</small></span><em>${escapeHtml(metricText)}</em></button>`;
  }).join('') : '<div class="dashboard-empty compact"><strong>Sin resultados.</strong><span>Probá otra búsqueda o revisá la sede y ubicación seleccionadas.</span></div>';
}

function managementProfileCell(key, value) {
  if (value === null || value === undefined || value === '') return '—';
  const lower = String(key).toLowerCase();
  if (lower.endsWith('_at') || ['opened_at','closed_at','received_at','detected_at','due_at','completed_at','scheduled_at'].includes(lower)) return escapeHtml(formatDateTime(value));
  if (lower.includes('cost')) return escapeHtml(managementValue(value, 'CURRENCY'));
  if (['status','severity','condition','timing_status','maintenance_type','priority','result'].includes(lower)) return `<span class="status ${reportStatusClass(value)}">${escapeHtml(String(value).replaceAll('_', ' '))}</span>`;
  if (typeof value === 'number') return escapeHtml(new Intl.NumberFormat('es-AR', { maximumFractionDigits: 2 }).format(value));
  return escapeHtml(value);
}

function renderManagementProfile() {
  const profile = state.managementProfile;
  const detail = $('#management-profile-detail');
  if (!profile) {
    $('#management-profile-status').textContent = 'Sin selección';
    $('#management-profile-status').className = 'status neutral';
    detail.innerHTML = '<div class="dashboard-empty"><strong>Elegí una persona, sector o herramienta.</strong><span>La ficha mostrará la situación actual, el período seleccionado y los problemas registrados.</span></div>';
    renderManagementEntityList();
    return;
  }
  $('#management-profile-status').textContent = profile.view?.label || 'Ficha abierta';
  $('#management-profile-status').className = `status ${profile.summary?.some((item) => item.tone === 'danger') ? 'danger' : profile.summary?.some((item) => item.tone === 'warn') ? 'warn' : 'ok'}`;
  const costNote = profile.costCoverage === 'INCIDENTS_ONLY' ? '<div class="management-profile-note">La atribución económica personal se limita a incidentes con responsable identificado. Los costos generales se consultan por sector o activo.</div>' : profile.costCoverage === 'ECONOMIC_COMPLETE' ? '<div class="management-profile-note">Costos integrados, separados por moneda y reconciliados con sus registros individuales.</div>' : '';
  detail.innerHTML = `<header class="management-profile-header"><div><span class="dashboard-kicker">${escapeHtml(managementProfileTypeLabel(profile.type).toUpperCase())}</span><h3>${escapeHtml(profile.title)}</h3><p>${escapeHtml(profile.subtitle || '')}</p></div><span class="status ${reportStatusClass(profile.status)}">${escapeHtml(String(profile.status || 'ACTIVO').replaceAll('_', ' '))}</span></header>
    ${profile.current ? `<div class="management-current-line"><span><strong>Ubicación:</strong> ${escapeHtml(profile.current.location || '—')}</span><span><strong>Responsable actual:</strong> ${escapeHtml(profile.current.custodian || 'Nadie')}</span><span><strong>Serie:</strong> ${escapeHtml(profile.current.serialNumber || '—')}</span></div>` : ''}
    <div class="management-profile-summary">${(profile.summary || []).map((item) => `<article class="management-profile-kpi ${managementProfileToneClass(item.tone)}"><span>${escapeHtml(item.label)}</span><strong>${escapeHtml(managementProfileValue(item.value, item.unit))}</strong>${item.help ? `<small>${escapeHtml(item.help)}</small>` : ''}</article>`).join('')}</div>
    ${costNote}
    <div class="management-profile-sections">${(profile.sections || []).map((section) => `<article class="management-profile-section"><div class="section-head compact"><div><h4>${escapeHtml(section.title)}</h4></div><span class="status neutral">${section.rows?.length || 0}</span></div><div class="table-wrap"><table><thead><tr>${(section.columns || []).map((column) => `<th>${escapeHtml(column[1])}</th>`).join('')}</tr></thead><tbody>${section.rows?.length ? section.rows.map((row) => `<tr>${section.columns.map((column) => `<td>${managementProfileCell(column[0], row[column[0]])}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${Math.max(1, section.columns?.length || 1)}">${escapeHtml(section.empty || 'Sin registros.')}</td></tr>`}</tbody></table></div></article>`).join('')}</div>`;
  renderManagementEntityList();
}

async function loadManagementEntities({ preserveProfile = true } = {}) {
  const params = managementProfileParams();
  const result = await api(`/api/v1/management/entities?${params}`);
  state.managementEntities = result.items || [];
  if (!preserveProfile || (state.managementProfile && state.managementProfile.type !== state.managementEntityType)) state.managementProfile = null;
  renderManagementEntityList();
  renderManagementProfile();
}

async function loadManagementProfile(type, id) {
  const params = managementProfileParams({ type, id });
  state.managementProfile = await api(`/api/v1/management/profile?${params}`);
  renderManagementProfile();
}

async function loadManagement() {
  const params = managementQueryParams();
  const [model, dashboard] = await Promise.all([
    api(`/api/v1/management/model?${params}`),
    api(`/api/v1/management/dashboard?${params}`)
  ]);
  state.managementModel = model;
  state.managementDashboard = dashboard;
  populateManagementOptions(model);
  renderManagementDashboard();
  renderManagementModel();
  await loadManagementEntities({ preserveProfile: true });
  if (can('Finance.Read')) await loadFinance();
  if (can('Actions.Read')) await loadActionsMeetings();
}

async function evaluateManagement() {
  const body = { dateFrom: $('#management-date-from').value, dateTo: $('#management-date-to').value, siteId: $('#management-site').value || null, locationId: $('#management-location').value || null };
  state.managementResult = await api('/api/v1/management/evaluate', { method: 'POST', body: JSON.stringify(body) });
  await loadManagement();
  flash('Indicadores actualizados.');
}

async function configureManagementIndicator(indicator) {
  const options = state.managementModel?.options || { users: [], roles: [], periodicities: [] };
  const target = indicator.target || {};
  const fields = [
    { name: 'targetValue', label: `Objetivo (${indicator.unit === 'PERCENT' ? '%' : indicator.unit === 'HOURS' ? 'horas' : 'cantidad'})`, type: 'number', value: target.targetValue ?? indicator.defaultTarget },
    { name: 'warningValue', label: 'Nivel desde el que requiere atención', type: 'number', value: target.warningValue ?? indicator.defaultWarning },
    { name: 'periodicity', label: 'Frecuencia de revisión', type: 'select', value: target.periodicity || indicator.defaultPeriodicity, options: [{ value: 'DAILY', label: 'Diaria' }, { value: 'WEEKLY', label: 'Semanal' }, { value: 'MONTHLY', label: 'Mensual' }] }
  ];
  if (can('Management.Assign')) {
    fields.push({ name: 'responsibleRoleId', label: 'Rol responsable', type: 'select', required: false, value: target.responsibleRoleId || '', options: [{ value: '', label: 'Sin rol' }, ...options.roles.map((item) => ({ value: item.id, label: item.name }))] });
    fields.push({ name: 'responsibleUserId', label: 'Persona responsable (opcional)', type: 'select', required: false, value: target.responsibleUserId || '', options: [{ value: '', label: 'Sin persona específica' }, ...options.users.map((item) => ({ value: item.id, label: `${item.full_name} · ${item.username}` }))] });
  }
  const values = await askFields(`Configurar: ${indicator.name}`, fields, { message: `${indicator.formulaDescription} La configuración se aplicará al alcance seleccionado.`, confirmText: 'Guardar configuración' });
  if (!values) return;
  const payload = { siteId: $('#management-site').value || null, locationId: $('#management-location').value || null, targetValue: Number(values.targetValue), warningValue: Number(values.warningValue), periodicity: values.periodicity, responsibleRoleId: can('Management.Assign') ? (values.responsibleRoleId || null) : target.responsibleRoleId, responsibleUserId: can('Management.Assign') ? (values.responsibleUserId || null) : target.responsibleUserId, version: target.version };
  await api(`/api/v1/management/targets/${encodeURIComponent(indicator.code)}`, { method: 'PUT', body: JSON.stringify(payload) });
  flash('Objetivo y responsable actualizados.');
  await loadManagement();
}

function openManagementDetail(code) {
  const indicator = state.managementDashboard?.indicators?.find((item) => item.code === code);
  if (!indicator?.detail?.view) return;
  openDashboardTarget(indicator.detail.view, indicator.detail.filter || {}, indicator.name);
}

$('#management-filter-form').addEventListener('submit', (event) => { event.preventDefault(); evaluateManagement().catch((error) => flash(error.message, 'error')); });
$('#management-refresh').addEventListener('click', () => loadManagement().catch((error) => flash(error.message, 'error')));
$('#management-site').addEventListener('change', () => { populateManagementLocations(); $('#management-location').value = ''; loadManagement().catch((error) => flash(error.message, 'error')); });
$('#management-location').addEventListener('change', () => loadManagement().catch((error) => flash(error.message, 'error')));
$('#management-category').addEventListener('change', () => { renderManagementDashboard(); renderManagementModel(); });
$('#management-trend-code').addEventListener('change', () => loadManagement().catch((error) => flash(error.message, 'error')));
$('#management-body').addEventListener('click', (event) => { const button = event.target.closest('[data-management-configure]'); if (!button) return; const indicator = state.managementModel?.indicators?.find((item) => item.code === button.dataset.managementConfigure); if (indicator) configureManagementIndicator(indicator).catch((error) => flash(error.message, 'error')); });
$('#management-priority-list').addEventListener('click', (event) => { const button = event.target.closest('[data-management-detail]'); if (button) openManagementDetail(button.dataset.managementDetail); });
$('#management-indicator-grid').addEventListener('click', (event) => { const button = event.target.closest('[data-management-detail]'); if (button) openManagementDetail(button.dataset.managementDetail); });
$$('[data-management-profile-type]').forEach((button) => button.addEventListener('click', () => {
  state.managementEntityType = button.dataset.managementProfileType;
  state.managementProfile = null;
  $('#management-profile-search').value = '';
  loadManagementEntities({ preserveProfile: false }).catch((error) => flash(error.message, 'error'));
}));
$('#management-profile-search-button').addEventListener('click', () => loadManagementEntities({ preserveProfile: false }).catch((error) => flash(error.message, 'error')));
$('#management-profile-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); loadManagementEntities({ preserveProfile: false }).catch((error) => flash(error.message, 'error')); } });
$('#management-entity-list').addEventListener('click', (event) => { const button = event.target.closest('[data-management-entity-id]'); if (button) loadManagementProfile(button.dataset.managementEntityType, button.dataset.managementEntityId).catch((error) => flash(error.message, 'error')); });



// F6: visibility only; existing loading, filters and operations are preserved.
document.querySelector('.management-function-tabs')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-management-tab]');
  if (!button) return;
  document.querySelector('#view-management').dataset.f6Tab = button.dataset.managementTab;
  document.querySelectorAll('[data-management-tab]').forEach((tab) => {
    tab.setAttribute('aria-pressed', String(tab === button));
  });
});
