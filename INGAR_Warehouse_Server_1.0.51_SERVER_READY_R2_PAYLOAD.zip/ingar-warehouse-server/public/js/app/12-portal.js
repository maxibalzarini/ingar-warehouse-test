let portalRefreshInFlight = false;

function renderPortalNetworkAndQrs(qrData) {
  state.portalQrs = qrData.items || [];
  const network = qrData.network || { available: false, message: 'ACCESO MÓVIL NO DISPONIBLE', userMessage: 'Conecte la computadora y el celular a la misma red.' };
  const networkPanel = $('#portal-network-status');
  const transportDetail = network.transport === 'HTTP' ? 'Red local' : 'Transporte no disponible';
  const trustSetup = '';
  const lanConfirmed = network.diagnosticCode === 'READY';
  // Clases reales definidas en app.css: notice.info (azul), notice.warn (ámbar), notice.bad (rojo).
  // Antes se usaban 'success'/'warning', que no existen en ningún stylesheet — el panel nunca
  // tuvo color diferenciado, ni siquiera entre disponible/no disponible.
  networkPanel.className = `notice ${network.available ? (lanConfirmed ? 'info' : 'warn') : 'bad'}`;
  networkPanel.innerHTML = network.available
    ? `<strong>CÓDIGO QR DISPONIBLE · ${escapeHtml(transportDetail)}${lanConfirmed ? ' confirmada' : ' SIN CONFIRMAR — pruebe desde el celular'}</strong><br>${escapeHtml(network.userMessage || 'Escanee el QR desde un celular conectado a la misma red.')}${!lanConfirmed ? '<br><em>El firewall de Windows no confirmó la regla de acceso entrante. Use el botón "Probar desde celular" antes de asumir que funciona.</em>' : ''}${trustSetup}`
    : `<strong>CÓDIGO QR NO DISPONIBLE</strong><br>${escapeHtml(network.userMessage || 'Conecte la computadora y el celular a la misma red.')}${trustSetup}`;
  const revision = encodeURIComponent(String(network.revision || 0));
  $('#qrs-grid').innerHTML = state.portalQrs.map((qr) => `<article class="qr-card"><div class="qr-image"><img src="/api/v1/operation/mobile-access/${encodeURIComponent(qr.site_id)}/qr?networkRevision=${revision}" alt="QR ${escapeHtml(qr.site_name)}"></div><div><span class="small">${escapeHtml(qr.site_code)}</span><h4>${escapeHtml(qr.title)}</h4><p>${escapeHtml(qr.site_name)}</p><code>${escapeHtml(qr.url)}</code><div class="actions"><button data-qr-action="open" data-site="${qr.site_id}">Abrir</button><button data-qr-action="download" data-site="${qr.site_id}">Descargar SVG</button><button data-qr-action="validate" data-site="${qr.site_id}" class="primary">Probar desde celular</button></div></div></article>`).join('');
}

async function refreshPortalNetworkAndQrs({ silent = false } = {}) {
  if (portalRefreshInFlight) return;
  portalRefreshInFlight = true;
  try {
    const qrData = await api('/api/v1/operation/mobile-access');
    if (state.currentView === 'portal') renderPortalNetworkAndQrs(qrData);
  } catch (error) {
    if (!silent) throw error;
  } finally {
    portalRefreshInFlight = false;
  }
}

function startPortalAutoRefresh() {
  stopPortalAutoRefresh();
  portalAutoRefreshTimer = setInterval(() => {
    if (state.currentView === 'portal') refreshPortalNetworkAndQrs({ silent: true });
  }, 10_000);
}

function stopPortalAutoRefresh() {
  if (portalAutoRefreshTimer) clearInterval(portalAutoRefreshTimer);
  portalAutoRefreshTimer = null;
}

let mobileValidationPollTimer = null;

function stopMobileValidationPolling() {
  if (mobileValidationPollTimer) clearInterval(mobileValidationPollTimer);
  mobileValidationPollTimer = null;
}

function mobileValidationStep(label, completed, detail = '') {
  return `<li class="${completed ? 'done' : ''}"><span class="validation-step-icon"><svg class="ui-icon" aria-hidden="true" focusable="false"><use href="/assets/icons.svg#icon-${completed ? 'check' : 'pending'}"></use></svg></span><div><strong>${escapeHtml(label)}</strong>${detail ? `<small>${escapeHtml(detail)}</small>` : ''}</div></li>`;
}

function renderMobileValidation(validation) {
  state.mobileValidation = validation;
  const panel = $('#mobile-validation-panel');
  const content = $('#mobile-validation-content');
  panel.classList.remove('hidden');
  const passed = validation.status === 'PASSED';
  const expired = validation.status === 'EXPIRED';
  const physicallyAttested = Boolean(validation.physicalPhoneVerified);
  const title = physicallyAttested ? 'TELÉFONO FÍSICO ATESTIGUADO' : passed ? 'SEGUNDO DISPOSITIVO LAN VALIDADO' : expired ? 'PRUEBA VENCIDA' : 'VALIDACIÓN LAN EN CURSO';
  const noticeClass = physicallyAttested || passed ? 'success' : expired ? 'warning' : 'neutral';
  const message = physicallyAttested
    ? `Aceptación física registrada para ${escapeHtml(validation.requestNumber || '')}. La evidencia combina verificación automática LAN y atestación visual local.`
    : passed
      ? `Solicitud ${escapeHtml(validation.requestNumber || '')} recibida desde el mismo segundo dispositivo. Para cerrar 13.4, el operador debe observar el equipo y atestiguar que es un teléfono físico.`
      : expired ? 'Inicie una nueva prueba desde el QR de la sede.' : 'Escanee este QR desde un teléfono conectado a la red local y complete una solicitud real.';
  const evidence = validation.deviceEvidence || {};
  const deviceDetail = [validation.deviceClass, evidence.platform, evidence.screenWidth && evidence.screenHeight ? `${evidence.screenWidth}×${evidence.screenHeight}` : null, evidence.maxTouchPoints ? `${evidence.maxTouchPoints} puntos táctiles` : null].filter(Boolean).join(' · ');
  content.innerHTML = `<div class="notice ${noticeClass}"><strong>${title}</strong><br>${message}</div>
    <div class="mobile-validation-layout">
      <div class="qr-image mobile-validation-qr">${expired || passed ? '' : `<img src="/api/v1/operation/mobile-validation/${encodeURIComponent(validation.id)}/svg?ts=${Date.now()}" alt="QR de prueba móvil">`}</div>
      <div>
        <p><strong>${escapeHtml(validation.siteCode)} · ${escapeHtml(validation.siteName)}</strong></p>
        <p class="small">La prueba vence: ${escapeHtml(formatDateTime(validation.expiresAt))}</p>
        <ol class="mobile-validation-steps">
          ${mobileValidationStep('Mi operación abierta desde un segundo dispositivo LAN', Boolean(validation.operationOpenedRemote), validation.remoteAddress || '')}
          ${mobileValidationStep('Usuario autenticado con el login general', Boolean(validation.authenticatedRemote), validation.username || '')}
          ${mobileValidationStep('Solicitud creada desde el mismo segundo dispositivo', Boolean(validation.requestCreatedRemote), validation.requestNumber || '')}
          ${mobileValidationStep('Señales técnicas móviles registradas', validation.deviceClass === 'MOBILE_LIKE' && Boolean(evidence.maxTouchPoints), deviceDetail)}
          ${mobileValidationStep('Teléfono físico observado y atestiguado localmente', physicallyAttested, validation.physicalPhoneAttestation?.deviceBrandModel || '')}
        </ol>
        <div class="actions">
          ${passed && !physicallyAttested ? `<button id="mobile-validation-attest" class="primary">Atestiguar teléfono físico</button>` : ''}
          ${passed ? `<button id="mobile-validation-evidence">Descargar evidencia</button>` : ''}
        </div>
      </div>
    </div>`;
  const evidenceButton = $('#mobile-validation-evidence');
  if (evidenceButton) evidenceButton.addEventListener('click', () => downloadFile(`/api/v1/operation/mobile-validation/${encodeURIComponent(validation.id)}/evidence`, `validacion-mi-operacion-${validation.id}.json`).catch((error) => flash(error.message, 'error')));
  const attestButton = $('#mobile-validation-attest');
  if (attestButton) attestButton.addEventListener('click', async () => {
    const code = validation.physicalConfirmationCode;
    const values = await askFields('Atestación de teléfono físico', [
      { name: 'witnessName', label: 'Nombre de quien observa el teléfono', placeholder: 'Nombre y apellido' },
      { name: 'deviceBrandModel', label: 'Marca y modelo observado', placeholder: 'Ej.: Samsung Galaxy A54' },
      { name: 'confirmation', label: `Escriba exactamente ${code}`, placeholder: code },
      { name: 'notes', label: 'Observaciones (opcional)', type: 'textarea', required: false }
    ], { message: 'Confirme únicamente si observó físicamente el teléfono usado para escanear, autenticarse y crear la solicitud.', confirmText: 'Registrar atestación' });
    if (!values) return;
    try {
      const result = await api(`/api/v1/operation/mobile-validation/${encodeURIComponent(validation.id)}/physical-phone-attestation`, { method: 'POST', body: JSON.stringify({ ...values, observedPhysicalPhone: true }) });
      renderMobileValidation(result.validation);
      flash('Teléfono físico atestiguado y auditado.');
    } catch (error) { flash(error.message, 'error'); }
  });
  if (expired || physicallyAttested) stopMobileValidationPolling();
}

async function pollMobileValidation(id) {
  const result = await api(`/api/v1/operation/mobile-validation/${encodeURIComponent(id)}/status`);
  renderMobileValidation(result.validation);
}

async function startMobileValidation(qr) {
  stopMobileValidationPolling();
  const result = await api('/api/v1/operation/mobile-validation/start', { method: 'POST', body: JSON.stringify({ siteId: qr.site_id }) });
  renderMobileValidation(result.validation);
  mobileValidationPollTimer = setInterval(() => pollMobileValidation(result.validation.id).catch(() => {}), 2_000);
}

async function loadPortalAdmin() {
  const [qrData, policyData] = await Promise.all([api('/api/v1/operation/mobile-access'), api('/api/v1/request-policies')]);
  state.requestPolicies = policyData.items;
  renderPortalNetworkAndQrs(qrData);
  await ensureAssetCatalogs();
  $('#policies-body').innerHTML = state.requestPolicies.map((policy) => `<tr><td>${policy.priority}</td><td><strong>${escapeHtml(policy.name)}</strong><div class="small">v${policy.version}</div></td><td>${escapeHtml(uiCodeLabel(policy.operation_type))}</td><td>${escapeHtml(policy.site_name || 'Todas las sedes')}<div class="small">${escapeHtml(policy.category_name || 'Todas las categorías')}</div></td><td>${policy.requires_approval ? 'Obligatoria' : 'Automática'}</td><td>${policy.max_quantity ? `Cantidad ≤ ${policy.max_quantity}` : 'Sin límite de cantidad'}<div class="small">${policy.max_duration_hours ? `Duración ≤ ${policy.max_duration_hours} h` : 'Sin límite de duración'}</div></td><td><span class="status ${policy.active ? 'ok' : 'danger'}">${policy.active ? 'Activa' : 'Inactiva'}</span></td><td>${can('Requests.Policy') ? `<button data-policy-id="${policy.id}">Editar</button>` : ''}</td></tr>`).join('');
  $('#policy-site').innerHTML = '<option value="">Todas las sedes</option>' + state.locations.sites.filter((item) => item.active).map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('');
  $('#policy-category').innerHTML = '<option value="">Todas las categorías</option>' + state.categories.filter((item) => item.active).map((item) => `<option value="${item.id}">${escapeHtml(item.code)} · ${escapeHtml(item.name)}</option>`).join('');
  startPortalAutoRefresh();
}

$('#portal-refresh').addEventListener('click', () => loadPortalAdmin().catch((error) => flash(error.message, 'error')));
$('#mobile-validation-close').addEventListener('click', () => { stopMobileValidationPolling(); $('#mobile-validation-panel').classList.add('hidden'); state.mobileValidation = null; });
$('#policy-create').addEventListener('click', async () => { await loadPortalAdmin(); fillPolicyForm(); $('#request-policy-dialog').showModal(); });
$('#policies-body').addEventListener('click', (event) => { const button = event.target.closest('[data-policy-id]'); if (!button) return; const policy = state.requestPolicies.find((item) => item.id === button.dataset.policyId); if (!policy) return; fillPolicyForm(policy); $('#request-policy-dialog').showModal(); });
$('#request-policy-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const id = $('#policy-id').value;
    const payload = { name: $('#policy-name').value, operationType: $('#policy-operation').value, siteId: $('#policy-site').value || null, categoryId: $('#policy-category').value || null, requiresApproval: $('#policy-requires-approval').checked, maxQuantity: $('#policy-max-quantity').value || null, maxDurationHours: $('#policy-max-hours').value || null, priority: Number($('#policy-priority').value), active: $('#policy-active').checked, version: id ? Number($('#policy-version').value) : undefined };
    await api(id ? `/api/v1/request-policies/${id}` : '/api/v1/request-policies', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
    $('#request-policy-dialog').close(); flash('Política guardada.'); await loadPortalAdmin();
  } catch (error) { flash(error.message, 'error'); }
});
$('#qrs-grid').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-qr-action]'); if (!button) return; const qr = state.portalQrs.find((item) => item.site_id === button.dataset.site); if (!qr) return;
  try {
    if (button.dataset.qrAction === 'open') window.open(qr.url, '_blank', 'noopener');
    if (button.dataset.qrAction === 'download') await downloadFile(`/api/v1/operation/mobile-access/${encodeURIComponent(qr.site_id)}/qr`, `mi-operacion-${qr.site_code}.svg`);
    if (button.dataset.qrAction === 'validate') await startMobileValidation(qr);
  } catch (error) { flash(error.message, 'error'); }
});

async function downloadFile(url, filename) {
  const response = await fetch(url, { credentials: 'same-origin' });
  if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.message || `Error HTTP ${response.status}`); }
  const blob = await response.blob();
  const resolvedFilename = filenameFromDisposition(response.headers.get('content-disposition'), filename);
  const objectUrl = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = objectUrl; link.download = resolvedFilename; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(objectUrl);
}
