async function loadMaintenance() {
  const status = $('#maintenance-order-status').value;
  const orderParams = dashboardFilterParams('maintenance'); orderParams.set('limit','500'); if (!orderParams.has('overdue') && status) orderParams.set('status', status);
  const [plans, orders] = await Promise.all([
    api('/api/v1/maintenance/plans?limit=500'),
    api(`/api/v1/maintenance/orders?${orderParams}`)
  ]);
  state.maintenancePlans = plans.items; state.maintenanceOrders = orders.items;
  const planDueText = (x) => {
    if (x.next_due_at) return formatDateTime(x.next_due_at);
    if (x.next_due_value == null) return 'Manual';
    const suffix = x.trigger_type === 'HOROMETRO' ? 'h' : 'km';
    const factor = Number(x.km_per_hour || 50);
    const equivalentValue = x.trigger_type === 'HOROMETRO'
      ? Number(x.current_odometer || 0) + (Number(x.next_due_value) - Number(x.current_hourmeter || 0)) * factor
      : Number(x.current_hourmeter || 0) + (Number(x.next_due_value) - Number(x.current_odometer || 0)) / factor;
    const equivalent = x.trigger_type === 'HOROMETRO' ? `${vehicleMeterNumber(equivalentValue)} km` : `${vehicleMeterNumber(equivalentValue)} h`;
    return `${vehicleMeterNumber(x.next_due_value)} ${suffix} (${equivalent} equivalentes)`;
  };
  $('#maintenance-plans-body').innerHTML = plans.items.map((x) => `<tr><td><strong>${escapeHtml(x.internal_code)}</strong><div class="small">${escapeHtml(x.description)}</div></td><td>${escapeHtml(x.code)}<div class="small">${escapeHtml(x.name)}</div></td><td>${escapeHtml(x.trigger_type === 'ODOMETRO' ? 'KILÓMETROS' : x.trigger_type === 'HOROMETRO' ? 'HORAS' : x.trigger_type)}</td><td>${escapeHtml(planDueText(x))}</td><td>${x.blocking_when_overdue ? '<span class="status danger">Sí</span>' : 'No'}</td><td><span class="status ${x.active ? 'ok' : 'neutral'}">${x.active ? 'Activo' : 'Inactivo'}</span></td><td><button data-maintenance-plan="detail" data-id="${x.id}">Detalle</button>${can('Maintenance.Manage') ? `<button data-maintenance-plan="edit" data-id="${x.id}">Editar</button>` : ''}</td></tr>`).join('');
  $('#maintenance-orders-body').innerHTML = orders.items.map((x) => `<tr><td><strong>${escapeHtml(x.order_number)}</strong></td><td>${escapeHtml(x.internal_code)}<div class="small">${escapeHtml(x.description)}</div></td><td>${escapeHtml(uiCodeLabel(x.maintenance_type))}</td><td>${escapeHtml(formatDateTime(x.scheduled_at))}</td><td>${escapeHtml(x.due_at ? formatDateTime(x.due_at) : '—')}</td><td><span class="status ${x.status === 'COMPLETADA' ? 'ok' : x.status === 'VENCIDA' ? 'danger' : 'neutral'}">${escapeHtml(uiCodeLabel(x.status))}</span></td><td class="actions"><button data-maintenance-order="detail" data-id="${x.id}">Detalle</button>${can('Maintenance.Execute') && ['PROGRAMADA','VENCIDA'].includes(x.status) ? `<button data-maintenance-order="start" data-id="${x.id}">Iniciar</button>` : ''}${can('Maintenance.Complete') && x.status === 'EN_PROGRESO' ? `<button data-maintenance-order="complete" data-id="${x.id}">Completar</button>` : ''}${can('Maintenance.Complete') && ['BORRADOR','PROGRAMADA','VENCIDA'].includes(x.status) ? `<button data-maintenance-order="cancel" data-id="${x.id}">Cancelar</button>` : ''}</td></tr>`).join('');
}
$('#maintenance-refresh').addEventListener('click',()=>loadMaintenance().catch((e)=>flash(e.message,'error')));
$('#maintenance-order-status').addEventListener('change',()=>loadMaintenance().catch((e)=>flash(e.message,'error')));
$('#maintenance-plan-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const selected = await askFields('Seleccionar bien', [
      { name: 'assetId', label: 'Bien', type: 'select', options: state.assets.filter((asset) => asset.active).map((asset) => ({ value: asset.id, label: `${asset.internal_code} · ${asset.description}` })) }
    ], { confirmText: 'Continuar' });
    if (!selected) return;
    const asset = state.assets.find((item) => item.id === selected.assetId);
    const isVehicle = asset?.category_nature === 'VEHICULO';
    const profile = isVehicle ? (await api(`/api/v1/vehicles/${asset.id}/profile`)).profile : null;
    const primaryTrigger = profile?.usage_unit === 'HORAS' ? 'HOROMETRO' : 'ODOMETRO';
    const triggerOptions = isVehicle
      ? [{ value: primaryTrigger, label: primaryTrigger === 'HOROMETRO' ? 'Horas de funcionamiento' : 'Kilómetros' }, { value: primaryTrigger === 'HOROMETRO' ? 'ODOMETRO' : 'HOROMETRO', label: primaryTrigger === 'HOROMETRO' ? 'Kilómetros (equivalencia)' : 'Horas (equivalencia)' }, { value: 'CALENDARIO', label: 'Calendario' }, { value: 'MANUAL', label: 'Manual' }]
      : [{ value: 'CALENDARIO', label: 'Calendario' }, { value: 'MANUAL', label: 'Manual' }];
    const values = await askFields('Nuevo plan de mantenimiento', [
      { name: 'code', label: 'Código del plan', value: 'PM-001' },
      { name: 'name', label: 'Nombre del plan', value: 'Mantenimiento preventivo' },
      { name: 'triggerType', label: 'Unidad de cálculo', type: 'select', value: isVehicle ? primaryTrigger : 'CALENDARIO', options: triggerOptions },
      { name: 'interval', label: 'Intervalo', type: 'number', value: isVehicle ? (primaryTrigger === 'HOROMETRO' ? 250 : 12500) : 30 }
    ], { confirmText: 'Crear plan', message: isVehicle ? `Vehículo configurado en ${vehicleUsageLabel(profile)} · 1 h = ${vehicleMeterNumber(profile.km_per_hour || 50)} km.` : 'El plan se calculará por calendario o activación manual.' });
    if (!values) return;
    const intervalDays = values.triggerType === 'CALENDARIO' ? Number(values.interval) : null;
    const intervalValue = ['ODOMETRO','HOROMETRO'].includes(values.triggerType) ? Number(values.interval) : null;
    await api('/api/v1/maintenance/plans', { method: 'POST', body: JSON.stringify({ assetId: selected.assetId, code: values.code, name: values.name, maintenanceType: 'PREVENTIVO', triggerType: values.triggerType, intervalDays, intervalValue, leadDays: 7, blockingWhenOverdue: true, instructions: 'Plan creado desde interfaz administrativa.' }) });
    flash('Plan creado.'); await loadMaintenance();
  } catch (e) { flash(e.message, 'error'); }
});
$('#maintenance-plans-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-maintenance-plan]'); if (!button) return;
  const plan = state.maintenancePlans.find((item) => item.id === button.dataset.id); if (!plan) return;
  if (button.dataset.maintenancePlan === 'detail') return showDetails('Detalle del plan', plan);
  try {
    const isMeterPlan = ['ODOMETRO','HOROMETRO'].includes(plan.trigger_type);
    const isCalendarPlan = plan.trigger_type === 'CALENDARIO';
    const unit = plan.trigger_type === 'HOROMETRO' ? 'h' : 'km';
    const fields = [{ name: 'name', label: 'Nombre', value: plan.name }];
    if (isMeterPlan) {
      fields.push({ name: 'intervalValue', label: `Intervalo (${unit})`, type: 'number', value: plan.interval_value });
      fields.push({ name: 'nextDueValue', label: `Próximo vencimiento (${unit})`, type: 'number', value: plan.next_due_value });
    } else if (isCalendarPlan) {
      fields.push({ name: 'intervalDays', label: 'Intervalo (días)', type: 'number', value: plan.interval_days });
      fields.push({ name: 'nextDueAt', label: 'Próximo vencimiento', type: 'datetime-local', value: plan.next_due_at ? dateTimeLocalValue(new Date(plan.next_due_at)) : '', required: false });
    }
    const values = await askFields(`Editar ${plan.code}`, fields, { confirmText: 'Guardar cambios', message: isMeterPlan ? `Todos los vencimientos de este plan se calculan en ${plan.trigger_type === 'HOROMETRO' ? 'horas' : 'kilómetros'}.` : '' });
    if (!values) return;
    const body = { version: plan.version, name: values.name };
    if (isMeterPlan) { body.intervalValue = Number(values.intervalValue); body.nextDueValue = Number(values.nextDueValue); }
    if (isCalendarPlan) { body.intervalDays = Number(values.intervalDays); body.nextDueAt = values.nextDueAt ? new Date(values.nextDueAt).toISOString() : null; }
    await api(`/api/v1/maintenance/plans/${plan.id}`, { method: 'PATCH', body: JSON.stringify(body) });
    flash('Plan actualizado.'); await loadMaintenance();
  } catch (e) { flash(e.message, 'error'); }
});
$('#maintenance-order-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const values = await askFields('Nueva orden de mantenimiento', [
      { name: 'assetId', label: 'Bien', type: 'select', options: state.assets.filter((asset) => asset.active).map((asset) => ({ value: asset.id, label: `${asset.internal_code} · ${asset.description}` })) },
      { name: 'description', label: 'Trabajo requerido', type: 'textarea' }
    ], { confirmText: 'Crear orden' });
    if (!values) return;
    await api('/api/v1/maintenance/orders', { method: 'POST', body: JSON.stringify({ clientOrderId: crypto.randomUUID(), assetId: values.assetId, maintenanceType: 'CORRECTIVO', priority: 'MEDIA', description: values.description, scheduledAt: new Date().toISOString() }) });
    flash('Orden creada.'); await loadMaintenance();
  } catch (e) { flash(e.message, 'error'); }
});
$('#maintenance-orders-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-maintenance-order]'); if (!button) return;
  const current = (await api(`/api/v1/maintenance/orders/${button.dataset.id}`)).order;
  if (button.dataset.maintenanceOrder === 'detail') return showDetails('Detalle de la orden', current);
  try {
    if (button.dataset.maintenanceOrder === 'start') {
      const values = await askFields('Iniciar orden', [{ name: 'reason', label: 'Fundamento de inicio', type: 'textarea' }], { confirmText: 'Iniciar' });
      if (!values) return;
      await api(`/api/v1/maintenance/orders/${current.id}/start`, { method: 'POST', body: JSON.stringify({ version: current.version, reason: values.reason }) });
    } else if (button.dataset.maintenanceOrder === 'complete') {
      const meterField = current.meter_type ? [{ name: 'meterAtClose', label: current.meter_type === 'HOROMETRO' ? 'Horómetro al cierre (h)' : 'Kilometraje al cierre (km)', type: 'number', value: current.meter_at_open ?? 0 }] : [];
      const values = await askFields('Completar orden', [
        { name: 'result', label: 'Resultado', type: 'select', value: 'APTO', options: ['APTO','APTO_CON_OBSERVACIONES','NO_APTO'] },
        ...meterField,
        { name: 'findings', label: 'Hallazgos', type: 'textarea' },
        { name: 'workPerformed', label: 'Trabajo realizado', type: 'textarea' }
      ], { confirmText: 'Completar' });
      if (!values) return;
      await api(`/api/v1/maintenance/orders/${current.id}/complete`, { method: 'POST', body: JSON.stringify({ version: current.version, meterAtClose: current.meter_type ? Number(values.meterAtClose) : null, result: values.result, findings: values.findings, workPerformed: values.workPerformed, condition: values.result === 'NO_APTO' ? 'DANADO' : 'CONFORME', checklist: { verificacion: true }, reason: 'Cierre técnico desde interfaz.' }) });
    } else {
      const values = await askFields('Cancelar orden', [{ name: 'reason', label: 'Motivo de cancelación', type: 'textarea' }], { confirmText: 'Cancelar orden', danger: true });
      if (!values) return;
      await api(`/api/v1/maintenance/orders/${current.id}/cancel`, { method: 'POST', body: JSON.stringify({ version: current.version, reason: values.reason }) });
    }
    flash('Orden actualizada.'); await loadMaintenance();
  } catch (e) { flash(e.message, 'error'); }
});

function notificationOpenAction(notification) {
  if (notification.entity_type === 'custody') return 'custody';
  if (notification.entity_type === 'incident') return 'incident';
  if (notification.entity_type === 'custody_integrity_anomaly') return 'custody-integrity';
  if (notification.entity_type === 'request') return 'request';
  return null;
}

async function loadNotifications() {
  const unread = $('#notifications-unread').checked;
  const data = await api(`/api/v1/notifications?limit=500${unread ? '&unread=true' : ''}`);
  state.notifications = data.items;
  renderNotificationCount(unread ? data.items : (await api('/api/v1/notifications?limit=500&unread=true')).items);
  $('#notifications-body').innerHTML = data.items.length ? data.items.map((item) => {
    const openAction = notificationOpenAction(item);
    return `<tr><td>${escapeHtml(formatDateTime(item.scheduled_at))}</td><td>${escapeHtml(uiCodeLabel(item.type))}</td><td><strong>${escapeHtml(item.subject)}</strong></td><td>${escapeHtml(item.body)}</td><td><span class="status ${item.read_at ? 'ok' : 'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td class="actions">${openAction ? `<button data-notification-open="${openAction}" data-id="${item.id}">Abrir</button>` : ''}${item.read_at ? '' : `<button data-notification-read="${item.id}">Leída</button>`}</td></tr>`;
  }).join('') : '<tr><td colspan="6">No hay notificaciones para mostrar.</td></tr>';
}

$('#notifications-refresh').addEventListener('click', () => loadNotifications().catch((error) => flash(error.message, 'error')));
$('#notifications-unread').addEventListener('change', () => loadNotifications().catch((error) => flash(error.message, 'error')));
$('#notifications-read-all').addEventListener('click', async () => {
  try { await api('/api/v1/notifications/read-all', { method: 'POST', body: '{}' }); flash('Notificaciones marcadas como leídas.'); await loadNotifications(); }
  catch (error) { flash(error.message, 'error'); }
});
$('#notifications-body').addEventListener('click', async (event) => {
  const readButton = event.target.closest('[data-notification-read]');
  const openButton = event.target.closest('[data-notification-open]');
  try {
    if (readButton) {
      await api(`/api/v1/notifications/${readButton.dataset.notificationRead}/read`, { method: 'POST', body: '{}' });
      await loadNotifications();
      return;
    }
    if (!openButton) return;
    const notification = state.notifications.find((item) => item.id === openButton.dataset.id);
    if (!notification) return;
    if (!notification.read_at) await api(`/api/v1/notifications/${notification.id}/read`, { method: 'POST', body: '{}' });
    if (openButton.dataset.notificationOpen === 'custody') {
      setView('custodies');
      await loadCustodies();
      return renderCustodyDetail((await api(`/api/v1/custodies/${notification.entity_id}`)).custody);
    }
    if (openButton.dataset.notificationOpen === 'incident') {
      setView('incidents');
      await loadIncidents();
      return renderIncidentDetail((await api(`/api/v1/incidents/${notification.entity_id}`)).incident);
    }
    if (openButton.dataset.notificationOpen === 'custody-integrity') {
      setView('custodies');
      await loadCustodies();
      $('#custody-integrity-body')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (openButton.dataset.notificationOpen === 'request') {
      setView('requests');
      await loadRequests();
      return renderRequestDetail((await api(`/api/v1/requests/${notification.entity_id}`)).request);
    }
  } catch (error) { flash(error.message, 'error'); }
});



