
function requestUsesSimpleWarehouseFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (!items.length) return false;
  if (String(request?.operation_type || '').toUpperCase() !== 'RETIRO') return false;
  return items.every((item) => ['CANTIDAD','CONSUMIBLE'].includes(String(item.category_nature || '').toUpperCase()));
}

function requestUsesVehicleWarehouseFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  return items.length === 1 && String(request?.operation_type || '').toUpperCase() === 'RETIRO' && String(items[0]?.category_nature || '').toUpperCase() === 'VEHICULO' && Number(items[0]?.quantity || 0) === 1;
}

function requestUsesSerializedWarehouseFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (!items.length) return false;
  if (String(request?.operation_type || '').toUpperCase() !== 'RETIRO') return false;
  return items.every((item) => String(item.category_nature || '').toUpperCase() === 'SERIADO' && Number(item.quantity || 0) === 1);
}

function custodyUsesSimpleWarehouseFlow(custody) {
  return ['CANTIDAD','CONSUMIBLE'].includes(String(custody?.category_nature || '').toUpperCase());
}

function custodyUsesVehicleWarehouseFlow(custody) { return String(custody?.category_nature || '').toUpperCase() === 'VEHICULO'; }

function custodyUsesSerializedWarehouseFlow(custody) {
  return String(custody?.category_nature || '').toUpperCase() === 'SERIADO';
}

function custodyUsesKitWarehouseFlow(custody) {
  return String(custody?.category_nature || '').toUpperCase() === 'KIT';
}

function custodySerializedReturnHasProblem(custody) {
  const declaration = custody?.returnDeclaration;
  return Boolean(declaration && (Number(declaration.problem_reported || 0) === 1 || String(declaration.condition || '').toUpperCase() !== 'CONFORME'));
}

function custodyRequiresRequesterReturn(custody) {
  return ['SERIADO', 'KIT', 'VEHICULO'].includes(String(custody?.category_nature || '').toUpperCase());
}

function custodyCanBeReceivedByWarehouse(custody) {
  if (!custody) return false;
  if (custodyUsesVehicleWarehouseFlow(custody)) {
    if (custody.status !== 'DEVOLUCION_DECLARADA') return false;
    const supervision = custody.vehicleReturnSupervision;
    return Boolean(supervision && String(supervision.status || '').toUpperCase() === 'APROBADA');
  }
  if (custodyRequiresRequesterReturn(custody)) return custody.status === 'DEVOLUCION_DECLARADA';
  return ['ABIERTA', 'DEVOLUCION_DECLARADA'].includes(custody.status);
}

function custodyVehicleNeedsSupervisor(custody) {
  const supervision = custody?.vehicleReturnSupervision;
  return custodyUsesVehicleWarehouseFlow(custody) && custody?.status === 'DEVOLUCION_DECLARADA' && supervision && String(supervision.status || '').toUpperCase() === 'PENDIENTE';
}

function currentUserIsVehicleSupervisor(custody) {
  const supervision = custody?.vehicleReturnSupervision;
  return Boolean(supervision && state.user && String(supervision.supervisor_user_id) === String(state.user.id) && can('Vehicles.SuperviseReturn'));
}

async function loadRequests() {
  const params = dashboardFilterParams('requests');
  if (!params.has('statuses')) params.set('status', $('#request-admin-status').value); params.set('search', $('#request-admin-search').value); if (!params.has('neededBefore')) params.set('overdue', $('#request-admin-overdue').checked ? 'true' : ''); params.set('limit', '300');
  const data = await api(`/api/v1/requests?${params}`);
  state.requests = data.items;
  $('#requests-body').innerHTML = data.items.map((request) => {
    const receivable = (request.custodies || []).filter(custodyCanBeReceivedByWarehouse);
    return `<tr>
      <td><strong>${escapeHtml(request.request_number)}</strong><div class="small">${escapeHtml(request.site_code)} · v${request.version}</div></td>
      <td>${escapeHtml(request.requester_name)}<div class="small">${escapeHtml(request.requester_document || '')}</div></td>
      <td>${escapeHtml(uiCodeLabel(request.operation_type))}<div class="small">${escapeHtml(request.location_name)}</div></td>
      <td>${request.items.length}<div class="small">${escapeHtml(request.items.map((item) => `${item.internal_code} × ${item.quantity}`).join(' · '))}</div></td>
      <td>${escapeHtml(formatDateTime(request.needed_at))}${request.due_at ? `<div class="small">Hasta ${escapeHtml(formatDateTime(request.due_at))}</div>` : ''}</td>
      <td><span class="status ${requestStatusClass(request.status)}">${escapeHtml(requestStatusLabel(request.status))}</span>${request.approval_required ? '<div class="small">Requiere autorización</div>' : ''}${receivable.length ? '<div class="small">Pendiente de recibir</div>' : ''}</td>
      <td class="actions"><button data-request-action="detail" data-id="${request.id}">Detalle</button>
        ${can('Requests.Approve') && request.status === 'PENDIENTE_AUTORIZACION' ? `<button data-request-action="approve" data-id="${request.id}">Aprobar</button><button data-request-action="reject" data-id="${request.id}">Rechazar</button>` : ''}
        ${can('Warehouse.Operate') && request.status === 'APROBADA' && requestUsesSimpleWarehouseFlow(request) ? `<button class="primary" data-request-action="quick-handover" data-id="${request.id}">ENTREGAR</button>` : ''}
        ${can('Warehouse.Operate') && request.status === 'APROBADA' && requestUsesSerializedWarehouseFlow(request) ? `<button class="primary" data-request-action="serialized-handover" data-id="${request.id}">ENTREGAR</button>` : ''}
        ${can('Warehouse.Operate') && request.status === 'APROBADA' && requestUsesVehicleWarehouseFlow(request) ? `<button class="primary" data-request-action="vehicle-handover" data-id="${request.id}">ENTREGAR VEHÍCULO</button>` : ''}
        ${can('Warehouse.Prepare') && request.status === 'APROBADA' && requestUsesSimpleWarehouseFlow(request) ? `<button data-request-action="prepare" data-id="${request.id}">NO PUEDO ENTREGAR</button>` : ''}
        ${can('Warehouse.Prepare') && request.status === 'APROBADA' && !requestUsesSimpleWarehouseFlow(request) && !requestUsesSerializedWarehouseFlow(request) && !requestUsesVehicleWarehouseFlow(request) ? `<button data-request-action="prepare" data-id="${request.id}">Preparar</button>` : ''}
        ${can('Warehouse.Prepare') && request.status === 'PREPARANDO' ? `<button data-request-action="ready" data-id="${request.id}">Marcar lista</button>` : ''}
        ${can('Warehouse.Operate') && request.status === 'LISTA_PARA_ENTREGA' ? `<button data-request-action="handover" data-id="${request.id}">Entregar</button>` : ''}
        ${can('Warehouse.Operate') && receivable.length ? `<button class="primary" data-request-action="return" data-id="${request.id}">REVISAR DEVOLUCIÓN${receivable.length > 1 ? ` (${receivable.length})` : ''}</button>` : ''}
        ${can('Requests.CancelAny') && !['CANCELADA','EXPIRADA','ENTREGADA','PREPARANDO','LISTA_PARA_ENTREGA'].includes(request.status) ? `<button data-request-action="cancel" data-id="${request.id}">Cancelar</button>` : ''}
      </td></tr>`;
  }).join('') || '<tr><td colspan="7">No hay solicitudes para los filtros seleccionados.</td></tr>';
}

async function refreshRequestWorkflow(requestId) {
  clearDashboardFilter('requests');
  $('#request-admin-status').value = '';
  $('#request-admin-overdue').checked = false;
  await loadRequests();
  if (!state.requests.some((item) => item.id === requestId)) {
    $('#request-admin-search').value = '';
    await loadRequests();
  }
  const action = $(`#requests-body [data-id="${CSS.escape(requestId)}"]`);
  action?.closest('tr')?.scrollIntoView({ block: 'nearest' });
  if (typeof refreshWarehouseOperationalViews === 'function' && can('Warehouse.Operate')) await refreshWarehouseOperationalViews({ silent: true });
}

function renderRequestDetail(request) {
  state.currentRequest = request;
  $('#request-detail-title').textContent = `${request.request_number} · ${requestStatusLabel(request.status)}`;
  const decisionActions = can('Requests.Approve') && request.status === 'PENDIENTE_AUTORIZACION'
    ? `<div class="actions request-detail-primary-actions"><button type="button" class="primary" data-request-detail-decision="approve">APROBAR</button><button type="button" data-request-detail-decision="reject">RECHAZAR</button></div>`
    : '';
  const approvals = request.approvals.length ? request.approvals.map((item) => `<li><strong>${escapeHtml(item.decision === 'APROBADA' ? 'Aprobada' : item.decision === 'RECHAZADA' ? 'Rechazada' : item.decision)}</strong> · ${escapeHtml(item.approver_name)} · ${escapeHtml(formatDateTime(item.decided_at))}${item.reason ? `<br>${escapeHtml(item.reason)}` : ''}</li>`).join('') : '<li>Sin decisiones registradas.</li>';
  const events = request.events.map((item) => `<li>${escapeHtml(formatDateTime(item.occurred_at))} · ${escapeHtml(requestStatusLabel(item.from_status || 'INICIO'))} → <strong>${escapeHtml(requestStatusLabel(item.to_status))}</strong>${item.reason ? ` · ${escapeHtml(item.reason)}` : ''}</li>`).join('');
  $('#request-detail-content').innerHTML = `<div class="request-summary-grid">
    <div><span>Pedido</span><strong>${escapeHtml(request.request_number)}</strong></div><div><span>Solicitante</span><strong>${escapeHtml(request.requester_name)}</strong></div>
    <div><span>Qué hay que hacer</span><strong>${escapeHtml(requestStatusLabel(request.status))}</strong></div><div><span>Ubicación</span><strong>${escapeHtml(request.location_name)}</strong></div>
    <div><span>Necesidad</span><strong>${escapeHtml(formatDateTime(request.needed_at))}</strong></div><div><span>Devolución prevista</span><strong>${escapeHtml(formatDateTime(request.due_at))}</strong></div>
  </div><p><strong>Motivo:</strong> ${escapeHtml(request.reason)}</p>${decisionActions}
  ${request.evidence?.length ? `<h4>Fotos</h4><div class="actions">${request.evidence.map((item) => `<button data-evidence-download="${item.id}" data-evidence-name="${escapeHtml(item.filename)}">VER FOTO</button>`).join('')}</div>` : ''}
  <h4>Bienes</h4><div class="table-wrap"><table><thead><tr><th>Código</th><th>Descripción</th><th>Cantidad</th><th>OT</th><th>Estado</th></tr></thead><tbody>${request.items.map((item) => `<tr><td>${escapeHtml(item.internal_code)}</td><td>${escapeHtml(item.description)}</td><td>${item.quantity} ${escapeHtml(item.unit_of_measure || '')}</td><td>${item.work_order_required ? `<strong>${escapeHtml(item.work_order_reference || 'FALTANTE')}</strong>` : 'No requerida'}</td><td>${escapeHtml(requestStatusLabel(item.status))}</td></tr>`).join('')}</tbody></table></div>
  ${request.preparation ? `<p><strong>Preparación:</strong> ${escapeHtml(requestStatusLabel(request.preparation.status))} · ${escapeHtml(request.preparation.operator_name || request.preparation.username || '')}</p>` : ''}
  ${request.custodies?.length ? `<h4>Bienes entregados</h4><ul>${request.custodies.map((item) => `<li>${escapeHtml(item.internal_code || item.id)} · ${escapeHtml(custodyStatusLabel(item.status))}${item.due_at ? ` · devuelve ${escapeHtml(formatDateTime(item.due_at))}` : ''}${can('Warehouse.Operate') && custodyCanBeReceivedByWarehouse(item) ? ` · <button data-request-custody-receive="${item.id}">${escapeHtml(warehouseReceiveActionLabel(item))}</button>` : ''}</li>`).join('')}</ul>` : ''}
  <details class="detail-technical"><summary>Ver trazabilidad completa</summary><div class="grid request-history"><section><h4>Aprobaciones</h4><ol>${approvals}</ol></section><section><h4>Historial</h4><ol>${events}</ol></section></div></details>`;
  $('#request-detail-dialog').showModal();
}

$('#request-admin-refresh').addEventListener('click', () => loadRequests().catch((error) => flash(error.message, 'error')));
$('#request-admin-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadRequests().catch((error) => flash(error.message, 'error')); });
$('#requests-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-request-action]'); if (!button) return;
  const current = state.requests.find((item) => item.id === button.dataset.id); if (!current) return;
  try {
    if (button.dataset.requestAction === 'detail') return renderRequestDetail((await api(`/api/v1/requests/${current.id}`)).request);
    if (button.dataset.requestAction === 'quick-handover') {
      button.disabled = true;
      const originalText = button.textContent;
      button.textContent = 'ENTREGANDO…';
      try {
        const result = await requestWorkflowApi(`/api/v1/requests/${current.id}/quick-handover`, {
          method: 'POST',
          headers: { 'Idempotency-Key': newIdempotencyKey('quick-handover') },
          body: JSON.stringify({ version: current.version })
        });
        flash(`Entregado a ${current.requester_name}. ${result.handover?.custodies?.length ? 'Custodia abierta.' : 'Stock actualizado.'}`);
        return refreshRequestWorkflow(current.id);
      } finally {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
    if (button.dataset.requestAction === 'serialized-handover') {
      button.disabled = true;
      const originalText = button.textContent;
      button.textContent = 'ENTREGANDO…';
      try {
        const result = await requestWorkflowApi(`/api/v1/requests/${current.id}/serialized-handover`, {
          method: 'POST',
          headers: { 'Idempotency-Key': newIdempotencyKey('serialized-handover') },
          body: JSON.stringify({ version: current.version })
        });
        flash(`Bien serializado entregado a ${current.requester_name}. Custodia abierta.`);
        return refreshRequestWorkflow(current.id);
      } finally {
        button.disabled = false;
        button.textContent = originalText;
      }
    }

    if (button.dataset.requestAction === 'vehicle-handover') {
      button.disabled = true; const originalText = button.textContent; button.textContent = 'ENTREGANDO…';
      try {
        const detail = (await api(`/api/v1/requests/${current.id}/vehicle-detail`)).vehicleDetail;
        const values = await askFields('Confirmar entrega del vehículo', [
          { name:'odometer', label:'Kilometraje', type:'number', value:detail.departure_odometer },
          { name:'fuelLevelPercent', label:'Combustible', type:'select', value:String(detail.departure_fuel_percent), options:[{value:'100',label:'Lleno'},{value:'75',label:'3/4'},{value:'50',label:'1/2'},{value:'25',label:'1/4'},{value:'10',label:'Reserva'}] },
          { name:'notes', label:'Observación del pañolero', type:'textarea', required:false, value:detail.departure_notes || '' }
        ], { confirmText:'ENTREGAR VEHÍCULO', details:`Conductor: ${detail.driver_name}
Acompañante: ${detail.companion_name || 'Sin acompañante'}
Destino: ${detail.destination}
Exterior: ${detail.departureChecklist?.exterior || '—'} · Neumáticos: ${detail.departureChecklist?.neumaticos || '—'} · Luces: ${detail.departureChecklist?.luces || '—'}
Interior: ${detail.departureChecklist?.interior || '—'} · Documentación: ${detail.departureChecklist?.documentacion || '—'}
Uso responsable: ${Number(detail.disclaimer_accepted)===1 ? 'ACEPTADO' : 'NO ACEPTADO'}` });
        if (!values) return;
        await requestWorkflowApi(`/api/v1/requests/${current.id}/vehicle-handover`, { method:'POST', headers:{'Idempotency-Key':newIdempotencyKey('vehicle-handover')}, body:JSON.stringify({version:current.version,odometer:Number(values.odometer),fuelLevelPercent:Number(values.fuelLevelPercent),notes:values.notes||null}) });
        flash(`Vehículo entregado a ${current.requester_name}. Custodia abierta.`); return refreshRequestWorkflow(current.id);
      } finally { button.disabled=false; button.textContent=originalText; }
    }

    if (button.dataset.requestAction === 'prepare') return openPreparationDialog(current.id);
    if (button.dataset.requestAction === 'ready') {
      const detail = (await api(`/api/v1/requests/${current.id}`)).request;
      const preparation = detail.preparation || (await api(`/api/v1/requests/${current.id}/preparation`)).preparation;
      if (!preparation) throw new Error('No existe una preparación abierta.');
      await requestWorkflowApi(`/api/v1/requests/${current.id}/ready`, { method: 'POST', body: JSON.stringify({ version: detail.version, preparationVersion: preparation.version, reason: 'Preparación física completa y verificada.' }) });
      flash('Solicitud lista para entrega.');
      return refreshRequestWorkflow(current.id);
    }
    if (button.dataset.requestAction === 'handover') return openHandoverDialog(current.id);
    if (button.dataset.requestAction === 'return') return openRequestReturnDialog(current.id);
    if (button.dataset.requestAction === 'approve') {
      await requestWorkflowApi(`/api/v1/requests/${current.id}/approve`, { method: 'POST', body: JSON.stringify({ version: current.version }) });
      flash('Solicitud aprobada y bienes reservados.');
      return refreshRequestWorkflow(current.id);
    }
    if (button.dataset.requestAction === 'reject') {
      const values = await askFields('Rechazar solicitud', [{ name: 'reason', label: 'Fundamento de rechazo', type: 'textarea' }], { confirmText: 'Rechazar', danger: true });
      if (!values) return;
      const reason = values.reason;
      await requestWorkflowApi(`/api/v1/requests/${current.id}/reject`, { method: 'POST', body: JSON.stringify({ version: current.version, reason }) }); flash('Solicitud rechazada.'); return refreshRequestWorkflow(current.id);
    }
    if (button.dataset.requestAction === 'cancel') {
      const values = await askFields('Cancelar solicitud', [{ name: 'reason', label: 'Motivo de cancelación', type: 'textarea' }], { confirmText: 'Cancelar solicitud', danger: true });
      if (!values) return;
      const reason = values.reason;
      await requestWorkflowApi(`/api/v1/requests/${current.id}/cancel`, { method: 'POST', body: JSON.stringify({ version: current.version, reason }) }); flash('Solicitud cancelada y reservas liberadas.'); return refreshRequestWorkflow(current.id);
    }
  } catch (error) { flash(error.message, 'error'); }
});


$('#request-detail-content').addEventListener('click', async (event) => {
  const evidenceButton = event.target.closest('[data-evidence-download]');
  if (evidenceButton) {
    try { return downloadFile(`/api/v1/evidence/${evidenceButton.dataset.evidenceDownload}`, evidenceButton.dataset.evidenceName || 'foto.jpg'); }
    catch (error) { flash(error.message, 'error'); return; }
  }
  const decisionButton = event.target.closest('[data-request-detail-decision]');
  if (decisionButton) {
    const request = state.currentRequest;
    if (!request) return;
    try {
      if (decisionButton.dataset.requestDetailDecision === 'approve') {
        decisionButton.disabled = true;
        await requestWorkflowApi(`/api/v1/requests/${request.id}/approve`, { method:'POST', body:JSON.stringify({ version:request.version }) });
        $('#request-detail-dialog').close();
        flash('Solicitud aprobada.');
        return refreshRequestWorkflow(request.id);
      }
      const values = await askFields('Rechazar solicitud', [{ name:'reason', label:'Motivo del rechazo', type:'textarea' }], { confirmText:'RECHAZAR', danger:true });
      if (!values) return;
      await requestWorkflowApi(`/api/v1/requests/${request.id}/reject`, { method:'POST', body:JSON.stringify({ version:request.version, reason:values.reason }) });
      $('#request-detail-dialog').close();
      flash('Solicitud rechazada.');
      return refreshRequestWorkflow(request.id);
    } catch (error) {
      decisionButton.disabled = false;
      flash(error.message, 'error');
      return;
    }
  }
  const button = event.target.closest('[data-request-custody-receive]');
  if (!button) return;
  try { $('#request-detail-dialog').close(); renderCustodyDetail((await api(`/api/v1/custodies/${button.dataset.requestCustodyReceive}`)).custody); }
  catch (error) { flash(error.message, 'error'); }
});

$('#request-return-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-request-return-custody]');
  if (!button) return;
  const custody = (state.requestReturnCustodies || []).find((item) => item.id === button.dataset.requestReturnCustody);
  if (!custody) return;
  $('#request-return-dialog').close();
  try { renderCustodyDetail((await api(`/api/v1/custodies/${custody.id}`)).custody); }
  catch (error) { flash(error.message, 'error'); }
});


function newIdempotencyKey(prefix) {
  return `${prefix}:${crypto.randomUUID()}`;
}

function dateTimeLocalValue(value) {
  const date = value ? new Date(value) : new Date();
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function formatElapsedSeconds(seconds) {
  const value = Math.max(0, Number(seconds) || 0);
  const days = Math.floor(value / 86400);
  const hours = Math.floor((value % 86400) / 3600);
  const minutes = Math.floor((value % 3600) / 60);
  return [days ? `${days} d` : '', hours ? `${hours} h` : '', minutes || (!days && !hours) ? `${minutes} min` : ''].filter(Boolean).join(' ');
}

function custodyTemporalSituation(custody, at = new Date()) {
  if (String(custody?.status || '').toUpperCase() === 'DEVOLUCION_DECLARADA') {
    const late = custody?.due_at && new Date(custody.due_at).getTime() < (at instanceof Date ? at : new Date(at)).getTime();
    return { code: 'DEVOLUCION_DECLARADA', label: late ? 'Pendiente de recibir · declarada fuera de término' : 'Pendiente de recibir', className: 'neutral', overdueSeconds: 0 };
  }
  if (!custody?.due_at) return { code: 'SIN_VENCIMIENTO', label: 'Sin vencimiento definido', className: 'neutral', overdueSeconds: 0 };
  const due = new Date(custody.due_at);
  const moment = at instanceof Date ? at : new Date(at);
  const seconds = Math.floor((moment.getTime() - due.getTime()) / 1000);
  if (seconds > 0) return { code: 'FUERA_DE_TERMINO', label: `Fuera de término · ${formatElapsedSeconds(seconds)} de atraso`, className: 'danger', overdueSeconds: seconds };
  return { code: 'EN_TERMINO', label: `En término · restan ${formatElapsedSeconds(Math.abs(seconds))}`, className: 'ok', overdueSeconds: 0 };
}

function updateReceiveTiming() {
  const custody = state.currentReturnCustody;
  if (!custody) return;
  const value = $('#receive-at').value;
  const situation = custodyTemporalSituation(custody, value ? new Date(value) : new Date());
  const node = $('#receive-timing');
  node.textContent = situation.label;
  node.className = `status ${situation.className}`;
}

function updateReceiveConditionUi() {
  const custody = state.currentReturnCustody;
  if (!custody) return;
  const comment = $('#receive-notes').value.trim();
  const vehicle = custodyUsesVehicleWarehouseFlow(custody);
  if (!vehicle && comment && $('#receive-condition').value === 'CONFORME') $('#receive-condition').value = 'OBSERVADO';
  const anomalous = $('#receive-condition').value !== 'CONFORME';
  $('#receive-notes').required = anomalous && !custody.returnDeclaration?.notes;
  $('#receive-incident-warning').classList.toggle('hidden', !anomalous);
  $('#receive-submit').textContent = anomalous ? '⚠ ACEPTAR Y BLOQUEAR' : '✓ ACEPTAR DEVOLUCIÓN';
}

function openReceiveDialog(custody) {
  state.currentReturnCustody = custody;
  $('#receive-form').reset();
  $('#receive-custody-id').value = custody.id;
  $('#receive-custody-version').value = custody.version;
  $('#receive-at').value = dateTimeLocalValue(new Date());
  $('#receive-dialog-title').textContent = custodyRequiresRequesterReturn(custody) ? 'Recepción física de devolución' : 'Recepción física';
  const declarationHtml = custody.returnDeclaration ? `<div class="return-declaration-box"><strong>Declaración del usuario:</strong> ${escapeHtml(conditionLabel(custody.returnDeclaration.condition || 'CONFORME'))}${Number(custody.returnDeclaration.problem_reported || 0) === 1 ? ' · informó problema' : ''}${custody.returnDeclaration.notes ? `<br>${escapeHtml(custody.returnDeclaration.notes)}` : ''}</div>` : '<div class="small">Sin observaciones declaradas por el usuario.</div>';
  const quantityReturn = String(custody.category_nature || '').toUpperCase() === 'CANTIDAD' && Number(custody.requires_return || 0) === 1;
  const outstanding = Number(custody.quantity_outstanding ?? custody.quantity ?? 0);
  const returned = Number(custody.returned_quantity || 0);
  const declaredQuantity = quantityReturn ? Number(custody.returnDeclaration?.requested_quantity || 0) : 0;
  const receivableMax = quantityReturn && declaredQuantity > 0 ? Math.min(outstanding, declaredQuantity) : outstanding;
  $('#receive-summary').innerHTML = `<strong>${escapeHtml(custody.internal_code)} · ${escapeHtml(custody.description)}</strong><div class="small">Custodio: ${escapeHtml(custody.custodian_name)} · Solicitud: ${escapeHtml(custody.request_number)} · Vencimiento: ${escapeHtml(formatDateTime(custody.due_at))}</div>${quantityReturn ? `<div class="small"><strong>Entregado:</strong> ${escapeHtml(custody.quantity)} · <strong>Ya devuelto:</strong> ${escapeHtml(returned)} · <strong>Pendiente total:</strong> ${escapeHtml(outstanding)}${declaredQuantity > 0 ? ` · <strong>Declarado ahora:</strong> ${escapeHtml(declaredQuantity)}` : ''}</div>` : ''}${declarationHtml}`;
  $('#receive-quantity-wrap').classList.toggle('hidden', !quantityReturn);
  $('#receive-quantity-status').classList.toggle('hidden', !quantityReturn);
  $('#receive-quantity').required = quantityReturn;
  $('#receive-quantity').disabled = !quantityReturn;
  $('#receive-quantity').max = quantityReturn ? String(receivableMax) : '';
  $('#receive-quantity').value = quantityReturn ? String(receivableMax) : '';
  $('#receive-quantity-status').textContent = quantityReturn ? (declaredQuantity > 0 ? `Declarado para esta devolución: ${declaredQuantity}. Saldo total pendiente: ${outstanding}.` : `Podés recibir una parte. Saldo máximo pendiente: ${outstanding}.`) : '';
  const declaredCondition = returnDeclarationCondition(custody);
  $('#receive-condition').value = ['CONFORME','OBSERVADO','DANADO','INCOMPLETO'].includes(declaredCondition) ? declaredCondition : 'CONFORME';
  $('#receive-notes').value = '';
  updateReceiveConditionUi();
  updateReceiveTiming();
  $('#receive-dialog').showModal();
}

async function openRequestReturnDialog(requestId) {
  const detail = (await api(`/api/v1/requests/${requestId}`)).request;
  const ids = (detail.custodies || []).filter(custodyCanBeReceivedByWarehouse).map((item) => item.id);
  const custodies = await Promise.all(ids.map(async (id) => (await api(`/api/v1/custodies/${id}`)).custody));
  if (!custodies.length) throw new Error('La solicitud no tiene devoluciones habilitadas para recepción física.');
  if (custodies.length === 1) return renderCustodyDetail(custodies[0]);
  state.requestReturnCustodies = custodies;
  $('#request-return-title').textContent = `Recepción física · ${detail.request_number}`;
  $('#request-return-body').innerHTML = custodies.map((custody) => {
    const timing = custodyTemporalSituation(custody);
    return `<tr><td><strong>${escapeHtml(custody.internal_code)}</strong><div class="small">${escapeHtml(custody.description)}</div></td><td>${escapeHtml(custody.custodian_name)}</td><td>${escapeHtml(formatDateTime(custody.due_at))}</td><td><span class="status ${timing.className}">${escapeHtml(timing.label)}</span></td><td><button class="primary" data-request-return-custody="${custody.id}">${escapeHtml(warehouseReceiveActionLabel(custody))}</button></td></tr>`;
  }).join('');
  $('#request-return-dialog').showModal();
}

async function openPreparationDialog(requestId) {
  const detail = (await api(`/api/v1/requests/${requestId}`)).request;
  state.currentRequest = detail;
  const rows = await Promise.all(detail.items.map(async (item) => {
    const params = new URLSearchParams({ availableOnly: 'true', categoryId: item.category_id, locationId: detail.location_id, limit: '250' });
    const available = (await api(`/api/v1/assets?${params}`)).items;
    const candidates = [{ id: item.asset_id, internal_code: item.internal_code, description: item.description, status: item.asset_status || 'RESERVADO' }, ...available.filter((asset) => asset.id !== item.asset_id)];
    return { item, candidates };
  }));
  $('#preparation-request-id').value = detail.id;
  $('#preparation-request-version').value = detail.version;
  $('#preparation-observations').value = '';
  $('#preparation-items').innerHTML = rows.map(({ item, candidates }) => `<article class="preparation-item" data-request-item-id="${item.id}" data-requested-asset-id="${item.asset_id}">
    <div><strong>${escapeHtml(item.internal_code)} · ${escapeHtml(item.description)}</strong><div class="small">${escapeHtml(item.category_name)} · Cantidad ${item.quantity}</div></div>
    <label>Unidad preparada<select data-field="preparedAssetId">${candidates.map((asset) => `<option value="${asset.id}" ${asset.id === item.asset_id ? 'selected' : ''}>${escapeHtml(asset.internal_code)} · ${escapeHtml(asset.description)} · ${escapeHtml(uiCodeLabel(asset.status))}</option>`).join('')}</select></label>
    <label>Condición<select data-field="condition"><option value="CONFORME">Conforme</option><option value="OBSERVADO">Con observación</option></select></label>
    <label>Observaciones<input data-field="notes" maxlength="1500"></label>
    <label class="substitution-reason hidden">Fundamento de sustitución<input data-field="substitutionReason" maxlength="1000"></label>
  </article>`).join('');
  $$('#preparation-items [data-field="preparedAssetId"]').forEach((select) => select.addEventListener('change', () => {
    const row = select.closest('.preparation-item');
    row.querySelector('.substitution-reason').classList.toggle('hidden', select.value === row.dataset.requestedAssetId);
  }));
  $('#preparation-dialog').showModal();
}

$('#preparation-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const items = $$('.preparation-item', $('#preparation-items')).map((row) => {
      const preparedAssetId = row.querySelector('[data-field="preparedAssetId"]').value;
      const changed = preparedAssetId !== row.dataset.requestedAssetId;
      return {
        requestItemId: row.dataset.requestItemId,
        preparedAssetId,
        quantity: Number(state.currentRequest.items.find((item) => item.id === row.dataset.requestItemId).quantity),
        condition: row.querySelector('[data-field="condition"]').value,
        notes: row.querySelector('[data-field="notes"]').value || null,
        substitutionReason: changed ? (row.querySelector('[data-field="substitutionReason"]').value || 'Sustitución equivalente confirmada durante preparación física.') : null
      };
    });
    const requestId = $('#preparation-request-id').value;
    await requestWorkflowApi(`/api/v1/requests/${requestId}/prepare`, { method: 'POST', body: JSON.stringify({ version: Number($('#preparation-request-version').value), items, observations: $('#preparation-observations').value || null }) });
    $('#preparation-dialog').close(); flash('Preparación registrada. Ya está habilitado Marcar lista.'); await refreshRequestWorkflow(requestId);
  } catch (error) { flash(error.message, 'error'); }
});

async function openHandoverDialog(requestId) {
  const detail = (await api(`/api/v1/requests/${requestId}`)).request;
  state.currentRequest = detail;
  $('#handover-form').reset();
  $('#handover-request-id').value = detail.id; $('#handover-request-version').value = detail.version;
  $('#handover-acceptance-method').value = 'EXPLICITA'; $('#handover-pin-label').classList.add('hidden');
  $('#handover-dialog').showModal();
}

$('#handover-acceptance-method').addEventListener('change', () => {
  const pin = $('#handover-acceptance-method').value === 'PIN';
  $('#handover-pin-label').classList.toggle('hidden', !pin); $('#handover-acceptance-value').required = pin;
});

$('#handover-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const method = $('#handover-acceptance-method').value;
    const requestId = $('#handover-request-id').value;
    const result = await requestWorkflowApi(`/api/v1/requests/${requestId}/handover`, { method: 'POST', headers: { 'Idempotency-Key': newIdempotencyKey('handover') }, body: JSON.stringify({
      version: Number($('#handover-request-version').value), acceptanceMethod: method, acceptanceConfirmed: $('#handover-acceptance-confirmed').checked,
      acceptanceValue: method === 'PIN' ? $('#handover-acceptance-value').value : null, observations: $('#handover-observations').value || null
    }) });
    $('#handover-dialog').close(); flash(`Entrega confirmada. ${result.handover.custodies.length} custodia(s) abierta(s).`); await refreshRequestWorkflow(requestId);
  } catch (error) { flash(error.message, 'error'); }
});

function custodyStatusClass(status, overdue = false) {
  if ((overdue && status !== 'DEVOLUCION_DECLARADA') || ['INCIDENTE'].includes(status)) return 'danger';
  if (status === 'CERRADA') return 'ok';
  return 'neutral';
}

function vehicleChecklistLabel(key) {
  return ({ exterior:'Exterior', neumaticos:'Neumáticos', luces:'Luces', interior:'Interior', documentacion:'Documentación' })[String(key || '').toLowerCase()] || uiCodeLabel(key);
}

function custodyDetailChecklist(title, checklist) {
  const entries = Object.entries(checklist || {});
  if (!entries.length) return `<div><span>${escapeHtml(title)}</span><strong>Sin datos</strong></div>`;
  return `<div><span>${escapeHtml(title)}</span><strong>${entries.map(([key,value]) => `${escapeHtml(vehicleChecklistLabel(key))}: ${escapeHtml(uiCodeLabel(value))}`).join(' · ')}</strong></div>`;
}

function renderCustodyDetail(custody) {
  state.currentCustody = custody;
  $('#custody-detail-title').textContent = `${custody.internal_code} · ${custodyStatusLabel(custody.status)}`;
  const events = custody.events?.length ? custody.events.map((item) => `<li>${escapeHtml(formatDateTime(item.occurred_at))} · ${escapeHtml(uiCodeLabel(item.from_status || 'INICIO'))} → <strong>${escapeHtml(uiCodeLabel(item.to_status))}</strong>${item.reason ? ` · ${escapeHtml(item.reason)}` : ''}</li>`).join('') : '<li>Sin eventos.</li>';
  const inspections = custody.inspections?.length ? custody.inspections.map((item) => `<tr><td>${escapeHtml(formatDateTime(item.occurred_at))}</td><td>${escapeHtml(uiCodeLabel(item.phase))}</td><td>${escapeHtml(uiCodeLabel(item.condition))}</td><td>${escapeHtml(uiCodeLabel(item.result))}</td><td>${escapeHtml(item.inspector_name)}</td><td>${escapeHtml(item.notes || '')}</td></tr>`).join('') : '<tr><td colspan="6">Sin inspecciones.</td></tr>';
  const incidents = custody.incidents?.length ? custody.incidents.map((item) => `<li><strong>${escapeHtml(uiCodeLabel(item.type))}</strong> · ${escapeHtml(uiCodeLabel(item.status))} · ${escapeHtml(item.description)}</li>`).join('') : '<li>Sin incidentes.</li>';
  const transfers = custody.transfers?.length ? custody.transfers.map((item) => `<li>${escapeHtml(item.from_name)} → ${escapeHtml(item.to_name)} · ${escapeHtml(uiCodeLabel(item.status))} · ${escapeHtml(formatDateTime(item.requested_at))}</li>`).join('') : '<li>Sin transferencias.</li>';
  const temporal = custodyTemporalSituation(custody, custody.returnRecord?.received_at || custody.closed_at || new Date());
  const receiverComment = custody.receptionReview?.operator_comment || null;
  const legacyReception = custody.receptionReview?.source_mode === 'LEGACY_BACKFILL';
  const receptionCommentHtml = legacyReception
    ? (custody.returnRecord?.notes ? `<p><strong>Nota histórica de recepción:</strong> ${escapeHtml(custody.returnRecord.notes)}<br><span class="small">Registro anterior a F22: no es posible separar con certeza si la nota provino del usuario o del pañolero.</span></p>` : '<p class="small">Registro anterior a F22 sin comentario atribuible al receptor.</p>')
    : (receiverComment ? `<p><strong>Comentario del pañolero:</strong> ${escapeHtml(receiverComment)}</p>` : '<p class="small"><strong>Comentario del pañolero:</strong> sin comentario.</p>');
  const returnRecord = custody.returnRecord ? `<article class="detail-block return-record"><h4>Devolución registrada</h4><div class="request-summary-grid">
    <div><span>Fecha real</span><strong>${escapeHtml(formatDateTime(custody.returnRecord.received_at))}</strong></div>
    <div><span>Situación</span><strong>${escapeHtml(uiCodeLabel(custody.returnRecord.timing_status))}${custody.returnRecord.overdue_seconds ? ` · ${escapeHtml(formatElapsedSeconds(custody.returnRecord.overdue_seconds))}` : ''}</strong></div>
    <div><span>Resultado</span><strong>${escapeHtml(conditionLabel(custody.returnRecord.condition))}</strong></div>
    <div><span>Incidente</span><strong>${escapeHtml(custody.returnRecord.incident_id ? 'GENERADO' : 'NO')}</strong></div>
    <div><span>Bloqueado al recibir</span><strong>${escapeHtml(custody.receptionReview?.blocked_after_receipt ? 'SÍ' : 'NO')}</strong></div>
    <div><span>Comentario forzó observación</span><strong>${escapeHtml(custody.receptionReview?.comment_forced_observation ? 'SÍ' : 'NO')}</strong></div>
  </div>${receptionCommentHtml}</article>` : '';

  let specializedReturn = '';
  if (custodyUsesVehicleWarehouseFlow(custody)) {
    const departure = custody.vehicleRequestDetail;
    const returned = custody.vehicleReturnDetail;
    const supervision = custody.vehicleReturnSupervision;
    const distance = departure && returned ? Math.max(0, Number(returned.return_odometer || 0) - Number(departure.departure_odometer || 0)) : null;
    const supervisionStatus = supervision ? String(supervision.status || '').toUpperCase() : 'PENDIENTE';
    const safety = Number(supervision?.safety_observation || 0) === 1;
    const supervisionTone = supervisionStatus === 'PENDIENTE' ? 'warning' : safety ? 'danger' : supervisionStatus === 'APROBADA' ? 'ok' : 'neutral';
    specializedReturn = `<article class="detail-block"><h4>Devolución del vehículo</h4><div class="request-summary-grid">
      <div><span>Km salida</span><strong>${escapeHtml(departure?.departure_odometer ?? '—')}</strong></div>
      <div><span>Km devolución</span><strong>${escapeHtml(returned?.return_odometer ?? '—')}</strong></div>
      <div><span>Distancia recorrida</span><strong>${escapeHtml(distance === null ? '—' : `${distance} km`)}</strong></div>
      <div><span>Combustible salida</span><strong>${escapeHtml(departure?.departure_fuel_percent === null || departure?.departure_fuel_percent === undefined ? '—' : `${departure.departure_fuel_percent}%`)}</strong></div>
      <div><span>Combustible devolución</span><strong>${escapeHtml(returned?.return_fuel_percent === null || returned?.return_fuel_percent === undefined ? '—' : `${returned.return_fuel_percent}%`)}</strong></div>
      <div><span>Condición declarada por mecánico</span><strong>${escapeHtml(uiCodeLabel(returned?.return_condition || custody.returnDeclaration?.condition || '—'))}</strong></div>
      ${custodyDetailChecklist('Checklist de salida', departure?.departureChecklist)}
      ${custodyDetailChecklist('Checklist de devolución', returned?.returnChecklist)}
    </div>${departure?.departure_notes ? `<p><strong>Observaciones de salida:</strong> ${escapeHtml(departure.departure_notes)}</p>` : ''}${returned?.notes ? `<p><strong>Comentario del mecánico:</strong> ${escapeHtml(returned.notes)}</p>` : ''}
    <h4>V°B° del Supervisor</h4>${supervision ? `<div class="request-summary-grid">
      <div><span>Supervisor asignado</span><strong>${escapeHtml(supervision.supervisor_name || supervision.supervisor_username || '—')}</strong></div>
      <div><span>Estado</span><strong><span class="status ${supervisionTone}">${escapeHtml(supervisionStatus === 'PENDIENTE' ? 'PENDIENTE DE INSPECCIÓN' : 'APROBADA')}</span></strong></div>
      <div><span>Observación de Seguridad</span><strong class="${safety ? 'danger-text' : ''}">${safety ? 'SÍ · VEHÍCULO BLOQUEADO' : (supervisionStatus === 'APROBADA' ? 'NO' : 'PENDIENTE')}</strong></div>
      <div><span>Inspección</span><strong>${escapeHtml(supervision.inspected_at ? formatDateTime(supervision.inspected_at) : 'Pendiente')}</strong></div>
    </div>${supervision.supervisor_comment ? `<p><strong>Comentario general del Supervisor:</strong> ${escapeHtml(supervision.supervisor_comment)}</p>` : (supervisionStatus === 'APROBADA' ? '<p class="small"><strong>Comentario general del Supervisor:</strong> sin comentario.</p>' : '<p class="small">El pañol no puede recibir las llaves hasta el V°B° del Supervisor asignado.</p>')}
    ${Array.isArray(supervision.checklistAssessments) && supervision.checklistAssessments.length ? `<h4>Checklist inspeccionado por Supervisor</h4><div class="table-wrap"><table><thead><tr><th>Ítem</th><th>Mecánico</th><th>Supervisor</th><th>Seguridad</th><th>Comentario</th></tr></thead><tbody>${supervision.checklistAssessments.map((item)=>`<tr><td><strong>${escapeHtml(item.checklist_label_snapshot || vehicleChecklistLabel(item.checklist_key))}</strong></td><td>${escapeHtml(uiCodeLabel(item.technician_value_snapshot))}</td><td>${escapeHtml(uiCodeLabel(item.supervisor_value))}</td><td class="${Number(item.safety_observation||0)===1?'danger-text':''}">${Number(item.safety_observation||0)===1?'SÍ':'NO'}</td><td>${escapeHtml(item.supervisor_comment || '—')}</td></tr>`).join('')}</tbody></table></div>` : (supervisionStatus === 'APROBADA' ? '<p class="small">V°B° emitido en F24: no existe evaluación ítem por ítem porque todavía no estaba implementada.</p>' : '')}` : '<p class="small danger-text"><strong>Pendiente de regularización:</strong> esta devolución no tiene V°B° de Supervisor registrado. El pañol no puede recibir las llaves hasta completar una supervisión válida.</p>'}</article>`;
  }else if (custodyUsesKitWarehouseFlow(custody) && Array.isArray(custody.kitReturnComponents)) {
    const kitRows = custody.kitReturnComponents;
    const kitIssues = kitRows.filter((item) => Number(item.missing_quantity || 0) > 0 || String(item.condition || 'CONFORME').toUpperCase() !== 'CONFORME');
    specializedReturn = `<article class="detail-block"><h4>KIT</h4><p><strong>${kitRows.length} componente(s)</strong>${kitIssues.length ? ` · <span class="danger-text">${kitIssues.length} con faltante/observación</span>` : ' · sin diferencias registradas'}</p><details class="detail-technical"><summary>Ver componentes</summary><div class="table-wrap"><table><thead><tr><th>Componente</th><th>Entregado</th><th>Devuelto</th><th>Faltante</th><th>Condición</th></tr></thead><tbody>${kitRows.map((item) => `<tr><td><strong>${escapeHtml(item.internal_code)}</strong><div class="small">${escapeHtml(item.description)}</div></td><td>${escapeHtml(item.issued_quantity)}</td><td>${escapeHtml(item.returned_quantity)}</td><td>${escapeHtml(item.missing_quantity)}</td><td>${escapeHtml(conditionLabel(item.condition))}</td></tr>`).join('')}</tbody></table></div></details></article>`;
  }

  const formalNature = custodyUsesSerializedWarehouseFlow(custody) || custodyUsesVehicleWarehouseFlow(custody) || custodyUsesKitWarehouseFlow(custody);
  let receptionActions = '';
  if (custodyUsesVehicleWarehouseFlow(custody) && custody.status === 'DEVOLUCION_DECLARADA') {
    const supervision = custody.vehicleReturnSupervision;
    if (supervision && String(supervision.status || '').toUpperCase() === 'PENDIENTE') {
      if (currentUserIsVehicleSupervisor(custody)) {
        receptionActions = `<article class="detail-block"><h4>Inspección del Supervisor</h4><p class="small">Revisá el vehículo. Un comentario normal no lo bloquea. Marcá <strong>Seguridad</strong> sólo si la observación impide volver a ponerlo en servicio.</p><div class="actions"><button class="primary" data-custody-detail-action="vehicle-supervisor-review">INSPECCIONAR Y DAR V°B°</button></div></article>`;
      } else {
        receptionActions = `<article class="detail-block"><h4>Pendiente de Supervisor</h4><p class="small">La devolución está esperando la inspección y V°B° de <strong>${escapeHtml(supervision.supervisor_name || 'Supervisor asignado')}</strong>. El pañol todavía no puede recibir las llaves.</p></article>`;
      }
    } else if (supervision && String(supervision.status || '').toUpperCase() === 'APROBADA' && can('Vehicles.ReceiveReturnKeys') && custodyCanBeReceivedByWarehouse(custody)) {
      const safety = Number(supervision.safety_observation || 0) === 1;
      receptionActions = `<article class="detail-block"><h4>Recepción de llaves</h4><p class="small">V°B° del Supervisor registrado.${safety ? ' Existe una observación de Seguridad: el vehículo permanecerá BLOQUEADO después de recibir las llaves.' : ' Sin observación de Seguridad: el vehículo quedará disponible al finalizar la devolución.'}</p><div class="actions"><button class="primary" data-custody-detail-action="vehicle-keys-receive">RECIBIR LLAVES</button></div></article>`;
    } else if (!supervision && can('Vehicles.ReceiveReturnKeys') && custodyCanBeReceivedByWarehouse(custody)) {
      receptionActions = '<article class="detail-block"><h4>Pendiente de Supervisor</h4><p class="small danger-text"><strong>No se pueden recibir las llaves.</strong> Esta devolución no tiene una supervisión válida registrada. Debe regularizarse y obtener V°B° del Supervisor antes de la recepción.</p></article>';
    }
  } else if (can('Warehouse.Operate') && formalNature && custodyCanBeReceivedByWarehouse(custody)) {
    const declaredProblem = custodySerializedReturnHasProblem(custody);
    receptionActions = `<article class="detail-block"><h4>Recepción física</h4><p class="small">La custodia permanece fuera del pañol hasta registrar esta recepción.</p><div class="actions">
      ${declaredProblem ? '' : `<button class="primary" data-custody-detail-action="accept">✓ ACEPTAR DEVOLUCIÓN</button>`}
      <button class="${declaredProblem ? 'primary ' : ''}warning-action" data-custody-detail-action="accept-observed">⚠ ACEPTAR CON OBSERVACIÓN</button>
      ${custodyUsesKitWarehouseFlow(custody) ? '<button data-custody-detail-action="kit-components">DETALLAR FALTANTES / DAÑOS</button>' : ''}
    </div></article>`;
  } else if (custody.returnReceipt) {
    receptionActions = `<article class="detail-block"><h4>Constancia de devolución</h4><div class="actions"><button class="primary" data-custody-detail-action="receipt">CONSTANCIA PDF</button></div></article>`;
  }

  const quantityProgress = String(custody.category_nature || '').toUpperCase() === 'CANTIDAD' && Number(custody.requires_return || 0) === 1
    ? `<article class="detail-block"><h4>Devolución cuantitativa</h4><div class="request-summary-grid"><div><span>Entregado</span><strong>${escapeHtml(custody.quantity)}</strong></div><div><span>Devuelto acumulado</span><strong>${escapeHtml(custody.returned_quantity || 0)}</strong></div><div><span>Pendiente</span><strong>${escapeHtml(custody.quantity_outstanding ?? custody.quantity)}</strong></div></div>${custody.returnPortions?.length ? `<div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Cantidad</th><th>Pendiente</th><th>Condición</th><th>Recibió</th></tr></thead><tbody>${custody.returnPortions.map((item) => `<tr><td>${escapeHtml(formatDateTime(item.received_at))}</td><td>${escapeHtml(item.quantity)}</td><td>${escapeHtml(item.remaining_after)}</td><td>${escapeHtml(conditionLabel(item.condition))}</td><td>${escapeHtml(item.recorded_by_name || item.recorded_by_username || '—')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="small">Todavía no hay recepciones parciales registradas.</p>'}</article>`
    : '';
  $('#custody-detail-content').innerHTML = `<div class="request-summary-grid">
    <div><span>Bien</span><strong>${escapeHtml(custody.internal_code)} · ${escapeHtml(custody.description)}</strong></div><div><span>Tipo</span><strong>${escapeHtml(natureLabel(custody.category_nature))}</strong></div>
    <div><span>Custodio</span><strong>${escapeHtml(custody.custodian_name)}</strong></div><div><span>Solicitud</span><strong>${escapeHtml(custody.request_number)}</strong></div>
    <div><span>Estado</span><strong>${escapeHtml(custodyStatusLabel(custody.status))}</strong></div><div><span>Apertura</span><strong>${escapeHtml(formatDateTime(custody.opened_at))}</strong></div>
    <div><span>Vencimiento</span><strong>${escapeHtml(formatDateTime(custody.due_at))}</strong></div><div><span>Situación temporal</span><strong class="${temporal.className === 'danger' ? 'danger-text' : ''}">${escapeHtml(uiCodeLabel(custody.returnRecord?.timing_status || temporal.label))}</strong></div>
    <div><span>Sede / ubicación</span><strong>${escapeHtml(custody.site_name)} · ${escapeHtml(custody.location_name)}</strong></div>
  </div>${quantityProgress}${returnRecord}${custody.returnDeclaration ? `<h4>Devolución informada por el usuario</h4><p><strong>${escapeHtml(conditionLabel(custody.returnDeclaration.condition))}</strong>${Number(custody.returnDeclaration.problem_reported||0)===1 ? ' · <span class="danger-text">INFORMÓ PROBLEMA</span>' : ''}${custody.returnDeclaration.notes ? `<br>${escapeHtml(custody.returnDeclaration.notes)}` : ''}${custody.returnEvidence?.length ? `<br>${custody.returnEvidence.length} foto(s) adjunta(s)<br><span class="actions">${custody.returnEvidence.map((item) => `<button data-evidence-download="${item.id}" data-evidence-name="${escapeHtml(item.filename)}">VER FOTO</button>`).join('')}</span>` : ''}</p>` : ''}${specializedReturn}${receptionActions}<details class="detail-technical"><summary>Ver trazabilidad técnica</summary><h4>Inspecciones</h4><div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Etapa</th><th>Condición</th><th>Resultado</th><th>Inspector</th><th>Notas</th></tr></thead><tbody>${inspections}</tbody></table></div>
  <div class="grid request-history"><section><h4>Historial</h4><ol>${events}</ol></section><section><h4>Transferencias</h4><ol>${transfers}</ol><h4>Incidencias</h4><ol>${incidents}</ol></section></div></details>`;
  $('#custody-detail-dialog').showModal();
}

$('#custody-detail-content').addEventListener('click', async (event) => {
  const evidenceButton = event.target.closest('[data-evidence-download]');
  if (evidenceButton) {
    return downloadFile(`/api/v1/evidence/${evidenceButton.dataset.evidenceDownload}`, evidenceButton.dataset.evidenceName || 'foto.jpg').catch((error) => flash(error.message, 'error'));
  }
  const actionButton = event.target.closest('[data-custody-detail-action]');
  if (!actionButton || !state.currentCustody) return;
  const custody = state.currentCustody;
  try {
    if (actionButton.dataset.custodyDetailAction === 'receipt') {
      return downloadFile(`/api/v1/custodies/${custody.id}/return-receipt`, `${custody.returnReceipt?.receipt_number || 'constancia-devolucion'}.pdf`);
    }
    if (actionButton.dataset.custodyDetailAction === 'vehicle-supervisor-review') {
      const supervision = custody.vehicleReturnSupervision;
      if (!supervision) throw new Error('No existe una supervisión F24 para esta devolución.');
      const mechanicChecklist = supervision.returnChecklist || custody.vehicleReturnDetail?.returnChecklist || {};
      const checklistKeys = ['exterior','neumaticos','luces','interior','documentacion'];
      const fields = [];
      for (const key of checklistKeys) {
        const mechanicValue = String(mechanicChecklist[key] || 'OK').toUpperCase() === 'OBSERVACION' ? 'OBSERVACION' : 'OK';
        fields.push({ name: `result_${key}`, label: `${vehicleChecklistLabel(key)} · resultado Supervisor (mecánico: ${uiCodeLabel(mechanicValue)})`, type: 'select', value: mechanicValue, options: [{ value: 'OK', label: 'OK' }, { value: 'OBSERVACION', label: 'OBSERVACIÓN' }] });
        fields.push({ name: `safety_${key}`, label: `${vehicleChecklistLabel(key)} · ¿Seguridad?`, type: 'select', value: 'NO', options: [{ value: 'NO', label: 'No' }, { value: 'SI', label: 'Sí · bloquea vehículo' }] });
        fields.push({ name: `comment_${key}`, label: `${vehicleChecklistLabel(key)} · comentario`, type: 'textarea', required: false, placeholder: 'Obligatorio si el Supervisor marca OBSERVACIÓN.' });
      }
      fields.push({ name: 'generalSafety', label: '¿Existe una observación general de Seguridad fuera del checklist?', type: 'select', value: 'NO', options: [{ value: 'NO', label: 'No' }, { value: 'SI', label: 'Sí · bloquea vehículo' }] });
      fields.push({ name: 'comment', label: 'Comentario general del Supervisor', type: 'textarea', required: false, placeholder: 'Opcional. Obligatorio si marcás Seguridad general.' });
      const values = await askFields('Inspección de devolución del vehículo', fields, {
        confirmText: 'DAR V°B°',
        message: 'Revisá cada ítem. Una OBSERVACIÓN sólo bloquea cuando el Supervisor la clasifica como SEGURIDAD.'
      });
      if (!values) return;
      const checklistAssessments = {};
      let safetyObservation = values.generalSafety === 'SI';
      for (const key of checklistKeys) {
        const result = values[`result_${key}`];
        const safety = values[`safety_${key}`] === 'SI';
        const itemComment = String(values[`comment_${key}`] || '').trim();
        if (safety && result !== 'OBSERVACION') throw new Error(`${vehicleChecklistLabel(key)} sólo puede marcarse como Seguridad si tiene una OBSERVACIÓN.`);
        if (result === 'OBSERVACION' && itemComment.length < 3) throw new Error(`La observación de ${vehicleChecklistLabel(key)} requiere un comentario.`);
        checklistAssessments[key] = { value: result, safety, comment: itemComment || null };
        if (safety) safetyObservation = true;
      }
      if (values.generalSafety === 'SI' && String(values.comment || '').trim().length < 3) throw new Error('La observación general de Seguridad requiere un comentario del Supervisor.');
      await requestWorkflowApi(`/api/v1/custodies/${custody.id}/vehicle-supervisor-review`, {
        method: 'POST',
        body: JSON.stringify({ version: Number(supervision.version), comment: values.comment || null, generalSafetyObservation: values.generalSafety === 'SI', checklistAssessments })
      });
      const refreshed = (await api(`/api/v1/custodies/${custody.id}`)).custody;
      $('#custody-detail-dialog').close();
      renderCustodyDetail(refreshed);
      flash(safetyObservation ? 'V°B° registrado. Vehículo BLOQUEADO por observación de Seguridad; el pañol ya puede recibir las llaves.' : 'V°B° registrado. El pañol ya puede recibir las llaves.');
      if (typeof refreshWarehouseOperationalViews === 'function') await refreshWarehouseOperationalViews({ silent: true });
      return;
    }
    if (actionButton.dataset.custodyDetailAction === 'vehicle-keys-receive') {
      $('#custody-detail-dialog').close();
      const completed = await receiveVehicleFromWarehouse(custody);
      if (completed) {
        await loadRequests().catch(() => {});
        await loadCustodies();
        if (typeof refreshWarehouseOperationalViews === 'function') await refreshWarehouseOperationalViews({ silent: true });
        await refreshNotificationsBackground().catch(() => {});
      }
      return;
    }
    if (actionButton.dataset.custodyDetailAction === 'kit-components') {
      $('#custody-detail-dialog').close();
      await openKitReceiveDialog(custody, { forceObserved: true });
      return;
    }
    const forceObserved = actionButton.dataset.custodyDetailAction === 'accept-observed';
    $('#custody-detail-dialog').close();
    const completed = await openWarehouseReceiveAction(custody, { forceObserved });
    if (completed) {
      await loadRequests().catch(() => {});
      await loadCustodies();
      if (typeof refreshWarehouseOperationalViews === 'function') await refreshWarehouseOperationalViews({ silent: true });
      await refreshNotificationsBackground().catch(() => {});
    }
  } catch (error) { flash(error.message, 'error'); }
});

function renderCustodyIntegrityRows(items) {
  const body = $('#custody-integrity-body');
  if (!body) return;
  body.innerHTML = items.length ? items.map((item) => {
    const detail = item.details || {};
    const missing = Array.isArray(detail.missing) && detail.missing.length ? `Faltan: ${detail.missing.join(', ')}` : (item.resolution_notes || 'Revisar trazabilidad de entrega y custodia.');
    return `<tr><td><span class="status ${item.status === 'REQUIERE_REVISION' ? 'danger' : item.status === 'REPARADA' ? 'ok' : 'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${escapeHtml(uiCodeLabel(item.anomaly_type))}</td><td>${escapeHtml(item.request_number || '—')}</td><td>${escapeHtml(item.internal_code || '—')}<div class="small">${escapeHtml(item.description || '')}</div></td><td>${escapeHtml(missing)}</td><td>${escapeHtml(formatDateTime(item.detected_at))}</td></tr>`;
  }).join('') : '<tr><td colspan="6">No se detectaron anomalías de integridad.</td></tr>';
}

function returnDeclarationCondition(custody) {
  const declaration = custody?.returnDeclaration;
  if (!declaration) return 'CONFORME';
  const condition = String(declaration.condition || 'CONFORME').toUpperCase();
  if (Number(declaration.problem_reported || 0) === 1 && condition === 'CONFORME') return 'OBSERVADO';
  return ['CONFORME','OBSERVADO','DANADO','INCOMPLETO'].includes(condition) ? condition : 'CONFORME';
}

function strongestUiReturnCondition(...values) {
  const rank = { CONFORME: 0, OBSERVADO: 1, DANADO: 2, INCOMPLETO: 3 };
  let result = 'CONFORME';
  for (const value of values) {
    const condition = String(value || 'CONFORME').toUpperCase();
    if ((rank[condition] ?? -1) > rank[result]) result = condition;
  }
  return result;
}

function warehouseReceiveActionLabel(custody) {
  return 'REVISAR DEVOLUCIÓN';
}

async function receiveVehicleFromWarehouse(custody) {
  const supervision = custody.vehicleReturnSupervision;
  if (supervision && String(supervision.status || '').toUpperCase() !== 'APROBADA') {
    throw new Error('El Supervisor asignado debe dar el V°B° antes de recibir las llaves.');
  }
  const safety = Number(supervision?.safety_observation || 0) === 1;
  const values = await askFields('Recepción de llaves del vehículo', [
    { name: 'notes', label: 'Comentario del pañolero', type: 'textarea', required: false, placeholder: 'Opcional. Este comentario no bloquea el vehículo.' }
  ], { confirmText: 'RECIBIR LLAVES' });
  if (!values) return false;
  await requestWorkflowApi(`/api/v1/custodies/${custody.id}/vehicle-receive`, {
    method: 'POST',
    headers: { 'Idempotency-Key': newIdempotencyKey('vehicle-receive') },
    body: JSON.stringify({ version: custody.version, notes: values.notes || null })
  });
  flash(safety ? 'Llaves recibidas. La devolución finalizó y el vehículo permanece BLOQUEADO por Seguridad.' : 'Llaves recibidas. Devolución finalizada; vehículo disponible.');
  return true;
}

async function receiveSerializedFromDetail(custody, forceObserved = false) {
  const declaredProblem = Number(custody?.returnDeclaration?.problem_reported || 0) === 1 || returnDeclarationCondition(custody) !== 'CONFORME';
  if (forceObserved || declaredProblem) {
    openReceiveDialog(custody);
    if ($('#receive-condition').value === 'CONFORME') { $('#receive-condition').value = 'OBSERVADO'; updateReceiveConditionUi(); }
    return false;
  }
  const result = await api(`/api/v1/custodies/${custody.id}/receive`, {
    method: 'POST',
    headers: { 'Idempotency-Key': newIdempotencyKey('receive-conforme') },
    body: JSON.stringify({ version: Number(custody.version), condition: 'CONFORME', warehouseComment: null, reviewConfirmed: true })
  });
  const record = result.returnRecord || result.custody?.returnRecord;
  const timing = record?.timing_status === 'FUERA_DE_TERMINO' ? ` fuera de término (${formatElapsedSeconds(record.overdue_seconds)})` : ' en término';
  flash(`Devolución recibida conforme${timing}. Constancia PDF generada.`);
  return true;
}

let currentKitReceive = null;
let currentKitReceiveForcedCondition = 'CONFORME';

function kitReceiveRows() {
  return $$('#kit-receive-components tr[data-kit-component-id]');
}

function updateKitReceiveState() {
  if (!currentKitReceive) return;
  const warehouseComment = $('#kit-receive-notes').value.trim();
  let condition = strongestUiReturnCondition(currentKitReceiveForcedCondition, returnDeclarationCondition(currentKitReceive.custody), warehouseComment ? 'OBSERVADO' : 'CONFORME');
  for (const row of kitReceiveRows()) {
    const missing = Number(row.querySelector('[data-field="missingQuantity"]').value || 0);
    const itemCondition = row.querySelector('[data-field="condition"]').value;
    condition = strongestUiReturnCondition(condition, missing > 0 ? 'INCOMPLETO' : itemCondition);
  }
  const observed = condition !== 'CONFORME';
  $('#kit-receive-notes').required = observed && !currentKitReceive.custody.returnDeclaration?.notes;
  $('#kit-receive-warning').classList.toggle('hidden', !observed);
  $('#kit-receive-submit').textContent = observed ? '⚠ ACEPTAR Y BLOQUEAR' : '✓ ACEPTAR DEVOLUCIÓN';
}

async function openKitReceiveDialog(custody, options = {}) {
  const detail = await api(`/api/v1/custodies/${custody.id}/kit-detail`);
  currentKitReceive = detail;
  currentKitReceiveForcedCondition = options.forceObserved ? 'OBSERVADO' : 'CONFORME';
  const c = detail.custody;
  $('#kit-receive-custody-id').value = c.id;
  $('#kit-receive-custody-version').value = c.version;
  $('#kit-receive-at').value = dateTimeLocalValue(new Date());
  // F22: nunca precargar como comentario del pañolero lo que declaró el técnico.
  $('#kit-receive-notes').value = '';
  $('#kit-receive-components-wrap')?.classList.add('hidden');
  const toggleComponents = $('#kit-receive-toggle-components'); if (toggleComponents) toggleComponents.textContent = 'HAY FALTANTES O DAÑOS';
  $('#kit-receive-summary').innerHTML = `<strong>${escapeHtml(c.internal_code)} · ${escapeHtml(c.description)}</strong><div class="small">Custodio: ${escapeHtml(c.custodian_name)} · Solicitud: ${escapeHtml(c.request_number)} · Estado: ${escapeHtml(custodyStatusLabel(c.status))}</div>${c.returnDeclaration ? `<div class="small">Declarado: ${escapeHtml(conditionLabel(c.returnDeclaration.condition))}${Number(c.returnDeclaration.problem_reported || 0) === 1 ? ' · informó problema' : ''}${c.returnDeclaration.notes ? ` · ${escapeHtml(c.returnDeclaration.notes)}` : ''}</div>` : ''}`;
  $('#kit-receive-components').innerHTML = detail.components.map((item) => {
    const issued = Number(item.issued_quantity || 0);
    const existingMissing = Number(item.missing_quantity || 0);
    const existingAccounted = Number(item.returned_quantity || 0) + existingMissing;
    const returned = existingAccounted >= issued - 1e-9 ? Number(item.returned_quantity || 0) : Math.max(0, issued - existingMissing);
    const condition = existingMissing > 0 && String(item.condition || 'CONFORME').toUpperCase() === 'CONFORME' ? 'INCOMPLETO' : String(item.condition || 'CONFORME').toUpperCase();
    return `<tr data-kit-component-id="${escapeHtml(item.id)}" data-issued="${issued}" data-version="${Number(item.version)}"><td><strong>${escapeHtml(item.internal_code)}</strong><div class="small">${escapeHtml(item.description)}</div></td><td>${issued}</td><td><input type="number" min="0" step="0.001" data-field="returnedQuantity" value="${returned}" required></td><td><input type="number" min="0" step="0.001" data-field="missingQuantity" value="${existingMissing}" required></td><td><select data-field="condition"><option value="CONFORME" ${condition === 'CONFORME' ? 'selected' : ''}>Conforme</option><option value="OBSERVADO" ${condition === 'OBSERVADO' ? 'selected' : ''}>Con observación</option><option value="DANADO" ${condition === 'DANADO' ? 'selected' : ''}>Dañado</option><option value="INCOMPLETO" ${condition === 'INCOMPLETO' ? 'selected' : ''}>Incompleto</option></select></td></tr>`;
  }).join('');
  kitReceiveRows().forEach((row) => row.querySelectorAll('input,select').forEach((control) => control.addEventListener('change', updateKitReceiveState)));
  updateKitReceiveState();
  $('#kit-receive-dialog').showModal();
}

async function kitComponentsAsFullyReturned(custody) {
  const detail = await api(`/api/v1/custodies/${custody.id}/kit-detail`);
  return (detail.components || []).map((item) => ({
    id: item.id,
    version: Number(item.version),
    returnedQuantity: Number(item.issued_quantity || 0),
    missingQuantity: 0,
    condition: 'CONFORME'
  }));
}

async function receiveKitConformeDirect(custody) {
  const declaredProblem = Number(custody?.returnDeclaration?.problem_reported || 0) === 1 || returnDeclarationCondition(custody) !== 'CONFORME';
  if (declaredProblem) { await openKitReceiveDialog(custody, { forceObserved: true }); return false; }
  const components = await kitComponentsAsFullyReturned(custody);
  const result = await requestWorkflowApi(`/api/v1/custodies/${custody.id}/kit-receive`, {
    method: 'POST',
    headers: { 'Idempotency-Key': newIdempotencyKey('kit-receive-conforme') },
    body: JSON.stringify({ version: Number(custody.version), condition: 'CONFORME', warehouseComment: null, reviewConfirmed: true, components })
  });
  flash(result.returnRecord?.incident_id ? 'Kit recibido con observación y bloqueado para revisión.' : 'Kit recibido conforme. Custodia cerrada y constancia PDF generada.');
  return true;
}

async function receiveKitObservedDirect(custody) {
  await openKitReceiveDialog(custody, { forceObserved: true });
  return false;
}

async function receiveGenericConformeDirect(custody) {
  if (String(custody?.category_nature || '').toUpperCase() === 'CANTIDAD') { openReceiveDialog(custody); return false; }
  const declaredProblem = Number(custody?.returnDeclaration?.problem_reported || 0) === 1 || returnDeclarationCondition(custody) !== 'CONFORME';
  if (declaredProblem) { openReceiveDialog(custody); if ($('#receive-condition').value === 'CONFORME') { $('#receive-condition').value = 'OBSERVADO'; updateReceiveConditionUi(); } return false; }
  await api(`/api/v1/custodies/${custody.id}/receive`, {
    method: 'POST',
    headers: { 'Idempotency-Key': newIdempotencyKey('receive-conforme') },
    body: JSON.stringify({ version: Number(custody.version), condition: 'CONFORME', warehouseComment: null, reviewConfirmed: true })
  });
  flash('Devolución recibida conforme.');
  return true;
}

async function openWarehouseReceiveAction(custody, options = {}) {
  const forceObserved = Boolean(options.forceObserved);
  if (custodyUsesVehicleWarehouseFlow(custody)) return receiveVehicleFromWarehouse(custody, forceObserved);
  if (custodyUsesSerializedWarehouseFlow(custody)) return receiveSerializedFromDetail(custody, forceObserved);
  if (custodyUsesKitWarehouseFlow(custody)) {
    return forceObserved ? receiveKitObservedDirect(custody) : receiveKitConformeDirect(custody);
  }
  if (!forceObserved) return receiveGenericConformeDirect(custody);
  openReceiveDialog(custody);
  if ($('#receive-condition').value === 'CONFORME') {
    $('#receive-condition').value = 'OBSERVADO';
    updateReceiveConditionUi();
  }
  return false;
}

async function loadCustodies() {
  const params = dashboardFilterParams('custodies');
  if (!params.has('search')) params.set('search', $('#custody-search').value); if (!params.has('statuses')) params.set('status', $('#custody-status').value); if (!params.has('dueBefore')) params.set('overdue', String($('#custody-overdue').checked)); params.set('limit', '300');
  const data = await api(`/api/v1/custodies?${params}`); state.custodies = data.items;
  $('#custodies-body').innerHTML = data.items.length ? data.items.map((custody) => {
    const timing = custodyTemporalSituation(custody);
    const supervisorReview = custodyVehicleNeedsSupervisor(custody) && currentUserIsVehicleSupervisor(custody);
    const warehouseReview = can('Warehouse.Operate') && custodyCanBeReceivedByWarehouse(custody) && (custodyUsesSerializedWarehouseFlow(custody) || custodyUsesVehicleWarehouseFlow(custody) || custodyUsesKitWarehouseFlow(custody));
    return `<tr>
    <td><strong>${escapeHtml(custody.internal_code)}</strong><div class="small">${escapeHtml(custody.description)}</div></td><td>${escapeHtml(custody.custodian_name)}<div class="small">${escapeHtml(custody.custodian_document || '')}</div></td>
    <td>${escapeHtml(custody.request_number)}</td><td>${escapeHtml(formatDateTime(custody.opened_at))}</td><td>${escapeHtml(formatDateTime(custody.due_at))}<div class="small ${timing.className === 'danger' ? 'danger-text' : ''}">${escapeHtml(timing.label)}</div></td>
    <td><span class="status ${custodyStatusClass(custody.status, custody.overdue)}">${escapeHtml(custodyStatusLabel(custody.status))}</span>${custody.returnDeclaration && (Number(custody.returnDeclaration.problem_reported || 0) === 1 || String(custody.returnDeclaration.condition || '').toUpperCase() !== 'CONFORME') ? '<br><span class="status warning">⚠ CON PROBLEMA</span>' : ''}</td><td class="actions">
      <button class="${supervisorReview || warehouseReview ? 'primary' : ''}" data-custody-action="detail" data-id="${custody.id}">${supervisorReview ? 'INSPECCIONAR VEHÍCULO' : warehouseReview ? (custodyUsesVehicleWarehouseFlow(custody) ? 'RECIBIR LLAVES' : 'REVISAR DEVOLUCIÓN') : 'Detalle'}</button>
      ${(can('Custody.ReturnAny') || can('Custody.ReturnOwn')) && custody.status === 'ABIERTA' && !custodyRequiresRequesterReturn(custody) ? `<button data-custody-action="return" data-id="${custody.id}">Declarar devolución</button>` : ''}
      ${can('Warehouse.Operate') && custodyCanBeReceivedByWarehouse(custody) && custodyUsesSimpleWarehouseFlow(custody) ? `<button class="primary" data-custody-action="review-receive" data-id="${custody.id}">REVISAR DEVOLUCIÓN</button>` : ''}
      ${can('Warehouse.Operate') && custodyCanBeReceivedByWarehouse(custody) && !custodyUsesSimpleWarehouseFlow(custody) && !custodyUsesSerializedWarehouseFlow(custody) && !custodyUsesVehicleWarehouseFlow(custody) && !custodyUsesKitWarehouseFlow(custody) ? `<button class="primary" data-custody-action="review-receive" data-id="${custody.id}">REVISAR DEVOLUCIÓN</button>` : ''}
      ${can('Custody.Extend') && ['ABIERTA','DEVOLUCION_DECLARADA'].includes(custody.status) ? `<button data-custody-action="extend" data-id="${custody.id}">Extender</button>` : ''}
      ${(can('Custody.TransferAny') || can('Custody.TransferOwn')) && custody.status === 'ABIERTA' ? `<button data-custody-action="transfer" data-id="${custody.id}">Transferir</button>` : ''}
      ${custody.returnReceipt ? `<button class="primary" data-custody-action="receipt" data-id="${custody.id}">CONSTANCIA PDF</button>` : ''}
    </td></tr>`;
  }).join('') : '<tr><td colspan="7">No existen custodias para los filtros seleccionados.</td></tr>';

  if (can('Warehouse.Operate')) {
    try {
      const anomalyData = await api('/api/v1/custody-integrity-anomalies?limit=300');
      state.custodyIntegrityAnomalies = anomalyData.items || anomalyData.anomalies || [];
      renderCustodyIntegrityRows(state.custodyIntegrityAnomalies);
    } catch (error) {
      state.custodyIntegrityAnomalies = [];
      $('#custody-integrity-body').innerHTML = `<tr><td colspan="6">${escapeHtml(error.message)}</td></tr>`;
    }
  }

  try {
    const transferData = await api('/api/v1/custody-transfers'); state.transfers = transferData.items;
    $('#transfers-body').innerHTML = transferData.items.length ? transferData.items.map((item) => `<tr><td>${escapeHtml(item.internal_code)}<div class="small">${escapeHtml(item.description)}</div></td><td>${escapeHtml(item.from_name)}</td><td>${escapeHtml(item.to_name)}</td><td>${escapeHtml(formatDateTime(item.requested_at))}</td><td><span class="status ${item.status === 'ACEPTADA' ? 'ok' : item.status === 'RECHAZADA' ? 'danger' : 'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td class="actions">${item.status === 'PENDIENTE' && item.to_person_id === state.user.personId ? `<button data-transfer-action="accept" data-id="${item.id}">Aceptar</button><button data-transfer-action="reject" data-id="${item.id}">Rechazar</button>` : ''}</td></tr>`).join('') : '<tr><td colspan="6">Sin transferencias.</td></tr>';
  } catch { state.transfers = []; $('#transfers-body').innerHTML = '<tr><td colspan="6">Sin acceso a transferencias.</td></tr>'; }
}

$('#custody-refresh').addEventListener('click', () => loadCustodies().catch((error) => flash(error.message, 'error')));
$('#custody-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadCustodies().catch((error) => flash(error.message, 'error')); });
$('#custodies-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-custody-action]'); if (!button) return;
  const custody = state.custodies.find((item) => item.id === button.dataset.id); if (!custody) return;
  try {
    if (button.dataset.custodyAction === 'detail') return renderCustodyDetail((await api(`/api/v1/custodies/${custody.id}`)).custody);
    if (button.dataset.custodyAction === 'receipt') return downloadFile(`/api/v1/custodies/${custody.id}/return-receipt`, `${custody.returnReceipt?.receipt_number || 'constancia-devolucion'}.pdf`);
    if (button.dataset.custodyAction === 'review-receive') {
      await openWarehouseReceiveAction((await api(`/api/v1/custodies/${custody.id}`)).custody);
      return;
    }

    if (button.dataset.custodyAction === 'return') {
      const values = await askFields('Declarar devolución', [{ name: 'reason', label: 'Comentario sobre el estado del bien (opcional)', type: 'textarea', required: false }], { confirmText: 'Declarar devolución' });
      if (!values) return;
      const returnComment = String(values.reason || '').trim() || null;
      await api(`/api/v1/custodies/${custody.id}/declare-return`, { method: 'POST', body: JSON.stringify({
        version: custody.version,
        condition: returnComment ? 'OBSERVADO' : 'CONFORME',
        problemReported: Boolean(returnComment),
        notes: returnComment,
        reason: returnComment || 'Devolución solicitada por el usuario.'
      }) });
      flash('Devolución declarada. La custodia permanece abierta hasta la recepción física.');
    }
    if (button.dataset.custodyAction === 'receive-observed') {
      await openWarehouseReceiveAction((await api(`/api/v1/custodies/${custody.id}`)).custody, { forceObserved: true });
      return;
    }
    if (button.dataset.custodyAction === 'extend') {
      const values = await askFields('Extender custodia', [
        { name: 'dueAt', label: 'Nuevo vencimiento', type: 'datetime-local', value: dateTimeLocalValue(new Date(Date.now() + 24 * 3600_000)) },
        { name: 'reason', label: 'Fundamento de extensión', type: 'textarea' }
      ], { confirmText: 'Extender' });
      if (!values) return;
      await api(`/api/v1/custodies/${custody.id}/extend`, { method: 'POST', body: JSON.stringify({ version: custody.version, dueAt: new Date(values.dueAt).toISOString(), reason: values.reason }) });
      flash('Custodia extendida.');
    }
    if (button.dataset.custodyAction === 'transfer') { const people = await api('/api/v1/custody-people'); state.custodyPeople = people.items.filter((person) => person.id !== custody.person_id); $('#transfer-person').innerHTML = state.custodyPeople.map((person) => `<option value="${person.id}">${escapeHtml(person.full_name)} · ${escapeHtml(person.document_number || '')}</option>`).join(''); $('#transfer-custody-id').value = custody.id; $('#transfer-custody-version').value = custody.version; $('#transfer-reason').value = ''; $('#transfer-dialog').showModal(); return; }
    await loadCustodies();
  } catch (error) { flash(error.message, 'error'); }
});

$('#receive-at').addEventListener('change', updateReceiveTiming);
$('#receive-condition').addEventListener('change', updateReceiveConditionUi);
$('#receive-notes').addEventListener('input', updateReceiveConditionUi);

$('#receive-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const warehouseComment = $('#receive-notes').value.trim() || null;
    const result = await api(`/api/v1/custodies/${$('#receive-custody-id').value}/receive`, {
      method: 'POST',
      headers: { 'Idempotency-Key': newIdempotencyKey('receive') },
      body: JSON.stringify({
        version: Number($('#receive-custody-version').value),
        condition: $('#receive-condition').value,
        warehouseComment,
        reviewConfirmed: true,
        returnQuantity: !$('#receive-quantity-wrap').classList.contains('hidden') ? Number($('#receive-quantity').value) : undefined
      })
    });
    $('#receive-dialog').close();
    const record = result.returnRecord || result.custody?.returnRecord;
    const partial = result.partialReturn && Number(result.partialReturn.is_final || 0) === 0;
    if (partial) {
      const pending = Number(result.custody?.quantity_outstanding || 0);
      const incident = result.partialReturn?.incident_id ? ' Se generó un incidente y el bien quedó bloqueado para revisión.' : '';
      flash(`Devolución parcial registrada. Restan ${pending}.${incident}`);
    } else {
      const timing = record?.timing_status === 'FUERA_DE_TERMINO' ? ` fuera de término (${formatElapsedSeconds(record.overdue_seconds)})` : ' en término';
      const incident = record?.incident_id ? ' Se generó un incidente y el bien quedó bloqueado.' : '';
      flash(`Devolución registrada${timing}.${incident}`);
    }
    if (can('Warehouse.Operate')) await loadRequests().catch(() => {});
    await loadCustodies();
    if (typeof refreshWarehouseOperationalViews === 'function' && can('Warehouse.Operate')) await refreshWarehouseOperationalViews({ silent: true });
    await refreshNotificationsBackground().catch(() => {});
  } catch (error) { flash(error.message, 'error'); }
});

$('#custody-integrity-run').addEventListener('click', async () => {
  try {
    const result = await api('/api/v1/custody-integrity/reconcile', { method: 'POST', body: '{}' });
    const summary = result.result || result.summary || result;
    flash(`Control ejecutado: ${Number(summary.repaired || 0)} custodia(s) reparada(s), ${Number(summary.reviewRequired || 0)} caso(s) para revisión.`);
    await loadCustodies();
    await refreshNotificationsBackground().catch(() => {});
  } catch (error) { flash(error.message, 'error'); }
});

$('#kit-receive-notes')?.addEventListener('input', updateKitReceiveState);

$('#kit-receive-toggle-components')?.addEventListener('click', () => {
  const wrap = $('#kit-receive-components-wrap'); if (!wrap) return;
  const opening = wrap.classList.contains('hidden');
  wrap.classList.toggle('hidden', !opening);
  $('#kit-receive-toggle-components').textContent = opening ? 'OCULTAR COMPONENTES' : 'HAY FALTANTES O DAÑOS';
});

$('#kit-receive-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    if (!currentKitReceive) throw new Error('No hay un kit seleccionado para recepción.');
    const components = [];
    let condition = strongestUiReturnCondition(currentKitReceiveForcedCondition, returnDeclarationCondition(currentKitReceive.custody));
    for (const row of kitReceiveRows()) {
      const issued = Number(row.dataset.issued || 0);
      const returnedQuantity = Number(row.querySelector('[data-field="returnedQuantity"]').value);
      const missingQuantity = Number(row.querySelector('[data-field="missingQuantity"]').value);
      if (!Number.isFinite(returnedQuantity) || returnedQuantity < 0 || !Number.isFinite(missingQuantity) || missingQuantity < 0) throw new Error('Las cantidades devueltas y faltantes del kit deben ser válidas.');
      if (Math.abs((returnedQuantity + missingQuantity) - issued) > 1e-9) throw new Error(`El componente ${row.querySelector('strong')?.textContent || ''} debe quedar totalmente devuelto o declarado faltante.`);
      let itemCondition = row.querySelector('[data-field="condition"]').value;
      if (missingQuantity > 0 && itemCondition === 'CONFORME') itemCondition = 'INCOMPLETO';
      condition = strongestUiReturnCondition(condition, itemCondition, missingQuantity > 0 ? 'INCOMPLETO' : 'CONFORME');
      components.push({ id: row.dataset.kitComponentId, version: Number(row.dataset.version), returnedQuantity, missingQuantity, condition: itemCondition });
    }
    const notes = $('#kit-receive-notes').value.trim();
    condition = strongestUiReturnCondition(condition, notes ? 'OBSERVADO' : 'CONFORME');
    if (condition !== 'CONFORME' && !notes && !currentKitReceive.custody.returnDeclaration?.notes) throw new Error('Una recepción con observación requiere detalle del pañolero o una declaración previa del usuario.');
    const result = await requestWorkflowApi(`/api/v1/custodies/${$('#kit-receive-custody-id').value}/kit-receive`, {
      method: 'POST',
      headers: { 'Idempotency-Key': newIdempotencyKey('kit-receive') },
      body: JSON.stringify({
        version: Number($('#kit-receive-custody-version').value),
        condition,
        warehouseComment: notes || null,
        reviewConfirmed: true,
        components
      })
    });
    $('#kit-receive-dialog').close();
    currentKitReceive = null;
    flash(result.returnRecord?.incident_id ? 'Kit recibido con observación. Se generó incidente y quedó bloqueado para revisión.' : 'Kit recibido conforme. Custodia cerrada y constancia PDF generada.');
    if (can('Warehouse.Operate')) await loadRequests().catch(() => {});
    await loadCustodies();
    if (typeof refreshWarehouseOperationalViews === 'function' && can('Warehouse.Operate')) await refreshWarehouseOperationalViews({ silent: true });
    await refreshNotificationsBackground().catch(() => {});
  } catch (error) { flash(error.message, 'error'); }
});

$('#transfer-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api(`/api/v1/custodies/${$('#transfer-custody-id').value}/transfer`, { method: 'POST', body: JSON.stringify({ version: Number($('#transfer-custody-version').value), toPersonId: $('#transfer-person').value, reason: $('#transfer-reason').value }) });
    $('#transfer-dialog').close(); flash('Transferencia solicitada. Requiere aceptación del nuevo responsable.'); await loadCustodies();
  } catch (error) { flash(error.message, 'error'); }
});

$('#transfers-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-transfer-action]'); if (!button) return;
  const transfer = state.transfers.find((item) => item.id === button.dataset.id); if (!transfer) return;
  try {
    const values = await askFields(button.dataset.transferAction === 'accept' ? 'Aceptar transferencia' : 'Rechazar transferencia', [
      { name: 'reason', label: button.dataset.transferAction === 'accept' ? 'Confirmación de aceptación' : 'Fundamento de rechazo', type: 'textarea' }
    ], { confirmText: button.dataset.transferAction === 'accept' ? 'Aceptar' : 'Rechazar', danger: button.dataset.transferAction !== 'accept' });
    if (!values) return;
    const reason = values.reason;
    const endpoint = button.dataset.transferAction === 'accept' ? 'accept' : 'reject';
    const body = { transferVersion: transfer.version, custodyVersion: transfer.custody_version, reason };
    if (endpoint === 'accept') { body.acceptanceConfirmed = true; body.idempotencyKey = newIdempotencyKey('transfer'); }
    await api(`/api/v1/custody-transfers/${transfer.id}/${endpoint}`, { method: 'POST', headers: endpoint === 'accept' ? { 'Idempotency-Key': body.idempotencyKey } : {}, body: JSON.stringify(body) });
    flash(endpoint === 'accept' ? 'Custodia transferida.' : 'Transferencia rechazada.'); await loadCustodies();
  } catch (error) { flash(error.message, 'error'); }
});

function fillPolicyForm(policy = null) {
  $('#request-policy-form').reset();
  $('#policy-id').value = policy?.id || ''; $('#policy-version').value = policy?.version || '';
  $('#request-policy-title').textContent = policy ? `Editar ${policy.name}` : 'Nueva política';
  $('#policy-name').value = policy?.name || ''; $('#policy-operation').value = policy?.operation_type || 'RETIRO';
  $('#policy-site').value = policy?.site_id || ''; $('#policy-category').value = policy?.category_id || '';
  $('#policy-requires-approval').checked = Boolean(policy?.requires_approval);
  $('#policy-max-quantity').value = policy?.max_quantity ?? ''; $('#policy-max-hours').value = policy?.max_duration_hours ?? '';
  $('#policy-priority').value = policy?.priority || 100; $('#policy-active').checked = policy ? Boolean(policy.active) : true;
}

let portalAutoRefreshTimer = null;
