async function loadAudit() {
  const action = encodeURIComponent($('#audit-action').value || '');
  const data = await api(`/api/v1/audit?action=${action}&limit=250`);
  $('#audit-chain').textContent = data.chain.valid ? `Cadena válida · ${data.chain.count} eventos` : `Cadena inválida · ${data.chain.reason}`;
  $('#audit-chain').className = `status ${data.chain.valid ? 'ok' : 'danger'}`;
  $('#audit-body').innerHTML = data.items.map((item) => `<tr><td>${escapeHtml(new Date(item.occurred_at).toLocaleString())}</td><td>${escapeHtml(item.action)}</td><td>${escapeHtml(item.entity_type)}<div class="small">${escapeHtml(item.entity_id || '')}</div></td><td><span class="status ${item.result === 'SUCCESS' ? 'ok' : 'danger'}">${escapeHtml(uiCodeLabel(item.result))}</span></td><td>${escapeHtml(item.actor_user_id || 'Sistema')}</td><td><code>${escapeHtml(item.correlation_id)}</code></td></tr>`).join('');
}
$('#audit-refresh').addEventListener('click', () => loadAudit().catch((error) => flash(error.message, 'error')));

async function loadLogs() {
  const params = new URLSearchParams({ level: $('#log-level').value, search: $('#log-search').value, limit: '250' });
  const data = await api(`/api/v1/logs?${params}`);
  $('#logs-body').innerHTML = data.items.map((item) => `<tr><td>${escapeHtml(new Date(item.occurred_at).toLocaleString())}</td><td><span class="status ${item.level === 'ERROR' ? 'danger' : item.level === 'INFO' ? 'ok' : 'neutral'}">${escapeHtml(item.level)}</span></td><td>${escapeHtml(item.component)}</td><td>${escapeHtml(item.message)}</td><td><code>${escapeHtml(item.correlation_id || '')}</code></td></tr>`).join('');
}
$('#log-refresh').addEventListener('click', () => loadLogs().catch((error) => flash(error.message, 'error')));
$('#log-export').addEventListener('click', async () => {
  try {
    await downloadFile('/api/v1/logs/export', `iwc-logs-${new Date().toISOString().slice(0, 10)}.iwcexport`);
  } catch (error) { flash(error.message, 'error'); }
});

async function loadBackups() {
  const data = await api('/api/v1/backups');
  $('#backups-body').innerHTML = data.items.map((item) => `<tr><td>${escapeHtml(new Date(item.created_at).toLocaleString())}</td><td><span class="status ${item.status === 'FALLIDO' ? 'danger' : item.status === 'VERIFICADO' ? 'ok' : 'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td>${item.schema_version}</td><td>${item.size ? `${Math.round(item.size / 1024)} KiB` : '—'}</td><td>${item.verified_at ? escapeHtml(new Date(item.verified_at).toLocaleString()) : '—'}</td><td class="actions">${can('Backup.Verify') ? `<button data-backup-action="verify" data-id="${item.id}">Verificar</button>` : ''}${can('Backup.Verify') && item.status === 'VERIFICADO' ? `<button data-backup-action="portable" data-id="${item.id}">Exportar portátil</button>` : ''}${can('Backup.Restore') && item.status === 'VERIFICADO' ? `<button data-backup-action="restore" data-id="${item.id}">Restaurar</button>` : ''}</td></tr>`).join('');
}
$('#backup-create').addEventListener('click', async () => { try { await api('/api/v1/backups', { method: 'POST', body: '{}' }); flash('Backup creado.'); await loadBackups(); } catch (error) { flash(error.message, 'error'); } });
$('#backup-refresh').addEventListener('click', () => loadBackups().catch((error) => flash(error.message, 'error')));
$('#backup-import').addEventListener('click', async () => {
  try {
    const file = $('#backup-import-file').files[0];
    if (!file) throw new Error('Seleccione un archivo .iwcportable.');
    if (!file.name.toLowerCase().endsWith('.iwcportable')) throw new Error('El archivo debe tener extensión .iwcportable.');
    if (file.size > 768 * 1024 * 1024) throw new Error('El backup portátil supera el límite de 768 MiB.');
    const values = await askFields('Importar backup portátil', [
      { name: 'password', label: 'Contraseña del backup', type: 'password' }
    ], { message: 'El archivo se verificará y se cifrará con la clave de esta instalación antes de habilitar la restauración.', confirmText: 'Importar' });
    if (!values) return;
    const headerBytes = new TextEncoder().encode(JSON.stringify({ filename: file.name, password: values.password }));
    const headerLength = new ArrayBuffer(4);
    new DataView(headerLength).setUint32(0, headerBytes.length, false);
    const body = new Blob([headerLength, headerBytes, file], { type: 'application/vnd.ingar.portable-backup-import' });
    const result = await api('/api/v1/backups/portable/import', { method: 'POST', body });
    $('#backup-import-file').value = '';
    flash(result.verified ? 'Backup portátil importado y verificado.' : 'Backup portátil importado.');
    await loadBackups();
  } catch (error) { flash(error.message, 'error'); }
});
$('#backups-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-backup-action]'); if (!button) return;
  try {
    if (button.dataset.backupAction === 'verify') { await api(`/api/v1/backups/${button.dataset.id}/verify`, { method: 'POST', body: '{}' }); flash('Backup verificado.'); }
    if (button.dataset.backupAction === 'portable') {
      const values = await askFields('Exportar backup portátil', [
        { name: 'password', label: 'Contraseña portátil', type: 'password' },
        { name: 'confirmation', label: 'Repetir contraseña', type: 'password' }
      ], { message: 'Esta contraseña será necesaria para importar el archivo en otra instalación. No se guarda en el sistema.', confirmText: 'Exportar' });
      if (!values) return;
      if (values.password !== values.confirmation) throw new Error('Las contraseñas no coinciden.');
      const response = await fetch(`/api/v1/backups/${button.dataset.id}/portable`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { Accept: 'application/vnd.ingar.portable-backup', 'Content-Type': 'application/json', 'X-CSRF-Token': state.csrfToken },
        body: JSON.stringify({ password: values.password })
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || `Error HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const filename = filenameFromDisposition(response.headers.get('content-disposition'), 'INGAR-backup-portatil.iwcportable');
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
      flash('Backup portátil exportado.');
    }
    if (button.dataset.backupAction === 'restore') {
      const values = await askFields('Restaurar backup', [
        { name: 'confirmation', label: `Confirmación obligatoria: RESTORE:${button.dataset.id}`, placeholder: `RESTORE:${button.dataset.id}` }
      ], { message: 'Esta operación reemplaza la base activa. Verificá la selección antes de continuar.', confirmText: 'Restaurar', danger: true });
      if (!values) return;
      const result = await api(`/api/v1/backups/${button.dataset.id}/restore`, { method: 'POST', body: JSON.stringify({ confirmation: values.confirmation }) });
      if (result.requiresReauthentication) {
        sessionStorage.removeItem('iwc_csrf');
        await showNotice('Restauración terminada', 'La base fue restaurada y se creó una copia de seguridad previa. Ingrese nuevamente con los usuarios del backup.');
        location.reload();
        return;
      }
      flash('Backup restaurado.');
    }
    await loadBackups();
  } catch (error) { flash(error.message, 'error'); }
});


