function systemStatusClass(status) {
  const value = String(status || '').toUpperCase();
  if (['OK', 'READY', 'UP', 'SUCCESS', 'VERIFICADO'].includes(value)) return 'ok';
  if (['ATTENTION', 'DEGRADED', 'FAILED', 'FALLIDO', 'MISSING', 'UNAVAILABLE'].includes(value)) return 'danger';
  return 'neutral';
}

function systemStatusLabel(status) {
  const labels = {
    OK: 'Correcto', READY: 'Disponible', UP: 'Disponible', ATTENTION: 'Requiere atención',
    DEGRADED: 'Requiere atención', PENDING: 'Pendiente', MISSING: 'Sin datos', FAILED: 'Falló',
    FALLIDO: 'Falló', UNAVAILABLE: 'No disponible', VERIFICADO: 'Verificado'
  };
  const value = String(status || '').toUpperCase();
  return labels[value] || value || 'Sin datos';
}

function systemDate(value) {
  return value ? formatDateTime(value) : 'Sin registro';
}

function systemVersion(value) {
  const match = String(value || '').match(/\d+\.\d+\.\d+/);
  return match ? match[0] : 'No informada';
}

function systemDuration(seconds) {
  const total = Math.max(0, Number(seconds || 0));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  return days ? `${days} d ${hours} h` : hours ? `${hours} h ${minutes} min` : `${minutes} min`;
}

function renderSystemDetails(target, rows) {
  const node = $(target);
  if (!node) return;
  node.innerHTML = rows.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value ?? '—')}</dd></div>`).join('');
}

function renderSystemBadge(target, status) {
  const node = $(target);
  if (!node) return;
  node.className = `status ${systemStatusClass(status)}`;
  node.textContent = systemStatusLabel(status);
}

function renderSystemStatus(data) {
  const overall = $('#system-status-summary');
  const ready = data.status === 'READY';
  overall.className = `system-status-summary notice ${ready ? 'neutral' : 'warn'}`;
  overall.innerHTML = ready
    ? '<strong>Sistema disponible.</strong> No se detectaron problemas en los controles consultados.'
    : '<strong>Hay elementos para revisar.</strong> Abrí la tarjeta marcada para conocer el detalle.';
  $('#system-status-updated').textContent = `Última comprobación: ${systemDate(data.generatedAt)}.`;

  renderSystemBadge('#system-server-state', data.server?.status);
  renderSystemDetails('#system-server-details', [
    ['Estado', systemStatusLabel(data.server?.status)],
    ['Versión instalada', systemVersion(data.server?.version)],
    ['Entorno', String(data.server?.platform || '—').toUpperCase()],
    ['Tiempo activo', systemDuration(data.server?.uptimeSeconds)]
  ]);

  renderSystemBadge('#system-database-state', data.database?.status);
  renderSystemDetails('#system-database-details', [
    ['Integridad', data.database?.quickCheck === 'ok' ? 'Correcta' : 'Revisar'],
    ['Protección', data.database?.encryptedAtRest ? 'Cifrada' : 'Revisar'],
    ['Clave local', data.database?.keyProtection?.provider || '—'],
    ['Esquema', data.database?.schemaVersion ?? '—'],
    ['Última actualización', data.database?.latestMigration ? `${data.database.latestMigration.version} · ${systemDate(data.database.latestMigration.applied_at)}` : 'Sin registro'],
    ['Copia previa', data.database?.latestExecution?.backupCreated ? 'Registrada' : 'No aplica / sin registro']
  ]);

  if (data.backup) {
    renderSystemBadge('#system-backup-state', data.backup.status);
    renderSystemDetails('#system-backup-details', [
      ['Copias registradas', data.backup.count],
      ['Última copia', systemDate(data.backup.latestAt)],
      ['Estado', systemStatusLabel(data.backup.latestStatus)],
      ['Protección', data.backup.encryptedAtRest ? 'Cifrada' : 'Revisar'],
      ['Última verificación', systemDate(data.backup.latestVerifiedAt)]
    ]);
  }

  if (data.audit) {
    renderSystemBadge('#system-audit-state', data.audit.status);
    renderSystemDetails('#system-audit-details', [
      ['Eventos activos', data.audit.liveEvents],
      ['Eventos archivados', data.audit.archivedEvents],
      ['Segmentos', data.audit.archivedSegments],
      ['Avisos', data.audit.warnings?.length ? data.audit.warnings.length : 'Ninguno']
    ]);
  }

  if (data.scheduler) {
    renderSystemBadge('#system-scheduler-state', data.scheduler.status);
    renderSystemDetails('#system-scheduler-details', [
      ['Trabajos configurados', data.scheduler.total],
      ['Habilitados', data.scheduler.enabled],
      ['Con error', data.scheduler.failed],
      ['Última ejecución', systemDate(data.scheduler.lastRunAt)]
    ]);
  }

  if (data.mobileAccess) {
    renderSystemBadge('#system-portal-state', data.mobileAccess.status);
    renderSystemDetails('#system-portal-details', [
      ['Disponibilidad', data.mobileAccess.available ? 'Disponible' : 'No disponible'],
      ['Dirección local', data.mobileAccess.address || 'Sin dirección'],
      ['Interfaz', data.mobileAccess.interfaceName || 'Sin detectar'],
      ['Transporte', data.mobileAccess.transport || 'HTTP'],
      ['Acceso móvil', data.mobileAccess.diagnosticCode === 'READY' ? 'Confirmado' : (data.mobileAccess.available ? 'Por verificar desde celular' : 'No disponible')],
      ['Firewall', data.mobileAccess.firewallStatus === 'UNMANAGED' ? 'Sin cambios administrativos' : (data.mobileAccess.firewallStatus || 'Sin comprobar')]
    ]);
  }
}

async function loadSystemStatus() {
  const refresh = $('#system-status-refresh');
  refresh?.classList.add('is-busy');
  try {
    const data = await api('/api/v1/system/status');
    state.systemStatus = data;
    renderSystemStatus(data);
  } finally {
    refresh?.classList.remove('is-busy');
  }
}

async function loadSystemAdministration() {
  await loadSystemStatus();
  if (can('Resilience.Read')) await loadResilience();
}

async function loadResilience(){const [status,jobs]=await Promise.all([api('/api/v1/resilience/status'),api('/api/v1/scheduler/jobs')]);state.resilience=status;state.schedulerJobs=jobs.items;$('#resilience-status').textContent=JSON.stringify(status,null,2);$('#scheduler-jobs-body').innerHTML=jobs.items.map(x=>`<tr><td><strong>${escapeHtml(x.code)}</strong><div class="small">${escapeHtml(x.name)}</div></td><td>${x.interval_seconds} s</td><td>${escapeHtml(x.last_run_at?formatDateTime(x.last_run_at):'—')}</td><td>${escapeHtml(x.next_run_at?formatDateTime(x.next_run_at):'—')}</td><td><span class="status ${x.last_status==='FAILED'?'danger':x.last_status==='SUCCESS'?'ok':'neutral'}">${escapeHtml(x.enabled?x.last_status||'PENDIENTE':'DESHABILITADO')}</span></td><td class="actions">${can('Scheduler.Run')?`<button data-scheduler-run="${x.code}">Ejecutar</button>`:''}${can('Scheduler.Manage')?`<button data-scheduler-edit="${x.id}">Configurar</button>`:''}</td></tr>`).join('');}
$('#resilience-refresh').addEventListener('click', () => loadResilience().catch((error) => flash(error.message, 'error')));
$('#system-status-refresh')?.addEventListener('click', () => loadSystemStatus().catch((error) => flash(error.message, 'error')));
document.addEventListener('click', (event) => {
  const openButton = event.target.closest('[data-system-open]');
  if (openButton && !openButton.hidden) setView(openButton.dataset.systemOpen);
  const scrollButton = event.target.closest('[data-system-scroll]');
  if (scrollButton && !scrollButton.hidden) { const target = document.getElementById(scrollButton.dataset.systemScroll); if (target) { target.open = true; target.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }
});
$('#scheduler-jobs-body').addEventListener('click', async (event) => {
  const run = event.target.closest('[data-scheduler-run]');
  const edit = event.target.closest('[data-scheduler-edit]');
  try {
    if (run) {
      await api(`/api/v1/scheduler/jobs/${run.dataset.schedulerRun}/run`, { method: 'POST', body: '{}' });
      flash('Trabajo ejecutado.');
    } else if (edit) {
      const job = state.schedulerJobs.find((item) => item.id === edit.dataset.schedulerEdit);
      const values = await askFields(`Configurar ${job.code}`, [
        { name: 'intervalSeconds', label: 'Intervalo en segundos', type: 'number', value: job.interval_seconds },
        { name: 'enabled', label: 'Estado', type: 'select', value: job.enabled ? 'true' : 'false', options: [{ value: 'true', label: 'Habilitado' }, { value: 'false', label: 'Deshabilitado' }] }
      ], { confirmText: 'Guardar' });
      if (!values) return;
      await api(`/api/v1/scheduler/jobs/${job.id}`, { method: 'PATCH', body: JSON.stringify({ version: job.version, intervalSeconds: Number(values.intervalSeconds), enabled: values.enabled === 'true' }) });
      flash('Scheduler actualizado.');
    }
    await loadResilience();
  } catch (error) { flash(error.message, 'error'); }
});

window.addEventListener('online', () => { $('#connection-state').textContent = 'Servidor disponible'; $('#connection-state').className = 'status ok'; });
window.addEventListener('offline', () => { $('#connection-state').textContent = 'Sin conexión'; $('#connection-state').className = 'status danger'; });

const TABLE_EMPTY_MESSAGES = Object.freeze({
  'users-body': 'No hay personas o usuarios que coincidan con la consulta.',
  'assets-body': 'No hay bienes o herramientas para los filtros aplicados.',
  'categories-body': 'No hay categorías registradas para mostrar.',
  'imports-body': 'No hay lotes de importación para los filtros aplicados.',
  'import-rows-body': 'El lote no contiene filas para mostrar.',
  'requests-body': 'No hay solicitudes en esta bandeja para los filtros aplicados.',
  'custodies-body': 'No hay custodias o devoluciones para los filtros aplicados.',
  'custody-integrity-body': 'No se detectaron anomalías de integridad en custodias.',
  'transfers-body': 'No hay transferencias de custodia pendientes.',
  'incidents-body': 'No hay incidentes para los filtros aplicados.',
  'blocks-body': 'No hay bloqueos operativos para los filtros aplicados.',
  'exceptions-body': 'No hay excepciones asociadas para mostrar.',
  'vehicles-body': 'No hay vehículos registrados para mostrar.',
  'kits-body': 'No hay kits registrados para mostrar.',
  'stock-body': 'No hay existencias para la ubicación seleccionada.',
  'inventory-body': 'No hay inventarios físicos para los filtros aplicados.',
  'inventory-transfers-body': 'No hay transferencias internas para los filtros aplicados.',
  'maintenance-plans-body': 'No hay planes de mantenimiento para mostrar.',
  'maintenance-orders-body': 'No hay órdenes de mantenimiento para mostrar.',
  'notifications-body': 'No hay alertas para mostrar.',
  'scheduler-jobs-body': 'No hay trabajos programados para mostrar.',
  'policies-body': 'No hay políticas de solicitudes para mostrar.',
  'locations-body': 'No hay sedes o ubicaciones para mostrar.',
  'audit-body': 'No hay eventos de auditoría para los filtros aplicados.',
  'logs-body': 'No hay eventos técnicos para los filtros aplicados.',
  'backups-body': 'No hay copias de seguridad registradas.',
  'asset-documents-body': 'El bien no tiene documentación asociada.',
  'request-return-body': 'La solicitud no tiene custodias abiertas para devolución.',
  'actions-body': 'No hay acciones para los filtros actuales.',
  'actions-mine-body': 'No hay acciones asignadas o creadas por usted.',
  'actions-overdue-body': 'No hay acciones vencidas.',
  'meetings-body': 'No hay actas o reuniones registradas.'
});
