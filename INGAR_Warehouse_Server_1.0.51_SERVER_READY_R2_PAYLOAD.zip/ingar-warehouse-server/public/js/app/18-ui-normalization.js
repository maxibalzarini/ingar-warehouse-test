const TABLE_PRESENTATION_STATE = new WeakMap();

function isLegacyEmptyRow(tbody, row) {
  if (!tbody.id || row.matches('[data-generated-empty="true"]') || row.cells.length !== 1) return false;
  const cell = row.cells[0];
  if (cell.querySelector('button, a[href], input, select, textarea') || Number(cell.colSpan) < 2) return false;
  return /^(No hay|No existen|No se detectaron|Sin (?!acceso))/i.test(cell.textContent.trim());
}

function tableDataRows(tbody) {
  return [...tbody.children].filter((row) => !row.matches('[data-generated-empty="true"]') && !isLegacyEmptyRow(tbody, row));
}

function updateOperationalTable(table) {
  const tbody = table.tBodies?.[0];
  if (!tbody) return;
  const headers = [...table.querySelectorAll('thead th')].map((header) => header.textContent.trim());
  const legacyEmptyRows = [...tbody.children].filter((row) => isLegacyEmptyRow(tbody, row));
  legacyEmptyRows.forEach((row) => row.remove());
  const rows = tableDataRows(tbody);
  const emptyRow = tbody.querySelector('[data-generated-empty="true"]');
  if (rows.length === 0) {
    if (!emptyRow) {
      const row = document.createElement('tr');
      row.className = 'table-empty-row';
      row.dataset.generatedEmpty = 'true';
      const cell = document.createElement('td');
      cell.colSpan = Math.max(headers.length, 1);
      const message = TABLE_EMPTY_MESSAGES[tbody.id] || 'No hay registros para mostrar con los filtros actuales.';
      cell.innerHTML = `<div class="table-empty-state" role="status"><svg class="ui-icon table-empty-icon" aria-hidden="true" focusable="false"><use href="/assets/icons.svg#icon-info"></use></svg><div><strong>Sin registros</strong><span>${escapeHtml(message)}</span></div></div>`;
      row.appendChild(cell);
      tbody.appendChild(row);
    }
  } else if (emptyRow) {
    emptyRow.remove();
  }
  rows.forEach((row) => {
    [...row.cells].forEach((cell, index) => {
      if (headers[index]) cell.dataset.label = headers[index];
    });
    const actionCell = [...row.cells].find((cell) => cell.querySelector('button, a[href]'));
    if (actionCell) actionCell.classList.add('actions');
  });
  const stateForTable = TABLE_PRESENTATION_STATE.get(table);
  if (stateForTable) {
    stateForTable.count.textContent = `${rows.length} ${rows.length === 1 ? 'registro' : 'registros'}`;
    stateForTable.meta.classList.toggle('is-empty', rows.length === 0);
  }
}

function prepareOperationalTable(table, index) {
  if (table.dataset.interfaceNormalized === 'true') return;
  table.dataset.interfaceNormalized = 'true';
  table.classList.add('operational-table');
  table.querySelectorAll('thead th').forEach((header) => header.setAttribute('scope', 'col'));
  const wrap = table.closest('.table-wrap');
  if (!wrap) return;
  wrap.classList.add('operational-table-wrap');
  wrap.tabIndex = 0;
  const view = table.closest('.view');
  const sectionHeading = table.closest('article, section')?.querySelector('h3, h4')?.textContent?.trim();
  const viewName = view?.id?.replace('view-', '') || `tabla-${index + 1}`;
  wrap.setAttribute('aria-label', sectionHeading ? `Tabla: ${sectionHeading}` : `Tabla de ${viewName}`);
  let meta = wrap.previousElementSibling;
  if (!meta?.classList?.contains('table-meta')) {
    meta = document.createElement('div');
    meta.className = 'table-meta';
    meta.innerHTML = '<span class="table-meta-label">Resultados</span><strong class="table-count" aria-live="polite">0 registros</strong>';
    wrap.parentNode.insertBefore(meta, wrap);
  }
  const count = meta.querySelector('.table-count');
  TABLE_PRESENTATION_STATE.set(table, { meta, count });
  const observer = new MutationObserver(() => updateOperationalTable(table));
  observer.observe(table.tBodies[0], { childList: true, subtree: false });
  updateOperationalTable(table);
}

function prepareNormalizedForm(form) {
  if (form.dataset.interfaceNormalized === 'true') return;
  form.dataset.interfaceNormalized = 'true';
  form.classList.add('normalized-form');
  form.querySelectorAll('label').forEach((label) => {
    const control = label.querySelector('input, select, textarea');
    if (!control) return;
    label.classList.add('field-shell');
    if (control.required) {
      label.classList.add('field-required');
      control.setAttribute('aria-required', 'true');
      if (!label.querySelector('.field-requirement')) {
        const marker = document.createElement('span');
        marker.className = 'field-requirement';
        marker.textContent = 'Obligatorio';
        marker.setAttribute('aria-hidden', 'true');
        label.insertBefore(marker, control);
      }
    }
    const maximum = Number(control.getAttribute('maxlength'));
    if (maximum > 0 && ['INPUT', 'TEXTAREA'].includes(control.tagName) && !label.querySelector('.field-counter')) {
      const counter = document.createElement('span');
      counter.className = 'field-counter';
      const refresh = () => { counter.textContent = `${control.value.length}/${maximum}`; };
      control.insertAdjacentElement('afterend', counter);
      control.addEventListener('input', refresh);
      refresh();
    }
  });
}

function prepareFilterToolbar(toolbar) {
  if (toolbar.dataset.interfaceNormalized === 'true') return;
  toolbar.dataset.interfaceNormalized = 'true';
  toolbar.classList.add('normalized-toolbar');
  const hasFilterControls = Boolean(toolbar.querySelector('input:not([type="file"]), select'));
  toolbar.classList.toggle('filter-toolbar', hasFilterControls);
  toolbar.setAttribute('role', 'group');
  toolbar.setAttribute('aria-label', hasFilterControls ? 'Filtros y acciones de la vista' : 'Acciones de la vista');
}

function prepareDialog(dialog) {
  if (dialog.dataset.interfaceNormalized === 'true') return;
  dialog.dataset.interfaceNormalized = 'true';
  const id = dialog.id || '';
  const danger = /(incident|block|resolve)/i.test(id);
  const operation = /(handover|receive|return|preparation|transfer)/i.test(id);
  dialog.dataset.dialogTone = danger ? 'danger' : operation ? 'operation' : 'neutral';
  dialog.querySelectorAll('footer button[type="submit"]').forEach((button) => button.classList.add('dialog-primary-action'));
  dialog.querySelectorAll('footer .dialog-close, footer button[type="button"]').forEach((button) => button.classList.add('dialog-secondary-action'));
}

function normalizeVisibleCodeText(root = document) {
  const elements = [];
  if (root.nodeType === Node.ELEMENT_NODE) elements.push(root);
  if (root.querySelectorAll) elements.push(...root.querySelectorAll('option, td, th, span, strong, small, div, p, label'));
  for (const element of elements) {
    if (element.closest('code, pre, script, style, textarea, [data-raw-code="true"]')) continue;
    if (element.children.length) continue;
    const original = element.textContent;
    const raw = original.trim();
    if (!raw) continue;
    const translated = uiCodeLabel(raw);
    if (translated === raw) continue;
    const leading = original.match(/^\s*/)?.[0] || '';
    const trailing = original.match(/\s*$/)?.[0] || '';
    element.textContent = `${leading}${translated}${trailing}`;
  }
}

function normalizeInterfaceWithin(root = document) {
  const select = (selector) => {
    const matches = root.matches?.(selector) ? [root] : [];
    return [...matches, ...root.querySelectorAll(selector)];
  };
  select('.table-wrap table').forEach(prepareOperationalTable);
  select('form').forEach(prepareNormalizedForm);
  select('.toolbar').forEach(prepareFilterToolbar);
  select('dialog').forEach(prepareDialog);
  normalizeVisibleCodeText(root);
}

function initializeInterfaceNormalization() {
  normalizeInterfaceWithin(document);
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => mutation.addedNodes.forEach((node) => {
      if (node.nodeType === Node.ELEMENT_NODE) normalizeInterfaceWithin(node);
      else if (node.nodeType === Node.TEXT_NODE && node.parentElement) normalizeVisibleCodeText(node.parentElement);
    }));
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

initializeInterfaceNormalization();
bootstrap();

async function purgeLegacyDesktopCaches(){
  if('serviceWorker' in navigator){
    const registrations=await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.map(item=>item.unregister()));
  }
  if('caches' in window){
    const keys=await caches.keys();
    await Promise.all(keys.map(key=>caches.delete(key)));
  }
}
window.addEventListener('load',()=>purgeLegacyDesktopCaches().catch(()=>{}));

document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshNotificationsBackground().catch(()=>{});});
