function incidentStatusClass(status) {
  if (status === 'CERRADO') return 'neutral';
  if (status === 'RESUELTO') return 'ok';
  return status === 'EN_INVESTIGACION' ? 'warn' : 'danger';
}
function severityClass(severity) { return ['CRITICA','ALTA'].includes(severity) ? 'danger' : severity === 'MEDIA' ? 'warn' : 'neutral'; }

async function ensureIncidentDependencies({ includeAssets = true } = {}) {
  const jobs = [];
  if (includeAssets && !state.assets.length) jobs.push(api('/api/v1/assets?active=true&limit=1000').then((data) => { state.assets = data.items; }));
  if (!state.categories.length) jobs.push(api('/api/v1/asset-categories?limit=1000').then((data) => { state.categories = data.items; }));
  if (!state.users.length && (can('Users.Read') || can('Incident.Investigate') || can('Blocks.Manage'))) jobs.push(api('/api/v1/users?limit=1000').then((data) => { state.users = data.items; }));
  if (!state.locations.sites.length && (can('Config.Read') || can('Blocks.Manage'))) jobs.push(api('/api/v1/locations').then((data) => { state.locations = data; }));
  await Promise.all(jobs);
}

function incidentAssetLabel(asset) {
  const location = [asset.site_code, asset.location_code].filter(Boolean).join('/');
  return [asset.internal_code, asset.description, asset.brand, asset.model, asset.category_name, location, asset.status].filter(Boolean).join(' · ');
}

function ensureIncidentAssetStatusWarning() {
  let warning = $('#incident-asset-status-warning');
  if (warning) return warning;
  const select = $('#incident-asset');
  warning = document.createElement('span');
  warning.id = 'incident-asset-status-warning';
  warning.className = 'field-help';
  warning.setAttribute('aria-live', 'polite');
  warning.hidden = true;
  select.closest('label')?.appendChild(warning);
  return warning;
}

function syncIncidentAssetStatusWarning() {
  const select = $('#incident-asset');
  const selected = select?.selectedOptions?.[0];
  const assetStatus = String(selected?.dataset?.status || '').trim().toUpperCase();
  const warning = ensureIncidentAssetStatusWarning();
  if (!selected?.value || !assetStatus || assetStatus === 'DISPONIBLE') {
    warning.hidden = true;
    warning.dataset.state = '';
    warning.textContent = '';
    return;
  }
  warning.hidden = false;
  warning.dataset.state = 'error';
  warning.textContent = `Atención: el bien seleccionado está en estado ${assetStatus}. El incidente puede registrarse igualmente y el bien será bloqueado.`;
}

function renderIncidentAssetOptions(items, preferredId = '') {
  const select = $('#incident-asset');
  const status = $('#incident-asset-search-status');
  const previousId = preferredId || select.value;
  const activeItems = (items || []).filter((asset) => asset.active);
  select.innerHTML = activeItems.length
    ? activeItems.map((asset) => `<option value="${escapeHtml(asset.id)}" data-status="${escapeHtml(String(asset.status || ''))}">${escapeHtml(incidentAssetLabel(asset))}</option>`).join('')
    : '<option value="">Sin coincidencias</option>';
  select.disabled = activeItems.length === 0;
  if (previousId && activeItems.some((asset) => asset.id === previousId)) select.value = previousId;
  syncIncidentAssetStatusWarning();
  status.dataset.state = activeItems.length ? 'ok' : 'error';
  status.textContent = activeItems.length
    ? `${activeItems.length} ${activeItems.length === 1 ? 'resultado encontrado' : 'resultados encontrados'}. Elegí el bien correcto.`
    : 'No se encontraron bienes con esas palabras.';
}

async function searchIncidentAssets({ preferredId = '' } = {}) {
  const query = $('#incident-asset-search').value.trim();
  const status = $('#incident-asset-search-status');
  const sequence = ++incidentAssetSearchSequence;
  status.dataset.state = '';
  status.textContent = 'Buscando...';
  const params = new URLSearchParams({ active: 'true', limit: '100' });
  if (query) params.set('search', query);
  try {
    const data = await api(`/api/v1/assets?${params}`);
    if (sequence !== incidentAssetSearchSequence) return;
    renderIncidentAssetOptions(data.items, preferredId);
  } catch (error) {
    if (sequence !== incidentAssetSearchSequence) return;
    $('#incident-asset').innerHTML = '<option value="">No fue posible buscar</option>';
    $('#incident-asset').disabled = true;
    syncIncidentAssetStatusWarning();
    status.dataset.state = 'error';
    status.textContent = error.message;
  }
}

function scheduleIncidentAssetSearch() {
  clearTimeout(incidentAssetSearchTimer);
  incidentAssetSearchTimer = setTimeout(() => {
    searchIncidentAssets().catch((error) => flash(error.message, 'error'));
  }, INCIDENT_ASSET_SEARCH_DELAY_MS);
}

async function loadIncidents() {
  const params = dashboardFilterParams('incidents');
  params.set('search', $('#incident-search').value); if (!params.has('statuses')) params.set('status', $('#incident-status').value); if (!params.has('severity')) params.set('severity', $('#incident-severity').value); params.set('type', $('#incident-type').value); params.set('limit', '300');
  const data = await api(`/api/v1/incidents?${params}`); state.incidents = data.items;
  $('#incidents-body').innerHTML = data.items.map((item) => `<tr><td><strong>${escapeHtml(item.incident_number)}</strong><div class="small">${escapeHtml(item.title)}</div></td>
    <td><strong>${escapeHtml(item.internal_code)}</strong><div class="small">${escapeHtml(item.asset_description)}</div></td><td>${escapeHtml(uiCodeLabel(item.type))}</td>
    <td><span class="status ${severityClass(item.severity)}">${escapeHtml(uiCodeLabel(item.severity))}</span></td><td><span class="status ${incidentStatusClass(item.status)}">${escapeHtml(uiCodeLabel(item.status))}</span></td>
    <td>${escapeHtml(item.assigned_name || 'Sin asignar')}</td><td>${escapeHtml(formatDateTime(item.opened_at))}</td><td><button data-incident-action="detail" data-id="${item.id}">Detalle</button></td></tr>`).join('');
}

function incidentActionsHtml(incident) {
  const actions = [];
  if (can('Incident.Investigate') && incident.status === 'ABIERTO') actions.push('<button data-detail-action="start">Iniciar investigación</button>');
  if (can('Incident.Investigate') && incident.status !== 'CERRADO') actions.push('<button data-detail-action="note">Agregar nota</button>');
  if (can('Incident.Investigate') && ['ABIERTO','EN_INVESTIGACION'].includes(incident.status)) actions.push('<button data-detail-action="action">Nueva acción</button>');
  if (can('Incident.Evidence') && incident.status !== 'CERRADO') actions.push('<button data-detail-action="evidence">Adjuntar evidencia</button>');
  if (can('Incident.Resolve') && ['ABIERTO','EN_INVESTIGACION'].includes(incident.status)) actions.push('<button data-detail-action="resolve" class="primary">Resolver</button>');
  if (can('Incident.Close') && incident.status === 'RESUELTO') actions.push('<button data-detail-action="close" class="primary">Cerrar</button>');
  if (can('Incident.Resolve') && ['RESUELTO','CERRADO'].includes(incident.status)) actions.push('<button data-detail-action="reopen">Reabrir</button>');
  return actions.join('');
}

function renderIncidentDetail(incident) {
  state.currentIncident = incident;
  $('#incident-detail-title').textContent = `${incident.incident_number} · ${uiCodeLabel(incident.status)}`;
  const events = incident.events?.length ? incident.events.map((e) => `<li><strong>${escapeHtml(uiCodeLabel(e.event_type))}</strong> · ${escapeHtml(formatDateTime(e.occurred_at))} · ${escapeHtml(e.actor_name || 'Sistema')}<br>${escapeHtml(e.details)}</li>`).join('') : '<li>Sin eventos.</li>';
  const evidence = incident.evidence?.length ? incident.evidence.map((e) => `<li><a href="/api/v1/evidence/${encodeURIComponent(e.evidence_id)}" target="_blank" rel="noopener">${escapeHtml(e.filename)}</a> · ${escapeHtml(uiCodeLabel(e.evidence_type))} · SHA-256 ${escapeHtml(e.sha256)}</li>`).join('') : '<li>Sin evidencias.</li>';
  const actions = incident.actions?.length ? incident.actions.map((a) => `<tr><td>${escapeHtml(uiCodeLabel(a.action_type))}</td><td>${escapeHtml(a.description)}</td><td>${escapeHtml(a.assigned_name || 'Sin asignar')}</td><td>${escapeHtml(formatDateTime(a.due_at))}</td><td>${escapeHtml(uiCodeLabel(a.status))}</td><td>${can('Incident.Investigate') && !['COMPLETADA','CANCELADA'].includes(a.status) ? `<button data-investigation-action-id="${a.id}" data-version="${a.version}">Actualizar</button>` : escapeHtml(a.result || '')}</td></tr>`).join('') : '<tr><td colspan="6">Sin acciones.</td></tr>';
  $('#incident-detail-content').innerHTML = `<div class="request-summary-grid"><div><span>Bien</span><strong>${escapeHtml(incident.internal_code)} · ${escapeHtml(incident.asset_description)}</strong></div><div><span>Tipo / severidad</span><strong>${escapeHtml(uiCodeLabel(incident.type))} · ${escapeHtml(uiCodeLabel(incident.severity))}</strong></div><div><span>Reportado por</span><strong>${escapeHtml(incident.reporter_name)}</strong></div><div><span>Asignado</span><strong>${escapeHtml(incident.assigned_name || 'Sin asignar')}</strong></div><div><span>Fecha del hecho</span><strong>${escapeHtml(formatDateTime(incident.occurred_at || incident.detected_at))}</strong></div><div><span>Estado del bien</span><strong>${escapeHtml(uiCodeLabel(incident.asset_status))}</strong></div></div>
    <article class="detail-block"><h4>${escapeHtml(incident.title)}</h4><p>${escapeHtml(incident.description)}</p>${incident.root_cause ? `<p><strong>Causa raíz:</strong> ${escapeHtml(incident.root_cause)}</p>` : ''}${incident.resolution_notes ? `<p><strong>Resolución:</strong> ${escapeHtml(incident.resolution_notes)}</p>` : ''}</article>
    <h4>Acciones de investigación</h4><div class="table-wrap"><table><thead><tr><th>Tipo</th><th>Descripción</th><th>Responsable</th><th>Vencimiento</th><th>Estado</th><th>Resultado</th></tr></thead><tbody>${actions}</tbody></table></div>
    <div class="detail-columns"><div><h4>Eventos</h4><ol class="timeline">${events}</ol></div><div><h4>Evidencias</h4><ul>${evidence}</ul><h4>Bloqueos asociados</h4><ul>${incident.blocks?.length ? incident.blocks.map((b) => `<li>${escapeHtml(b.block_number)} · ${escapeHtml(uiCodeLabel(b.target_type))} · ${escapeHtml(uiCodeLabel(b.status))}</li>`).join('') : '<li>Sin bloqueos.</li>'}</ul></div></div>`;
  $('#incident-detail-actions').innerHTML = incidentActionsHtml(incident);
  if (!$('#incident-detail-dialog').open) $('#incident-detail-dialog').showModal();
}

async function refreshIncidentDetail() {
  if (!state.currentIncident) return;
  renderIncidentDetail((await api(`/api/v1/incidents/${state.currentIncident.id}`)).incident);
  await loadIncidents();
}

$('#incident-refresh').addEventListener('click', () => loadIncidents().catch((error) => flash(error.message, 'error')));
$('#incident-search').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadIncidents().catch((error) => flash(error.message, 'error')); });
$('#incident-export').addEventListener('click', () => { const params = new URLSearchParams({ search: $('#incident-search').value, status: $('#incident-status').value, severity: $('#incident-severity').value, type: $('#incident-type').value }); downloadFile(`/api/v1/incidents/export?${params}`, `incidentes-${new Date().toISOString().slice(0,10)}.csv`).catch((error) => flash(error.message, 'error')); });
$('#incident-create').addEventListener('click', async () => {
  try {
    await ensureIncidentDependencies({ includeAssets: false });
    $('#incident-form').reset();
    $('#incident-asset-search').value = '';
    $('#incident-asset').innerHTML = '<option value="">Buscando bienes...</option>';
    $('#incident-asset').disabled = true;
    syncIncidentAssetStatusWarning();
    $('#incident-occurred').value = dateTimeLocalValue(new Date());
    $('#incident-dialog').showModal();
    await searchIncidentAssets();
    setTimeout(() => $('#incident-asset-search').focus(), 30);
  } catch (error) { flash(error.message, 'error'); }
});
$('#incident-asset').addEventListener('change', syncIncidentAssetStatusWarning);
$('#incident-asset-search').addEventListener('input', scheduleIncidentAssetSearch);
$('#incident-asset-search').addEventListener('keydown', (event) => {
  if (event.key !== 'Enter') return;
  event.preventDefault();
  clearTimeout(incidentAssetSearchTimer);
  searchIncidentAssets().catch((error) => flash(error.message, 'error'));
});
$('#incident-form').addEventListener('submit', async (event) => { event.preventDefault(); try { await api('/api/v1/incidents', { method: 'POST', headers: { 'Idempotency-Key': newIdempotencyKey('incident') }, body: JSON.stringify({ assetId: $('#incident-asset').value, type: $('#incident-type-edit').value, severity: $('#incident-severity-edit').value, occurredAt: $('#incident-occurred').value ? new Date($('#incident-occurred').value).toISOString() : null, title: $('#incident-title').value, description: $('#incident-description').value, blockCustodian: $('#incident-block-custodian').checked }) }); $('#incident-dialog').close(); flash('Incidente abierto y bien bloqueado.'); await loadIncidents(); } catch (error) { flash(error.message, 'error'); } });
$('#incidents-body').addEventListener('click', async (event) => { const button = event.target.closest('[data-incident-action="detail"]'); if (!button) return; try { renderIncidentDetail((await api(`/api/v1/incidents/${button.dataset.id}`)).incident); } catch (error) { flash(error.message, 'error'); } });

$('#incident-detail-actions').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-detail-action]'); if (!button || !state.currentIncident) return;
  const incident = state.currentIncident;
  try {
    if (button.dataset.detailAction === 'start') {
      const values = await askFields('Iniciar investigación', [{ name: 'plan', label: 'Plan de investigación', type: 'textarea' }], { confirmText: 'Iniciar' });
      if (!values) return;
      await api(`/api/v1/incidents/${incident.id}/start-investigation`, { method: 'POST', body: JSON.stringify({ version: incident.version, assignedToUserId: state.user.id, plan: values.plan }) });
    }
    if (button.dataset.detailAction === 'note') {
      const values = await askFields('Agregar nota', [{ name: 'note', label: 'Nota del incidente', type: 'textarea' }], { confirmText: 'Agregar' });
      if (!values) return;
      await api(`/api/v1/incidents/${incident.id}/notes`, { method: 'POST', body: JSON.stringify({ version: incident.version, note: values.note }) });
    }
    if (button.dataset.detailAction === 'action') {
      const values = await askFields('Nueva acción de investigación', [
        { name: 'description', label: 'Acción', type: 'textarea' },
        { name: 'due', label: 'Vencimiento', type: 'datetime-local', value: dateTimeLocalValue(new Date(Date.now()+24*3600_000)), required: false }
      ], { confirmText: 'Crear acción' });
      if (!values) return;
      await api(`/api/v1/incidents/${incident.id}/actions`, { method: 'POST', body: JSON.stringify({ actionType: 'VERIFICACION', description: values.description, assignedToUserId: state.user.id, dueAt: values.due ? new Date(values.due).toISOString() : null }) });
    }
    if (button.dataset.detailAction === 'evidence') { $('#incident-evidence-form').reset(); $('#incident-evidence-incident-id').value = incident.id; $('#incident-evidence-version').value = incident.version; $('#incident-evidence-dialog').showModal(); return; }
    if (button.dataset.detailAction === 'resolve') {
      $('#incident-resolve-form').reset();
      $('#incident-resolve-id').value = incident.id;
      $('#incident-resolve-version').value = incident.version;
      syncIncidentResolveForm();
      $('#incident-resolve-dialog').showModal();
      queueMicrotask(() => $('#incident-resolution-notes').focus());
      return;
    }
    if (button.dataset.detailAction === 'close') {
      const values = await askFields('Cerrar incidente', [{ name: 'reason', label: 'Fundamento de cierre independiente', type: 'textarea' }], { confirmText: 'Cerrar incidente' });
      if (!values) return;
      await api(`/api/v1/incidents/${incident.id}/close`, { method: 'POST', body: JSON.stringify({ version: incident.version, reason: values.reason }) });
    }
    if (button.dataset.detailAction === 'reopen') {
      const values = await askFields('Reabrir incidente', [{ name: 'reason', label: 'Fundamento de reapertura', type: 'textarea' }], { confirmText: 'Reabrir' });
      if (!values) return;
      await api(`/api/v1/incidents/${incident.id}/reopen`, { method: 'POST', body: JSON.stringify({ version: incident.version, reason: values.reason }) });
    }
    flash('Incidente actualizado.'); await refreshIncidentDetail();
  } catch (error) { flash(error.message, 'error'); }
});

$('#incident-detail-content').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-investigation-action-id]'); if (!button) return;
  const values = await askFields('Actualizar acción', [
    { name: 'status', label: 'Nuevo estado', type: 'select', value: 'COMPLETADA', options: ['EN_CURSO','COMPLETADA','CANCELADA'] },
    { name: 'result', label: 'Resultado o fundamento', type: 'textarea', required: false }
  ], { confirmText: 'Actualizar' });
  if (!values) return;
  try {
    await api(`/api/v1/incident-actions/${button.dataset.investigationActionId}/update`, { method: 'POST', body: JSON.stringify({ version: Number(button.dataset.version), status: values.status, result: values.result || null }) });
    flash('Acción actualizada.'); await refreshIncidentDetail();
  } catch (error) { flash(error.message, 'error'); }
});
$('#incident-evidence-form').addEventListener('submit', async (event) => { event.preventDefault(); try { const file = $('#incident-evidence-file').files[0]; await api(`/api/v1/incidents/${$('#incident-evidence-incident-id').value}/evidence`, { method: 'POST', body: JSON.stringify({ version: Number($('#incident-evidence-version').value), originalFilename: file.name, dataUrl: await fileToDataUrl(file), evidenceType: $('#incident-evidence-type').value, description: $('#incident-evidence-description').value || null }) }); $('#incident-evidence-dialog').close(); flash('Evidencia adjuntada con hash.'); await refreshIncidentDetail(); } catch (error) { flash(error.message, 'error'); } });
function syncIncidentResolveForm() {
  const code = $('#incident-resolution-code').value;
  const condition = $('#incident-recovery-condition');
  const resolution = $('#incident-resolution-notes').value.trim();
  const submit = $('#incident-resolve-submit');
  const recovering = code === 'RECUPERADO_CONFORME' || code === 'RECUPERADO_BLOQUEADO';

  if (code === 'RECUPERADO_CONFORME') {
    condition.value = 'CONFORME';
    condition.disabled = true;
  } else if (code === 'RECUPERADO_BLOQUEADO') {
    condition.disabled = false;
    if (!['OBSERVADO','DANADO','INCOMPLETO'].includes(condition.value)) condition.value = 'OBSERVADO';
  } else {
    condition.value = '';
    condition.disabled = true;
  }

  const busy = submit.dataset.submitting === 'true';
  submit.disabled = busy || resolution.length < 1;
  submit.setAttribute('aria-disabled', submit.disabled ? 'true' : 'false');
  $('#incident-recovery-condition').closest('label').classList.toggle('field-disabled', !recovering);
}

$('#incident-resolution-notes').addEventListener('input', syncIncidentResolveForm);
$('#incident-resolution-code').addEventListener('change', syncIncidentResolveForm);
$('#incident-recovery-condition').addEventListener('change', syncIncidentResolveForm);

$('#incident-resolve-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = $('#incident-resolve-submit');
  if (submit.dataset.submitting === 'true') return;
  const resolutionNotes = $('#incident-resolution-notes').value.trim();
  if (!resolutionNotes) { syncIncidentResolveForm(); flash('Ingresá una resolución para habilitar Resolver.', 'error'); return; }
  const code = $('#incident-resolution-code').value;
  const recoveryCondition = code === 'RECUPERADO_CONFORME' ? 'CONFORME' : code === 'RECUPERADO_BLOQUEADO' ? $('#incident-recovery-condition').value : null;
  submit.dataset.submitting = 'true';
  submit.textContent = 'Resolviendo…';
  syncIncidentResolveForm();
  try {
    await api(`/api/v1/incidents/${$('#incident-resolve-id').value}/resolve`, {
      method: 'POST',
      body: JSON.stringify({
        version: Number($('#incident-resolve-version').value),
        resolutionCode: code,
        recoveryCondition,
        recoveredAt: code.startsWith('RECUPERADO_') ? new Date().toISOString() : null,
        rootCause: $('#incident-root-cause').value.trim() || null,
        resolutionNotes,
        estimatedCost: $('#incident-estimated-cost').value || null,
        actualCost: $('#incident-actual-cost').value || null
      })
    });
    $('#incident-resolve-dialog').close();
    flash('Incidente resuelto.');
    await refreshIncidentDetail();
  } catch (error) {
    flash(error.message, 'error');
  } finally {
    submit.dataset.submitting = 'false';
    submit.textContent = 'Resolver';
    syncIncidentResolveForm();
  }
});

function renderBlockTargetOptions() {
  const type = $('#block-target-type-edit').value;
  let rows = [];
  if (type === 'PERSONA') rows = state.users.filter((u) => u.active).map((u) => ({ id: u.personId, label: `${u.person.fullName}${userDocumentDisplay(u) ? ` · ${userDocumentDisplay(u)}` : ''}` }));
  if (type === 'ACTIVO') rows = state.assets.filter((a) => a.active).map((a) => ({ id: a.id, label: `${a.internal_code} · ${a.description}` }));
  if (type === 'CATEGORIA') rows = state.categories.filter((c) => c.active).map((c) => ({ id: c.id, label: `${c.code} · ${c.name}` }));
  $('#block-target-id').innerHTML = rows.map((r) => `<option value="${r.id}">${escapeHtml(r.label)}</option>`).join('');
}
async function loadBlocks() {
  const params = new URLSearchParams({ search: $('#block-search').value, status: $('#block-status').value, targetType: $('#block-target-type').value, limit: '300' });
  const [blocks, exceptions] = await Promise.all([api(`/api/v1/blocks?${params}`), api('/api/v1/block-exceptions?limit=300')]); state.blocks = blocks.items; state.exceptions = exceptions.items;
  $('#blocks-body').innerHTML = state.blocks.map((b) => `<tr><td><strong>${escapeHtml(b.block_number)}</strong><div class="small">${escapeHtml(b.reason)}</div></td><td>${escapeHtml(uiCodeLabel(b.target_type))}<div class="small">${escapeHtml(b.target_label)}</div></td><td>${escapeHtml(uiCodeLabel(b.scope_type))}${b.operation_type ? ` · ${escapeHtml(uiCodeLabel(b.operation_type))}` : ''}</td><td>${escapeHtml(b.source)}</td><td><span class="status ${severityClass(b.severity)}">${escapeHtml(uiCodeLabel(b.severity))}</span></td><td>${escapeHtml(formatDateTime(b.starts_at))}<div class="small">${b.expires_at ? `hasta ${escapeHtml(formatDateTime(b.expires_at))}` : 'sin vencimiento'}</div></td><td><span class="status ${b.effective_status === 'ACTIVO' ? 'danger' : 'neutral'}">${escapeHtml(uiCodeLabel(b.effective_status))}</span></td><td class="actions">${can('Blocks.Exception.Request') && b.effective_status === 'ACTIVO' ? `<button data-block-action="exception" data-id="${b.id}">Excepción</button>` : ''}${can('Blocks.Manage') && b.effective_status === 'ACTIVO' && b.target_type !== 'ACTIVO' ? `<button data-block-action="lift" data-id="${b.id}">Levantar</button>` : ''}${b.effective_status === 'ACTIVO' && b.target_type === 'ACTIVO' && can('Assets.ReleaseBlocked') ? `<span class="small">Habilitar desde Bienes</span>` : ''}</td></tr>`).join('');
  $('#exceptions-body').innerHTML = state.exceptions.map((e) => `<tr><td>${escapeHtml(e.person_name)}</td><td>${escapeHtml(e.block_number)}<div class="small">${escapeHtml(e.block_reason)}</div></td><td>${escapeHtml(uiCodeLabel(e.operation_type))}</td><td>${escapeHtml(e.asset_code || 'Todos')}</td><td>${e.valid_until ? escapeHtml(formatDateTime(e.valid_until)) : 'Pendiente'}</td><td><span class="status ${e.status === 'APROBADA' ? 'ok' : e.status === 'PENDIENTE' ? 'warn' : 'neutral'}">${escapeHtml(uiCodeLabel(e.status))}</span></td><td class="actions">${can('Blocks.Exception.Decide') && e.status === 'PENDIENTE' ? `<button data-exception-action="approve" data-id="${e.id}">Aprobar</button><button data-exception-action="reject" data-id="${e.id}">Rechazar</button>` : ''}</td></tr>`).join('');
}
$('#block-refresh').addEventListener('click', () => loadBlocks().catch((error) => flash(error.message, 'error'))); $('#exception-refresh').addEventListener('click', () => loadBlocks().catch((error) => flash(error.message, 'error')));
$('#block-create').addEventListener('click', async () => { try { await ensureIncidentDependencies(); $('#block-form').reset(); $('#block-starts-at').value = dateTimeLocalValue(new Date()); $('#block-site-id').innerHTML = '<option value="">No aplica</option>'+state.locations.sites.filter((x)=>x.active).map((x)=>`<option value="${x.id}">${escapeHtml(x.code)} · ${escapeHtml(x.name)}</option>`).join(''); $('#block-location-id').innerHTML = '<option value="">No aplica</option>'+state.locations.locations.filter((x)=>x.active).map((x)=>`<option value="${x.id}">${escapeHtml(x.code)} · ${escapeHtml(x.name)}</option>`).join(''); $('#block-category-id').innerHTML = '<option value="">No aplica</option>'+state.categories.filter((x)=>x.active).map((x)=>`<option value="${x.id}">${escapeHtml(x.code)} · ${escapeHtml(x.name)}</option>`).join(''); renderBlockTargetOptions(); $('#block-dialog').showModal(); } catch (error) { flash(error.message, 'error'); } });
$('#block-target-type-edit').addEventListener('change', renderBlockTargetOptions);
$('#block-form').addEventListener('submit', async (event) => { event.preventDefault(); try { await api('/api/v1/blocks', { method: 'POST', body: JSON.stringify({ targetType: $('#block-target-type-edit').value, targetId: $('#block-target-id').value, scopeType: $('#block-scope-type').value, siteId: $('#block-site-id').value || null, locationId: $('#block-location-id').value || null, categoryId: $('#block-category-id').value || null, operationType: $('#block-operation-type').value || null, severity: $('#block-severity').value, startsAt: $('#block-starts-at').value ? new Date($('#block-starts-at').value).toISOString() : null, expiresAt: $('#block-expires-at').value ? new Date($('#block-expires-at').value).toISOString() : null, reason: $('#block-reason').value }) }); $('#block-dialog').close(); flash('Bloqueo operativo aplicado.'); await loadBlocks(); } catch (error) { flash(error.message, 'error'); } });
$('#blocks-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-block-action]'); if (!button) return;
  const block = state.blocks.find((item) => item.id === button.dataset.id); if (!block) return;
  try {
    if (button.dataset.blockAction === 'lift') {
      const values = await askFields('Levantar bloqueo', [{ name: 'reason', label: 'Fundamento', type: 'textarea' }], { confirmText: 'Levantar bloqueo' });
      if (!values) return;
      await api(`/api/v1/blocks/${block.id}/lift`, { method: 'POST', body: JSON.stringify({ version: block.version, reason: values.reason }) });
      flash('Bloqueo levantado.');
      await loadBlocks();
    } else {
      await ensureIncidentDependencies();
      $('#block-exception-form').reset();
      $('#exception-block-id').value = block.id;
      $('#exception-asset').innerHTML = '<option value="">Todos los bienes alcanzados</option>'+state.assets.filter((a)=>a.active).map((a)=>`<option value="${a.id}">${escapeHtml(a.internal_code)} · ${escapeHtml(a.description)}</option>`).join('');
      $('#block-exception-dialog').showModal();
    }
  } catch (error) { flash(error.message, 'error'); }
});
$('#block-exception-form').addEventListener('submit', async (event) => { event.preventDefault(); try { await api(`/api/v1/blocks/${$('#exception-block-id').value}/exceptions`, { method: 'POST', body: JSON.stringify({ operationType: $('#exception-operation').value, assetId: $('#exception-asset').value || null, reason: $('#exception-reason').value }) }); $('#block-exception-dialog').close(); flash('Excepción enviada para decisión segregada.'); await loadBlocks(); } catch (error) { flash(error.message, 'error'); } });
$('#exceptions-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-exception-action]'); if (!button) return;
  const row = state.exceptions.find((item) => item.id === button.dataset.id); if (!row) return;
  const approve = button.dataset.exceptionAction === 'approve';
  const values = await askFields(approve ? 'Aprobar excepción' : 'Rechazar excepción', [{ name: 'reason', label: approve ? 'Fundamento de aprobación' : 'Fundamento de rechazo', type: 'textarea' }], { confirmText: approve ? 'Aprobar' : 'Rechazar', danger: !approve });
  if (!values) return;
  try {
    const body = { version: row.version, reason: values.reason };
    if (approve) { const hours = 8; body.validFrom = new Date().toISOString(); body.validUntil = new Date(Date.now()+hours*3600_000).toISOString(); body.oneTime = true; }
    await api(`/api/v1/block-exceptions/${row.id}/${button.dataset.exceptionAction}`, { method: 'POST', body: JSON.stringify(body) });
    flash('Excepción decidida.'); await loadBlocks();
  } catch (error) { flash(error.message, 'error'); }
});


async function ensureCustodyDependencies() {
  if (!state.locations.locations.length) state.locations = await api('/api/v1/config/locations');
  if (!state.assets.length) state.assets = (await api('/api/v1/assets?limit=1000')).items;
  if (!state.users.length && can('Users.Read')) state.users = (await api('/api/v1/users?limit=1000')).items;
  if (!state.categories.length) state.categories = (await api('/api/v1/asset-categories?limit=1000')).items;
}
