function vehicleMeterNumber(value) { return Number(value || 0).toLocaleString('es-AR', { maximumFractionDigits: 2 }); }
function vehicleUsageLabel(profile) { return profile?.usage_unit === 'HORAS' ? 'Horas' : 'Kilómetros'; }
function vehiclePrimaryValue(profile, asset = {}) { return profile?.usage_unit === 'HORAS' ? Number(profile.current_hourmeter || 0) : Number(profile.current_odometer ?? asset.odometer ?? 0); }
function vehiclePrimarySuffix(profile) { return profile?.usage_unit === 'HORAS' ? 'h' : 'km'; }
function vehicleEquivalentText(profile, asset = {}) {
  const factor = Number(profile?.km_per_hour || 50);
  if (profile?.usage_unit === 'HORAS') return `${vehicleMeterNumber(Number(profile.current_odometer ?? asset.odometer ?? 0))} km equivalentes · 1 h = ${vehicleMeterNumber(factor)} km`;
  return `${vehicleMeterNumber(Number(profile.current_hourmeter || 0))} h equivalentes · 1 h = ${vehicleMeterNumber(factor)} km`;
}
async function loadVehicles() {
  const assets = (await api('/api/v1/vehicles?limit=1000')).items;
  state.vehicles = await Promise.all(assets.map(async (asset) => ({
    ...asset,
    vehicleProfile: (await api(`/api/v1/vehicles/${asset.id}/profile`)).profile
  })));
  $('#vehicles-body').innerHTML = state.vehicles.map((v) => {
    const profile = v.vehicleProfile;
    const moveDisabled = !v.active || String(v.status).toUpperCase() !== 'DISPONIBLE';
    return `<tr><td><strong>${escapeHtml(v.internal_code)}</strong></td><td>${escapeHtml(v.description)}<div class="small">${escapeHtml([v.brand,v.model].filter(Boolean).join(' · '))}</div></td><td>${escapeHtml(v.license_plate || '—')}</td><td>${escapeHtml(v.site_code || '')}/${escapeHtml(v.location_code || '')}<div class="small">${escapeHtml(v.location_name || '')}</div></td><td><strong>${escapeHtml(vehicleUsageLabel(profile))}</strong></td><td>${escapeHtml(`${vehicleMeterNumber(vehiclePrimaryValue(profile, v))} ${vehiclePrimarySuffix(profile)}`)}</td><td>${escapeHtml(vehicleEquivalentText(profile, v))}</td><td><span class="status ${v.status === 'DISPONIBLE' ? 'ok' : 'neutral'}">${escapeHtml(uiCodeLabel(v.status))}</span></td><td class="actions">${can('Vehicles.Manage') ? `<button data-vehicle-action="edit" data-id="${v.id}">Editar</button><button data-vehicle-action="move" data-id="${v.id}" ${moveDisabled ? 'disabled title="Sólo puede moverse un vehículo disponible y sin operación abierta."' : ''}>Mover</button>${can('Assets.Update') ? `<button data-vehicle-action="deactivate" data-id="${v.id}" ${!v.active ? 'disabled' : ''}>Dar de baja</button>` : ''}` : `<button data-vehicle-action="detail" data-id="${v.id}">Detalle</button>`}${can('Vehicles.Operate') && v.active ? `<button data-vehicle-action="operation" data-id="${v.id}">Registrar control</button>` : ''}</td></tr>`;
  }).join('') || '<tr><td colspan="9">No hay vehículos registrados.</td></tr>';
}

async function refreshVehicleCatalogs() {
  const [locationsData, categoriesData] = await Promise.all([
    api('/api/v1/config/locations'),
    api('/api/v1/asset-categories?limit=1000')
  ]);
  state.locations = locationsData;
  state.categories = categoriesData.items || [];
  return { locationsData, categoriesData };
}

function vehicleLocationLabel(location) {
  const site = state.locations.sites.find((item) => item.id === location.site_id);
  return `${site?.name || site?.code || 'Sede'} · ${uiCodeLabel(location.type || 'OTRO')} · ${location.name}`;
}

function vehicleCategoriesForLocation(locationId, currentCategoryId = null) {
  const location = state.locations.locations.find((item) => item.id === locationId);
  const enabled = enabledCategoryIdsForSite(location?.site_id || null);
  return state.categories.filter((category) => category.nature === 'VEHICULO' && (category.id === currentCategoryId || (category.active && enabled.has(category.id))));
}

async function openVehicleEdit(vehicleId) {
  await refreshVehicleCatalogs();
  const [assetData, profileData] = await Promise.all([
    api(`/api/v1/assets/${vehicleId}`),
    api(`/api/v1/vehicles/${vehicleId}/profile`)
  ]);
  const vehicle = assetData.asset;
  const profile = profileData.profile;
  const categories = vehicleCategoriesForLocation(vehicle.location_id, vehicle.category_id);
  const values = await askFields(`Editar vehículo · ${vehicle.internal_code}`, [
    { name: 'categoryId', label: 'Categoría vehicular', type: 'select', value: vehicle.category_id, options: categories.map((category) => ({ value: category.id, label: `${category.code} · ${category.name}` })) },
    { name: 'internalCode', label: 'Código interno', value: vehicle.internal_code },
    { name: 'description', label: 'Descripción', value: vehicle.description },
    { name: 'licensePlate', label: 'Patente', value: vehicle.license_plate || '' },
    { name: 'brand', label: 'Marca', value: vehicle.brand || '', required: false },
    { name: 'model', label: 'Modelo', value: vehicle.model || '', required: false },
    { name: 'serialNumber', label: 'Serie / identificador adicional', value: vehicle.serial_number || '', required: false },
    { name: 'vin', label: 'VIN', value: profile.vin || '', required: false },
    { name: 'chassisNumber', label: 'Número de chasis', value: profile.chassis_number || '', required: false },
    { name: 'engineNumber', label: 'Número de motor', value: profile.engine_number || '', required: false },
    { name: 'manufactureYear', label: 'Año', type: 'number', value: profile.manufacture_year ?? '', required: false },
    { name: 'vehicleClass', label: 'Clase de vehículo', value: profile.vehicle_class || '', required: false },
    { name: 'usageUnit', label: 'Unidad operativa principal', type: 'select', value: profile.usage_unit || 'KILOMETROS', options: [{ value: 'KILOMETROS', label: 'Kilómetros' }, { value: 'HORAS', label: 'Horas de funcionamiento' }] },
    { name: 'currentOdometer', label: 'Odómetro actual (km)', type: 'number', value: profile.current_odometer ?? vehicle.odometer ?? 0 },
    { name: 'currentHourmeter', label: 'Horómetro actual (h)', type: 'number', value: profile.current_hourmeter ?? 0 },
    { name: 'kmPerHour', label: 'Equivalencia: km por hora', type: 'number', value: profile.km_per_hour || 50 },
    { name: 'fuelType', label: 'Combustible', value: profile.fuel_type || vehicle.fuel_type || '', required: false },
    { name: 'fuelCapacity', label: 'Capacidad de combustible', type: 'number', value: profile.fuel_capacity ?? '', required: false },
    { name: 'requiredLicenseClass', label: 'Clase de licencia requerida', value: profile.required_license_class || '', required: false },
    { name: 'notes', label: 'Observaciones', type: 'textarea', value: vehicle.notes || '', required: false }
  ], { confirmText: 'Guardar vehículo', message: `Ubicación actual: ${vehicle.site_name || vehicle.site_code} · ${vehicle.location_name}. Para cambiarla usá Mover.` });
  if (!values) return;
  await api(`/api/v1/vehicles/${vehicle.id}`, { method: 'PATCH', body: JSON.stringify({
    ...values,
    assetVersion: vehicle.version,
    profileVersion: profile.version,
    manufactureYear: values.manufactureYear === '' ? null : Number(values.manufactureYear),
    currentOdometer: Number(values.currentOdometer),
    currentHourmeter: Number(values.currentHourmeter),
    kmPerHour: Number(values.kmPerHour),
    fuelCapacity: values.fuelCapacity === '' ? null : Number(values.fuelCapacity)
  }) });
  flash('Vehículo actualizado.');
  state.assets = [];
  await loadVehicles();
}

async function moveVehicle(vehicleId) {
  await refreshVehicleCatalogs();
  const asset = (await api(`/api/v1/assets/${vehicleId}`)).asset;
  const activeSiteIds = new Set(state.locations.sites.filter((site) => site.active).map((site) => site.id));
  const sourceSiteId = asset.site_id || state.locations.locations.find((location) => location.id === asset.location_id)?.site_id;
  const destinations = state.locations.locations.filter((location) => location.active && activeSiteIds.has(location.site_id) && location.id !== asset.location_id && (location.site_id === sourceSiteId || enabledCategoryIdsForSite(location.site_id).has(asset.category_id)));
  if (!destinations.length) throw new Error('No existe otra ubicación activa compatible con la categoría de este vehículo.');
  const values = await askFields(`Mover vehículo · ${asset.internal_code}`, [
    { name: 'destinationLocationId', label: 'Nueva ubicación', type: 'select', options: destinations.map((location) => ({ value: location.id, label: vehicleLocationLabel(location) })) },
    { name: 'reason', label: 'Motivo / referencia', required: false }
  ], { confirmText: 'Mover vehículo', message: `Origen: ${asset.site_name || asset.site_code} · ${asset.location_name}. El movimiento quedará registrado en el histórico.` });
  if (!values) return;
  const result = await api(`/api/v1/vehicles/${asset.id}/move`, { method: 'POST', body: JSON.stringify({ assetVersion: asset.version, destinationLocationId: values.destinationLocationId, reason: values.reason || 'Transferencia individual de vehículo' }) });
  flash(`Vehículo trasladado a ${result.destination?.name || 'la nueva ubicación'}.`);
  state.assets = [];
  await loadVehicles();
}
function activeCategoriesByNature(nature, siteId = null) {
  const enabled = siteId ? enabledCategoryIdsForSite(siteId) : null;
  return state.categories.filter((category) => category.active && category.nature === nature && (!enabled || enabled.has(category.id)));
}

$('#vehicle-create').addEventListener('click', async () => {
  try {
    await refreshVehicleCatalogs();
    const locations = activeLocations();
    if (!locations.length) throw new Error('No existe una ubicación activa para registrar el vehículo.');
    const destination = await askFields('Nuevo vehículo · ubicación', [
      { name: 'locationId', label: 'Sede / ubicación', type: 'select', options: locations.map((location) => {
        const site = state.locations.sites.find((item) => item.id === location.site_id);
        return { value: location.id, label: `${site?.name || site?.code || 'Sede'} · ${location.code} · ${location.name}` };
      }) }
    ], { confirmText: 'Continuar', message: 'Primero elegí dónde quedará registrado. Después pediremos sólo los datos indispensables.' });
    if (!destination) return;
    const location = locations.find((item) => item.id === destination.locationId);
    const vehicleCategories = activeCategoriesByNature('VEHICULO', location?.site_id || null);
    if (!vehicleCategories.length) throw new Error('La sede seleccionada no tiene habilitada ninguna categoría de Vehículos. Habilítela desde Configuración → Sedes.');
    const values = await askFields('Nuevo vehículo · datos básicos', [
      { name: 'categoryId', label: 'Categoría vehicular', type: 'select', options: vehicleCategories.map((category) => ({ value: category.id, label: `${category.code} · ${category.name}` })) },
      { name: 'internalCode', label: 'Código interno' },
      { name: 'description', label: 'Descripción' },
      { name: 'licensePlate', label: 'Patente / identificación', required: false },
      { name: 'usageUnit', label: 'Medición operativa principal', type: 'select', value: 'KILOMETROS', options: [{ value: 'KILOMETROS', label: 'Kilómetros' }, { value: 'HORAS', label: 'Horas de funcionamiento' }] },
      { name: 'initialMeter', label: 'Lectura inicial', type: 'number', value: 0, min: 0, step: 0.1 }
    ], { confirmText: 'Crear vehículo', message: 'VIN, chasis, motor, marca, modelo, combustible y demás datos técnicos se pueden completar después desde Editar. No son necesarios para dar de alta el vehículo.' });
    if (!values) return;
    const usageUnit = values.usageUnit || 'KILOMETROS';
    const reading = Number(values.initialMeter || 0);
    await api('/api/v1/vehicles', { method: 'POST', body: JSON.stringify({
      categoryId: values.categoryId,
      internalCode: values.internalCode,
      description: values.description,
      licensePlate: values.licensePlate || null,
      locationId: destination.locationId,
      usageUnit,
      currentOdometer: usageUnit === 'KILOMETROS' ? reading : undefined,
      currentHourmeter: usageUnit === 'HORAS' ? reading : undefined,
      kmPerHour: 50,
      status: 'DISPONIBLE',
      active: true
    }) });
    flash('Vehículo creado. Los datos técnicos opcionales se completan desde Editar cuando corresponda.');
    state.assets = [];
    await loadVehicles();
  } catch (e) { flash(e.message, 'error'); }
});


function kitComponentStatusClass(status) {
  return status === 'DISPONIBLE' ? 'ok' : status === 'BAJA' ? 'danger' : 'neutral';
}

function renderKitComponentCandidates() {
  const editor = state.kitCompositionEditor;
  if (!editor) return;
  const visible = editor.candidates || [];
  $('#kit-component-candidates').innerHTML = visible.length ? visible.map((asset, index) => {
    const current = editor.selection.get(asset.id);
    const selected = Boolean(current);
    const serialized = ['SERIADO','KIT','VEHICULO'].includes(asset.category_nature);
    const quantity = current?.requiredQuantity ?? 1;
    const mandatory = current ? Boolean(current.mandatory) : true;
    const substitution = current ? Boolean(current.allowSubstitution) : false;
    const sequence = current?.sequence ?? index + 1;
    return `<tr data-kit-component-row data-id="${asset.id}" data-selected="${selected}">
      <td><input class="kit-component-use" type="checkbox" ${selected ? 'checked' : ''} aria-label="Usar ${escapeHtml(asset.internal_code)}"></td>
      <td><strong>${escapeHtml(asset.internal_code)}</strong><div class="small">${escapeHtml(asset.description)}</div></td>
      <td>${escapeHtml(asset.category_code)}<div class="small">${escapeHtml(uiCodeLabel(asset.category_nature))}</div></td>
      <td><span class="status ${kitComponentStatusClass(asset.status)}">${escapeHtml(uiCodeLabel(asset.status))}</span></td>
      <td><input class="kit-component-quantity" type="number" min="${serialized ? '1' : '0.000001'}" ${serialized ? 'max="1" step="1"' : 'step="any"'} value="${escapeHtml(quantity)}" ${selected ? '' : 'disabled'}></td>
      <td class="kit-advanced-col"><input class="kit-component-mandatory" type="checkbox" ${mandatory ? 'checked' : ''} ${selected ? '' : 'disabled'}></td>
      <td class="kit-advanced-col"><input class="kit-component-substitution" type="checkbox" ${substitution ? 'checked' : ''} ${selected ? '' : 'disabled'}></td>
      <td class="kit-advanced-col"><input class="kit-component-sequence" type="number" min="1" step="1" value="${escapeHtml(sequence)}" ${selected ? '' : 'disabled'}></td>
    </tr>`;
  }).join('') : '<tr><td colspan="8" class="small">Sin componentes que coincidan con la búsqueda.</td></tr>';
  updateKitSelectionSummary();
}

let kitComponentSearchTimer = null;

async function refreshKitComponentCandidates() {
  const editor = state.kitCompositionEditor;
  if (!editor) return;
  const params = new URLSearchParams({ limit: '300' });
  const search = $('#kit-component-search').value.trim();
  if (search) params.set('search', search);
  const includeIds = [...editor.selection.keys()];
  if (includeIds.length) params.set('includeIds', includeIds.join(','));
  const result = await api(`/api/v1/kits/component-candidates?${params}`);
  if (state.kitCompositionEditor !== editor) return;
  editor.candidates = result.items || [];
  renderKitComponentCandidates();
}

function showKitDialogError(message) {
  const errorNode = $('#kit-create-error');
  if (!errorNode) return;
  errorNode.textContent = message || 'No se pudo guardar la composición del kit.';
  errorNode.classList.remove('hidden');
  errorNode.setAttribute('tabindex', '-1');
  errorNode.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  errorNode.focus({ preventScroll: true });
}

function clearKitDialogError() {
  const errorNode = $('#kit-create-error');
  if (!errorNode) return;
  errorNode.textContent = '';
  errorNode.classList.add('hidden');
  errorNode.removeAttribute('tabindex');
}

function updateKitSelectionSummary() {
  const count = state.kitCompositionEditor?.selection?.size || 0;
  $('#kit-component-selection-summary').textContent = `${count} ${count === 1 ? 'componente seleccionado' : 'componentes seleccionados'}.`;
}

function refreshKitCategoriesForLocation() {
  const location = state.locations.locations.find((item) => item.id === $('#kit-create-location').value);
  const kitCategories = activeCategoriesByNature('KIT', location?.site_id || null);
  $('#kit-create-category').innerHTML = kitCategories.map((category) => `<option value="${category.id}">${escapeHtml(category.code)} · ${escapeHtml(category.name)}</option>`).join('');
  if (!kitCategories.length) $('#kit-create-category').innerHTML = '<option value="">Sin categoría KIT habilitada en esta sede</option>';
}

async function openKitCompositionEditor(kitId = null) {
  await ensureCustodyDependencies();
  const current = kitId ? await api(`/api/v1/kits/${kitId}`) : null;
  if (!current) {
    const mechanicsData = await api('/api/v1/kits/mechanics');
    state.kitMechanics = mechanicsData.items || [];
    if (!state.kitMechanics.length) throw new Error('No existe ningún usuario técnico activo con rol Solicitante para asignar el kit.');
  }
  const selection = new Map((current?.components || []).map((component) => [component.component_asset_id, {
    componentAssetId: component.component_asset_id,
    requiredQuantity: Number(component.required_quantity),
    mandatory: Boolean(component.mandatory),
    allowSubstitution: Boolean(component.allow_substitution),
    sequence: Number(component.sequence)
  }]));
  state.kitCompositionEditor = { current, candidates: [], selection };
  $('#kit-create-form').reset();
  $('#kit-create-dialog-title').textContent = current ? `Composición · ${current.asset.internal_code}` : 'Nuevo kit';
  $('#kit-master-fields').classList.toggle('hidden', Boolean(current));
  $$('#kit-master-fields input, #kit-master-fields select').forEach((field) => { field.required = false; });
  ['kit-create-category','kit-create-code','kit-create-description','kit-create-location','kit-create-person'].forEach((id) => { $(`#${id}`).required = !current; });
  $('#kit-create-submit').textContent = current ? 'Guardar composición' : 'Crear kit';
  $('#kit-create-allow-incomplete').checked = Boolean(current?.definition.allow_incomplete_with_authorization);
  $('#kit-create-notes').value = current?.definition.notes || '';
  $('#kit-component-search').value = '';
  clearKitDialogError();
  if (!current) {
    const locations = activeLocations();
    if (!locations.length) throw new Error('No existe una ubicación activa para registrar el kit.');
    $('#kit-create-location').innerHTML = locations.map((location) => {
      const site = state.locations.sites.find((item) => item.id === location.site_id);
      return `<option value="${location.id}">${escapeHtml(site?.name || site?.code || 'Sede')} · ${escapeHtml(location.code)} · ${escapeHtml(location.name)}</option>`;
    }).join('');
    $('#kit-create-person').innerHTML = state.kitMechanics.map((person) => `<option value="${person.personId}">${escapeHtml(person.fullName)} · ${escapeHtml(person.username)}${person.sector ? ` · ${escapeHtml(person.sector)}` : ''}</option>`).join('');
    refreshKitCategoriesForLocation();
  }
  await refreshKitComponentCandidates();
  const componentAdvanced = Boolean(current?.components?.some((component, index) => !component.mandatory || component.allow_substitution || Number(component.sequence) !== index + 1));
  $('#kit-composition-card')?.classList.toggle('show-advanced', componentAdvanced);
  const advancedToggle = $('#kit-components-advanced-toggle'); if (advancedToggle) advancedToggle.textContent = componentAdvanced ? 'Ocultar configuración avanzada' : 'Configuración avanzada';
  const advancedOptions = $('#kit-advanced-options'); if (advancedOptions) advancedOptions.open = Boolean(current && (current.definition.allow_incomplete_with_authorization || current.definition.notes));
  $('#kit-create-dialog').showModal();
}

$('#kit-create').addEventListener('click', () => openKitCompositionEditor().catch((e) => flash(e.message, 'error')));
$('#kit-create-location').addEventListener('change', refreshKitCategoriesForLocation);
$('#kit-components-advanced-toggle')?.addEventListener('click', () => {
  const card = $('#kit-composition-card'); if (!card) return;
  const opening = !card.classList.contains('show-advanced'); card.classList.toggle('show-advanced', opening);
  $('#kit-components-advanced-toggle').textContent = opening ? 'Ocultar configuración avanzada' : 'Configuración avanzada';
});
$('#kit-component-search').addEventListener('input', () => {
  clearTimeout(kitComponentSearchTimer);
  kitComponentSearchTimer = setTimeout(() => {
    refreshKitComponentCandidates().catch((e) => showKitDialogError(e.message));
  }, 180);
});
$('#kit-component-candidates').addEventListener('change', (event) => {
  const row = event.target.closest('[data-kit-component-row]');
  const editor = state.kitCompositionEditor;
  if (!row || !editor) return;
  const use = row.querySelector('.kit-component-use');
  if (event.target.classList.contains('kit-component-use')) {
    row.dataset.selected = String(use.checked);
    row.querySelectorAll('input:not(.kit-component-use)').forEach((input) => { input.disabled = !use.checked; });
    if (!use.checked) editor.selection.delete(row.dataset.id);
  }
  if (use.checked) {
    editor.selection.set(row.dataset.id, {
      componentAssetId: row.dataset.id,
      requiredQuantity: Number(row.querySelector('.kit-component-quantity').value),
      mandatory: row.querySelector('.kit-component-mandatory').checked,
      allowSubstitution: row.querySelector('.kit-component-substitution').checked,
      sequence: Number(row.querySelector('.kit-component-sequence').value)
    });
  }
  clearKitDialogError();
  updateKitSelectionSummary();
});

$('#kit-create-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const editor = state.kitCompositionEditor;
    if (!editor) return;
    clearKitDialogError();
    const components = [...editor.selection.values()];
    if (!components.length) {
      showKitDialogError('Un kit debe tener al menos un componente. Seleccione uno antes de guardar.');
      return;
    }
    const common = {
      allowIncompleteWithAuthorization: $('#kit-create-allow-incomplete').checked,
      definitionNotes: $('#kit-create-notes').value,
      components
    };
    if (editor.current) {
      await api(`/api/v1/kits/${editor.current.asset.id}`, { method: 'PUT', body: JSON.stringify({
        ...common,
        notes: common.definitionNotes,
        version: editor.current.definition.version
      }) });
      flash('Composición de kit actualizada.');
    } else {
      if (!$('#kit-create-category').value) throw new Error('La sede seleccionada no tiene habilitada una categoría KIT.');
      await api('/api/v1/kits', { method: 'POST', body: JSON.stringify({
        ...common,
        categoryId: $('#kit-create-category').value,
        internalCode: $('#kit-create-code').value,
        serialNumber: $('#kit-create-serial').value,
        description: $('#kit-create-description').value,
        locationId: $('#kit-create-location').value,
        assignedPersonId: $('#kit-create-person').value,
        assignmentNotes: $('#kit-create-notes').value,
        status: 'DISPONIBLE',
        active: true
      }) });
      flash('Kit, definición y componentes creados en una sola operación.');
    }
    $('#kit-create-dialog').close();
    state.kitCompositionEditor = null;
    state.assets = [];
    await loadKits();
  } catch (e) {
    showKitDialogError(e.message || 'No se pudo guardar la composición del kit.');
    flash(e.message, 'error');
  }
});

$('#vehicles-refresh').addEventListener('click', () => loadVehicles().catch((e) => flash(e.message, 'error')));
$('#vehicle-authorization-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const values = await askFields('Nueva habilitación vehicular', [
      { name: 'personId', label: 'Persona habilitada', type: 'select', options: state.users.filter((user) => user.active).map((user) => ({ value: user.personId, label: `${user.person.fullName}${userDocumentDisplay(user) ? ` · ${userDocumentDisplay(user)}` : ''}` })) },
      { name: 'vehicleAssetId', label: 'Vehículo específico (opcional)', type: 'select', required: false, options: [{ value: '', label: 'Aplicar por categoría' }, ...state.vehicles.map((vehicle) => ({ value: vehicle.id, label: `${vehicle.internal_code} · ${vehicle.description}` }))] },
      { name: 'categoryId', label: 'Categoría vehicular (si no se eligió vehículo)', type: 'select', required: false, options: [{ value: '', label: 'Seleccionar categoría' }, ...state.categories.filter((category) => category.nature === 'VEHICULO').map((category) => ({ value: category.id, label: `${category.code} · ${category.name}` }))] },
      { name: 'licenseNumber', label: 'Número de licencia' },
      { name: 'licenseClass', label: 'Clase de licencia' }
    ], { confirmText: 'Registrar habilitación' });
    if (!values || (!values.vehicleAssetId && !values.categoryId)) return;
    const authorizationStart = new Date();
    authorizationStart.setSeconds(0, 0);
    await api('/api/v1/vehicle-authorizations', { method: 'POST', body: JSON.stringify({ personId: values.personId, vehicleAssetId: values.vehicleAssetId || null, categoryId: values.vehicleAssetId ? null : values.categoryId, licenseNumber: values.licenseNumber, licenseClass: values.licenseClass, validFrom: authorizationStart.toISOString(), validUntil: new Date(authorizationStart.getTime()+365*86400000).toISOString(), notes: 'Habilitación creada desde interfaz administrativa.' }) });
    flash('Habilitación registrada.');
  } catch (e) { flash(e.message, 'error'); }
});
$('#vehicles-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-vehicle-action]'); if (!button) return;
  try {
    const vehicle = state.vehicles.find((x) => x.id === button.dataset.id); if (!vehicle) return;
    if (button.dataset.vehicleAction === 'edit') return openVehicleEdit(vehicle.id);
    if (button.dataset.vehicleAction === 'move') return moveVehicle(vehicle.id);
    if (button.dataset.vehicleAction === 'deactivate') {
      if (!await askConfirm(`Dar de baja lógicamente el vehículo ${vehicle.internal_code}? Se conservarán su perfil, movimientos, custodias e histórico.`, { title: 'Dar de baja vehículo', confirmText: 'Dar de baja', danger: true })) return;
      await api(`/api/v1/assets/${vehicle.id}/inactivate`, { method: 'POST', body: JSON.stringify({ version: vehicle.version }) });
      flash('Vehículo dado de baja lógicamente.');
      await loadVehicles();
      return;
    }
    if (button.dataset.vehicleAction === 'detail') {
      const current = (await api(`/api/v1/vehicles/${vehicle.id}/profile`)).profile;
      return showDetails(`Vehículo ${vehicle.internal_code}`, { asset: vehicle, profile: current });
    }
    if (button.dataset.vehicleAction === 'operation') {
      await ensureCustodyDependencies();
      const profile = vehicle.vehicleProfile || (await api(`/api/v1/vehicles/${vehicle.id}/profile`)).profile;
      const isHours = profile.usage_unit === 'HORAS';
      const values = await askFields(`Registrar control · ${vehicle.internal_code}`, [
        { name: 'driverPersonId', label: 'Persona conductora', type: 'select', options: state.users.filter((user) => user.active).map((user) => ({ value: user.personId, label: `${user.person.fullName}${userDocumentDisplay(user) ? ` · ${userDocumentDisplay(user)}` : ''}` })) },
        { name: 'meterValue', label: isHours ? 'Horómetro actual (h)' : 'Kilometraje actual (km)', type: 'number', value: vehiclePrimaryValue(profile, vehicle) },
        { name: 'fuelLevelPercent', label: 'Combustible (%)', type: 'number', value: 100 }
      ], { confirmText: 'Registrar control', message: `Unidad principal: ${vehicleUsageLabel(profile)}. La equivalencia se calculará automáticamente con 1 h = ${vehicleMeterNumber(profile.km_per_hour || 50)} km.` });
      if (!values) return;
      const body = { driverPersonId: values.driverPersonId, operationType: 'CONTROL', usageUnit: profile.usage_unit || 'KILOMETROS', kmPerHour: Number(profile.km_per_hour || 50), fuelLevelPercent: Number(values.fuelLevelPercent), condition: 'CONFORME', checklist: { controlVisual: true }, notes: 'Control registrado desde interfaz.' };
      if (isHours) body.hourmeter = Number(values.meterValue); else body.odometer = Number(values.meterValue);
      await api(`/api/v1/vehicles/${vehicle.id}/operations`, { method: 'POST', body: JSON.stringify(body) });
      flash('Control vehicular registrado.'); await loadVehicles();
    }
  } catch (e) { flash(e.message, 'error'); }
});

async function loadKits() {
  const kits = (await api('/api/v1/assets?nature=KIT&limit=1000')).items;
  state.kits = await Promise.all(kits.map(async (asset) => ({ asset, ...(await api(`/api/v1/kits/${asset.id}/availability`)) })));
  $('#kits-body').innerHTML = state.kits.map((k) => {
    const availability = !k.configured
      ? '<span class="status danger">Sin composición</span>'
      : k.complete
        ? '<span class="status ok">Completo</span>'
        : `<span class="status danger">${k.missing.length} faltante(s)</span>`;
    const mechanic = k.assignment
      ? `<strong>${escapeHtml(k.assignment.full_name)}</strong>${k.assignment.employee_number ? `<div class="small">Legajo ${escapeHtml(k.assignment.employee_number)}</div>` : ''}`
      : '<span class="status warning">Sin asignar</span>';
    const manageActions = can('Kits.Manage')
      ? `<button data-kit-action="compose" data-id="${k.asset.id}">Composición</button><button data-kit-action="assign" data-id="${k.asset.id}">${k.assignment ? 'Reasignar' : 'Asignar'}</button>${k.assignment ? `<button data-kit-action="unassign" data-id="${k.asset.id}">Quitar asignación</button>` : ''}`
      : '';
    const inventoryAction = can('Kits.Manage') ? `<button data-kit-action="inventory" data-id="${k.asset.id}">Inventario / imprimir</button>` : '';
    return `<tr><td><strong>${escapeHtml(k.asset.internal_code)}</strong></td><td>${escapeHtml(k.asset.description)}</td><td>${mechanic}</td><td>${k.components.length}</td><td>${availability}</td><td>${escapeHtml(uiCodeLabel(k.asset.status))}</td><td class="actions"><button data-kit-action="detail" data-id="${k.asset.id}">Detalle</button>${inventoryAction}${manageActions}</td></tr>`;
  }).join('');
}
$('#kits-refresh').addEventListener('click', () => loadKits().catch((e) => flash(e.message, 'error')));
$('#kit-import-excel').addEventListener('click', () => {
  setView('imports');
  $('#import-kind').value = 'KIT';
  updateImportKindHelp();
  $('#import-file').focus();
  flash('Importación de Kits lista. Seleccione el archivo de la plantilla "Kits con componentes".');
});
$('#kits-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-kit-action]');
  if (!button) return;
  const kit = state.kits.find((item) => item.asset.id === button.dataset.id);
  try {
    if (button.dataset.kitAction === 'detail') {
      const current = await api(`/api/v1/kits/${button.dataset.id}`);
      const assignment = await api(`/api/v1/kits/${button.dataset.id}/assignment`);
      return showDetails('Detalle del kit', { ...current, assignmentHistory: assignment.history });
    }
    if (button.dataset.kitAction === 'compose') return openKitCompositionEditor(button.dataset.id);
    if (button.dataset.kitAction === 'assign') {
      const mechanics = (await api('/api/v1/kits/mechanics')).items || [];
      if (!mechanics.length) throw new Error('No existen usuarios técnicos activos con rol Solicitante para asignación.');
      const values = await askFields(kit?.assignment ? 'Reasignar kit a mecánico' : 'Asignar kit a mecánico', [
        { name: 'personId', label: 'Mecánico', type: 'select', value: kit?.assignment?.person_id || '', options: mechanics.map((person) => ({ value: person.personId, label: `${person.fullName} · ${person.username}${person.sector ? ` · ${person.sector}` : ''}` })) },
        { name: 'notes', label: 'Observaciones de asignación', type: 'textarea', required: false },
        { name: 'reason', label: 'Motivo', type: 'textarea', value: kit?.assignment ? 'Reasignación nominal del kit' : 'Asignación nominal del kit' }
      ], { confirmText: kit?.assignment ? 'Reasignar' : 'Asignar' });
      if (!values) return;
      await api(`/api/v1/kits/${button.dataset.id}/assign`, { method: 'POST', body: JSON.stringify({ personId: values.personId, notes: values.notes || null, reason: values.reason, reassign: Boolean(kit?.assignment && kit.assignment.person_id !== values.personId) }) });
      flash('Asignación del kit actualizada.');
      return loadKits();
    }
    if (button.dataset.kitAction === 'unassign') {
      const values = await askFields('Quitar asignación del kit', [
        { name: 'reason', label: 'Motivo', type: 'textarea', value: 'Kit retirado de la asignación personal' }
      ], { confirmText: 'Quitar asignación' });
      if (!values) return;
      await api(`/api/v1/kits/${button.dataset.id}/unassign`, { method: 'POST', body: JSON.stringify({ reason: values.reason }) });
      flash('Asignación cerrada. El histórico se conserva.');
      return loadKits();
    }
    if (button.dataset.kitAction === 'inventory') {
      const values = await askFields('Control imprimible del kit', [
        { name: 'notes', label: 'Observaciones para esta hoja', type: 'textarea', required: false }
      ], { confirmText: 'Generar control' });
      if (!values) return;
      const printWindow = window.open('about:blank', '_blank');
      const result = await api(`/api/v1/kits/${button.dataset.id}/inventory-control`, { method: 'POST', body: JSON.stringify({ notes: values.notes || null }) });
      if (!printWindow) throw new Error('El navegador bloqueó la ventana imprimible. Habilite ventanas emergentes para INGAR Warehouse.');
      printWindow.document.open();
      printWindow.document.write(result.printHtml);
      printWindow.document.close();
      flash(`Control ${result.control.control_number} generado y trazado.`);
    }
  } catch (e) { flash(e.message, 'error'); }
});

function operationalLocationLabel(location) {
  const site = (state.locations.sites || []).find((item) => item.id === location.site_id);
  const type = typeof locationTypeLabel === 'function' ? locationTypeLabel(location.type) : uiCodeLabel(location.type || 'UBICACION');
  return `${location.name} · ${type}${site ? ` · ${site.name}` : ''}`;
}

async function loadStock() {
  await ensureCustodyDependencies();
  const selectedLocation = $('#stock-location-filter').value;
  $('#stock-location-filter').innerHTML = '<option value="">Todas las ubicaciones</option>'+state.locations.locations.filter((x)=>x.active).map((x)=>`<option value="${x.id}">${escapeHtml(operationalLocationLabel(x))}</option>`).join('');
  if (state.locations.locations.some((x) => x.id === selectedLocation)) $('#stock-location-filter').value = selectedLocation;
  const filter = state.dashboardViewFilters.stock || {};
  const lotParams = new URLSearchParams({ limit: '1000' });
  if ($('#stock-location-filter').value) lotParams.set('locationId', $('#stock-location-filter').value);
  if ($('#stock-unavailable-filter').checked || filter.unavailable) lotParams.set('unavailable', 'true');
  const movementParams = new URLSearchParams({ limit: '1000' });
  if ($('#stock-movement-type').value) movementParams.set('movementType', $('#stock-movement-type').value);
  const from = filter.movementFrom || ($('#stock-movement-from').value ? new Date($('#stock-movement-from').value).toISOString() : '');
  const to = filter.movementTo || ($('#stock-movement-to').value ? new Date($('#stock-movement-to').value).toISOString() : '');
  if (from) movementParams.set('movementFrom', from);
  if (to) movementParams.set('movementTo', to);
  const [lots, movements] = await Promise.all([api(`/api/v1/stock?${lotParams}`), api(`/api/v1/stock/movements?${movementParams}`)]);
  state.stockLots = lots.items; state.stockMovements = movements.items;
  $('#stock-lots-panel').classList.toggle('hidden', filter.mode === 'movements');
  $('#stock-movements-panel').classList.toggle('hidden', filter.mode === 'lots');
  $('#stock-body').innerHTML = lots.items.map((x) => `<tr><td><strong>${escapeHtml(x.internal_code)}</strong><br><span class="small">${escapeHtml(x.description)}</span></td><td>${escapeHtml(x.lot_code)}</td><td>${escapeHtml(x.location_code)}</td><td>${x.quantity_on_hand}</td><td>${x.quantity_reserved}</td><td>${x.quantity_available}</td><td>${escapeHtml(x.expires_at ? formatDateTime(x.expires_at) : '—')}</td><td>${can('Stock.Operate') ? `<button data-stock-move="${x.id}">Movimiento</button>` : ''}</td></tr>`).join('');
  $('#stock-movements-count').textContent = `${movements.items.length} ${movements.items.length === 1 ? 'movimiento' : 'movimientos'}`;
  $('#stock-movements-body').innerHTML = movements.items.map((x) => `<tr><td>${escapeHtml(formatDateTime(x.occurred_at))}</td><td><strong>${escapeHtml(x.movement_number)}</strong></td><td>${escapeHtml(x.internal_code)}<div class="small">${escapeHtml(x.description)}</div></td><td>${escapeHtml(x.lot_code)}</td><td>${escapeHtml(x.location_code)}</td><td><span class="status neutral">${escapeHtml(uiCodeLabel(x.movement_type))}</span></td><td>${Number(x.quantity).toLocaleString('es-AR')}</td><td>${Number(x.quantity_after).toLocaleString('es-AR')}</td><td>${escapeHtml(x.actor_username)}</td><td>${escapeHtml(x.reason)}</td></tr>`).join('');
}
$('#stock-refresh').addEventListener('click', () => { clearDashboardFilter('stock'); loadStock().catch((e) => flash(e.message, 'error')); });
$('#stock-location-filter').addEventListener('change', () => { clearDashboardFilter('stock'); loadStock().catch((e) => flash(e.message, 'error')); });
$('#stock-movements-refresh').addEventListener('click', () => { clearDashboardFilter('stock'); loadStock().catch((e) => flash(e.message, 'error')); });
$('#stock-unavailable-filter').addEventListener('change', () => { clearDashboardFilter('stock'); loadStock().catch((e) => flash(e.message, 'error')); });
$('#stock-lot-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const stockAssets = state.assets.filter((asset) => ['CANTIDAD','CONSUMIBLE'].includes(asset.category_nature));
    const values = await askFields('Nuevo lote de stock', [
      { name: 'assetId', label: 'Bien o consumible', type: 'select', options: stockAssets.map((asset) => ({ value: asset.id, label: `${asset.internal_code} · ${asset.description}` })) },
      { name: 'locationId', label: 'Ubicación', type: 'select', options: state.locations.locations.filter((location) => location.active).map((location) => ({ value: location.id, label: operationalLocationLabel(location) })) },
      { name: 'lotCode', label: 'Código de lote', value: 'GENERAL' },
      { name: 'quantityOnHand', label: 'Cantidad física', type: 'number', value: 0 }
    ], { confirmText: 'Crear lote' });
    if (!values) return;
    await api('/api/v1/stock/lots', { method: 'POST', body: JSON.stringify({ assetId: values.assetId, locationId: values.locationId, lotCode: values.lotCode, quantityOnHand: Number(values.quantityOnHand) }) });
    flash('Lote creado.'); await loadStock();
  } catch (e) { flash(e.message, 'error'); }
});
$('#stock-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-stock-move]'); if (!button) return;
  try {
    const values = await askFields('Registrar movimiento de stock', [
      { name: 'movementType', label: 'Tipo de movimiento', type: 'select', value: 'SALIDA', options: ['ENTRADA','SALIDA','CONSUMO','DEVOLUCION','RESERVA','LIBERACION'] },
      { name: 'quantity', label: 'Cantidad', type: 'number', value: 1 },
      { name: 'reason', label: 'Fundamento', type: 'textarea' }
    ], { confirmText: 'Registrar movimiento' });
    if (!values) return;
    await api('/api/v1/stock/movements', { method: 'POST', body: JSON.stringify({ clientMovementId: crypto.randomUUID(), lotId: button.dataset.stockMove, movementType: values.movementType, quantity: Number(values.quantity), reason: values.reason }) });
    flash('Movimiento registrado.'); await loadStock();
  } catch (e) { flash(e.message, 'error'); }
});

async function loadInventoryCounts() {
  const status=$('#inventory-status-filter').value;
  state.inventoryCounts=(await api(`/api/v1/inventory-counts${status?`?status=${encodeURIComponent(status)}`:''}`)).items;
  $('#inventory-body').innerHTML=state.inventoryCounts.map((x)=>`<tr><td><strong>${escapeHtml(x.count_number)}</strong></td><td>${escapeHtml(uiCodeLabel(x.count_type))}</td><td>${escapeHtml(x.location_name ? `${x.location_code || ''} · ${x.location_name}` : x.site_name || 'Alcance general')}</td><td>${escapeHtml(formatDateTime(x.planned_at))}</td><td><span class="status ${x.status==='CERRADO'?'ok':'neutral'}">${escapeHtml(uiCodeLabel(x.status))}</span></td><td>${x.version}</td><td class="actions"><button data-count-action="detail" data-id="${x.id}">Abrir detalle</button>${can('Inventory.Execute')&&x.status==='PLANIFICADO'?`<button data-count-action="open" data-id="${x.id}">Iniciar conteo</button>`:''}${can('Inventory.Close')&&['CONTEO','CONCILIACION'].includes(x.status)?`<button data-count-action="close" data-id="${x.id}">Cerrar inventario</button>`:''}</td></tr>`).join('') || '<tr><td colspan="7">No hay inventarios registrados para este filtro.</td></tr>';
}
function inventoryDifferenceClass(value){const n=Number(value||0);return n<0?'inventory-diff-negative':n>0?'inventory-diff-positive':'';}
function renderInventoryDetail(count){
  state.currentInventoryCount=count;
  $('#inventory-detail-title').textContent=`${count.count_number} · ${uiCodeLabel(count.status)}`;
  const items=count.items||[]; const pending=items.filter((item)=>['PENDIENTE','DIFERENCIA'].includes(item.status)).length;
  $('#inventory-detail-summary').className=`user-clearance-status ${pending?'pending':'ready'}`;
  $('#inventory-detail-summary').textContent=`${items.length} ítem(s) · ${pending} pendiente(s) o diferencia(s) · ${count.location_name || count.site_name || 'alcance general'}`;
  $('#inventory-detail-body').innerHTML=items.length?items.map((item)=>{
    const counted=item.counted_quantity==null?'—':Number(item.counted_quantity).toLocaleString('es-AR');
    const diff=item.difference_quantity==null?'—':Number(item.difference_quantity).toLocaleString('es-AR');
    const canCount=can('Inventory.Execute')&&['ABIERTO','CONTEO'].includes(count.status);
    const canReconcile=can('Inventory.Reconcile')&&item.counted_quantity!=null&&['DIFERENCIA','CONTADO'].includes(item.status)&&['CONTEO','CONCILIACION'].includes(count.status);
    return `<tr><td><strong>${escapeHtml(item.internal_code)}</strong><div class="small">${escapeHtml(item.description)}</div></td><td>${escapeHtml(item.lot_code || item.location_code || '—')}</td><td>${Number(item.expected_quantity||0).toLocaleString('es-AR')}</td><td>${escapeHtml(counted)}</td><td class="${inventoryDifferenceClass(item.difference_quantity)}">${escapeHtml(diff)}</td><td><span class="status ${item.status==='CONCILIADO'||item.status==='AJUSTADO'||item.status==='CONTADO'?'ok':item.status==='DIFERENCIA'?'danger':'neutral'}">${escapeHtml(uiCodeLabel(item.status))}</span></td><td class="actions">${canCount?`<button data-inventory-item-action="count" data-id="${item.id}">${item.counted_quantity==null?'Contar':'Recontar'}</button>`:''}${canReconcile?`<button data-inventory-item-action="reconcile" data-id="${item.id}">Conciliar</button>`:''}</td></tr>`;
  }).join(''):'<tr><td colspan="7">Este inventario no contiene ítems.</td></tr>';
  $('#inventory-detail-dialog').showModal();
}
async function openInventoryDetail(id){const detail=(await api(`/api/v1/inventory-counts/${id}`)).count;renderInventoryDetail(detail);return detail;}
$('#inventory-refresh').addEventListener('click',()=>loadInventoryCounts().catch((e)=>flash(e.message,'error'))); $('#inventory-status-filter').addEventListener('change',()=>loadInventoryCounts().catch((e)=>flash(e.message,'error')));
$('#inventory-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const values = await askFields('Planificar inventario', [
      { name: 'locationId', label: 'Ubicación (opcional)', type: 'select', required: false, options: [{ value: '', label: 'Todas las ubicaciones' }, ...state.locations.locations.filter((location) => location.active).map((location) => ({ value: location.id, label: operationalLocationLabel(location) }))] },
      { name: 'categoryId', label: 'Categoría (opcional)', type: 'select', required: false, options: [{ value: '', label: 'Todas las categorías' }, ...state.categories.filter((category) => category.active).map((category) => ({ value: category.id, label: `${category.code} · ${category.name}` }))] }
    ], { confirmText: 'Planificar' });
    if (!values) return;
    const locationId = values.locationId || null;
    const categoryId = values.categoryId || null;
    await api('/api/v1/inventory-counts', { method: 'POST', body: JSON.stringify({ clientCountId: crypto.randomUUID(), countType: locationId || categoryId ? 'PARCIAL' : 'TOTAL', locationId, categoryId, blindCount: true, notes: 'Inventario planificado desde interfaz.' }) });
    flash('Inventario planificado.'); await loadInventoryCounts();
  } catch (e) { flash(e.message, 'error'); }
});
$('#inventory-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-count-action]'); if (!button) return;
  try {
    const detail = (await api(`/api/v1/inventory-counts/${button.dataset.id}`)).count;
    if (button.dataset.countAction === 'detail') return renderInventoryDetail(detail);
    const values = await askFields(button.dataset.countAction === 'open' ? 'Iniciar conteo físico' : 'Cerrar inventario', [{ name: 'reason', label: 'Fundamento de la operación', type: 'textarea', minLength: 5 }], { confirmText: button.dataset.countAction === 'open' ? 'Iniciar conteo' : 'Cerrar inventario' });
    if (!values) return;
    await api(`/api/v1/inventory-counts/${button.dataset.id}/${button.dataset.countAction}`, { method: 'POST', body: JSON.stringify({ version: detail.version, reason: values.reason }) });
    flash('Inventario actualizado.'); await loadInventoryCounts();
    if (button.dataset.countAction === 'open') await openInventoryDetail(button.dataset.id);
  } catch (e) { flash(e.message, 'error'); }
});
$('#inventory-detail-body').addEventListener('click', async (event)=>{
  const button=event.target.closest('[data-inventory-item-action]'); if(!button||!state.currentInventoryCount)return;
  const item=(state.currentInventoryCount.items||[]).find((row)=>row.id===button.dataset.id); if(!item)return;
  try{
    if(button.dataset.inventoryItemAction==='count'){
      const values=await askFields(`Conteo · ${item.internal_code}`,[{name:'countedQuantity',label:`Cantidad física (${item.unit_of_measure||'unidades'})`,type:'number',value:item.counted_quantity??item.expected_quantity,min:0,step:0.001}],{message:`Sistema: ${Number(item.expected_quantity||0).toLocaleString('es-AR')} · El conteo físico es el dato que observaste.`,confirmText:'Registrar conteo'});
      if(!values)return;
      await api(`/api/v1/inventory-count-items/${item.id}/count`,{method:'POST',body:JSON.stringify({version:item.version,countedQuantity:Number(values.countedQuantity)})});
      flash('Conteo registrado.');
    }else{
      const options=[{value:'ACEPTAR_CONTEO',label:'Aceptar conteo físico'},{value:'MANTENER_SISTEMA',label:'Mantener cantidad del sistema'},{value:'INVESTIGAR',label:'Dejar diferencia para investigar'}];
      if(can('Inventory.Adjust')) options.splice(2,0,{value:'AJUSTAR',label:'Ajustar stock al conteo físico'});
      const values=await askFields(`Conciliar · ${item.internal_code}`,[{name:'resolution',label:'Resolución',type:'select',options},{name:'reason',label:'Fundamento',type:'textarea',minLength:5}],{message:`Esperado: ${Number(item.expected_quantity||0).toLocaleString('es-AR')} · contado: ${Number(item.counted_quantity||0).toLocaleString('es-AR')} · diferencia: ${Number(item.difference_quantity||0).toLocaleString('es-AR')}.`,confirmText:'Guardar resolución'});
      if(!values)return;
      await api(`/api/v1/inventory-count-items/${item.id}/reconcile`,{method:'POST',body:JSON.stringify({version:item.version,resolution:values.resolution,reason:values.reason})});
      flash('Diferencia conciliada.');
    }
    await openInventoryDetail(state.currentInventoryCount.id); await loadInventoryCounts();
  }catch(e){flash(e.message,'error');}
});

async function loadInventoryTransfers(){const status=$('#inventory-transfer-status').value;state.inventoryTransfers=(await api(`/api/v1/inventory-transfers${status?`?status=${encodeURIComponent(status)}`:''}`)).items;$('#inventory-transfers-body').innerHTML=state.inventoryTransfers.map((x)=>`<tr><td><strong>${escapeHtml(x.transfer_number)}</strong></td><td>${escapeHtml(x.from_code)}</td><td>${escapeHtml(x.to_code)}</td><td><span class="status ${x.status==='RECIBIDA'?'ok':'neutral'}">${escapeHtml(uiCodeLabel(x.status))}</span></td><td>${escapeHtml(formatDateTime(x.created_at))}</td><td class="actions"><button data-inventory-transfer-action="detail" data-id="${x.id}">Detalle</button>${can('Transfers.Dispatch')&&x.status==='BORRADOR'?`<button data-inventory-transfer-action="dispatch" data-id="${x.id}">Despachar</button>`:''}${can('Transfers.Receive')&&x.status==='EN_TRANSITO'?`<button data-inventory-transfer-action="receive" data-id="${x.id}">Recibir</button>`:''}${can('Transfers.Cancel')&&x.status==='BORRADOR'?`<button data-inventory-transfer-action="cancel" data-id="${x.id}">Cancelar</button>`:''}</td></tr>`).join('');}
$('#inventory-transfer-refresh').addEventListener('click',()=>loadInventoryTransfers().catch((e)=>flash(e.message,'error')));$('#inventory-transfer-status').addEventListener('change',()=>loadInventoryTransfers().catch((e)=>flash(e.message,'error')));
$('#inventory-transfer-create').addEventListener('click', async () => {
  try {
    await ensureCustodyDependencies();
    const locations = state.locations.locations.filter((location) => location.active).map((location) => ({ value: location.id, label: operationalLocationLabel(location) }));
    const values = await askFields('Nueva transferencia interna', [
      { name: 'fromLocationId', label: 'Ubicación origen', type: 'select', options: locations },
      { name: 'toLocationId', label: 'Ubicación destino', type: 'select', options: locations },
      { name: 'assetId', label: 'Bien', type: 'select', options: state.assets.filter((asset) => asset.active).map((asset) => ({ value: asset.id, label: `${asset.internal_code} · ${asset.description}` })) },
      { name: 'quantity', label: 'Cantidad', type: 'number', value: 1, min: 0.001, step: 0.001 },
      { name: 'reason', label: 'Fundamento', type: 'textarea', minLength: 5 }
    ], { confirmText: 'Continuar' });
    if (!values) return;
    if (values.fromLocationId === values.toLocationId) throw new Error('Origen y destino deben ser diferentes.');
    const asset = state.assets.find((item) => item.id === values.assetId);
    if (!asset) throw new Error('El bien seleccionado ya no está disponible en el catálogo. Actualizá e intentá nuevamente.');
    let sourceLotId = null;
    if (['CANTIDAD','CONSUMIBLE'].includes(String(asset.category_nature||'').toUpperCase())) {
      const stock = await api(`/api/v1/stock?locationId=${encodeURIComponent(values.fromLocationId)}&limit=1000`);
      const lots = (stock.items||[]).filter((lot)=>lot.asset_id===asset.id && Number(lot.quantity_available||0)>0);
      if (!lots.length) throw new Error('Ese bien no tiene un lote con stock disponible en la ubicación de origen.');
      if (lots.length === 1) sourceLotId = lots[0].id;
      else {
        const lotChoice = await askFields('Seleccionar lote de origen', [{ name:'sourceLotId', label:'Lote', type:'select', options:lots.map((lot)=>({value:lot.id,label:`${lot.lot_code} · disponible ${Number(lot.quantity_available||0).toLocaleString('es-AR')}`})) }], { message:'El lote se toma del stock real de la ubicación de origen.', confirmText:'Usar este lote' });
        if (!lotChoice) return; sourceLotId=lotChoice.sourceLotId;
      }
    }
    await api('/api/v1/inventory-transfers', { method: 'POST', body: JSON.stringify({ clientTransferId: crypto.randomUUID(), fromLocationId: values.fromLocationId, toLocationId: values.toLocationId, reason: values.reason, items: [{ assetId: values.assetId, sourceLotId, quantity: Number(values.quantity) }] }) });
    flash('Transferencia creada.'); await loadInventoryTransfers();
  } catch (e) { flash(e.message, 'error'); }
});

$('#inventory-transfers-body').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-inventory-transfer-action]'); if (!button) return;
  try {
    const detail = (await api(`/api/v1/inventory-transfers/${button.dataset.id}`)).transfer;
    if (button.dataset.inventoryTransferAction === 'detail') return showDetails('Detalle de la transferencia', detail);
    const values = await askFields('Actualizar transferencia', [{ name: 'reason', label: 'Fundamento', type: 'textarea' }], { confirmText: 'Confirmar acción', danger: button.dataset.inventoryTransferAction === 'cancel' });
    if (!values) return;
    await api(`/api/v1/inventory-transfers/${button.dataset.id}/${button.dataset.inventoryTransferAction}`, { method: 'POST', body: JSON.stringify({ version: detail.version, reason: values.reason }) });
    flash('Transferencia actualizada.'); await loadInventoryTransfers();
  } catch (e) { flash(e.message, 'error'); }
});

