function dashboardMetricValue(value) {
  return value === null || value === undefined ? '—' : Number(value).toLocaleString('es-AR');
}

function formatDashboardDate(value) {
  if (!value) return 'Sin fecha';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function dashboardCardHtml(item) {
  return `<button class="card dashboard-kpi" type="button" data-tone="${escapeHtml(item.tone || 'neutral')}" data-dashboard-open="${escapeHtml(item.view || '')}" data-dashboard-label="${escapeHtml(item.label || '')}" data-dashboard-filter="${escapeHtml(JSON.stringify(item.filter || {}))}">
    <span class="dashboard-kpi-icon"><svg class="ui-icon" aria-hidden="true"><use href="/assets/icons.svg#icon-${escapeHtml(item.icon || 'info')}"></use></svg></span>
    <span class="dashboard-kpi-copy"><small>${escapeHtml(item.label)}</small><strong>${dashboardMetricValue(item.value)}</strong><em>${escapeHtml(item.unit || '')}</em></span>
  </button>`;
}

function renderDashboardCards(cards = []) {
  const sections = { attention: $('#dashboard-cards-attention'), status: $('#dashboard-cards-status'), today: $('#dashboard-cards-today') };
  for (const [section, node] of Object.entries(sections)) {
    if (!node) continue;
    const items = cards.filter((item) => item.section === section);
    node.innerHTML = items.length ? items.map(dashboardCardHtml).join('') : '<div class="dashboard-empty compact">No hay indicadores disponibles para este usuario.</div>';
    node.closest('.dashboard-card-section')?.classList.toggle('hidden', items.length === 0);
  }
}

function renderDashboardAttention(items = [], total = items.length, limit = items.length) {
  const list = $('#dashboard-attention-list');
  const count = $('#dashboard-attention-count');
  if (!list || !count) return;
  const visible = items.length;
  count.textContent = total > visible ? `${total} pendientes · mostrando ${visible}` : `${total} ${total === 1 ? 'pendiente' : 'pendientes'}`;
  count.className = `status ${items.some((item) => item.priority === 'CRITICA') ? 'danger' : total ? 'warn' : 'ok'}`;
  if (!items.length) {
    list.innerHTML = '<div class="dashboard-empty"><strong>Sin asuntos pendientes.</strong><span>No hay acciones urgentes dentro de su alcance y permisos.</span></div>';
    return;
  }
  list.innerHTML = items.map((item) => `<button type="button" class="dashboard-attention-item" data-priority="${escapeHtml(item.priority)}" data-dashboard-open="${escapeHtml(item.view)}" data-dashboard-label="${escapeHtml(item.title)}" data-dashboard-filter="${escapeHtml(JSON.stringify(item.filter || {}))}">
    <span class="dashboard-attention-priority" aria-hidden="true"></span>
    <span class="dashboard-attention-copy"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.detail)}</small></span>
    <span class="dashboard-attention-time">${escapeHtml(formatDashboardDate(item.dueAt))}</span>
  </button>`).join('');
}

function renderDashboardActivity(rows = []) {
  const chart = $('#dashboard-activity-chart');
  if (!chart) return;
  const max = Math.max(1, ...rows.flatMap((row) => [row.requests, row.deliveries, row.returns].map(Number)));
  chart.innerHTML = rows.map((row) => {
    const bars = [
      ['requests', row.requests, 'Solicitudes'],
      ['deliveries', row.deliveries, 'Entregas'],
      ['returns', row.returns, 'Devoluciones']
    ].map(([series, raw, name]) => {
      const value = Number(raw) || 0;
      const height = value === 0 ? 0 : (value / max) * 100;
      return `<span class="dashboard-bar ${series} ${percentClass('h', height)}" title="${escapeHtml(`${name}: ${value}`)}" aria-label="${escapeHtml(`${name}: ${value}`)}"></span>`;
    }).join('');
    return `<div class="dashboard-day"><div class="dashboard-bars">${bars}</div><span class="dashboard-day-label" title="${escapeHtml(row.day)}">${escapeHtml(row.label || row.day)}</span></div>`;
  }).join('');
}

function c3ControlValue(value) { return value === null || value === undefined ? '—' : Number(value).toLocaleString('es-AR'); }
function c3ControlListRow(title, detail, dateText, view, tone = '', filter = {}, label = '') {
  return `<button type="button" class="c3-control-row ${escapeHtml(tone)}" data-dashboard-open="${escapeHtml(view || '')}" data-dashboard-label="${escapeHtml(label || title || 'Filtro seleccionado')}" data-dashboard-filter="${escapeHtml(JSON.stringify(filter || {}))}"><span class="c3-control-row-dot"></span><div><strong>${escapeHtml(title || 'Registro')}</strong><small>${escapeHtml(detail || '')}</small></div><time>${escapeHtml(dateText || '')}</time></button>`;
}

function renderSupervisorReviewNotice(rows = []) {
  const pending = Array.isArray(rows) ? rows : [];
  let notice = $('#supervisor-review-popout');
  let pill = $('#supervisor-review-pill');
  if (!pending.length) {
    notice?.remove();
    pill?.remove();
    try { sessionStorage.removeItem('iwcSupervisorReviewDismissed'); } catch {}
    return;
  }
  const signature = pending.map((row) => row.id).filter(Boolean).sort().join('|');
  let dismissed = '';
  try { dismissed = sessionStorage.getItem('iwcSupervisorReviewDismissed') || ''; } catch {}
  if (!pill) {
    pill = document.createElement('button');
    pill.id = 'supervisor-review-pill';
    pill.type = 'button';
    pill.className = 'supervisor-review-pill';
    document.body.appendChild(pill);
  }
  pill.innerHTML = `<span>Supervisión</span><strong>${pending.length}</strong>`;
  pill.setAttribute('aria-label', `${pending.length} ${pending.length === 1 ? 'devolución pendiente' : 'devoluciones pendientes'} de revisión`);
  if (!notice) {
    notice = document.createElement('aside');
    notice.id = 'supervisor-review-popout';
    notice.className = 'supervisor-review-popout';
    notice.setAttribute('role', 'status');
    document.body.appendChild(notice);
  }
  notice.dataset.signature = signature;
  notice.innerHTML = `<header><div><span class="eyebrow">REQUIERE TU REVISIÓN</span><h3>${pending.length} ${pending.length === 1 ? 'vehículo pendiente' : 'vehículos pendientes'}</h3></div><button type="button" class="supervisor-review-close" aria-label="Cerrar aviso">×</button></header><div class="supervisor-review-list">${pending.slice(0,3).map((item)=>`<button type="button" class="supervisor-review-item" data-supervisor-review-custody="${escapeHtml(item.custody_id||'')}" data-supervisor-review-search="${escapeHtml(item.license_plate||item.internal_code||'')}"><strong>${escapeHtml(item.license_plate||item.internal_code||'Vehículo')} · ${escapeHtml(item.description||'Vehículo')}</strong><small>${escapeHtml(item.requester_name||'Usuario')} · devolución declarada</small><time>${escapeHtml(formatDashboardDate(item.requested_at))}</time><span>REVISAR</span></button>`).join('')}</div>${pending.length>3?`<footer>+ ${pending.length-3} pendientes adicionales</footer>`:''}`;
  notice.classList.toggle('hidden', dismissed === signature);
  pill.classList.toggle('hidden', false);
}

function renderC3ControlCenter(data = {}) {
  const m = data.metrics || {};
  const supervisorPanel=$('#c3-supervisor-decisions');
  const adminPanels=$('#c3-admin-operational-panels');
  const mode=String(data.dashboardMode||'CONTROL').toUpperCase();
  supervisorPanel?.classList.toggle('hidden',mode!=='SUPERVISOR');
  adminPanels?.classList.toggle('hidden',mode!=='ADMIN');
  if (mode!=='SUPERVISOR') renderSupervisorReviewNotice([]);
  if (mode==='SUPERVISOR') {
    const rows=data.vehicleApprovals||[];
    const count=$('#c3-supervisor-approval-count');
    if(count) count.textContent=`${rows.length} ${rows.length===1?'pendiente':'pendientes'}`;
    const list=$('#c3-supervisor-approvals');
    if(list) list.innerHTML=rows.length?rows.map((item)=>{ const vehicleKey=item.license_plate||item.internal_code||''; return c3ControlListRow(`${vehicleKey||'Vehículo'} · ${item.description||'Vehículo'}`,`${item.requester_name||'Usuario'} · devolución declarada`,formatDashboardDate(item.requested_at),'custodies','warn',{ search: vehicleKey },`Revisión ${vehicleKey||'vehículo'}`); }).join(''):'<p class="c3-empty">Sin vehículos pendientes de tu V°B°.</p>';
    renderSupervisorReviewNotice(rows);
  }
  if (mode==='ADMIN') {
    const vehicles=data.vehiclesOutNow||[];
    const count=$('#c3-admin-vehicles-out-count'); if(count) count.textContent=String(vehicles.length);
    const list=$('#c3-admin-vehicles-out');
    if(list) list.innerHTML=vehicles.length?vehicles.map((item)=>c3ControlListRow(`${item.license_plate||item.internal_code} · ${item.description||'Vehículo'}`,`${item.custodian_name||'Sin responsable'} · Supervisor: ${item.supervisor_name||'Sin asignar'}`,item.due_at?formatDashboardDate(item.due_at):formatDashboardDate(item.opened_at),'custodies',item.due_at&&new Date(item.due_at)<new Date()?'danger':'')).join(''):'<p class="c3-empty">No hay vehículos fuera en este momento.</p>';
    const serialized=data.serializedOutNow||[];
    const serializedCount=$('#c3-admin-serialized-out-count'); if(serializedCount) serializedCount.textContent=String(serialized.length);
    const serializedList=$('#c3-admin-serialized-out');
    if(serializedList) serializedList.innerHTML=serialized.length?serialized.map((item)=>c3ControlListRow(`${item.internal_code} · ${item.description||'Serializado'}`,`Serie: ${item.serial_number||'Sin serie'} · ${item.custodian_name||'Sin responsable'}`,item.due_at?formatDashboardDate(item.due_at):formatDashboardDate(item.opened_at),'custodies',item.due_at&&new Date(item.due_at)<new Date()?'danger':'',{ search:item.serial_number||item.internal_code },`Serializado ${item.internal_code||''}`)).join(''):'<p class="c3-empty">No hay bienes serializados fuera en este momento.</p>';
    const custody=$('#c3-admin-custody-snapshot');
    const rows=data.custodySnapshot||[];
    if(custody) custody.innerHTML=rows.length?rows.map((item)=>c3ControlListRow(`${item.internal_code} · ${item.description||'Bien'}`,`${item.custodian_name||'Sin responsable'} · Supervisor: ${item.supervisor_name||'Sin asignar'}`,item.due_at?formatDashboardDate(item.due_at):'', 'custodies', item.due_at&&new Date(item.due_at)<new Date()?'danger':'')).join(''):'<p class="c3-empty">Sin custodias activas.</p>';
  }
  const set = (id, value) => { const node=$(id); if (node) node.textContent=c3ControlValue(value); };
  set('#c3-fleet-operational',m.fleetOperational); set('#c3-fleet-total',m.fleetTotal);
  set('#c3-equipment-custody',m.equipmentInCustody); set('#c3-equipment-total',m.equipmentTotal);
  set('#c3-open-incidents',m.openIncidents); set('#c3-pending-returns',m.pendingReturns); set('#c3-maintenance-next30',m.maintenanceNext30);

  const flow = data.fleetByStatus || {};
  const flowRows = [
    ['En custodia',flow.enCustodia,'vehicle'],['Disponible',flow.disponible,'ok'],['Reservado',flow.reservado,'info'],['En mantenimiento',flow.mantenimiento,'warn'],['Fuera de servicio',flow.fueraServicio,'danger']
  ];
  const flowNode=$('#c3-fleet-flow');
  if (flowNode) flowNode.innerHTML=flowRows.map(([label,value,tone])=>`<div class="c3-flow-step ${tone}"><span>${escapeHtml(label)}</span><strong>${c3ControlValue(value)}</strong></div>`).join('<b class="c3-flow-arrow">›</b>');

  const total=Number(m.fleetTotal||0);
  const values=[Number(flow.disponible||0),Number(flow.reservado||0),Number(flow.enCustodia||0),Number(flow.mantenimiento||0),Number(flow.fueraServicio||0)];
  const labels=['Disponible','Reservado','En custodia','En mantenimiento','Fuera de servicio'];
  const tones=['green','blue','cyan','amber','gray'];
  let acc=0; const stops=[];
  const colors=['#11a95d','#1687df','#17a9b7','#efad18','#71839a'];
  values.forEach((value,index)=>{ const next=total?acc+(value/total*100):acc; stops.push(`${colors[index]} ${acc}% ${next}%`); acc=next; });
  const donut=$('#c3-fleet-donut'); if(donut){ donut.style.background=total?`conic-gradient(${stops.join(',')})`:'#e6edf3'; donut.querySelector('span').textContent=c3ControlValue(total); }
  const legend=$('#c3-fleet-legend'); if(legend) legend.innerHTML=labels.map((label,index)=>`<div><i class="${tones[index]}"></i><span>${escapeHtml(label)}</span><strong>${c3ControlValue(values[index])}</strong><em>${total?Math.round(values[index]/total*100):0}%</em></div>`).join('');

  const alerts=$('#c3-control-alerts');
  if(alerts) alerts.innerHTML=(data.alerts||[]).length ? data.alerts.map((item)=>{
    const view=item.kind==='ACTION'?'management':item.kind==='INCIDENT'?'incidents':'custodies';
    return c3ControlListRow(item.title,item.detail,formatDashboardDate(item.at),view,String(item.severity||'').toLowerCase());
  }).join('') : '<p class="c3-empty">Sin alertas ni acciones abiertas dentro del alcance.</p>';
  const maintenance=$('#c3-control-maintenance');
  if(maintenance) maintenance.innerHTML=(data.maintenance||[]).length ? data.maintenance.map((item)=>c3ControlListRow(`${item.internal_code || item.order_number} · ${item.description || item.asset_description || ''}`,item.status,formatDashboardDate(item.due_at || item.scheduled_at),'maintenance',item.status==='VENCIDA'?'danger':'')).join('') : '<p class="c3-empty">Sin mantenimientos próximos registrados.</p>';
  const returns=$('#c3-control-returns');
  if(returns) returns.innerHTML=(data.pendingReturnEquipment||[]).length ? data.pendingReturnEquipment.map((item)=>c3ControlListRow(`${item.internal_code} · ${item.description}`,item.custodian_name,formatDashboardDate(item.due_at),'custodies',item.due_at&&new Date(item.due_at)<new Date()?'danger':'')).join('') : '<p class="c3-empty">Sin equipos con devolución pendiente.</p>';
}

async function loadDashboard({ silent = false } = {}) {
  if (!state.user || dashboardRefreshInFlight) return;
  dashboardRefreshInFlight = true;
  const refresh = $('#dashboard-refresh');
  refresh?.classList.add('is-busy');
  try {
    const data = await api('/api/v1/dashboard/control-center');
    state.dashboard = data;
    renderC3ControlCenter(data);
    const updated = $('#dashboard-updated');
    if (updated) { updated.textContent = `Actualizado ${new Date(data.generatedAt).toLocaleString('es-AR')} · datos de Warehouse.`; updated.classList.add('c4-live'); updated.classList.remove('c4-stale'); }
  } catch (error) {
    const updated = $('#dashboard-updated');
    if (updated) { updated.classList.remove('c4-live'); updated.classList.add('c4-stale'); updated.textContent = 'Actualización interrumpida · conservando último estado real.'; }
    if (!silent) throw error;
  } finally {
    dashboardRefreshInFlight = false;
    refresh?.classList.remove('is-busy');
  }
}

function startDashboardAutoRefresh() {
  stopDashboardAutoRefresh();
  if (!state.user) return;
  dashboardAutoRefreshTimer = setInterval(() => {
    if (state.currentView === 'dashboard' && !document.hidden) loadDashboard({ silent: true }).catch(() => {});
  }, DASHBOARD_REFRESH_MS);
}

function stopDashboardAutoRefresh() {
  if (dashboardAutoRefreshTimer) clearInterval(dashboardAutoRefreshTimer);
  dashboardAutoRefreshTimer = null;
}

async function refreshRequestsBackground() {
  if (!state.user || state.currentView !== 'requests' || requestsRefreshInFlight || document.hidden) return;
  if ($('dialog[open]')) return;
  requestsRefreshInFlight = true;
  try {
    await loadRequests();
  } catch (error) {
    if (error.status === 401) stopRequestsAutoRefresh();
  } finally {
    requestsRefreshInFlight = false;
  }
}

function startRequestsAutoRefresh() {
  stopRequestsAutoRefresh();
  if (!state.user || (!can('Requests.ReadAll') && !can('Requests.ReadOwn') && !can('Requests.Approve') && !can('Warehouse.Prepare') && !can('Warehouse.Operate'))) return;
  requestsAutoRefreshTimer = setInterval(() => refreshRequestsBackground().catch(() => {}), REQUESTS_REFRESH_MS);
}

function stopRequestsAutoRefresh() {
  if (requestsAutoRefreshTimer) clearInterval(requestsAutoRefreshTimer);
  requestsAutoRefreshTimer = null;
}

function clearDashboardControls(view) {
  const values = {
    requests: [['#request-admin-search',''],['#request-admin-status','']],
    custodies: [['#custody-search',''],['#custody-status','']],
    incidents: [['#incident-search',''],['#incident-status',''],['#incident-severity',''],['#incident-type','']],
    assets: [['#asset-search',''],['#asset-status',''],['#asset-category-filter',''],['#asset-location-filter',''],['#asset-active','']],
    maintenance: [['#maintenance-order-status','']],
    stock: [['#stock-location-filter',''],['#stock-movement-type',''],['#stock-movement-from',''],['#stock-movement-to','']]
  };
  for (const [selector, value] of values[view] || []) { const node = $(selector); if (node) node.value = value; }
  if (view === 'requests' && $('#request-admin-overdue')) $('#request-admin-overdue').checked = false;
  if (view === 'custodies' && $('#custody-overdue')) $('#custody-overdue').checked = false;
  if (view === 'stock' && $('#stock-unavailable-filter')) $('#stock-unavailable-filter').checked = false;
}

function dashboardFilterParams(view) {
  const filter = state.dashboardViewFilters[view] || {};
  const params = new URLSearchParams();
  for (const [key, raw] of Object.entries(filter)) {
    if (raw === null || raw === undefined || raw === '' || key === 'mode') continue;
    params.set(key, Array.isArray(raw) ? raw.join(',') : String(raw));
  }
  return params;
}

function dashboardFilterBanner(view) {
  const target = $(`#view-${view}`);
  if (!target) return null;
  let banner = target.querySelector('.dashboard-active-filter');
  if (!banner) {
    banner = document.createElement('div');
    banner.className = 'dashboard-filter-banner dashboard-active-filter hidden';
    target.prepend(banner);
  }
  return banner;
}

function clearDashboardFilter(view) {
  delete state.dashboardViewFilters[view];
  dashboardFilterBanner(view)?.classList.add('hidden');
  if (view === 'stock') { $('#stock-lots-panel')?.classList.remove('hidden'); $('#stock-movements-panel')?.classList.remove('hidden'); }
}

function applyDashboardFilter(view, filter = {}, label = '') {
  clearDashboardControls(view);
  state.dashboardViewFilters[view] = { ...filter };
  if (view === 'requests') {
    const statuses = Array.isArray(filter.statuses) ? filter.statuses : [];
    $('#request-admin-status').value = statuses.length === 1 ? statuses[0] : (filter.status || '');
    $('#request-admin-overdue').checked = Boolean(filter.overdue);
  } else if (view === 'custodies') {
    const statuses = Array.isArray(filter.statuses) ? filter.statuses : [];
    $('#custody-search').value = filter.search || '';
    $('#custody-status').value = statuses.length === 1 ? statuses[0] : (filter.status || '');
    $('#custody-overdue').checked = Boolean(filter.overdue || filter.dueBefore);
  } else if (view === 'incidents') {
    const statuses = Array.isArray(filter.statuses) ? filter.statuses : [];
    $('#incident-status').value = statuses.length === 1 ? statuses[0] : (filter.status || '');
    $('#incident-severity').value = filter.severity || '';
  } else if (view === 'assets') {
    $('#asset-status').value = filter.status || '';
  } else if (view === 'maintenance') {
    $('#maintenance-order-status').value = filter.status || '';
  } else if (view === 'stock') {
    $('#stock-unavailable-filter').checked = Boolean(filter.unavailable);
    if (filter.movementFrom) $('#stock-movement-from').value = dateTimeLocalValue(new Date(filter.movementFrom));
    if (filter.movementTo) $('#stock-movement-to').value = dateTimeLocalValue(new Date(filter.movementTo));
  }
  const banner = dashboardFilterBanner(view);
  if (banner && label) {
    banner.innerHTML = `<strong>Vista del dashboard:</strong> ${escapeHtml(label)} <button type="button" data-clear-dashboard-filter="${escapeHtml(view)}">Ver todo</button>`;
    banner.classList.remove('hidden');
  }
}

function navigationButtonForCurrentShell(view) {
  const selector = document.body.classList.contains('c3-workbench-mode') ? `.cv-role-nav-workbench [data-view="${CSS.escape(view)}"]` : document.body.classList.contains('c3-control-mode') ? `.cv-role-nav-control [data-view="${CSS.escape(view)}"]` : `#nav [data-view="${CSS.escape(view)}"]`;
  return [...document.querySelectorAll(selector)].find((button) => !button.hidden) || null;
}
function openDashboardTarget(view, filter = {}, label = '') {
  if (!['workbench','dashboard'].includes(view) && !navigationButtonForCurrentShell(view)) {
    flash('Tu rol no tiene acceso a ese módulo. El indicador se mantiene visible como contexto, pero no habilita una acción fuera de tus permisos.', 'error');
    return;
  }
  if (view === 'workbench') {
    state.dashboardViewFilters[view] = { ...filter };
    setView('workbench');
    const lane = ['prepare','deliver','receive','problems'].includes(String(filter.lane || '')) ? String(filter.lane) : null;
    if (lane) setTimeout(() => $(`#workbench-lane-${lane}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0);
    return;
  }
  applyDashboardFilter(view, filter, label);
  setView(view);
}

function activeNavigationRoot() {
  if (document.body.classList.contains('c3-control-mode')) return document.querySelector('.cv-role-nav-control');
  if (document.body.classList.contains('c3-workbench-mode')) return document.querySelector('.cv-role-nav-workbench');
  return $('#nav');
}

function setNavigationGroupOpen(group, open, { exclusive = false } = {}) {
  if (!group || group.hidden) return;
  const root = group.closest('[data-role-navigation]') || $('#nav');
  if (exclusive && open) {
    [...root.querySelectorAll('.nav-group')].forEach((candidate) => {
      if (candidate !== group) setNavigationGroupOpen(candidate, false);
    });
  }
  const toggle = group.querySelector('[data-nav-group-toggle]');
  const items = group.querySelector('.nav-group-items');
  group.classList.toggle('open', open);
  toggle?.setAttribute('aria-expanded', String(open));
  if (items) items.hidden = !open;
}

function syncNavigationGroups() {
  const root = activeNavigationRoot();
  if (!root) return;
  [...root.querySelectorAll('.nav-group')].forEach((group) => {
    const visibleItems = [...group.querySelectorAll('.nav-group-items [data-view]')].filter((button) => !button.hidden);
    group.hidden = visibleItems.length === 0;
    if (group.hidden) setNavigationGroupOpen(group, false);
  });
  activateNavigationForView(state.currentView);
}

function activateNavigationForView(name) {
  const root = activeNavigationRoot();
  if (!root) return;
  const buttons = [...root.querySelectorAll('[data-view]')];
  buttons.forEach((button) => button.classList.toggle('active', button.dataset.view === name));
  const activeButton = buttons.find((button) => button.dataset.view === name && !button.hidden);
  const activeGroup = activeButton?.closest('.nav-group');
  [...root.querySelectorAll('.nav-group-toggle')].forEach((toggle) => toggle.classList.toggle('active', toggle.closest('.nav-group') === activeGroup));
  if (activeGroup) setNavigationGroupOpen(activeGroup, true, { exclusive: true });
  else [...root.querySelectorAll('.nav-group')].forEach((group) => setNavigationGroupOpen(group, false));
}

function showLogin() {
  ensurePublicBranding().catch(() => {});
  stopDashboardAutoRefresh();
  stopRequestsAutoRefresh();
  stopNotificationsAutoRefresh();
  state.user = null; state.csrfToken = ''; sessionStorage.removeItem('iwc_csrf');
  $('#app-view').classList.add('hidden');
  $('#initial-setup-view').classList.add('hidden');
  $('#recovery-view')?.classList.add('hidden');
  $('#unified-first-access-view')?.classList.add('hidden');
  $('#login-view').classList.remove('hidden');
  reportLoginMobileValidation('OPERATION_OPENED').catch(() => {});
}

function showInitialSetup(setup = {}) {
  stopDashboardAutoRefresh();
  stopRequestsAutoRefresh();
  stopNotificationsAutoRefresh();
  state.user = null; state.csrfToken = ''; sessionStorage.removeItem('iwc_csrf');
  $('#app-view').classList.add('hidden');
  $('#login-view').classList.add('hidden');
  $('#recovery-view')?.classList.add('hidden');
  $('#unified-first-access-view')?.classList.add('hidden');
  $('#initial-setup-view').classList.remove('hidden');
  $('#initial-setup-error').textContent = '';
  const requiresIdentity = setup.requiresIdentity !== false;
  $('#initial-setup-identity')?.classList.toggle('hidden', !requiresIdentity);
  for (const input of [$('#initial-setup-full-name'), $('#initial-setup-document-type'), $('#initial-setup-document-number')]) {
    if (input) input.required = requiresIdentity;
  }
  setTimeout(() => (requiresIdentity ? $('#initial-setup-full-name') : $('#initial-setup-username'))?.focus(), 30);
}


function usesSimpleCredentialUi() {
  const simpleRoles = new Set(['SOLICITANTE', 'PANOLERO']);
  const roles = state.user?.roleCodes || [];
  return roles.length > 0 && roles.every((role) => simpleRoles.has(role));
}

function configureCredentialFields() {
  const simple = true;
  const minimum = 4;
  const maximum = 8;
  for (const input of [$('#password-new'), $('#password-confirm')]) {
    input.minLength = minimum; input.maxLength = maximum;
    input.pattern = '[A-Za-z0-9]{4,8}';
  }
}

function serverExperience() {
  return state.user?.experience || null;
}

function requestedExperienceTarget(experience = serverExperience()) {
  const requested = new URLSearchParams(window.location.search).get('next');
  if (!requested || !requested.startsWith('/') || requested.startsWith('//')) return null;
  try {
    const parsed = new URL(requested, window.location.origin);
    const route = parsed.pathname.replace(/\/+$/, '') || '/';
    if (parsed.origin !== window.location.origin || !(experience?.screenRoutes || []).includes(route)) return null;
    return `${route}${parsed.search}`;
  } catch {
    return null;
  }
}

function mobileValidationFromLogin() {
  const target = requestedExperienceTarget({ screenRoutes: ['/mi-operacion'] });
  if (!target) return null;
  const parsed = new URL(target, window.location.origin);
  const validationToken = String(parsed.searchParams.get('v') || '').trim();
  return validationToken ? { validationToken } : null;
}

function mobileDeviceEvidence() {
  return {
    screenWidth: Number(window.screen?.width || 0),
    screenHeight: Number(window.screen?.height || 0),
    viewportWidth: Number(window.innerWidth || 0),
    viewportHeight: Number(window.innerHeight || 0),
    maxTouchPoints: Number(navigator.maxTouchPoints || 0),
    touchEvent: 'ontouchstart' in window,
    coarsePointer: Boolean(window.matchMedia?.('(pointer: coarse)').matches),
    standalone: Boolean(window.matchMedia?.('(display-mode: standalone)').matches),
    platform: navigator.userAgentData?.platform || navigator.platform || null,
    vendor: navigator.vendor || null,
    orientation: window.screen?.orientation?.type || null
  };
}

async function reportLoginMobileValidation(stage) {
  const validation = mobileValidationFromLogin();
  if (!validation) return;
  await api('/api/v1/operation/mobile-validation/ping', {
    method: 'POST',
    body: JSON.stringify({ ...validation, stage, deviceEvidence: mobileDeviceEvidence() })
  });
}

function isWarehouseOperatorHome() {
  return serverExperience()?.code === 'WAREHOUSE_OPERATOR';
}

function viewForExperienceRoute(route) {
  if (route === '/panol/workbench') return 'workbench';
  if (route === '/gestion/config') return 'config';
  return 'dashboard';
}

const DEFAULT_PUBLIC_BRANDING = Object.freeze({ organizationName: 'Cliente', productName: 'INGAR Warehouse', clientLogoConfigured: false, clientLogoUrl: null });
let publicBrandingRequest = null;
function applyPublicBranding(branding = {}) {
  const current = { ...DEFAULT_PUBLIC_BRANDING, ...branding };
  const loginName = $('#login-product-name'); if (loginName) loginName.textContent = current.productName || 'INGAR Warehouse';
  document.querySelectorAll('[data-client-brand]').forEach((slot) => {
    const image = slot.querySelector('[data-client-logo]');
    const name = slot.querySelector('[data-client-name]');
    if (name) name.textContent = current.organizationName || 'Cliente';
    if (current.clientLogoConfigured && current.clientLogoUrl && image) {
      image.src = current.clientLogoUrl; image.alt = `Logo de ${current.organizationName || 'cliente'}`; slot.classList.remove('hidden');
    } else { if (image) image.removeAttribute('src'); slot.classList.add('hidden'); }
  });
}
async function ensurePublicBranding({ force = false } = {}) {
  if (!force && state.publicBranding?.loaded) { applyPublicBranding(state.publicBranding); return state.publicBranding; }
  if (!publicBrandingRequest) publicBrandingRequest = fetch('/api/v1/public/branding', { credentials:'same-origin', cache:'no-store' })
    .then(async (response) => { if (!response.ok) throw new Error('BRANDING_UNAVAILABLE'); return response.json(); })
    .then((data) => { state.publicBranding = { ...DEFAULT_PUBLIC_BRANDING, ...(data?.branding || {}), loaded:true }; applyPublicBranding(state.publicBranding); return state.publicBranding; })
    .catch(() => { state.publicBranding = { ...DEFAULT_PUBLIC_BRANDING, loaded:true }; applyPublicBranding(state.publicBranding); return state.publicBranding; })
    .finally(() => { publicBrandingRequest = null; });
  return publicBrandingRequest;
}
function applySessionAvatar() {
  const image = $('#session-user-avatar-image'), fallback = $('#session-user-avatar-fallback');
  if (!image || !fallback) return;
  const evidenceId = String(state.user?.photoEvidenceId || '').trim();
  if (!evidenceId) { image.classList.add('hidden'); image.removeAttribute('src'); fallback.classList.remove('hidden'); return; }
  image.onerror = () => { image.classList.add('hidden'); image.removeAttribute('src'); fallback.classList.remove('hidden'); };
  image.src = `/api/v1/evidence/${encodeURIComponent(evidenceId)}`; image.classList.remove('hidden'); fallback.classList.add('hidden');
}
window.iwcBranding = { refresh: () => ensurePublicBranding({ force:true }), ensure: ensurePublicBranding };

function enterServerExperience({ replace = false } = {}) {
  const experience = serverExperience();
  const requestedTarget = requestedExperienceTarget(experience);
  const target = requestedTarget || experience?.targetRoute || '/acceso-limitado';
  const current = (window.location.pathname || '/').replace(/\/+$/, '') || '/';
  const entitledRoutes = new Set(experience?.screenRoutes || []);
  if (current === '/' || current === '/index.html') {
    window.location[replace ? 'replace' : 'assign'](target);
    return true;
  }
  if (current === '/mi-operacion') return false;
  // El shell pertenece a la experiencia primaria del rol. Un ADMIN/SUPERVISOR no debe
  // quedar convertido en Pañolero sólo porque una ventana antigua terminó en /panol/workbench.
  if (!requestedTarget && experience?.code === 'CONTROL_CENTER' && current === '/panol/workbench') {
    window.location[replace ? 'replace' : 'assign'](experience.targetRoute || '/control');
    return true;
  }
  if (current === target || entitledRoutes.has(current)) {
    setView(viewForExperienceRoute(current));
    return false;
  }
  window.location.replace(target);
  return true;
}

function showApp() {
  ensurePublicBranding().catch(() => {});
  $('#initial-setup-view').classList.add('hidden');
  $('#recovery-view')?.classList.add('hidden');
  $('#unified-first-access-view')?.classList.add('hidden');
  $('#login-view').classList.add('hidden'); $('#app-view').classList.remove('hidden');
  configureCredentialFields();
  const warehouseOperatorMode = isWarehouseOperatorHome();
  const experienceCode = String(serverExperience()?.code || '');
  document.body.classList.toggle('warehouse-operator-mode', warehouseOperatorMode);
  document.body.classList.toggle('c3-workbench-mode', experienceCode === 'WAREHOUSE_OPERATOR');
  document.body.classList.toggle('c3-control-mode', experienceCode === 'CONTROL_CENTER');
  const workbenchNavigation = document.querySelector('.cv-role-nav-workbench');
  const controlNavigation = document.querySelector('.cv-role-nav-control');
  if (workbenchNavigation) workbenchNavigation.hidden = experienceCode !== 'WAREHOUSE_OPERATOR';
  if (controlNavigation) controlNavigation.hidden = experienceCode !== 'CONTROL_CENTER';
  document.body.classList.remove('warehouse-operator-more');
  const moreOptions = $('#warehouse-more-options');
  if (moreOptions) moreOptions.hidden = true;
  const roleCodes = new Set((state.user?.roleCodes || []).map((code) => String(code || '').toUpperCase()));
  document.body.dataset.roleFamily = roleCodes.has('ADMIN_GENERAL') ? 'ADMIN_GENERAL' : roleCodes.has('ADMINISTRADOR') ? 'ADMIN' : roleCodes.has('SUPERVISOR') ? 'SUPERVISOR' : warehouseOperatorMode ? 'PANOLERO' : 'OTHER';
  $('#session-user').textContent = state.user.fullName;
  $('#session-user').title = `Usuario: ${state.user.username}`;
  applySessionAvatar();
  const roleBadge = $('#cv-session-role');
  if (roleBadge) {
    const code = state.user?.experience?.code || '';
    roleBadge.textContent = roleCodes.has('ADMIN_GENERAL') ? 'Administrador General' : roleCodes.has('ADMINISTRADOR') ? 'Administrador' : roleCodes.has('SUPERVISOR') ? 'Supervisor' : code === 'WAREHOUSE_OPERATOR' ? 'Pañolero' : 'Usuario';
  }
  const dateNode = $('#cv-current-date');
  if (dateNode) dateNode.textContent = new Date().toLocaleString('es-AR',{weekday:'short',day:'2-digit',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});
  $$('[data-permission]').forEach((node) => { node.hidden = !can(node.dataset.permission); });
  $$('[data-permission-any]').forEach((node) => { node.hidden = !node.dataset.permissionAny.split(',').some((permission) => can(permission.trim())); });
  $$('.pb-role-nav [data-write-permission]').forEach((node) => {
    node.querySelector('.pb-readonly-badge')?.remove();
    if (!node.hidden && !can(node.dataset.writePermission)) {
      const badge = document.createElement('span');
      badge.className = 'pb-readonly-badge';
      badge.textContent = 'Solo lectura';
      node.appendChild(badge);
    }
  });
  syncNavigationGroups();
  startNotificationsAutoRefresh();
  startDashboardAutoRefresh();
  startRequestsAutoRefresh();
}

const SESSION_HINT_KEY = 'iwc_session_hint_until';

function rememberSessionHint(expiresAt) {
  const value = Date.parse(expiresAt || '');
  if (Number.isFinite(value) && value > Date.now()) localStorage.setItem(SESSION_HINT_KEY, String(value));
  else localStorage.removeItem(SESSION_HINT_KEY);
}

function clearSessionHint() {
  localStorage.removeItem(SESSION_HINT_KEY);
}

function hasCurrentSessionHint() {
  const value = Number(localStorage.getItem(SESSION_HINT_KEY) || 0);
  if (!Number.isFinite(value) || value <= Date.now()) {
    clearSessionHint();
    return false;
  }
  return true;
}


function isServerGatedExperiencePath() {
  const current = (window.location.pathname || '/').replace(/\/+$/, '') || '/';
  return ['/panol/workbench','/control','/gestion/config','/acceso-limitado'].includes(current);
}

async function bootstrap() {
  ensurePublicBranding().catch(() => {});
  try {
    const setup = await api('/api/v1/auth/initial-setup');
    if (setup.required) {
      showInitialSetup(setup);
      return;
    }
  } catch (error) {
    if (error.status !== 403) {
      showLogin();
      return;
    }
  }
  if (!state.csrfToken && !hasCurrentSessionHint() && !isServerGatedExperiencePath()) {
    showLogin();
    return;
  }
  try {
    const data = await api('/api/v1/auth/me');
    state.user = data.user;
    if (!state.csrfToken) {
      const csrfData = await api('/api/v1/auth/csrf');
      state.csrfToken = csrfData.csrfToken || '';
      if (state.csrfToken) sessionStorage.setItem('iwc_csrf', state.csrfToken);
    }
    showApp();
    enterServerExperience({ replace: true });
  } catch {
    clearSessionHint();
    showLogin();
  }
}

function setView(name) {
  state.currentView = name;
  document.body.dataset.currentView = name;
  if (name !== 'portal') stopPortalAutoRefresh();
  $$('.view').forEach((view) => view.classList.toggle('active', view.id === `view-${name}`));
  activateNavigationForView(name);
  const titles = {
    workbench: ['Puesto del pañolero', 'Preparar, entregar, recibir y resolver la operación diaria'],
    dashboard: ['Centro de Control', 'Prioridades, riesgos, disponibilidad y acciones de gestión'],
    users: ['Personas y usuarios', 'Personas, cuentas, estados y asignaciones'],
    roles: ['Roles y permisos', 'Autorización RBAC, herencia y permisos efectivos'],
    assets: ['Bienes y herramientas', 'Maestro, identificación, disponibilidad y documentación'],
    categories: ['Categorías', 'Naturaleza y reglas de control de los bienes'],
    imports: ['Importaciones', 'Plantillas, validación sin aplicar, aplicación, historial y reversión'],
    requests: ['Solicitudes', 'Recepción, autorización, preparación, entrega y seguimiento'],
    custodies: ['Custodias y devoluciones', 'Responsabilidad, devolución, recepción, inspección y transferencias'],
    incidents: ['Incidencias', 'Apertura, investigación, evidencias, recuperación y cierre'],
    blocks: ['Bloqueos y excepciones', 'Restricciones operativas, vigencias y autorizaciones controladas'],
    vehicles: ['Vehículos', 'Perfiles, habilitaciones, odómetro, combustible y checklist'],
    kits: ['Kits', 'Composición, disponibilidad, sustituciones y devoluciones parciales'],
    stock: ['Stock y consumibles', 'Lotes, movimientos, reservas, consumos y ajustes'],
    inventory: ['Inventarios físicos', 'Planificación, conteo, conciliación y cierre'],
    'inventory-transfers': ['Transferencias internas', 'Despacho, tránsito y recepción entre ubicaciones'],
    maintenance: ['Mantenimiento', 'Planes, órdenes, inspecciones técnicas y bloqueo por vencimiento'],
    notifications: ['Alertas', 'Avisos operativos propios y estado de lectura'],
    resilience: ['Estado del sistema', 'Servidor, base de datos, copias, auditoría y servicios internos'],
    portal: ['Acceso móvil y políticas', 'Entrada a Mi operación por sede y políticas de solicitudes'],
    config: ['Configuración', 'Parámetros generales y políticas'],
    management: ['Gestión', 'Resumen gerencial, tendencias, objetivos y responsables'],
    reports: ['Informes', 'Operación, custodias, devoluciones, inventario, incidentes y trazabilidad'],
    audit: ['Auditoría', 'Registro inmutable y cadena de evidencia'],
    logs: ['Logs', 'Eventos técnicos de frontend, backend, API y persistencia'],
    backups: ['Backups', 'Copias, verificación y restauración controlada']
  };
  [$('#view-title').textContent, $('#view-subtitle').textContent] = titles[name] || titles.dashboard;
  const pageContext = $('#page-context');
  const pageHead = $('.main > .page-head');
  if (pageHead) pageHead.classList.toggle('hidden', name === 'workbench' || name === 'dashboard');
  if (pageContext) {
    if (['requests','custodies','incidents','blocks'].includes(name)) pageContext.textContent = 'Operación';
    else if (['assets','categories','vehicles','kits','stock','inventory','inventory-transfers','imports'].includes(name)) pageContext.textContent = 'Activos e inventario';
    else if (name === 'maintenance') pageContext.textContent = 'Mantenimiento';
    else if (['audit','reports','management','notifications'].includes(name)) pageContext.textContent = 'Control y seguimiento';
    else if (['users','roles','portal','config','resilience','logs','backups'].includes(name)) pageContext.textContent = 'Administración';
    else pageContext.textContent = 'Vista operativa';
  }
  const loaders = { workbench: loadWarehouseWorkbench, dashboard: loadDashboard, users: loadUsers, roles: loadRoles, assets: loadAssets, categories: loadCategories, imports: loadImports, requests: loadRequests, custodies: loadCustodies, incidents: loadIncidents, blocks: loadBlocks, vehicles: loadVehicles, kits: loadKits, stock: loadStock, inventory: loadInventoryCounts, 'inventory-transfers': loadInventoryTransfers, maintenance: loadMaintenance, notifications: loadNotifications, resilience: loadSystemAdministration, portal: loadPortalAdmin, config: loadConfig, management: loadManagement, reports: loadReports, audit: loadAudit, logs: loadLogs, backups: loadBackups };
  loaders[name]?.().catch((error) => flash(error.message, 'error'));
}

$('#initial-setup-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const errorNode = $('#initial-setup-error');
  errorNode.textContent = '';
  const password = $('#initial-setup-password').value;
  const confirmPassword = $('#initial-setup-confirm').value;
  if (password !== confirmPassword) {
    errorNode.textContent = 'Las contraseñas no coinciden.';
    return;
  }
  if (!form.reportValidity()) return;
  const button = $('#initial-setup-submit');
  button.disabled = true;
  button.textContent = 'CREANDO…';
  try {
    const data = await api('/api/v1/auth/initial-setup', {
      method: 'POST',
      body: JSON.stringify({
        fullName: $('#initial-setup-full-name').value.trim(),
        documentType: $('#initial-setup-document-type').value.trim(),
        documentNumber: $('#initial-setup-document-number').value.trim(),
        username: $('#initial-setup-username').value.trim(),
        password,
        confirmPassword
      })
    });
    state.user = data.user;
    state.csrfToken = data.csrfToken;
    sessionStorage.setItem('iwc_csrf', state.csrfToken);
    rememberSessionHint(data.expiresAt);
    form.reset();
    showApp();
    enterServerExperience();
    flash('Acceso creado.');
  } catch (error) {
    errorNode.textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = 'GUARDAR Y ENTRAR';
  }
});

let localAdminRecovery = { token: null, expiresAt: null, accounts: [] };

function selectedRecoveryAccount() {
  const id = $('#recovery-account')?.value || '';
  return localAdminRecovery.accounts.find((item) => item.id === id) || null;
}

function syncRecoveryAccount() {
  const account = selectedRecoveryAccount();
  if (!account) return;
  $('#recovery-username').value = account.username || '';
  const stateLabel = account.active ? 'Cuenta activa' : 'Cuenta inactiva: se reactivará al recuperar';
  $('#recovery-account-detail').textContent = `${account.fullName} · usuario actual: ${account.username} · ${stateLabel}`;
}

async function showLocalAdminRecovery() {
  $('#login-error').textContent = '';
  const data = await api('/api/v1/auth/local-admin-recovery');
  localAdminRecovery = {
    token: data.recoveryToken,
    expiresAt: data.expiresAt,
    accounts: Array.isArray(data.accounts) ? data.accounts : []
  };
  if (!localAdminRecovery.accounts.length) throw new Error('No hay cuentas administrativas disponibles para recuperar.');
  const select = $('#recovery-account');
  select.innerHTML = localAdminRecovery.accounts.map((account) =>
    `<option value="${escapeHtml(account.id)}">${escapeHtml(account.fullName)} — ${escapeHtml(account.username)}${account.active ? '' : ' (inactiva)'}</option>`
  ).join('');
  $('#recovery-form').reset();
  // reset() deja el primer option seleccionado pero también limpia inputs.
  select.selectedIndex = 0;
  syncRecoveryAccount();
  $('#recovery-error').textContent = '';
  $('#app-view').classList.add('hidden');
  $('#initial-setup-view').classList.add('hidden');
  $('#login-view').classList.add('hidden');
  $('#recovery-view').classList.remove('hidden');
  setTimeout(() => $('#recovery-username').focus(), 30);
}

$('#login-recovery-open')?.addEventListener('click', async () => {
  const button = $('#login-recovery-open');
  const original = button.textContent;
  button.disabled = true;
  button.textContent = 'ABRIENDO RECUPERACIÓN…';
  try {
    await showLocalAdminRecovery();
  } catch (error) {
    $('#login-error').textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = original;
  }
});

$('#recovery-account')?.addEventListener('change', syncRecoveryAccount);

$('#recovery-cancel')?.addEventListener('click', () => {
  localAdminRecovery = { token: null, expiresAt: null, accounts: [] };
  $('#recovery-form').reset();
  showLogin();
  setTimeout(() => $('#login-username').focus(), 30);
});

$('#recovery-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const errorNode = $('#recovery-error');
  errorNode.textContent = '';
  if (!localAdminRecovery.token) {
    errorNode.textContent = 'La recuperación venció. Volvé al ingreso e iniciá nuevamente.';
    return;
  }
  const password = $('#recovery-password').value;
  const confirmPassword = $('#recovery-confirm').value;
  if (password !== confirmPassword) {
    errorNode.textContent = 'Las contraseñas no coinciden.';
    return;
  }
  if (!form.reportValidity()) return;
  const account = selectedRecoveryAccount();
  if (!account) {
    errorNode.textContent = 'Seleccioná la cuenta administrativa.';
    return;
  }
  const button = $('#recovery-submit');
  button.disabled = true;
  button.textContent = 'ACTUALIZANDO…';
  try {
    const data = await api('/api/v1/auth/local-admin-recovery', {
      method: 'POST',
      body: JSON.stringify({
        recoveryToken: localAdminRecovery.token,
        accountId: account.id,
        username: $('#recovery-username').value.trim(),
        password,
        confirmPassword,
        confirmation: 'BLANQUEAR'
      })
    });
    state.user = data.user;
    state.csrfToken = data.csrfToken;
    sessionStorage.setItem('iwc_csrf', state.csrfToken);
    rememberSessionHint(data.expiresAt);
    localAdminRecovery = { token: null, expiresAt: null, accounts: [] };
    form.reset();
    $('#login-form').reset();
    showApp();
    enterServerExperience();
    flash('Credenciales administrativas actualizadas.');
  } catch (error) {
    errorNode.textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = 'GUARDAR NUEVO ACCESO';
  }
});


function technicalUsernameFromNameC2(fullName) {
  const normalized = String(fullName || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const parts = normalized.trim().split(/\s+/).map((part) => part.replace(/[^a-z0-9]/g, '')).filter(Boolean);
  return parts.length >= 2 ? `${parts[0]}.${parts[parts.length - 1]}` : '';
}

async function openUnifiedFirstAccess(mode = 'INITIAL_SETUP', identifier = '') {
  const form = $('#unified-first-access-form');
  form.reset();
  form.dataset.mode = mode;
  $('#unified-first-access-error').textContent = '';
  $('#unified-first-access-identifier').value = identifier || '';
  const reset = mode === 'PASSWORD_RESET';
  const documentTypeInput = $('#unified-first-access-document-type');
  const documentTypeField = $('#unified-first-access-document-type-field');
  if (documentTypeInput) { documentTypeInput.disabled = reset; documentTypeInput.required = !reset; }
  documentTypeField?.classList.toggle('hidden', reset);
  $('#unified-first-access-title').textContent = reset ? 'Definí una nueva contraseña' : 'Creá tu acceso';
  $('#unified-first-access-help').textContent = reset ? 'Tu usuario, historial y asignaciones se conservan.' : 'Esto se hace una sola vez. El usuario técnico se genera con nombre.apellido.';
  $('#unified-first-access-name').readOnly = reset;
  $('#unified-first-access-identifier').readOnly = reset;
  if (reset) {
    try {
      const stateResult = await api('/api/v1/auth/access-state', { method: 'POST', body: JSON.stringify({ identifier }) });
      $('#unified-first-access-name').value = stateResult.fullName || '';
      $('#unified-first-access-username').value = stateResult.username || identifier;
    } catch (error) {
      $('#login-error').textContent = error.message;
      return;
    }
  }
  showUnifiedFirstAccess();
}

function showUnifiedFirstAccess() {
  $('#initial-setup-view').classList.add('hidden');
  $('#recovery-view')?.classList.add('hidden');
  $('#login-view').classList.add('hidden');
  $('#unified-first-access-view').classList.remove('hidden');
  setTimeout(() => ($('#unified-first-access-name').readOnly ? $('#unified-first-access-password') : $('#unified-first-access-name'))?.focus(), 0);
}

$('#login-first-access-open')?.addEventListener('click', () => openUnifiedFirstAccess('INITIAL_SETUP'));
$('#unified-first-access-back')?.addEventListener('click', () => { $('#unified-first-access-view').classList.add('hidden'); showLogin(); });
$('#unified-first-access-name')?.addEventListener('input', () => {
  $('#unified-first-access-username').value = technicalUsernameFromNameC2($('#unified-first-access-name').value);
});
$('#unified-first-access-form')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const errorNode = $('#unified-first-access-error');
  errorNode.textContent = '';
  const password = $('#unified-first-access-password').value;
  const confirmPassword = $('#unified-first-access-confirm').value;
  if (password !== confirmPassword) { errorNode.textContent = 'Las contraseñas no coinciden.'; return; }
  const mode = form.dataset.mode || 'INITIAL_SETUP';
  const payload = {
    identifier: $('#unified-first-access-identifier').value.trim(),
    documentType: mode === 'PASSWORD_RESET' ? undefined : $('#unified-first-access-document-type').value.trim(),
    fullName: $('#unified-first-access-name').value.trim(),
    username: $('#unified-first-access-username').value.trim(),
    password,
    confirmPassword
  };
  try {
    const endpoint = mode === 'PASSWORD_RESET' ? '/api/v1/auth/password-reset' : '/api/v1/auth/first-access';
    const result = await api(endpoint, { method: 'POST', body: JSON.stringify(payload) });
    $('#unified-first-access-view').classList.add('hidden');
    showLogin();
    $('#login-username').value = result.username || payload.username;
    $('#login-password').value = '';
    $('#login-error').textContent = mode === 'PASSWORD_RESET' ? 'Contraseña actualizada. Ingresá con tu usuario.' : 'Acceso creado. Ingresá con tu usuario y contraseña.';
    $('#login-password').focus();
  } catch (error) { errorNode.textContent = error.message; }
});

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault(); $('#login-error').textContent = '';
  try {
    const data = await api('/api/v1/auth/login', { method: 'POST', body: JSON.stringify({ username: $('#login-username').value, password: $('#login-password').value, remember: $('#login-remember').checked }) });
    state.user = data.user; state.csrfToken = data.csrfToken; sessionStorage.setItem('iwc_csrf', state.csrfToken); rememberSessionHint(data.expiresAt);
    await reportLoginMobileValidation('AUTHENTICATED');
    $('#login-password').value = ''; showApp(); enterServerExperience();
  } catch (error) {
    if (error?.code === 'PASSWORD_RESET_REQUIRED') {
      await openUnifiedFirstAccess('PASSWORD_RESET', $('#login-username').value.trim());
      return;
    }
    $('#login-error').textContent = error?.code === 'FIRST_ACCESS_REQUIRED' ? 'Tu acceso todavía no está configurado. Elegí CREAR MI ACCESO.' : error.message;
  }
});

$('#logout-button').addEventListener('click', async () => {
  try { await api('/api/v1/auth/logout', { method: 'POST', body: '{}' }); } finally { clearSessionHint(); showLogin(); }
});
function currentUserUsesSimpleOperationalCredential() {
  const roleCodes = (state.user?.roleCodes || []).map((code) => String(code || '').toUpperCase());
  return roleCodes.length > 0 && roleCodes.every((code) => ['SOLICITANTE', 'PANOLERO'].includes(code));
}
function configureCredentialDialog() {
  const simple = true;
  const min = 4;
  const max = 8;
  const newInput = $('#password-new');
  const confirmInput = $('#password-confirm');
  [newInput, confirmInput].forEach((input) => {
    input.minLength = min;
    input.maxLength = max;
    input.pattern = `[A-Za-z0-9]{${min},${max}}`;
  });
  $('#password-dialog-title').textContent = 'Cambiar contraseña';
  $('#password-current-label').firstChild.textContent = 'Contraseña actual';
  $('#password-new-label').firstChild.textContent = 'Nueva contraseña';
  $('#password-confirm-label').firstChild.textContent = 'Repetir nueva contraseña';
  $('#password-policy-help').textContent = 'Contraseña: 4 a 8 caracteres. Puede usar letras y números. Sin vencimiento.';
  $('#password-submit-button').textContent = 'Cambiar contraseña';
}
$('#change-password-button').addEventListener('click', () => {
  $('#password-form').reset();
  configureCredentialDialog();
  $('#password-dialog').showModal();
});
$('#nav').addEventListener('click', (event) => {
  const moreOptions = event.target.closest('#warehouse-more-options');
  if (moreOptions && !moreOptions.hidden) {
    const expanded = document.body.classList.toggle('warehouse-operator-more');
    const label = moreOptions.querySelector('.nav-label');
    if (label) label.textContent = expanded ? 'Menos opciones' : 'Más opciones';
    if (!expanded) $$('.nav-group').forEach((group) => setNavigationGroupOpen(group, false));
    return;
  }
  const groupToggle = event.target.closest('[data-nav-group-toggle]');
  if (groupToggle) {
    const group = groupToggle.closest('.nav-group');
    setNavigationGroupOpen(group, !group.classList.contains('open'), { exclusive: true });
    return;
  }
  const button = event.target.closest('[data-view]');
  if (!button || button.hidden) return;
  clearDashboardFilter(button.dataset.view);
  setView(button.dataset.view);
  $('#sidebar').classList.remove('open');
  $('#mobile-nav-toggle').setAttribute('aria-expanded', 'false');
});
$('#mobile-nav-toggle').addEventListener('click', () => {
  const open = $('#sidebar').classList.toggle('open');
  $('#mobile-nav-toggle').setAttribute('aria-expanded', String(open));
});
$$('.dashboard-jump').forEach((button) => button.addEventListener('click', () => { clearDashboardFilter(button.dataset.jumpView); setView(button.dataset.jumpView); }));
$('#dashboard-refresh').addEventListener('click', () => loadDashboard().catch((error) => flash(error.message, 'error')));
$('#view-dashboard').addEventListener('click', (event) => {
  const button = event.target.closest('[data-dashboard-open]');
  if (!button) return;
  let filter = {};
  try { filter = JSON.parse(button.dataset.dashboardFilter || '{}'); } catch {}
  openDashboardTarget(button.dataset.dashboardOpen, filter, button.dataset.dashboardLabel || 'Filtro seleccionado');
});
document.addEventListener('click', (event) => { const button = event.target.closest('[data-clear-dashboard-filter]'); if (!button) return; clearDashboardFilter(button.dataset.clearDashboardFilter); setView(button.dataset.clearDashboardFilter); });
document.addEventListener('click', (event) => {
  const close = event.target.closest('.supervisor-review-close');
  if (close) {
    const notice = close.closest('#supervisor-review-popout');
    if (notice) {
      try { sessionStorage.setItem('iwcSupervisorReviewDismissed', notice.dataset.signature || ''); } catch {}
      notice.classList.add('hidden');
    }
    return;
  }
  const pill = event.target.closest('#supervisor-review-pill');
  if (pill) {
    const notice = $('#supervisor-review-popout');
    if (notice) notice.classList.remove('hidden');
    return;
  }
  const review = event.target.closest('[data-supervisor-review-custody]');
  if (!review) return;
  try { sessionStorage.setItem('iwcSupervisorReviewDismissed', $('#supervisor-review-popout')?.dataset.signature || ''); } catch {}
  $('#supervisor-review-popout')?.classList.add('hidden');
  const search = review.dataset.supervisorReviewSearch || '';
  openDashboardTarget('custodies', { search }, `Revisión ${search || 'vehículo'}`);
});
document.addEventListener('change', (event) => { const toolbar = event.target.closest('.view.active .toolbar'); if (toolbar && state.currentView !== 'dashboard') clearDashboardFilter(state.currentView); });

document.addEventListener('visibilitychange', () => {
  if (document.hidden) return;
  if (state.currentView === 'workbench') loadWarehouseWorkbench({ silent: true }).catch(() => {});
  if (state.currentView === 'dashboard') loadDashboard({ silent: true }).catch(() => {});
  if (state.currentView === 'requests') refreshRequestsBackground().catch(() => {});
});
$$('.dialog-close').forEach((button) => button.addEventListener('click', () => button.closest('dialog').close()));
$('#ui-interaction-cancel').addEventListener('click', () => closeInteraction({ confirmed: false, values: {} }));
$('#ui-interaction-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  closeInteraction({ confirmed: true, values });
});
$('#ui-interaction-dialog').addEventListener('close', () => {
  // Un cierre programático puede despachar su evento después de abrir la siguiente interacción.
  // En ese caso el diálogo ya está abierto y el evento no pertenece al resolver vigente.
  if (interactionResolver && !$('#ui-interaction-dialog').open) closeInteraction({ confirmed: false, values: {} });
});

$('#password-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if ($('#password-new').value !== $('#password-confirm').value) return flash('Las contraseñas nuevas no coinciden.', 'error');
  if (!event.currentTarget.reportValidity()) return;
  try {
    await api('/api/v1/auth/change-password', { method: 'POST', body: JSON.stringify({ currentPassword: $('#password-current').value, newPassword: $('#password-new').value }) });
    $('#password-dialog').close(); $('#password-form').reset();
    const me = await api('/api/v1/auth/me'); state.user = me.user; showApp(); flash('Contraseña actualizada.');
  } catch (error) { flash(error.message, 'error'); }
});

// CV1 — acción de sesión duplicada en el pie de navegación para mantener la misma
// posición operativa entre Pañolero y Centro de Control. La autoridad sigue siendo
// el handler de logout existente; este control sólo delega el click.
document.querySelectorAll('[data-cv-action="logout"]').forEach((button) => {
  if (button.dataset.cvBound === '1') return;
  button.dataset.cvBound = '1';
  button.addEventListener('click', () => document.querySelector('#logout-button')?.click());
});
