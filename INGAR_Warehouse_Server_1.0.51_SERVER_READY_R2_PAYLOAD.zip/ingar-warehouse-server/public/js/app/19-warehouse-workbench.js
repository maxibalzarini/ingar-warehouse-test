'use strict';

let warehouseWorkbenchTimer = null;
let warehouseWorkbenchLoading = false;
let warehouseWorkbenchRefreshPromise = null;
const WAREHOUSE_WORKBENCH_REFRESH_MS = 5_000;
let warehouseLoanedFilter = 'ALL';

function workbenchText(value) { return String(value ?? '').trim(); }

function workbenchCustodyKind(custody) {
  const nature = String(custody?.category_nature || '').toUpperCase();
  if (nature === 'VEHICULO') return { code: 'VEHICULO', label: 'Vehículo' };
  if (nature === 'SERIADO') return { code: 'SERIADO', label: 'Bien serializado' };
  if (nature === 'KIT') return { code: 'KIT', label: 'Kit' };
  if (nature === 'CONSUMIBLE') return { code: 'CONSUMIBLE', label: 'Consumible' };
  return { code: 'HERRAMIENTA', label: 'Herramienta' };
}

function workbenchItemsText(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (!items.length) return 'Sin detalle de bienes';
  const first = items.slice(0, 2).map((item) => `${item.description || item.internal_code}${Number(item.quantity || 1) > 1 ? ` × ${item.quantity}` : ''}`);
  return `${first.join(' · ')}${items.length > 2 ? ` · +${items.length - 2}` : ''}`;
}


function workbenchTaskUnitCount(task) {
  // Cada task representa una operación/pedido: la cola cuenta pedidos, no bienes.
  return task ? 1 : 0;
}

function workbenchRequestGoodsCount(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  return items.reduce((sum, item) => {
    const quantity = Number(item?.quantity || 1);
    return sum + (Number.isFinite(quantity) && quantity > 0 ? quantity : 1);
  }, 0);
}

function workbenchLaneUnitCount(tasks = []) {
  return (tasks || []).reduce((sum, task) => sum + workbenchTaskUnitCount(task), 0);
}

function workbenchDateSort(value) {
  const time = value ? new Date(value).getTime() : Number.MAX_SAFE_INTEGER;
  return Number.isFinite(time) ? time : Number.MAX_SAFE_INTEGER;
}

function workbenchIsReturnProblem(custody) {
  const declaration = custody?.returnDeclaration;
  return Boolean(custody?.status === 'INCIDENTE' || (declaration && (Number(declaration.problem_reported || 0) === 1 || String(declaration.condition || '').toUpperCase() !== 'CONFORME')));
}

function workbenchActionLabel(task) {
  if (task.action === 'quick-handover' || task.action === 'serialized-handover') return 'ENTREGAR';
  if (task.action === 'vehicle-handover') return 'ENTREGAR VEHÍCULO';
  if (task.action === 'view-request') return 'VER PEDIDO';
  if (task.action === 'approve') return 'APROBAR';
  if (task.action === 'prepare') return 'PREPARAR';
  if (task.action === 'ready') return 'MARCAR LISTO';
  if (task.action === 'handover') return 'ENTREGAR';
  if (task.action === 'quick-receive') return 'REVISAR DEVOLUCIÓN';
  if (task.action === 'serialized-quick-receive') return 'REVISAR DEVOLUCIÓN';
  if (task.action === 'vehicle-supervisor-inspect') return 'INSPECCIONAR VEHÍCULO';
  if (task.action === 'vehicle-receive') return 'RECIBIR LLAVES';
  if (task.action === 'kit-receive') return 'REVISAR DEVOLUCIÓN';
  if (task.action === 'review-custody') return 'REVISAR PROBLEMA';
  if (task.action === 'receive') return 'REVISAR DEVOLUCIÓN';
  if (task.action === 'incident-detail') return 'VER PROBLEMA';
  return 'ABRIR';
}

function workbenchTaskSearchText(task) {
  if (task.entity === 'request') return [task.request.request_number, task.request.requester_name, task.request.reason, task.request.location_name, ...(task.request.items || []).flatMap((item) => [item.internal_code, item.description])].join(' ').toLowerCase();
  if (task.entity === 'custody') return [task.custody.request_number, task.custody.custodian_name, task.custody.internal_code, task.custody.description, task.custody.location_name, task.custody.returnDeclaration?.notes].join(' ').toLowerCase();
  return [task.incident.incident_number, task.incident.title, task.incident.internal_code, task.incident.asset_description].join(' ').toLowerCase();
}

function workbenchCardHtml(task) {
  let title = '', subtitle = '', detail = '', reason = '', id = '';
  if (task.entity === 'request') {
    const r = task.request; id = r.id;
    title = r.requester_name || 'Solicitante';
    subtitle = workbenchItemsText(r);
    const goodsCount = workbenchRequestGoodsCount(r);
    detail = `${r.request_number} · ${r.location_name || 'Sin ubicación'} · ${formatDateTime(r.needed_at)} · ${goodsCount} bien${goodsCount === 1 ? '' : 'es'}`;
    reason = r.reason || '';
  } else if (task.entity === 'custody') {
    const c = task.custody; id = c.id;
    title = c.custodian_name || c.person_name || 'Usuario';
    subtitle = `${c.internal_code} · ${c.description}`;
    detail = `${c.request_number || 'Custodia'} · ${c.location_name || 'Sin ubicación'}${c.due_at ? ` · ${formatDateTime(c.due_at)}` : ''}`;
    reason = c.returnDeclaration?.notes || (c.status === 'INCIDENTE' ? 'La devolución requiere revisión.' : '');
  } else {
    const i = task.incident; id = i.id;
    title = i.title || 'Incidente';
    subtitle = `${i.internal_code || ''}${i.asset_description ? ` · ${i.asset_description}` : ''}`;
    detail = `${i.incident_number || 'Incidente'} · ${String(i.severity || '').replaceAll('_', ' ')}`;
    reason = i.status === 'EN_INVESTIGACION' ? 'Investigación en curso.' : 'Requiere atención.';
  }
  const due = task.dueAt ? new Date(task.dueAt) : null;
  const declaredReturnPending = task.entity === 'custody' && String(task.custody?.status || '').toUpperCase() === 'DEVOLUCION_DECLARADA';
  const overdue = task.entity !== 'incident' && !declaredReturnPending && due && Number.isFinite(due.getTime()) && due.getTime() < Date.now();
  const returnProblem = task.entity === 'custody' && task.custody?.status === 'DEVOLUCION_DECLARADA' && workbenchIsReturnProblem(task.custody);
  const pendingApproval = task.entity === 'request' && task.action === 'approve';
  const scheduledRequest = task.entity === 'request' && task.request?.needed_at && new Date(task.request.needed_at).getTime() > Date.now();
  const requestUnits = task.entity === 'request' ? workbenchRequestGoodsCount(task.request) : 0;
  return `<article class="warehouse-workbench-task ${task.entity === 'incident' || (workbenchIsReturnProblem(task.custody) && !returnProblem) ? 'is-problem' : ''} ${returnProblem ? 'has-warning' : ''}" data-search="${escapeHtml(workbenchTaskSearchText(task))}">
    <div class="warehouse-workbench-task-head"><span class="warehouse-workbench-kind" data-kind="${escapeHtml(task.kind.code)}">${escapeHtml(task.kind.label)}</span>${task.entity === 'request' && requestUnits > 1 ? `<span class="warehouse-workbench-attention">${requestUnits} BIENES</span>` : ''}${scheduledRequest ? '<span class="warehouse-workbench-attention is-scheduled">PROGRAMADO</span>' : ''}${pendingApproval ? '<span class="warehouse-workbench-attention">POR AUTORIZAR</span>' : ''}${returnProblem ? '<span class="warehouse-workbench-attention is-danger">CON PROBLEMA</span>' : ''}${overdue ? '<span class="warehouse-workbench-overdue">ATRASADO</span>' : ''}</div>
    <h4>${escapeHtml(title)}</h4>
    <p class="warehouse-workbench-item">${escapeHtml(subtitle)}</p>
    <p class="warehouse-workbench-meta">${escapeHtml(detail)}</p>
    ${reason ? `<p class="warehouse-workbench-reason">${escapeHtml(reason)}</p>` : ''}
    <div class="warehouse-workbench-actions"><button type="button" class="primary warehouse-workbench-primary" data-workbench-action="${escapeHtml(task.action)}" data-workbench-entity="${escapeHtml(task.entity)}" data-id="${escapeHtml(id)}">${escapeHtml(workbenchActionLabel(task))}</button><button type="button" class="warehouse-workbench-detail" data-workbench-detail="${escapeHtml(task.entity)}" data-id="${escapeHtml(id)}">Detalle</button></div>
  </article>`;
}

function workbenchLoanedSearchText(item) {
  return [item.kind?.label, item.internalCode, item.description, item.serialNumber, item.licensePlate, item.custodianName, item.custodianDocument, item.requestNumber, item.locationName, item.state?.label]
    .join(' ').toLowerCase();
}

function workbenchLoanedMatchesFilter(item) {
  if (warehouseLoanedFilter === 'ALL') return true;
  if (warehouseLoanedFilter === 'SERIALIZADO') return ['SERIADO','KIT'].includes(String(item.kind?.code || '').toUpperCase());
  if (warehouseLoanedFilter === 'DUE_TODAY') return Boolean(item.dueToday);
  return String(item.kind?.code || '').toUpperCase() === warehouseLoanedFilter;
}

function workbenchLoanedAssetTitle(item) {
  const description = workbenchText(item.description) || workbenchText(item.internalCode) || 'Bien';
  if (item.kind?.code === 'VEHICULO' && item.licensePlate) return `${description} (${item.licensePlate})`;
  return description;
}

function workbenchLoanedAssetMeta(item) {
  const parts = [];
  if (item.internalCode) parts.push(`Código: ${item.internalCode}`);
  if (item.licensePlate) parts.push(`Patente: ${item.licensePlate}`);
  if (item.serialNumber) parts.push(`Serie: ${item.serialNumber}`);
  if (Number(item.quantity || 1) > 1) parts.push(`Cantidad: ${item.quantity}`);
  return parts.join(' · ');
}

function workbenchLoanedRowHtml(item) {
  const stateCode = String(item.state?.code || 'EN_USO').toLowerCase().replaceAll('_','-');
  const dueText = item.dueAt ? formatDateTime(item.dueAt) : 'Sin fecha prevista';
  const dueNote = item.overdue ? 'atrasado' : item.dueToday ? 'hoy' : '';
  return `<tr data-loaned-search="${escapeHtml(workbenchLoanedSearchText(item))}">
    <td><span class="warehouse-loaned-kind" data-kind="${escapeHtml(item.kind?.code || '')}">${escapeHtml(item.kind?.label || 'Bien')}</span></td>
    <td><strong>${escapeHtml(workbenchLoanedAssetTitle(item))}</strong>${workbenchLoanedAssetMeta(item) ? `<small>${escapeHtml(workbenchLoanedAssetMeta(item))}</small>` : ''}</td>
    <td><strong>${escapeHtml(item.custodianName || 'Sin responsable')}</strong><small>${escapeHtml(item.locationName || item.requestNumber || '')}</small></td>
    <td><strong>${escapeHtml(item.openedAt ? formatDateTime(item.openedAt) : '—')}</strong>${item.requestNumber ? `<small>${escapeHtml(item.requestNumber)}</small>` : ''}</td>
    <td><strong>${escapeHtml(dueText)}</strong>${dueNote ? `<small class="${item.overdue ? 'is-overdue' : ''}">${escapeHtml(dueNote)}</small>` : ''}</td>
    <td><span class="warehouse-loaned-state ${escapeHtml(stateCode)}">${escapeHtml(item.state?.label || 'En uso')}</span>${item.hasReturnProblem ? `<small class="is-overdue">⚠ CON PROBLEMA${item.returnProblemNotes ? ` · ${escapeHtml(item.returnProblemNotes)}` : ''}</small>` : ''}</td>
    <td><button type="button" class="warehouse-loaned-detail" data-workbench-outside-detail="${escapeHtml(item.custodyId || item.id)}">Detalle</button></td>
  </tr>`;
}

function renderWarehouseLoanedNow() {
  const loaned = state.workbench.loanedNow || { summary: {}, items: [], total: 0 };
  const summary = loaned.summary || {};
  const totalNode = $('#workbench-loaned-total'); if (totalNode) totalNode.textContent = String(loaned.total ?? summary.totalOut ?? 0);
  const values = {
    '#workbench-loaned-vehicles': summary.vehiclesOut || 0,
    '#workbench-loaned-tools': summary.toolsLoaned || 0,
    '#workbench-loaned-serialized': summary.serializedOut || 0,
    '#workbench-loaned-due-today': summary.dueToday || 0
  };
  for (const [selector, value] of Object.entries(values)) { const target = $(selector); if (target) target.textContent = value; }

  const vehicleAlert = $('#workbench-vehicle-alert');
  if (vehicleAlert) {
    const count = Number(summary.vehiclesOut || 0);
    vehicleAlert.classList.toggle('has-vehicle', count > 0);
    vehicleAlert.classList.toggle('is-clear', count === 0);
    const text = vehicleAlert.querySelector('span');
    if (text) text.textContent = count ? `${count} ${count === 1 ? 'vehículo fuera ahora' : 'vehículos fuera ahora'}` : 'Sin vehículos fuera';
  }

  $$('#workbench-loaned-summary [data-loaned-kind]').forEach((button) => button.classList.toggle('active', button.dataset.loanedKind === warehouseLoanedFilter));
  const globalQuery = workbenchText($('#workbench-search')?.value).toLowerCase();
  const localQuery = workbenchText($('#workbench-loaned-search')?.value).toLowerCase();
  const items = (loaned.items || []).filter(workbenchLoanedMatchesFilter).filter((item) => {
    const text = workbenchLoanedSearchText(item);
    return (!globalQuery || text.includes(globalQuery)) && (!localQuery || text.includes(localQuery));
  });
  const body = $('#workbench-loaned-body');
  if (body) body.innerHTML = items.length ? items.map(workbenchLoanedRowHtml).join('') : `<tr><td colspan="7" class="warehouse-loaned-empty">${(globalQuery || localQuery || warehouseLoanedFilter !== 'ALL') ? 'No hay activos que coincidan con el filtro.' : 'No hay activos actualmente fuera del pañol.'}</td></tr>`;
  const foot = $('#workbench-loaned-foot-text');
  if (foot) foot.textContent = `${loaned.total || 0} ${(loaned.total || 0) === 1 ? 'activo fuera' : 'activos fuera'} del pañol${items.length !== (loaned.total || 0) ? ` · mostrando ${items.length}` : ''}`;
  const overdue = $('#workbench-loaned-overdue');
  if (overdue) {
    const count = Number(summary.overdue || 0);
    overdue.classList.toggle('hidden', count === 0);
    overdue.textContent = count ? `${count} ${count === 1 ? 'devolución atrasada' : 'devoluciones atrasadas'}` : '';
  }
}


function c3WorkbenchLine(title, detail, timeText = '') {
  return `<div class="c3-insight-row"><span class="c3-insight-dot"></span><div><strong>${escapeHtml(title)}</strong><small>${escapeHtml(detail || '')}</small></div><time>${escapeHtml(timeText || '')}</time></div>`;
}
function renderC3WorkbenchInsights() {
  const allTasks = ['prepare','deliver','receive','problems'].flatMap((lane) => (state.workbench.lanes[lane] || []).map((task) => ({...task,lane})));
  const endToday = new Date(); endToday.setHours(23,59,59,999);
  const urgent = allTasks.filter((task) => {
    if (task.entity === 'incident') return true;
    const due = task.dueAt ? new Date(task.dueAt) : null;
    return due && Number.isFinite(due.getTime()) && due <= endToday;
  }).sort((a,b) => workbenchDateSort(a.dueAt)-workbenchDateSort(b.dueAt)).slice(0,5);
  const urgentNode = $('#c3-workbench-urgent');
  if (urgentNode) urgentNode.innerHTML = urgent.length ? urgent.map((task) => {
    if (task.entity === 'request') return c3WorkbenchLine(`${task.request.request_number} · ${task.request.requester_name || 'Solicitante'}`, workbenchItemsText(task.request), task.dueAt ? formatDateTime(task.dueAt) : '');
    if (task.entity === 'custody') return c3WorkbenchLine(`${task.custody.internal_code} · ${task.custody.custodian_name || task.custody.person_name || 'Usuario'}`, task.custody.description || 'Devolución', task.dueAt ? formatDateTime(task.dueAt) : '');
    return c3WorkbenchLine(task.incident.incident_number || 'Incidencia', task.incident.title || task.incident.asset_description || '', task.dueAt ? formatDateTime(task.dueAt) : '');
  }).join('') : '<p class="c3-empty">No hay tareas urgentes registradas.</p>';

  const critical = state.workbench.criticalStock || {items:[],total:null};
  const criticalNode = $('#c3-critical-stock');
  const criticalCount = $('#c3-critical-stock-count');
  if (criticalCount) criticalCount.textContent = critical.total === null || critical.total === undefined ? '—' : String(critical.total);
  if (criticalNode) criticalNode.innerHTML = critical.items?.length ? critical.items.map((item) => c3WorkbenchLine(item.description || item.internal_code, `${item.internal_code || ''}${item.location_name ? ` · ${item.location_name}` : ''}`, `${Number(item.quantity_on_hand || 0)-Number(item.quantity_reserved || 0)} ${item.unit_of_measure || ''}`)).join('') : '<p class="c3-empty">Sin stock crítico dentro del alcance.</p>';

  const todayRows = (state.workbench.loanedNow?.items || []).filter((item) => item.dueToday).slice(0,6);
  const todayNode = $('#c3-today-returns'); const todayCount = $('#c3-today-returns-count');
  if (todayCount) todayCount.textContent = String(state.workbench.loanedNow?.summary?.dueToday ?? 0);
  if (todayNode) todayNode.innerHTML = todayRows.length ? todayRows.map((item) => c3WorkbenchLine(item.internalCode || item.description || 'Bien', `${item.custodianName || 'Sin responsable'} · ${item.description || ''}`, item.dueAt ? new Date(item.dueAt).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'}) : '')).join('') : '<p class="c3-empty">No hay devoluciones previstas para hoy.</p>';
}

function renderWarehouseWorkbench() {
  const query = workbenchText($('#workbench-search')?.value).toLowerCase();
  const scheduledAll = state.workbench.lanes.scheduled || [];
  const scheduledItems = query ? scheduledAll.filter((task) => workbenchTaskSearchText(task).includes(query)) : scheduledAll;
  const scheduledCount = $('#workbench-lane-count-scheduled'); if (scheduledCount) scheduledCount.textContent = scheduledAll.length;
  const scheduledTarget = $('#workbench-list-scheduled'); if (scheduledTarget) scheduledTarget.innerHTML = scheduledItems.length ? scheduledItems.map(workbenchCardHtml).join('') : `<div class="warehouse-workbench-empty">${query ? 'No hay resultados para esta búsqueda.' : 'No hay pedidos programados.'}</div>`;
  $('#workbench-scheduled-block')?.classList.toggle('hidden', scheduledAll.length === 0 && !query);
  for (const lane of ['prepare', 'deliver', 'receive', 'problems']) {
    const all = state.workbench.lanes[lane] || [];
    const items = query ? all.filter((task) => workbenchTaskSearchText(task).includes(query)) : all;
    const units = workbenchLaneUnitCount(all);
    $(`#workbench-lane-${lane}`)?.classList.remove('hidden');
    $(`#workbench-count-${lane}`).textContent = units;
    $(`#workbench-lane-count-${lane}`).textContent = units;
    const summaryHint = document.querySelector(`#workbench-summary [data-workbench-lane="${lane}"] .cv-summary-copy em`);
    if (summaryHint) summaryHint.textContent = units ? (lane === 'receive' ? 'Ver devoluciones →' : lane === 'problems' ? 'Ver detalles →' : 'Ver pedidos →') : (lane === 'prepare' ? 'No hay nada para preparar.' : lane === 'deliver' ? 'No hay nada para entregar.' : lane === 'receive' ? 'No hay nada para recibir.' : 'No hay problemas abiertos.');
    const target = $(`#workbench-list-${lane}`);
    target.innerHTML = items.length ? items.map(workbenchCardHtml).join('') : `<div class="warehouse-workbench-empty">${query ? 'No hay resultados para esta búsqueda.' : lane === 'prepare' ? 'No hay nada para preparar.' : lane === 'deliver' ? 'No hay nada para entregar.' : lane === 'receive' ? 'No hay nada para recibir.' : 'No hay problemas abiertos.'}</div>`;
  }
  const grid = $('#view-workbench .warehouse-workbench-grid');
  let empty = $('#workbench-empty');
  if (!empty && grid) {
    empty = document.createElement('div');
    empty.id = 'workbench-empty';
    empty.className = 'card warehouse-workbench-empty';
    empty.setAttribute('role', 'status');
    empty.textContent = 'No hay tareas pendientes';
    grid.appendChild(empty);
  }
  const visibleLanes = ['prepare', 'deliver', 'receive', 'problems'].filter((lane) => query || (state.workbench.lanes[lane] || []).length);
  empty?.classList.add('hidden');
  grid?.classList.toggle('workbench-single-lane', visibleLanes.length <= 1);
  renderWarehouseLoanedNow();
  renderC3WorkbenchInsights();
}

function hydrateWorkbenchLanes(rawLanes = {}) {
  const requestMap = new Map((state.workbench.requests || []).map((item) => [item.id, item]));
  const custodyMap = new Map((state.workbench.custodies || []).map((item) => [item.id, item]));
  const incidentMap = new Map((state.workbench.incidents || []).map((item) => [item.id, item]));
  const output = { scheduled: [], prepare: [], deliver: [], receive: [], problems: [] };
  for (const lane of Object.keys(output)) {
    output[lane] = (rawLanes[lane] || []).map((item) => {
      const hydrated = { ...item };
      if (item.entity === 'request') hydrated.request = requestMap.get(item.id);
      else if (item.entity === 'custody') hydrated.custody = custodyMap.get(item.id);
      else if (item.entity === 'incident') hydrated.incident = incidentMap.get(item.id);
      return hydrated;
    }).filter((item) => item.request || item.custody || item.incident);
  }
  return output;
}

function applyWarehouseWorkbenchFeed(feed) {
  state.workbench.requests = Array.isArray(feed?.requests) ? feed.requests : [];
  state.workbench.custodies = Array.isArray(feed?.custodies) ? feed.custodies : [];
  state.workbench.incidents = Array.isArray(feed?.incidents) ? feed.incidents : [];
  state.workbench.lanes = hydrateWorkbenchLanes(feed?.lanes || {});
  state.workbench.loanedNow = feed?.loanedNow && typeof feed.loanedNow === 'object' ? feed.loanedNow : { summary: { vehiclesOut: 0, toolsLoaned: 0, serializedOut: 0, dueToday: 0, overdue: 0, totalOut: 0 }, items: [], total: 0, timeZone: null };
  state.workbench.criticalStock = feed?.criticalStock && typeof feed.criticalStock === 'object' ? feed.criticalStock : { items: [], total: null };
  state.workbench.loaded = true;
  state.workbench.error = null;
  state.workbench.generatedAt = feed?.generatedAt || new Date().toISOString();
  $('#workbench-loaned-now')?.classList.remove('is-stale');
}

function showWarehouseWorkbenchFeedError(error) {
  const message = String(error?.message || 'No se pudo actualizar el puesto del pañolero.');
  state.workbench.error = message;
  const updated = $('#workbench-updated');
  if (updated) updated.textContent = `ERROR DE ACTUALIZACIÓN · ${message}`;
  const liveUpdated = $('#workbench-updated');
  if (liveUpdated) { liveUpdated.classList.remove('c4-live'); liveUpdated.classList.add('c4-stale'); liveUpdated.textContent = 'Actualización interrumpida · conservando último estado real.'; }
  const adminUpdated = $('#admin-ops-updated');
  if (adminUpdated) adminUpdated.textContent = `ERROR DE ACTUALIZACIÓN · ${message}`;
  $('#workbench-loaned-now')?.classList.add('is-stale');
  if (state.workbench.loaded) return;
  for (const selector of ['#workbench-loaned-vehicles','#workbench-loaned-tools','#workbench-loaned-serialized','#workbench-loaned-due-today']) { const target = $(selector); if (target) target.textContent = '—'; }
  const vehicleAlert = $('#workbench-vehicle-alert'); if (vehicleAlert) { vehicleAlert.className = 'warehouse-loaned-alert is-error'; const text = vehicleAlert.querySelector('span'); if (text) text.textContent = 'No se pudo actualizar'; }
  const loanedBody = $('#workbench-loaned-body'); if (loanedBody) loanedBody.innerHTML = '<tr><td colspan="7" class="warehouse-loaned-empty">No se pudo obtener el estado de los activos fuera del pañol. Use Actualizar o revise la conexión.</td></tr>';
  const loanedFoot = $('#workbench-loaned-foot-text'); if (loanedFoot) loanedFoot.textContent = 'Estado no disponible';
  for (const lane of ['scheduled','prepare','deliver','receive','problems']) {
    const count = $(`#workbench-count-${lane}`); if (count) count.textContent = '—';
    const laneCount = $(`#workbench-lane-count-${lane}`); if (laneCount) laneCount.textContent = '—';
    const list = $(`#workbench-list-${lane}`); if (list) list.innerHTML = '<div class="warehouse-workbench-empty">No se pudo obtener la cola operativa. Use Actualizar o revise la conexión.</div>';
    const adminCount = $(`#admin-ops-count-${lane}`); if (adminCount) adminCount.textContent = '—';
    const adminLaneCount = $(`#admin-ops-lane-count-${lane}`); if (adminLaneCount) adminLaneCount.textContent = '—';
  }
}

async function refreshWarehouseWorkbenchFeed({ silent = false } = {}) {
  if (!state.user || !can('Warehouse.Operate')) return null;
  if (warehouseWorkbenchRefreshPromise) return warehouseWorkbenchRefreshPromise;
  warehouseWorkbenchRefreshPromise = (async () => {
    try {
      const feed = await api('/api/v1/dashboard/warehouse-workbench');
      applyWarehouseWorkbenchFeed(feed);
      renderWarehouseWorkbench();
      if (typeof renderAdminWarehouseOperations === 'function' && typeof isAdminGeneralWarehouseControl === 'function' && isAdminGeneralWarehouseControl()) renderAdminWarehouseOperations();
      return feed;
    } catch (error) {
      showWarehouseWorkbenchFeedError(error);
      if (!silent) throw error;
      return null;
    } finally {
      warehouseWorkbenchRefreshPromise = null;
    }
  })();
  return warehouseWorkbenchRefreshPromise;
}

async function loadWarehouseWorkbench({ silent = false } = {}) {
  if (!state.user || !can('Warehouse.Operate') || warehouseWorkbenchLoading) return;
  warehouseWorkbenchLoading = true;
  $('#workbench-refresh')?.classList.add('is-busy');
  $('#workbench-loaned-refresh')?.classList.add('is-busy');
  try {
    const feed = await refreshWarehouseWorkbenchFeed({ silent });
    if (!feed) return;
    const total = Object.values(state.workbench.lanes).reduce((sum, rows) => sum + rows.length, 0);
    const outside = Number(state.workbench.loanedNow?.total || 0);
    const updated = $('#workbench-updated');
    const when = new Date(feed.generatedAt || Date.now()).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
    if (updated) { updated.textContent = `${total ? `${total} tareas visibles` : 'Sin tareas pendientes'} · ${outside} ${outside === 1 ? 'activo fuera' : 'activos fuera'} · actualizado ${when}${feed.truncated ? ' · VISTA PARCIAL' : ''}`; updated.classList.add('c4-live'); updated.classList.remove('c4-stale'); }
  } finally {
    warehouseWorkbenchLoading = false;
    $('#workbench-refresh')?.classList.remove('is-busy');
    $('#workbench-loaned-refresh')?.classList.remove('is-busy');
  }
}

async function refreshWarehouseOperationalViews({ silent = true } = {}) {
  return refreshWarehouseWorkbenchFeed({ silent });
}

function startWarehouseWorkbenchAutoRefresh() {
  stopWarehouseWorkbenchAutoRefresh();
  if (!state.user || !can('Warehouse.Operate')) return;
  warehouseWorkbenchTimer = setInterval(() => {
    if (state.currentView === 'workbench' && !document.hidden && !$('dialog[open]')) loadWarehouseWorkbench({ silent: true }).catch(() => {});
  }, WAREHOUSE_WORKBENCH_REFRESH_MS);
}

function stopWarehouseWorkbenchAutoRefresh() {
  if (warehouseWorkbenchTimer) clearInterval(warehouseWorkbenchTimer);
  warehouseWorkbenchTimer = null;
}

function workbenchRequestById(id) { return (state.workbench.requests || []).find((item) => item.id === id); }
function workbenchCustodyById(id) { return (state.workbench.custodies || []).find((item) => item.id === id); }
function workbenchIncidentById(id) { return (state.workbench.incidents || []).find((item) => item.id === id); }

async function workbenchVehicleHandover(request) {
  const detail = (await api(`/api/v1/requests/${request.id}/vehicle-detail`)).vehicleDetail;
  const values = await askFields('Entregar vehículo', [
    { name: 'odometer', label: 'Kilometraje', type: 'number', value: detail.departure_odometer },
    { name: 'fuelLevelPercent', label: 'Combustible', type: 'select', value: String(detail.departure_fuel_percent), options: [{ value: '100', label: 'Lleno' }, { value: '75', label: '3/4' }, { value: '50', label: '1/2' }, { value: '25', label: '1/4' }, { value: '10', label: 'Reserva' }] },
    { name: 'notes', label: 'Observación', type: 'textarea', required: false, value: detail.departure_notes || '' }
  ], { confirmText: 'ENTREGAR VEHÍCULO', details: `Conductor: ${detail.driver_name}\nAcompañante: ${detail.companion_name || 'Sin acompañante'}\nDestino: ${detail.destination}\nExterior: ${detail.departureChecklist?.exterior || '—'} · Neumáticos: ${detail.departureChecklist?.neumaticos || '—'} · Luces: ${detail.departureChecklist?.luces || '—'}\nInterior: ${detail.departureChecklist?.interior || '—'} · Documentación: ${detail.departureChecklist?.documentacion || '—'}` });
  if (!values) return false;
  await requestWorkflowApi(`/api/v1/requests/${request.id}/vehicle-handover`, { method: 'POST', headers: { 'Idempotency-Key': newIdempotencyKey('vehicle-handover') }, body: JSON.stringify({ version: request.version, odometer: Number(values.odometer), fuelLevelPercent: Number(values.fuelLevelPercent), notes: values.notes || null }) });
  flash(`Vehículo entregado a ${request.requester_name}.`);
  return true;
}

async function workbenchVehicleReceive(custody) {
  return receiveVehicleFromWarehouse(custody, workbenchIsReturnProblem(custody));
}

async function workbenchKitReceive(custody) {
  await openKitReceiveDialog(custody, { forceObserved: workbenchIsReturnProblem(custody) });
  return false;
}

async function executeWorkbenchTask(button) {
  const entity = button.dataset.workbenchEntity;
  const action = button.dataset.workbenchAction;
  const id = button.dataset.id;
  button.disabled = true;
  const original = button.textContent;
  button.textContent = 'PROCESANDO…';
  try {
    if (entity === 'request') {
      const request = workbenchRequestById(id); if (!request) throw new Error('El pedido cambió. Actualizá la pantalla.');
      if (action === 'view-request') { renderRequestDetail((await api(`/api/v1/requests/${id}`)).request); return; }
      if (action === 'approve') {
        await requestWorkflowApi(`/api/v1/requests/${id}/approve`, { method: 'POST', body: JSON.stringify({ version: request.version }) });
        flash('Pedido aprobado.');
      } else if (action === 'quick-handover') await requestWorkflowApi(`/api/v1/requests/${id}/quick-handover`, { method: 'POST', headers: { 'Idempotency-Key': newIdempotencyKey('quick-handover') }, body: JSON.stringify({ version: request.version }) });
      else if (action === 'serialized-handover') await requestWorkflowApi(`/api/v1/requests/${id}/serialized-handover`, { method: 'POST', headers: { 'Idempotency-Key': newIdempotencyKey('serialized-handover') }, body: JSON.stringify({ version: request.version }) });
      else if (action === 'vehicle-handover') { if (!(await workbenchVehicleHandover(request))) return; }
      else if (action === 'prepare') { openPreparationDialog(id); return; }
      else if (action === 'ready') {
        const detail = (await api(`/api/v1/requests/${id}`)).request;
        const preparation = detail.preparation || (await api(`/api/v1/requests/${id}/preparation`)).preparation;
        if (!preparation) throw new Error('No existe una preparación abierta.');
        await requestWorkflowApi(`/api/v1/requests/${id}/ready`, { method: 'POST', body: JSON.stringify({ version: detail.version, preparationVersion: preparation.version, reason: 'Preparación física completa y verificada desde el puesto del pañolero.' }) });
      } else if (action === 'handover') { openHandoverDialog(id); return; }
      if (action !== 'approve') flash(action === 'ready' ? 'Pedido listo para entregar.' : 'Entrega registrada.');
    } else if (entity === 'custody') {
      const custody = workbenchCustodyById(id); if (!custody) throw new Error('La devolución cambió. Actualizá la pantalla.');
      if (action === 'quick-receive') { await openWarehouseReceiveAction((await api(`/api/v1/custodies/${id}`)).custody); return; }
      else if (['serialized-quick-receive','vehicle-supervisor-inspect','vehicle-receive','kit-receive'].includes(action)) { renderCustodyDetail((await api(`/api/v1/custodies/${id}`)).custody); return; }
      else if (action === 'review-custody') { renderCustodyDetail((await api(`/api/v1/custodies/${id}`)).custody); return; }
      else if (action === 'receive') { await openWarehouseReceiveAction((await api(`/api/v1/custodies/${id}`)).custody); return; }
    } else if (entity === 'incident') {
      const incident = workbenchIncidentById(id); if (!incident) throw new Error('El problema cambió. Actualizá la pantalla.');
      renderIncidentDetail((await api(`/api/v1/incidents/${id}`)).incident); return;
    }
    await loadWarehouseWorkbench();
  } finally {
    button.disabled = false;
    button.textContent = original;
  }
}

$('#workbench-refresh')?.addEventListener('click', () => loadWarehouseWorkbench().catch((error) => flash(error.message, 'error')));
$('#workbench-loaned-refresh')?.addEventListener('click', () => loadWarehouseWorkbench().catch((error) => flash(error.message, 'error')));
$('#workbench-search')?.addEventListener('input', renderWarehouseWorkbench);
$('#workbench-loaned-search')?.addEventListener('input', renderWarehouseLoanedNow);
$('#workbench-loaned-show-all')?.addEventListener('click', () => {
  warehouseLoanedFilter = 'ALL';
  const search = $('#workbench-loaned-search'); if (search) search.value = '';
  const block = $('#workbench-loaned-table-block');
  const toggle = $('#workbench-loaned-show-all');
  const opening = Boolean(block?.classList.contains('hidden'));
  block?.classList.toggle('hidden', !opening);
  toggle?.setAttribute('aria-expanded', opening ? 'true' : 'false');
  if (toggle) toggle.textContent = opening ? 'Ocultar detalle' : 'Ver detalle';
  renderWarehouseLoanedNow();
  if (opening) block?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
});
$('#workbench-loaned-summary')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-loaned-kind]'); if (!button) return;
  warehouseLoanedFilter = warehouseLoanedFilter === button.dataset.loanedKind ? 'ALL' : button.dataset.loanedKind;
  const block = $('#workbench-loaned-table-block');
  block?.classList.remove('hidden');
  const toggle = $('#workbench-loaned-show-all');
  toggle?.setAttribute('aria-expanded', 'true');
  if (toggle) toggle.textContent = 'Ocultar detalle';
  renderWarehouseLoanedNow();
  block?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
});
$('#workbench-summary')?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-workbench-lane]'); if (!button) return;
  if (!(state.workbench.lanes[button.dataset.workbenchLane] || []).length) return;
  $(`#workbench-lane-${button.dataset.workbenchLane}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
});
$('#view-workbench')?.addEventListener('click', async (event) => {
  const outsideDetail = event.target.closest('[data-workbench-outside-detail]');
  if (outsideDetail) {
    try { return renderCustodyDetail((await api(`/api/v1/custodies/${outsideDetail.dataset.workbenchOutsideDetail}`)).custody); }
    catch (error) { flash(error.message, 'error'); return; }
  }
  const action = event.target.closest('[data-workbench-action]');
  if (action) { try { await executeWorkbenchTask(action); } catch (error) { flash(error.message, 'error'); } return; }
  const detail = event.target.closest('[data-workbench-detail]'); if (!detail) return;
  try {
    if (detail.dataset.workbenchDetail === 'request') return renderRequestDetail((await api(`/api/v1/requests/${detail.dataset.id}`)).request);
    if (detail.dataset.workbenchDetail === 'custody') return renderCustodyDetail((await api(`/api/v1/custodies/${detail.dataset.id}`)).custody);
    if (detail.dataset.workbenchDetail === 'incident') return renderIncidentDetail((await api(`/api/v1/incidents/${detail.dataset.id}`)).incident);
  } catch (error) { flash(error.message, 'error'); }
});

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.currentView === 'workbench') loadWarehouseWorkbench({ silent: true }).catch(() => {});
});

// F7: el puesto se refresca automáticamente mientras el usuario trabaja en esta vista.
const originalShowAppForWorkbench = showApp;
showApp = function showAppWithWorkbench() {
  originalShowAppForWorkbench();
  startWarehouseWorkbenchAutoRefresh();
};
const originalShowLoginForWorkbench = showLogin;
showLogin = function showLoginWithWorkbenchStop() {
  stopWarehouseWorkbenchAutoRefresh();
  originalShowLoginForWorkbench();
};
