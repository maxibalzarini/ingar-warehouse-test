'use strict';

(function initializeUnifiedUi() {
  function visibleText(node) {
    return String(node?.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function inferControlName(control) {
    const explicitLabel = control.closest('label');
    if (explicitLabel) {
      const clone = explicitLabel.cloneNode(true);
      clone.querySelectorAll('input,select,textarea,button,img,svg').forEach((node) => node.remove());
      const labelText = visibleText(clone);
      if (labelText) return labelText;
    }
    if (control.id) {
      const linked = document.querySelector(`label[for="${CSS.escape(control.id)}"]`);
      if (linked && visibleText(linked)) return visibleText(linked);
    }
    return control.getAttribute('placeholder') || control.getAttribute('title') || control.id?.replaceAll('-', ' ') || '';
  }

  function ensureAccessibleNames() {
    document.querySelectorAll('input:not([type="hidden"]),select,textarea').forEach((control) => {
      if (control.getAttribute('aria-label') || control.getAttribute('aria-labelledby') || control.labels?.length) return;
      const name = inferControlName(control);
      if (name) control.setAttribute('aria-label', name);
    });
    document.querySelectorAll('button').forEach((button) => {
      if (button.getAttribute('aria-label') || button.getAttribute('aria-labelledby') || visibleText(button)) return;
      const title = button.getAttribute('title') || button.id?.replaceAll('-', ' ') || 'Acción';
      button.setAttribute('aria-label', title);
    });
    document.querySelectorAll('.table-wrap table').forEach((table) => {
      if (table.getAttribute('aria-label') || table.querySelector('caption')) return;
      const container = table.closest('section,article,.view');
      const heading = container?.querySelector('h2,h3,h4');
      table.setAttribute('aria-label', visibleText(heading) || 'Listado del sistema');
    });
  }

  function observeDynamicUi() {
    let scheduled = false;
    const observer = new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => { scheduled = false; ensureAccessibleNames(); });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  document.addEventListener('DOMContentLoaded', () => {
    ensureAccessibleNames();
    observeDynamicUi();
  });
})();
