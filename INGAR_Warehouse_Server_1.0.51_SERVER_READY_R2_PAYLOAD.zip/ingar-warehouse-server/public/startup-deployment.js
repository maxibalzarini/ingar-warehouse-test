'use strict';

const $ = (selector) => document.querySelector(selector);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let redirecting = false;
let busy = false;

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

function render(status) {
  const badge = $('#status-badge');
  const summary = $('#summary');
  const network = $('#network-detail');
  const actions = $('#actions');
  const success = $('#success');
  const firewallButton = $('#firewall-button');

  const labels = {
    NOT_INITIALIZED: ['VERIFICANDO', 'checking'],
    CHECKING: ['VERIFICANDO', 'checking'],
    BLOCKED: ['CORREGIR', 'blocked'],
    PASSED: ['APROBADO', 'passed']
  };
  const [text, className] = labels[status.status] || labels.CHECKING;
  badge.textContent = text;
  badge.className = `badge ${className}`;
  summary.textContent = status.message || 'Verificando…';
  network.textContent = status.networkAddress ? `${status.networkAddress}:${status.port}` : '';

  $('#checks').innerHTML = (status.checks || []).map((check) => `
    <div class="check ${check.passed ? 'ok' : 'fail'}">
      <div class="check-icon">${check.passed ? '✓' : '!'}</div>
      <div><strong>${escapeHtml(check.label)}</strong><small>${escapeHtml(check.detail)}</small></div>
    </div>`).join('');

  const blocked = status.status === 'BLOCKED';
  actions.classList.toggle('hidden', !blocked);
  firewallButton.classList.toggle('hidden', status.firewallStatus === 'READY');
  success.classList.toggle('hidden', status.status !== 'PASSED');

  if (status.status === 'PASSED' && !redirecting) {
    redirecting = true;
    setTimeout(() => { location.replace('/'); }, 900);
  }
}

async function request(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.result?.detail || `Error HTTP ${response.status}`);
  return data;
}

async function poll() {
  while (!redirecting) {
    try {
      const data = await request('/api/v1/startup-deployment/status');
      render(data.deployment);
    } catch (error) {
      $('#summary').textContent = error.message;
    }
    await sleep(1200);
  }
}

$('#retry-button').addEventListener('click', async () => {
  if (busy) return;
  busy = true;
  $('#retry-button').disabled = true;
  try {
    const data = await request('/api/v1/startup-deployment/retry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}'
    });
    render(data.deployment);
  } catch (error) {
    $('#summary').textContent = error.message;
  } finally {
    busy = false;
    $('#retry-button').disabled = false;
  }
});

$('#firewall-button').addEventListener('click', async () => {
  if (busy) return;
  busy = true;
  $('#firewall-button').disabled = true;
  $('#summary').textContent = 'Esperando autorización de administrador de Windows…';
  try {
    const data = await request('/api/v1/startup-deployment/provision-firewall', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}'
    });
    render(data.deployment);
  } catch (error) {
    $('#summary').textContent = error.message;
  } finally {
    busy = false;
    $('#firewall-button').disabled = false;
  }
});

poll();
