'use strict';

(() => {
  const listeners = new Set();
  let state = { status: 'SEARCHING', server: { baseUrl: window.location.origin } };
  let csrf = sessionStorage.getItem('iwc_csrf') || '';
  let currentUser = null;
  let retryTimer = null;
  let probeInFlight = null;
  const validationToken = String(new URLSearchParams(window.location.search).get('v') || '').trim();

  function mobileDeviceEvidence() {
    return {
      screenWidth: Number(window.screen?.width || 0),
      screenHeight: Number(window.screen?.height || 0),
      viewportWidth: Number(window.innerWidth || 0),
      viewportHeight: Number(window.innerHeight || 0),
      maxTouchPoints: Number(navigator.maxTouchPoints || 0),
      touchEvent: 'ontouchstart' in window,
      coarsePointer: Boolean(window.matchMedia?.('(pointer: coarse)').matches),
      standalone: Boolean(window.matchMedia?.('(display-mode: standalone)').matches),
      platform: navigator.userAgentData?.platform || navigator.platform || null,
      vendor: navigator.vendor || null,
      orientation: window.screen?.orientation?.type || null
    };
  }

  function publicError(error) {
    return {
      ok: false,
      error: {
        message: error?.message || 'No se pudo completar la operación.',
        code: error?.code || 'CLIENT_ERROR',
        status: Number(error?.status || 0) || null,
        fieldErrors: error?.fieldErrors || []
      }
    };
  }

  function emit(next) {
    state = { ...next, server: { baseUrl: window.location.origin } };
    for (const callback of listeners) {
      try { callback(state); } catch {}
    }
  }

  function stopRetryLoop() {
    if (retryTimer) clearInterval(retryTimer);
    retryTimer = null;
  }

  function startRetryLoop() {
    if (retryTimer) return;
    retryTimer = setInterval(() => { probe().catch(() => {}); }, 3000);
  }

  function markUnavailable() {
    if (state.status !== 'NOT_FOUND') emit({ status: 'NOT_FOUND' });
    startRetryLoop();
  }

  async function request(path, { method = 'GET', body = null, headers = {} } = {}) {
    const init = {
      method,
      headers: { Accept: 'application/json', ...headers },
      credentials: 'same-origin',
      cache: 'no-store'
    };
    if (body !== null) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(body);
    }
    let response;
    try {
      response = await fetch(path, init);
    } catch {
      markUnavailable();
      const error = new Error('Se perdió la conexión con Warehouse.');
      error.code = 'WAREHOUSE_UNAVAILABLE';
      throw error;
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || `Warehouse respondió ${response.status}`);
      error.status = response.status;
      error.code = data.code || 'HTTP_ERROR';
      error.fieldErrors = data.fieldErrors || [];
      throw error;
    }
    if (state.status !== 'FOUND') {
      stopRetryLoop();
      emit({ status: 'FOUND' });
    }
    return data;
  }

  async function reportMobileValidation(stage, requestId = null) {
    if (!validationToken) return null;
    return request('/api/v1/operation/mobile-validation/ping', {
      method: 'POST',
      body: { validationToken, stage, requestId, deviceEvidence: mobileDeviceEvidence() }
    });
  }

  async function probe() {
    if (probeInFlight) return probeInFlight;
    probeInFlight = (async () => {
      try {
        const response = await fetch('/api/v1/health/live', { credentials: 'same-origin', cache: 'no-store' });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.status !== 'UP') throw new Error('HEALTH_NOT_READY');
        stopRetryLoop();
        if (state.status !== 'FOUND') emit({ status: 'FOUND' });
        return state;
      } catch {
        markUnavailable();
        return state;
      } finally {
        probeInFlight = null;
      }
    })();
    return probeInFlight;
  }

  async function ensureCsrf() {
    if (csrf) return csrf;
    const data = await request('/api/v1/auth/csrf');
    csrf = String(data.csrfToken || '');
    if (csrf) sessionStorage.setItem('iwc_csrf', csrf);
    return csrf;
  }

  function clearSession() {
    csrf = '';
    currentUser = null;
    sessionStorage.removeItem('iwc_csrf');
  }

  function idempotencyKey() {
    if (window.crypto?.randomUUID) return `web-${window.crypto.randomUUID()}`;
    return `web-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
  }

  window.ingarClient = {
    onState(callback) {
      if (typeof callback !== 'function') return () => {};
      listeners.add(callback);
      queueMicrotask(() => callback(state));
      return () => listeners.delete(callback);
    },

    async getState() { return probe(); },
    async retry() { return probe(); },

    async sessionState() {
      try {
        const data = await request('/api/v1/auth/me');
        currentUser = data.user || null;
        if (currentUser) await reportMobileValidation('AUTHENTICATED').catch(() => null);
        return { authenticated: Boolean(currentUser), user: currentUser };
      } catch (error) {
        if (error.status === 401) {
          clearSession();
          return { authenticated: false, user: null };
        }
        return { authenticated: false, user: null };
      }
    },

    async homeState() {
      try { return { ok: true, data: await request('/api/v1/operation/home') }; }
      catch (error) { return publicError(error); }
    },

    async requestHistory(filters = {}) {
      try {
        const params = new URLSearchParams();
        params.set('view', 'history');
        params.set('limit', String(Math.max(1, Math.min(200, Number(filters.limit) || 50))));
        params.set('offset', String(Math.max(0, Number(filters.offset) || 0)));
        for (const key of ['search','dateFrom','dateTo','type','result']) {
          if (String(filters[key] || '').trim()) params.set(key, String(filters[key]).trim());
        }
        const data = await request(`/api/v1/operation/requests?${params.toString()}`);
        return { ok: true, data };
      } catch (error) { return publicError(error); }
    },


    async createVehicleRequest(payload) {
      try {
        const token = await ensureCsrf(); const key = idempotencyKey();
        const result = await request('/api/v1/operation/vehicle-requests', { method:'POST', headers:{'X-CSRF-Token':token,'Idempotency-Key':key}, body:{...payload,clientRequestId:key} });
        await reportMobileValidation('REQUEST_CREATED', result?.request?.id).catch(() => null);
        return { ok:true, result };
      } catch (error) { return publicError(error); }
    },

    async uploadVehicleRequestPhoto(requestId, payload) {
      try { const token=await ensureCsrf(); const result=await request(`/api/v1/operation/vehicle-requests/${encodeURIComponent(requestId)}/photo`,{method:'POST',headers:{'X-CSRF-Token':token},body:payload}); return {ok:true,result}; }
      catch(error){ return publicError(error); }
    },

    async declareVehicleReturn(payload) {
      try { const token=await ensureCsrf(); const result=await request(`/api/v1/operation/vehicle-custodies/${encodeURIComponent(payload?.custodyId||'')}/declare-return`,{method:'POST',headers:{'X-CSRF-Token':token},body:{version:Number(payload?.version),odometer:Number(payload?.odometer),fuelLevelPercent:Number(payload?.fuelLevelPercent),checklist:payload?.checklist,condition:payload?.condition,problemReported:Boolean(payload?.problemReported),notes:payload?.notes||null}}); return {ok:true,...result}; }
      catch(error){ return publicError(error); }
    },

    async uploadVehicleReturnPhoto(custodyId, payload) {
      try { const token=await ensureCsrf(); const result=await request(`/api/v1/operation/vehicle-custodies/${encodeURIComponent(custodyId)}/return-photo`,{method:'POST',headers:{'X-CSRF-Token':token},body:payload}); return {ok:true,result}; }
      catch(error){ return publicError(error); }
    },

    async getAssetPhoto(assetId) {
      const id=String(assetId||'').trim();
      if (!id) return publicError(Object.assign(new Error('Foto no disponible.'),{code:'ASSET_PHOTO_NOT_FOUND'}));
      return { ok:true, url:`/api/v1/operation/assets/${encodeURIComponent(id)}/photo` };
    },

    async saveReturnReceipt(custodyId) {
      try {
        const response=await fetch(`/api/v1/operation/custodies/${encodeURIComponent(custodyId)}/return-receipt`,{credentials:'same-origin',cache:'no-store'});
        if (!response.ok) { const data=await response.json().catch(()=>({})); const e=new Error(data.message||'No se pudo descargar la constancia.'); e.status=response.status; e.code=data.code||'HTTP_ERROR'; throw e; }
        const blob=await response.blob();
        const disposition=response.headers.get('content-disposition')||'';
        const filename=(disposition.match(/filename="?([^";]+)"?/i)||[])[1]||'constancia-devolucion.pdf';
        const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
        return {ok:true,saved:true};
      } catch(error) { return publicError(error); }
    },

    async logout() {
      try {
        if (currentUser) {
          const token = await ensureCsrf().catch(() => '');
          if (token) await request('/api/v1/auth/logout', { method: 'POST', body: {}, headers: { 'X-CSRF-Token': token } }).catch(() => {});
        }
      } finally {
        clearSession();
      }
      return { ok: true, authenticated: false, user: null };
    },

    async openModule(moduleCode, search = '') {
      const code = String(moduleCode || '').toUpperCase();
      const q = String(search || '').trim();
      let path = '';
      if (code === 'TOOLS') path = `/api/v1/operation/availability?flow=TOOLS&limit=80${q ? `&search=${encodeURIComponent(q)}` : ''}`;
      else if (code === 'VEHICLES') path = `/api/v1/operation/availability?flow=VEHICLES&limit=80${q ? `&search=${encodeURIComponent(q)}` : ''}`;
      else if (code === 'REQUESTS') path = `/api/v1/operation/requests?limit=60${q ? `&search=${encodeURIComponent(q)}` : ''}`;
      else if (code === 'RETURNS') path = `/api/v1/operation/custodies?limit=60${q ? `&search=${encodeURIComponent(q)}` : ''}`;
      else if (code === 'MY_KITS') path = '/api/v1/operation/kits';
      else return publicError(Object.assign(new Error('Opción no disponible.'), { code: 'MODULE_INVALID' }));
      try { return { ok: true, moduleCode: code, data: await request(path) }; }
      catch (error) { return publicError(error); }
    },

    async createToolRequest(payload) {
      try {
        const token = await ensureCsrf();
        const key = idempotencyKey();
        const result = await request('/api/v1/operation/requests', {
          method: 'POST',
          headers: { 'X-CSRF-Token': token, 'Idempotency-Key': key },
          body: { ...payload, clientRequestId: key }
        });
        await reportMobileValidation('REQUEST_CREATED', result?.request?.id).catch(() => null);
        return { ok: true, result };
      } catch (error) { return publicError(error); }
    },

    async uploadSerializedRequestPhoto(requestId, payload) {
      try {
        const token = await ensureCsrf();
        const result = await request(`/api/v1/operation/requests/${encodeURIComponent(requestId)}/photo`, {
          method: 'POST', headers: { 'X-CSRF-Token': token }, body: payload
        });
        return { ok: true, result };
      } catch (error) { return publicError(error); }
    },

    async declareSerializedReturn(payload) {
      try {
        const token = await ensureCsrf();
        const result = await request(`/api/v1/operation/custodies/${encodeURIComponent(payload?.custodyId || '')}/declare-return`, {
          method: 'POST', headers: { 'X-CSRF-Token': token },
          body: {
            version: Number(payload?.version),
            condition: payload?.condition,
            problemReported: Boolean(payload?.problemReported),
            notes: payload?.notes || null,
            returnQuantity: payload?.returnQuantity === null || payload?.returnQuantity === undefined ? null : Number(payload.returnQuantity)
          }
        });
        return { ok: true, ...result };
      } catch (error) { return publicError(error); }
    },

    async uploadSerializedReturnPhoto(custodyId, payload) {
      try {
        const token = await ensureCsrf();
        const result = await request(`/api/v1/operation/custodies/${encodeURIComponent(custodyId)}/return-photo`, {
          method: 'POST', headers: { 'X-CSRF-Token': token }, body: payload
        });
        return { ok: true, result };
      } catch (error) { return publicError(error); }
    }
  };

  window.addEventListener('online', () => probe().catch(() => {}));
  window.addEventListener('offline', markUnavailable);
  reportMobileValidation('OPERATION_OPENED').catch(() => {});
  probe().catch(() => {});
})();
