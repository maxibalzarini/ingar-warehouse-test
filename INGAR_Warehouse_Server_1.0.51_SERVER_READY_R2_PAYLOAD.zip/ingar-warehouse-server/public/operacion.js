'use strict';


function technicalUsernameFromName(fullName) {
  const normalized = String(fullName || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const parts = normalized.trim().split(/\s+/).map((part) => part.replace(/[^a-z0-9]/g, '')).filter(Boolean);
  return parts.length >= 2 ? `${parts[0]}.${parts[parts.length - 1]}` : '';
}

const panelIds = ['searching','home','module-view','order-start-panel','cart-panel','return-panel','vehicle-request-panel','vehicle-return-panel','success','not-found','ambiguous'];
const moduleMeta = {
  TOOLS: { title: 'HERRAMIENTAS', kicker: 'PEDIR', icon: 'tool', empty: 'No encontramos herramientas disponibles.' },
  VEHICLES: { title: 'VEHÍCULOS', kicker: 'CONSULTAR', icon: 'vehicle', empty: 'No hay vehículos disponibles.' },
  REQUESTS: { title: 'MIS PEDIDOS', kicker: 'SEGUIMIENTO', icon: 'requests', empty: 'Todavía no hiciste pedidos.' },
  RETURNS: { title: 'DEVOLVER', kicker: 'TUS BIENES', icon: 'returns', empty: 'No tenés nada pendiente de devolución.' },
  HISTORY: { title: 'HISTORIA DE PEDIDOS', kicker: 'HISTÓRICO', icon: 'history', empty: 'Todavía no hay pedidos cerrados para mostrar.' },
  MY_KITS: { title: 'MI KIT', kicker: 'ASIGNADO A VOS', icon: 'kit', empty: 'Todavía no tenés un kit personal asignado.' }
};
let discoveryState = null;
let currentUser = null;
let currentModule = null;
let currentTechNavKey = null;
let selectedAsset = null;
let selectedCustody = null;
let returnHasProblem = false;
let selectedVehicle = null;
let selectedVehicleCustody = null;
let vehicleReturnHasProblem = false;
let vehicleRequestChecklist = {};
let vehicleReturnChecklist = {};
let vehicleRequestFuel = 75;
let vehicleReturnFuel = 75;
let searchTimer = null;
let historyMode = 'all';
let historyDateFrom = '';
let historyDateTo = '';
let historyOffset = 0;
let historyAccumulated = [];
let historyHasMore = false;
let orderWorkOrder = '';
let orderCart = [];
const C4_HOME_REFRESH_MS = 15_000;
let c4HomeRefreshTimer = null;
let c4HomeRefreshInFlight = false;


const $ = (id) => document.getElementById(id);
const OPERATION_BRANDING_DEFAULT = { organizationName:'Cliente', productName:'INGAR Warehouse', clientLogoConfigured:false, clientLogoUrl:null };
function applyOperationBranding(branding={}){ const b={...OPERATION_BRANDING_DEFAULT,...branding}; document.querySelectorAll('[data-client-brand]').forEach((slot)=>{const img=slot.querySelector('[data-client-logo]'),name=slot.querySelector('[data-client-name]'); if(name)name.textContent=b.organizationName||'Cliente'; if(b.clientLogoConfigured&&b.clientLogoUrl&&img){img.src=b.clientLogoUrl;slot.classList.remove('hidden');}else slot.classList.add('hidden');}); }
async function loadOperationBranding(){ try{const r=await fetch('/api/v1/public/branding',{credentials:'same-origin',cache:'no-store'}); if(!r.ok)throw new Error(); applyOperationBranding((await r.json())?.branding||{});}catch{applyOperationBranding(OPERATION_BRANDING_DEFAULT);} }
function applyOperationAvatar(user){const image=$('tech-user-avatar-image'),fallback=$('tech-user-avatar-fallback');if(!image||!fallback)return;const id=String(user?.photoEvidenceId||'');if(!id){image.classList.add('hidden');fallback.classList.remove('hidden');return;}image.onerror=()=>{image.classList.add('hidden');fallback.classList.remove('hidden');};image.src=`/api/v1/evidence/${encodeURIComponent(id)}`;image.classList.remove('hidden');fallback.classList.add('hidden');}
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function iconSvg(kind) {
  const icons = {
    tool: '<svg viewBox="0 0 24 24"><path d="M14.7 6.3a4 4 0 0 0-5-5l2.1 2.1-3.4 3.4-2.1-2.1a4 4 0 0 0 5 5L4 17l3 3 7.3-7.3a4 4 0 0 0 5-5l-2.1 2.1-3.4-3.4 2.1-2.1z"/></svg>',
    vehicle: '<svg viewBox="0 0 24 24"><path d="M3 17h18M5 17l1-6h12l1 6M7 11l2-4h6l2 4M7 17v2M17 17v2M7.5 14h.01M16.5 14h.01"/></svg>',
    requests: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18H6zM9 7h6M9 11h6M9 15h4"/></svg>',
    returns: '<svg viewBox="0 0 24 24"><path d="M9 7l-5 5 5 5M4 12h10a6 6 0 0 1 6 6"/></svg>',
    history: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5M12 7v5l3 2"/></svg>',
    kit: '<svg viewBox="0 0 24 24"><path d="M4 7h16v12H4zM8 7V5h8v2M4 11h16M10 14h4"/></svg>'
  };
  return icons[kind] || '';
}

function syncTechNavigation(id) {
  const panelModule = { 'order-start-panel':'TOOLS', 'cart-panel':'TOOLS', 'return-panel':'RETURNS', 'vehicle-request-panel':'VEHICLES', 'vehicle-return-panel':'VEHICLES' };
  const panelKey = { 'order-start-panel':'TOOLS_REQUEST', 'cart-panel':'TOOLS_REQUEST', 'return-panel':'RETURNS', 'vehicle-request-panel':'VEHICLES_REQUEST', 'vehicle-return-panel':'RETURNS' };
  const activeModule = id === 'home' ? null : (panelModule[id] || currentModule);
  const activeKey = id === 'home' ? null : (panelKey[id] || currentTechNavKey || activeModule);
  let activated = false;
  document.querySelectorAll('.cv-tech-sidebar .c3-tech-nav').forEach((button) => {
    const isHome = button.hasAttribute('data-home-focus');
    const key = button.dataset.techNavKey || button.dataset.module;
    const active = id === 'home' ? isHome : (!isHome && !activated && button.dataset.module === activeModule && key === activeKey);
    if (active && !isHome) activated = true;
    button.classList.toggle('active', active);
  });
  if (!activated && id !== 'home') {
    const fallback = [...document.querySelectorAll('.cv-tech-sidebar .c3-tech-nav')].find((button) => button.dataset.module === activeModule);
    fallback?.classList.add('active');
  }
}
function show(id) {
  for (const panelId of panelIds) $(panelId).classList.toggle('hidden', panelId !== id);
  const authenticatedSurface = Boolean(currentUser) && !['searching','not-found','ambiguous'].includes(id);
  document.body.classList.toggle('c3-tech-mode', authenticatedSurface);
  if (authenticatedSurface) syncTechNavigation(id);
  if (id !== 'home') stopC4HomeRefresh();
}
function setConnection(kind, text) {
  const node = $('connection-pill');
  node.className = `connection-pill ${kind}`;
  node.querySelector('b').textContent = text;
}
function friendlyOperationError(error) {
  if (error?.code === 'AUTH_REQUIRED' || error?.status === 401) return 'Tu sesión terminó. Volvé a ingresar.';
  if (['ASSET_NOT_AVAILABLE','ASSET_RESERVATION_CONFLICT','KIT_COMPONENT_RESERVED','KIT_COMPONENT_NOT_AVAILABLE'].includes(error?.code)) return error?.message || 'Ya no está disponible. El pedido fue actualizado con el estado real.';
  if (error?.code === 'WORK_ORDER_REQUIRED' || error?.code === 'REQUEST_WORK_ORDER_REQUIRED' || error?.code === 'REQUEST_WORK_ORDER_INVALID') return 'Ingresá una OT válida antes de enviar el pedido.';
  if (error?.code === 'VEHICLE_FORM_REQUIRED') return 'Este vehículo necesita su formulario de vehículo.';
  if (error?.code === 'SERIAL_DUE_AT_REQUIRED' || error?.code === 'SERIAL_DUE_AT_INVALID') return 'Elegí cuándo pensás devolverlo.';
  if (error?.code === 'RETURN_DECLARATION_NOTES_REQUIRED') return 'Si tiene un problema, contanos brevemente qué pasó.';
  if (error?.code === 'SERIAL_RETURN_NOT_DECLARED') return 'Primero tenés que avisar la devolución.';
  if (String(error?.code || '').includes('WAREHOUSE')) return 'Se perdió la conexión. Esperá un momento y volvé a intentar.';
  return error?.message || 'No pudimos completar la operación.';
}
function renderDiscovery(state) {
  discoveryState = state;
  if (!state) return;
  if (state.status === 'FOUND') {
    setConnection('ok', 'LISTO');
    if (!currentUser) {
      show('searching');
      $('status-title').textContent = 'Validando tu sesión…';
      $('status-text').textContent = 'INGAR Warehouse usa un único acceso.';
    }
    return;
  }
  currentUser = null;
  if (state.status === 'AMBIGUOUS') { setConnection('danger','SIN CONEXIÓN'); show('ambiguous'); return; }
  if (state.status === 'NOT_FOUND' || state.status === 'ERROR') { setConnection('danger','SIN CONEXIÓN'); show('not-found'); return; }
  setConnection('searching','INICIANDO');
  show('searching');
  $('status-title').textContent = 'Preparando el sistema…';
  $('status-text').textContent = 'No tenés que hacer nada.';
}
async function retry() {
  currentUser = null;
  setConnection('searching','INICIANDO');
  show('searching');
  renderDiscovery(await window.ingarClient.retry());
}

function homeNotificationRow(item) {
  const when = item.sent_at || item.scheduled_at || item.created_at;
  let dateText = '';
  if (when) { try { dateText = new Date(when).toLocaleString('es-AR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}); } catch {} }
  return `<div class="c3-feed-row"><span class="c3-feed-dot"></span><div><strong>${escapeHtml(item.subject || item.type || 'Aviso')}</strong><small>${escapeHtml(item.body || '')}</small></div><time>${escapeHtml(dateText)}</time></div>`;
}
async function loadHomeState({ silent = false } = {}) {
  if (c4HomeRefreshInFlight) return;
  c4HomeRefreshInFlight = true;
  const result = await window.ingarClient.homeState();
  if (!result?.ok) {
    if (!silent) {
      for (const id of ['tech-active-requests','tech-active-custodies','tech-due-today','tech-overdue-returns']) if ($(id)) $(id).textContent = '—';
      if ($('tech-news-list')) $('tech-news-list').innerHTML = '<p class="c3-empty">No se pudo actualizar.</p>';
      if ($('tech-alerts-list')) $('tech-alerts-list').innerHTML = '<p class="c3-empty">No se pudo actualizar.</p>';
    }
    if ($('tech-home-updated')) { $('tech-home-updated').textContent = 'Actualización interrumpida'; $('tech-home-updated').classList.remove('c4-live'); $('tech-home-updated').classList.add('c4-stale'); }
    c4HomeRefreshInFlight = false;
    return;
  }
  const data = result.data || {}; const metrics = data.metrics || {};
  if ($('tech-active-requests')) $('tech-active-requests').textContent = String(metrics.activeRequests ?? 0);
  if ($('tech-active-custodies')) $('tech-active-custodies').textContent = String(metrics.activeCustodies ?? 0);
  if ($('tech-due-today')) $('tech-due-today').textContent = String(metrics.dueToday ?? 0);
  if ($('tech-overdue-returns')) $('tech-overdue-returns').textContent = String(metrics.overdueReturns ?? 0);
  if ($('tech-overdue-card')) $('tech-overdue-card').classList.toggle('needs-attention', Number(metrics.overdueReturns || 0) > 0);
  if ($('tech-home-updated')) $('tech-home-updated').textContent = `Actualizado ${new Date(data.generatedAt).toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'})}`;
  const rows = Array.isArray(data.notifications) ? data.notifications : [];
  const news = rows.filter((x) => String(x.type||'').toUpperCase() !== 'SISTEMA').slice(0,5);
  const alerts = rows.filter((x) => String(x.type||'').toUpperCase() === 'SISTEMA').slice(0,5);
  if ($('tech-news-list')) $('tech-news-list').innerHTML = news.length ? news.map(homeNotificationRow).join('') : '<p class="c3-empty">Sin novedades registradas.</p>';
  if ($('tech-alerts-list')) $('tech-alerts-list').innerHTML = alerts.length ? alerts.map(homeNotificationRow).join('') : '<p class="c3-empty">Sin avisos registrados.</p>';
  if ($('tech-alerts-card')) $('tech-alerts-card').classList.toggle('hidden', alerts.length === 0);
  if ($('tech-home-updated')) { $('tech-home-updated').classList.add('c4-live'); $('tech-home-updated').classList.remove('c4-stale'); }
  c4HomeRefreshInFlight = false;
}
function stopC4HomeRefresh() { if (c4HomeRefreshTimer) clearInterval(c4HomeRefreshTimer); c4HomeRefreshTimer = null; }
function startC4HomeRefresh() {
  stopC4HomeRefresh();
  if (!currentUser) return;
  c4HomeRefreshTimer = setInterval(() => {
    if (!document.hidden && document.body.classList.contains('c3-tech-mode')) loadHomeState({ silent: true }).catch(()=>{ c4HomeRefreshInFlight=false; });
  }, C4_HOME_REFRESH_MS);
}
function renderHome(user) {
  currentUser = user;
  currentModule = null;
  currentTechNavKey = null;
  selectedAsset = null;
  selectedCustody = null;
  returnHasProblem = false;
  $('user-name').textContent = user?.fullName || user?.username || 'Usuario';
  applyOperationAvatar(user);
  if ($('tech-first-name')) $('tech-first-name').textContent = String(user?.fullName || user?.username || 'Usuario').trim().split(/\s+/)[0];
  if ($('tech-current-date')) $('tech-current-date').textContent = new Date().toLocaleString('es-AR',{weekday:'short',day:'2-digit',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});
  show('home');
  setConnection('ok','LISTO');
  loadHomeState().catch(()=>{ c4HomeRefreshInFlight=false; });
  startC4HomeRefresh();
}

$('logout').addEventListener('click', async () => {
  $('logout').disabled = true;
  try { await window.ingarClient.logout(); } finally {
    currentUser = null;
    window.location.replace('/');
  }
});
function statusLabel(status) {
  const labels = {
    PENDIENTE_AUTORIZACION:'Esperando aprobación',
    APROBADA:'Aprobado',
    PREPARANDO:'Lo están preparando',
    LISTA_PARA_ENTREGA:'Listo para retirar',
    ENTREGADA:'Entregado',
    BLOQUEADA:'Hay que revisar',
    CANCELADA:'Cancelado',
    EXPIRADA:'Vencido',
    ABIERTA:'Lo tenés vos',
    DEVOLUCION_DECLARADA:'Pediste devolverlo',
    RECEPCION_PENDIENTE:'Esperando que lo reciban',
    EN_USO:'En uso',
    DEVUELTO:'Devuelto',
    DEVUELTO_CON_OBSERVACION:'Devuelto con observación',
    INCIDENTE:'Tiene un problema'
  };
  return labels[status] || 'En proceso';
}
function terminalAssetId(item) {
  return item?.assetId || item?.id || item?.kit_asset_id || item?.component_asset_id || null;
}
function terminalAssetHasPhoto(item) {
  return Boolean(item?.photoAvailable ?? item?.photo_evidence_id ?? item?.photoUrl ?? item?.photo_url);
}
function terminalAssetPhotoHtml(item, className='asset-visual') {
  const id = terminalAssetId(item);
  if (!id || !terminalAssetHasPhoto(item)) return `<div class="${className} asset-visual-empty" aria-hidden="true">${iconSvg(String(item?.nature||'').toUpperCase()==='VEHICULO'?'vehicle':'tool')}</div>`;
  return `<div class="${className} asset-photo-pending" data-asset-photo-id="${escapeHtml(id)}"><span class="asset-photo-loading" aria-hidden="true">${iconSvg(String(item?.nature||'').toUpperCase()==='VEHICULO'?'vehicle':'tool')}</span></div>`;
}
async function hydrateAssetPhotos(root=document) {
  const nodes = [...root.querySelectorAll('[data-asset-photo-id]:not([data-photo-hydrated])')];
  await Promise.all(nodes.map(async (node) => {
    node.dataset.photoHydrated='1';
    const id=node.dataset.assetPhotoId;
    try {
      let src='';
      if (window.ingarClient?.getAssetPhoto) {
        const result=await window.ingarClient.getAssetPhoto(id);
        if (result?.ok) src=String(result.dataUrl || result.url || result.result?.dataUrl || result.result?.url || '');
      } else src=`/api/v1/operation/assets/${encodeURIComponent(id)}/photo`;
      if (!src) throw new Error('PHOTO_UNAVAILABLE');
      const img=document.createElement('img');
      img.alt='Foto de la herramienta'; img.loading='lazy'; img.src=src;
      img.addEventListener('load',()=>node.classList.remove('asset-photo-pending'),{once:true});
      img.addEventListener('error',()=>{node.classList.add('asset-visual-empty');node.removeAttribute('data-asset-photo-id');},{once:true});
      node.replaceChildren(img);
    } catch { node.classList.add('asset-visual-empty'); }
  }));
}
function assetTitle(item) { return item.description || item.internalCode || 'Bien'; }
function assetSubtitle(item) {
  const id = item.licensePlate || item.serialNumber || item.internalCode || '';
  const loc = [item.siteName,item.locationName].filter(Boolean).join(' · ');
  return [id,loc].filter(Boolean).join(' — ');
}
function formatDate(value) {
  if (!value) return '';
  try { return new Date(value).toLocaleString('es-AR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}); }
  catch { return ''; }
}
function updateCartButton() {
  const button = $('open-cart');
  if (!button) return;
  button.textContent = `MI PEDIDO (${orderCart.length})`;
  button.classList.toggle('hidden', currentModule !== 'TOOLS' || !orderWorkOrder);
  button.disabled = orderCart.length === 0;
}
function cartEntry(asset) { return orderCart.find((row) => row.asset.id === asset.id); }
function addToCart(asset) {
  const nature = String(asset?.nature || '').toUpperCase();
  const firstLocationId = orderCart[0]?.asset?.locationId || null;
  if (firstLocationId && asset?.locationId && asset.locationId !== firstLocationId) {
    const origin = orderCart[0]?.asset?.locationName || 'el pañol del pedido';
    const destination = asset?.locationName || 'otro pañol';
    $('module-message').textContent = `Este pedido ya contiene bienes de ${origin}. Para pedir un bien de ${destination}, enviá este pedido y creá otro con la misma OT.`;
    $('module-message').classList.remove('hidden');
    return;
  }
  $('module-message').classList.add('hidden');
  const existing = cartEntry(asset);
  if (existing) {
    if (!['SERIADO','KIT'].includes(nature)) existing.quantity = Math.min(Number(asset.quantityAvailable || 1), existing.quantity + 1);
  } else orderCart.push({ asset, quantity: 1 });
  updateCartButton();
  loadModule('TOOLS',$('module-search').value.trim());
}
function renderTools(data) {
  const items = data?.items || [];
  if (!items.length) { $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.TOOLS.empty}</div>`; updateCartButton(); return; }
  $('module-list').innerHTML = items.map((item,index) => {
    const nature = String(item.nature || '').toUpperCase();
    const kindLabel = nature === 'CONSUMIBLE' ? 'CONSUMIBLE' : nature === 'SERIADO' ? 'BIEN SERIALIZADO' : nature === 'KIT' ? 'KIT' : 'HERRAMIENTA';
    const inCart = cartEntry(item);
    return `
    <article class="data-card tool-data-card">
      ${terminalAssetPhotoHtml(item,'asset-visual asset-visual-card')}
      <div class="data-main">
        <h3>${escapeHtml(assetTitle(item))}</h3>
        <p>${escapeHtml(assetSubtitle(item))}</p>
        <div class="chips"><span>${escapeHtml(kindLabel)}</span>${item.categoryName ? `<span>${escapeHtml(item.categoryName)}</span>` : ''}<span>${inCart ? `EN PEDIDO · ${escapeHtml(inCart.quantity)}` : `DISPONIBLE · ${escapeHtml(item.quantityAvailable)} ${escapeHtml(item.unitOfMeasure||'')}`}</span></div>
      </div>
      <button class="item-action f15-primary-action" data-add-index="${index}" type="button" ${inCart && ['SERIADO','KIT'].includes(nature) ? 'disabled' : ''}>${inCart ? (['SERIADO','KIT'].includes(nature) ? 'AGREGADA' : '+ AGREGAR OTRA') : '+ AGREGAR'}</button>
    </article>`;
  }).join('');
  hydrateAssetPhotos($('module-list'));
  for (const button of document.querySelectorAll('[data-add-index]')) button.addEventListener('click', () => addToCart(items[Number(button.dataset.addIndex)]));
  updateCartButton();
}

function renderVehicles(data) {
  const items = data?.items || [];
  if (!items.length) { $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.VEHICLES.empty}</div>`; return; }
  $('module-list').innerHTML = items.map((item,index) => `
    <article class="data-card tool-data-card">
      ${terminalAssetPhotoHtml(item,'asset-visual asset-visual-card')}
      <div class="data-main">
        <h3>${escapeHtml(assetTitle(item))}</h3>
        <p>${escapeHtml(assetSubtitle(item))}</p>
        <div class="chips"><span>${escapeHtml([item.brand,item.model].filter(Boolean).join(' ') || 'Vehículo')}</span><span>Disponible</span>${Number.isFinite(Number(item.currentOdometer)) ? `<span>${escapeHtml(Number(item.currentOdometer).toLocaleString('es-AR'))} km</span>` : ''}</div>
      </div>
      <button class="item-action f15-primary-action" data-vehicle-index="${index}" type="button">PEDIR ESTE</button>
    </article>`).join('');
  hydrateAssetPhotos($('module-list'));
  for (const button of document.querySelectorAll('[data-vehicle-index]')) button.addEventListener('click', () => openVehicleRequest(items[Number(button.dataset.vehicleIndex)]));
}
function renderRequests(data) {
  const items = data?.items || [];
  if (!items.length) { $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.REQUESTS.empty}</div>`; return; }
  $('module-list').innerHTML = items.map(item => `
    <article class="data-card request-visual-card">
      <div class="data-main">
        <div class="card-top"><h3>${escapeHtml(item.requestNumber || 'Pedido')}${item.workOrderReference ? ` · OT ${escapeHtml(item.workOrderReference)}` : ''}</h3><span class="status-tag f15-status">${escapeHtml(statusLabel(item.displayStatus || item.status))}</span></div>
        ${(item.items||[]).map(row => `<div class="request-visual-line">${terminalAssetPhotoHtml(row,'asset-visual asset-visual-request')}<div><strong>${escapeHtml(row.description||row.internalCode)}</strong><small>${escapeHtml(row.internalCode||'')}${row.workOrderRequired?` · OT ${escapeHtml(row.workOrderReference||'—')}`:''}</small><span>${escapeHtml(statusLabel(row.lifecycleStatus || row.status))}</span></div></div>`).join('')}
        <p class="muted f15-meta">${escapeHtml(formatDate(item.createdAt))}${item.locationName ? ` · ${escapeHtml(item.locationName)}` : ''}</p>
      </div>
    </article>`).join('');
  hydrateAssetPhotos($('module-list'));
}

function historyResultLabel(value) {
  const labels = {
    ENTREGADA: 'Entregado',
    DEVUELTO: 'Devuelto',
    DEVUELTO_CON_OBSERVACION: 'Devuelto con observación',
    CANCELADA: 'Cancelado',
    EXPIRADA: 'Vencido'
  };
  return labels[String(value || '').toUpperCase()] || statusLabel(value);
}
function formatHistoryDate(value) {
  if (!value) return '';
  try { return new Date(value).toLocaleString('es-AR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}); }
  catch { return ''; }
}
function historyItemText(row) {
  const identity = [row.internalCode,row.licensePlate||row.serialNumber].filter(Boolean).join(' · ');
  const status = historyResultLabel(row.lifecycleStatus || row.status);
  const parts = [status];
  if (row.returnedAt) parts.push(`Devuelto: ${formatHistoryDate(row.returnedAt)}`);
  if (row.returnCondition && row.returnCondition !== 'CONFORME') parts.push(`Condición: ${row.returnCondition}`);
  if (row.timingStatus === 'FUERA_DE_TERMINO') parts.push('Fuera de término');
  const ot=row.workOrderRequired?`<small><strong>OT:</strong> ${escapeHtml(row.workOrderReference||'—')}</small>`:'';
  const receipt=row.hasReturnReceipt && row.custodyId ? `<button class="history-receipt" data-return-receipt="${escapeHtml(row.custodyId)}" type="button">CONSTANCIA PDF${row.returnReceiptNumber ? ` · ${escapeHtml(row.returnReceiptNumber)}` : ''}</button>` : '';
  return `<div class="history-item history-item-visual">${terminalAssetPhotoHtml(row,'asset-visual asset-visual-history')}<div><strong>${escapeHtml(row.description||row.internalCode||'Bien')} × ${escapeHtml(row.quantity)}</strong>${identity ? `<small>${escapeHtml(identity)}</small>` : ''}${ot}<small>${escapeHtml(parts.join(' · '))}</small>${receipt}</div></div>`;
}
function historyEventText(event) {
  const actor = event.actorName || event.actorUsername || 'Sistema';
  return `<div class="history-event"><b>${escapeHtml(formatHistoryDate(event.occurredAt))}</b> · ${escapeHtml(statusLabel(event.toStatus))} · ${escapeHtml(actor)}${event.reason ? ` · ${escapeHtml(event.reason)}` : ''}</div>`;
}
function renderHistory(data, append = false) {
  const incoming = data?.items || [];
  historyAccumulated = append ? [...historyAccumulated, ...incoming] : incoming;
  historyHasMore = Boolean(data?.hasMore);
  $('module-load-more').classList.toggle('hidden', !historyHasMore);
  if (!historyAccumulated.length) {
    $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.HISTORY.empty}</div>`;
    return;
  }
  $('module-list').innerHTML = historyAccumulated.map(item => `
    <article class="data-card history-card">
      <div class="data-main">
        <div class="card-top"><h3>${escapeHtml(item.requestNumber || 'Pedido')}${item.workOrderReference ? ` · OT ${escapeHtml(item.workOrderReference)}` : ''}</h3><span class="status-tag">${escapeHtml(historyResultLabel(item.history?.result || item.displayStatus || item.status))}</span></div>
        <div class="history-summary">
          <span>Pedido: ${escapeHtml(formatHistoryDate(item.createdAt))}</span>
          ${item.history?.completionAt ? `<span>Cierre: ${escapeHtml(formatHistoryDate(item.history.completionAt))}</span>` : ''}
          ${item.siteName || item.locationName ? `<span>${escapeHtml([item.siteName,item.locationName].filter(Boolean).join(' · '))}</span>` : ''}
        </div>
        ${item.reason ? `<p>${escapeHtml(item.reason)}</p>` : ''}
        <div class="history-items">${(item.items||[]).map(historyItemText).join('')}</div>
        ${(item.events||[]).length ? `<div class="history-timeline">${item.events.map(historyEventText).join('')}</div>` : ''}
      </div>
    </article>`).join('');
  hydrateAssetPhotos($('module-list'));
  wireReturnReceiptButtons();
}
function renderReturns(data) {
  const items = data?.items || [];
  if (!items.length) { $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.RETURNS.empty}</div>`; return; }
  $('module-list').innerHTML = items.map((item,index) => {
    const nature = String(item.nature || '').toUpperCase();
    let action = '';
    if (['CANTIDAD','SERIADO','KIT'].includes(nature) && item.canDeclareReturn && item.status === 'ABIERTA') action = `<button class="item-action return-action f15-primary-action" data-return-index="${index}" type="button">DEVOLVER ESTE</button>`;
    else if (['CANTIDAD','SERIADO','KIT'].includes(nature) && item.status === 'DEVOLUCION_DECLARADA') action = '<span class="static-action">YA AVISASTE</span>';
    else if (nature === 'VEHICULO' && item.status === 'ABIERTA') action = `<button class="item-action return-action f15-primary-action" data-vehicle-return-index="${index}" type="button">DEVOLVER ESTE</button>`;
    else if (nature === 'VEHICULO' && item.status === 'DEVOLUCION_DECLARADA') action = '<span class="static-action">YA AVISASTE</span>';
    else if (item.returnReceipt) action = `<button class="item-action return-action" data-receipt-index="${index}" type="button">CONSTANCIA PDF</button>`;
    else action = '<span class="static-action">LLEVALO AL PAÑOL</span>';
    return `<article class="data-card tool-data-card return-visual-card">
      ${terminalAssetPhotoHtml(item,'asset-visual asset-visual-card')}
      <div class="data-main">
        <div class="card-top"><h3>${escapeHtml(item.description||item.internalCode)}</h3><span class="status-tag">${escapeHtml(statusLabel(item.displayStatus || item.status))}</span></div>
        <p>${escapeHtml([item.licensePlate||item.serialNumber||item.internalCode,item.locationName].filter(Boolean).join(' — '))}</p>
        <div class="chips">${item.categoryName||item.nature ? `<span>${escapeHtml(item.categoryName||item.nature)}</span>` : ''}${nature === 'CANTIDAD' ? `<span>PENDIENTE · ${escapeHtml(item.quantityOutstanding ?? item.quantity ?? 0)} DE ${escapeHtml(item.quantity ?? 0)}</span>` : ''}${item.dueAt ? `<span>Devolver: ${escapeHtml(formatDate(item.dueAt))}</span>` : ''}</div>
      </div>${action}
    </article>`;
  }).join('');
  hydrateAssetPhotos($('module-list'));
  for (const button of document.querySelectorAll('[data-return-index]')) button.addEventListener('click', () => openSerializedReturn(items[Number(button.dataset.returnIndex)]));
  for (const button of document.querySelectorAll('[data-vehicle-return-index]')) button.addEventListener('click', () => openVehicleReturn(items[Number(button.dataset.vehicleReturnIndex)]));
  for (const button of document.querySelectorAll('[data-receipt-index]')) button.addEventListener('click', async () => {
    const item = items[Number(button.dataset.receiptIndex)];
    await saveReturnReceiptFromButton(button,item.id);
  });
}

function renderMyKits(data) {
  const items = data?.items || [];
  if (!items.length) {
    $('module-list').innerHTML = `<div class="empty-state">${moduleMeta.MY_KITS.empty}</div>`;
    return;
  }
  $('module-list').innerHTML = items.map((kit) => {
    const components = (kit.components || []).map((item) => `<li class="kit-component-visual">${terminalAssetPhotoHtml(item,'asset-visual asset-visual-kit-component')}<div><strong>${escapeHtml(item.internal_code)}</strong><br>${escapeHtml(item.description)}${Number(item.required_quantity || 1) !== 1 ? ` · ${escapeHtml(item.required_quantity)}` : ''}</div></li>`).join('');
    return `<article class="data-card kit-personal-card tool-data-card">
      ${terminalAssetPhotoHtml(kit,'asset-visual asset-visual-card')}
      <div class="data-main">
        <div class="card-top"><h3>${escapeHtml(kit.description || kit.internal_code)}</h3><span class="status-tag">${escapeHtml(statusLabel(kit.status))}</span></div>
        <p>${escapeHtml([kit.internal_code, kit.serial_number, kit.location_name].filter(Boolean).join(' — '))}</p>
        <div class="chips"><span>Asignado a vos</span><span>${(kit.components || []).length} herramientas</span></div>
        <ul class="kit-personal-components">${components}</ul>
      </div>
    </article>`;
  }).join('');
  hydrateAssetPhotos($('module-list'));
}

async function saveReturnReceiptFromButton(button,custodyId) {
  if (!custodyId) return;
  const label=button.textContent; button.disabled=true; button.textContent='GUARDANDO…';
  try {
    if (window.ingarClient?.saveReturnReceipt) {
      const result=await window.ingarClient.saveReturnReceipt(custodyId);
      if (!result?.ok) throw result?.error || new Error('No se pudo guardar la constancia.');
      if (result.saved === false) return;
      $('module-message').textContent='Constancia PDF guardada.'; $('module-message').classList.remove('hidden');
    } else window.open(`/api/v1/operation/custodies/${encodeURIComponent(custodyId)}/return-receipt`,'_blank','noopener');
  } catch(error) { $('module-message').textContent=friendlyOperationError(error); $('module-message').classList.remove('hidden'); }
  finally { button.disabled=false; button.textContent=label; }
}
function wireReturnReceiptButtons() {
  for (const button of document.querySelectorAll('[data-return-receipt]')) button.addEventListener('click',()=>saveReturnReceiptFromButton(button,button.dataset.returnReceipt));
}

function configureModuleSearch(code) {
  const searchable = ['TOOLS','VEHICLES','REQUESTS','HISTORY'].includes(code);
  $('module-search-wrap').classList.toggle('hidden', !searchable);
  $('history-controls').classList.toggle('hidden', code !== 'HISTORY');
  $('module-load-more').classList.add('hidden');
  if (code === 'TOOLS') {
    $('module-search-label').textContent = 'BUSCÁ LO QUE NECESITÁS';
    $('module-search').placeholder = 'Escribí nombre, marca o medida';
  } else if (code === 'VEHICLES') {
    $('module-search-label').textContent = 'BUSCÁ UN VEHÍCULO';
    $('module-search').placeholder = 'Escribí patente, marca o modelo';
  } else if (code === 'REQUESTS') {
    $('module-search-label').textContent = 'BUSCAR EN MIS PEDIDOS';
    $('module-search').placeholder = 'Escribí una palabra';
  } else if (code === 'HISTORY') {
    $('module-search-label').textContent = 'BUSCAR EN EL HISTÓRICO';
    $('module-search').placeholder = 'Solicitud, bien, patente, serie o sede';
  }
}
function renderModuleData(code,data,append=false) {
  if (!append) $('module-list').innerHTML = '';
  $('module-message').classList.add('hidden');
  if (code === 'TOOLS') renderTools(data);
  else if (code === 'VEHICLES') renderVehicles(data);
  else if (code === 'REQUESTS') renderRequests(data);
  else if (code === 'HISTORY') renderHistory(data,append);
  else if (code === 'MY_KITS') renderMyKits(data);
  else renderReturns(data);
}
function historyFilters(search, offset = 0) {
  return {
    search,
    offset,
    limit: 50,
    dateFrom: historyMode === 'date' ? historyDateFrom : '',
    dateTo: historyMode === 'date' ? historyDateTo : ''
  };
}
async function loadModule(code,search='',options={}) {
  currentModule = code;
  const meta = moduleMeta[code];
  if (!meta) return;
  const append = Boolean(options.append && code === 'HISTORY');
  if (code === 'HISTORY' && !append) {
    historyOffset = 0;
    historyAccumulated = [];
    historyHasMore = false;
  }
  $('module-title').textContent = meta.title;
  $('module-kicker').textContent = meta.kicker;
  $('module-icon').innerHTML = iconSvg(meta.icon);
  if (!append) $('module-search').value = search;
  $('clear-search').classList.toggle('hidden', !search);
  configureModuleSearch(code);
  updateCartButton();
  $('module-message').classList.add('hidden');
  if (!append) $('module-list').innerHTML = '';
  $('module-loading').classList.remove('hidden');
  show('module-view');
  const result = code === 'HISTORY'
    ? await window.ingarClient.requestHistory(historyFilters(search, append ? historyOffset : 0))
    : await window.ingarClient.openModule(code,search);
  $('module-loading').classList.add('hidden');
  if (!result.ok) {
    if (result.error?.status === 401 || result.error?.code === 'AUTH_REQUIRED') { currentUser = null; window.location.replace(`/?next=${encodeURIComponent(`/mi-operacion${window.location.search || ''}`)}`); return; }
    $('module-message').textContent = friendlyOperationError(result.error);
    $('module-message').classList.remove('hidden');
    return;
  }
  if (code === 'HISTORY') {
    renderModuleData(code,result.data,append);
    historyOffset = (append ? historyOffset : 0) + (result.data?.items?.length || 0);
  } else renderModuleData(code,result.data,false);
}
for (const button of document.querySelectorAll('[data-home-focus]')) button.addEventListener('click', () => { if (currentUser) renderHome(currentUser); });
for (const button of document.querySelectorAll('[data-module]')) button.addEventListener('click', () => {
  const code = button.dataset.module;
  currentTechNavKey = button.dataset.techNavKey || (code === 'TOOLS' ? 'TOOLS_REQUEST' : code === 'VEHICLES' ? 'VEHICLES_REQUEST' : code);
  if (code === 'TOOLS') { startOrderFlow(); return; }
  if (code === 'HISTORY') {
    historyMode = 'all'; historyDateFrom = ''; historyDateTo = '';
    $('history-all').classList.add('active'); $('history-by-date').classList.remove('active');
    $('history-date-range').classList.add('hidden'); $('history-date-from').value=''; $('history-date-to').value='';
  }
  loadModule(code);
});
$('back-home').addEventListener('click', () => renderHome(currentUser));
$('clear-search').addEventListener('click', () => { $('module-search').value=''; $('clear-search').classList.add('hidden'); currentModule && loadModule(currentModule,''); });
$('module-search').addEventListener('input', () => {
  const value = $('module-search').value.trim();
  $('clear-search').classList.toggle('hidden', !value);
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { if (currentModule && (value.length >= 2 || value.length === 0)) loadModule(currentModule,value); }, 450);
});
$('module-search').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    clearTimeout(searchTimer);
    if (currentModule) loadModule(currentModule,$('module-search').value.trim());
  }
});
$('history-all').addEventListener('click', () => {
  historyMode='all'; historyDateFrom=''; historyDateTo='';
  $('history-all').classList.add('active'); $('history-by-date').classList.remove('active'); $('history-date-range').classList.add('hidden');
  if (currentModule==='HISTORY') loadModule('HISTORY',$('module-search').value.trim());
});
$('history-by-date').addEventListener('click', () => {
  historyMode='date';
  $('history-by-date').classList.add('active'); $('history-all').classList.remove('active'); $('history-date-range').classList.remove('hidden');
  setTimeout(() => $('history-date-from').focus(),50);
});
$('history-apply').addEventListener('click', () => {
  historyDateFrom=$('history-date-from').value;
  historyDateTo=$('history-date-to').value;
  if (!historyDateFrom && !historyDateTo) {
    $('module-message').textContent='Indicá al menos una fecha para usar POR FECHA.'; $('module-message').classList.remove('hidden'); return;
  }
  if (historyDateFrom && historyDateTo && historyDateFrom > historyDateTo) {
    $('module-message').textContent='La fecha DESDE no puede ser posterior a HASTA.'; $('module-message').classList.remove('hidden'); return;
  }
  loadModule('HISTORY',$('module-search').value.trim());
});
$('module-load-more').addEventListener('click', () => {
  if (currentModule==='HISTORY' && historyHasMore) loadModule('HISTORY',$('module-search').value.trim(),{append:true});
});

function tomorrowDateValue() {
  const d = new Date(Date.now() + 24 * 3600_000);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2,'0');
  const day = String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function dateValueToDueAt(value) {
  const parts = String(value || '').split('-').map(Number);
  if (parts.length !== 3 || parts.some((n) => !Number.isFinite(n))) return null;
  return new Date(parts[0], parts[1] - 1, parts[2], 23, 59, 0, 0).toISOString();
}
function blobToDataUrl(blob) {
  return new Promise((resolve,reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('No pudimos leer la foto.'));
    reader.readAsDataURL(blob);
  });
}
async function prepareImagePayload(file) {
  if (!file) return null;
  if (!String(file.type || '').startsWith('image/')) throw new Error('Elegí una foto.');
  try {
    const bitmap = await createImageBitmap(file);
    const maxSide = 1400;
    const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    let blob = null;
    for (const quality of [0.82,0.68,0.54]) {
      blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
      if (blob && blob.size <= 1_850_000) break;
    }
    if (!blob || blob.size > 2_000_000) throw new Error('La foto es demasiado grande. Sacá otra foto más simple.');
    return { dataUrl: await blobToDataUrl(blob), originalFilename: `${String(file.name || 'foto').replace(/\.[^.]+$/, '')}.jpg` };
  } catch (error) {
    if (file.size <= 1_850_000) return { dataUrl: await blobToDataUrl(file), originalFilename: file.name || 'foto.jpg' };
    throw error;
  }
}

function validWorkOrder(value) { return /^[A-Za-z0-9][A-Za-z0-9 ._:/#-]{0,119}$/.test(String(value || '').trim()); }
function startOrderFlow() {
  currentModule = 'TOOLS';
  $('order-work-order').value = orderWorkOrder;
  $('order-start-error').classList.add('hidden');
  syncOrderStart();
  show('order-start-panel');
  setTimeout(() => $('order-work-order').focus(),50);
}
function syncOrderStart() {
  const value = String($('order-work-order').value || '').trim();
  $('continue-order').disabled = Boolean(value && !validWorkOrder(value));
}
$('order-work-order').addEventListener('input', syncOrderStart);
$('cancel-order-start').addEventListener('click', () => { orderWorkOrder=''; orderCart=[]; renderHome(currentUser); });
$('order-start-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const value = String($('order-work-order').value || '').trim();
  if (value && !validWorkOrder(value)) { $('order-start-error').textContent='Ingresá una OT válida.'; $('order-start-error').classList.remove('hidden'); return; }
  if (orderWorkOrder && orderWorkOrder !== value) orderCart=[];
  orderWorkOrder = value;
  loadModule('TOOLS');
});
function cartNeedsDueDate() { return orderCart.some(({asset}) => ['SERIADO','KIT'].includes(String(asset.nature||'').toUpperCase()) || Boolean(asset.requiresReturn)); }
function cartRequiresWorkOrder() { return true; }
function cartAllowsPhoto() { return orderCart.some(({asset}) => ['SERIADO','KIT'].includes(String(asset.nature||'').toUpperCase())); }
function renderCart() {
  $('cart-title').textContent = orderWorkOrder ? `MI PEDIDO · OT ${orderWorkOrder}` : 'MI PEDIDO';
  $('cart-list').innerHTML = orderCart.length ? orderCart.map(({asset,quantity},index) => {
    const nature=String(asset.nature||'').toUpperCase(); const unit=['SERIADO','KIT'].includes(nature);
    return `<article class="cart-row">${terminalAssetPhotoHtml(asset,'asset-visual asset-visual-card')}<div class="cart-row-main"><strong>${escapeHtml(assetTitle(asset))}</strong><small>${escapeHtml(asset.internalCode||'')}</small>${unit?'<span>Cantidad 1</span>':`<div class="cart-qty"><button type="button" data-cart-minus="${index}">−</button><b>${escapeHtml(quantity)}</b><button type="button" data-cart-plus="${index}">+</button></div>`}</div><button class="cart-remove" data-cart-remove="${index}" type="button">QUITAR</button></article>`;
  }).join('') : '<div class="empty-state">Tu pedido está vacío.</div>';
  hydrateAssetPhotos($('cart-list'));
  for(const b of document.querySelectorAll('[data-cart-remove]')) b.addEventListener('click',()=>{orderCart.splice(Number(b.dataset.cartRemove),1);updateCartButton();renderCart();});
  for(const b of document.querySelectorAll('[data-cart-minus]')) b.addEventListener('click',()=>{const row=orderCart[Number(b.dataset.cartMinus)];row.quantity=Math.max(1,row.quantity-1);renderCart();});
  for(const b of document.querySelectorAll('[data-cart-plus]')) b.addEventListener('click',()=>{const row=orderCart[Number(b.dataset.cartPlus)];row.quantity=Math.min(Number(row.asset.quantityAvailable||1),row.quantity+1);renderCart();});
  const due=cartNeedsDueDate(); $('cart-due-wrap').classList.toggle('hidden',!due); $('cart-due-date').required=due; $('cart-due-date').min=new Date().toISOString().slice(0,10); if(due&&!$('cart-due-date').value)$('cart-due-date').value=tomorrowDateValue();
  $('cart-photo-wrap').classList.toggle('hidden',!cartAllowsPhoto());
  $('send-cart').disabled=orderCart.length===0 || (cartRequiresWorkOrder() && !validWorkOrder(orderWorkOrder));
}
function openCart() { $('cart-error').classList.add('hidden'); renderCart(); show('cart-panel'); }
$('open-cart').addEventListener('click',openCart);
$('cart-back-tools').addEventListener('click',()=>startOrderFlow());
$('cart-photo').addEventListener('change',()=>{$('cart-photo-status').textContent=$('cart-photo').files?.[0]?'Foto lista para adjuntar.':'No hace falta foto si está todo bien.';});
$('cart-form').addEventListener('submit',async(event)=>{
  event.preventDefault(); if(!orderCart.length)return;
  if(cartRequiresWorkOrder()&&!validWorkOrder(orderWorkOrder)){ $('cart-error').textContent='Este carrito contiene una herramienta con OT obligatoria. Volvé y cargá una OT válida.'; $('cart-error').classList.remove('hidden'); return; }
  const button=$('send-cart'), errorNode=$('cart-error'); errorNode.classList.add('hidden'); button.disabled=true; button.textContent='ENVIANDO…';
  try {
    const dueAt=cartNeedsDueDate()?dateValueToDueAt($('cart-due-date').value):null;
    let photoPayload=null; if(cartAllowsPhoto()&&$('cart-photo').files?.[0]) photoPayload=await prepareImagePayload($('cart-photo').files[0]);
    const result=await window.ingarClient.createToolRequest({items:orderCart.map(({asset,quantity})=>({assetId:asset.id,quantity})),dueAt,workOrderReference:orderWorkOrder,reason:$('cart-reason').value.trim()});
    if(!result.ok) throw result.error;
    const request=result.result?.request||result.result; let photoWarning='';
    if(photoPayload&&request?.id){const uploaded=await window.ingarClient.uploadSerializedRequestPhoto(request.id,photoPayload);if(!uploaded.ok)photoWarning=' El pedido quedó registrado, pero la foto no pudo adjuntarse.';}
    orderCart=[]; orderWorkOrder=''; updateCartButton(); $('cart-form').reset();
    $('success-text').textContent=request?.request_number?`Tu pedido ${request.request_number} ya llegó al pañol.${photoWarning}`:`Tu pedido ya llegó al pañol.${photoWarning}`; show('success');
  } catch(error) {
    const availabilityConflict = ['ASSET_NOT_AVAILABLE','ASSET_RESERVATION_CONFLICT','KIT_COMPONENT_RESERVED','KIT_COMPONENT_NOT_AVAILABLE'].includes(error?.code);
    if (availabilityConflict) {
      try {
        const refreshed = await window.ingarClient.openModule('TOOLS','');
        if (refreshed?.ok) {
          const availableIds = new Set((refreshed.data?.items || []).map((item) => item.id));
          const before = orderCart.length;
          orderCart = orderCart.filter(({asset}) => availableIds.has(asset.id));
          updateCartButton();
          renderCart();
          if (before !== orderCart.length) errorNode.textContent = `${friendlyOperationError(error)} Quitamos del pedido lo que ya no puede solicitarse.`;
          else errorNode.textContent = friendlyOperationError(error);
        } else errorNode.textContent = friendlyOperationError(error);
      } catch { errorNode.textContent = friendlyOperationError(error); }
    } else errorNode.textContent=friendlyOperationError(error);
    errorNode.classList.remove('hidden');
  }
  finally { button.textContent='ENVIAR PEDIDO'; button.disabled=orderCart.length===0; }
});

function openSerializedReturn(custody) {
  selectedCustody = custody;
  const nature = String(custody?.nature || custody?.categoryNature || custody?.category_nature || '').toUpperCase();
  const natureLabel = nature === 'KIT' ? 'KIT' : nature === 'SERIADO' ? 'BIEN SERIALIZADO' : nature === 'CANTIDAD' ? `HERRAMIENTA · PENDIENTE ${custody.quantityOutstanding ?? custody.quantity ?? 0}` : 'HERRAMIENTA';
  if ($('return-nature-label')) $('return-nature-label').textContent = natureLabel;
  returnHasProblem = false;
  const quantityReturn = nature === 'CANTIDAD';
  const outstanding = Number(custody.quantityOutstanding ?? custody.quantity ?? 0);
  $('return-quantity-wrap').classList.toggle('hidden', !quantityReturn);
  $('return-quantity').required = quantityReturn;
  $('return-quantity').disabled = !quantityReturn;
  $('return-quantity').max = quantityReturn ? String(outstanding) : '';
  $('return-quantity').value = quantityReturn ? String(outstanding) : '';
  $('return-quantity-help').textContent = quantityReturn ? `Pendiente total: ${outstanding}. Podés devolver una parte.` : '';
  $('selected-custody').innerHTML = `${terminalAssetPhotoHtml(custody,'asset-visual asset-visual-selected')}<div class="selected-asset-copy"><span class="f15-confirm-kicker">ESTÁS DEVOLVIENDO</span><strong>${escapeHtml(custody.description || custody.internalCode)}</strong><span>${escapeHtml([custody.serialNumber || custody.internalCode,custody.locationName].filter(Boolean).join(' — '))}</span></div>`;
  hydrateAssetPhotos($('selected-custody'));
  $('return-ok').classList.add('selected');
  $('return-problem').classList.remove('selected');
  $('return-problem-fields').classList.add('hidden');
  $('return-notes').value = '';
  $('return-notes').required = false;
  $('return-photo').value = '';
  $('return-photo-wrap')?.classList.add('hidden');
  $('return-photo-status').textContent = 'La foto es opcional, pero ayuda al pañolero a preparar la recepción.';
  $('return-error').classList.add('hidden');
  show('return-panel');
}
function setReturnProblem(value) {
  returnHasProblem = Boolean(value);
  $('return-ok').classList.toggle('selected', !returnHasProblem);
  $('return-problem').classList.toggle('selected', returnHasProblem);
  $('return-problem-fields').classList.toggle('hidden', !returnHasProblem);
  $('return-photo-wrap')?.classList.toggle('hidden', !returnHasProblem);
  $('return-notes').required = returnHasProblem;
  if (returnHasProblem) setTimeout(() => $('return-notes').focus(), 30);
}
$('return-ok').addEventListener('click', () => setReturnProblem(false));
$('return-problem').addEventListener('click', () => setReturnProblem(true));
$('return-photo').addEventListener('change', () => {
  $('return-photo-status').textContent = $('return-photo').files?.[0] ? 'Foto lista para adjuntar.' : 'La foto es opcional, pero ayuda al pañolero a preparar la recepción.';
});
$('return-qty-minus').addEventListener('click', () => {
  if ($('return-quantity-wrap').classList.contains('hidden')) return;
  const current = Number($('return-quantity').value || 0);
  $('return-quantity').value = String(Math.max(0.001, current - 1));
});
$('return-qty-plus').addEventListener('click', () => {
  if ($('return-quantity-wrap').classList.contains('hidden')) return;
  const max = Number($('return-quantity').max || 0);
  const current = Number($('return-quantity').value || 0);
  $('return-quantity').value = String(Math.min(max, current + 1));
});
$('cancel-return').addEventListener('click', () => loadModule('RETURNS'));
$('return-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!selectedCustody) return;
  const button = $('send-return');
  const errorNode = $('return-error');
  errorNode.classList.add('hidden');
  button.disabled = true;
  button.textContent = 'ENVIANDO…';
  try {
    const notes = $('return-notes').value.trim();
    const nature = String(selectedCustody?.nature || selectedCustody?.categoryNature || selectedCustody?.category_nature || '').toUpperCase();
    const returnQuantity = nature === 'CANTIDAD' ? Number($('return-quantity').value) : null;
    if (nature === 'CANTIDAD') {
      const outstanding = Number(selectedCustody.quantityOutstanding ?? selectedCustody.quantity ?? 0);
      if (!Number.isFinite(returnQuantity) || returnQuantity <= 0 || returnQuantity - outstanding > 1e-9) throw new Error(`Indicá una cantidad válida hasta ${outstanding}.`);
    }
    if (returnHasProblem && notes.length < 3) throw new Error('Contanos brevemente qué problema tiene.');
    let photoPayload = null;
    if ($('return-photo').files?.[0]) {
      $('return-photo-status').textContent = 'Preparando foto…';
      photoPayload = await prepareImagePayload($('return-photo').files[0]);
    }
    const result = await window.ingarClient.declareSerializedReturn({
      custodyId:selectedCustody.id,
      version:selectedCustody.version,
      condition:returnHasProblem ? 'OBSERVADO' : 'CONFORME',
      problemReported:returnHasProblem,
      notes:notes || null,
      returnQuantity
    });
    if (!result.ok) throw result.error;
    const custody = result.custody || result.result?.custody || result.result || result;
    let photoWarning = '';
    if (photoPayload) {
      const uploaded = await window.ingarClient.uploadSerializedReturnPhoto(selectedCustody.id, photoPayload);
      if (!uploaded.ok) photoWarning = ' La devolución quedó avisada, pero la foto no pudo adjuntarse.';
    }
    $('success-text').textContent = `Listo. El pañol ya sabe que vas a devolver ${nature === 'CANTIDAD' ? `${returnQuantity} de ` : ''}${selectedCustody.description || 'el bien'}.${photoWarning}`;
    selectedCustody = custody;
    show('success');
  } catch (error) {
    errorNode.textContent = friendlyOperationError(error);
    errorNode.classList.remove('hidden');
  } finally {
    button.disabled = false;
    button.textContent = 'CONFIRMAR DEVOLUCIÓN';
  }
});

const VEHICLE_CHECKS = [
  ['exterior','Exterior'],['neumaticos','Neumáticos'],['luces','Luces'],['interior','Interior'],['documentacion','Documentación']
];
const FUEL_LEVELS = [[100,'Lleno'],[75,'3/4'],[50,'1/2'],[25,'1/4'],[10,'Reserva']];
function renderChecklist(containerId, state, onChange) {
  const node = $(containerId);
  const allOk = VEHICLE_CHECKS.every(([key]) => state[key] === 'OK');
  node.innerHTML = `<div class="vehicle-check-all"><button type="button" class="vehicle-check-all-ok ${allOk ? 'selected' : ''}" data-vcheck-all-ok>✓ TODO OK</button><span>Usalo si revisaste el vehículo y está todo bien.</span></div>` + VEHICLE_CHECKS.map(([key,label]) => `<div class="vehicle-check-row"><strong>${label}</strong><button type="button" class="vehicle-check-btn ok ${state[key]==='OK'?'selected':''}" data-vcheck="${key}" data-value="OK">✓ OK</button><button type="button" class="vehicle-check-btn obs ${state[key]==='OBSERVACION'?'selected':''}" data-vcheck="${key}" data-value="OBSERVACION">! OBSERVACIÓN</button></div>`).join('');
  node.querySelector('[data-vcheck-all-ok]')?.addEventListener('click', () => {
    for (const [key] of VEHICLE_CHECKS) state[key] = 'OK';
    renderChecklist(containerId,state,onChange);
    onChange?.();
  });
  for (const button of node.querySelectorAll('[data-vcheck]')) button.addEventListener('click', () => {
    state[button.dataset.vcheck] = button.dataset.value;
    renderChecklist(containerId,state,onChange);
    onChange?.();
  });
}
function renderFuel(containerId, selected, onSelect) {
  const node=$(containerId);
  node.innerHTML=FUEL_LEVELS.map(([value,label])=>`<button class="fuel-button ${Number(selected)===value?'selected':''}" type="button" data-fuel="${value}">${label}</button>`).join('');
  for(const button of node.querySelectorAll('[data-fuel]')) button.addEventListener('click',()=>onSelect(Number(button.dataset.fuel)));
}
function allChecklistSet(state){ return VEHICLE_CHECKS.every(([key])=>['OK','OBSERVACION'].includes(state[key])); }
function checklistHasObservation(state){ return VEHICLE_CHECKS.some(([key])=>state[key]==='OBSERVACION'); }
function localDateTimeValue(date){ const d=new Date(date); d.setMinutes(d.getMinutes()-d.getTimezoneOffset()); return d.toISOString().slice(0,16); }
async function prepareImagePayloads(input) {
  const files = Array.from(input?.files || []).slice(0,5); const out=[];
  for (const file of files) out.push(await prepareImagePayload(file));
  return out;
}

function fuelLabel(value){ return FUEL_LEVELS.find(([v])=>v===Number(value))?.[1] || `${Number(value)||0}%`; }
function userDisplayName(){ return currentUser?.fullName || currentUser?.username || 'Usuario'; }
function vehicleIdentityHtml(vehicle){
  const plate=vehicle?.licensePlate || vehicle?.internalCode || 'Sin patente';
  const brandModel=[vehicle?.brand,vehicle?.model].filter(Boolean).join(' ');
  const location=vehicle?.locationName || '';
  return `<div class="vehicle-f15-identity">${terminalAssetPhotoHtml(vehicle,'asset-visual asset-visual-vehicle')}<div><strong>${escapeHtml(assetTitle(vehicle||{}))}</strong><span>${escapeHtml(plate)}</span><div class="vehicle-subline">${brandModel?`<b>${escapeHtml(brandModel)}</b>`:''}${location?`<b>${escapeHtml(location)}</b>`:''}</div></div></div>`;
}
function renderPhotoPreviews(inputId, containerId){
  const input=$(inputId), box=$(containerId); if(!box)return;
  box.innerHTML=''; const files=Array.from(input?.files||[]).slice(0,5);
  files.forEach((file,index)=>{const url=URL.createObjectURL(file);const item=document.createElement('div');item.className='vehicle-photo-thumb';item.innerHTML=`<img alt="Foto ${index+1}"><span>${index+1}</span>`;const img=item.querySelector('img');img.src=url;img.addEventListener('load',()=>URL.revokeObjectURL(url),{once:true});box.appendChild(item);});
}
function renderVehicleReturnComparison(){
  if(!selectedVehicleCustody)return; const dep=selectedVehicleCustody.vehicleDeparture||{};
  const start=Number(dep.departure_odometer||0); const current=Number($('vehicle-return-odometer')?.value||start); const delta=Math.max(0,current-start);
  $('vehicle-return-comparison').innerHTML=`<div><small>Salida</small><strong>${escapeHtml(start.toLocaleString('es-AR'))} km · ${escapeHtml(fuelLabel(dep.departure_fuel_percent))}</strong></div><div><small>Ahora</small><strong>${escapeHtml(current.toLocaleString('es-AR'))} km · ${escapeHtml(fuelLabel(vehicleReturnFuel))}</strong></div><div><small>Recorrido</small><strong>+${escapeHtml(delta.toLocaleString('es-AR'))} km</strong></div>`;
}
function openVehicleRequest(vehicle) {
  selectedVehicle=vehicle; vehicleRequestChecklist={}; vehicleRequestFuel=75;
  $('selected-vehicle').innerHTML=vehicleIdentityHtml(vehicle); hydrateAssetPhotos($('selected-vehicle'));
  $('vehicle-request-user').textContent=userDisplayName();
  $('vehicle-driver').textContent=userDisplayName();
  $('vehicle-companion').value='';
  $('vehicle-needed-at').value=localDateTimeValue(new Date());
  $('vehicle-due-at').value=localDateTimeValue(new Date(Date.now()+8*3600_000));
  $('vehicle-work-order').value='';
  $('vehicle-destination').value='';
  $('vehicle-request-odometer').value=String(Math.round(Number(vehicle.currentOdometer||0)));
  $('vehicle-request-observation').value=''; $('vehicle-request-observation-wrap').classList.add('hidden');
  $('vehicle-request-photos').value=''; $('vehicle-request-photo-preview').innerHTML=''; $('vehicle-request-photo-status').textContent='Agregá fotos si encontrás golpes, daños o algo fuera de condición.';
  $('vehicle-disclaimer').checked=false; $('vehicle-request-error').classList.add('hidden');
  renderChecklist('vehicle-request-checklist',vehicleRequestChecklist,()=>{ $('vehicle-request-observation-wrap').classList.toggle('hidden',!checklistHasObservation(vehicleRequestChecklist)); });
  const setRequestFuel=(value)=>{vehicleRequestFuel=value;renderFuel('vehicle-request-fuel',vehicleRequestFuel,setRequestFuel)}; setRequestFuel(vehicleRequestFuel);
  show('vehicle-request-panel');
}
$('cancel-vehicle-request').addEventListener('click',()=>loadModule('VEHICLES'));
$('vehicle-request-photos').addEventListener('change',()=>{renderPhotoPreviews('vehicle-request-photos','vehicle-request-photo-preview');$('vehicle-request-photo-status').textContent=$('vehicle-request-photos').files?.length?`${Math.min(5,$('vehicle-request-photos').files.length)} foto(s) lista(s).`:'Agregá fotos si encontrás golpes, daños o algo fuera de condición.';});
$('vehicle-request-form').addEventListener('submit',async(event)=>{
  event.preventDefault(); if(!selectedVehicle)return;
  const button=$('send-vehicle-request'), errorNode=$('vehicle-request-error'); errorNode.classList.add('hidden');
  button.disabled=true; button.textContent='ENVIANDO…';
  try{
    if(!allChecklistSet(vehicleRequestChecklist)) throw new Error('Completá todo el checklist.');
    const observation=$('vehicle-request-observation').value.trim();
    if(checklistHasObservation(vehicleRequestChecklist)&&observation.length<3) throw new Error('Contanos brevemente qué observaste.');
    const neededAt=new Date($('vehicle-needed-at').value); const dueAt=new Date($('vehicle-due-at').value);
    if(!Number.isFinite(neededAt.getTime())||!Number.isFinite(dueAt.getTime())||dueAt<=neededAt) throw new Error('Revisá las fechas de salida y devolución.');
    const workOrderReference=String($('vehicle-work-order').value||'').trim(); if(!validWorkOrder(workOrderReference)) throw new Error('Ingresá una OT válida.');
    const photos=await prepareImagePayloads($('vehicle-request-photos'));
    const result=await window.ingarClient.createVehicleRequest({assetId:selectedVehicle.id,driverPersonId:currentUser?.personId,companionName:$('vehicle-companion').value.trim()||null,
      neededAt:neededAt.toISOString(),dueAt:dueAt.toISOString(),workOrderReference,destination:$('vehicle-destination').value.trim(),reason:$('vehicle-destination').value.trim(),
      odometer:Number($('vehicle-request-odometer').value),fuelLevelPercent:vehicleRequestFuel,checklist:vehicleRequestChecklist,departureNotes:observation||null,disclaimerAccepted:$('vehicle-disclaimer').checked});
    if(!result.ok) throw result.error;
    const request=result.result?.request||result.result; let failed=0;
    for(const photo of photos){ const up=await window.ingarClient.uploadVehicleRequestPhoto(request.id,photo); if(!up.ok) failed++; }
    $('success-text').textContent=`Tu pedido de vehículo ${request?.request_number||''} ya llegó al pañol.${failed?' Alguna foto no pudo adjuntarse.':''}`; show('success');
  }catch(error){errorNode.textContent=friendlyOperationError(error);errorNode.classList.remove('hidden');}
  finally{button.disabled=false;button.textContent='SOLICITAR VEHÍCULO';}
});
function openVehicleReturn(custody){
  selectedVehicleCustody=custody; vehicleReturnHasProblem=false; vehicleReturnChecklist={}; vehicleReturnFuel=Number(custody.vehicleDeparture?.departure_fuel_percent||75);
  const dep=custody.vehicleDeparture||{};
  $('selected-vehicle-return').innerHTML=vehicleIdentityHtml({assetId:custody.assetId,photoAvailable:custody.photoAvailable,description:custody.description,internalCode:custody.internalCode,licensePlate:custody.licensePlate,locationName:custody.locationName,brand:dep.brand,model:dep.model,nature:'VEHICULO'}); hydrateAssetPhotos($('selected-vehicle-return'));
  $('vehicle-return-user').textContent=userDisplayName();
  $('vehicle-return-driver').textContent=dep.driver_name || userDisplayName();
  $('vehicle-return-date').textContent=new Date().toLocaleString('es-AR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  $('vehicle-return-odometer').value=String(Math.round(Number(dep.departure_odometer||0))); $('vehicle-return-notes').value='';
  $('vehicle-return-problem-wrap').classList.add('hidden'); $('vehicle-return-no').classList.add('selected'); $('vehicle-return-yes').classList.remove('selected');
  $('vehicle-return-photos').value=''; $('vehicle-return-photo-preview').innerHTML=''; $('vehicle-return-photo-status').textContent='Si hubo un problema, agregá una foto.'; $('vehicle-return-error').classList.add('hidden');
  renderChecklist('vehicle-return-checklist',vehicleReturnChecklist,()=>{});
  const setFuel=(value)=>{vehicleReturnFuel=value;renderFuel('vehicle-return-fuel',vehicleReturnFuel,setFuel);renderVehicleReturnComparison();}; setFuel(vehicleReturnFuel);
  renderVehicleReturnComparison();
  show('vehicle-return-panel');
}
function setVehicleReturnProblem(value){ vehicleReturnHasProblem=Boolean(value); $('vehicle-return-no').classList.toggle('selected',!vehicleReturnHasProblem); $('vehicle-return-yes').classList.toggle('selected',vehicleReturnHasProblem); $('vehicle-return-problem-wrap').classList.toggle('hidden',!vehicleReturnHasProblem); }
$('vehicle-return-no').addEventListener('click',()=>setVehicleReturnProblem(false)); $('vehicle-return-yes').addEventListener('click',()=>setVehicleReturnProblem(true));
$('cancel-vehicle-return').addEventListener('click',()=>loadModule('RETURNS'));
$('vehicle-return-odometer').addEventListener('input',renderVehicleReturnComparison);
$('vehicle-return-photos').addEventListener('change',()=>{renderPhotoPreviews('vehicle-return-photos','vehicle-return-photo-preview');$('vehicle-return-photo-status').textContent=$('vehicle-return-photos').files?.length?`${Math.min(5,$('vehicle-return-photos').files.length)} foto(s) lista(s).`:'Si hubo un problema, agregá una foto.';});
$('vehicle-return-form').addEventListener('submit',async(event)=>{
  event.preventDefault(); if(!selectedVehicleCustody)return; const button=$('send-vehicle-return'),errorNode=$('vehicle-return-error'); errorNode.classList.add('hidden'); button.disabled=true;button.textContent='ENVIANDO…';
  try{
    if(!allChecklistSet(vehicleReturnChecklist)) throw new Error('Completá todo el checklist.');
    const checklistProblem=checklistHasObservation(vehicleReturnChecklist); const problem=vehicleReturnHasProblem||checklistProblem; const notes=$('vehicle-return-notes').value.trim();
    if(problem&&notes.length<3) throw new Error('Contanos brevemente qué pasó.');
    const photos=await prepareImagePayloads($('vehicle-return-photos'));
    const result=await window.ingarClient.declareVehicleReturn({custodyId:selectedVehicleCustody.id,version:selectedVehicleCustody.version,odometer:Number($('vehicle-return-odometer').value),fuelLevelPercent:vehicleReturnFuel,checklist:vehicleReturnChecklist,condition:problem?'OBSERVADO':'CONFORME',problemReported:problem,notes:notes||null});
    if(!result.ok) throw result.error; let failed=0;
    for(const photo of photos){const up=await window.ingarClient.uploadVehicleReturnPhoto(selectedVehicleCustody.id,photo);if(!up.ok)failed++;}
    const supervisorName=result?.supervision?.supervisor_name||'tu Supervisor asignado';
    $('success-text').textContent=`Listo. La devolución de ${selectedVehicleCustody.description||'el vehículo'} quedó enviada a ${supervisorName} para inspección y V°B°. Después el pañol podrá recibir las llaves.${failed?' Alguna foto no pudo adjuntarse.':''}`;show('success');
  }catch(error){errorNode.textContent=friendlyOperationError(error);errorNode.classList.remove('hidden');}
  finally{button.disabled=false;button.textContent='AVISAR DEVOLUCIÓN';}
});

$('success-home').addEventListener('click', () => {
  selectedAsset = null;
  selectedCustody = null;
  returnHasProblem = false;
  selectedVehicle = null; selectedVehicleCustody = null; vehicleReturnHasProblem = false;
  currentModule = null;
  renderHome(currentUser);
});
$('retry').addEventListener('click',retry);
$('retry-amb').addEventListener('click',retry);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && currentUser && document.body.classList.contains('c3-tech-mode')) loadHomeState({ silent: true }).catch(()=>{ c4HomeRefreshInFlight=false; });
});
window.ingarClient.onState(renderDiscovery);
loadOperationBranding();
Promise.all([window.ingarClient.getState(), window.ingarClient.sessionState()]).then(([state, session]) => {
  discoveryState = state;
  if (state?.status === 'FOUND' && session?.authenticated && session.user) {
    renderHome(session.user);
    return;
  }
  if (state?.status === 'FOUND') {
    window.location.replace(`/?next=${encodeURIComponent(`/mi-operacion${window.location.search || ''}`)}`);
    return;
  }
  renderDiscovery(state);
});

for (const button of document.querySelectorAll('[data-home-focus]')) button.addEventListener('click',()=>document.getElementById('tech-home-top')?.scrollIntoView({behavior:'smooth',block:'start'}));
