'use strict';

const $ = (selector) => document.querySelector(selector);
const token = new URLSearchParams(location.search).get('token') || '';
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let running = false;

function deviceEvidence() {
  const media = window.matchMedia ? window.matchMedia('(pointer: coarse)') : null;
  return {
    screenWidth: screen.width,
    screenHeight: screen.height,
    viewportWidth: innerWidth,
    viewportHeight: innerHeight,
    maxTouchPoints: navigator.maxTouchPoints || 0,
    touchEvent: 'ontouchstart' in window,
    coarsePointer: Boolean(media?.matches),
    platform: navigator.platform || '',
    vendor: navigator.vendor || '',
    orientation: screen.orientation?.type || ''
  };
}

async function request(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Error HTTP ${response.status}`);
  return data;
}

function done(id) {
  const step = $(`#${id}`);
  step.classList.remove('active');
  step.classList.add('done');
}

function active(id) {
  $$('.step').forEach((step) => step.classList.remove('active'));
  $(`#${id}`).classList.add('active');
}

function $$(selector) {
  return [...document.querySelectorAll(selector)];
}

function fail(error) {
  $('#message').textContent = 'La prueba quedó detenida.';
  $('#error-detail').textContent = error.message;
  $('#error').classList.remove('hidden');
}

async function waitForLocalReturn() {
  active('step-return');
  for (let attempt = 0; attempt < 40; attempt += 1) {
    const data = await request(`/api/v1/installation-validation/mobile-status?token=${encodeURIComponent(token)}`);
    if (data.validation?.passed || data.validation?.status === 'PASSED') {
      done('step-return');
      $('#message').textContent = 'La computadora confirmó el retorno.';
      $('#result-detail').textContent = data.validation.requestCode
        ? `El pedido técnico ${data.validation.requestCode} fue recibido y confirmado. Puede cerrar esta página.`
        : 'La comunicación quedó validada. Puede cerrar esta página.';
      $('#result').classList.remove('hidden');
      return;
    }
    await sleep(700);
  }
  throw new Error('La computadora del servidor no confirmó el retorno dentro del tiempo esperado.');
}

async function run() {
  if (running) return;
  running = true;
  $('#error').classList.add('hidden');
  try {
    if (!token) throw new Error('El QR no contiene un token de validación válido.');
    const evidence = deviceEvidence();

    active('step-connect');
    const connected = await request('/api/v1/installation-validation/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, deviceEvidence: evidence })
    });
    done('step-connect');
    $('#message').textContent = 'Celular conectado. Enviando el pedido técnico…';

    active('step-order');
    const order = await request('/api/v1/installation-validation/test-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token,
        challenge: connected.challenge,
        requestCode: connected.requestCode,
        deviceEvidence: evidence
      })
    });
    done('step-order');
    $('#message').textContent = 'Pedido recibido por el servidor. Confirmando su respuesta…';

    active('step-ack');
    await request('/api/v1/installation-validation/ack-received', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, ackId: order.acknowledgement.ackId, deviceEvidence: evidence })
    });
    done('step-ack');
    $('#message').textContent = 'Respuesta confirmada. Esperando el registro en la computadora…';

    await waitForLocalReturn();
  } catch (error) {
    fail(error);
  } finally {
    running = false;
  }
}

$('#retry').addEventListener('click', run);
run();
