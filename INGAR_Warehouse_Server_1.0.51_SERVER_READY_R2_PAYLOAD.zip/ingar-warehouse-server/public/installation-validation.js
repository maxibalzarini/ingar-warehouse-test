'use strict';

const $ = (selector) => document.querySelector(selector);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let finished = false;
let busy = false;
let lastValidationId = null;

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

async function request(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Error HTTP ${response.status}`);
  return data;
}

function render(validation) {
  const badge = $('#status-badge');
  const labels = {
    NOT_INITIALIZED: ['PREPARANDO', 'checking'],
    BLOCKED: ['CORREGIR', 'blocked'],
    WAITING_SCAN: ['ESPERANDO CELULAR', 'waiting'],
    MOBILE_CONNECTED: ['CELULAR CONECTADO', 'waiting'],
    WAITING_PHONE_ACK: ['PEDIDO RECIBIDO', 'waiting'],
    WAITING_LOCAL_OBSERVATION: ['CONFIRMANDO RETORNO', 'waiting'],
    EXPIRED: ['QR VENCIDO', 'expired'],
    PASSED: ['APROBADO', 'passed']
  };
  const [label, className] = labels[validation.status] || labels.NOT_INITIALIZED;
  badge.textContent = label;
  badge.className = `badge ${className}`;
  $('#summary').textContent = validation.message || 'Validando…';
  $('#network-detail').textContent = validation.networkAddress && validation.port ? `${validation.networkAddress}:${validation.port}` : '';

  $('#checks').innerHTML = (validation.checks || []).map((check) => `
    <div class="check ${check.passed ? 'ok' : 'pending'}">
      <div class="check-icon">${check.passed ? '✓' : '·'}</div>
      <div><strong>${escapeHtml(check.label)}</strong><small>${escapeHtml(check.detail)}</small></div>
    </div>`).join('');

  const qrImage = $('#qr');
  if (validation.qrAvailable && (validation.validationId !== lastValidationId || !qrImage.getAttribute('src'))) {
    lastValidationId = validation.validationId;
    qrImage.onerror = () => {
      qrImage.classList.add('hidden');
      $('#qr-state').textContent = 'No se pudo cargar el QR. Reintentando…';
      setTimeout(() => {
        if (!finished && validation.qrAvailable) qrImage.src = `/api/v1/installation-validation/qr.svg?ts=${Date.now()}`;
      }, 800);
    };
    qrImage.onload = () => {
      qrImage.classList.remove('hidden');
      $('#qr-state').textContent = 'Abra la cámara del celular y escanee.';
    };
    qrImage.src = `/api/v1/installation-validation/qr.svg?ts=${Date.now()}`;
  }
  if (!validation.qrAvailable) qrImage.classList.add('hidden');
  else if (qrImage.complete && qrImage.naturalWidth > 0) qrImage.classList.remove('hidden');
  if (!validation.qrAvailable) $('#qr-state').textContent = validation.status === 'PASSED' ? 'Validación completada.' : 'QR no disponible.';

  const passed = validation.status === 'PASSED';
  $('#result').classList.toggle('hidden', !passed);
  if (passed) {
    $('#result-detail').textContent = validation.requestCode
      ? `El pedido técnico ${validation.requestCode} llegó al servidor y su respuesta fue confirmada por el celular.`
      : 'La comunicación celular ↔ servidor ↔ computadora quedó comprobada.';
  }
  $('#restart-button').classList.toggle('hidden', passed);

  if (passed && !finished) {
    finished = true;
    setTimeout(() => { location.replace('/'); }, 1000);
  }
}

async function poll() {
  while (!finished) {
    try {
      const data = await request('/api/v1/installation-validation/status');
      render(data.validation);
    } catch (error) {
      $('#summary').textContent = error.message;
    }
    await sleep(900);
  }
}

$('#restart-button').addEventListener('click', async () => {
  if (busy) return;
  busy = true;
  $('#restart-button').disabled = true;
  try {
    const data = await request('/api/v1/installation-validation/restart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}'
    });
    lastValidationId = null;
    render(data.validation);
  } catch (error) {
    $('#summary').textContent = error.message;
  } finally {
    busy = false;
    $('#restart-button').disabled = false;
  }
});

poll();
