'use strict';

const CACHE_NAME = 'iwc-operation-ui-v8-1-0-51-aligned';
const STATIC_ASSETS = ['/operacion.css', '/operacion.js', '/operacion-client.js', '/operacion.webmanifest', '/assets/ingar-logo.png', '/assets/icons.svg', '/sw.js'];
const OFFLINE_CRITICAL_OPERATION_DENIED = Object.freeze({
  code: 'OFFLINE_CRITICAL_OPERATION_DENIED',
  message: 'Las operaciones críticas requieren conexión activa y nunca se almacenan en cola offline.'
});

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(STATIC_ASSETS);
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))));
  self.clients.claim();
});

function offlineJson(status, payload) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
  });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const desktopPaths = new Set(['/', '/index.html', '/app.css', '/ui-system.css', '/js/ui-runtime.js', '/mi-operacion', '/panol/workbench', '/control', '/gestion/config', '/acceso-limitado']);
  // app.js se dividio en modulos bajo /js/app/*.js (ver index.html); todos requieren el
  // mismo no-store que antes tenia el archivo unico.
  if (desktopPaths.has(url.pathname) || url.pathname.startsWith('/js/app/')) {
    event.respondWith(fetch(request, { cache: 'no-store' }));
    return;
  }

  if (url.pathname.startsWith('/api/')) {
    if (!['GET', 'HEAD'].includes(request.method)) {
      event.respondWith(fetch(request).catch(() => offlineJson(503, OFFLINE_CRITICAL_OPERATION_DENIED)));
      return;
    }
    event.respondWith(fetch(request).catch(() => offlineJson(503, {
      code: 'OFFLINE_READ_UNAVAILABLE',
      message: 'La consulta requiere conexión al servidor local.'
    })));
    return;
  }

  if (request.method === 'GET') {
    const operationStatic = new Set(STATIC_ASSETS);
    if (operationStatic.has(url.pathname)) {
      event.respondWith(fetch(request, { cache: 'no-store' }).then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => undefined);
        return response;
      }).catch(() => caches.match(request)));
      return;
    }
    event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => undefined);
      return response;
    })));
  }
});
