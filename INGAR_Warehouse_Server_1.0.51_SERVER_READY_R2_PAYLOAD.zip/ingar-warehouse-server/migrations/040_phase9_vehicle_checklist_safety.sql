-- +up
PRAGMA foreign_keys = ON;

-- F25 / Fase 9: evaluación del checklist vehicular por Supervisor.
-- Cada ítem queda evaluado como OK/OBSERVACION y, si corresponde, Seguridad.
CREATE TABLE vehicle_return_checklist_assessment (
  id TEXT PRIMARY KEY,
  supervision_id TEXT NOT NULL REFERENCES vehicle_return_supervision(id),
  custody_id TEXT NOT NULL REFERENCES custody(id),
  checklist_key TEXT NOT NULL,
  checklist_label_snapshot TEXT NOT NULL,
  technician_value_snapshot TEXT NOT NULL CHECK(technician_value_snapshot IN ('OK','OBSERVACION')),
  supervisor_value TEXT NOT NULL CHECK(supervisor_value IN ('OK','OBSERVACION')),
  safety_observation INTEGER NOT NULL DEFAULT 0 CHECK(safety_observation IN (0,1)),
  supervisor_comment TEXT,
  assessed_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  assessed_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(supervision_id, checklist_key),
  CHECK(safety_observation=0 OR supervisor_value='OBSERVACION'),
  CHECK(supervisor_value='OK' OR (supervisor_comment IS NOT NULL AND length(trim(supervisor_comment)) >= 3))
);

CREATE INDEX ix_vehicle_return_checklist_assessment_supervision
  ON vehicle_return_checklist_assessment(supervision_id, checklist_key);
CREATE INDEX ix_vehicle_return_checklist_assessment_safety
  ON vehicle_return_checklist_assessment(custody_id, safety_observation, assessed_at);

CREATE TRIGGER vehicle_return_checklist_assessment_no_update
BEFORE UPDATE ON vehicle_return_checklist_assessment
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_CHECKLIST_ASSESSMENT_IMMUTABLE');
END;

CREATE TRIGGER vehicle_return_checklist_assessment_no_delete
BEFORE DELETE ON vehicle_return_checklist_assessment
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_CHECKLIST_ASSESSMENT_IMMUTABLE');
END;

-- No se hace backfill: las decisiones F24 ya emitidas permanecen válidas y no se
-- inventan evaluaciones ítem por ítem que el Supervisor nunca realizó.

-- +down
DROP TRIGGER IF EXISTS vehicle_return_checklist_assessment_no_delete;
DROP TRIGGER IF EXISTS vehicle_return_checklist_assessment_no_update;
DROP INDEX IF EXISTS ix_vehicle_return_checklist_assessment_safety;
DROP INDEX IF EXISTS ix_vehicle_return_checklist_assessment_supervision;
DROP TABLE IF EXISTS vehicle_return_checklist_assessment;
