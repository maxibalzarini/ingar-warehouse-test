-- +up
PRAGMA foreign_keys = ON;

-- F20/Fase 4: congelado histórico de identidad visible, sede/ubicación y bienes.
-- El pedido/custodia conserva sus FK operativas; estas tablas preservan cómo se
-- identificaban los elementos al cerrar la solicitud, evitando que renombres
-- posteriores cambien la lectura del histórico.
CREATE TABLE request_history_snapshot (
  request_id TEXT PRIMARY KEY REFERENCES request(id),
  requester_person_id TEXT NOT NULL,
  requester_name_snapshot TEXT NOT NULL,
  requester_username_snapshot TEXT,
  site_id TEXT NOT NULL,
  site_code_snapshot TEXT,
  site_name_snapshot TEXT,
  location_id TEXT NOT NULL,
  location_code_snapshot TEXT,
  location_name_snapshot TEXT,
  frozen_status TEXT NOT NULL CHECK(frozen_status IN ('CANCELADA','EXPIRADA','ENTREGADA')),
  frozen_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE request_item_history_snapshot (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  request_item_id TEXT NOT NULL,
  asset_id TEXT NOT NULL,
  internal_code_snapshot TEXT,
  description_snapshot TEXT NOT NULL,
  serial_number_snapshot TEXT,
  license_plate_snapshot TEXT,
  category_id TEXT,
  category_code_snapshot TEXT,
  category_name_snapshot TEXT,
  category_nature_snapshot TEXT,
  requires_return_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(requires_return_snapshot IN (0,1)),
  unit_of_measure_snapshot TEXT,
  quantity_snapshot REAL NOT NULL CHECK(quantity_snapshot > 0),
  frozen_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(request_id, request_item_id)
);

CREATE INDEX ix_request_history_person ON request_history_snapshot(requester_person_id, frozen_at DESC);
CREATE INDEX ix_request_item_history_request ON request_item_history_snapshot(request_id, request_item_id);
CREATE INDEX ix_request_item_history_asset ON request_item_history_snapshot(asset_id, request_id);

-- Backfill de todo pedido ya finalizado en instalaciones existentes.
INSERT OR IGNORE INTO request_history_snapshot(
  request_id,requester_person_id,requester_name_snapshot,requester_username_snapshot,
  site_id,site_code_snapshot,site_name_snapshot,location_id,location_code_snapshot,location_name_snapshot,
  frozen_status,frozen_at,created_at
)
SELECT r.id,r.requester_person_id,p.full_name,ua.username,
       r.site_id,s.code,s.name,r.location_id,sl.code,sl.name,
       r.status,COALESCE(r.updated_at,r.created_at),COALESCE(r.updated_at,r.created_at)
FROM request r
JOIN person p ON p.id=r.requester_person_id
LEFT JOIN user_account ua ON ua.person_id=r.requester_person_id
JOIN site s ON s.id=r.site_id
JOIN storage_location sl ON sl.id=r.location_id
WHERE r.status IN ('CANCELADA','EXPIRADA','ENTREGADA');

INSERT OR IGNORE INTO request_item_history_snapshot(
  id,request_id,request_item_id,asset_id,internal_code_snapshot,description_snapshot,
  serial_number_snapshot,license_plate_snapshot,category_id,category_code_snapshot,
  category_name_snapshot,category_nature_snapshot,requires_return_snapshot,unit_of_measure_snapshot,
  quantity_snapshot,frozen_at,created_at
)
SELECT lower(hex(randomblob(16))),ri.request_id,ri.id,ri.asset_id,a.internal_code,a.description,
       a.serial_number,a.license_plate,a.category_id,ac.code,ac.name,ac.nature,ac.requires_return,
       a.unit_of_measure,ri.quantity,COALESCE(r.updated_at,r.created_at),COALESCE(r.updated_at,r.created_at)
FROM request_item ri
JOIN request r ON r.id=ri.request_id
JOIN asset a ON a.id=ri.asset_id
JOIN asset_category ac ON ac.id=a.category_id
WHERE r.status IN ('CANCELADA','EXPIRADA','ENTREGADA');

-- Congela automáticamente cuando la solicitud pasa por primera vez a estado final.
CREATE TRIGGER request_history_freeze_after_status
AFTER UPDATE OF status ON request
WHEN NEW.status IN ('CANCELADA','EXPIRADA','ENTREGADA')
 AND OLD.status <> NEW.status
BEGIN
  INSERT OR IGNORE INTO request_history_snapshot(
    request_id,requester_person_id,requester_name_snapshot,requester_username_snapshot,
    site_id,site_code_snapshot,site_name_snapshot,location_id,location_code_snapshot,location_name_snapshot,
    frozen_status,frozen_at,created_at
  )
  SELECT NEW.id,NEW.requester_person_id,p.full_name,ua.username,
         NEW.site_id,s.code,s.name,NEW.location_id,sl.code,sl.name,
         NEW.status,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM person p
  LEFT JOIN user_account ua ON ua.person_id=NEW.requester_person_id
  JOIN site s ON s.id=NEW.site_id
  JOIN storage_location sl ON sl.id=NEW.location_id
  WHERE p.id=NEW.requester_person_id;

  INSERT OR IGNORE INTO request_item_history_snapshot(
    id,request_id,request_item_id,asset_id,internal_code_snapshot,description_snapshot,
    serial_number_snapshot,license_plate_snapshot,category_id,category_code_snapshot,
    category_name_snapshot,category_nature_snapshot,requires_return_snapshot,unit_of_measure_snapshot,
    quantity_snapshot,frozen_at,created_at
  )
  SELECT lower(hex(randomblob(16))),ri.request_id,ri.id,ri.asset_id,a.internal_code,a.description,
         a.serial_number,a.license_plate,a.category_id,ac.code,ac.name,ac.nature,ac.requires_return,
         a.unit_of_measure,ri.quantity,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM request_item ri
  JOIN asset a ON a.id=ri.asset_id
  JOIN asset_category ac ON ac.id=a.category_id
  WHERE ri.request_id=NEW.id;
END;

-- Defensa: una vez congelado, el histórico visible no se reescribe ni se elimina.
CREATE TRIGGER request_history_snapshot_immutable_update
BEFORE UPDATE ON request_history_snapshot
BEGIN SELECT RAISE(ABORT, 'REQUEST_HISTORY_SNAPSHOT_IMMUTABLE'); END;

CREATE TRIGGER request_history_snapshot_immutable_delete
BEFORE DELETE ON request_history_snapshot
BEGIN SELECT RAISE(ABORT, 'REQUEST_HISTORY_SNAPSHOT_IMMUTABLE'); END;

CREATE TRIGGER request_item_history_snapshot_immutable_update
BEFORE UPDATE ON request_item_history_snapshot
BEGIN SELECT RAISE(ABORT, 'REQUEST_ITEM_HISTORY_SNAPSHOT_IMMUTABLE'); END;

CREATE TRIGGER request_item_history_snapshot_immutable_delete
BEFORE DELETE ON request_item_history_snapshot
BEGIN SELECT RAISE(ABORT, 'REQUEST_ITEM_HISTORY_SNAPSHOT_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS request_item_history_snapshot_immutable_delete;
DROP TRIGGER IF EXISTS request_item_history_snapshot_immutable_update;
DROP TRIGGER IF EXISTS request_history_snapshot_immutable_delete;
DROP TRIGGER IF EXISTS request_history_snapshot_immutable_update;
DROP TRIGGER IF EXISTS request_history_freeze_after_status;
DROP INDEX IF EXISTS ix_request_item_history_asset;
DROP INDEX IF EXISTS ix_request_item_history_request;
DROP INDEX IF EXISTS ix_request_history_person;
DROP TABLE IF EXISTS request_item_history_snapshot;
DROP TABLE IF EXISTS request_history_snapshot;
