-- +up
PRAGMA foreign_keys = ON;

-- F24 / Fase 8: devolución vehicular en dos etapas.
-- Técnico -> Supervisor asignado -> Pañol recibe llaves.
CREATE TABLE vehicle_return_supervision (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL UNIQUE REFERENCES custody(id),
  request_id TEXT NOT NULL REFERENCES request(id),
  vehicle_asset_id TEXT NOT NULL REFERENCES asset(id),
  requester_user_id TEXT NOT NULL REFERENCES user_account(id),
  requester_person_id TEXT NOT NULL REFERENCES person(id),
  supervisor_user_id TEXT NOT NULL REFERENCES user_account(id),
  supervisor_person_id TEXT NOT NULL REFERENCES person(id),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','APROBADA')),
  technician_condition_snapshot TEXT NOT NULL CHECK(technician_condition_snapshot IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  technician_problem_reported_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(technician_problem_reported_snapshot IN (0,1)),
  technician_comment_snapshot TEXT,
  return_checklist_json TEXT NOT NULL DEFAULT '{}',
  return_odometer_snapshot REAL NOT NULL CHECK(return_odometer_snapshot >= 0),
  return_fuel_percent_snapshot REAL NOT NULL CHECK(return_fuel_percent_snapshot BETWEEN 0 AND 100),
  supervisor_comment TEXT,
  safety_observation INTEGER NOT NULL DEFAULT 0 CHECK(safety_observation IN (0,1)),
  security_block_id TEXT REFERENCES operational_block(id),
  requested_at TEXT NOT NULL,
  inspected_at TEXT,
  inspected_by_user_id TEXT REFERENCES user_account(id),
  warehouse_authorized_at TEXT,
  warehouse_received_at TEXT,
  warehouse_received_by_user_id TEXT REFERENCES user_account(id),
  warehouse_handover_id TEXT REFERENCES handover(id),
  request_correlation_id TEXT NOT NULL,
  decision_correlation_id TEXT,
  warehouse_correlation_id TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(requester_user_id <> supervisor_user_id),
  CHECK((status='PENDIENTE' AND inspected_at IS NULL AND inspected_by_user_id IS NULL AND warehouse_authorized_at IS NULL)
     OR (status='APROBADA' AND inspected_at IS NOT NULL AND inspected_by_user_id IS NOT NULL AND warehouse_authorized_at IS NOT NULL)),
  CHECK(safety_observation=0 OR (supervisor_comment IS NOT NULL AND length(trim(supervisor_comment)) >= 3))
);

CREATE INDEX ix_vehicle_return_supervision_supervisor
  ON vehicle_return_supervision(supervisor_user_id,status,requested_at);
CREATE INDEX ix_vehicle_return_supervision_asset
  ON vehicle_return_supervision(vehicle_asset_id,requested_at DESC);
CREATE INDEX ix_vehicle_return_supervision_requester
  ON vehicle_return_supervision(requester_user_id,requested_at DESC);

CREATE TABLE vehicle_return_supervision_event (
  id TEXT PRIMARY KEY,
  supervision_id TEXT NOT NULL REFERENCES vehicle_return_supervision(id),
  custody_id TEXT NOT NULL REFERENCES custody(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('SOLICITADA','VISTO_BUENO','SEGURIDAD_BLOQUEADA','RECIBIDA_PANOL')),
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  from_status TEXT,
  to_status TEXT,
  comment TEXT,
  safety_observation INTEGER NOT NULL DEFAULT 0 CHECK(safety_observation IN (0,1)),
  block_id TEXT REFERENCES operational_block(id),
  correlation_id TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_vehicle_return_supervision_event
  ON vehicle_return_supervision_event(supervision_id,occurred_at);

CREATE TRIGGER vehicle_return_supervision_snapshot_immutable
BEFORE UPDATE ON vehicle_return_supervision
WHEN NEW.custody_id <> OLD.custody_id
  OR NEW.request_id <> OLD.request_id
  OR NEW.vehicle_asset_id <> OLD.vehicle_asset_id
  OR NEW.requester_user_id <> OLD.requester_user_id
  OR NEW.requester_person_id <> OLD.requester_person_id
  OR NEW.supervisor_user_id <> OLD.supervisor_user_id
  OR NEW.supervisor_person_id <> OLD.supervisor_person_id
  OR NEW.technician_condition_snapshot <> OLD.technician_condition_snapshot
  OR NEW.technician_problem_reported_snapshot <> OLD.technician_problem_reported_snapshot
  OR ifnull(NEW.technician_comment_snapshot,'') <> ifnull(OLD.technician_comment_snapshot,'')
  OR NEW.return_checklist_json <> OLD.return_checklist_json
  OR NEW.return_odometer_snapshot <> OLD.return_odometer_snapshot
  OR NEW.return_fuel_percent_snapshot <> OLD.return_fuel_percent_snapshot
  OR NEW.requested_at <> OLD.requested_at
  OR NEW.request_correlation_id <> OLD.request_correlation_id
  OR NEW.created_at <> OLD.created_at
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_SUPERVISION_SNAPSHOT_IMMUTABLE');
END;

CREATE TRIGGER vehicle_return_supervision_decision_immutable
BEFORE UPDATE ON vehicle_return_supervision
WHEN OLD.inspected_at IS NOT NULL AND (
     NEW.status <> OLD.status
  OR ifnull(NEW.supervisor_comment,'') <> ifnull(OLD.supervisor_comment,'')
  OR NEW.safety_observation <> OLD.safety_observation
  OR ifnull(NEW.security_block_id,'') <> ifnull(OLD.security_block_id,'')
  OR ifnull(NEW.inspected_at,'') <> ifnull(OLD.inspected_at,'')
  OR ifnull(NEW.inspected_by_user_id,'') <> ifnull(OLD.inspected_by_user_id,'')
  OR ifnull(NEW.warehouse_authorized_at,'') <> ifnull(OLD.warehouse_authorized_at,'')
  OR ifnull(NEW.decision_correlation_id,'') <> ifnull(OLD.decision_correlation_id,'')
)
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_SUPERVISION_DECISION_IMMUTABLE');
END;

CREATE TRIGGER vehicle_return_supervision_no_delete
BEFORE DELETE ON vehicle_return_supervision
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_SUPERVISION_IMMUTABLE');
END;

CREATE TRIGGER vehicle_return_supervision_event_no_update
BEFORE UPDATE ON vehicle_return_supervision_event
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_SUPERVISION_EVENT_IMMUTABLE');
END;

CREATE TRIGGER vehicle_return_supervision_event_no_delete
BEFORE DELETE ON vehicle_return_supervision_event
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_RETURN_SUPERVISION_EVENT_IMMUTABLE');
END;

-- Permisos explícitos para separar Supervisor de Pañol.
INSERT OR IGNORE INTO permission(id,code,name,module,action,created_at,updated_at)
VALUES (lower(hex(randomblob(16))),'Vehicles.SuperviseReturn','Dar V°B° de Supervisor a devoluciones vehiculares','Vehicles','SuperviseReturn',datetime('now'),datetime('now'));
INSERT OR IGNORE INTO permission(id,code,name,module,action,created_at,updated_at)
VALUES (lower(hex(randomblob(16))),'Vehicles.ReceiveReturnKeys','Recibir llaves de vehículos con V°B° de Supervisor','Vehicles','ReceiveReturnKeys',datetime('now'),datetime('now'));

INSERT OR IGNORE INTO role_permission(role_id,permission_id,created_at)
SELECT r.id,p.id,datetime('now') FROM role r JOIN permission p ON p.code='Vehicles.SuperviseReturn'
WHERE r.code IN ('SUPERVISOR','ADMINISTRADOR','ADMIN_GENERAL');
INSERT OR IGNORE INTO role_permission(role_id,permission_id,created_at)
SELECT r.id,p.id,datetime('now') FROM role r JOIN permission p ON p.code='Vehicles.ReceiveReturnKeys'
WHERE r.code IN ('PANOLERO','ADMINISTRADOR','ADMIN_GENERAL');

-- No se inventa backfill para devoluciones vehiculares anteriores a F24.
-- Las que ya estaban DEVOLUCION_DECLARADA antes de aplicar F24 deberán seguir
-- siendo visibles como legado; el servicio las distingue sin adjudicar un V°B° inexistente.

-- +down
DELETE FROM role_permission WHERE permission_id IN (SELECT id FROM permission WHERE code IN ('Vehicles.SuperviseReturn','Vehicles.ReceiveReturnKeys'));
DELETE FROM permission WHERE code IN ('Vehicles.SuperviseReturn','Vehicles.ReceiveReturnKeys');
DROP TRIGGER IF EXISTS vehicle_return_supervision_event_no_delete;
DROP TRIGGER IF EXISTS vehicle_return_supervision_event_no_update;
DROP TRIGGER IF EXISTS vehicle_return_supervision_no_delete;
DROP TRIGGER IF EXISTS vehicle_return_supervision_decision_immutable;
DROP TRIGGER IF EXISTS vehicle_return_supervision_snapshot_immutable;
DROP INDEX IF EXISTS ix_vehicle_return_supervision_event;
DROP TABLE IF EXISTS vehicle_return_supervision_event;
DROP INDEX IF EXISTS ix_vehicle_return_supervision_requester;
DROP INDEX IF EXISTS ix_vehicle_return_supervision_asset;
DROP INDEX IF EXISTS ix_vehicle_return_supervision_supervisor;
DROP TABLE IF EXISTS vehicle_return_supervision;
