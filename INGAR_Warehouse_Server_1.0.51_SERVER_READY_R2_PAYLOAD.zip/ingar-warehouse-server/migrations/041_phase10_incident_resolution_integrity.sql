-- +up
PRAGMA foreign_keys = ON;

-- F26 / Fase 10
-- La causa raíz es opcional. La resolución, en cambio, debe existir siempre
-- que el incidente esté RESUELTO o CERRADO. Se refuerza a nivel SQL para que
-- ninguna ruta alternativa pueda dejar un incidente resuelto sin texto.
CREATE TRIGGER incident_resolution_required_insert
BEFORE INSERT ON incident
WHEN NEW.status IN ('RESUELTO','CERRADO') AND length(trim(coalesce(NEW.resolution_notes,''))) < 1
BEGIN
  SELECT RAISE(ABORT, 'INCIDENT_RESOLUTION_REQUIRED');
END;

CREATE TRIGGER incident_resolution_required_update
BEFORE UPDATE OF status,resolution_notes ON incident
WHEN NEW.status IN ('RESUELTO','CERRADO') AND length(trim(coalesce(NEW.resolution_notes,''))) < 1
BEGIN
  SELECT RAISE(ABORT, 'INCIDENT_RESOLUTION_REQUIRED');
END;

-- +down
DROP TRIGGER IF EXISTS incident_resolution_required_update;
DROP TRIGGER IF EXISTS incident_resolution_required_insert;
