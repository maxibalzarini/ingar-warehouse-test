-- +up
PRAGMA foreign_keys = ON;

-- F27 / Fase 11: OT obligatoria configurable por bien y congelada por ítem del pedido.
ALTER TABLE asset ADD COLUMN requires_work_order INTEGER NOT NULL DEFAULT 0 CHECK(requires_work_order IN (0,1));
ALTER TABLE request_item ADD COLUMN work_order_required INTEGER NOT NULL DEFAULT 0 CHECK(work_order_required IN (0,1));
ALTER TABLE request_item ADD COLUMN work_order_reference TEXT;
ALTER TABLE request_item_history_snapshot ADD COLUMN work_order_required_snapshot INTEGER CHECK(work_order_required_snapshot IN (0,1));
ALTER TABLE request_item_history_snapshot ADD COLUMN work_order_reference_snapshot TEXT;

CREATE INDEX ix_asset_requires_work_order ON asset(requires_work_order, active, status);
CREATE INDEX ix_request_item_work_order ON request_item(work_order_required, work_order_reference);

-- Ningún ítem nuevo puede declarar que no requiere OT si el maestro vigente sí la exige.
CREATE TRIGGER request_item_work_order_requirement_insert
BEFORE INSERT ON request_item
WHEN (SELECT requires_work_order FROM asset WHERE id=NEW.asset_id)=1 AND NEW.work_order_required<>1
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REQUIREMENT_SNAPSHOT_REQUIRED'); END;

-- Si el snapshot del ítem exige OT, la referencia debe existir y contener texto útil.
CREATE TRIGGER request_item_work_order_reference_insert
BEFORE INSERT ON request_item
WHEN NEW.work_order_required=1 AND trim(COALESCE(NEW.work_order_reference,''))=''
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REFERENCE_REQUIRED'); END;

CREATE TRIGGER request_item_work_order_reference_update
BEFORE UPDATE OF work_order_required,work_order_reference,asset_id ON request_item
WHEN NEW.work_order_required=1 AND trim(COALESCE(NEW.work_order_reference,''))=''
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REFERENCE_REQUIRED'); END;

CREATE TRIGGER request_item_work_order_requirement_update
BEFORE UPDATE OF work_order_required,asset_id ON request_item
WHEN (SELECT requires_work_order FROM asset WHERE id=NEW.asset_id)=1 AND NEW.work_order_required<>1
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REQUIREMENT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER request_item_work_order_reference_length_insert
BEFORE INSERT ON request_item
WHEN length(trim(COALESCE(NEW.work_order_reference,'')))>120
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REFERENCE_TOO_LONG'); END;

CREATE TRIGGER request_item_work_order_reference_length_update
BEFORE UPDATE OF work_order_reference ON request_item
WHEN length(trim(COALESCE(NEW.work_order_reference,'')))>120
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REFERENCE_TOO_LONG'); END;

-- F11 no aplica a vehículos: evita contaminar el flujo vehicular F8/F9 incluso ante escritura directa.
CREATE TRIGGER asset_vehicle_work_order_insert
BEFORE INSERT ON asset
WHEN NEW.requires_work_order=1
 AND (SELECT nature FROM asset_category WHERE id=NEW.category_id)='VEHICULO'
BEGIN SELECT RAISE(ABORT, 'VEHICLE_WORK_ORDER_NOT_APPLICABLE'); END;

CREATE TRIGGER asset_vehicle_work_order_update
BEFORE UPDATE OF requires_work_order,category_id ON asset
WHEN NEW.requires_work_order=1
 AND (SELECT nature FROM asset_category WHERE id=NEW.category_id)='VEHICULO'
BEGIN SELECT RAISE(ABORT, 'VEHICLE_WORK_ORDER_NOT_APPLICABLE'); END;

-- Una vez que el pedido dejó la ventana editable, su OT queda congelada.
CREATE TRIGGER request_item_work_order_locked_after_request_progress
BEFORE UPDATE OF work_order_required,work_order_reference ON request_item
WHEN EXISTS (
  SELECT 1 FROM request r
  WHERE r.id=OLD.request_id
    AND r.status NOT IN ('PENDIENTE_AUTORIZACION','BLOQUEADA')
)
AND (
  COALESCE(NEW.work_order_required,-1)<>COALESCE(OLD.work_order_required,-1)
  OR COALESCE(NEW.work_order_reference,'')<>COALESCE(OLD.work_order_reference,'')
)
BEGIN SELECT RAISE(ABORT, 'WORK_ORDER_REFERENCE_LOCKED'); END;

-- Reemplaza el trigger F20 para incorporar el snapshot de OT en pedidos que cierren desde F27.
DROP TRIGGER IF EXISTS request_history_freeze_after_status;
CREATE TRIGGER request_history_freeze_after_status
AFTER UPDATE OF status ON request
WHEN NEW.status IN ('CANCELADA','EXPIRADA','ENTREGADA')
 AND OLD.status <> NEW.status
BEGIN
  INSERT OR IGNORE INTO request_history_snapshot(
    request_id,requester_person_id,requester_name_snapshot,requester_username_snapshot,
    site_id,site_code_snapshot,site_name_snapshot,location_id,location_code_snapshot,location_name_snapshot,
    frozen_status,frozen_at,created_at
  )
  SELECT NEW.id,NEW.requester_person_id,p.full_name,ua.username,
         NEW.site_id,s.code,s.name,NEW.location_id,sl.code,sl.name,
         NEW.status,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM person p
  LEFT JOIN user_account ua ON ua.person_id=NEW.requester_person_id
  JOIN site s ON s.id=NEW.site_id
  JOIN storage_location sl ON sl.id=NEW.location_id
  WHERE p.id=NEW.requester_person_id;

  INSERT OR IGNORE INTO request_item_history_snapshot(
    id,request_id,request_item_id,asset_id,internal_code_snapshot,description_snapshot,
    serial_number_snapshot,license_plate_snapshot,category_id,category_code_snapshot,
    category_name_snapshot,category_nature_snapshot,requires_return_snapshot,unit_of_measure_snapshot,
    quantity_snapshot,work_order_required_snapshot,work_order_reference_snapshot,frozen_at,created_at
  )
  SELECT lower(hex(randomblob(16))),ri.request_id,ri.id,ri.asset_id,a.internal_code,a.description,
         a.serial_number,a.license_plate,a.category_id,ac.code,ac.name,ac.nature,ac.requires_return,
         a.unit_of_measure,ri.quantity,ri.work_order_required,ri.work_order_reference,
         COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM request_item ri
  JOIN asset a ON a.id=ri.asset_id
  JOIN asset_category ac ON ac.id=a.category_id
  WHERE ri.request_id=NEW.id;
END;

-- +down
DROP TRIGGER IF EXISTS request_history_freeze_after_status;
DROP TRIGGER IF EXISTS request_item_work_order_locked_after_request_progress;
DROP TRIGGER IF EXISTS asset_vehicle_work_order_update;
DROP TRIGGER IF EXISTS asset_vehicle_work_order_insert;
DROP TRIGGER IF EXISTS request_item_work_order_reference_length_update;
DROP TRIGGER IF EXISTS request_item_work_order_reference_length_insert;
DROP TRIGGER IF EXISTS request_item_work_order_requirement_update;
DROP TRIGGER IF EXISTS request_item_work_order_reference_update;
DROP TRIGGER IF EXISTS request_item_work_order_reference_insert;
DROP TRIGGER IF EXISTS request_item_work_order_requirement_insert;
DROP INDEX IF EXISTS ix_request_item_work_order;
DROP INDEX IF EXISTS ix_asset_requires_work_order;
-- SQLite no soporta DROP COLUMN de forma compatible con todas las instalaciones objetivo.
