-- +up
PRAGMA foreign_keys = ON;

-- F21 / Fase 5: baja y deshabilitación controladas, con prechequeo, exportación
-- previa y trazabilidad inmutable. La baja sigue siendo lógica: nunca elimina
-- físicamente user_account/person ni sus relaciones históricas.
CREATE TABLE user_lifecycle_event (
  id TEXT PRIMARY KEY,
  target_user_id TEXT NOT NULL REFERENCES user_account(id),
  target_person_id TEXT NOT NULL REFERENCES person(id),
  target_username_snapshot TEXT NOT NULL,
  target_name_snapshot TEXT NOT NULL,
  action TEXT NOT NULL CHECK(action IN ('DISABLE','TERMINATE')),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPLIED','CANCELLED','EXPIRED')),
  requested_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  requested_at TEXT NOT NULL,
  target_user_version_snapshot INTEGER NOT NULL,
  request_count_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(request_count_snapshot >= 0),
  historical_request_count_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(historical_request_count_snapshot >= 0),
  active_request_count_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(active_request_count_snapshot >= 0),
  open_custody_count_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(open_custody_count_snapshot >= 0),
  pending_warehouse_return_count_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(pending_warehouse_return_count_snapshot >= 0),
  applied_by_user_id TEXT REFERENCES user_account(id),
  applied_at TEXT,
  reason TEXT,
  result_snapshot_json TEXT,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_user_lifecycle_target ON user_lifecycle_event(target_user_id, requested_at DESC);
CREATE INDEX ix_user_lifecycle_status ON user_lifecycle_event(status, action, requested_at DESC);

CREATE TABLE user_lifecycle_export (
  id TEXT PRIMARY KEY,
  lifecycle_event_id TEXT NOT NULL REFERENCES user_lifecycle_event(id),
  target_user_id TEXT NOT NULL REFERENCES user_account(id),
  export_scope TEXT NOT NULL CHECK(export_scope IN ('REQUEST_HISTORY','PENDING_WAREHOUSE_RETURNS','ALL')),
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  row_count INTEGER NOT NULL DEFAULT 0 CHECK(row_count >= 0),
  generated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  generated_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_user_lifecycle_export_event ON user_lifecycle_export(lifecycle_event_id, generated_at DESC);
CREATE INDEX ix_user_lifecycle_export_target ON user_lifecycle_export(target_user_id, generated_at DESC);

-- Un evento ya aplicado es evidencia histórica y no puede reescribirse.
CREATE TRIGGER user_lifecycle_event_applied_immutable
BEFORE UPDATE ON user_lifecycle_event
WHEN OLD.status = 'APPLIED'
BEGIN
  SELECT RAISE(ABORT, 'USER_LIFECYCLE_EVENT_APPLIED_IMMUTABLE');
END;

CREATE TRIGGER user_lifecycle_event_no_delete
BEFORE DELETE ON user_lifecycle_event
BEGIN
  SELECT RAISE(ABORT, 'USER_LIFECYCLE_EVENT_IMMUTABLE');
END;

CREATE TRIGGER user_lifecycle_export_no_update
BEFORE UPDATE ON user_lifecycle_export
BEGIN
  SELECT RAISE(ABORT, 'USER_LIFECYCLE_EXPORT_IMMUTABLE');
END;

CREATE TRIGGER user_lifecycle_export_no_delete
BEFORE DELETE ON user_lifecycle_export
BEGIN
  SELECT RAISE(ABORT, 'USER_LIFECYCLE_EXPORT_IMMUTABLE');
END;

-- Defensa en profundidad: la aplicación trabaja con baja lógica. Un DELETE físico
-- sobre identidad destruiría referencias históricas y queda prohibido a nivel DB.
CREATE TRIGGER user_account_no_physical_delete
BEFORE DELETE ON user_account
BEGIN
  SELECT RAISE(ABORT, 'USER_ACCOUNT_PHYSICAL_DELETE_FORBIDDEN');
END;

CREATE TRIGGER person_no_physical_delete
BEFORE DELETE ON person
BEGIN
  SELECT RAISE(ABORT, 'PERSON_PHYSICAL_DELETE_FORBIDDEN');
END;

-- +down
DROP TRIGGER IF EXISTS person_no_physical_delete;
DROP TRIGGER IF EXISTS user_account_no_physical_delete;
DROP TRIGGER IF EXISTS user_lifecycle_export_no_delete;
DROP TRIGGER IF EXISTS user_lifecycle_export_no_update;
DROP TRIGGER IF EXISTS user_lifecycle_event_no_delete;
DROP TRIGGER IF EXISTS user_lifecycle_event_applied_immutable;
DROP INDEX IF EXISTS ix_user_lifecycle_export_target;
DROP INDEX IF EXISTS ix_user_lifecycle_export_event;
DROP TABLE IF EXISTS user_lifecycle_export;
DROP INDEX IF EXISTS ix_user_lifecycle_status;
DROP INDEX IF EXISTS ix_user_lifecycle_target;
DROP TABLE IF EXISTS user_lifecycle_event;
