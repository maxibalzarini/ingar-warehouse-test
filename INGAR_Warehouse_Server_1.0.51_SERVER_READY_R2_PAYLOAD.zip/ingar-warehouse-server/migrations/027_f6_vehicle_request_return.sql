-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE vehicle_request_detail (
  request_id TEXT PRIMARY KEY REFERENCES request(id),
  vehicle_asset_id TEXT NOT NULL REFERENCES asset(id),
  driver_person_id TEXT NOT NULL REFERENCES person(id),
  companion_name TEXT,
  destination TEXT NOT NULL,
  expected_return_at TEXT NOT NULL,
  departure_odometer REAL NOT NULL CHECK(departure_odometer >= 0),
  departure_fuel_percent REAL NOT NULL CHECK(departure_fuel_percent BETWEEN 0 AND 100),
  departure_condition TEXT NOT NULL CHECK(departure_condition IN ('CONFORME','OBSERVADO')),
  departure_checklist_json TEXT NOT NULL DEFAULT '{}',
  departure_notes TEXT,
  disclaimer_accepted INTEGER NOT NULL DEFAULT 0 CHECK(disclaimer_accepted IN (0,1)),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX ix_vehicle_request_asset ON vehicle_request_detail(vehicle_asset_id, created_at DESC);
CREATE INDEX ix_vehicle_request_driver ON vehicle_request_detail(driver_person_id, created_at DESC);

CREATE TABLE vehicle_return_detail (
  custody_id TEXT PRIMARY KEY REFERENCES custody(id),
  request_id TEXT NOT NULL REFERENCES request(id),
  vehicle_asset_id TEXT NOT NULL REFERENCES asset(id),
  driver_person_id TEXT NOT NULL REFERENCES person(id),
  return_odometer REAL NOT NULL CHECK(return_odometer >= 0),
  return_fuel_percent REAL NOT NULL CHECK(return_fuel_percent BETWEEN 0 AND 100),
  return_condition TEXT NOT NULL CHECK(return_condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  return_checklist_json TEXT NOT NULL DEFAULT '{}',
  problem_reported INTEGER NOT NULL DEFAULT 0 CHECK(problem_reported IN (0,1)),
  notes TEXT,
  declared_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  declared_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_vehicle_return_asset ON vehicle_return_detail(vehicle_asset_id, declared_at DESC);

-- +down
DROP INDEX IF EXISTS ix_vehicle_return_asset;
DROP TABLE IF EXISTS vehicle_return_detail;
DROP INDEX IF EXISTS ix_vehicle_request_driver;
DROP INDEX IF EXISTS ix_vehicle_request_asset;
DROP TABLE IF EXISTS vehicle_request_detail;
