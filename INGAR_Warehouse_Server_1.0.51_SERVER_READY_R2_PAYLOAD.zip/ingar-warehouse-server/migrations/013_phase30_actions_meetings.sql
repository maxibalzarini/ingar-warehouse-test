-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE management_action (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  scope_type TEXT NOT NULL CHECK(scope_type IN ('GLOBAL','SITE','LOCATION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  title TEXT NOT NULL,
  problem TEXT NOT NULL,
  cause_code TEXT NOT NULL CHECK(cause_code IN ('OPERATIVA','FALTA_DISPONIBILIDAD','DEMORA_APROBACION','DEMORA_PREPARACION','DEMORA_USUARIO','FALTA_CAPACITACION','FALLA_ACTIVO','MANTENIMIENTO','COMPRA_REPOSICION','PLANIFICACION','OTRA','PENDIENTE_ANALISIS')),
  cause_detail TEXT,
  action_text TEXT NOT NULL,
  expected_result TEXT NOT NULL,
  indicator_code TEXT REFERENCES management_indicator_definition(code),
  priority TEXT NOT NULL CHECK(priority IN ('BAJA','MEDIA','ALTA','URGENTE')),
  assigned_person_id TEXT REFERENCES person(id),
  assigned_role_id TEXT REFERENCES role(id),
  assigned_sector TEXT,
  responsible_manager_person_id TEXT REFERENCES person(id),
  verifier_person_id TEXT REFERENCES person(id),
  target_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','EN_CURSO','CERRADA')),
  progress_percent INTEGER NOT NULL DEFAULT 0 CHECK(progress_percent BETWEEN 0 AND 100),
  actual_result TEXT,
  no_evidence_justification TEXT,
  source_meeting_id TEXT,
  closed_at TEXT,
  closed_by_user_id TEXT REFERENCES user_account(id),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (
    (scope_type='GLOBAL' AND site_id IS NULL AND location_id IS NULL) OR
    (scope_type='SITE' AND site_id IS NOT NULL AND location_id IS NULL) OR
    (scope_type='LOCATION' AND site_id IS NOT NULL AND location_id IS NOT NULL)
  ),
  CHECK(assigned_person_id IS NOT NULL OR assigned_role_id IS NOT NULL OR TRIM(IFNULL(assigned_sector,''))<>'')
);

CREATE TABLE management_action_relation (
  id TEXT PRIMARY KEY,
  action_id TEXT NOT NULL REFERENCES management_action(id),
  entity_type TEXT NOT NULL CHECK(entity_type IN ('INDICATOR','ASSET','TOOL','CONSUMABLE','PERSON','SECTOR','INCIDENT','MAINTENANCE','REQUEST','CUSTODY','BUDGET','PURCHASE','LOCATION','SITE','OTHER')),
  entity_id TEXT,
  label TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL
);

CREATE TABLE management_action_evidence (
  id TEXT PRIMARY KEY,
  action_id TEXT NOT NULL REFERENCES management_action(id),
  evidence_id TEXT REFERENCES file_evidence(id),
  evidence_type TEXT NOT NULL CHECK(evidence_type IN ('FILE','NOTE','REFERENCE','INTERNAL_LINK')),
  description TEXT,
  reference_value TEXT,
  added_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  CHECK(
    (evidence_type='FILE' AND evidence_id IS NOT NULL) OR
    (evidence_type<>'FILE' AND TRIM(IFNULL(reference_value,''))<>'')
  ),
  UNIQUE(action_id,evidence_id)
);

CREATE TABLE management_action_event (
  id TEXT PRIMARY KEY,
  action_id TEXT NOT NULL REFERENCES management_action(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('CREACION','ACTUALIZACION','ASIGNACION','EVIDENCIA','CAMBIO_ESTADO','CIERRE','CORRECCION')),
  from_status TEXT,
  to_status TEXT,
  details TEXT NOT NULL,
  metadata_json TEXT,
  actor_user_id TEXT REFERENCES user_account(id),
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE management_meeting (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  scope_type TEXT NOT NULL CHECK(scope_type IN ('GLOBAL','SITE','LOCATION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  meeting_type TEXT NOT NULL CHECK(meeting_type IN ('SEMANAL','MENSUAL')),
  title TEXT NOT NULL,
  meeting_date TEXT NOT NULL,
  period_from TEXT NOT NULL,
  period_to TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(status IN ('BORRADOR','CERRADA')),
  executive_summary TEXT,
  observations TEXT,
  agenda_snapshot_json TEXT NOT NULL DEFAULT '{}',
  integrity_hash TEXT,
  closed_at TEXT,
  closed_by_user_id TEXT REFERENCES user_account(id),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(period_to>=period_from),
  CHECK (
    (scope_type='GLOBAL' AND site_id IS NULL AND location_id IS NULL) OR
    (scope_type='SITE' AND site_id IS NOT NULL AND location_id IS NULL) OR
    (scope_type='LOCATION' AND site_id IS NOT NULL AND location_id IS NOT NULL)
  )
);

CREATE TABLE management_meeting_participant (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL REFERENCES management_meeting(id),
  person_id TEXT REFERENCES person(id),
  display_name TEXT NOT NULL,
  role_in_meeting TEXT,
  attended INTEGER NOT NULL DEFAULT 1 CHECK(attended IN (0,1)),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  UNIQUE(meeting_id,display_name)
);

CREATE TABLE management_meeting_topic (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL REFERENCES management_meeting(id),
  topic_type TEXT NOT NULL CHECK(topic_type IN ('INFORMACION','DECISION_REQUERIDA','ACCION_REQUERIDA')),
  source_type TEXT,
  source_id TEXT,
  title TEXT NOT NULL,
  detail TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL
);

CREATE TABLE management_meeting_decision (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL REFERENCES management_meeting(id),
  decision_text TEXT NOT NULL,
  responsible_person_id TEXT REFERENCES person(id),
  responsible_role_id TEXT REFERENCES role(id),
  responsible_sector TEXT,
  target_date TEXT,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','EJECUTADA','CANCELADA')),
  action_id TEXT REFERENCES management_action(id),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(responsible_person_id IS NOT NULL OR responsible_role_id IS NOT NULL OR TRIM(IFNULL(responsible_sector,''))<>'')
);

CREATE TABLE management_meeting_correction (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL REFERENCES management_meeting(id),
  reason TEXT NOT NULL,
  correction_text TEXT NOT NULL,
  previous_hash TEXT NOT NULL,
  correction_hash TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL
);

CREATE INDEX ix_management_action_scope_status ON management_action(site_id,location_id,status,target_date);
CREATE INDEX ix_management_action_assigned_person ON management_action(assigned_person_id,status,target_date);
CREATE INDEX ix_management_action_assigned_role ON management_action(assigned_role_id,status,target_date);
CREATE INDEX ix_management_action_sector ON management_action(assigned_sector,status,target_date);
CREATE INDEX ix_management_action_indicator ON management_action(indicator_code,status,target_date);
CREATE INDEX ix_management_action_relation_entity ON management_action_relation(entity_type,entity_id);
CREATE UNIQUE INDEX ux_management_action_relation_unique ON management_action_relation(action_id,entity_type,IFNULL(entity_id,''),label);
CREATE INDEX ix_management_action_evidence_action ON management_action_evidence(action_id,created_at);
CREATE INDEX ix_management_action_event_action ON management_action_event(action_id,occurred_at);
CREATE INDEX ix_management_meeting_scope_date ON management_meeting(site_id,location_id,meeting_type,meeting_date);
CREATE INDEX ix_management_meeting_status ON management_meeting(status,meeting_date);
CREATE INDEX ix_management_meeting_topic ON management_meeting_topic(meeting_id,sort_order);
CREATE INDEX ix_management_meeting_decision ON management_meeting_decision(meeting_id,status,target_date);

CREATE TRIGGER management_action_no_delete BEFORE DELETE ON management_action BEGIN SELECT RAISE(ABORT,'MANAGEMENT_ACTION_IMMUTABLE_DELETE'); END;
CREATE TRIGGER management_action_relation_no_delete BEFORE DELETE ON management_action_relation BEGIN SELECT RAISE(ABORT,'MANAGEMENT_ACTION_RELATION_IMMUTABLE_DELETE'); END;
CREATE TRIGGER management_action_evidence_no_delete BEFORE DELETE ON management_action_evidence BEGIN SELECT RAISE(ABORT,'MANAGEMENT_ACTION_EVIDENCE_IMMUTABLE_DELETE'); END;
CREATE TRIGGER management_action_event_no_update BEFORE UPDATE ON management_action_event BEGIN SELECT RAISE(ABORT,'MANAGEMENT_ACTION_EVENT_IMMUTABLE'); END;
CREATE TRIGGER management_action_event_no_delete BEFORE DELETE ON management_action_event BEGIN SELECT RAISE(ABORT,'MANAGEMENT_ACTION_EVENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_closed_no_update BEFORE UPDATE ON management_meeting WHEN OLD.status='CERRADA' BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CLOSED_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_no_delete BEFORE DELETE ON management_meeting BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_IMMUTABLE_DELETE'); END;
CREATE TRIGGER management_meeting_participant_closed_no_update BEFORE UPDATE ON management_meeting_participant WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA') BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_participant_no_delete BEFORE DELETE ON management_meeting_participant BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_topic_closed_no_update BEFORE UPDATE ON management_meeting_topic WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA') BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_topic_no_delete BEFORE DELETE ON management_meeting_topic BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_decision_closed_no_update BEFORE UPDATE ON management_meeting_decision WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA') BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_decision_no_delete BEFORE DELETE ON management_meeting_decision BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_correction_no_update BEFORE UPDATE ON management_meeting_correction BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CORRECTION_IMMUTABLE'); END;
CREATE TRIGGER management_meeting_correction_no_delete BEFORE DELETE ON management_meeting_correction BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CORRECTION_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS management_meeting_correction_no_delete;
DROP TRIGGER IF EXISTS management_meeting_correction_no_update;
DROP TRIGGER IF EXISTS management_meeting_decision_no_delete;
DROP TRIGGER IF EXISTS management_meeting_decision_closed_no_update;
DROP TRIGGER IF EXISTS management_meeting_topic_no_delete;
DROP TRIGGER IF EXISTS management_meeting_topic_closed_no_update;
DROP TRIGGER IF EXISTS management_meeting_participant_no_delete;
DROP TRIGGER IF EXISTS management_meeting_participant_closed_no_update;
DROP TRIGGER IF EXISTS management_meeting_no_delete;
DROP TRIGGER IF EXISTS management_meeting_closed_no_update;
DROP TRIGGER IF EXISTS management_action_event_no_delete;
DROP TRIGGER IF EXISTS management_action_event_no_update;
DROP TRIGGER IF EXISTS management_action_evidence_no_delete;
DROP TRIGGER IF EXISTS management_action_relation_no_delete;
DROP TRIGGER IF EXISTS management_action_no_delete;
DROP INDEX IF EXISTS ix_management_meeting_decision;
DROP INDEX IF EXISTS ix_management_meeting_topic;
DROP INDEX IF EXISTS ix_management_meeting_status;
DROP INDEX IF EXISTS ix_management_meeting_scope_date;
DROP INDEX IF EXISTS ix_management_action_event_action;
DROP INDEX IF EXISTS ix_management_action_evidence_action;
DROP INDEX IF EXISTS ux_management_action_relation_unique;
DROP INDEX IF EXISTS ix_management_action_relation_entity;
DROP INDEX IF EXISTS ix_management_action_indicator;
DROP INDEX IF EXISTS ix_management_action_sector;
DROP INDEX IF EXISTS ix_management_action_assigned_role;
DROP INDEX IF EXISTS ix_management_action_assigned_person;
DROP INDEX IF EXISTS ix_management_action_scope_status;
DROP TABLE IF EXISTS management_meeting_correction;
DROP TABLE IF EXISTS management_meeting_decision;
DROP TABLE IF EXISTS management_meeting_topic;
DROP TABLE IF EXISTS management_meeting_participant;
DROP TABLE IF EXISTS management_meeting;
DROP TABLE IF EXISTS management_action_event;
DROP TABLE IF EXISTS management_action_evidence;
DROP TABLE IF EXISTS management_action_relation;
DROP TABLE IF EXISTS management_action;
