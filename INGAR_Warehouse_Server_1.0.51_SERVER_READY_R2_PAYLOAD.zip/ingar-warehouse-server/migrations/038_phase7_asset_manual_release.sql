-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE asset_manual_release_event (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  prior_status TEXT NOT NULL,
  prior_quantity_available REAL NOT NULL,
  released_status TEXT NOT NULL CHECK(released_status='DISPONIBLE'),
  released_quantity_available REAL NOT NULL,
  reason TEXT NOT NULL,
  lifted_block_ids_json TEXT NOT NULL DEFAULT '[]',
  linked_incident_ids_json TEXT NOT NULL DEFAULT '[]',
  active_incident_count INTEGER NOT NULL DEFAULT 0 CHECK(active_incident_count >= 0),
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  actor_role_snapshot TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  released_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_asset_manual_release_asset ON asset_manual_release_event(asset_id,released_at DESC);
CREATE INDEX ix_asset_manual_release_actor ON asset_manual_release_event(actor_user_id,released_at DESC);
CREATE TRIGGER asset_manual_release_event_immutable_update BEFORE UPDATE ON asset_manual_release_event BEGIN SELECT RAISE(ABORT,'ASSET_MANUAL_RELEASE_EVENT_IMMUTABLE'); END;
CREATE TRIGGER asset_manual_release_event_immutable_delete BEFORE DELETE ON asset_manual_release_event BEGIN SELECT RAISE(ABORT,'ASSET_MANUAL_RELEASE_EVENT_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS asset_manual_release_event_immutable_delete;
DROP TRIGGER IF EXISTS asset_manual_release_event_immutable_update;
DROP INDEX IF EXISTS ix_asset_manual_release_actor;
DROP INDEX IF EXISTS ix_asset_manual_release_asset;
DROP TABLE IF EXISTS asset_manual_release_event;
