-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE custody_return_receipt (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL UNIQUE REFERENCES custody(id),
  handover_id TEXT NOT NULL UNIQUE REFERENCES handover(id),
  return_record_id TEXT NOT NULL UNIQUE REFERENCES custody_return_record(id),
  receipt_number TEXT NOT NULL UNIQUE,
  asset_nature TEXT NOT NULL,
  snapshot_json TEXT NOT NULL,
  snapshot_sha256 TEXT NOT NULL,
  pdf_bytes BLOB NOT NULL,
  pdf_sha256 TEXT NOT NULL,
  pdf_size INTEGER NOT NULL CHECK(pdf_size > 0),
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL
);

CREATE INDEX ix_custody_return_receipt_created ON custody_return_receipt(created_at DESC);

CREATE TRIGGER custody_return_receipt_immutable_update
BEFORE UPDATE ON custody_return_receipt
BEGIN
  SELECT RAISE(ABORT, 'RETURN_RECEIPT_IMMUTABLE');
END;

CREATE TRIGGER custody_return_receipt_immutable_delete
BEFORE DELETE ON custody_return_receipt
BEGIN
  SELECT RAISE(ABORT, 'RETURN_RECEIPT_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS custody_return_receipt_immutable_delete;
DROP TRIGGER IF EXISTS custody_return_receipt_immutable_update;
DROP INDEX IF EXISTS ix_custody_return_receipt_created;
DROP TABLE IF EXISTS custody_return_receipt;
