-- +up
-- Amplía el dominio sin descartar notificaciones ni relaciones históricas.
CREATE TABLE notification_phase2 (
  id TEXT PRIMARY KEY, recipient_person_id TEXT REFERENCES person(id), recipient_user_id TEXT REFERENCES user_account(id),
  type TEXT NOT NULL CHECK(type IN ('MANTENIMIENTO_PROXIMO','MANTENIMIENTO_VENCIDO','CUSTODIA_PROXIMA','CUSTODIA_VENCIDA','DEVOLUCION_DECLARADA','CUSTODIA_ANOMALIA','SOLICITUD_ATRASADA','HABILITACION_PROXIMA','SISTEMA','INCIDENTE','VEHICLE_RETURN_SUPERVISION')),
  channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK(channel IN ('IN_APP','EMAIL')),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA','CANCELADA')),
  subject TEXT NOT NULL, body TEXT NOT NULL, entity_type TEXT, entity_id TEXT, dedup_key TEXT UNIQUE, scheduled_at TEXT NOT NULL, sent_at TEXT, read_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0), last_error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  CHECK(recipient_person_id IS NOT NULL OR recipient_user_id IS NOT NULL)
);
INSERT INTO notification_phase2(
  id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,
  scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
)
SELECT id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,
  scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
FROM notification;
DROP TABLE notification;
ALTER TABLE notification_phase2 RENAME TO notification;
CREATE INDEX ix_notification_recipient ON notification(recipient_user_id,recipient_person_id,status,scheduled_at);
CREATE INDEX ix_notification_entity ON notification(entity_type,entity_id,type);
-- +down
DROP TABLE IF EXISTS notification_phase2;
