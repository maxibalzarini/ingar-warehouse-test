-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE migration_file_integrity (
  version INTEGER PRIMARY KEY REFERENCES schema_migration(version) ON DELETE CASCADE,
  name TEXT NOT NULL,
  file_sha256 TEXT NOT NULL CHECK(length(file_sha256) = 64),
  recorded_at TEXT NOT NULL
);

CREATE TABLE migration_execution (
  id TEXT PRIMARY KEY,
  started_at TEXT NOT NULL,
  finished_at TEXT NOT NULL,
  previous_schema_version INTEGER NOT NULL,
  target_schema_version INTEGER NOT NULL,
  process_name TEXT NOT NULL,
  source_version TEXT,
  backup_ref TEXT,
  backup_sha256 TEXT CHECK(backup_sha256 IS NULL OR length(backup_sha256) = 64),
  backup_manifest_sha256 TEXT CHECK(backup_manifest_sha256 IS NULL OR length(backup_manifest_sha256) = 64),
  status TEXT NOT NULL CHECK(status IN ('APPLIED','FAILED','ROLLED_BACK','RESTORED')),
  migrations_json TEXT NOT NULL,
  error TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_migration_execution_time ON migration_execution(started_at DESC);
CREATE INDEX ix_migration_execution_status ON migration_execution(status, started_at DESC);

CREATE TRIGGER migration_execution_immutable_update
BEFORE UPDATE ON migration_execution
BEGIN
  SELECT RAISE(ABORT, 'MIGRATION_EXECUTION_IMMUTABLE');
END;

CREATE TRIGGER migration_execution_immutable_delete
BEFORE DELETE ON migration_execution
BEGIN
  SELECT RAISE(ABORT, 'MIGRATION_EXECUTION_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS migration_execution_immutable_delete;
DROP TRIGGER IF EXISTS migration_execution_immutable_update;
DROP INDEX IF EXISTS ix_migration_execution_status;
DROP INDEX IF EXISTS ix_migration_execution_time;
DROP TABLE IF EXISTS migration_execution;
DROP TABLE IF EXISTS migration_file_integrity;
