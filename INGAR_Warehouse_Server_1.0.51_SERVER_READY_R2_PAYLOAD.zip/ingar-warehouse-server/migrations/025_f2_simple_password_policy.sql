-- +up
-- F2: política simple para todos los usuarios. No hay expiración ni cambio forzado por complejidad.
UPDATE system_setting
SET value_json = '4',
    version = version + 1,
    updated_at = datetime('now')
WHERE scope_type = 'SYSTEM'
  AND scope_id = 'GLOBAL'
  AND key = 'security.passwordMinLength';

-- +down
UPDATE system_setting
SET value_json = '12',
    version = version + 1,
    updated_at = datetime('now')
WHERE scope_type = 'SYSTEM'
  AND scope_id = 'GLOBAL'
  AND key = 'security.passwordMinLength';
