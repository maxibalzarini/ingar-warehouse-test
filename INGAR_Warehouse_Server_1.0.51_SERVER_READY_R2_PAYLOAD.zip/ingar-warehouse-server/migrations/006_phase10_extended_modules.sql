-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE vehicle_profile (
  asset_id TEXT PRIMARY KEY REFERENCES asset(id),
  vin TEXT COLLATE NOCASE UNIQUE,
  chassis_number TEXT COLLATE NOCASE UNIQUE,
  engine_number TEXT COLLATE NOCASE,
  manufacture_year INTEGER CHECK(manufacture_year IS NULL OR manufacture_year BETWEEN 1900 AND 2200),
  vehicle_class TEXT,
  current_odometer REAL NOT NULL DEFAULT 0 CHECK(current_odometer >= 0),
  current_hourmeter REAL NOT NULL DEFAULT 0 CHECK(current_hourmeter >= 0),
  fuel_type TEXT,
  fuel_capacity REAL CHECK(fuel_capacity IS NULL OR fuel_capacity > 0),
  required_license_class TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE vehicle_driver_authorization (
  id TEXT PRIMARY KEY,
  person_id TEXT NOT NULL REFERENCES person(id),
  vehicle_asset_id TEXT REFERENCES asset(id),
  category_id TEXT REFERENCES asset_category(id),
  license_number TEXT NOT NULL,
  license_class TEXT NOT NULL,
  valid_from TEXT NOT NULL,
  valid_until TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'VIGENTE' CHECK(status IN ('VIGENTE','SUSPENDIDA','VENCIDA','REVOCADA')),
  notes TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(vehicle_asset_id IS NOT NULL OR category_id IS NOT NULL)
);

CREATE TABLE vehicle_operation (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  custody_id TEXT REFERENCES custody(id),
  handover_id TEXT REFERENCES handover(id),
  driver_person_id TEXT NOT NULL REFERENCES person(id),
  operation_type TEXT NOT NULL CHECK(operation_type IN ('ENTREGA','RECEPCION','CONTROL','AJUSTE')),
  odometer REAL NOT NULL CHECK(odometer >= 0),
  hourmeter REAL CHECK(hourmeter IS NULL OR hourmeter >= 0),
  fuel_level_percent REAL CHECK(fuel_level_percent IS NULL OR fuel_level_percent BETWEEN 0 AND 100),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  checklist_json TEXT NOT NULL DEFAULT '{}',
  notes TEXT,
  operator_user_id TEXT NOT NULL REFERENCES user_account(id),
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE kit_definition (
  kit_asset_id TEXT PRIMARY KEY REFERENCES asset(id),
  allow_incomplete_with_authorization INTEGER NOT NULL DEFAULT 0 CHECK(allow_incomplete_with_authorization IN (0,1)),
  notes TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE kit_component (
  id TEXT PRIMARY KEY,
  kit_asset_id TEXT NOT NULL REFERENCES kit_definition(kit_asset_id),
  component_asset_id TEXT NOT NULL REFERENCES asset(id),
  required_quantity REAL NOT NULL CHECK(required_quantity > 0),
  mandatory INTEGER NOT NULL DEFAULT 1 CHECK(mandatory IN (0,1)),
  allow_substitution INTEGER NOT NULL DEFAULT 0 CHECK(allow_substitution IN (0,1)),
  sequence INTEGER NOT NULL DEFAULT 1 CHECK(sequence > 0),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(kit_asset_id, component_asset_id),
  CHECK(kit_asset_id <> component_asset_id)
);

CREATE TABLE kit_custody_component (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL REFERENCES custody(id),
  kit_asset_id TEXT NOT NULL REFERENCES asset(id),
  component_asset_id TEXT NOT NULL REFERENCES asset(id),
  substituted_for_asset_id TEXT REFERENCES asset(id),
  issued_quantity REAL NOT NULL CHECK(issued_quantity > 0),
  returned_quantity REAL NOT NULL DEFAULT 0 CHECK(returned_quantity >= 0),
  missing_quantity REAL NOT NULL DEFAULT 0 CHECK(missing_quantity >= 0),
  condition TEXT NOT NULL DEFAULT 'CONFORME' CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  status TEXT NOT NULL DEFAULT 'ENTREGADO' CHECK(status IN ('ENTREGADO','PARCIALMENTE_DEVUELTO','DEVUELTO','FALTANTE')),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(custody_id, component_asset_id)
);

CREATE TABLE stock_lot (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  location_id TEXT NOT NULL REFERENCES storage_location(id),
  lot_code TEXT NOT NULL COLLATE NOCASE,
  expires_at TEXT,
  quantity_on_hand REAL NOT NULL DEFAULT 0 CHECK(quantity_on_hand >= 0),
  quantity_reserved REAL NOT NULL DEFAULT 0 CHECK(quantity_reserved >= 0 AND quantity_reserved <= quantity_on_hand),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(asset_id, location_id, lot_code)
);

CREATE TABLE stock_movement (
  id TEXT PRIMARY KEY,
  movement_number TEXT NOT NULL UNIQUE,
  client_movement_id TEXT UNIQUE,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  lot_id TEXT NOT NULL REFERENCES stock_lot(id),
  movement_type TEXT NOT NULL CHECK(movement_type IN ('ENTRADA','SALIDA','CONSUMO','DEVOLUCION','AJUSTE_POSITIVO','AJUSTE_NEGATIVO','RESERVA','LIBERACION','TRANSFERENCIA_SALIDA','TRANSFERENCIA_ENTRADA')),
  quantity REAL NOT NULL CHECK(quantity > 0),
  quantity_before REAL NOT NULL,
  quantity_after REAL NOT NULL,
  reserved_before REAL NOT NULL,
  reserved_after REAL NOT NULL,
  reference_type TEXT,
  reference_id TEXT,
  reason TEXT NOT NULL,
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE inventory_count (
  id TEXT PRIMARY KEY,
  count_number TEXT NOT NULL UNIQUE,
  client_count_id TEXT UNIQUE,
  count_type TEXT NOT NULL CHECK(count_type IN ('TOTAL','PARCIAL','CICLICO','RESPONSABLE')),
  status TEXT NOT NULL DEFAULT 'PLANIFICADO' CHECK(status IN ('PLANIFICADO','ABIERTO','CONTEO','CONCILIACION','CERRADO','CANCELADO')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  category_id TEXT REFERENCES asset_category(id),
  responsible_person_id TEXT REFERENCES person(id),
  blind_count INTEGER NOT NULL DEFAULT 0 CHECK(blind_count IN (0,1)),
  notes TEXT,
  planned_at TEXT NOT NULL,
  opened_at TEXT,
  closed_at TEXT,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  opened_by_user_id TEXT REFERENCES user_account(id),
  closed_by_user_id TEXT REFERENCES user_account(id),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE inventory_count_item (
  id TEXT PRIMARY KEY,
  count_id TEXT NOT NULL REFERENCES inventory_count(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  lot_id TEXT REFERENCES stock_lot(id),
  expected_quantity REAL NOT NULL,
  counted_quantity REAL,
  difference_quantity REAL,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','CONTADO','DIFERENCIA','CONCILIADO','AJUSTADO')),
  resolution TEXT CHECK(resolution IS NULL OR resolution IN ('ACEPTAR_CONTEO','MANTENER_SISTEMA','AJUSTAR','INVESTIGAR')),
  resolution_reason TEXT,
  counted_by_user_id TEXT REFERENCES user_account(id),
  counted_at TEXT,
  reconciled_by_user_id TEXT REFERENCES user_account(id),
  reconciled_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(count_id, asset_id, lot_id)
);

CREATE TABLE inventory_adjustment (
  id TEXT PRIMARY KEY,
  count_item_id TEXT NOT NULL UNIQUE REFERENCES inventory_count_item(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  lot_id TEXT REFERENCES stock_lot(id),
  quantity_delta REAL NOT NULL,
  reason TEXT NOT NULL,
  approved_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  stock_movement_id TEXT REFERENCES stock_movement(id),
  created_at TEXT NOT NULL
);

CREATE TABLE inventory_transfer (
  id TEXT PRIMARY KEY,
  transfer_number TEXT NOT NULL UNIQUE,
  client_transfer_id TEXT UNIQUE,
  from_location_id TEXT NOT NULL REFERENCES storage_location(id),
  to_location_id TEXT NOT NULL REFERENCES storage_location(id),
  status TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(status IN ('BORRADOR','DESPACHADA','EN_TRANSITO','RECIBIDA','CANCELADA')),
  reason TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  dispatched_by_user_id TEXT REFERENCES user_account(id),
  received_by_user_id TEXT REFERENCES user_account(id),
  dispatched_at TEXT,
  received_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(from_location_id <> to_location_id)
);

CREATE TABLE inventory_transfer_item (
  id TEXT PRIMARY KEY,
  transfer_id TEXT NOT NULL REFERENCES inventory_transfer(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  source_lot_id TEXT REFERENCES stock_lot(id),
  destination_lot_id TEXT REFERENCES stock_lot(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','DESPACHADO','RECIBIDO','CANCELADO')),
  asset_snapshot_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(transfer_id, asset_id, source_lot_id)
);

CREATE INDEX ix_vehicle_authorization_person ON vehicle_driver_authorization(person_id,status,valid_until);
CREATE INDEX ix_vehicle_operation_asset ON vehicle_operation(asset_id,occurred_at DESC);
CREATE INDEX ix_kit_component_kit ON kit_component(kit_asset_id,active,sequence);
CREATE INDEX ix_kit_custody_component ON kit_custody_component(custody_id,status);
CREATE INDEX ix_stock_lot_asset ON stock_lot(asset_id,location_id,active,expires_at);
CREATE INDEX ix_stock_movement_asset ON stock_movement(asset_id,occurred_at DESC);
CREATE INDEX ix_inventory_count_status ON inventory_count(status,planned_at DESC);
CREATE INDEX ix_inventory_count_item_count ON inventory_count_item(count_id,status);
CREATE INDEX ix_inventory_transfer_status ON inventory_transfer(status,created_at DESC);
CREATE INDEX ix_inventory_transfer_item_transfer ON inventory_transfer_item(transfer_id,status);

CREATE TRIGGER vehicle_operation_immutable_update BEFORE UPDATE ON vehicle_operation BEGIN SELECT RAISE(ABORT, 'VEHICLE_OPERATION_IMMUTABLE'); END;
CREATE TRIGGER vehicle_operation_immutable_delete BEFORE DELETE ON vehicle_operation BEGIN SELECT RAISE(ABORT, 'VEHICLE_OPERATION_IMMUTABLE'); END;
CREATE TRIGGER stock_movement_immutable_update BEFORE UPDATE ON stock_movement BEGIN SELECT RAISE(ABORT, 'STOCK_MOVEMENT_IMMUTABLE'); END;
CREATE TRIGGER stock_movement_immutable_delete BEFORE DELETE ON stock_movement BEGIN SELECT RAISE(ABORT, 'STOCK_MOVEMENT_IMMUTABLE'); END;
CREATE TRIGGER inventory_adjustment_immutable_update BEFORE UPDATE ON inventory_adjustment BEGIN SELECT RAISE(ABORT, 'INVENTORY_ADJUSTMENT_IMMUTABLE'); END;
CREATE TRIGGER inventory_adjustment_immutable_delete BEFORE DELETE ON inventory_adjustment BEGIN SELECT RAISE(ABORT, 'INVENTORY_ADJUSTMENT_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS inventory_adjustment_immutable_delete;
DROP TRIGGER IF EXISTS inventory_adjustment_immutable_update;
DROP TRIGGER IF EXISTS stock_movement_immutable_delete;
DROP TRIGGER IF EXISTS stock_movement_immutable_update;
DROP TRIGGER IF EXISTS vehicle_operation_immutable_delete;
DROP TRIGGER IF EXISTS vehicle_operation_immutable_update;
DROP TABLE IF EXISTS inventory_transfer_item;
DROP TABLE IF EXISTS inventory_transfer;
DROP TABLE IF EXISTS inventory_adjustment;
DROP TABLE IF EXISTS inventory_count_item;
DROP TABLE IF EXISTS inventory_count;
DROP TABLE IF EXISTS stock_movement;
DROP TABLE IF EXISTS stock_lot;
DROP TABLE IF EXISTS kit_custody_component;
DROP TABLE IF EXISTS kit_component;
DROP TABLE IF EXISTS kit_definition;
DROP TABLE IF EXISTS vehicle_operation;
DROP TABLE IF EXISTS vehicle_driver_authorization;
DROP TABLE IF EXISTS vehicle_profile;
