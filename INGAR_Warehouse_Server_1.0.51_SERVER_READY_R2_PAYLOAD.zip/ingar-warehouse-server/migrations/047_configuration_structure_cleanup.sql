-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE site ADD COLUMN deleted_at TEXT;
CREATE INDEX ix_site_active_deleted ON site(active, deleted_at, organization_id);

-- Una ubicación eliminada lógicamente conserva su fila e históricos. Los bienes
-- inactivos pueden seguir referenciándola; sólo los bienes operativos activos
-- impiden retirarla de la configuración.
DROP TRIGGER IF EXISTS storage_location_soft_delete_asset_guard;
CREATE TRIGGER storage_location_soft_delete_asset_guard
BEFORE UPDATE OF deleted_at ON storage_location
WHEN OLD.deleted_at IS NULL
 AND NEW.deleted_at IS NOT NULL
 AND EXISTS (
   SELECT 1 FROM asset a
   WHERE a.location_id = OLD.id
     AND a.deleted_at IS NULL
     AND a.active = 1
 )
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_DELETE_BLOCKED_ASSETS');
END;

-- +down
DROP TRIGGER IF EXISTS storage_location_soft_delete_asset_guard;
CREATE TRIGGER storage_location_soft_delete_asset_guard
BEFORE UPDATE OF deleted_at ON storage_location
WHEN OLD.deleted_at IS NULL
 AND NEW.deleted_at IS NOT NULL
 AND EXISTS (
   SELECT 1 FROM asset a
   WHERE a.location_id = OLD.id
     AND a.deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_DELETE_BLOCKED_ASSETS');
END;
DROP INDEX IF EXISTS ix_site_active_deleted;
ALTER TABLE site DROP COLUMN deleted_at;
