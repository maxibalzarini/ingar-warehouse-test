-- +up
PRAGMA foreign_keys = ON;

-- F5.2: cada recepción parcial de una custodia cuantitativa retornable queda
-- congelada como evento físico independiente. La cantidad original de custody
-- permanece inmutable como cantidad entregada; el saldo se deriva de la suma
-- de estas porciones para no perder trazabilidad histórica.
CREATE TABLE custody_return_portion (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL REFERENCES custody(id),
  handover_id TEXT NOT NULL UNIQUE REFERENCES handover(id),
  inspection_id TEXT NOT NULL UNIQUE REFERENCES inspection(id),
  incident_id TEXT REFERENCES incident(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  remaining_after REAL NOT NULL CHECK(remaining_after >= 0),
  is_final INTEGER NOT NULL DEFAULT 0 CHECK(is_final IN (0,1)),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  notes TEXT,
  received_at TEXT NOT NULL,
  recorded_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  CHECK((is_final=1 AND remaining_after=0) OR (is_final=0 AND remaining_after>0))
);

CREATE INDEX ix_custody_return_portion_custody
  ON custody_return_portion(custody_id, received_at);
CREATE INDEX ix_custody_return_portion_incident
  ON custody_return_portion(incident_id) WHERE incident_id IS NOT NULL;

CREATE TABLE custody_quantity_return_declaration (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL REFERENCES custody(id),
  declared_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  requested_quantity REAL NOT NULL CHECK(requested_quantity > 0),
  actual_received_quantity REAL CHECK(actual_received_quantity IS NULL OR actual_received_quantity > 0),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  problem_reported INTEGER NOT NULL DEFAULT 0 CHECK(problem_reported IN (0,1)),
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','ATENDIDA','CANCELADA')),
  fulfilled_by_portion_id TEXT REFERENCES custody_return_portion(id),
  declared_at TEXT NOT NULL,
  fulfilled_at TEXT,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE UNIQUE INDEX ux_custody_quantity_return_declaration_pending
  ON custody_quantity_return_declaration(custody_id) WHERE status='PENDIENTE';
CREATE INDEX ix_custody_quantity_return_declaration_history
  ON custody_quantity_return_declaration(custody_id, declared_at);

CREATE TRIGGER custody_quantity_return_declaration_no_delete
BEFORE DELETE ON custody_quantity_return_declaration
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_QUANTITY_RETURN_DECLARATION_IMMUTABLE');
END;

CREATE TRIGGER custody_quantity_return_declaration_preserve_source
BEFORE UPDATE ON custody_quantity_return_declaration
WHEN NEW.id IS NOT OLD.id
  OR NEW.custody_id IS NOT OLD.custody_id
  OR NEW.declared_by_user_id IS NOT OLD.declared_by_user_id
  OR NEW.requested_quantity IS NOT OLD.requested_quantity
  OR NEW.condition IS NOT OLD.condition
  OR NEW.problem_reported IS NOT OLD.problem_reported
  OR NEW.notes IS NOT OLD.notes
  OR NEW.declared_at IS NOT OLD.declared_at
  OR NEW.correlation_id IS NOT OLD.correlation_id
  OR NEW.created_at IS NOT OLD.created_at
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_QUANTITY_RETURN_DECLARATION_SOURCE_IMMUTABLE');
END;

CREATE TRIGGER custody_return_portion_immutable_update
BEFORE UPDATE ON custody_return_portion
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RETURN_PORTION_IMMUTABLE');
END;

CREATE TRIGGER custody_return_portion_immutable_delete
BEFORE DELETE ON custody_return_portion
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RETURN_PORTION_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS custody_quantity_return_declaration_preserve_source;
DROP TRIGGER IF EXISTS custody_quantity_return_declaration_no_delete;
DROP INDEX IF EXISTS ix_custody_quantity_return_declaration_history;
DROP INDEX IF EXISTS ux_custody_quantity_return_declaration_pending;
DROP TABLE IF EXISTS custody_quantity_return_declaration;
DROP TRIGGER IF EXISTS custody_return_portion_immutable_delete;
DROP TRIGGER IF EXISTS custody_return_portion_immutable_update;
DROP INDEX IF EXISTS ix_custody_return_portion_incident;
DROP INDEX IF EXISTS ix_custody_return_portion_custody;
DROP TABLE IF EXISTS custody_return_portion;
