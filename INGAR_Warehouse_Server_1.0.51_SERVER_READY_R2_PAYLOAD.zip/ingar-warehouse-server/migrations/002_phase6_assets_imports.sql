-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE asset_category (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL COLLATE NOCASE UNIQUE,
  name TEXT NOT NULL,
  nature TEXT NOT NULL CHECK(nature IN ('SERIADO','CANTIDAD','CONSUMIBLE','KIT','VEHICULO')),
  serialized INTEGER NOT NULL DEFAULT 1 CHECK(serialized IN (0,1)),
  requires_inspection INTEGER NOT NULL DEFAULT 1 CHECK(requires_inspection IN (0,1)),
  requires_return INTEGER NOT NULL DEFAULT 1 CHECK(requires_return IN (0,1)),
  default_unit TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE asset (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL REFERENCES asset_category(id),
  internal_code TEXT NOT NULL COLLATE NOCASE UNIQUE,
  serial_number TEXT COLLATE NOCASE UNIQUE,
  description TEXT NOT NULL,
  brand TEXT,
  model TEXT,
  status TEXT NOT NULL DEFAULT 'DISPONIBLE' CHECK(status IN ('DISPONIBLE','RESERVADO','EN_CUSTODIA','BLOQUEADO','MANTENIMIENTO','PERDIDO','BAJA')),
  location_id TEXT NOT NULL REFERENCES storage_location(id),
  custodian_person_id TEXT REFERENCES person(id),
  quantity_total REAL NOT NULL DEFAULT 1 CHECK(quantity_total >= 0),
  quantity_available REAL NOT NULL DEFAULT 1 CHECK(quantity_available >= 0 AND quantity_available <= quantity_total),
  unit_of_measure TEXT,
  license_plate TEXT COLLATE NOCASE UNIQUE,
  odometer REAL CHECK(odometer IS NULL OR odometer >= 0),
  fuel_type TEXT,
  notes TEXT,
  photo_evidence_id TEXT REFERENCES file_evidence(id),
  source_import_batch_id TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE asset_document (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  evidence_id TEXT NOT NULL REFERENCES file_evidence(id),
  issued_at TEXT,
  expires_at TEXT,
  status TEXT NOT NULL DEFAULT 'VIGENTE' CHECK(status IN ('VIGENTE','VENCIDO','ANULADO')),
  notes TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE import_batch (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL DEFAULT 'ASSET' CHECK(type IN ('ASSET')),
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_evidence_id TEXT REFERENCES file_evidence(id),
  sha256 TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('CARGADA','VALIDADA_CON_ERRORES','VALIDADA','APLICADA','REVERTIDA','FALLIDA')),
  mode TEXT NOT NULL CHECK(mode IN ('CREATE_ONLY','UPDATE_ONLY','CREATE_OR_UPDATE')),
  mapping_json TEXT NOT NULL,
  total_rows INTEGER NOT NULL DEFAULT 0,
  valid_rows INTEGER NOT NULL DEFAULT 0,
  invalid_rows INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  validated_at TEXT,
  applied_at TEXT,
  reverted_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  error TEXT
);

CREATE TABLE import_row (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES import_batch(id),
  row_number INTEGER NOT NULL,
  raw_json TEXT NOT NULL,
  normalized_json TEXT,
  operation TEXT CHECK(operation IN ('CREATE','UPDATE')),
  validation_status TEXT NOT NULL CHECK(validation_status IN ('VALID','INVALID','APPLIED','REVERTED')),
  errors_json TEXT NOT NULL DEFAULT '[]',
  resulting_entity_id TEXT,
  before_json TEXT,
  applied_entity_version INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(batch_id, row_number)
);

CREATE INDEX ix_asset_category_active ON asset_category(active, deleted_at, code);
CREATE INDEX ix_asset_status ON asset(status, active, deleted_at);
CREATE INDEX ix_asset_location ON asset(location_id, status, active);
CREATE INDEX ix_asset_category ON asset(category_id, status, active);
CREATE INDEX ix_asset_document_asset ON asset_document(asset_id, deleted_at, expires_at);
CREATE INDEX ix_import_batch_time ON import_batch(created_at DESC, status);
CREATE INDEX ix_import_row_batch ON import_row(batch_id, row_number);

-- +down
DROP TABLE IF EXISTS import_row;
DROP TABLE IF EXISTS import_batch;
DROP TABLE IF EXISTS asset_document;
DROP TABLE IF EXISTS asset;
DROP TABLE IF EXISTS asset_category;
