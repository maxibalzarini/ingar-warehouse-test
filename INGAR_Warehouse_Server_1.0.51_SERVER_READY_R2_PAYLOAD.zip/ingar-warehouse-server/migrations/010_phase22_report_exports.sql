-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE report_export (
  id TEXT PRIMARY KEY,
  report_execution_id TEXT REFERENCES report_execution(id),
  report_code TEXT NOT NULL,
  report_name TEXT NOT NULL,
  format TEXT NOT NULL CHECK(format IN ('CSV','XLSX','PDF')),
  filename TEXT,
  mime_type TEXT NOT NULL,
  row_count INTEGER NOT NULL DEFAULT 0 CHECK(row_count >= 0),
  byte_size INTEGER NOT NULL DEFAULT 0 CHECK(byte_size >= 0),
  sha256 TEXT,
  generated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  generated_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('SUCCESS','FAILED')),
  duration_ms INTEGER NOT NULL DEFAULT 0 CHECK(duration_ms >= 0),
  error_code TEXT,
  correlation_id TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_report_export_user_time ON report_export(generated_by_user_id, generated_at DESC);
CREATE INDEX ix_report_export_code_time ON report_export(report_code, generated_at DESC);
CREATE INDEX ix_report_export_format_time ON report_export(format, generated_at DESC);

-- +down
DROP TABLE IF EXISTS report_export;
