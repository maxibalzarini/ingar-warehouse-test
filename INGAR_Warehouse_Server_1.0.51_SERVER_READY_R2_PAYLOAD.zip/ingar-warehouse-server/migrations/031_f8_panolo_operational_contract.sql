-- +up
-- F8: contrato operativo mínimo del perfil PANOLERO.
-- Idempotente: repara bases existentes sin borrar permisos adicionales ni overrides individuales.
INSERT OR IGNORE INTO role_permission(role_id, permission_id, created_at)
SELECT r.id, p.id, datetime('now')
FROM role r CROSS JOIN permission p
WHERE r.code='PANOLERO'
  AND p.code IN (
    'Auth.Self','Assets.Read',
    'Requests.Availability','Requests.Create','Requests.ReadOwn','Requests.UpdateOwn','Requests.CancelOwn','Requests.ReadAll','Requests.Approve',
    'Warehouse.Prepare','Warehouse.Operate',
    'Custody.ReadOwn','Custody.ReadAll','Custody.ReturnOwn','Custody.TransferOwn','Custody.Extend','Custody.TransferAny',
    'Incident.Read','Incident.Create','Incident.Evidence',
    'Blocks.Read','Blocks.Manage','Blocks.Exception.Request',
    'Vehicles.Read','Vehicles.Operate','Kits.Read','Kits.Operate',
    'Stock.Read','Stock.Operate','Stock.Adjust','Inventory.Read','Inventory.Execute','Inventory.Reconcile',
    'Transfers.Read','Transfers.Create','Transfers.Dispatch','Transfers.Receive','Transfers.Cancel',
    'Maintenance.Read','Maintenance.Execute','Maintenance.Complete','Notifications.Read','Reports.Read','Reports.Generate'
  );

-- +down
-- Reparación canónica de permisos del rol PANOLERO: rollback deliberadamente no destructivo.
SELECT 1;
