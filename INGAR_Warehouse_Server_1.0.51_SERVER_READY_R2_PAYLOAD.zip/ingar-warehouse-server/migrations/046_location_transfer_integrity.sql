-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE asset_location_transfer (
  id TEXT PRIMARY KEY,
  transfer_number TEXT NOT NULL UNIQUE,
  source_location_id TEXT NOT NULL REFERENCES storage_location(id),
  destination_location_id TEXT NOT NULL REFERENCES storage_location(id),
  mode TEXT NOT NULL CHECK(mode IN ('SELECTED','ALL','EMPTY_AND_DEACTIVATE')),
  item_count INTEGER NOT NULL CHECK(item_count > 0),
  reason TEXT,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  CHECK(source_location_id <> destination_location_id)
);

CREATE TABLE asset_location_transfer_item (
  id TEXT PRIMARY KEY,
  transfer_id TEXT NOT NULL REFERENCES asset_location_transfer(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  asset_code_snapshot TEXT NOT NULL,
  asset_description_snapshot TEXT NOT NULL,
  asset_status_snapshot TEXT NOT NULL,
  source_location_id TEXT NOT NULL REFERENCES storage_location(id),
  destination_location_id TEXT NOT NULL REFERENCES storage_location(id),
  asset_version_before INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(transfer_id, asset_id),
  CHECK(source_location_id <> destination_location_id)
);

CREATE INDEX ix_asset_location_transfer_source ON asset_location_transfer(source_location_id, created_at DESC);
CREATE INDEX ix_asset_location_transfer_destination ON asset_location_transfer(destination_location_id, created_at DESC);
CREATE INDEX ix_asset_location_transfer_item_asset ON asset_location_transfer_item(asset_id, created_at DESC);

CREATE TRIGGER asset_location_transfer_immutable_update BEFORE UPDATE ON asset_location_transfer BEGIN SELECT RAISE(ABORT,'ASSET_LOCATION_TRANSFER_IMMUTABLE'); END;
CREATE TRIGGER asset_location_transfer_immutable_delete BEFORE DELETE ON asset_location_transfer BEGIN SELECT RAISE(ABORT,'ASSET_LOCATION_TRANSFER_IMMUTABLE'); END;
CREATE TRIGGER asset_location_transfer_item_immutable_update BEFORE UPDATE ON asset_location_transfer_item BEGIN SELECT RAISE(ABORT,'ASSET_LOCATION_TRANSFER_ITEM_IMMUTABLE'); END;
CREATE TRIGGER asset_location_transfer_item_immutable_delete BEFORE DELETE ON asset_location_transfer_item BEGIN SELECT RAISE(ABORT,'ASSET_LOCATION_TRANSFER_ITEM_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS asset_location_transfer_item_immutable_delete;
DROP TRIGGER IF EXISTS asset_location_transfer_item_immutable_update;
DROP TRIGGER IF EXISTS asset_location_transfer_immutable_delete;
DROP TRIGGER IF EXISTS asset_location_transfer_immutable_update;
DROP INDEX IF EXISTS ix_asset_location_transfer_item_asset;
DROP INDEX IF EXISTS ix_asset_location_transfer_destination;
DROP INDEX IF EXISTS ix_asset_location_transfer_source;
DROP TABLE IF EXISTS asset_location_transfer_item;
DROP TABLE IF EXISTS asset_location_transfer;
