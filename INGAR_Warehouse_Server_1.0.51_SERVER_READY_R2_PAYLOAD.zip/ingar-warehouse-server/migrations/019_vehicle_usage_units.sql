-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE vehicle_profile ADD COLUMN usage_unit TEXT NOT NULL DEFAULT 'KILOMETROS'
  CHECK(usage_unit IN ('KILOMETROS','HORAS'));
ALTER TABLE vehicle_profile ADD COLUMN km_per_hour REAL NOT NULL DEFAULT 50
  CHECK(km_per_hour > 0);

-- +down
ALTER TABLE vehicle_profile DROP COLUMN km_per_hour;
ALTER TABLE vehicle_profile DROP COLUMN usage_unit;
