-- +up
-- Conserva quién habilitó disponibilidad administrativa y por qué, sin inferir
-- condición física desde observaciones de importación históricas.
CREATE TABLE asset_availability_review_event (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  prior_status TEXT NOT NULL,
  prior_quantity_available REAL NOT NULL,
  released_quantity_available REAL NOT NULL,
  reason TEXT NOT NULL,
  source TEXT NOT NULL CHECK(source IN ('PREVENTIVE_IMPORT_REVIEW','ADMINISTRATIVE_REVIEW')),
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  correlation_id TEXT,
  reviewed_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX ix_asset_availability_review_asset ON asset_availability_review_event(asset_id, reviewed_at DESC);
-- +down
DROP TABLE IF EXISTS asset_availability_review_event;
