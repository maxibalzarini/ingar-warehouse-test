-- +up
PRAGMA foreign_keys = ON;

-- F19/Fase 3: diferencia explícita entre alta inicial y blanqueo de contraseña.
-- must_change_password se conserva por compatibilidad; credential_setup_reason define
-- por qué la cuenta requiere completar credenciales sin reutilizar la identidad.
ALTER TABLE user_account ADD COLUMN credential_setup_reason TEXT NOT NULL DEFAULT 'NONE'
  CHECK(credential_setup_reason IN ('NONE','INITIAL_SETUP','PASSWORD_RESET'));

UPDATE user_account
SET credential_setup_reason = CASE
  WHEN must_change_password = 0 THEN 'NONE'
  WHEN last_login_at IS NOT NULL THEN 'PASSWORD_RESET'
  WHEN (SELECT COUNT(*) FROM password_history ph WHERE ph.user_id = user_account.id) > 1 THEN 'PASSWORD_RESET'
  ELSE 'INITIAL_SETUP'
END;

-- Evento específico de blanqueo. No contiene contraseña ni hash recuperable.
-- Congela la identidad y el supervisor vigentes para demostrar que el blanqueo
-- no recreó la cuenta ni alteró la cadena histórica.
CREATE TABLE password_reset_event (
  id TEXT PRIMARY KEY,
  target_user_id TEXT NOT NULL REFERENCES user_account(id),
  target_person_id TEXT NOT NULL REFERENCES person(id),
  target_username_snapshot TEXT NOT NULL,
  reset_by_user_id TEXT REFERENCES user_account(id),
  supervisor_user_id_snapshot TEXT REFERENCES user_account(id),
  reset_mode TEXT NOT NULL CHECK(reset_mode IN ('USER_SETUP','DIRECT_ADMIN_SET','BATCH_USER_SETUP','LOCAL_ADMIN_RECOVERY')),
  authority_scope TEXT NOT NULL CHECK(authority_scope IN ('SELF','DIRECT_SUPERVISOR','ADMINISTRATIVE','LOCAL_RECOVERY','SYSTEM')),
  status TEXT NOT NULL CHECK(status IN ('PENDING','COMPLETED','CANCELLED')),
  requested_at TEXT NOT NULL,
  completed_at TEXT,
  completion_source TEXT,
  created_at TEXT NOT NULL,
  CHECK((status = 'COMPLETED' AND completed_at IS NOT NULL) OR status <> 'COMPLETED')
);

CREATE INDEX ix_password_reset_event_target
  ON password_reset_event(target_user_id, requested_at DESC);

CREATE INDEX ix_password_reset_event_actor
  ON password_reset_event(reset_by_user_id, requested_at DESC);

-- Defensa en profundidad: mientras una cuenta está en PASSWORD_RESET, ningún
-- camino de código puede aprovechar ese estado para cambiar user_id/person_id/username.
CREATE TRIGGER user_identity_immutable_during_password_reset
BEFORE UPDATE OF person_id, username ON user_account
WHEN OLD.credential_setup_reason = 'PASSWORD_RESET'
 AND (NEW.person_id <> OLD.person_id OR NEW.username <> OLD.username)
BEGIN
  SELECT RAISE(ABORT, 'PASSWORD_RESET_IDENTITY_IMMUTABLE');
END;

CREATE UNIQUE INDEX ux_password_reset_event_pending
  ON password_reset_event(target_user_id)
  WHERE status = 'PENDING';

-- Registra como pendientes los accesos ya blanqueados antes de F19 cuando es posible
-- distinguirlos de un alta inicial por la existencia de un login previo.
INSERT INTO password_reset_event(
  id, target_user_id, target_person_id, target_username_snapshot,
  reset_by_user_id, supervisor_user_id_snapshot, reset_mode, authority_scope,
  status, requested_at, completed_at, completion_source, created_at
)
SELECT lower(hex(randomblob(16))), ua.id, ua.person_id, ua.username,
       NULL,
       (
         SELECT usa.supervisor_user_id
         FROM user_supervisor_assignment usa
         WHERE usa.user_id = ua.id AND usa.effective_to IS NULL
         ORDER BY usa.effective_from DESC LIMIT 1
       ),
       'USER_SETUP', 'SYSTEM', 'PENDING',
       COALESCE(ua.updated_at, datetime('now')), NULL, NULL,
       COALESCE(ua.updated_at, datetime('now'))
FROM user_account ua
WHERE ua.deleted_at IS NULL
  AND ua.must_change_password = 1
  AND ua.credential_setup_reason = 'PASSWORD_RESET';

-- +down
DROP TRIGGER IF EXISTS user_identity_immutable_during_password_reset;
DROP INDEX IF EXISTS ux_password_reset_event_pending;
DROP INDEX IF EXISTS ix_password_reset_event_actor;
DROP INDEX IF EXISTS ix_password_reset_event_target;
DROP TABLE IF EXISTS password_reset_event;
-- SQLite no permite DROP COLUMN de forma compatible con todas las instalaciones
-- soportadas por el producto; el downgrade conserva credential_setup_reason.
