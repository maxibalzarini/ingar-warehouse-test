-- +up
-- F5: declaración estructurada de devolución iniciada por el custodio para bienes SERIADO.
CREATE TABLE custody_return_declaration (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL UNIQUE REFERENCES custody(id),
  declared_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  problem_reported INTEGER NOT NULL DEFAULT 0 CHECK(problem_reported IN (0,1)),
  notes TEXT,
  declared_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_custody_return_declaration_user
  ON custody_return_declaration(declared_by_user_id, declared_at DESC);

-- +down
DROP INDEX IF EXISTS ix_custody_return_declaration_user;
DROP TABLE IF EXISTS custody_return_declaration;
