-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE audit_archive_segment (
  id TEXT PRIMARY KEY,
  sequence_no INTEGER NOT NULL UNIQUE,
  created_at TEXT NOT NULL,
  cutoff_at TEXT NOT NULL,
  first_event_id TEXT NOT NULL,
  first_occurred_at TEXT NOT NULL,
  first_previous_hash TEXT,
  first_hash TEXT NOT NULL,
  last_event_id TEXT NOT NULL,
  last_occurred_at TEXT NOT NULL,
  last_hash TEXT NOT NULL,
  event_count INTEGER NOT NULL CHECK(event_count > 0),
  archive_ref TEXT NOT NULL UNIQUE,
  archive_sha256 TEXT NOT NULL,
  compressed_size INTEGER NOT NULL CHECK(compressed_size > 0),
  uncompressed_size INTEGER NOT NULL CHECK(uncompressed_size > 0),
  status TEXT NOT NULL CHECK(status = 'VERIFIED'),
  verified_at TEXT NOT NULL
);
CREATE INDEX ix_audit_archive_segment_time ON audit_archive_segment(first_occurred_at, last_occurred_at);

CREATE TABLE audit_retention_authorization (
  event_id TEXT PRIMARY KEY,
  segment_id TEXT NOT NULL REFERENCES audit_archive_segment(id),
  evidence_hash TEXT NOT NULL,
  authorized_at TEXT NOT NULL
);

CREATE TRIGGER audit_archive_segment_immutable_update
BEFORE UPDATE ON audit_archive_segment
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_ARCHIVE_IMMUTABLE');
END;

CREATE TRIGGER audit_archive_segment_immutable_delete
BEFORE DELETE ON audit_archive_segment
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_ARCHIVE_IMMUTABLE');
END;

DROP TRIGGER IF EXISTS audit_event_immutable_delete;
CREATE TRIGGER audit_event_retention_delete_guard
BEFORE DELETE ON audit_event
WHEN NOT EXISTS (
  SELECT 1
  FROM audit_retention_authorization ara
  JOIN audit_archive_segment aas ON aas.id = ara.segment_id AND aas.status = 'VERIFIED'
  WHERE ara.event_id = OLD.id AND ara.evidence_hash = OLD.evidence_hash
)
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

CREATE TRIGGER audit_event_retention_cleanup
AFTER DELETE ON audit_event
BEGIN
  DELETE FROM audit_retention_authorization WHERE event_id = OLD.id;
END;

-- +down
DROP TRIGGER IF EXISTS audit_event_retention_cleanup;
DROP TRIGGER IF EXISTS audit_event_retention_delete_guard;
CREATE TRIGGER audit_event_immutable_delete
BEFORE DELETE ON audit_event
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;
DROP TRIGGER IF EXISTS audit_archive_segment_immutable_delete;
DROP TRIGGER IF EXISTS audit_archive_segment_immutable_update;
DROP TABLE IF EXISTS audit_retention_authorization;
DROP TABLE IF EXISTS audit_archive_segment;
