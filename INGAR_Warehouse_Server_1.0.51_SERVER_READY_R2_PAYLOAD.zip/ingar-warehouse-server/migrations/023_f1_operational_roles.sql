-- +up
-- F1: contrato operativo del rol PANOLERO.
-- La devolución de serializados/vehículos queda iniciada por el custodio en código de servicio.
DELETE FROM role_permission
WHERE role_id = (SELECT id FROM role WHERE code='PANOLERO');

INSERT OR IGNORE INTO role_permission(role_id, permission_id, created_at)
SELECT r.id, p.id, datetime('now')
FROM role r
JOIN permission p ON p.code IN (
  'Auth.Self', 'Assets.Read', 'Requests.Availability', 'Requests.ReadAll', 'Warehouse.Prepare', 'Warehouse.Operate', 'Custody.ReadAll', 'Custody.ReturnOwn', 'Custody.Extend', 'Custody.TransferAny', 'Incident.Read', 'Incident.Create', 'Incident.Evidence', 'Blocks.Read', 'Blocks.Manage', 'Blocks.Exception.Request', 'Vehicles.Read', 'Vehicles.Operate', 'Kits.Read', 'Kits.Operate', 'Stock.Read', 'Stock.Operate', 'Stock.Adjust', 'Inventory.Read', 'Inventory.Execute', 'Inventory.Reconcile', 'Transfers.Read', 'Transfers.Create', 'Transfers.Dispatch', 'Transfers.Receive', 'Transfers.Cancel', 'Maintenance.Read', 'Maintenance.Execute', 'Maintenance.Complete', 'Notifications.Read', 'Reports.Read', 'Reports.Generate'
)
WHERE r.code='PANOLERO';

-- +down
-- No se restaura el perfil histórico automáticamente: una reversión de permisos requiere decisión administrativa explícita.
