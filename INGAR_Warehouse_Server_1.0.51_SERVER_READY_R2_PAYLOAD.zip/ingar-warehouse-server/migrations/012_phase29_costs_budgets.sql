-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE economic_currency (
  code TEXT PRIMARY KEY COLLATE NOCASE,
  name TEXT NOT NULL,
  minor_units INTEGER NOT NULL DEFAULT 2 CHECK(minor_units BETWEEN 0 AND 4),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT OR IGNORE INTO economic_currency(code,name,minor_units,active,created_at,updated_at)
VALUES
  ('ARS','Peso argentino',2,1,datetime('now'),datetime('now')),
  ('USD','Dólar estadounidense',2,1,datetime('now'),datetime('now')),
  ('EUR','Euro',2,1,datetime('now'),datetime('now'));

CREATE TABLE economic_budget (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  scope_type TEXT NOT NULL CHECK(scope_type IN ('GLOBAL','SITE','LOCATION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  sector TEXT,
  cost_center TEXT,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  approved_amount_minor INTEGER NOT NULL CHECK(approved_amount_minor >= 0),
  responsible_user_id TEXT REFERENCES user_account(id),
  status TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(status IN ('BORRADOR','ACTIVO','CERRADO')),
  observations TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(period_end >= period_start),
  CHECK(
    (scope_type='GLOBAL' AND site_id IS NULL AND location_id IS NULL) OR
    (scope_type='SITE' AND site_id IS NOT NULL AND location_id IS NULL) OR
    (scope_type='LOCATION' AND site_id IS NOT NULL AND location_id IS NOT NULL)
  )
);

CREATE UNIQUE INDEX ux_economic_budget_active_exact_scope ON economic_budget(
  organization_id,scope_type,IFNULL(site_id,''),IFNULL(location_id,''),IFNULL(sector,''),IFNULL(cost_center,''),category,currency_code,period_start,period_end
) WHERE status='ACTIVO';
CREATE INDEX ix_economic_budget_period ON economic_budget(period_start,period_end,status,currency_code);
CREATE INDEX ix_economic_budget_scope ON economic_budget(site_id,location_id,sector,cost_center,status);

CREATE TABLE economic_purchase (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  site_id TEXT NOT NULL REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  sector TEXT,
  concept TEXT NOT NULL,
  provider TEXT,
  requested_at TEXT NOT NULL,
  estimated_amount_minor INTEGER NOT NULL DEFAULT 0 CHECK(estimated_amount_minor >= 0),
  committed_amount_minor INTEGER NOT NULL DEFAULT 0 CHECK(committed_amount_minor >= 0),
  executed_amount_minor INTEGER NOT NULL DEFAULT 0 CHECK(executed_amount_minor >= 0),
  currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  budget_id TEXT REFERENCES economic_budget(id),
  status TEXT NOT NULL DEFAULT 'BORRADOR' CHECK(status IN ('BORRADOR','SOLICITADA','COMPROMETIDA','PARCIAL','RECIBIDA','CANCELADA','CERRADA')),
  document_reference TEXT,
  responsible_user_id TEXT REFERENCES user_account(id),
  observations TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(executed_amount_minor <= CASE WHEN committed_amount_minor > 0 THEN committed_amount_minor ELSE 9223372036854775807 END)
);
CREATE INDEX ix_economic_purchase_scope ON economic_purchase(site_id,location_id,sector,status,currency_code);
CREATE INDEX ix_economic_purchase_budget ON economic_purchase(budget_id,status);

CREATE TABLE economic_cost_record (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  site_id TEXT NOT NULL REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  sector TEXT,
  cost_center TEXT,
  occurred_on TEXT NOT NULL,
  cost_type TEXT NOT NULL CHECK(cost_type IN ('ADQUISICION','REPOSICION','REPARACION','MANTENIMIENTO','REPUESTOS','SERVICIO_EXTERNO','INCIDENTE','HERRAMIENTA_DANADA','HERRAMIENTA_PERDIDA','CONSUMIBLE','COMPRA','OTRO')),
  description TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK(amount_minor >= 0),
  currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  provider TEXT,
  document_reference TEXT,
  asset_id TEXT REFERENCES asset(id),
  lot_id TEXT REFERENCES stock_lot(id),
  incident_id TEXT REFERENCES incident(id),
  maintenance_order_id TEXT REFERENCES maintenance_order(id),
  purchase_id TEXT REFERENCES economic_purchase(id),
  budget_id TEXT REFERENCES economic_budget(id),
  entry_kind TEXT NOT NULL DEFAULT 'NORMAL' CHECK(entry_kind IN ('NORMAL','REVERSA','CORRECCION')),
  sign INTEGER NOT NULL DEFAULT 1 CHECK(sign IN (-1,1)),
  reversal_of_id TEXT REFERENCES economic_cost_record(id),
  correction_of_id TEXT REFERENCES economic_cost_record(id),
  status TEXT NOT NULL DEFAULT 'EJECUTADO' CHECK(status IN ('BORRADOR','COMPROMETIDO','EJECUTADO','REVERSADO','ANULADO')),
  reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK((entry_kind='REVERSA' AND sign=-1 AND reversal_of_id IS NOT NULL) OR (entry_kind<>'REVERSA' AND sign=1 AND reversal_of_id IS NULL)),
  CHECK(entry_kind<>'CORRECCION' OR correction_of_id IS NOT NULL)
);
CREATE UNIQUE INDEX ux_economic_cost_single_reversal ON economic_cost_record(reversal_of_id) WHERE reversal_of_id IS NOT NULL;
CREATE INDEX ix_economic_cost_scope_date ON economic_cost_record(site_id,location_id,sector,occurred_on,currency_code,status);
CREATE INDEX ix_economic_cost_asset ON economic_cost_record(asset_id,occurred_on,status);
CREATE INDEX ix_economic_cost_budget ON economic_cost_record(budget_id,occurred_on,status);
CREATE INDEX ix_economic_cost_purchase ON economic_cost_record(purchase_id,status);

CREATE TABLE economic_stock_price (
  id TEXT PRIMARY KEY,
  lot_id TEXT NOT NULL UNIQUE REFERENCES stock_lot(id),
  unit_cost_minor INTEGER NOT NULL CHECK(unit_cost_minor >= 0),
  currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  valuation_method TEXT NOT NULL DEFAULT 'LOTE' CHECK(valuation_method='LOTE'),
  valid_from TEXT NOT NULL,
  source TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX ix_economic_stock_price_currency ON economic_stock_price(currency_code,valid_from);

CREATE TABLE asset_economic_profile (
  asset_id TEXT PRIMARY KEY REFERENCES asset(id),
  acquisition_amount_minor INTEGER CHECK(acquisition_amount_minor IS NULL OR acquisition_amount_minor >= 0),
  replacement_amount_minor INTEGER CHECK(replacement_amount_minor IS NULL OR replacement_amount_minor >= 0),
  currency_code TEXT REFERENCES economic_currency(code),
  acquired_on TEXT,
  expected_life_months INTEGER CHECK(expected_life_months IS NULL OR expected_life_months >= 0),
  remaining_life_months INTEGER CHECK(remaining_life_months IS NULL OR remaining_life_months >= 0),
  updated_value_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  updated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK((acquisition_amount_minor IS NULL AND replacement_amount_minor IS NULL) OR currency_code IS NOT NULL)
);

CREATE TABLE economic_exchange_rate (
  id TEXT PRIMARY KEY,
  base_currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  quote_currency_code TEXT NOT NULL REFERENCES economic_currency(code),
  rate REAL NOT NULL CHECK(rate > 0),
  effective_on TEXT NOT NULL,
  source TEXT NOT NULL,
  responsible_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  CHECK(base_currency_code <> quote_currency_code),
  UNIQUE(base_currency_code,quote_currency_code,effective_on)
);

CREATE TRIGGER economic_cost_no_delete BEFORE DELETE ON economic_cost_record
BEGIN SELECT RAISE(ABORT,'ECONOMIC_COST_IMMUTABLE'); END;
CREATE TRIGGER economic_budget_no_delete BEFORE DELETE ON economic_budget
BEGIN SELECT RAISE(ABORT,'ECONOMIC_BUDGET_NO_DELETE'); END;
CREATE TRIGGER economic_purchase_no_delete BEFORE DELETE ON economic_purchase
BEGIN SELECT RAISE(ABORT,'ECONOMIC_PURCHASE_NO_DELETE'); END;

-- +down
DROP TRIGGER IF EXISTS economic_purchase_no_delete;
DROP TRIGGER IF EXISTS economic_budget_no_delete;
DROP TRIGGER IF EXISTS economic_cost_no_delete;
DROP TABLE IF EXISTS economic_exchange_rate;
DROP TABLE IF EXISTS asset_economic_profile;
DROP INDEX IF EXISTS ix_economic_stock_price_currency;
DROP TABLE IF EXISTS economic_stock_price;
DROP INDEX IF EXISTS ix_economic_cost_purchase;
DROP INDEX IF EXISTS ix_economic_cost_budget;
DROP INDEX IF EXISTS ix_economic_cost_asset;
DROP INDEX IF EXISTS ix_economic_cost_scope_date;
DROP INDEX IF EXISTS ux_economic_cost_single_reversal;
DROP TABLE IF EXISTS economic_cost_record;
DROP INDEX IF EXISTS ix_economic_purchase_budget;
DROP INDEX IF EXISTS ix_economic_purchase_scope;
DROP TABLE IF EXISTS economic_purchase;
DROP INDEX IF EXISTS ix_economic_budget_scope;
DROP INDEX IF EXISTS ix_economic_budget_period;
DROP INDEX IF EXISTS ux_economic_budget_active_exact_scope;
DROP TABLE IF EXISTS economic_budget;
DROP TABLE IF EXISTS economic_currency;
