-- +up
-- F2: los solicitantes que todavía nunca ingresaron configuran su propio usuario y contraseña en el primer acceso.
UPDATE user_account
SET must_change_password = 1,
    failed_attempts = 0,
    locked_until = NULL,
    updated_at = datetime('now'),
    version = version + 1
WHERE last_login_at IS NULL
  AND deleted_at IS NULL
  AND active = 1
  AND EXISTS (
    SELECT 1 FROM user_role_scope urs
    JOIN role r ON r.id = urs.role_id
    WHERE urs.user_id = user_account.id AND r.code = 'SOLICITANTE'
  );

-- +down
-- No se revierte automáticamente porque algunos usuarios pueden haber completado su primer acceso.
