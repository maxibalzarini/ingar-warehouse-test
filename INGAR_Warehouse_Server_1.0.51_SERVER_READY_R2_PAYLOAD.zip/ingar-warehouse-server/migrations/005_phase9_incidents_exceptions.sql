-- +up
PRAGMA foreign_keys = ON;

DROP INDEX IF EXISTS ix_incident_status;
ALTER TABLE incident RENAME TO incident_phase8_legacy;

CREATE TABLE incident (
  id TEXT PRIMARY KEY,
  incident_number TEXT NOT NULL UNIQUE,
  client_incident_id TEXT UNIQUE,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  custody_id TEXT REFERENCES custody(id),
  inspection_id TEXT REFERENCES inspection(id),
  type TEXT NOT NULL CHECK(type IN ('DANO','FALTANTE','CONDICION_INSEGURA','PERDIDA','ROBO','INCUMPLIMIENTO','OTRO')),
  severity TEXT NOT NULL CHECK(severity IN ('BAJA','MEDIA','ALTA','CRITICA')),
  status TEXT NOT NULL DEFAULT 'ABIERTO' CHECK(status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO','CERRADO')),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  reported_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  opened_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  assigned_to_user_id TEXT REFERENCES user_account(id),
  liability_person_id TEXT REFERENCES person(id),
  occurred_at TEXT,
  detected_at TEXT NOT NULL,
  opened_at TEXT NOT NULL,
  investigation_started_at TEXT,
  resolved_at TEXT,
  closed_at TEXT,
  resolution_code TEXT CHECK(resolution_code IS NULL OR resolution_code IN ('RECUPERADO_CONFORME','RECUPERADO_BLOQUEADO','REPARACION_REQUERIDA','BAJA_DEFINITIVA','SIN_RECUPERACION','SIN_RESPONSABILIDAD','RESPONSABILIDAD_DETERMINADA','OTRA')),
  root_cause TEXT,
  resolution_notes TEXT,
  estimated_cost REAL CHECK(estimated_cost IS NULL OR estimated_cost >= 0),
  actual_cost REAL CHECK(actual_cost IS NULL OR actual_cost >= 0),
  recovered_at TEXT,
  recovery_condition TEXT CHECK(recovery_condition IS NULL OR recovery_condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  asset_snapshot_json TEXT NOT NULL DEFAULT '{}',
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT INTO incident(
  id,incident_number,client_incident_id,asset_id,custody_id,inspection_id,type,severity,status,title,description,
  reported_by_user_id,opened_by_user_id,detected_at,opened_at,closed_at,asset_snapshot_json,version,created_at,updated_at
)
SELECT id,
  'INC-' || upper(substr(replace(id,'-',''),1,12)),
  NULL,
  asset_id,custody_id,inspection_id,type,severity,status,
  CASE type WHEN 'DANO' THEN 'Daño detectado en recepción' WHEN 'FALTANTE' THEN 'Faltante detectado en recepción' ELSE 'Condición insegura detectada' END,
  notes,opened_by_user_id,opened_by_user_id,opened_at,opened_at,closed_at,'{}',version,created_at,updated_at
FROM incident_phase8_legacy;

DROP TABLE incident_phase8_legacy;

CREATE TABLE incident_event (
  id TEXT PRIMARY KEY,
  incident_id TEXT NOT NULL REFERENCES incident(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('APERTURA','ASIGNACION','NOTA','EVIDENCIA','CAMBIO_ESTADO','RECUPERACION','RESOLUCION','CIERRE','REAPERTURA')),
  from_status TEXT,
  to_status TEXT,
  actor_user_id TEXT REFERENCES user_account(id),
  details TEXT NOT NULL,
  metadata_json TEXT,
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE incident_evidence (
  id TEXT PRIMARY KEY,
  incident_id TEXT NOT NULL REFERENCES incident(id),
  evidence_id TEXT NOT NULL REFERENCES file_evidence(id),
  evidence_type TEXT NOT NULL CHECK(evidence_type IN ('FOTO','DOCUMENTO','DENUNCIA','INFORME','ACTA','OTRO')),
  description TEXT,
  added_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  UNIQUE(incident_id,evidence_id)
);

CREATE TABLE incident_investigation_action (
  id TEXT PRIMARY KEY,
  incident_id TEXT NOT NULL REFERENCES incident(id),
  action_type TEXT NOT NULL CHECK(action_type IN ('ENTREVISTA','INSPECCION','VERIFICACION','DOCUMENTACION','CORRECTIVA','PREVENTIVA','OTRA')),
  description TEXT NOT NULL,
  assigned_to_user_id TEXT REFERENCES user_account(id),
  due_at TEXT,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','EN_CURSO','COMPLETADA','CANCELADA')),
  result TEXT,
  completed_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE operational_block (
  id TEXT PRIMARY KEY,
  block_number TEXT NOT NULL UNIQUE,
  target_type TEXT NOT NULL CHECK(target_type IN ('PERSONA','ACTIVO','CATEGORIA')),
  target_id TEXT NOT NULL,
  scope_type TEXT NOT NULL CHECK(scope_type IN ('TOTAL','SEDE','UBICACION','CATEGORIA','OPERACION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  category_id TEXT REFERENCES asset_category(id),
  operation_type TEXT CHECK(operation_type IS NULL OR operation_type IN ('RETIRO','RESERVA','TRANSFERENCIA')),
  reason TEXT NOT NULL,
  source TEXT NOT NULL CHECK(source IN ('MANUAL','INCIDENTE','AUTOMATICO')),
  incident_id TEXT REFERENCES incident(id),
  severity TEXT NOT NULL CHECK(severity IN ('BAJA','MEDIA','ALTA','CRITICA')),
  status TEXT NOT NULL DEFAULT 'ACTIVO' CHECK(status IN ('ACTIVO','LEVANTADO','EXPIRADO')),
  starts_at TEXT NOT NULL,
  expires_at TEXT,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  approved_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  lifted_by_user_id TEXT REFERENCES user_account(id),
  lifted_at TEXT,
  lift_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE block_exception (
  id TEXT PRIMARY KEY,
  block_id TEXT NOT NULL REFERENCES operational_block(id),
  request_id TEXT REFERENCES request(id),
  person_id TEXT NOT NULL REFERENCES person(id),
  asset_id TEXT REFERENCES asset(id),
  operation_type TEXT NOT NULL CHECK(operation_type IN ('RETIRO','RESERVA','TRANSFERENCIA')),
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','APROBADA','RECHAZADA','CONSUMIDA','CANCELADA','EXPIRADA')),
  requested_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  decided_by_user_id TEXT REFERENCES user_account(id),
  valid_from TEXT,
  valid_until TEXT,
  one_time INTEGER NOT NULL DEFAULT 1 CHECK(one_time IN (0,1)),
  consumed_at TEXT,
  decision_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX ix_incident_status ON incident(status,severity,opened_at DESC);
CREATE INDEX ix_incident_asset ON incident(asset_id,status,opened_at DESC);
CREATE INDEX ix_incident_custody ON incident(custody_id,opened_at DESC);
CREATE INDEX ix_incident_assigned ON incident(assigned_to_user_id,status,opened_at DESC);
CREATE INDEX ix_incident_event ON incident_event(incident_id,occurred_at);
CREATE INDEX ix_incident_evidence ON incident_evidence(incident_id,created_at);
CREATE INDEX ix_investigation_action ON incident_investigation_action(incident_id,status,due_at);
CREATE INDEX ix_block_target ON operational_block(target_type,target_id,status,starts_at);
CREATE INDEX ix_block_scope ON operational_block(status,site_id,location_id,category_id,operation_type);
CREATE UNIQUE INDEX ux_block_active_scope ON operational_block(
  target_type,target_id,scope_type,ifnull(site_id,''),ifnull(location_id,''),ifnull(category_id,''),ifnull(operation_type,'')
) WHERE status='ACTIVO';
CREATE INDEX ix_exception_lookup ON block_exception(block_id,person_id,asset_id,operation_type,status,valid_until);

CREATE TRIGGER incident_event_immutable_update BEFORE UPDATE ON incident_event BEGIN SELECT RAISE(ABORT, 'INCIDENT_EVENT_IMMUTABLE'); END;
CREATE TRIGGER incident_event_immutable_delete BEFORE DELETE ON incident_event BEGIN SELECT RAISE(ABORT, 'INCIDENT_EVENT_IMMUTABLE'); END;
CREATE TRIGGER incident_evidence_immutable_update BEFORE UPDATE ON incident_evidence BEGIN SELECT RAISE(ABORT, 'INCIDENT_EVIDENCE_IMMUTABLE'); END;
CREATE TRIGGER incident_evidence_immutable_delete BEFORE DELETE ON incident_evidence BEGIN SELECT RAISE(ABORT, 'INCIDENT_EVIDENCE_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS incident_evidence_immutable_delete;
DROP TRIGGER IF EXISTS incident_evidence_immutable_update;
DROP TRIGGER IF EXISTS incident_event_immutable_delete;
DROP TRIGGER IF EXISTS incident_event_immutable_update;
DROP TABLE IF EXISTS block_exception;
DROP TABLE IF EXISTS operational_block;
DROP TABLE IF EXISTS incident_investigation_action;
DROP TABLE IF EXISTS incident_evidence;
DROP TABLE IF EXISTS incident_event;
DROP INDEX IF EXISTS ix_incident_assigned;
DROP INDEX IF EXISTS ix_incident_custody;
DROP INDEX IF EXISTS ix_incident_asset;
DROP INDEX IF EXISTS ix_incident_status;
ALTER TABLE incident RENAME TO incident_phase9_legacy;

CREATE TABLE incident (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  custody_id TEXT NOT NULL REFERENCES custody(id),
  inspection_id TEXT NOT NULL REFERENCES inspection(id),
  type TEXT NOT NULL CHECK(type IN ('DANO','FALTANTE','CONDICION_INSEGURA')),
  severity TEXT NOT NULL CHECK(severity IN ('BAJA','MEDIA','ALTA','CRITICA')),
  status TEXT NOT NULL DEFAULT 'ABIERTO' CHECK(status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO','CERRADO')),
  notes TEXT NOT NULL,
  opened_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  opened_at TEXT NOT NULL,
  closed_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT INTO incident(id,asset_id,custody_id,inspection_id,type,severity,status,notes,opened_by_user_id,opened_at,closed_at,version,created_at,updated_at)
SELECT id,asset_id,custody_id,inspection_id,
  CASE WHEN type='DANO' THEN 'DANO' WHEN type='CONDICION_INSEGURA' THEN 'CONDICION_INSEGURA' ELSE 'FALTANTE' END,
  severity,status,description,opened_by_user_id,opened_at,closed_at,version,created_at,updated_at
FROM incident_phase9_legacy
WHERE custody_id IS NOT NULL AND inspection_id IS NOT NULL;

DROP TABLE incident_phase9_legacy;
CREATE INDEX ix_incident_status ON incident(status,severity,opened_at DESC);
