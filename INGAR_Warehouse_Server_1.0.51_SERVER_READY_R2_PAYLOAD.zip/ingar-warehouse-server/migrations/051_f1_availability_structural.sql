-- +up
-- F1 disponibilidad estructural: acelera la misma clave operativa usada por catálogo/pedidos.
CREATE INDEX IF NOT EXISTS ix_asset_request_availability
  ON asset(active, status, quantity_available, location_id, category_id);
CREATE INDEX IF NOT EXISTS ix_asset_import_availability_review
  ON asset(source_import_batch_id, status, quantity_available)
  WHERE source_import_batch_id IS NOT NULL;
-- +down
DROP INDEX IF EXISTS ix_asset_import_availability_review;
DROP INDEX IF EXISTS ix_asset_request_availability;
