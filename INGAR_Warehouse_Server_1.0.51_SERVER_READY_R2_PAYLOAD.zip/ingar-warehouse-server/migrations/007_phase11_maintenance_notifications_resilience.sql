-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE maintenance_plan (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  code TEXT NOT NULL COLLATE NOCASE,
  name TEXT NOT NULL,
  maintenance_type TEXT NOT NULL DEFAULT 'PREVENTIVO' CHECK(maintenance_type IN ('PREVENTIVO','CORRECTIVO','INSPECCION_TECNICA')),
  trigger_type TEXT NOT NULL CHECK(trigger_type IN ('CALENDARIO','ODOMETRO','HOROMETRO','MANUAL')),
  interval_days INTEGER CHECK(interval_days IS NULL OR interval_days > 0),
  interval_value REAL CHECK(interval_value IS NULL OR interval_value > 0),
  lead_days INTEGER NOT NULL DEFAULT 7 CHECK(lead_days >= 0),
  blocking_when_overdue INTEGER NOT NULL DEFAULT 1 CHECK(blocking_when_overdue IN (0,1)),
  instructions TEXT,
  last_completed_at TEXT,
  last_completed_value REAL,
  next_due_at TEXT,
  next_due_value REAL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(asset_id, code)
);

CREATE TABLE maintenance_order (
  id TEXT PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  client_order_id TEXT UNIQUE,
  plan_id TEXT REFERENCES maintenance_plan(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  maintenance_type TEXT NOT NULL CHECK(maintenance_type IN ('PREVENTIVO','CORRECTIVO','INSPECCION_TECNICA')),
  priority TEXT NOT NULL DEFAULT 'MEDIA' CHECK(priority IN ('BAJA','MEDIA','ALTA','CRITICA')),
  status TEXT NOT NULL DEFAULT 'PROGRAMADA' CHECK(status IN ('BORRADOR','PROGRAMADA','EN_PROGRESO','COMPLETADA','CANCELADA','VENCIDA')),
  scheduled_at TEXT NOT NULL,
  due_at TEXT,
  started_at TEXT,
  completed_at TEXT,
  assigned_person_id TEXT REFERENCES person(id),
  meter_type TEXT CHECK(meter_type IS NULL OR meter_type IN ('ODOMETRO','HOROMETRO')),
  meter_at_open REAL,
  meter_at_close REAL,
  description TEXT NOT NULL,
  findings TEXT,
  work_performed TEXT,
  result TEXT CHECK(result IS NULL OR result IN ('APTO','APTO_CON_OBSERVACIONES','NO_APTO')),
  asset_status_before TEXT,
  generated_by_scheduler INTEGER NOT NULL DEFAULT 0 CHECK(generated_by_scheduler IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  started_by_user_id TEXT REFERENCES user_account(id),
  completed_by_user_id TEXT REFERENCES user_account(id),
  cancelled_by_user_id TEXT REFERENCES user_account(id),
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE maintenance_inspection (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES maintenance_order(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  inspector_person_id TEXT REFERENCES person(id),
  checklist_json TEXT NOT NULL DEFAULT '{}',
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  result TEXT NOT NULL CHECK(result IN ('APTO','APTO_CON_OBSERVACIONES','NO_APTO')),
  observations TEXT,
  inspected_at TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL
);

CREATE TABLE maintenance_event (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES maintenance_order(id),
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor_user_id TEXT REFERENCES user_account(id),
  reason TEXT,
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE notification (
  id TEXT PRIMARY KEY,
  recipient_person_id TEXT REFERENCES person(id),
  recipient_user_id TEXT REFERENCES user_account(id),
  type TEXT NOT NULL CHECK(type IN ('MANTENIMIENTO_PROXIMO','MANTENIMIENTO_VENCIDO','CUSTODIA_VENCIDA','HABILITACION_PROXIMA','SISTEMA','INCIDENTE')),
  channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK(channel IN ('IN_APP','EMAIL')),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA','CANCELADA')),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  dedup_key TEXT UNIQUE,
  scheduled_at TEXT NOT NULL,
  sent_at TEXT,
  read_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(recipient_person_id IS NOT NULL OR recipient_user_id IS NOT NULL)
);

CREATE TABLE scheduler_job (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  interval_seconds INTEGER NOT NULL CHECK(interval_seconds >= 60),
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  last_run_at TEXT,
  next_run_at TEXT,
  last_status TEXT CHECK(last_status IS NULL OR last_status IN ('SUCCESS','PARTIAL','FAILED','RUNNING')),
  last_error TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE scheduler_run (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES scheduler_job(id),
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('RUNNING','SUCCESS','PARTIAL','FAILED')),
  processed_count INTEGER NOT NULL DEFAULT 0,
  generated_count INTEGER NOT NULL DEFAULT 0,
  details_json TEXT NOT NULL DEFAULT '{}',
  error TEXT,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_maintenance_plan_due ON maintenance_plan(active,next_due_at,next_due_value);
CREATE INDEX ix_maintenance_order_asset ON maintenance_order(asset_id,status,due_at);
CREATE INDEX ix_maintenance_order_plan ON maintenance_order(plan_id,status);
CREATE INDEX ix_maintenance_event_order ON maintenance_event(order_id,occurred_at);
CREATE INDEX ix_notification_recipient ON notification(recipient_user_id,recipient_person_id,status,scheduled_at);
CREATE INDEX ix_notification_entity ON notification(entity_type,entity_id,type);
CREATE INDEX ix_scheduler_run_job ON scheduler_run(job_id,started_at DESC);

CREATE TRIGGER maintenance_inspection_immutable_update BEFORE UPDATE ON maintenance_inspection BEGIN SELECT RAISE(ABORT, 'MAINTENANCE_INSPECTION_IMMUTABLE'); END;
CREATE TRIGGER maintenance_inspection_immutable_delete BEFORE DELETE ON maintenance_inspection BEGIN SELECT RAISE(ABORT, 'MAINTENANCE_INSPECTION_IMMUTABLE'); END;
CREATE TRIGGER maintenance_event_immutable_update BEFORE UPDATE ON maintenance_event BEGIN SELECT RAISE(ABORT, 'MAINTENANCE_EVENT_IMMUTABLE'); END;
CREATE TRIGGER maintenance_event_immutable_delete BEFORE DELETE ON maintenance_event BEGIN SELECT RAISE(ABORT, 'MAINTENANCE_EVENT_IMMUTABLE'); END;
CREATE TRIGGER scheduler_run_immutable_update BEFORE UPDATE ON scheduler_run WHEN OLD.status <> 'RUNNING' BEGIN SELECT RAISE(ABORT, 'SCHEDULER_RUN_IMMUTABLE'); END;
CREATE TRIGGER scheduler_run_immutable_delete BEFORE DELETE ON scheduler_run BEGIN SELECT RAISE(ABORT, 'SCHEDULER_RUN_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS scheduler_run_immutable_delete;
DROP TRIGGER IF EXISTS scheduler_run_immutable_update;
DROP TRIGGER IF EXISTS maintenance_event_immutable_delete;
DROP TRIGGER IF EXISTS maintenance_event_immutable_update;
DROP TRIGGER IF EXISTS maintenance_inspection_immutable_delete;
DROP TRIGGER IF EXISTS maintenance_inspection_immutable_update;
DROP TABLE IF EXISTS scheduler_run;
DROP TABLE IF EXISTS scheduler_job;
DROP TABLE IF EXISTS notification;
DROP TABLE IF EXISTS maintenance_event;
DROP TABLE IF EXISTS maintenance_inspection;
DROP TABLE IF EXISTS maintenance_order;
DROP TABLE IF EXISTS maintenance_plan;
