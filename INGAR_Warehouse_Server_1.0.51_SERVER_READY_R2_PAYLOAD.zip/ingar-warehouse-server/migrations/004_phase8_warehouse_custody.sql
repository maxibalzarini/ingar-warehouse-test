-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE request_preparation (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL UNIQUE REFERENCES request(id),
  operator_user_id TEXT NOT NULL REFERENCES user_account(id),
  status TEXT NOT NULL CHECK(status IN ('EN_PREPARACION','LISTA','CANCELADA')),
  observations TEXT,
  prepared_at TEXT NOT NULL,
  ready_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE request_preparation_item (
  id TEXT PRIMARY KEY,
  preparation_id TEXT NOT NULL REFERENCES request_preparation(id),
  request_item_id TEXT NOT NULL UNIQUE REFERENCES request_item(id),
  requested_asset_id TEXT NOT NULL REFERENCES asset(id),
  prepared_asset_id TEXT NOT NULL REFERENCES asset(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  status TEXT NOT NULL CHECK(status IN ('PREPARADO','SUSTITUIDO')),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO')),
  substitution_reason TEXT,
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE handover (
  id TEXT PRIMARY KEY,
  request_id TEXT REFERENCES request(id),
  type TEXT NOT NULL CHECK(type IN ('ENTREGA','RECEPCION','TRANSFERENCIA')),
  operator_user_id TEXT NOT NULL REFERENCES user_account(id),
  person_id TEXT NOT NULL REFERENCES person(id),
  occurred_at TEXT NOT NULL,
  observations TEXT,
  acceptance_method TEXT NOT NULL CHECK(acceptance_method IN ('EXPLICITA','PIN','FIRMA','NINGUNA')),
  acceptance_hash TEXT,
  acceptance_evidence_id TEXT REFERENCES file_evidence(id),
  idempotency_key TEXT NOT NULL UNIQUE,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE handover_item (
  id TEXT PRIMARY KEY,
  handover_id TEXT NOT NULL REFERENCES handover(id),
  request_item_id TEXT REFERENCES request_item(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  notes TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(handover_id, asset_id)
);

CREATE TABLE custody (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  request_item_id TEXT NOT NULL UNIQUE REFERENCES request_item(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  person_id TEXT NOT NULL REFERENCES person(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  exclusive_unit INTEGER NOT NULL DEFAULT 1 CHECK(exclusive_unit IN (0,1)),
  opened_by_handover_id TEXT NOT NULL REFERENCES handover(id),
  opened_at TEXT NOT NULL,
  due_at TEXT,
  status TEXT NOT NULL CHECK(status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','CERRADA','INCIDENTE')),
  declared_return_at TEXT,
  closed_by_handover_id TEXT REFERENCES handover(id),
  closed_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE inspection (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  custody_id TEXT REFERENCES custody(id),
  handover_id TEXT NOT NULL REFERENCES handover(id),
  inspector_user_id TEXT NOT NULL REFERENCES user_account(id),
  phase TEXT NOT NULL CHECK(phase IN ('ENTREGA','RECEPCION')),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  result TEXT NOT NULL CHECK(result IN ('APROBADO','BLOQUEADO','INCIDENTE')),
  notes TEXT,
  occurred_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE custody_event (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL REFERENCES custody(id),
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor_user_id TEXT REFERENCES user_account(id),
  reason TEXT,
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE custody_transfer (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL REFERENCES custody(id),
  from_person_id TEXT NOT NULL REFERENCES person(id),
  to_person_id TEXT NOT NULL REFERENCES person(id),
  requested_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  accepted_by_user_id TEXT REFERENCES user_account(id),
  status TEXT NOT NULL CHECK(status IN ('PENDIENTE','ACEPTADA','RECHAZADA','CANCELADA')),
  reason TEXT NOT NULL,
  decision_reason TEXT,
  requested_at TEXT NOT NULL,
  decided_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE incident (
  id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(id),
  custody_id TEXT NOT NULL REFERENCES custody(id),
  inspection_id TEXT NOT NULL REFERENCES inspection(id),
  type TEXT NOT NULL CHECK(type IN ('DANO','FALTANTE','CONDICION_INSEGURA')),
  severity TEXT NOT NULL CHECK(severity IN ('BAJA','MEDIA','ALTA','CRITICA')),
  status TEXT NOT NULL DEFAULT 'ABIERTO' CHECK(status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO','CERRADO')),
  notes TEXT NOT NULL,
  opened_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  opened_at TEXT NOT NULL,
  closed_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX ix_preparation_request ON request_preparation(request_id, status);
CREATE INDEX ix_preparation_item_asset ON request_preparation_item(prepared_asset_id);
CREATE INDEX ix_handover_request ON handover(request_id, occurred_at DESC);
CREATE INDEX ix_handover_person ON handover(person_id, occurred_at DESC);
CREATE INDEX ix_custody_person_status ON custody(person_id, status, due_at);
CREATE INDEX ix_custody_asset_status ON custody(asset_id, status);
CREATE UNIQUE INDEX ux_custody_open_exclusive_asset ON custody(asset_id)
  WHERE exclusive_unit = 1 AND status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE');
CREATE INDEX ix_inspection_asset ON inspection(asset_id, occurred_at DESC);
CREATE INDEX ix_custody_event_custody ON custody_event(custody_id, occurred_at);
CREATE INDEX ix_transfer_custody_status ON custody_transfer(custody_id, status);
CREATE INDEX ix_transfer_person_status ON custody_transfer(to_person_id, status, requested_at DESC);
CREATE INDEX ix_incident_status ON incident(status, severity, opened_at DESC);

CREATE TRIGGER handover_immutable_update BEFORE UPDATE ON handover BEGIN SELECT RAISE(ABORT, 'HANDOVER_IMMUTABLE'); END;
CREATE TRIGGER handover_immutable_delete BEFORE DELETE ON handover BEGIN SELECT RAISE(ABORT, 'HANDOVER_IMMUTABLE'); END;
CREATE TRIGGER handover_item_immutable_update BEFORE UPDATE ON handover_item BEGIN SELECT RAISE(ABORT, 'HANDOVER_ITEM_IMMUTABLE'); END;
CREATE TRIGGER handover_item_immutable_delete BEFORE DELETE ON handover_item BEGIN SELECT RAISE(ABORT, 'HANDOVER_ITEM_IMMUTABLE'); END;
CREATE TRIGGER inspection_immutable_update BEFORE UPDATE ON inspection BEGIN SELECT RAISE(ABORT, 'INSPECTION_IMMUTABLE'); END;
CREATE TRIGGER inspection_immutable_delete BEFORE DELETE ON inspection BEGIN SELECT RAISE(ABORT, 'INSPECTION_IMMUTABLE'); END;
CREATE TRIGGER custody_event_immutable_update BEFORE UPDATE ON custody_event BEGIN SELECT RAISE(ABORT, 'CUSTODY_EVENT_IMMUTABLE'); END;
CREATE TRIGGER custody_event_immutable_delete BEFORE DELETE ON custody_event BEGIN SELECT RAISE(ABORT, 'CUSTODY_EVENT_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS custody_event_immutable_delete;
DROP TRIGGER IF EXISTS custody_event_immutable_update;
DROP TRIGGER IF EXISTS inspection_immutable_delete;
DROP TRIGGER IF EXISTS inspection_immutable_update;
DROP TRIGGER IF EXISTS handover_item_immutable_delete;
DROP TRIGGER IF EXISTS handover_item_immutable_update;
DROP TRIGGER IF EXISTS handover_immutable_delete;
DROP TRIGGER IF EXISTS handover_immutable_update;
DROP TABLE IF EXISTS incident;
DROP TABLE IF EXISTS custody_transfer;
DROP TABLE IF EXISTS custody_event;
DROP TABLE IF EXISTS inspection;
DROP TABLE IF EXISTS custody;
DROP TABLE IF EXISTS handover_item;
DROP TABLE IF EXISTS handover;
DROP TABLE IF EXISTS request_preparation_item;
DROP TABLE IF EXISTS request_preparation;
