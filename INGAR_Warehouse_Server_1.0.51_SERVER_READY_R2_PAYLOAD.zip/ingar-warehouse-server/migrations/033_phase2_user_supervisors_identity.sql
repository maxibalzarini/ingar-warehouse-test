-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE user_supervisor_assignment (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES user_account(id),
  supervisor_user_id TEXT NOT NULL REFERENCES user_account(id),
  assigned_by_user_id TEXT REFERENCES user_account(id),
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  reason TEXT,
  created_at TEXT NOT NULL,
  CHECK(user_id <> supervisor_user_id)
);

CREATE UNIQUE INDEX ux_user_supervisor_assignment_current
ON user_supervisor_assignment(user_id)
WHERE effective_to IS NULL;

CREATE INDEX ix_user_supervisor_assignment_supervisor
ON user_supervisor_assignment(supervisor_user_id, effective_from, effective_to);

-- Compatibilidad: todo usuario no ADMIN_GENERAL sin supervisor recibe el
-- Administrador General activo más antiguo. Se preservan IDs y relaciones existentes.
UPDATE person
SET supervisor_person_id = (
      SELECT admin_p.id
      FROM user_account admin_ua
      JOIN person admin_p ON admin_p.id = admin_ua.person_id
      JOIN user_role_scope admin_urs ON admin_urs.user_id = admin_ua.id
      JOIN role admin_r ON admin_r.id = admin_urs.role_id
      WHERE admin_r.code = 'ADMIN_GENERAL'
        AND admin_r.active = 1
        AND admin_ua.active = 1 AND admin_ua.deleted_at IS NULL
        AND admin_p.status = 'ACTIVA' AND admin_p.deleted_at IS NULL
      ORDER BY admin_ua.created_at, admin_ua.id
      LIMIT 1
    ),
    version = version + 1,
    updated_at = datetime('now')
WHERE id IN (
  SELECT p.id
  FROM person p
  JOIN user_account ua ON ua.person_id = p.id
  WHERE ua.deleted_at IS NULL
    AND p.deleted_at IS NULL
    AND p.supervisor_person_id IS NULL
    AND NOT EXISTS (
      SELECT 1
      FROM user_role_scope urs
      JOIN role r ON r.id = urs.role_id
      WHERE urs.user_id = ua.id AND r.code = 'ADMIN_GENERAL' AND r.active = 1
    )
)
AND EXISTS (
  SELECT 1
  FROM user_account admin_ua
  JOIN person admin_p ON admin_p.id = admin_ua.person_id
  JOIN user_role_scope admin_urs ON admin_urs.user_id = admin_ua.id
  JOIN role admin_r ON admin_r.id = admin_urs.role_id
  WHERE admin_r.code = 'ADMIN_GENERAL'
    AND admin_r.active = 1
    AND admin_ua.active = 1 AND admin_ua.deleted_at IS NULL
    AND admin_p.status = 'ACTIVA' AND admin_p.deleted_at IS NULL
);

-- Congela el vínculo supervisor vigente al momento de migrar.
INSERT INTO user_supervisor_assignment(
  id, user_id, supervisor_user_id, assigned_by_user_id,
  effective_from, effective_to, reason, created_at
)
SELECT lower(hex(randomblob(16))), ua.id, sup_ua.id, NULL,
       datetime('now'), NULL, 'MIGRACION_F18_SUPERVISOR_VIGENTE', datetime('now')
FROM user_account ua
JOIN person p ON p.id = ua.person_id
JOIN user_account sup_ua ON sup_ua.person_id = p.supervisor_person_id
WHERE ua.deleted_at IS NULL
  AND p.supervisor_person_id IS NOT NULL
  AND ua.id <> sup_ua.id;

-- +down
DROP INDEX IF EXISTS ix_user_supervisor_assignment_supervisor;
DROP INDEX IF EXISTS ux_user_supervisor_assignment_current;
DROP TABLE IF EXISTS user_supervisor_assignment;
