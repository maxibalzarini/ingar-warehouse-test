-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE report_execution (
  id TEXT PRIMARY KEY,
  report_code TEXT NOT NULL,
  report_name TEXT NOT NULL,
  category TEXT NOT NULL,
  parameters_json TEXT NOT NULL DEFAULT '{}',
  page INTEGER NOT NULL DEFAULT 1 CHECK(page >= 1),
  page_size INTEGER NOT NULL DEFAULT 25 CHECK(page_size >= 1 AND page_size <= 100),
  row_count INTEGER NOT NULL DEFAULT 0 CHECK(row_count >= 0),
  total_count INTEGER NOT NULL DEFAULT 0 CHECK(total_count >= 0),
  generated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  generated_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('SUCCESS','FAILED')),
  duration_ms INTEGER NOT NULL DEFAULT 0 CHECK(duration_ms >= 0),
  error_code TEXT,
  correlation_id TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_report_execution_user_time ON report_execution(generated_by_user_id, generated_at DESC);
CREATE INDEX ix_report_execution_code_time ON report_execution(report_code, generated_at DESC);
CREATE INDEX ix_report_execution_scope_time ON report_execution(site_id, location_id, generated_at DESC);

-- +down
DROP TABLE IF EXISTS report_execution;
