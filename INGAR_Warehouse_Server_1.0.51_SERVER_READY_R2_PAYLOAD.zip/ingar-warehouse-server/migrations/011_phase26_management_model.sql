-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE management_indicator_definition (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('SOLICITUDES','DEVOLUCIONES','ACTIVOS','INCIDENTES','MANTENIMIENTO','STOCK')),
  unit TEXT NOT NULL CHECK (unit IN ('PERCENT','HOURS','COUNT','DAYS','CURRENCY')),
  direction TEXT NOT NULL CHECK (direction IN ('HIGHER_BETTER','LOWER_BETTER')),
  calculation_mode TEXT NOT NULL CHECK (calculation_mode IN ('PERIOD','SNAPSHOT')),
  formula_code TEXT NOT NULL,
  formula_description TEXT NOT NULL,
  source_json TEXT NOT NULL,
  default_target_value REAL NOT NULL,
  default_warning_value REAL NOT NULL,
  default_periodicity TEXT NOT NULL CHECK (default_periodicity IN ('DAILY','WEEKLY','MONTHLY')),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  system_indicator INTEGER NOT NULL DEFAULT 1 CHECK (system_indicator IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE management_indicator_target (
  id TEXT PRIMARY KEY,
  indicator_id TEXT NOT NULL REFERENCES management_indicator_definition(id),
  scope_type TEXT NOT NULL CHECK (scope_type IN ('GLOBAL','SITE','LOCATION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  target_value REAL NOT NULL,
  warning_value REAL NOT NULL,
  responsible_user_id TEXT REFERENCES user_account(id),
  responsible_role_id TEXT REFERENCES role(id),
  periodicity TEXT NOT NULL CHECK (periodicity IN ('DAILY','WEEKLY','MONTHLY')),
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  valid_from TEXT NOT NULL,
  valid_to TEXT,
  created_by_user_id TEXT REFERENCES user_account(id),
  updated_by_user_id TEXT REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (
    (scope_type='GLOBAL' AND site_id IS NULL AND location_id IS NULL) OR
    (scope_type='SITE' AND site_id IS NOT NULL AND location_id IS NULL) OR
    (scope_type='LOCATION' AND site_id IS NOT NULL AND location_id IS NOT NULL)
  )
);

CREATE UNIQUE INDEX ux_management_target_active_scope
  ON management_indicator_target(indicator_id, scope_type, IFNULL(site_id,''), IFNULL(location_id,''))
  WHERE active=1;
CREATE INDEX ix_management_target_indicator ON management_indicator_target(indicator_id, active, valid_from, valid_to);
CREATE INDEX ix_management_target_responsible_user ON management_indicator_target(responsible_user_id, active);
CREATE INDEX ix_management_target_responsible_role ON management_indicator_target(responsible_role_id, active);

CREATE TABLE management_indicator_snapshot (
  id TEXT PRIMARY KEY,
  indicator_id TEXT NOT NULL REFERENCES management_indicator_definition(id),
  target_id TEXT REFERENCES management_indicator_target(id),
  scope_type TEXT NOT NULL CHECK (scope_type IN ('GLOBAL','SITE','LOCATION')),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  measurement_date TEXT NOT NULL,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  measured_at TEXT NOT NULL,
  value REAL,
  numerator REAL,
  denominator REAL,
  target_value REAL NOT NULL,
  warning_value REAL NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('BIEN','ATENCION','URGENTE','SIN_DATOS')),
  details_json TEXT NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('API','SCHEDULER','SYSTEM')),
  calculated_by_user_id TEXT REFERENCES user_account(id),
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (
    (scope_type='GLOBAL' AND site_id IS NULL AND location_id IS NULL) OR
    (scope_type='SITE' AND site_id IS NOT NULL AND location_id IS NULL) OR
    (scope_type='LOCATION' AND site_id IS NOT NULL AND location_id IS NOT NULL)
  )
);

CREATE UNIQUE INDEX ux_management_snapshot_period
  ON management_indicator_snapshot(indicator_id, scope_type, IFNULL(site_id,''), IFNULL(location_id,''), measurement_date, period_start, period_end);
CREATE INDEX ix_management_snapshot_indicator_time ON management_indicator_snapshot(indicator_id, measured_at DESC);
CREATE INDEX ix_management_snapshot_scope_time ON management_indicator_snapshot(site_id, location_id, measured_at DESC);
CREATE INDEX ix_management_snapshot_status_time ON management_indicator_snapshot(status, measured_at DESC);

-- +down
DROP INDEX IF EXISTS ix_management_snapshot_status_time;
DROP INDEX IF EXISTS ix_management_snapshot_scope_time;
DROP INDEX IF EXISTS ix_management_snapshot_indicator_time;
DROP INDEX IF EXISTS ux_management_snapshot_period;
DROP TABLE IF EXISTS management_indicator_snapshot;
DROP INDEX IF EXISTS ix_management_target_responsible_role;
DROP INDEX IF EXISTS ix_management_target_responsible_user;
DROP INDEX IF EXISTS ix_management_target_indicator;
DROP INDEX IF EXISTS ux_management_target_active_scope;
DROP TABLE IF EXISTS management_indicator_target;
DROP TABLE IF EXISTS management_indicator_definition;
