-- +up
PRAGMA foreign_keys = ON;

-- La cadena de auditoría debe seguir el orden de anexado, no el reloj del equipo.
-- Esto evita que un cambio de hora, una sincronización NTP o un evento histórico
-- incorporado fuera de orden invalide la cadena completa.
DROP TRIGGER IF EXISTS audit_event_immutable_update;
ALTER TABLE audit_event ADD COLUMN chain_sequence INTEGER;

WITH archived AS (
  SELECT COALESCE(SUM(event_count), 0) AS base
  FROM audit_archive_segment
  WHERE status = 'VERIFIED'
), ranked AS (
  SELECT id, ROW_NUMBER() OVER (ORDER BY occurred_at ASC, rowid ASC) AS position
  FROM audit_event
)
UPDATE audit_event
SET chain_sequence = (
  SELECT archived.base + ranked.position
  FROM archived, ranked
  WHERE ranked.id = audit_event.id
);

CREATE UNIQUE INDEX ux_audit_event_chain_sequence
ON audit_event(chain_sequence)
WHERE chain_sequence IS NOT NULL;

CREATE TRIGGER audit_event_immutable_update
BEFORE UPDATE ON audit_event
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

-- Índices operativos para bases grandes y operación prolongada.
CREATE INDEX ix_request_scope_created
ON "request"(site_id, location_id, created_at DESC);

CREATE INDEX ix_request_scope_status_needed
ON "request"(site_id, location_id, status, needed_at);

CREATE INDEX ix_notification_user_schedule
ON notification(recipient_user_id, scheduled_at DESC, created_at DESC);

CREATE INDEX ix_notification_person_schedule
ON notification(recipient_person_id, scheduled_at DESC, created_at DESC);

CREATE INDEX ix_custody_status_due
ON custody(status, due_at, request_id);

CREATE INDEX ix_maintenance_order_status_due
ON maintenance_order(status, due_at, priority, asset_id);

CREATE INDEX ix_handover_type_time
ON handover(type, occurred_at, request_id);

CREATE INDEX ix_asset_available_location
ON asset(location_id, status, active, deleted_at, internal_code);

-- +down
DROP INDEX IF EXISTS ix_asset_available_location;
DROP INDEX IF EXISTS ix_handover_type_time;
DROP INDEX IF EXISTS ix_maintenance_order_status_due;
DROP INDEX IF EXISTS ix_custody_status_due;
DROP INDEX IF EXISTS ix_notification_person_schedule;
DROP INDEX IF EXISTS ix_notification_user_schedule;
DROP INDEX IF EXISTS ix_request_scope_status_needed;
DROP INDEX IF EXISTS ix_request_scope_created;

DROP TRIGGER IF EXISTS audit_event_immutable_update;
DROP INDEX IF EXISTS ux_audit_event_chain_sequence;
ALTER TABLE audit_event DROP COLUMN chain_sequence;
CREATE TRIGGER audit_event_immutable_update
BEFORE UPDATE ON audit_event
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;
