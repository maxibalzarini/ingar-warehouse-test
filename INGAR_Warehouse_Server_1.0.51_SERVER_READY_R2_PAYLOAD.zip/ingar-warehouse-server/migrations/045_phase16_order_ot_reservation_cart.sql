-- +up
PRAGMA foreign_keys = ON;

-- F32 / F18 · pedido técnico multiítem, OT de pedido y reserva al enviar.
-- Compatibilidad: no reescribe filas históricas 001..044.
ALTER TABLE request ADD COLUMN work_order_reference TEXT;
ALTER TABLE request_history_snapshot ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE approval ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE asset_reservation ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE request_preparation ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE handover ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE custody ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE custody_return_declaration ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE custody_return_record ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE custody_reception_review ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE vehicle_request_detail ADD COLUMN work_order_reference_snapshot TEXT;
ALTER TABLE vehicle_return_detail ADD COLUMN work_order_reference_snapshot TEXT;

CREATE INDEX ix_request_work_order_reference ON request(work_order_reference, created_at DESC);

-- La OT es obligatoria para TODO pedido nuevo. Las filas históricas 001..044 permanecen intactas.
CREATE TRIGGER request_ot_required_insert
BEFORE INSERT ON request
WHEN trim(COALESCE(NEW.work_order_reference,''))=''
BEGIN SELECT RAISE(ABORT,'REQUEST_WORK_ORDER_REQUIRED'); END;

CREATE TRIGGER request_ot_format_insert
BEFORE INSERT ON request
WHEN length(NEW.work_order_reference)>120
  OR trim(NEW.work_order_reference)<>NEW.work_order_reference
  OR NEW.work_order_reference NOT GLOB '[A-Za-z0-9]*'
  OR NEW.work_order_reference GLOB '*[^A-Za-z0-9 ._:/#-]*'
BEGIN SELECT RAISE(ABORT,'REQUEST_WORK_ORDER_INVALID'); END;

CREATE TRIGGER request_ot_format_update
BEFORE UPDATE OF work_order_reference ON request
WHEN NEW.work_order_reference IS NOT NULL AND (
  trim(NEW.work_order_reference)=''
  OR length(NEW.work_order_reference)>120
  OR trim(NEW.work_order_reference)<>NEW.work_order_reference
  OR NEW.work_order_reference NOT GLOB '[A-Za-z0-9]*'
  OR NEW.work_order_reference GLOB '*[^A-Za-z0-9 ._:/#-]*'
)
BEGIN SELECT RAISE(ABORT,'REQUEST_WORK_ORDER_INVALID'); END;

-- Una vez definida, la OT de pedido es inmutable. Un pedido histórico NULL sólo puede recibirla una vez.
CREATE TRIGGER request_ot_immutable
BEFORE UPDATE OF work_order_reference ON request
WHEN OLD.work_order_reference IS NOT NULL
 AND COALESCE(NEW.work_order_reference,'')<>OLD.work_order_reference
BEGIN SELECT RAISE(ABORT,'REQUEST_WORK_ORDER_IMMUTABLE'); END;

-- Retira la interpretación F11 "OT según herramienta". El snapshot del ítem ahora hereda SIEMPRE la OT del pedido.
DROP TRIGGER IF EXISTS request_item_work_order_requirement_insert;
DROP TRIGGER IF EXISTS request_item_work_order_reference_insert;
DROP TRIGGER IF EXISTS request_item_work_order_reference_update;
DROP TRIGGER IF EXISTS request_item_work_order_requirement_update;
DROP TRIGGER IF EXISTS request_item_work_order_reference_length_insert;
DROP TRIGGER IF EXISTS request_item_work_order_reference_length_update;
DROP TRIGGER IF EXISTS request_item_work_order_locked_after_request_progress;
DROP TRIGGER IF EXISTS asset_vehicle_work_order_insert;
DROP TRIGGER IF EXISTS asset_vehicle_work_order_update;

CREATE TRIGGER request_item_ot_inherit_insert
BEFORE INSERT ON request_item
WHEN EXISTS (SELECT 1 FROM request r WHERE r.id=NEW.request_id AND r.work_order_reference IS NOT NULL)
 AND (
   NEW.work_order_required<>1
   OR COALESCE(NEW.work_order_reference,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
 )
BEGIN SELECT RAISE(ABORT,'REQUEST_ITEM_WORK_ORDER_MUST_INHERIT'); END;

CREATE TRIGGER request_item_ot_immutable
BEFORE UPDATE OF work_order_required,work_order_reference,request_id ON request_item
WHEN EXISTS (SELECT 1 FROM request r WHERE r.id=OLD.request_id AND r.work_order_reference IS NOT NULL)
 AND (
   NEW.request_id<>OLD.request_id
   OR NEW.work_order_required<>OLD.work_order_required
   OR COALESCE(NEW.work_order_reference,'')<>COALESCE(OLD.work_order_reference,'')
 )
BEGIN SELECT RAISE(ABORT,'REQUEST_ITEM_WORK_ORDER_IMMUTABLE'); END;

-- Reserva: identidad y cantidad no pueden mutar retroactivamente.
CREATE TRIGGER asset_reservation_identity_immutable
BEFORE UPDATE OF request_id,request_item_id,quantity,starts_at,expires_at,work_order_reference_snapshot ON asset_reservation
BEGIN SELECT RAISE(ABORT,'ASSET_RESERVATION_IDENTITY_IMMUTABLE'); END;

-- DB guard: el insert ACTIVA debe corresponder al ítem/pedido y a su OT.
CREATE TRIGGER asset_reservation_active_insert_guard
BEFORE INSERT ON asset_reservation
WHEN NEW.status='ACTIVA'
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM request_item ri JOIN request r ON r.id=ri.request_id
    WHERE ri.id=NEW.request_item_id AND ri.request_id=NEW.request_id AND ri.asset_id=NEW.asset_id
      AND abs(ri.quantity-NEW.quantity)<0.0000001
      AND r.work_order_reference IS NOT NULL
      AND NEW.work_order_reference_snapshot=r.work_order_reference
  ) THEN RAISE(ABORT,'ASSET_RESERVATION_REQUEST_MISMATCH') END;

  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    WHERE a.id=NEW.asset_id AND a.active=1 AND a.deleted_at IS NULL
      AND a.status='DISPONIBLE' AND a.quantity_available>=NEW.quantity
      AND (ac.nature NOT IN ('SERIADO','KIT','VEHICULO') OR NEW.quantity=1)
  ) THEN RAISE(ABORT,'ASSET_RESERVATION_NOT_AVAILABLE') END;

  -- Un kit PERSONAL sólo puede reservarlo su mecánico asignado.
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM asset a
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN kit_definition kd ON kd.kit_asset_id=a.id AND kd.ownership_mode='PERSONAL'
    WHERE a.id=NEW.asset_id AND ac.nature='KIT'
      AND NOT EXISTS (
        SELECT 1 FROM kit_person_assignment kpa
        JOIN request r ON r.id=NEW.request_id
        WHERE kpa.kit_asset_id=a.id AND kpa.person_id=r.requester_person_id AND kpa.status='ACTIVE'
      )
  ) THEN RAISE(ABORT,'KIT_PERSONAL_REQUESTER_ONLY') END;

  -- Un componente de un kit activamente reservado no puede pedirse suelto.
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM kit_component kc
    JOIN asset_reservation kar ON kar.asset_id=kc.kit_asset_id AND kar.status='ACTIVA'
    WHERE kc.component_asset_id=NEW.asset_id AND kc.active=1
  ) THEN RAISE(ABORT,'KIT_COMPONENT_RESERVED_BY_KIT') END;

  -- Reservar un kit exige que ninguno de sus componentes esté reservado o en custodia abierta.
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    WHERE a.id=NEW.asset_id AND ac.nature='KIT'
      AND EXISTS (
        SELECT 1 FROM kit_component kc
        LEFT JOIN asset_reservation ar ON ar.asset_id=kc.component_asset_id AND ar.status='ACTIVA'
        LEFT JOIN custody c ON c.asset_id=kc.component_asset_id AND c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')
        WHERE kc.kit_asset_id=NEW.asset_id AND kc.active=1 AND (ar.id IS NOT NULL OR c.id IS NOT NULL)
      )
  ) THEN RAISE(ABORT,'KIT_COMPONENT_NOT_AVAILABLE') END;
END;

-- La DB realiza la afectación del stock/reserva. El servicio no puede omitirla.
CREATE TRIGGER asset_reservation_active_apply
AFTER INSERT ON asset_reservation
WHEN NEW.status='ACTIVA'
BEGIN
  UPDATE asset
  SET quantity_available=quantity_available-NEW.quantity,
      status=CASE
        WHEN (SELECT nature FROM asset_category WHERE id=asset.category_id) IN ('SERIADO','KIT','VEHICULO') THEN 'RESERVADO'
        WHEN quantity_available-NEW.quantity<=0 THEN 'RESERVADO'
        ELSE 'DISPONIBLE' END,
      version=version+1,
      updated_at=NEW.updated_at
  WHERE id=NEW.asset_id;
END;

-- Al liberar/rechazar/cancelar/expirar se repone exactamente lo reservado.
CREATE TRIGGER asset_reservation_release_apply
AFTER UPDATE OF status ON asset_reservation
WHEN OLD.status='ACTIVA' AND NEW.status IN ('LIBERADA','EXPIRADA')
BEGIN
  UPDATE asset
  SET quantity_available=quantity_available+OLD.quantity,
      status=CASE WHEN status='RESERVADO' THEN 'DISPONIBLE' ELSE status END,
      version=version+1,
      updated_at=NEW.updated_at
  WHERE id=OLD.asset_id AND status IN ('RESERVADO','DISPONIBLE');
END;

-- Una reserva activa sólo puede terminar una vez y en estados conocidos.
CREATE TRIGGER asset_reservation_status_transition_guard
BEFORE UPDATE OF status ON asset_reservation
WHEN OLD.status<>'ACTIVA' OR NEW.status NOT IN ('LIBERADA','CONSUMIDA','EXPIRADA')
BEGIN SELECT RAISE(ABORT,'ASSET_RESERVATION_STATUS_INVALID'); END;

-- Congelado de OT en hitos transaccionales nuevos.
CREATE TRIGGER approval_ot_snapshot_guard BEFORE INSERT ON approval
WHEN (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'APPROVAL_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER preparation_ot_snapshot_guard BEFORE INSERT ON request_preparation
WHEN (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'PREPARATION_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER handover_ot_snapshot_guard BEFORE INSERT ON handover
WHEN NEW.request_id IS NOT NULL
 AND (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'HANDOVER_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER custody_ot_snapshot_guard BEFORE INSERT ON custody
WHEN (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'CUSTODY_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER return_declaration_ot_snapshot_guard BEFORE INSERT ON custody_return_declaration
WHEN (SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id)
BEGIN SELECT RAISE(ABORT,'RETURN_DECLARATION_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER return_record_ot_snapshot_guard BEFORE INSERT ON custody_return_record
WHEN (SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id)
BEGIN SELECT RAISE(ABORT,'RETURN_RECORD_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER reception_review_ot_snapshot_guard BEFORE INSERT ON custody_reception_review
WHEN (SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT r.work_order_reference FROM custody c JOIN request r ON r.id=c.request_id WHERE c.id=NEW.custody_id)
BEGIN SELECT RAISE(ABORT,'RECEPTION_REVIEW_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER vehicle_request_ot_snapshot_guard BEFORE INSERT ON vehicle_request_detail
WHEN (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'VEHICLE_REQUEST_OT_SNAPSHOT_REQUIRED'); END;

CREATE TRIGGER vehicle_return_ot_snapshot_guard BEFORE INSERT ON vehicle_return_detail
WHEN (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NOT NULL
 AND COALESCE(NEW.work_order_reference_snapshot,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
BEGIN SELECT RAISE(ABORT,'VEHICLE_RETURN_OT_SNAPSHOT_REQUIRED'); END;

-- Reemplaza congelado histórico de F27 incorporando OT de pedido y forzando herencia en cada ítem.
DROP TRIGGER IF EXISTS request_history_freeze_after_status;
CREATE TRIGGER request_history_freeze_after_status
AFTER UPDATE OF status ON request
WHEN NEW.status IN ('CANCELADA','EXPIRADA','ENTREGADA') AND OLD.status<>NEW.status
BEGIN
  INSERT OR IGNORE INTO request_history_snapshot(
    request_id,requester_person_id,requester_name_snapshot,requester_username_snapshot,
    site_id,site_code_snapshot,site_name_snapshot,location_id,location_code_snapshot,location_name_snapshot,
    frozen_status,frozen_at,created_at,work_order_reference_snapshot
  )
  SELECT NEW.id,NEW.requester_person_id,p.full_name,ua.username,
         NEW.site_id,s.code,s.name,NEW.location_id,sl.code,sl.name,
         NEW.status,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now')),NEW.work_order_reference
  FROM person p
  LEFT JOIN user_account ua ON ua.person_id=NEW.requester_person_id
  JOIN site s ON s.id=NEW.site_id
  JOIN storage_location sl ON sl.id=NEW.location_id
  WHERE p.id=NEW.requester_person_id;

  INSERT OR IGNORE INTO request_item_history_snapshot(
    id,request_id,request_item_id,asset_id,internal_code_snapshot,description_snapshot,
    serial_number_snapshot,license_plate_snapshot,category_id,category_code_snapshot,
    category_name_snapshot,category_nature_snapshot,requires_return_snapshot,unit_of_measure_snapshot,
    quantity_snapshot,work_order_required_snapshot,work_order_reference_snapshot,frozen_at,created_at
  )
  SELECT lower(hex(randomblob(16))),ri.request_id,ri.id,ri.asset_id,a.internal_code,a.description,
         a.serial_number,a.license_plate,a.category_id,ac.code,ac.name,ac.nature,ac.requires_return,
         a.unit_of_measure,ri.quantity,
         CASE WHEN NEW.work_order_reference IS NOT NULL THEN 1 ELSE ri.work_order_required END,
         COALESCE(NEW.work_order_reference,ri.work_order_reference),
         COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM request_item ri JOIN asset a ON a.id=ri.asset_id JOIN asset_category ac ON ac.id=a.category_id
  WHERE ri.request_id=NEW.id;
END;

-- Consulta defendible por OT: pedido, ítems y estado operativo vigente.
CREATE VIEW work_order_request_trace AS
SELECT r.work_order_reference AS work_order_reference,
       r.id AS request_id,r.request_number,r.requester_person_id,r.status AS request_status,
       r.created_at AS requested_at,r.needed_at,r.due_at,
       ri.id AS request_item_id,ri.asset_id,a.internal_code,a.description,
       ac.nature AS category_nature,ri.quantity,ri.status AS request_item_status,
       ar.status AS reservation_status,ar.starts_at AS reserved_at,
       rp.status AS preparation_status,rp.prepared_at,rp.ready_at,
       c.id AS custody_id,c.status AS custody_status,c.opened_at,c.closed_at,
       crr.received_at,crr.condition AS return_condition
FROM request r
JOIN request_item ri ON ri.request_id=r.id
JOIN asset a ON a.id=ri.asset_id
JOIN asset_category ac ON ac.id=a.category_id
LEFT JOIN asset_reservation ar ON ar.request_item_id=ri.id
LEFT JOIN request_preparation rp ON rp.request_id=r.id
LEFT JOIN custody c ON c.request_item_id=ri.id
LEFT JOIN custody_return_record crr ON crr.custody_id=c.id;

-- +down
DROP VIEW IF EXISTS work_order_request_trace;
DROP TRIGGER IF EXISTS request_history_freeze_after_status;
DROP TRIGGER IF EXISTS vehicle_return_ot_snapshot_guard;
DROP TRIGGER IF EXISTS vehicle_request_ot_snapshot_guard;
DROP TRIGGER IF EXISTS reception_review_ot_snapshot_guard;
DROP TRIGGER IF EXISTS return_record_ot_snapshot_guard;
DROP TRIGGER IF EXISTS return_declaration_ot_snapshot_guard;
DROP TRIGGER IF EXISTS custody_ot_snapshot_guard;
DROP TRIGGER IF EXISTS handover_ot_snapshot_guard;
DROP TRIGGER IF EXISTS preparation_ot_snapshot_guard;
DROP TRIGGER IF EXISTS approval_ot_snapshot_guard;
DROP TRIGGER IF EXISTS asset_reservation_status_transition_guard;
DROP TRIGGER IF EXISTS asset_reservation_release_apply;
DROP TRIGGER IF EXISTS asset_reservation_active_apply;
DROP TRIGGER IF EXISTS asset_reservation_active_insert_guard;
DROP TRIGGER IF EXISTS asset_reservation_identity_immutable;
DROP TRIGGER IF EXISTS request_item_ot_immutable;
DROP TRIGGER IF EXISTS request_item_ot_inherit_insert;
DROP TRIGGER IF EXISTS request_ot_immutable;
DROP TRIGGER IF EXISTS request_ot_format_update;
DROP TRIGGER IF EXISTS request_ot_format_insert;
DROP TRIGGER IF EXISTS request_ot_required_insert;
DROP INDEX IF EXISTS ix_request_work_order_reference;
-- Columnas 045 se conservan en una reversión manual por compatibilidad SQLite.
