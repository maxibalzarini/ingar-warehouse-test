-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE notification_phase16 (
  id TEXT PRIMARY KEY,
  recipient_person_id TEXT REFERENCES person(id),
  recipient_user_id TEXT REFERENCES user_account(id),
  type TEXT NOT NULL CHECK(type IN (
    'MANTENIMIENTO_PROXIMO','MANTENIMIENTO_VENCIDO','CUSTODIA_PROXIMA','CUSTODIA_VENCIDA',
    'DEVOLUCION_DECLARADA','CUSTODIA_ANOMALIA','SOLICITUD_ATRASADA','HABILITACION_PROXIMA','SISTEMA','INCIDENTE'
  )),
  channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK(channel IN ('IN_APP','EMAIL')),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA','CANCELADA')),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  dedup_key TEXT UNIQUE,
  scheduled_at TEXT NOT NULL,
  sent_at TEXT,
  read_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(recipient_person_id IS NOT NULL OR recipient_user_id IS NOT NULL)
);

INSERT INTO notification_phase16(
  id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,
  scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
)
SELECT id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,
  scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
FROM notification;

DROP TABLE notification;
ALTER TABLE notification_phase16 RENAME TO notification;
CREATE INDEX ix_notification_recipient ON notification(recipient_user_id,recipient_person_id,status,scheduled_at);
CREATE INDEX ix_notification_entity ON notification(entity_type,entity_id,type);

-- Elimina exclusivamente la tolerancia heredada de fábrica de 30 minutos.
-- Los valores personalizados distintos de 30 se conservan.
UPDATE system_setting
SET value_json='0',version=version+1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')
WHERE scope_type='SYSTEM' AND scope_id='GLOBAL'
  AND key='notification.custodyOverdueMinutes' AND value_json='30';

CREATE TABLE custody_return_record (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL UNIQUE REFERENCES custody(id),
  handover_id TEXT NOT NULL UNIQUE REFERENCES handover(id),
  inspection_id TEXT NOT NULL UNIQUE REFERENCES inspection(id),
  incident_id TEXT REFERENCES incident(id),
  due_at_snapshot TEXT,
  received_at TEXT NOT NULL,
  timing_status TEXT NOT NULL CHECK(timing_status IN ('EN_TERMINO','FUERA_DE_TERMINO','SIN_VENCIMIENTO')),
  overdue_seconds INTEGER NOT NULL DEFAULT 0 CHECK(overdue_seconds >= 0),
  condition TEXT NOT NULL CHECK(condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  notes TEXT,
  recorded_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_custody_return_timing ON custody_return_record(timing_status,received_at DESC);
CREATE INDEX ix_custody_return_condition ON custody_return_record(condition,received_at DESC);

CREATE TABLE custody_integrity_anomaly (
  id TEXT PRIMARY KEY,
  anomaly_key TEXT NOT NULL UNIQUE,
  anomaly_type TEXT NOT NULL CHECK(anomaly_type IN (
    'ENTREGA_RETORNABLE_SIN_CUSTODIA','CUSTODIA_SIN_VENCIMIENTO','CUSTODIA_SIN_ENTREGA',
    'CUSTODIA_DUPLICADA','SIN_OPERADOR_DE_PANOL'
  )),
  status TEXT NOT NULL CHECK(status IN ('ABIERTA','REQUIERE_REVISION','REPARADA','DESCARTADA')),
  request_id TEXT REFERENCES request(id),
  request_item_id TEXT REFERENCES request_item(id),
  custody_id TEXT REFERENCES custody(id),
  handover_id TEXT REFERENCES handover(id),
  asset_id TEXT REFERENCES asset(id),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  details_json TEXT NOT NULL DEFAULT '{}',
  detected_at TEXT NOT NULL,
  resolved_at TEXT,
  resolution TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX ix_custody_integrity_status ON custody_integrity_anomaly(status,anomaly_type,detected_at DESC);
CREATE INDEX ix_custody_integrity_request ON custody_integrity_anomaly(request_id,request_item_id);

CREATE TRIGGER custody_return_record_immutable_update BEFORE UPDATE ON custody_return_record BEGIN SELECT RAISE(ABORT, 'CUSTODY_RETURN_RECORD_IMMUTABLE'); END;
CREATE TRIGGER custody_return_record_immutable_delete BEFORE DELETE ON custody_return_record BEGIN SELECT RAISE(ABORT, 'CUSTODY_RETURN_RECORD_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS custody_return_record_immutable_delete;
DROP TRIGGER IF EXISTS custody_return_record_immutable_update;
DROP TABLE IF EXISTS custody_integrity_anomaly;
DROP TABLE IF EXISTS custody_return_record;

CREATE TABLE notification_phase15 (
  id TEXT PRIMARY KEY,
  recipient_person_id TEXT REFERENCES person(id),
  recipient_user_id TEXT REFERENCES user_account(id),
  type TEXT NOT NULL CHECK(type IN ('MANTENIMIENTO_PROXIMO','MANTENIMIENTO_VENCIDO','CUSTODIA_VENCIDA','HABILITACION_PROXIMA','SISTEMA','INCIDENTE')),
  channel TEXT NOT NULL DEFAULT 'IN_APP' CHECK(channel IN ('IN_APP','EMAIL')),
  status TEXT NOT NULL DEFAULT 'PENDIENTE' CHECK(status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA','CANCELADA')),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  dedup_key TEXT UNIQUE,
  scheduled_at TEXT NOT NULL,
  sent_at TEXT,
  read_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(recipient_person_id IS NOT NULL OR recipient_user_id IS NOT NULL)
);

INSERT INTO notification_phase15(
  id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,
  scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
)
SELECT id,recipient_person_id,recipient_user_id,
  CASE WHEN type IN ('CUSTODIA_PROXIMA','DEVOLUCION_DECLARADA','CUSTODIA_ANOMALIA','SOLICITUD_ATRASADA') THEN 'SISTEMA' ELSE type END,
  channel,status,subject,body,entity_type,entity_id,dedup_key,scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at
FROM notification;

DROP TABLE notification;
ALTER TABLE notification_phase15 RENAME TO notification;
CREATE INDEX ix_notification_recipient ON notification(recipient_user_id,recipient_person_id,status,scheduled_at);
CREATE INDEX ix_notification_entity ON notification(entity_type,entity_id,type);
