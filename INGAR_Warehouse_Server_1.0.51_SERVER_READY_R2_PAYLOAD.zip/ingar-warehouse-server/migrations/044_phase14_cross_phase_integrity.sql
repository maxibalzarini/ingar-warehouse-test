-- +up
PRAGMA foreign_keys = ON;

-- F30 / Fase 14: cierre transversal de trazabilidad e invariantes históricas.
-- No reescribe datos; únicamente endurece transiciones futuras y evita alteraciones
-- retroactivas de vínculos que ya fueron utilizados por pedidos, devoluciones o auditoría.

-- Historial de supervisión: una asignación activa sólo puede cerrarse definiendo effective_to.
-- Identidad, supervisor, actor, inicio, motivo y creación quedan congelados desde el alta.
CREATE TRIGGER user_supervisor_assignment_update_guard
BEFORE UPDATE ON user_supervisor_assignment
WHEN OLD.effective_to IS NOT NULL
   OR NEW.user_id IS NOT OLD.user_id
   OR NEW.supervisor_user_id IS NOT OLD.supervisor_user_id
   OR NEW.assigned_by_user_id IS NOT OLD.assigned_by_user_id
   OR NEW.effective_from IS NOT OLD.effective_from
   OR NEW.reason IS NOT OLD.reason
   OR NEW.created_at IS NOT OLD.created_at
   OR NEW.effective_to IS NULL
BEGIN
  SELECT RAISE(ABORT, 'USER_SUPERVISOR_ASSIGNMENT_HISTORY_IMMUTABLE');
END;

CREATE TRIGGER user_supervisor_assignment_delete_guard
BEFORE DELETE ON user_supervisor_assignment
BEGIN
  SELECT RAISE(ABORT, 'USER_SUPERVISOR_ASSIGNMENT_HISTORY_IMMUTABLE');
END;

-- Eventos de blanqueo: sólo se permite completar/cancelar un evento PENDING.
-- Todos los snapshots de identidad y autoridad permanecen inmutables.
CREATE TRIGGER password_reset_event_transition_guard
BEFORE UPDATE ON password_reset_event
WHEN OLD.status <> 'PENDING'
   OR NEW.target_user_id IS NOT OLD.target_user_id
   OR NEW.target_person_id IS NOT OLD.target_person_id
   OR NEW.target_username_snapshot IS NOT OLD.target_username_snapshot
   OR NEW.reset_by_user_id IS NOT OLD.reset_by_user_id
   OR NEW.supervisor_user_id_snapshot IS NOT OLD.supervisor_user_id_snapshot
   OR NEW.reset_mode IS NOT OLD.reset_mode
   OR NEW.authority_scope IS NOT OLD.authority_scope
   OR NEW.requested_at IS NOT OLD.requested_at
   OR NEW.created_at IS NOT OLD.created_at
   OR NEW.status NOT IN ('COMPLETED','CANCELLED')
   OR (NEW.status='COMPLETED' AND NEW.completed_at IS NULL)
   OR (NEW.status='CANCELLED' AND NEW.completed_at IS NOT NULL)
BEGIN
  SELECT RAISE(ABORT, 'PASSWORD_RESET_EVENT_HISTORY_IMMUTABLE');
END;

CREATE TRIGGER password_reset_event_delete_guard
BEFORE DELETE ON password_reset_event
BEGIN
  SELECT RAISE(ABORT, 'PASSWORD_RESET_EVENT_HISTORY_IMMUTABLE');
END;

-- Prechequeos de baja/deshabilitación: mientras están PENDING pueden concluir,
-- pero no puede cambiarse retrospectivamente la identidad ni los conteos congelados.
CREATE TRIGGER user_lifecycle_event_transition_guard
BEFORE UPDATE ON user_lifecycle_event
WHEN OLD.status <> 'PENDING'
   OR NEW.target_user_id IS NOT OLD.target_user_id
   OR NEW.target_person_id IS NOT OLD.target_person_id
   OR NEW.target_username_snapshot IS NOT OLD.target_username_snapshot
   OR NEW.target_name_snapshot IS NOT OLD.target_name_snapshot
   OR NEW.action IS NOT OLD.action
   OR NEW.requested_by_user_id IS NOT OLD.requested_by_user_id
   OR NEW.requested_at IS NOT OLD.requested_at
   OR NEW.target_user_version_snapshot IS NOT OLD.target_user_version_snapshot
   OR NEW.request_count_snapshot IS NOT OLD.request_count_snapshot
   OR NEW.historical_request_count_snapshot IS NOT OLD.historical_request_count_snapshot
   OR NEW.active_request_count_snapshot IS NOT OLD.active_request_count_snapshot
   OR NEW.open_custody_count_snapshot IS NOT OLD.open_custody_count_snapshot
   OR NEW.pending_warehouse_return_count_snapshot IS NOT OLD.pending_warehouse_return_count_snapshot
   OR NEW.correlation_id IS NOT OLD.correlation_id
   OR NEW.created_at IS NOT OLD.created_at
BEGIN
  SELECT RAISE(ABORT, 'USER_LIFECYCLE_EVENT_HISTORY_IMMUTABLE');
END;

-- Asignaciones de kit ya cerradas son historia. No pueden reabrirse ni borrarse.
CREATE TRIGGER kit_person_assignment_closed_guard
BEFORE UPDATE ON kit_person_assignment
WHEN OLD.status='CLOSED'
BEGIN
  SELECT RAISE(ABORT, 'KIT_PERSON_ASSIGNMENT_CLOSED_IMMUTABLE');
END;

CREATE TRIGGER kit_person_assignment_delete_guard
BEFORE DELETE ON kit_person_assignment
BEGIN
  SELECT RAISE(ABORT, 'KIT_PERSON_ASSIGNMENT_HISTORY_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS kit_person_assignment_delete_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_closed_guard;
DROP TRIGGER IF EXISTS user_lifecycle_event_transition_guard;
DROP TRIGGER IF EXISTS password_reset_event_delete_guard;
DROP TRIGGER IF EXISTS password_reset_event_transition_guard;
DROP TRIGGER IF EXISTS user_supervisor_assignment_delete_guard;
DROP TRIGGER IF EXISTS user_supervisor_assignment_update_guard;
