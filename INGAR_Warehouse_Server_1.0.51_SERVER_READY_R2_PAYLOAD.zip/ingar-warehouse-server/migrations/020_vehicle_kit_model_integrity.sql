-- +up
PRAGMA foreign_keys = ON;

-- Reparación conservadora de registros especializados faltantes.
INSERT OR IGNORE INTO vehicle_profile(
  asset_id, vin, chassis_number, engine_number, manufacture_year, vehicle_class,
  current_odometer, current_hourmeter, fuel_type, fuel_capacity,
  required_license_class, active, version, created_at, updated_at,
  usage_unit, km_per_hour
)
SELECT
  a.id, NULL, NULL, NULL, NULL, NULL,
  COALESCE(a.odometer, 0), 0, a.fuel_type, NULL,
  NULL, a.active, 1, COALESCE(a.created_at, CURRENT_TIMESTAMP), COALESCE(a.updated_at, CURRENT_TIMESTAMP),
  'KILOMETROS', 50
FROM asset a
JOIN asset_category c ON c.id = a.category_id
WHERE c.nature = 'VEHICULO';

INSERT OR IGNORE INTO kit_definition(
  kit_asset_id, allow_incomplete_with_authorization, notes,
  version, created_at, updated_at
)
SELECT
  a.id, 0, NULL,
  1, COALESCE(a.created_at, CURRENT_TIMESTAMP), COALESCE(a.updated_at, CURRENT_TIMESTAMP)
FROM asset a
JOIN asset_category c ON c.id = a.category_id
WHERE c.nature = 'KIT';

-- Todo vehículo nuevo obtiene perfil estructural en la misma transacción SQL.
CREATE TRIGGER asset_vehicle_profile_after_insert
AFTER INSERT ON asset
WHEN (SELECT nature FROM asset_category WHERE id = NEW.category_id) = 'VEHICULO'
BEGIN
  INSERT INTO vehicle_profile(
    asset_id, vin, chassis_number, engine_number, manufacture_year, vehicle_class,
    current_odometer, current_hourmeter, fuel_type, fuel_capacity,
    required_license_class, active, version, created_at, updated_at,
    usage_unit, km_per_hour
  ) VALUES (
    NEW.id, NULL, NULL, NULL, NULL, NULL,
    COALESCE(NEW.odometer, 0), 0, NEW.fuel_type, NULL,
    NULL, NEW.active, 1, NEW.created_at, NEW.updated_at,
    'KILOMETROS', 50
  );
END;

-- Todo kit nuevo obtiene definición estructural en la misma transacción SQL.
CREATE TRIGGER asset_kit_definition_after_insert
AFTER INSERT ON asset
WHEN (SELECT nature FROM asset_category WHERE id = NEW.category_id) = 'KIT'
BEGIN
  INSERT INTO kit_definition(
    kit_asset_id, allow_incomplete_with_authorization, notes,
    version, created_at, updated_at
  ) VALUES (
    NEW.id, 0, NULL,
    1, NEW.created_at, NEW.updated_at
  );
END;

-- Un bien solamente puede cambiar a otra categoría de la misma naturaleza.
CREATE TRIGGER asset_nature_change_guard
BEFORE UPDATE OF category_id ON asset
WHEN OLD.category_id <> NEW.category_id
 AND (SELECT nature FROM asset_category WHERE id = OLD.category_id)
     <> (SELECT nature FROM asset_category WHERE id = NEW.category_id)
BEGIN
  SELECT RAISE(ABORT, 'ASSET_NATURE_CHANGE_FORBIDDEN');
END;

-- La naturaleza de una categoría con cualquier bien histórico queda congelada.
CREATE TRIGGER category_nature_change_guard
BEFORE UPDATE OF nature ON asset_category
WHEN OLD.nature <> NEW.nature
 AND EXISTS (SELECT 1 FROM asset WHERE category_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_NATURE_CHANGE_WITH_ASSETS_FORBIDDEN');
END;

-- No se admiten perfiles vehiculares asociados a bienes de otra naturaleza.
CREATE TRIGGER vehicle_profile_nature_insert_guard
BEFORE INSERT ON vehicle_profile
WHEN COALESCE((
  SELECT c.nature
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = NEW.asset_id
), '') <> 'VEHICULO'
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_PROFILE_NATURE_INVALID');
END;

CREATE TRIGGER vehicle_profile_nature_update_guard
BEFORE UPDATE OF asset_id ON vehicle_profile
WHEN COALESCE((
  SELECT c.nature
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = NEW.asset_id
), '') <> 'VEHICULO'
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_PROFILE_NATURE_INVALID');
END;

CREATE TRIGGER vehicle_profile_delete_guard
BEFORE DELETE ON vehicle_profile
WHEN EXISTS (
  SELECT 1
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = OLD.asset_id AND c.nature = 'VEHICULO'
)
BEGIN
  SELECT RAISE(ABORT, 'VEHICLE_PROFILE_REQUIRED');
END;

-- No se admiten definiciones de kit asociadas a bienes de otra naturaleza.
CREATE TRIGGER kit_definition_nature_insert_guard
BEFORE INSERT ON kit_definition
WHEN COALESCE((
  SELECT c.nature
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = NEW.kit_asset_id
), '') <> 'KIT'
BEGIN
  SELECT RAISE(ABORT, 'KIT_DEFINITION_NATURE_INVALID');
END;

CREATE TRIGGER kit_definition_nature_update_guard
BEFORE UPDATE OF kit_asset_id ON kit_definition
WHEN COALESCE((
  SELECT c.nature
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = NEW.kit_asset_id
), '') <> 'KIT'
BEGIN
  SELECT RAISE(ABORT, 'KIT_DEFINITION_NATURE_INVALID');
END;

CREATE TRIGGER kit_definition_delete_guard
BEFORE DELETE ON kit_definition
WHEN EXISTS (
  SELECT 1
  FROM asset a JOIN asset_category c ON c.id = a.category_id
  WHERE a.id = OLD.kit_asset_id AND c.nature = 'KIT'
)
BEGIN
  SELECT RAISE(ABORT, 'KIT_DEFINITION_REQUIRED');
END;

-- +down
DROP TRIGGER IF EXISTS kit_definition_delete_guard;
DROP TRIGGER IF EXISTS kit_definition_nature_update_guard;
DROP TRIGGER IF EXISTS kit_definition_nature_insert_guard;
DROP TRIGGER IF EXISTS vehicle_profile_delete_guard;
DROP TRIGGER IF EXISTS vehicle_profile_nature_update_guard;
DROP TRIGGER IF EXISTS vehicle_profile_nature_insert_guard;
DROP TRIGGER IF EXISTS category_nature_change_guard;
DROP TRIGGER IF EXISTS asset_nature_change_guard;
DROP TRIGGER IF EXISTS asset_kit_definition_after_insert;
DROP TRIGGER IF EXISTS asset_vehicle_profile_after_insert;
