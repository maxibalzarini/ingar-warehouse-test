-- +up
-- Fase 2: la OT es una regla de cada bien. El pedido conserva una única referencia
-- cuando uno o más ítems la requieren, sin reescribir snapshots históricos.
DROP TRIGGER IF EXISTS request_ot_required_insert;
DROP TRIGGER IF EXISTS request_item_ot_inherit_insert;
DROP TRIGGER IF EXISTS asset_reservation_active_insert_guard;
DROP TRIGGER IF EXISTS request_history_freeze_after_status;

CREATE TRIGGER request_item_ot_requirement_insert
BEFORE INSERT ON request_item
WHEN NEW.work_order_required NOT IN (0,1)
  OR (NEW.work_order_required=1 AND (
    (SELECT work_order_reference FROM request WHERE id=NEW.request_id) IS NULL
    OR COALESCE(NEW.work_order_reference,'')<>(SELECT work_order_reference FROM request WHERE id=NEW.request_id)
  ))
  OR (NEW.work_order_required=0 AND COALESCE(NEW.work_order_reference,'')<>COALESCE((SELECT work_order_reference FROM request WHERE id=NEW.request_id),''))
BEGIN SELECT RAISE(ABORT,'REQUEST_ITEM_WORK_ORDER_REQUIREMENT_INVALID'); END;

CREATE TRIGGER asset_reservation_active_insert_guard
BEFORE INSERT ON asset_reservation
WHEN NEW.status='ACTIVA'
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM request_item ri JOIN request r ON r.id=ri.request_id
    WHERE ri.id=NEW.request_item_id AND ri.request_id=NEW.request_id AND ri.asset_id=NEW.asset_id
      AND abs(ri.quantity-NEW.quantity)<0.0000001
      AND ((ri.work_order_required=1 AND r.work_order_reference IS NOT NULL AND NEW.work_order_reference_snapshot=r.work_order_reference)
        OR (ri.work_order_required=0 AND COALESCE(NEW.work_order_reference_snapshot,'')=COALESCE(r.work_order_reference,'')))
  ) THEN RAISE(ABORT,'ASSET_RESERVATION_REQUEST_MISMATCH') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    WHERE a.id=NEW.asset_id AND a.active=1 AND a.deleted_at IS NULL
      AND a.status='DISPONIBLE' AND a.quantity_available>=NEW.quantity
      AND (ac.nature NOT IN ('SERIADO','KIT','VEHICULO') OR NEW.quantity=1)
  ) THEN RAISE(ABORT,'ASSET_RESERVATION_NOT_AVAILABLE') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    JOIN kit_definition kd ON kd.kit_asset_id=a.id AND kd.ownership_mode='PERSONAL'
    WHERE a.id=NEW.asset_id AND ac.nature='KIT'
      AND NOT EXISTS (SELECT 1 FROM kit_person_assignment kpa JOIN request r ON r.id=NEW.request_id
        WHERE kpa.kit_asset_id=a.id AND kpa.person_id=r.requester_person_id AND kpa.status='ACTIVE')
  ) THEN RAISE(ABORT,'KIT_PERSONAL_REQUESTER_ONLY') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM kit_component kc JOIN asset_reservation kar ON kar.asset_id=kc.kit_asset_id AND kar.status='ACTIVA'
    WHERE kc.component_asset_id=NEW.asset_id AND kc.active=1
  ) THEN RAISE(ABORT,'KIT_COMPONENT_RESERVED_BY_KIT') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    WHERE a.id=NEW.asset_id AND ac.nature='KIT' AND EXISTS (
      SELECT 1 FROM kit_component kc
      LEFT JOIN asset_reservation ar ON ar.asset_id=kc.component_asset_id AND ar.status='ACTIVA'
      LEFT JOIN custody c ON c.asset_id=kc.component_asset_id AND c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')
      WHERE kc.kit_asset_id=NEW.asset_id AND kc.active=1 AND (ar.id IS NOT NULL OR c.id IS NOT NULL)
    )
  ) THEN RAISE(ABORT,'KIT_COMPONENT_NOT_AVAILABLE') END;
END;

CREATE TRIGGER request_history_freeze_after_status
AFTER UPDATE OF status ON request
WHEN NEW.status IN ('CANCELADA','EXPIRADA','ENTREGADA') AND OLD.status<>NEW.status
BEGIN
  INSERT OR IGNORE INTO request_history_snapshot(request_id,requester_person_id,requester_name_snapshot,requester_username_snapshot,site_id,site_code_snapshot,site_name_snapshot,location_id,location_code_snapshot,location_name_snapshot,frozen_status,frozen_at,created_at,work_order_reference_snapshot)
  SELECT NEW.id,NEW.requester_person_id,p.full_name,ua.username,NEW.site_id,s.code,s.name,NEW.location_id,sl.code,sl.name,NEW.status,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now')),NEW.work_order_reference
  FROM person p LEFT JOIN user_account ua ON ua.person_id=NEW.requester_person_id JOIN site s ON s.id=NEW.site_id JOIN storage_location sl ON sl.id=NEW.location_id WHERE p.id=NEW.requester_person_id;
  INSERT OR IGNORE INTO request_item_history_snapshot(id,request_id,request_item_id,asset_id,internal_code_snapshot,description_snapshot,serial_number_snapshot,license_plate_snapshot,category_id,category_code_snapshot,category_name_snapshot,category_nature_snapshot,requires_return_snapshot,unit_of_measure_snapshot,quantity_snapshot,work_order_required_snapshot,work_order_reference_snapshot,frozen_at,created_at)
  SELECT lower(hex(randomblob(16))),ri.request_id,ri.id,ri.asset_id,a.internal_code,a.description,a.serial_number,a.license_plate,a.category_id,ac.code,ac.name,ac.nature,ac.requires_return,a.unit_of_measure,ri.quantity,ri.work_order_required,ri.work_order_reference,COALESCE(NEW.updated_at,datetime('now')),COALESCE(NEW.updated_at,datetime('now'))
  FROM request_item ri JOIN asset a ON a.id=ri.asset_id JOIN asset_category ac ON ac.id=a.category_id WHERE ri.request_id=NEW.id;
END;

-- +down
DROP TRIGGER IF EXISTS request_item_ot_requirement_insert;
