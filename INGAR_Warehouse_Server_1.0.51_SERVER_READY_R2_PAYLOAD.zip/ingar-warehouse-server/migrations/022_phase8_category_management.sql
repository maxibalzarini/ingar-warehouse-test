-- +up
PRAGMA foreign_keys = ON;

CREATE INDEX ix_asset_category_state
ON asset_category(active, deleted_at, nature, code);

CREATE TRIGGER asset_category_hard_delete_guard
BEFORE DELETE ON asset_category
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_HARD_DELETE_FORBIDDEN');
END;

CREATE TRIGGER asset_category_soft_delete_asset_guard
BEFORE UPDATE OF deleted_at ON asset_category
WHEN OLD.deleted_at IS NULL
 AND NEW.deleted_at IS NOT NULL
 AND EXISTS (
   SELECT 1 FROM asset a
   WHERE a.category_id = OLD.id
 )
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_DELETE_BLOCKED_ASSETS');
END;

CREATE TRIGGER asset_category_soft_delete_state_guard
BEFORE UPDATE OF deleted_at ON asset_category
WHEN OLD.deleted_at IS NULL
 AND NEW.deleted_at IS NOT NULL
 AND NEW.active <> 0
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_DELETE_REQUIRES_INACTIVE');
END;

CREATE TRIGGER asset_category_undelete_guard
BEFORE UPDATE OF deleted_at ON asset_category
WHEN OLD.deleted_at IS NOT NULL
 AND NEW.deleted_at IS NULL
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_UNDELETE_FORBIDDEN');
END;

CREATE TRIGGER asset_category_deleted_reactivate_guard
BEFORE UPDATE OF active ON asset_category
WHEN OLD.deleted_at IS NOT NULL
 AND NEW.active <> OLD.active
BEGIN
  SELECT RAISE(ABORT, 'CATEGORY_DELETED_STATE_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS asset_category_deleted_reactivate_guard;
DROP TRIGGER IF EXISTS asset_category_undelete_guard;
DROP TRIGGER IF EXISTS asset_category_soft_delete_state_guard;
DROP TRIGGER IF EXISTS asset_category_soft_delete_asset_guard;
DROP TRIGGER IF EXISTS asset_category_hard_delete_guard;
DROP INDEX IF EXISTS ix_asset_category_state;
