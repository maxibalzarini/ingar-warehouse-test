-- +up
PRAGMA foreign_keys = ON;

-- F7.1 structural repair:
-- PERSONAL_KIT is a logical membership/reservation. It must never be represented
-- by consuming the physical quantity of the component. This table records the
-- physical baseline at the moment a component becomes part of an actively
-- assigned personal kit, so a legacy/foreign mutation can be reconciled safely
-- without guessing stock.
CREATE TABLE kit_component_membership_state (
  id TEXT PRIMARY KEY,
  kit_asset_id TEXT NOT NULL REFERENCES asset(id),
  component_asset_id TEXT NOT NULL REFERENCES asset(id),
  baseline_quantity_available REAL NOT NULL CHECK(baseline_quantity_available >= 0),
  baseline_status TEXT NOT NULL,
  baseline_custodian_person_id TEXT REFERENCES person(id),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  activated_at TEXT NOT NULL,
  released_at TEXT,
  release_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE UNIQUE INDEX ux_kit_component_membership_state_active
  ON kit_component_membership_state(kit_asset_id, component_asset_id)
  WHERE active=1;

CREATE INDEX ix_kit_component_membership_state_component
  ON kit_component_membership_state(component_asset_id, active);

-- Seed currently active personal-kit memberships using the physical state that
-- exists at migration time. This is traceability only; the migration does not
-- alter any asset quantity or status.
INSERT INTO kit_component_membership_state(
  id,kit_asset_id,component_asset_id,
  baseline_quantity_available,baseline_status,baseline_custodian_person_id,
  active,activated_at,released_at,release_reason,version,created_at,updated_at
)
SELECT lower(hex(randomblob(16))), kc.kit_asset_id, kc.component_asset_id,
       a.quantity_available, a.status, a.custodian_person_id,
       1, COALESCE(kpa.assigned_at, datetime('now')), NULL, NULL, 1,
       datetime('now'), datetime('now')
FROM kit_component kc
JOIN kit_person_assignment kpa
  ON kpa.kit_asset_id=kc.kit_asset_id AND kpa.status='ACTIVE'
JOIN asset ka
  ON ka.id=kc.kit_asset_id AND ka.deleted_at IS NULL AND ka.active=1 AND ka.status<>'BAJA'
JOIN asset a
  ON a.id=kc.component_asset_id AND a.deleted_at IS NULL
WHERE kc.active=1
  AND NOT EXISTS (
    SELECT 1 FROM kit_component_membership_state kms
    WHERE kms.kit_asset_id=kc.kit_asset_id
      AND kms.component_asset_id=kc.component_asset_id
      AND kms.active=1
  );

-- +down
DROP INDEX IF EXISTS ix_kit_component_membership_state_component;
DROP INDEX IF EXISTS ux_kit_component_membership_state_active;
DROP TABLE IF EXISTS kit_component_membership_state;
