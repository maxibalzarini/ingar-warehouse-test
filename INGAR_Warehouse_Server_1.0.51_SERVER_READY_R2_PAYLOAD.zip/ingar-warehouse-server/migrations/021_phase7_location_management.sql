-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE storage_location ADD COLUMN deleted_at TEXT;

CREATE INDEX ix_storage_location_state
ON storage_location(site_id, active, deleted_at, code);

CREATE TRIGGER storage_location_hard_delete_guard
BEFORE DELETE ON storage_location
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_HARD_DELETE_FORBIDDEN');
END;

CREATE TRIGGER storage_location_soft_delete_asset_guard
BEFORE UPDATE OF deleted_at ON storage_location
WHEN OLD.deleted_at IS NULL
 AND NEW.deleted_at IS NOT NULL
 AND EXISTS (
   SELECT 1 FROM asset a
   WHERE a.location_id = OLD.id
     AND a.deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_DELETE_BLOCKED_ASSETS');
END;

CREATE TRIGGER storage_location_deactivate_asset_guard
BEFORE UPDATE OF active ON storage_location
WHEN OLD.deleted_at IS NULL
 AND OLD.active = 1
 AND NEW.active = 0
 AND EXISTS (
   SELECT 1 FROM asset a
   WHERE a.location_id = OLD.id
     AND a.deleted_at IS NULL
     AND a.active = 1
 )
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_DEACTIVATE_BLOCKED_ACTIVE_ASSETS');
END;

CREATE TRIGGER storage_location_reactivate_site_guard
BEFORE UPDATE OF active ON storage_location
WHEN OLD.deleted_at IS NULL
 AND OLD.active = 0
 AND NEW.active = 1
 AND NOT EXISTS (
   SELECT 1 FROM site s
   WHERE s.id = OLD.site_id
     AND s.active = 1
 )
BEGIN
  SELECT RAISE(ABORT, 'LOCATION_REACTIVATE_BLOCKED_SITE_INACTIVE');
END;

-- +down
DROP TRIGGER IF EXISTS storage_location_reactivate_site_guard;
DROP TRIGGER IF EXISTS storage_location_deactivate_asset_guard;
DROP TRIGGER IF EXISTS storage_location_soft_delete_asset_guard;
DROP TRIGGER IF EXISTS storage_location_hard_delete_guard;
DROP INDEX IF EXISTS ix_storage_location_state;
ALTER TABLE storage_location DROP COLUMN deleted_at;
