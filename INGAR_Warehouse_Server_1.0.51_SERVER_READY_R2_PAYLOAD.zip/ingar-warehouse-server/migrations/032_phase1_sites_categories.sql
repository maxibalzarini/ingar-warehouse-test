-- +up
PRAGMA foreign_keys = ON;

UPDATE organization SET name='Organización', version=version+1, updated_at=datetime('now')
WHERE name='INGAR Warehouse Controller';

UPDATE system_setting SET value_json='"Organización"', version=version+1, updated_at=datetime('now')
WHERE scope_type='SYSTEM' AND scope_id='GLOBAL' AND key='organization.name' AND value_json='"INGAR Warehouse Controller"';

ALTER TABLE site ADD COLUMN is_primary INTEGER NOT NULL DEFAULT 0 CHECK(is_primary IN (0,1));
ALTER TABLE site ADD COLUMN description TEXT;

UPDATE site
SET is_primary = 1
WHERE id IN (
  SELECT s1.id
  FROM site s1
  WHERE s1.id = (
    SELECT s2.id
    FROM site s2
    WHERE s2.organization_id = s1.organization_id
    ORDER BY s2.active DESC, s2.created_at ASC, s2.id ASC
    LIMIT 1
  )
);

CREATE UNIQUE INDEX ux_site_primary_per_organization
ON site(organization_id)
WHERE is_primary = 1;

CREATE TABLE site_asset_category (
  site_id TEXT NOT NULL REFERENCES site(id),
  category_id TEXT NOT NULL REFERENCES asset_category(id),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(site_id, category_id)
);

CREATE INDEX ix_site_asset_category_active
ON site_asset_category(site_id, active, category_id);

INSERT INTO site_asset_category(site_id, category_id, active, version, created_at, updated_at)
SELECT s.id, c.id, 1, 1, datetime('now'), datetime('now')
FROM site s
CROSS JOIN asset_category c
WHERE c.deleted_at IS NULL;

-- +down
DROP INDEX IF EXISTS ix_site_asset_category_active;
DROP TABLE IF EXISTS site_asset_category;
DROP INDEX IF EXISTS ux_site_primary_per_organization;
ALTER TABLE site DROP COLUMN description;
ALTER TABLE site DROP COLUMN is_primary;
