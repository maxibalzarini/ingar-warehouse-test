-- +up
PRAGMA foreign_keys = ON;

-- F22 / Fase 6: revisión explícita de recepción antes de cerrar una devolución.
-- El comentario del pañolero queda separado de la declaración del usuario y es inmutable.
CREATE TABLE custody_reception_review (
  id TEXT PRIMARY KEY,
  custody_id TEXT NOT NULL UNIQUE REFERENCES custody(id),
  handover_id TEXT NOT NULL UNIQUE REFERENCES handover(id),
  return_record_id TEXT NOT NULL UNIQUE REFERENCES custody_return_record(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  reviewer_user_id TEXT NOT NULL REFERENCES user_account(id),
  source_mode TEXT NOT NULL CHECK(source_mode IN ('F22_REVIEW','LEGACY_BACKFILL')),
  asset_nature_snapshot TEXT NOT NULL,
  declared_condition_snapshot TEXT NOT NULL,
  declared_problem_reported_snapshot INTEGER NOT NULL DEFAULT 0 CHECK(declared_problem_reported_snapshot IN (0,1)),
  declared_comment_snapshot TEXT,
  operator_condition TEXT NOT NULL CHECK(operator_condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  operator_comment TEXT,
  effective_condition TEXT NOT NULL CHECK(effective_condition IN ('CONFORME','OBSERVADO','DANADO','INCOMPLETO')),
  comment_forced_observation INTEGER NOT NULL DEFAULT 0 CHECK(comment_forced_observation IN (0,1)),
  blocked_after_receipt INTEGER NOT NULL DEFAULT 0 CHECK(blocked_after_receipt IN (0,1)),
  incident_id TEXT REFERENCES incident(id),
  correlation_id TEXT NOT NULL,
  reviewed_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_custody_reception_review_asset ON custody_reception_review(asset_id, reviewed_at DESC);
CREATE INDEX ix_custody_reception_review_reviewer ON custody_reception_review(reviewer_user_id, reviewed_at DESC);

CREATE TRIGGER custody_reception_review_immutable_update
BEFORE UPDATE ON custody_reception_review
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RECEPTION_REVIEW_IMMUTABLE');
END;

CREATE TRIGGER custody_reception_review_immutable_delete
BEFORE DELETE ON custody_reception_review
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RECEPTION_REVIEW_IMMUTABLE');
END;

-- Backfill de devoluciones históricas. No inventa comentario del pañolero: sólo congela
-- lo que ya existía en el registro final y marca el bloqueo según condición histórica.
INSERT OR IGNORE INTO custody_reception_review(
  id,custody_id,handover_id,return_record_id,asset_id,reviewer_user_id,source_mode,
  asset_nature_snapshot,declared_condition_snapshot,declared_problem_reported_snapshot,declared_comment_snapshot,operator_condition,operator_comment,
  effective_condition,comment_forced_observation,blocked_after_receipt,incident_id,
  correlation_id,reviewed_at,created_at
)
SELECT
  'rrv-' || rr.id,
  rr.custody_id,
  rr.handover_id,
  rr.id,
  c.asset_id,
  rr.recorded_by_user_id,
  'LEGACY_BACKFILL',
  ac.nature,
  COALESCE(d.condition, vrd.return_condition, 'CONFORME'),
  CASE WHEN COALESCE(d.problem_reported, vrd.problem_reported, 0) <> 0 THEN 1 ELSE 0 END,
  COALESCE(d.notes, vrd.notes),
  rr.condition,
  NULL,
  rr.condition,
  0,
  CASE WHEN rr.condition <> 'CONFORME' THEN 1 ELSE 0 END,
  rr.incident_id,
  rr.correlation_id,
  rr.received_at,
  rr.created_at
FROM custody_return_record rr
JOIN custody c ON c.id=rr.custody_id
JOIN asset a ON a.id=c.asset_id
JOIN asset_category ac ON ac.id=a.category_id
LEFT JOIN custody_return_declaration d ON d.custody_id=c.id
LEFT JOIN vehicle_return_detail vrd ON vrd.custody_id=c.id;

-- La declaración del técnico es evidencia de la condición informada al devolver.
-- Desde F22 no puede reescribirse ni borrarse después de registrada.
CREATE TRIGGER custody_return_declaration_f22_immutable_update
BEFORE UPDATE ON custody_return_declaration
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RETURN_DECLARATION_IMMUTABLE');
END;

CREATE TRIGGER custody_return_declaration_f22_immutable_delete
BEFORE DELETE ON custody_return_declaration
BEGIN
  SELECT RAISE(ABORT, 'CUSTODY_RETURN_DECLARATION_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS custody_return_declaration_f22_immutable_delete;
DROP TRIGGER IF EXISTS custody_return_declaration_f22_immutable_update;
DROP TRIGGER IF EXISTS custody_reception_review_immutable_delete;
DROP TRIGGER IF EXISTS custody_reception_review_immutable_update;
DROP INDEX IF EXISTS ix_custody_reception_review_reviewer;
DROP INDEX IF EXISTS ix_custody_reception_review_asset;
DROP TABLE IF EXISTS custody_reception_review;
