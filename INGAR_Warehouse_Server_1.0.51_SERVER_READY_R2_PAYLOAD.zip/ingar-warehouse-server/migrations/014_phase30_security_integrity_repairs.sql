-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE management_meeting ADD COLUMN integrity_snapshot_json TEXT;
ALTER TABLE management_meeting_decision ADD COLUMN resolved_at TEXT;
ALTER TABLE management_meeting_decision ADD COLUMN resolved_by_user_id TEXT REFERENCES user_account(id);
ALTER TABLE management_meeting_decision ADD COLUMN resolution_note TEXT;

CREATE INDEX ix_file_evidence_owner ON file_evidence(owner_type, owner_id);

DROP TRIGGER IF EXISTS management_meeting_decision_closed_no_update;
CREATE TRIGGER management_meeting_decision_closed_guard
BEFORE UPDATE ON management_meeting_decision
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA')
AND (
  NEW.meeting_id IS NOT OLD.meeting_id OR
  NEW.decision_text IS NOT OLD.decision_text OR
  NEW.responsible_person_id IS NOT OLD.responsible_person_id OR
  NEW.responsible_role_id IS NOT OLD.responsible_role_id OR
  NEW.responsible_sector IS NOT OLD.responsible_sector OR
  NEW.target_date IS NOT OLD.target_date OR
  NEW.created_by_user_id IS NOT OLD.created_by_user_id OR
  NEW.created_at IS NOT OLD.created_at OR
  (NEW.action_id IS NOT OLD.action_id AND NOT (OLD.action_id IS NULL AND NEW.action_id IS NOT NULL)) OR
  (NEW.status IS NOT OLD.status AND NOT (OLD.status='PENDIENTE' AND NEW.status IN ('EJECUTADA','CANCELADA'))) OR
  (NEW.status='EJECUTADA' AND NEW.status IS NOT OLD.status AND NEW.action_id IS NOT NULL AND NOT EXISTS(
    SELECT 1 FROM management_action a WHERE a.id=NEW.action_id AND a.status='CERRADA'
  ))
)
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_DECISION_CLOSED_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS management_meeting_decision_closed_guard;
CREATE TRIGGER management_meeting_decision_closed_no_update
BEFORE UPDATE ON management_meeting_decision
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA')
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE');
END;
DROP INDEX IF EXISTS ix_file_evidence_owner;
ALTER TABLE management_meeting_decision DROP COLUMN resolution_note;
ALTER TABLE management_meeting_decision DROP COLUMN resolved_by_user_id;
ALTER TABLE management_meeting_decision DROP COLUMN resolved_at;
ALTER TABLE management_meeting DROP COLUMN integrity_snapshot_json;
