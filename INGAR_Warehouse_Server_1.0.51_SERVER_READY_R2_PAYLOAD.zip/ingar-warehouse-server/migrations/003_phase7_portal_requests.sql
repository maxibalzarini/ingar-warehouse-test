-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE portal_qr (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL UNIQUE REFERENCES site(id),
  token TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  replaced_at TEXT
);

CREATE TABLE request_policy (
  id TEXT PRIMARY KEY,
  site_id TEXT REFERENCES site(id),
  category_id TEXT REFERENCES asset_category(id),
  operation_type TEXT NOT NULL CHECK(operation_type IN ('RETIRO','RESERVA')),
  name TEXT NOT NULL,
  requires_approval INTEGER NOT NULL DEFAULT 0 CHECK(requires_approval IN (0,1)),
  max_quantity REAL CHECK(max_quantity IS NULL OR max_quantity > 0),
  max_duration_hours INTEGER CHECK(max_duration_hours IS NULL OR max_duration_hours > 0),
  priority INTEGER NOT NULL DEFAULT 100,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE request (
  id TEXT PRIMARY KEY,
  request_number TEXT NOT NULL UNIQUE,
  requester_person_id TEXT NOT NULL REFERENCES person(id),
  site_id TEXT NOT NULL REFERENCES site(id),
  location_id TEXT NOT NULL REFERENCES storage_location(id),
  operation_type TEXT NOT NULL CHECK(operation_type IN ('RETIRO','RESERVA')),
  status TEXT NOT NULL CHECK(status IN ('BORRADOR','RECIBIDA','VALIDANDO','BLOQUEADA','PENDIENTE_AUTORIZACION','APROBADA','PREPARANDO','LISTA_PARA_ENTREGA','EXPIRADA','CANCELADA','ENTREGADA')),
  needed_at TEXT NOT NULL,
  due_at TEXT,
  reservation_expires_at TEXT,
  reason TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'PORTAL' CHECK(source IN ('PORTAL','ADMIN')),
  approval_required INTEGER NOT NULL DEFAULT 0 CHECK(approval_required IN (0,1)),
  approval_reason TEXT,
  block_code TEXT,
  block_reason TEXT,
  client_request_id TEXT NOT NULL UNIQUE,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  cancelled_at TEXT,
  cancellation_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE request_item (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  quantity REAL NOT NULL DEFAULT 1 CHECK(quantity > 0),
  status TEXT NOT NULL CHECK(status IN ('PENDIENTE','VALIDADO','RESERVADO','RECHAZADO','CANCELADO','ENTREGADO')),
  rejection_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(request_id, asset_id)
);

CREATE TABLE approval (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  approver_user_id TEXT NOT NULL REFERENCES user_account(id),
  decision TEXT NOT NULL CHECK(decision IN ('APROBADA','RECHAZADA')),
  reason TEXT NOT NULL,
  decided_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE asset_reservation (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  request_item_id TEXT NOT NULL UNIQUE REFERENCES request_item(id),
  asset_id TEXT NOT NULL REFERENCES asset(id),
  quantity REAL NOT NULL CHECK(quantity > 0),
  starts_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('ACTIVA','LIBERADA','CONSUMIDA','EXPIRADA')),
  release_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE request_status_event (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL REFERENCES request(id),
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor_user_id TEXT REFERENCES user_account(id),
  reason TEXT,
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX ix_asset_reservation_asset ON asset_reservation(asset_id, status);
CREATE INDEX ix_portal_qr_active ON portal_qr(site_id, active);
CREATE INDEX ix_request_policy_match ON request_policy(operation_type, site_id, category_id, active, priority);
CREATE INDEX ix_request_requester ON request(requester_person_id, created_at DESC);
CREATE INDEX ix_request_status ON request(status, site_id, created_at DESC);
CREATE INDEX ix_request_item_request ON request_item(request_id, status);
CREATE INDEX ix_approval_request ON approval(request_id, decided_at DESC);
CREATE INDEX ix_reservation_expiry ON asset_reservation(status, expires_at);
CREATE INDEX ix_request_event_request ON request_status_event(request_id, occurred_at);

CREATE TRIGGER approval_immutable_update BEFORE UPDATE ON approval BEGIN SELECT RAISE(ABORT, 'APPROVAL_IMMUTABLE'); END;
CREATE TRIGGER approval_immutable_delete BEFORE DELETE ON approval BEGIN SELECT RAISE(ABORT, 'APPROVAL_IMMUTABLE'); END;
CREATE TRIGGER request_event_immutable_update BEFORE UPDATE ON request_status_event BEGIN SELECT RAISE(ABORT, 'REQUEST_EVENT_IMMUTABLE'); END;
CREATE TRIGGER request_event_immutable_delete BEFORE DELETE ON request_status_event BEGIN SELECT RAISE(ABORT, 'REQUEST_EVENT_IMMUTABLE'); END;

-- +down
DROP TRIGGER IF EXISTS request_event_immutable_delete;
DROP TRIGGER IF EXISTS request_event_immutable_update;
DROP TRIGGER IF EXISTS approval_immutable_delete;
DROP TRIGGER IF EXISTS approval_immutable_update;
DROP TABLE IF EXISTS request_status_event;
DROP TABLE IF EXISTS asset_reservation;
DROP TABLE IF EXISTS approval;
DROP TABLE IF EXISTS request_item;
DROP TABLE IF EXISTS request;
DROP TABLE IF EXISTS request_policy;
DROP TABLE IF EXISTS portal_qr;
