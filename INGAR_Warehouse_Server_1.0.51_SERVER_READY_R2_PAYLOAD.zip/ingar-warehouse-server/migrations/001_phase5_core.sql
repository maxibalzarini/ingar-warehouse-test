-- +up
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migration (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL
);

CREATE TABLE organization (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  timezone TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE site (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organization(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(organization_id, code)
);

CREATE TABLE storage_location (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL REFERENCES site(id),
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'PANOL',
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(site_id, code)
);

CREATE TABLE person (
  id TEXT PRIMARY KEY,
  document_type TEXT NOT NULL,
  document_number TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  sector TEXT,
  supervisor_person_id TEXT REFERENCES person(id),
  cost_center TEXT,
  employee_number TEXT,
  observations TEXT,
  photo_evidence_id TEXT,
  signature_evidence_id TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVA' CHECK(status IN ('ACTIVA','INACTIVA','ELIMINADA')),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  UNIQUE(document_type, document_number),
  UNIQUE(employee_number)
);

CREATE TABLE user_account (
  id TEXT PRIMARY KEY,
  person_id TEXT NOT NULL UNIQUE REFERENCES person(id),
  username TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  must_change_password INTEGER NOT NULL DEFAULT 1 CHECK(must_change_password IN (0,1)),
  last_login_at TEXT,
  last_password_change_at TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE role (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL COLLATE NOCASE UNIQUE,
  name TEXT NOT NULL,
  parent_role_id TEXT REFERENCES role(id),
  system_role INTEGER NOT NULL DEFAULT 0 CHECK(system_role IN (0,1)),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE permission (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL COLLATE NOCASE UNIQUE,
  name TEXT NOT NULL,
  module TEXT NOT NULL,
  action TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE role_permission (
  role_id TEXT NOT NULL REFERENCES role(id),
  permission_id TEXT NOT NULL REFERENCES permission(id),
  created_at TEXT NOT NULL,
  PRIMARY KEY(role_id, permission_id)
);

CREATE TABLE user_role_scope (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES user_account(id),
  role_id TEXT NOT NULL REFERENCES role(id),
  site_id TEXT REFERENCES site(id),
  location_id TEXT REFERENCES storage_location(id),
  valid_from TEXT,
  valid_to TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, role_id, site_id, location_id)
);

CREATE TABLE user_permission_override (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES user_account(id),
  permission_id TEXT NOT NULL REFERENCES permission(id),
  effect TEXT NOT NULL CHECK(effect IN ('ALLOW','DENY')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, permission_id)
);

CREATE TABLE user_session (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES user_account(id),
  token_hash TEXT NOT NULL UNIQUE,
  csrf_token_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  remember INTEGER NOT NULL DEFAULT 0 CHECK(remember IN (0,1)),
  ip_address TEXT,
  user_agent TEXT,
  revoked_at TEXT,
  revocation_reason TEXT
);

CREATE TABLE password_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES user_account(id),
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE system_setting (
  id TEXT PRIMARY KEY,
  scope_type TEXT NOT NULL DEFAULT 'SYSTEM',
  scope_id TEXT,
  key TEXT NOT NULL,
  value_json TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_by TEXT REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(scope_type, scope_id, key)
);

CREATE TABLE audit_event (
  id TEXT PRIMARY KEY,
  occurred_at TEXT NOT NULL,
  actor_user_id TEXT REFERENCES user_account(id),
  actor_role TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  before_json TEXT,
  after_json TEXT,
  correlation_id TEXT NOT NULL,
  source TEXT NOT NULL,
  reason TEXT,
  evidence_hash TEXT NOT NULL,
  previous_hash TEXT,
  ip_address TEXT,
  equipment TEXT,
  result TEXT NOT NULL,
  duration_ms INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  created_at TEXT NOT NULL
);

CREATE TRIGGER audit_event_immutable_update
BEFORE UPDATE ON audit_event
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

CREATE TRIGGER audit_event_immutable_delete
BEFORE DELETE ON audit_event
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

CREATE TABLE system_log (
  id TEXT PRIMARY KEY,
  occurred_at TEXT NOT NULL,
  level TEXT NOT NULL CHECK(level IN ('INFO','WARN','ERROR')),
  component TEXT NOT NULL,
  message TEXT NOT NULL,
  details_json TEXT,
  correlation_id TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE file_evidence (
  id TEXT PRIMARY KEY,
  owner_type TEXT NOT NULL,
  owner_id TEXT,
  purpose TEXT,
  file_ref TEXT NOT NULL,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE backup_set (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  created_by TEXT REFERENCES user_account(id),
  schema_version INTEGER NOT NULL,
  manifest_sha256 TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('CREANDO','CREADO','VERIFICADO','FALLIDO','RESTAURADO')),
  verified_at TEXT,
  path_ref TEXT NOT NULL,
  size INTEGER,
  error TEXT,
  updated_at TEXT NOT NULL
);

CREATE INDEX ix_person_status ON person(status);
CREATE INDEX ix_user_active ON user_account(active, deleted_at);
CREATE INDEX ix_session_token ON user_session(token_hash, expires_at);
CREATE INDEX ix_session_user ON user_session(user_id, revoked_at);
CREATE INDEX ix_user_role ON user_role_scope(user_id, valid_from, valid_to);
CREATE INDEX ix_audit_time ON audit_event(occurred_at DESC);
CREATE INDEX ix_audit_actor ON audit_event(actor_user_id, occurred_at DESC);
CREATE INDEX ix_audit_entity ON audit_event(entity_type, entity_id, occurred_at DESC);
CREATE INDEX ix_log_time ON system_log(occurred_at DESC);
CREATE INDEX ix_log_component ON system_log(component, level, occurred_at DESC);
CREATE INDEX ix_backup_time ON backup_set(created_at DESC);

-- +down
DROP TRIGGER IF EXISTS audit_event_immutable_delete;
DROP TRIGGER IF EXISTS audit_event_immutable_update;
DROP TABLE IF EXISTS backup_set;
DROP TABLE IF EXISTS file_evidence;
DROP TABLE IF EXISTS system_log;
DROP TABLE IF EXISTS audit_event;
DROP TABLE IF EXISTS system_setting;
DROP TABLE IF EXISTS password_history;
DROP TABLE IF EXISTS user_session;
DROP TABLE IF EXISTS user_permission_override;
DROP TABLE IF EXISTS user_role_scope;
DROP TABLE IF EXISTS role_permission;
DROP TABLE IF EXISTS permission;
DROP TABLE IF EXISTS role;
DROP TABLE IF EXISTS user_account;
DROP TABLE IF EXISTS person;
DROP TABLE IF EXISTS storage_location;
DROP TABLE IF EXISTS site;
DROP TABLE IF EXISTS organization;
