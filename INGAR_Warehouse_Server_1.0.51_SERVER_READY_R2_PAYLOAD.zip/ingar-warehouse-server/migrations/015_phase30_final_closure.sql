-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE file_evidence ADD COLUMN created_by_user_id TEXT REFERENCES user_account(id);
ALTER TABLE file_evidence ADD COLUMN lifecycle_state TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(lifecycle_state IN ('PENDING','ACTIVE','QUARANTINED'));
ALTER TABLE file_evidence ADD COLUMN original_owner_type TEXT;
ALTER TABLE file_evidence ADD COLUMN original_owner_id TEXT;
ALTER TABLE file_evidence ADD COLUMN claimed_by_user_id TEXT REFERENCES user_account(id);
ALTER TABLE file_evidence ADD COLUMN claimed_at TEXT;
ALTER TABLE file_evidence ADD COLUMN activated_at TEXT;
ALTER TABLE file_evidence ADD COLUMN quarantined_at TEXT;
ALTER TABLE file_evidence ADD COLUMN quarantine_reason TEXT;
ALTER TABLE management_meeting ADD COLUMN integrity_snapshot_version INTEGER NOT NULL DEFAULT 1 CHECK(integrity_snapshot_version IN (1,2));

UPDATE file_evidence
SET original_owner_type = owner_type,
    original_owner_id = owner_id,
    activated_at = COALESCE(activated_at, created_at)
WHERE original_owner_type IS NULL;

CREATE UNIQUE INDEX ux_file_evidence_file_ref ON file_evidence(file_ref);
CREATE INDEX ix_file_evidence_state_creator ON file_evidence(lifecycle_state, created_by_user_id, created_at);

CREATE TABLE file_evidence_reference (
  id TEXT PRIMARY KEY,
  evidence_id TEXT NOT NULL REFERENCES file_evidence(id),
  owner_type TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  purpose TEXT NOT NULL,
  created_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  created_at TEXT NOT NULL,
  UNIQUE(evidence_id, owner_type, owner_id, purpose)
);
CREATE INDEX ix_file_evidence_reference_owner ON file_evidence_reference(owner_type, owner_id);

CREATE TABLE management_meeting_decision_event (
  id TEXT PRIMARY KEY,
  meeting_id TEXT NOT NULL REFERENCES management_meeting(id),
  decision_id TEXT NOT NULL REFERENCES management_meeting_decision(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('ACTION_LINKED','EXECUTED','CANCELLED')),
  from_status TEXT NOT NULL CHECK(from_status IN ('PENDIENTE','EJECUTADA','CANCELADA')),
  to_status TEXT NOT NULL CHECK(to_status IN ('PENDIENTE','EJECUTADA','CANCELADA')),
  action_id TEXT REFERENCES management_action(id),
  resolution_note TEXT,
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  occurred_at TEXT NOT NULL,
  previous_hash TEXT NOT NULL,
  event_hash TEXT NOT NULL UNIQUE
);
CREATE INDEX ix_meeting_decision_event_decision ON management_meeting_decision_event(decision_id, occurred_at);
CREATE INDEX ix_meeting_decision_event_meeting ON management_meeting_decision_event(meeting_id, occurred_at);

CREATE TRIGGER file_evidence_insert_guard
BEFORE INSERT ON file_evidence
WHEN
  (NEW.lifecycle_state='PENDING' AND (NEW.owner_type<>'UNASSIGNED' OR NEW.owner_id IS NOT NULL OR NEW.created_by_user_id IS NULL)) OR
  (NEW.lifecycle_state='ACTIVE' AND (NEW.owner_type='UNASSIGNED' OR NEW.owner_id IS NULL))
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_STATE_OWNER_INVALID');
END;

CREATE TRIGGER file_evidence_pending_claim_guard
BEFORE UPDATE OF owner_type, owner_id, purpose, lifecycle_state, claimed_by_user_id, claimed_at, activated_at ON file_evidence
WHEN OLD.lifecycle_state='PENDING' AND NOT (
  (OLD.owner_type='UNASSIGNED' AND OLD.owner_id IS NULL AND
   NEW.lifecycle_state='ACTIVE' AND NEW.owner_type<>'UNASSIGNED' AND NEW.owner_id IS NOT NULL AND
   NEW.created_by_user_id IS OLD.created_by_user_id AND
   NEW.claimed_by_user_id IS NOT NULL AND NEW.claimed_at IS NOT NULL AND NEW.activated_at IS NOT NULL)
  OR
  (NEW.lifecycle_state='QUARANTINED' AND NEW.owner_type IS OLD.owner_type AND NEW.owner_id IS OLD.owner_id AND
   NEW.quarantined_at IS NOT NULL AND NEW.quarantine_reason IS NOT NULL)
)
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_INVALID_CLAIM');
END;

CREATE TRIGGER file_evidence_active_owner_immutable
BEFORE UPDATE OF owner_type, owner_id, purpose, original_owner_type, original_owner_id ON file_evidence
WHEN OLD.lifecycle_state='ACTIVE' AND (
  NEW.owner_type IS NOT OLD.owner_type OR NEW.owner_id IS NOT OLD.owner_id OR NEW.purpose IS NOT OLD.purpose OR
  NEW.original_owner_type IS NOT OLD.original_owner_type OR NEW.original_owner_id IS NOT OLD.original_owner_id
)
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_OWNER_IMMUTABLE');
END;

CREATE TRIGGER file_evidence_active_no_delete
BEFORE DELETE ON file_evidence
WHEN OLD.lifecycle_state='ACTIVE'
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_ACTIVE_IMMUTABLE');
END;


CREATE TRIGGER file_evidence_content_immutable
BEFORE UPDATE OF file_ref, filename, mime_type, size, sha256, created_at, created_by_user_id ON file_evidence
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_CONTENT_IMMUTABLE');
END;

CREATE TRIGGER file_evidence_active_state_guard
BEFORE UPDATE OF lifecycle_state, quarantined_at, quarantine_reason ON file_evidence
WHEN OLD.lifecycle_state='ACTIVE' AND NOT (
  NEW.lifecycle_state='QUARANTINED' AND NEW.quarantined_at IS NOT NULL AND NEW.quarantine_reason IS NOT NULL
)
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_ACTIVE_STATE_INVALID');
END;

CREATE TRIGGER file_evidence_quarantined_immutable
BEFORE UPDATE ON file_evidence
WHEN OLD.lifecycle_state='QUARANTINED'
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_QUARANTINED_IMMUTABLE');
END;
CREATE TRIGGER file_evidence_quarantined_no_delete
BEFORE DELETE ON file_evidence
WHEN OLD.lifecycle_state='QUARANTINED'
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_QUARANTINED_IMMUTABLE');
END;

CREATE TRIGGER file_evidence_reference_insert_guard
BEFORE INSERT ON file_evidence_reference
WHEN NEW.owner_type='' OR NEW.owner_id='' OR NOT EXISTS(
  SELECT 1 FROM file_evidence e WHERE e.id=NEW.evidence_id AND e.lifecycle_state='ACTIVE'
)
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_REFERENCE_INVALID');
END;

CREATE TRIGGER file_evidence_reference_no_update
BEFORE UPDATE ON file_evidence_reference
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_REFERENCE_IMMUTABLE');
END;
CREATE TRIGGER file_evidence_reference_no_delete
BEFORE DELETE ON file_evidence_reference
BEGIN
  SELECT RAISE(ABORT,'FILE_EVIDENCE_REFERENCE_IMMUTABLE');
END;

DROP TRIGGER IF EXISTS management_meeting_decision_closed_guard;
CREATE TRIGGER management_meeting_decision_closed_immutable
BEFORE UPDATE ON management_meeting_decision
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA')
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_DECISION_CLOSED_IMMUTABLE');
END;

CREATE TRIGGER management_meeting_participant_closed_no_insert
BEFORE INSERT ON management_meeting_participant
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=NEW.meeting_id AND m.status='CERRADA')
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE');
END;
CREATE TRIGGER management_meeting_topic_closed_no_insert
BEFORE INSERT ON management_meeting_topic
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=NEW.meeting_id AND m.status='CERRADA')
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE');
END;
CREATE TRIGGER management_meeting_decision_closed_no_insert
BEFORE INSERT ON management_meeting_decision
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=NEW.meeting_id AND m.status='CERRADA')
BEGIN
  SELECT RAISE(ABORT,'MANAGEMENT_MEETING_CONTENT_IMMUTABLE');
END;

CREATE TRIGGER management_meeting_decision_event_closed_only
BEFORE INSERT ON management_meeting_decision_event
WHEN NOT EXISTS(
  SELECT 1 FROM management_meeting m
  JOIN management_meeting_decision d ON d.meeting_id=m.id
  WHERE m.id=NEW.meeting_id AND d.id=NEW.decision_id AND d.meeting_id=NEW.meeting_id AND m.status='CERRADA'
)
BEGIN
  SELECT RAISE(ABORT,'MEETING_DECISION_EVENT_REQUIRES_CLOSED_MEETING');
END;
CREATE TRIGGER management_meeting_decision_event_no_update
BEFORE UPDATE ON management_meeting_decision_event
BEGIN
  SELECT RAISE(ABORT,'MEETING_DECISION_EVENT_IMMUTABLE');
END;
CREATE TRIGGER management_meeting_decision_event_no_delete
BEFORE DELETE ON management_meeting_decision_event
BEGIN
  SELECT RAISE(ABORT,'MEETING_DECISION_EVENT_IMMUTABLE');
END;

-- +down
DROP TRIGGER IF EXISTS management_meeting_decision_event_no_delete;
DROP TRIGGER IF EXISTS management_meeting_decision_event_no_update;
DROP TRIGGER IF EXISTS management_meeting_decision_event_closed_only;
DROP TRIGGER IF EXISTS management_meeting_decision_closed_no_insert;
DROP TRIGGER IF EXISTS management_meeting_topic_closed_no_insert;
DROP TRIGGER IF EXISTS management_meeting_participant_closed_no_insert;
DROP TRIGGER IF EXISTS management_meeting_decision_closed_immutable;
CREATE TRIGGER management_meeting_decision_closed_guard
BEFORE UPDATE ON management_meeting_decision
WHEN EXISTS(SELECT 1 FROM management_meeting m WHERE m.id=OLD.meeting_id AND m.status='CERRADA')
AND (
  NEW.meeting_id IS NOT OLD.meeting_id OR NEW.decision_text IS NOT OLD.decision_text OR
  NEW.responsible_person_id IS NOT OLD.responsible_person_id OR NEW.responsible_role_id IS NOT OLD.responsible_role_id OR
  NEW.responsible_sector IS NOT OLD.responsible_sector OR NEW.target_date IS NOT OLD.target_date OR
  NEW.created_by_user_id IS NOT OLD.created_by_user_id OR NEW.created_at IS NOT OLD.created_at OR
  (NEW.action_id IS NOT OLD.action_id AND NOT (OLD.action_id IS NULL AND NEW.action_id IS NOT NULL)) OR
  (NEW.status IS NOT OLD.status AND NOT (OLD.status='PENDIENTE' AND NEW.status IN ('EJECUTADA','CANCELADA')))
)
BEGIN SELECT RAISE(ABORT,'MANAGEMENT_MEETING_DECISION_CLOSED_IMMUTABLE'); END;
DROP TRIGGER IF EXISTS file_evidence_reference_no_delete;
DROP TRIGGER IF EXISTS file_evidence_reference_insert_guard;
DROP TRIGGER IF EXISTS file_evidence_quarantined_no_delete;
DROP TRIGGER IF EXISTS file_evidence_quarantined_immutable;
DROP TRIGGER IF EXISTS file_evidence_active_state_guard;
DROP TRIGGER IF EXISTS file_evidence_content_immutable;
DROP TRIGGER IF EXISTS file_evidence_reference_no_update;
DROP TRIGGER IF EXISTS file_evidence_active_no_delete;
DROP TRIGGER IF EXISTS file_evidence_active_owner_immutable;
DROP TRIGGER IF EXISTS file_evidence_pending_claim_guard;
DROP TRIGGER IF EXISTS file_evidence_insert_guard;
DROP INDEX IF EXISTS ix_meeting_decision_event_meeting;
DROP INDEX IF EXISTS ix_meeting_decision_event_decision;
DROP TABLE IF EXISTS management_meeting_decision_event;
DROP INDEX IF EXISTS ix_file_evidence_reference_owner;
DROP TABLE IF EXISTS file_evidence_reference;
DROP INDEX IF EXISTS ix_file_evidence_state_creator;
DROP INDEX IF EXISTS ux_file_evidence_file_ref;
ALTER TABLE management_meeting DROP COLUMN integrity_snapshot_version;
ALTER TABLE file_evidence DROP COLUMN quarantine_reason;
ALTER TABLE file_evidence DROP COLUMN quarantined_at;
ALTER TABLE file_evidence DROP COLUMN activated_at;
ALTER TABLE file_evidence DROP COLUMN claimed_at;
ALTER TABLE file_evidence DROP COLUMN claimed_by_user_id;
ALTER TABLE file_evidence DROP COLUMN original_owner_id;
ALTER TABLE file_evidence DROP COLUMN original_owner_type;
ALTER TABLE file_evidence DROP COLUMN lifecycle_state;
ALTER TABLE file_evidence DROP COLUMN created_by_user_id;
