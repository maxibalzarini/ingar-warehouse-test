-- +up
PRAGMA foreign_keys = ON;

ALTER TABLE kit_definition ADD COLUMN ownership_mode TEXT NOT NULL DEFAULT 'GENERAL' CHECK(ownership_mode IN ('GENERAL','PERSONAL'));

CREATE TABLE kit_person_assignment (
  id TEXT PRIMARY KEY,
  kit_asset_id TEXT NOT NULL REFERENCES asset(id),
  person_id TEXT NOT NULL REFERENCES person(id),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','CLOSED')),
  assigned_at TEXT NOT NULL,
  assigned_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  assignment_notes TEXT,
  ended_at TEXT,
  ended_by_user_id TEXT REFERENCES user_account(id),
  end_reason TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK((status='ACTIVE' AND ended_at IS NULL AND ended_by_user_id IS NULL) OR status='CLOSED')
);

CREATE UNIQUE INDEX ux_kit_person_assignment_active_kit
  ON kit_person_assignment(kit_asset_id) WHERE status='ACTIVE';
CREATE INDEX ix_kit_person_assignment_person
  ON kit_person_assignment(person_id,status,assigned_at DESC);

CREATE TABLE kit_person_assignment_event (
  id TEXT PRIMARY KEY,
  assignment_id TEXT NOT NULL REFERENCES kit_person_assignment(id),
  kit_asset_id TEXT NOT NULL REFERENCES asset(id),
  person_id TEXT NOT NULL REFERENCES person(id),
  event_type TEXT NOT NULL CHECK(event_type IN ('ASSIGNED','CLOSED')),
  actor_user_id TEXT NOT NULL REFERENCES user_account(id),
  reason TEXT,
  occurred_at TEXT NOT NULL,
  correlation_id TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX ix_kit_person_assignment_event_kit ON kit_person_assignment_event(kit_asset_id,occurred_at DESC);
CREATE INDEX ix_kit_person_assignment_event_person ON kit_person_assignment_event(person_id,occurred_at DESC);

CREATE TABLE kit_inventory_control (
  id TEXT PRIMARY KEY,
  control_number TEXT NOT NULL UNIQUE,
  kit_asset_id TEXT NOT NULL REFERENCES asset(id),
  assignment_id TEXT REFERENCES kit_person_assignment(id),
  person_id TEXT REFERENCES person(id),
  kit_code_snapshot TEXT NOT NULL,
  kit_description_snapshot TEXT NOT NULL,
  kit_serial_snapshot TEXT,
  person_name_snapshot TEXT,
  employee_number_snapshot TEXT,
  sector_snapshot TEXT,
  component_count INTEGER NOT NULL DEFAULT 0 CHECK(component_count >= 0),
  definition_version INTEGER NOT NULL,
  generated_by_user_id TEXT NOT NULL REFERENCES user_account(id),
  generated_at TEXT NOT NULL,
  notes TEXT,
  correlation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX ix_kit_inventory_control_kit ON kit_inventory_control(kit_asset_id,generated_at DESC);
CREATE INDEX ix_kit_inventory_control_person ON kit_inventory_control(person_id,generated_at DESC);

CREATE TABLE kit_inventory_control_item (
  id TEXT PRIMARY KEY,
  control_id TEXT NOT NULL REFERENCES kit_inventory_control(id),
  component_asset_id TEXT NOT NULL REFERENCES asset(id),
  component_code_snapshot TEXT NOT NULL,
  component_description_snapshot TEXT NOT NULL,
  component_serial_snapshot TEXT,
  component_category_snapshot TEXT,
  expected_quantity REAL NOT NULL CHECK(expected_quantity > 0),
  mandatory INTEGER NOT NULL CHECK(mandatory IN (0,1)),
  sequence INTEGER NOT NULL CHECK(sequence > 0),
  asset_status_snapshot TEXT NOT NULL,
  asset_location_snapshot TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(control_id, component_asset_id)
);
CREATE INDEX ix_kit_inventory_control_item_control ON kit_inventory_control_item(control_id,sequence);

CREATE TRIGGER kit_person_assignment_insert_guard
BEFORE INSERT ON kit_person_assignment
BEGIN
  SELECT CASE WHEN COALESCE((
    SELECT c.nature FROM asset a JOIN asset_category c ON c.id=a.category_id
    WHERE a.id=NEW.kit_asset_id AND a.deleted_at IS NULL AND a.active=1
  ),'') <> 'KIT' THEN RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_KIT_INVALID') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM person p JOIN user_account ua ON ua.person_id=p.id
    WHERE p.id=NEW.person_id AND p.status='ACTIVA' AND p.deleted_at IS NULL
      AND ua.active=1 AND ua.deleted_at IS NULL
  ) THEN RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_PERSON_INVALID') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM user_account ua
    JOIN user_role_scope urs ON urs.user_id=ua.id
    JOIN role r ON r.id=urs.role_id AND r.active=1
    WHERE ua.person_id=NEW.person_id AND ua.active=1 AND ua.deleted_at IS NULL
      AND r.code='SOLICITANTE'
      AND (urs.valid_from IS NULL OR julianday(urs.valid_from)<=julianday('now'))
      AND (urs.valid_to IS NULL OR julianday(urs.valid_to)>=julianday('now'))
  ) THEN RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_TECHNICAL_ROLE_REQUIRED') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM kit_component kc
    JOIN asset ca ON ca.id=kc.component_asset_id
    JOIN asset_category cc ON cc.id=ca.category_id
    WHERE kc.kit_asset_id=NEW.kit_asset_id AND kc.active=1 AND cc.nature='KIT'
  ) THEN RAISE(ABORT,'KIT_PERSONAL_NESTED_FORBIDDEN') END;
END;

CREATE TRIGGER kit_person_assignment_identity_guard
BEFORE UPDATE OF kit_asset_id,person_id,assigned_at,assigned_by_user_id ON kit_person_assignment
BEGIN
  SELECT RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_IDENTITY_IMMUTABLE');
END;

CREATE TRIGGER kit_person_assignment_component_exclusive_guard
BEFORE INSERT ON kit_person_assignment
WHEN NEW.status='ACTIVE'
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1
    FROM kit_component mine
    JOIN kit_component other ON other.component_asset_id=mine.component_asset_id AND other.active=1
    JOIN kit_person_assignment opa ON opa.kit_asset_id=other.kit_asset_id AND opa.status='ACTIVE'
    WHERE mine.kit_asset_id=NEW.kit_asset_id AND mine.active=1 AND other.kit_asset_id<>NEW.kit_asset_id
  ) THEN RAISE(ABORT,'KIT_PERSONAL_COMPONENT_ALREADY_ASSIGNED') END;
END;

CREATE TRIGGER kit_component_personal_exclusive_insert_guard
BEFORE INSERT ON kit_component
WHEN NEW.active=1 AND EXISTS (SELECT 1 FROM kit_person_assignment WHERE kit_asset_id=NEW.kit_asset_id AND status='ACTIVE')
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM kit_component other
    JOIN kit_person_assignment opa ON opa.kit_asset_id=other.kit_asset_id AND opa.status='ACTIVE'
    WHERE other.component_asset_id=NEW.component_asset_id AND other.active=1 AND other.kit_asset_id<>NEW.kit_asset_id
  ) THEN RAISE(ABORT,'KIT_PERSONAL_COMPONENT_ALREADY_ASSIGNED') END;
END;

CREATE TRIGGER kit_component_personal_exclusive_update_guard
BEFORE UPDATE OF component_asset_id,active ON kit_component
WHEN NEW.active=1 AND EXISTS (SELECT 1 FROM kit_person_assignment WHERE kit_asset_id=NEW.kit_asset_id AND status='ACTIVE')
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM kit_component other
    JOIN kit_person_assignment opa ON opa.kit_asset_id=other.kit_asset_id AND opa.status='ACTIVE'
    WHERE other.component_asset_id=NEW.component_asset_id AND other.active=1 AND other.kit_asset_id<>NEW.kit_asset_id AND other.id<>OLD.id
  ) THEN RAISE(ABORT,'KIT_PERSONAL_COMPONENT_ALREADY_ASSIGNED') END;
END;

CREATE TRIGGER kit_person_assignment_event_update_guard
BEFORE UPDATE ON kit_person_assignment_event BEGIN SELECT RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_EVENT_IMMUTABLE'); END;
CREATE TRIGGER kit_person_assignment_event_delete_guard
BEFORE DELETE ON kit_person_assignment_event BEGIN SELECT RAISE(ABORT,'KIT_PERSON_ASSIGNMENT_EVENT_IMMUTABLE'); END;

CREATE TRIGGER kit_inventory_control_update_guard
BEFORE UPDATE ON kit_inventory_control BEGIN SELECT RAISE(ABORT,'KIT_INVENTORY_CONTROL_IMMUTABLE'); END;
CREATE TRIGGER kit_inventory_control_delete_guard
BEFORE DELETE ON kit_inventory_control BEGIN SELECT RAISE(ABORT,'KIT_INVENTORY_CONTROL_IMMUTABLE'); END;
CREATE TRIGGER kit_inventory_control_item_update_guard
BEFORE UPDATE ON kit_inventory_control_item BEGIN SELECT RAISE(ABORT,'KIT_INVENTORY_CONTROL_ITEM_IMMUTABLE'); END;
CREATE TRIGGER kit_inventory_control_item_delete_guard
BEFORE DELETE ON kit_inventory_control_item BEGIN SELECT RAISE(ABORT,'KIT_INVENTORY_CONTROL_ITEM_IMMUTABLE'); END;

-- Un kit personal disponible debe tener una asignación activa.
CREATE TRIGGER kit_personal_available_insert_guard
AFTER INSERT ON kit_person_assignment
WHEN NEW.status='ACTIVE'
BEGIN
  UPDATE kit_definition SET ownership_mode='PERSONAL',version=version+1,updated_at=NEW.updated_at
  WHERE kit_asset_id=NEW.kit_asset_id AND ownership_mode<>'PERSONAL';
END;

-- +down
DROP TRIGGER IF EXISTS kit_personal_available_insert_guard;
DROP TRIGGER IF EXISTS kit_inventory_control_item_delete_guard;
DROP TRIGGER IF EXISTS kit_inventory_control_item_update_guard;
DROP TRIGGER IF EXISTS kit_inventory_control_delete_guard;
DROP TRIGGER IF EXISTS kit_inventory_control_update_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_event_delete_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_event_update_guard;
DROP TRIGGER IF EXISTS kit_component_personal_exclusive_update_guard;
DROP TRIGGER IF EXISTS kit_component_personal_exclusive_insert_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_component_exclusive_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_identity_guard;
DROP TRIGGER IF EXISTS kit_person_assignment_insert_guard;
DROP TABLE IF EXISTS kit_inventory_control_item;
DROP TABLE IF EXISTS kit_inventory_control;
DROP TABLE IF EXISTS kit_person_assignment_event;
DROP TABLE IF EXISTS kit_person_assignment;
-- SQLite no elimina columnas con DROP COLUMN en todas las versiones soportadas; ownership_mode se conserva si se revierte manualmente.
