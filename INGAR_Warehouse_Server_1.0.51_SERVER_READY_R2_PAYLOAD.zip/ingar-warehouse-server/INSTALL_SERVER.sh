#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${IWC_DATA_DIR:-$HOME/.ingar-warehouse-data}"
ENV_FILE="$HOME/.ingar-warehouse-server.env"
if [[ "$(node -p 'process.versions.node.split(".")[0]')" != "22" ]]; then
  echo "ERROR: se requiere Node.js 22. Actual: $(node -v)" >&2
  exit 2
fi
mkdir -p "$DATA_DIR"
chmod 700 "$DATA_DIR"
if [[ ! -f "$ENV_FILE" ]]; then
  SECRET="$(node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))")"
  cat > "$ENV_FILE" <<ENV
export IWC_SERVER_MODE=1
export IWC_HOST=0.0.0.0
export IWC_PORT=4317
export IWC_DATA_DIR='$DATA_DIR'
export IWC_MASTER_WRAP_SECRET='$SECRET'
ENV
  chmod 600 "$ENV_FILE"
fi
bash "$ROOT/scripts/install-linux-native.sh"
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a
node "$ROOT/scripts/server-self-test.js"
echo
printf 'INSTALL SERVER PASS\nDatos: %s\nRuntime env: %s\n' "$DATA_DIR" "$ENV_FILE"
echo "Ahora ejecutá: ./START_INGAR.sh"
