# INGAR Warehouse Controller Server 1.0.51

Server Edition para Linux / GitHub Codespaces.

## Arranque
```bash
npm install
npm run prepare:sqlite
npm start
```

Puerto: `4317`.
Datos persistentes del Codespace: `./data/`.
Schema máximo: `053`. No existe migración `054`.
