'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { getAccessContract } = require('../services/access-contract-service');

function csvCell(value) {
  const text = String(value ?? '');
  return /[;\n\r\"]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function endpointGuards() {
  const routesDir = path.resolve(__dirname, '..', 'http', 'routes');
  const entries = [];
  for (const filename of fs.readdirSync(routesDir).filter((name) => name.endsWith('.js')).sort()) {
    const lines = fs.readFileSync(path.join(routesDir, filename), 'utf8').split(/\r?\n/);
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const guards = [];
      const all = [...line.matchAll(/requireAuth\(req,\s*'([^']+)'\)/g)];
      for (const match of all) guards.push({ mode: 'ALL', permissions: [match[1]] });
      const any = line.match(/requireAnyPermission\(req,\s*\[([^\]]+)\]\)/);
      if (any) guards.push({ mode: 'ANY', permissions: [...any[1].matchAll(/'([^']+)'/g)].map((match) => match[1]) });
      if (!guards.length) continue;

      let method = null;
      let routePath = null;
      const start = Math.max(0, index - 35);
      for (let cursor = index; cursor >= start && (!method || !routePath); cursor -= 1) {
        const source = lines[cursor];
        if (!method) method = source.match(/req\.method\s*===\s*'([A-Z]+)'/)?.[1] || null;
        if (!routePath) {
          routePath = source.match(/pathname\s*===\s*'([^']+)'/)?.[1]
            || source.match(/match\(pathname,\s*'([^']+)'\)/)?.[1]
            || null;
        }
      }
      for (const guard of guards) {
        entries.push({
          method,
          path: routePath,
          guardMode: guard.mode,
          permissions: guard.permissions,
          sourceFile: `src/http/routes/${filename}`,
          sourceLine: index + 1
        });
      }
    }
  }
  return entries;
}

function authorizedRoles(entry, contract) {
  return contract.roles.filter((role) => {
    const permissions = new Set(role.defaultPermissions);
    if (permissions.has('*')) return true;
    if (entry.guardMode === 'ANY') return entry.permissions.some((permission) => permissions.has(permission));
    return entry.permissions.every((permission) => permissions.has(permission));
  }).map((role) => role.code);
}

function build() {
  const contract = getAccessContract();
  const endpoints = endpointGuards().map((entry) => ({
    ...entry,
    authorizedDefaultRoles: authorizedRoles(entry, contract),
    note: 'Guard mínimo de ruta. Scope, segregación de funciones, ownership y estado de negocio pueden restringir adicionalmente en servicios/DB.'
  }));
  return {
    schema: 'IWC_ENDPOINT_ACCESS_MATRIX_V1',
    generatedAt: new Date().toISOString(),
    accessContract: contract,
    endpointCount: endpoints.length,
    endpoints
  };
}

function main() {
  const outputDir = path.resolve(process.argv[2] || process.cwd());
  fs.mkdirSync(outputDir, { recursive: true });
  const result = build();
  const jsonPath = path.join(outputDir, 'ENDPOINT_ACCESS_MATRIX.json');
  const csvPath = path.join(outputDir, 'ENDPOINT_ACCESS_MATRIX.csv');
  fs.writeFileSync(jsonPath, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  const headers = ['method','path','guardMode','permissions','authorizedDefaultRoles','sourceFile','sourceLine','note'];
  const rows = [headers.join(';')];
  for (const endpoint of result.endpoints) {
    rows.push([
      endpoint.method,
      endpoint.path,
      endpoint.guardMode,
      endpoint.permissions.join(','),
      endpoint.authorizedDefaultRoles.join(','),
      endpoint.sourceFile,
      endpoint.sourceLine,
      endpoint.note
    ].map(csvCell).join(';'));
  }
  fs.writeFileSync(csvPath, `${rows.join('\r\n')}\r\n`, 'utf8');
  process.stdout.write(`${JSON.stringify({ jsonPath, csvPath, endpointCount: result.endpointCount })}\n`);
}

if (require.main === module) main();
module.exports = { endpointGuards, authorizedRoles, build };
