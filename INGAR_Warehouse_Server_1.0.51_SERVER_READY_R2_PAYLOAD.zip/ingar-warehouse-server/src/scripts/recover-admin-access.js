'use strict';

const path = require('node:path');
const os = require('node:os');
const readline = require('node:readline/promises');
const { stdin, stdout } = require('node:process');

const { safeErrorText, writeStderr } = require('../security/secure-console');
if (!process.env.IWC_DATA_DIR) {
  const base = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  process.env.IWC_DATA_DIR = path.join(base, 'INGAR Warehouse Controller', 'data');
}

const { recoverAdministratorAccess, listRecoverableAdministrators } = require('../services/bootstrap-access-service');
const { openDatabase, closeDatabase } = require('../db/database');
const { seedBase } = require('../services/seed-service');

async function main() {
  const userDataRoot = path.dirname(process.env.IWC_DATA_DIR);
  const rl = readline.createInterface({ input: stdin, output: stdout });
  try {
    openDatabase();
    seedBase();
    let admins;
    try { admins = listRecoverableAdministrators(); } finally { closeDatabase(); }
    if (!admins.length) throw Object.assign(new Error('No hay una cuenta ADMIN_GENERAL recuperable.'), { code: 'RECOVERY_ACCOUNT_NOT_FOUND' });
    stdout.write('Cuentas administrativas encontradas:\n');
    admins.forEach((item, index) => stdout.write(`  ${index + 1}. ${item.fullName} | ${item.username}${item.active ? '' : ' | INACTIVA'}\n`));
    const answer = (await rl.question(`Seleccione una cuenta [1-${admins.length}]: `)).trim();
    const selectedIndex = Number(answer || (admins.length === 1 ? '1' : '0')) - 1;
    if (!Number.isInteger(selectedIndex) || selectedIndex < 0 || selectedIndex >= admins.length) throw Object.assign(new Error('Selección inválida.'), { code: 'RECOVERY_SELECTION_INVALID' });
    const username = admins[selectedIndex].username.toLowerCase();
    stdout.write('\nEsta operación cambiará la contraseña, reactivará expresamente la cuenta y revocará sus sesiones activas.\n');
    const expected = `RECUPERAR:${username}`;
    const confirmation = (await rl.question(`Escriba exactamente ${expected}: `)).trim();
    const result = await recoverAdministratorAccess(userDataRoot, { username, confirmation });
    stdout.write(`\nRECUPERACIÓN COMPLETADA\nUsuario anterior: ${result.username}\n`);
    stdout.write('Abra Warehouse y configure directamente Usuario, Contraseña y Repetir contraseña.\n');
  } finally {
    rl.close();
  }
}

main().catch((error) => {
  writeStderr(`ERROR [${error.code || 'RECOVERY_ERROR'}]: ${safeErrorText(error)}\n`);
  process.exitCode = 1;
});
