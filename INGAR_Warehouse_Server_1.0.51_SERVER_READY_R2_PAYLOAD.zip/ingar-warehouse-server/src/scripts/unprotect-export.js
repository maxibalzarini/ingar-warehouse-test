'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { unprotectExport } = require('../services/protected-export-service');
const { safeErrorText, writeStdout, writeStderr } = require('../security/secure-console');

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : null;
}

const input = argument('--input') || process.argv[2];
const outputDirectory = argument('--output-directory');

if (!input) {
  writeStderr('Uso: unprotect-export --input <archivo.iwcexport> [--output-directory <directorio>]\n');
  process.exitCode = 2;
} else {
  try {
    const inputPath = path.resolve(input);
    const result = unprotectExport(fs.readFileSync(inputPath));
    const directory = path.resolve(outputDirectory || path.dirname(inputPath));
    fs.mkdirSync(directory, { recursive: true });
    const outputPath = path.join(directory, result.filename);
    fs.writeFileSync(outputPath, result.bytes, { flag: 'wx', mode: 0o600 });
    writeStdout(`ARCHIVO RECUPERADO: ${outputPath}\n`);
  } catch (error) {
    writeStderr(`ERROR: ${safeErrorText(error)}\n`);
    process.exitCode = 1;
  }
}
