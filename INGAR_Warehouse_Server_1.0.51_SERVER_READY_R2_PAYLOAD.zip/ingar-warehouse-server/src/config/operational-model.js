'use strict';

const SERIALIZED_NATURES = Object.freeze(new Set(['SERIADO', 'KIT', 'VEHICULO']));
const REQUESTER_RETURN_NATURES = Object.freeze(new Set(['CANTIDAD', 'SERIADO', 'KIT', 'VEHICULO']));
const SIMPLE_CREDENTIAL_ROLE_CODES = Object.freeze(new Set(['SOLICITANTE', 'PANOLERO']));
const SELF_APPROVAL_ROLE_CODES = Object.freeze(new Set(['PANOLERO', 'SUPERVISOR', 'ADMINISTRADOR', 'ADMIN_GENERAL']));
const REQUESTER_INTERFACE_ROLE_CODES = Object.freeze(new Set(['SOLICITANTE', ...SELF_APPROVAL_ROLE_CODES]));
const TECHNICAL_USER_ROLE_CODES = Object.freeze(new Set(['SOLICITANTE']));

const OPERATIONAL_RESPONSIBILITY = Object.freeze({
  REQUEST_CREATE: 'REQUESTER',
  REQUEST_RETURN_SERIALIZED: 'CURRENT_CUSTODIAN',
  HANDOVER_CONFIRM: 'WAREHOUSE_OPERATOR',
  RECEIVE_CONFIRM: 'WAREHOUSE_OPERATOR',
  STOCK_MUTATION: 'WAREHOUSE_OPERATOR',
  MASTER_DATA: 'ADMIN_OR_SUPERVISOR'
});

function requiresRequesterReturnInitiation(categoryNature) {
  return REQUESTER_RETURN_NATURES.has(String(categoryNature || '').toUpperCase());
}

function canWarehouseReceiveFromStatus(categoryNature, custodyStatus) {
  const status = String(custodyStatus || '').toUpperCase();
  if (requiresRequesterReturnInitiation(categoryNature)) return status === 'DEVOLUCION_DECLARADA';
  return status === 'ABIERTA' || status === 'DEVOLUCION_DECLARADA';
}

function usesSimpleOperationalCredential(roleCodes) {
  const normalized = [...new Set((roleCodes || []).map((code) => String(code || '').toUpperCase()).filter(Boolean))];
  return normalized.length > 0 && normalized.every((code) => SIMPLE_CREDENTIAL_ROLE_CODES.has(code));
}

function canUseRequesterTablet(roleCodes) {
  const normalized = (roleCodes || []).map((code) => String(code || '').toUpperCase());
  return normalized.some((code) => REQUESTER_INTERFACE_ROLE_CODES.has(code));
}

function isTechnicalUser(roleCodes) {
  const normalized = (roleCodes || []).map((code) => String(code || '').toUpperCase());
  return normalized.some((code) => TECHNICAL_USER_ROLE_CODES.has(code));
}

function canSelfApproveOwnRequest(roleCodes) {
  const normalized = (roleCodes || []).map((code) => String(code || '').toUpperCase());
  return normalized.some((code) => SELF_APPROVAL_ROLE_CODES.has(code));
}

module.exports = {
  SERIALIZED_NATURES,
  REQUESTER_RETURN_NATURES,
  SIMPLE_CREDENTIAL_ROLE_CODES,
  SELF_APPROVAL_ROLE_CODES,
  REQUESTER_INTERFACE_ROLE_CODES,
  TECHNICAL_USER_ROLE_CODES,
  OPERATIONAL_RESPONSIBILITY,
  requiresRequesterReturnInitiation,
  canWarehouseReceiveFromStatus,
  usesSimpleOperationalCredential,
  canUseRequesterTablet,
  isTechnicalUser,
  canSelfApproveOwnRequest
};
