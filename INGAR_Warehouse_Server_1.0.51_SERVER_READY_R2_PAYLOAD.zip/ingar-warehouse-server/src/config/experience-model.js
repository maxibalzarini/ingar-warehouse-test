'use strict';

// C0/C1: la experiencia primaria se decide en backend a partir de los roles efectivos.
// La UI puede presentar esa experiencia, pero no decide autoridad ni eleva permisos.
const EXPERIENCE_CODES = Object.freeze({
  TECHNICIAN: 'TECHNICIAN',
  WAREHOUSE_OPERATOR: 'WAREHOUSE_OPERATOR',
  CONTROL_CENTER: 'CONTROL_CENTER',
  LIMITED: 'LIMITED'
});

const EXPERIENCE_DEFINITIONS = Object.freeze({
  [EXPERIENCE_CODES.TECHNICIAN]: Object.freeze({
    code: EXPERIENCE_CODES.TECHNICIAN,
    label: 'Mi operación',
    targetRoute: '/mi-operacion',
    visualTarget: 'TECHNICIAN_IMAGE',
    purpose: 'Pedir herramientas o vehículos, devolver y consultar la operación propia.'
  }),
  [EXPERIENCE_CODES.WAREHOUSE_OPERATOR]: Object.freeze({
    code: EXPERIENCE_CODES.WAREHOUSE_OPERATOR,
    label: 'Puesto del pañolero',
    targetRoute: '/panol/workbench',
    visualTarget: 'WAREHOUSE_IMAGE',
    purpose: 'Preparar, entregar, recibir y resolver problemas operativos del pañol.'
  }),
  [EXPERIENCE_CODES.CONTROL_CENTER]: Object.freeze({
    code: EXPERIENCE_CODES.CONTROL_CENTER,
    label: 'Control Center',
    targetRoute: '/control',
    visualTarget: 'CONTROL_CENTER_IMAGE',
    purpose: 'Supervisar la operación, riesgos, disponibilidad, mantenimiento, incidentes y gestión.'
  }),
  [EXPERIENCE_CODES.LIMITED]: Object.freeze({
    code: EXPERIENCE_CODES.LIMITED,
    label: 'Acceso limitado',
    targetRoute: '/acceso-limitado',
    visualTarget: 'LIMITED',
    purpose: 'Acceso autenticado sin experiencia operativa asignada.'
  })
});

// Precedencia deliberada para usuarios con más de un rol. La experiencia no reemplaza RBAC.
const ROLE_PRIORITY = Object.freeze([
  'ADMIN_GENERAL',
  'ADMINISTRADOR',
  'SUPERVISOR',
  'AUDITOR',
  'CONSULTA',
  'PANOLERO',
  'SOLICITANTE',
  'INVITADO'
]);

const ROLE_EXPERIENCE = Object.freeze({
  ADMIN_GENERAL: EXPERIENCE_CODES.CONTROL_CENTER,
  ADMINISTRADOR: EXPERIENCE_CODES.CONTROL_CENTER,
  SUPERVISOR: EXPERIENCE_CODES.CONTROL_CENTER,
  AUDITOR: EXPERIENCE_CODES.CONTROL_CENTER,
  CONSULTA: EXPERIENCE_CODES.CONTROL_CENTER,
  PANOLERO: EXPERIENCE_CODES.WAREHOUSE_OPERATOR,
  SOLICITANTE: EXPERIENCE_CODES.TECHNICIAN,
  INVITADO: EXPERIENCE_CODES.LIMITED
});

const ROLE_SCREEN_ENTITLEMENTS = Object.freeze({
  ADMIN_GENERAL: Object.freeze(['/control', '/gestion/config', '/panol/workbench', '/mi-operacion']),
  ADMINISTRADOR: Object.freeze(['/control', '/gestion/config', '/panol/workbench', '/mi-operacion']),
  SUPERVISOR: Object.freeze(['/control', '/panol/workbench', '/mi-operacion']),
  AUDITOR: Object.freeze(['/control']),
  CONSULTA: Object.freeze(['/control']),
  PANOLERO: Object.freeze(['/panol/workbench', '/mi-operacion']),
  SOLICITANTE: Object.freeze(['/mi-operacion']),
  INVITADO: Object.freeze(['/acceso-limitado'])
});

module.exports = {
  EXPERIENCE_CODES,
  EXPERIENCE_DEFINITIONS,
  ROLE_PRIORITY,
  ROLE_EXPERIENCE,
  ROLE_SCREEN_ENTITLEMENTS
};
