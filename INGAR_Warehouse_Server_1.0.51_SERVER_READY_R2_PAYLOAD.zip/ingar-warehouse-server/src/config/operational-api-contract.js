'use strict';

// C2: autorización backend explícita para la experiencia "Mi operación".
// Estas reglas no reemplazan ownership/scope de los servicios; son el guard mínimo
// exigido antes de ejecutar la operación de negocio.
const OPERATIONAL_API_PERMISSIONS = Object.freeze({
  BOOTSTRAP_READ: Object.freeze(['Auth.Self']),
  AVAILABILITY_READ: Object.freeze(['Requests.Availability']),
  ASSET_PHOTO_READ: Object.freeze(['Requests.Availability']),
  REQUESTS_READ_OWN: Object.freeze(['Requests.ReadOwn']),
  CUSTODIES_READ_OWN: Object.freeze(['Custody.ReadOwn']),
  KITS_READ: Object.freeze(['Kits.Read']),
  REQUEST_CREATE: Object.freeze(['Requests.Create']),
  REQUEST_PHOTO_WRITE: Object.freeze(['Requests.UpdateOwn']),
  RETURN_RECEIPT_READ: Object.freeze(['Custody.ReadOwn']),
  RETURN_DECLARE: Object.freeze(['Custody.ReturnOwn']),
  RETURN_PHOTO_WRITE: Object.freeze(['Custody.ReturnOwn']),
  VEHICLE_REQUEST_CREATE: Object.freeze(['Requests.Create', 'Vehicles.Read']),
  VEHICLE_REQUEST_PHOTO_WRITE: Object.freeze(['Requests.UpdateOwn']),
  VEHICLE_RETURN_DECLARE: Object.freeze(['Custody.ReturnOwn']),
  VEHICLE_RETURN_PHOTO_WRITE: Object.freeze(['Custody.ReturnOwn'])
});

const OPERATIONAL_API_MATRIX = Object.freeze([
  Object.freeze({ method:'GET', route:'/api/v1/operation/bootstrap', action:'BOOTSTRAP_READ' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/availability', action:'AVAILABILITY_READ' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/assets/:id/photo', action:'ASSET_PHOTO_READ' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/requests', action:'REQUESTS_READ_OWN' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/custodies', action:'CUSTODIES_READ_OWN' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/kits', action:'KITS_READ' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/requests', action:'REQUEST_CREATE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/requests/:id/photo', action:'REQUEST_PHOTO_WRITE' }),
  Object.freeze({ method:'GET', route:'/api/v1/operation/custodies/:id/return-receipt', action:'RETURN_RECEIPT_READ' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/custodies/:id/declare-return', action:'RETURN_DECLARE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/custodies/:id/return-photo', action:'RETURN_PHOTO_WRITE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/vehicle-requests', action:'VEHICLE_REQUEST_CREATE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/vehicle-requests/:id/photo', action:'VEHICLE_REQUEST_PHOTO_WRITE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/vehicle-custodies/:id/declare-return', action:'VEHICLE_RETURN_DECLARE' }),
  Object.freeze({ method:'POST', route:'/api/v1/operation/vehicle-custodies/:id/return-photo', action:'VEHICLE_RETURN_PHOTO_WRITE' })
]);

function permissionsFor(action) {
  const permissions = OPERATIONAL_API_PERMISSIONS[action];
  if (!permissions) throw new Error(`C2 operational permission action desconocida: ${action}`);
  return permissions;
}

module.exports = { OPERATIONAL_API_PERMISSIONS, OPERATIONAL_API_MATRIX, permissionsFor };
