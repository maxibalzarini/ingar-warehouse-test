'use strict';

const path = require('node:path');
const packageMetadata = require('../../package.json');

const projectRoot = path.resolve(__dirname, '..', '..');
const dataDir = path.resolve(process.env.IWC_DATA_DIR || path.join(projectRoot, 'data'));
const securityDir = path.join(dataDir, 'security');
const serverMode = String(process.env.IWC_SERVER_MODE || '').trim() === '1';

module.exports = Object.freeze({
  projectRoot,
  dataDir,
  dbPath: path.resolve(process.env.IWC_DB_PATH || path.join(dataDir, 'iwc.sqlite')),
  securityDir,
  masterKeyPath: path.resolve(process.env.IWC_MASTER_KEY_PATH || path.join(securityDir, process.platform === 'win32' ? 'master-key.dpapi.json' : 'master-key.wrapped.json')),
  evidenceDir: path.join(dataDir, 'evidence'),
  backupDir: path.join(dataDir, 'backups'),
  auditArchiveDir: path.join(dataDir, 'audit-archive'),
  logDir: path.join(dataDir, 'logs'),
  publicDir: path.join(projectRoot, 'public'),
  migrationsDir: path.join(projectRoot, 'migrations'),
  serverMode,
  host: process.env.IWC_LOCAL_HOST || process.env.IWC_HOST || (serverMode ? '0.0.0.0' : '127.0.0.1'),
  localHost: process.env.IWC_LOCAL_HOST || process.env.IWC_HOST || (serverMode ? '0.0.0.0' : '127.0.0.1'),
  lanHost: process.env.IWC_LAN_HOST || '0.0.0.0',
  browserHost: process.env.IWC_BROWSER_HOST || '127.0.0.1',
  port: Number.parseInt(process.env.IWC_PORT || '4317', 10),
  mobileAccessPort: Number.parseInt(process.env.IWC_MOBILE_ACCESS_PORT || process.env.IWC_PORTAL_PORT || '4318', 10),
  discoveryPort: Number.parseInt(process.env.IWC_DISCOVERY_PORT || '4319', 10),
  mdnsPort: Number.parseInt(process.env.IWC_MDNS_PORT || '5353', 10),
  mdnsHostName: String(process.env.IWC_MDNS_HOSTNAME || 'ingar-warehouse.local').trim().toLowerCase(),
  cookieName: 'iwc_session',
  maxBodyBytes: 8_388_608,
  maxImageBytes: 2_097_152,
  maxDocumentBytes: 5_242_880,
  maxImportBytes: 5_242_880,
  maxPortableBackupBytes: 768 * 1024 * 1024,
  normalSessionSeconds: 8 * 60 * 60,
  rememberSessionSeconds: 30 * 24 * 60 * 60,
  passwordMinLength: 4,
  passwordMaxLength: 8,
  operationalCredentialMinLength: 4,
  operationalCredentialMaxLength: 8,
  loginWindowMs: 15 * 60 * 1000,
  loginIpLimit: 30,
  sourceVersion: packageMetadata.version
});
