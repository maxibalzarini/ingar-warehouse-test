'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { migrate } = require('./migrator');
const { ensureEncryptedDatabase, openCipherDatabase } = require('../security/sqlite-encryption');

let database = null;

function ensureDirectories() {
  for (const dir of [runtime.dataDir, runtime.securityDir, runtime.evidenceDir, runtime.backupDir, runtime.auditArchiveDir, runtime.logDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function openDatabase() {
  ensureDirectories();
  if (database) return database;
  ensureEncryptedDatabase(runtime.dbPath, { recoveryDirectory: runtime.backupDir });
  database = openCipherDatabase(runtime.dbPath, { fileMustExist: true });
  database.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL; PRAGMA busy_timeout = 5000;');
  migrate(database, runtime.migrationsDir, {
    dbPath: runtime.dbPath,
    backupDir: runtime.backupDir,
    processName: 'APP_STARTUP',
    sourceVersion: runtime.sourceVersion
  });
  const now = new Date().toISOString();
  database.prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE revoked_at IS NULL AND expires_at <= ?')
    .run(now, 'EXPIRED', now);
  database.prepare(`INSERT INTO system_log(id, occurred_at, level, component, message, details_json, correlation_id, created_at)
    VALUES (?, ?, 'INFO', 'SQLITE', 'Persistencia abierta y migrada.', ?, NULL, ?)`)
    .run(randomUUID(), now, JSON.stringify({
      dbFile: path.basename(runtime.dbPath),
      schemaVersion: database.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migration').get().version,
      encryptedAtRest: true,
      cipher: 'SQLite3MultipleCiphers'
    }), now);
  return database;
}

function getDb() {
  return database || openDatabase();
}

function closeDatabase() {
  if (database) {
    database.close();
    database = null;
  }
}

function reopenDatabase() {
  closeDatabase();
  return openDatabase();
}

function transaction(work) {
  const db = getDb();
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = work(db);
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

function currentSchemaVersion() {
  const row = getDb().prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migration').get();
  return row.version;
}

function databaseExists() {
  return fs.existsSync(runtime.dbPath) && fs.statSync(runtime.dbPath).size > 0;
}

function safeSqlitePath(filePath) {
  const resolved = path.resolve(filePath);
  return resolved.replaceAll("'", "''");
}

module.exports = {
  openDatabase,
  getDb,
  closeDatabase,
  reopenDatabase,
  transaction,
  currentSchemaVersion,
  databaseExists,
  safeSqlitePath,
  ensureDirectories
};
