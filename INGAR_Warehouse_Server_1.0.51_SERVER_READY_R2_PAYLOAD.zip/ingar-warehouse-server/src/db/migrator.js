'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { createHash, randomUUID } = require('node:crypto');
const { redactForLog, redactText } = require('../security/log-redaction');
const { openSqliteBytes, isPlaintextSqlite } = require('../security/sqlite-encryption');
const { isProtectedBuffer, protectBuffer, unprotectBuffer } = require('../security/data-protection');

function sha256(value) {
  return createHash('sha256').update(value).digest('hex');
}

function canonicalJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
}

function splitMigration(sql) {
  const upMarker = '-- +up';
  const downMarker = '-- +down';
  const upStart = sql.indexOf(upMarker);
  const downStart = sql.indexOf(downMarker);
  if (upStart < 0 || downStart < 0 || downStart <= upStart) {
    throw new Error('Formato de migración inválido: se requieren -- +up y -- +down.');
  }
  return {
    up: sql.slice(upStart + upMarker.length, downStart).trim(),
    down: sql.slice(downStart + downMarker.length).trim()
  };
}

function listMigrations(migrationsDir) {
  const migrations = fs.readdirSync(migrationsDir)
    .filter((name) => /^\d+_.+\.sql$/.test(name))
    .sort()
    .map((name) => {
      const match = name.match(/^(\d+)_/);
      const version = Number.parseInt(match[1], 10);
      const content = fs.readFileSync(path.join(migrationsDir, name));
      const sql = content.toString('utf8');
      return { version, name, fileSha256: sha256(content), ...splitMigration(sql) };
    });
  const versions = new Set();
  for (const migration of migrations) {
    if (versions.has(migration.version)) {
      const error = new Error(`Versión de migración duplicada: ${migration.version}.`);
      error.code = 'MIGRATION_VERSION_DUPLICATE';
      throw error;
    }
    versions.add(migration.version);
  }
  return migrations;
}

function tableExists(db, name) {
  return Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name));
}

function ensureMigrationTable(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migration (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL
  )`);
}

function appliedMigrationRows(db) {
  if (!tableExists(db, 'schema_migration')) return [];
  return db.prepare('SELECT version, name, applied_at FROM schema_migration ORDER BY version').all();
}

function databasePath(db) {
  const row = db.prepare("PRAGMA database_list").all().find((item) => item.name === 'main');
  return row?.file ? path.resolve(row.file) : null;
}

function safeSqlitePath(filePath) {
  return path.resolve(filePath).replaceAll("'", "''");
}

function fsyncDirectory(directory) {
  try {
    const fd = fs.openSync(directory, 'r');
    try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  } catch {}
}

function writeAtomic(filePath, bytes) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.tmp-${randomUUID()}`;
  let fd;
  try {
    fd = fs.openSync(temporary, 'wx');
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;
    fs.renameSync(temporary, filePath);
    fsyncDirectory(path.dirname(filePath));
  } catch (error) {
    try { if (fd !== null && fd !== undefined) fs.closeSync(fd); } catch {}
    fs.rmSync(temporary, { force: true });
    throw error;
  }
}

function verifySqliteBytes(dbBytes, workDir) {
  fs.mkdirSync(workDir, { recursive: true });
  const verifyPath = path.join(workDir, `${randomUUID()}.verify.sqlite`);
  fs.writeFileSync(verifyPath, dbBytes, { flag: 'wx' });
  let database;
  try {
    database = openSqliteBytes(verifyPath, { readOnly: true });
    const quick = database.prepare('PRAGMA quick_check').all();
    if (!quick.length || quick.some((row) => Object.values(row)[0] !== 'ok')) throw new Error('PRAGMA quick_check detectó corrupción.');
    const foreignKeys = database.prepare('PRAGMA foreign_key_check').all();
    if (foreignKeys.length) throw new Error(`Integridad referencial inválida: ${foreignKeys.length} violaciones.`);
    const schemaVersion = tableExists(database, 'schema_migration')
      ? Number(database.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migration').get().version || 0)
      : 0;
    return { quickCheck: 'ok', foreignKeyViolations: 0, schemaVersion };
  } finally {
    try { database?.close(); } catch {}
    fs.rmSync(verifyPath, { force: true });
  }
}

function decodeAndVerifyMigrationBackup(filePath, options = {}) {
  const stored = fs.readFileSync(filePath);
  const compressed = isProtectedBuffer(stored)
    ? unprotectBuffer(stored, { purpose: 'MIGRATION_BACKUP' }).bytes
    : stored;
  const payload = JSON.parse(zlib.gunzipSync(compressed, { maxOutputLength: 512 * 1024 * 1024 }).toString('utf8'));
  if (!['IWC_MIGRATION_BACKUP_V1', 'IWC_MIGRATION_BACKUP_V2'].includes(payload?.manifest?.format) || !payload.databaseBase64 || !payload.manifestSha256) {
    throw new Error('Formato de backup previo a migración inválido.');
  }
  if (sha256(canonicalJson(payload.manifest)) !== payload.manifestSha256) throw new Error('Hash del manifiesto de migración inválido.');
  const dbBytes = Buffer.from(payload.databaseBase64, 'base64');
  if (dbBytes.length !== payload.manifest.database.size || sha256(dbBytes) !== payload.manifest.database.sha256) {
    throw new Error('Integridad de la base de datos previa a migración inválida.');
  }
  const sqlite = verifySqliteBytes(dbBytes, options.workDir || path.dirname(filePath));
  if (sqlite.schemaVersion !== Number(payload.manifest.previousSchemaVersion)) throw new Error('La versión del backup no coincide con el manifiesto.');
  return {
    payload,
    dbBytes,
    sqlite,
    compressedSha256: sha256(stored),
    size: stored.length,
    encryptedContainer: isProtectedBuffer(stored)
  };
}

function resolveMigrationOptions(db, options = {}) {
  const dbPath = options.dbPath ? path.resolve(options.dbPath) : databasePath(db);
  const baseDir = dbPath ? path.dirname(dbPath) : fs.mkdtempSync(path.join(os.tmpdir(), 'iwc-migration-memory-'));
  return {
    dbPath,
    backupDir: path.resolve(options.backupDir || path.join(baseDir, 'migration-backups')),
    processName: String(options.processName || 'MIGRATOR'),
    sourceVersion: options.sourceVersion ? String(options.sourceVersion) : null
  };
}

function createPreMigrationBackup(db, migrations, previousSchemaVersion, targetSchemaVersion, options = {}) {
  const resolved = resolveMigrationOptions(db, options);
  const id = randomUUID();
  const startedAt = new Date().toISOString();
  const snapshotPath = path.join(resolved.backupDir, `${id}.snapshot.sqlite`);
  const backupPath = path.join(resolved.backupDir, `migration-${previousSchemaVersion}-to-${targetSchemaVersion}-${id}.iwcmigbak.gz`);
  try {
    fs.mkdirSync(resolved.backupDir, { recursive: true });
    db.exec(`VACUUM INTO '${safeSqlitePath(snapshotPath)}'`);
    const dbBytes = fs.readFileSync(snapshotPath);
    const manifest = {
      format: 'IWC_MIGRATION_BACKUP_V2',
      id,
      createdAt: startedAt,
      previousSchemaVersion,
      targetSchemaVersion,
      sourceDatabase: resolved.dbPath ? path.basename(resolved.dbPath) : 'memory.sqlite',
      processName: resolved.processName,
      sourceVersion: resolved.sourceVersion,
      database: {
        name: 'iwc.sqlite',
        size: dbBytes.length,
        sha256: sha256(dbBytes),
        encryptedAtRest: !isPlaintextSqlite(snapshotPath)
      },
      archiveProtection: {
        format: 'IWC_ENCRYPTED_CONTAINER_V1',
        cipher: 'AES-256-GCM',
        keyProvider: 'LOCAL_PROTECTED_MASTER_KEY'
      },
      pendingMigrations: migrations.map(({ version, name, fileSha256 }) => ({ version, name, fileSha256 }))
    };
    const payload = { manifest, manifestSha256: sha256(canonicalJson(manifest)), databaseBase64: dbBytes.toString('base64') };
    const compressed = zlib.gzipSync(Buffer.from(JSON.stringify(payload)), { level: 9 });
    writeAtomic(backupPath, protectBuffer(compressed, { purpose: 'MIGRATION_BACKUP' }));
    const verified = decodeAndVerifyMigrationBackup(backupPath, { workDir: resolved.backupDir });
    return {
      id,
      path: backupPath,
      pathRef: path.basename(backupPath),
      sha256: verified.compressedSha256,
      manifestSha256: payload.manifestSha256,
      size: verified.size,
      createdAt: startedAt,
      sqlite: verified.sqlite,
      options: resolved
    };
  } catch (error) {
    try { fs.rmSync(backupPath, { force: true }); } catch {}
    const wrapped = new Error(`No fue posible crear y verificar el backup previo a migración: ${error.message}`);
    wrapped.code = 'MIGRATION_BACKUP_FAILED';
    wrapped.cause = error;
    throw wrapped;
  } finally {
    try { fs.rmSync(snapshotPath, { force: true }); } catch {}
  }
}

function verifyAppliedMigrationIntegrity(db, migrations) {
  const applied = appliedMigrationRows(db);
  const byVersion = new Map(migrations.map((item) => [item.version, item]));
  for (const row of applied) {
    const file = byVersion.get(Number(row.version));
    if (!file) {
      const error = new Error(`Falta el archivo correspondiente a la migración aplicada ${row.version}.`);
      error.code = 'MIGRATION_FILE_MISSING';
      throw error;
    }
    if (file.name !== row.name) {
      const error = new Error(`El nombre de la migración ${row.version} no coincide con el registro aplicado.`);
      error.code = 'MIGRATION_NAME_MISMATCH';
      throw error;
    }
  }
  const hasIntegrity = tableExists(db, 'migration_file_integrity');
  const maxApplied = applied.length ? Number(applied.at(-1).version) : 0;
  if (maxApplied >= 17 && !hasIntegrity) {
    const error = new Error('Falta la tabla de integridad de migraciones para un esquema que debería contenerla.');
    error.code = 'MIGRATION_INTEGRITY_TABLE_MISSING';
    throw error;
  }
  if (!hasIntegrity) return { verified: 0, legacyBaselineRequired: applied.length > 0 };
  const integrityRows = db.prepare('SELECT version, name, file_sha256 FROM migration_file_integrity ORDER BY version').all();
  const integrityByVersion = new Map(integrityRows.map((row) => [Number(row.version), row]));
  for (const row of applied) {
    const integrity = integrityByVersion.get(Number(row.version));
    const file = byVersion.get(Number(row.version));
    if (!integrity) {
      const error = new Error(`Falta el hash registrado de la migración aplicada ${row.version}.`);
      error.code = 'MIGRATION_HASH_MISSING';
      throw error;
    }
    if (integrity.name !== file.name || integrity.file_sha256 !== file.fileSha256) {
      const error = new Error(`El archivo histórico de migración ${file.name} fue modificado después de aplicarse.`);
      error.code = 'MIGRATION_FILE_HASH_MISMATCH';
      throw error;
    }
  }
  return { verified: applied.length, legacyBaselineRequired: false };
}

function backfillMigrationIntegrity(db, migrations, now) {
  if (!tableExists(db, 'migration_file_integrity')) return;
  const applied = new Set(appliedMigrationRows(db).map((row) => Number(row.version)));
  const insert = db.prepare('INSERT OR IGNORE INTO migration_file_integrity(version, name, file_sha256, recorded_at) VALUES (?, ?, ?, ?)');
  for (const migration of migrations) {
    if (applied.has(migration.version)) insert.run(migration.version, migration.name, migration.fileSha256, now);
  }
}

function migrationExecutionPayload({ id, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion, processName, sourceVersion, backup, status, migrations, error }) {
  return {
    id,
    startedAt,
    finishedAt,
    previousSchemaVersion,
    targetSchemaVersion,
    processName,
    sourceVersion,
    backupRef: backup?.pathRef || null,
    backupSha256: backup?.sha256 || null,
    backupManifestSha256: backup?.manifestSha256 || null,
    status,
    migrations: migrations.map(({ version, name, fileSha256 }) => ({ version, name, fileSha256 })),
    error: error ? redactText(String(error.message || error)) : null
  };
}

function insertMigrationExecution(db, payload) {
  if (!tableExists(db, 'migration_execution')) return false;
  db.prepare(`INSERT INTO migration_execution(
    id, started_at, finished_at, previous_schema_version, target_schema_version,
    process_name, source_version, backup_ref, backup_sha256, backup_manifest_sha256,
    status, migrations_json, error, created_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(
      payload.id, payload.startedAt, payload.finishedAt, payload.previousSchemaVersion, payload.targetSchemaVersion,
      payload.processName, payload.sourceVersion, payload.backupRef, payload.backupSha256, payload.backupManifestSha256,
      payload.status, JSON.stringify(payload.migrations), payload.error, payload.finishedAt
    );
  return true;
}

function writeMigrationRunLog(backupDir, payload) {
  try {
    const directory = path.join(backupDir, 'migration-runs');
    const filePath = path.join(directory, `${payload.startedAt.replaceAll(':', '-').replaceAll('.', '-')}-${payload.id}.iwclog.enc`);
    const bytes = Buffer.from(`${JSON.stringify(redactForLog(payload), null, 2)}\n`);
    writeAtomic(filePath, protectBuffer(bytes, { purpose: 'MIGRATION_RUN_LOG' }));
    return filePath;
  } catch {
    return null;
  }
}

function migrate(db, migrationsDir, options = {}) {
  const migrations = listMigrations(migrationsDir);
  const appliedRows = appliedMigrationRows(db);
  verifyAppliedMigrationIntegrity(db, migrations);
  const applied = new Set(appliedRows.map((row) => Number(row.version)));
  const pending = migrations.filter((migration) => !applied.has(migration.version));
  if (!pending.length) return [];

  const previousSchemaVersion = appliedRows.length ? Number(appliedRows.at(-1).version) : 0;
  const targetSchemaVersion = Number(pending.at(-1).version);
  const resolved = resolveMigrationOptions(db, options);
  const startedAt = new Date().toISOString();
  const executionId = randomUUID();
  let backup;
  try {
    backup = createPreMigrationBackup(db, pending, previousSchemaVersion, targetSchemaVersion, resolved);
  } catch (error) {
    const finishedAt = new Date().toISOString();
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: resolved.processName, sourceVersion: resolved.sourceVersion, backup: null,
      status: 'FAILED', migrations: pending, error
    });
    try {
      db.exec('BEGIN IMMEDIATE');
      insertMigrationExecution(db, payload);
      db.exec('COMMIT');
    } catch {
      try { db.exec('ROLLBACK'); } catch {}
    }
    writeMigrationRunLog(resolved.backupDir, payload)
      || writeMigrationRunLog(resolved.dbPath ? path.dirname(resolved.dbPath) : os.tmpdir(), payload);
    throw error;
  }

  db.exec('BEGIN IMMEDIATE');
  try {
    ensureMigrationTable(db);
    for (const migration of pending) {
      try {
        db.exec(migration.up);
        db.prepare('INSERT INTO schema_migration(version, name, applied_at) VALUES (?, ?, ?)')
          .run(migration.version, migration.name, new Date().toISOString());
      } catch (error) {
        error.message = `Falló migración ${migration.name}: ${error.message}`;
        throw error;
      }
    }
    const finishedAt = new Date().toISOString();
    backfillMigrationIntegrity(db, migrations, finishedAt);
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: resolved.processName, sourceVersion: resolved.sourceVersion, backup,
      status: 'APPLIED', migrations: pending, error: null
    });
    insertMigrationExecution(db, payload);
    db.exec('COMMIT');
    writeMigrationRunLog(resolved.backupDir, payload);
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch {}
    const finishedAt = new Date().toISOString();
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: resolved.processName, sourceVersion: resolved.sourceVersion, backup,
      status: 'FAILED', migrations: pending, error
    });
    try {
      db.exec('BEGIN IMMEDIATE');
      insertMigrationExecution(db, payload);
      db.exec('COMMIT');
    } catch {
      try { db.exec('ROLLBACK'); } catch {}
    }
    writeMigrationRunLog(resolved.backupDir, payload);
    throw error;
  }
  return pending.map(({ version, name }) => ({ version, name }));
}

function rollbackLatest(db, migrationsDir, options = {}) {
  const migrations = listMigrations(migrationsDir);
  verifyAppliedMigrationIntegrity(db, migrations);
  const latest = appliedMigrationRows(db).at(-1);
  if (!latest) return null;
  const migration = migrations.find((item) => item.version === Number(latest.version));
  if (!migration) throw new Error(`No se encontró el archivo de migración ${latest.version}.`);
  const resolved = resolveMigrationOptions(db, options);
  const previousSchemaVersion = Number(latest.version);
  const targetSchemaVersion = Math.max(0, previousSchemaVersion - 1);
  const startedAt = new Date().toISOString();
  const executionId = randomUUID();
  let backup;
  try {
    backup = createPreMigrationBackup(db, [migration], previousSchemaVersion, targetSchemaVersion, resolved);
  } catch (error) {
    const finishedAt = new Date().toISOString();
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: `${resolved.processName}:ROLLBACK`, sourceVersion: resolved.sourceVersion, backup: null,
      status: 'FAILED', migrations: [migration], error
    });
    try {
      db.exec('BEGIN IMMEDIATE');
      insertMigrationExecution(db, payload);
      db.exec('COMMIT');
    } catch {
      try { db.exec('ROLLBACK'); } catch {}
    }
    writeMigrationRunLog(resolved.backupDir, payload)
      || writeMigrationRunLog(resolved.dbPath ? path.dirname(resolved.dbPath) : os.tmpdir(), payload);
    throw error;
  }
  db.exec('BEGIN IMMEDIATE');
  try {
    if (tableExists(db, 'migration_file_integrity')) db.prepare('DELETE FROM migration_file_integrity WHERE version = ?').run(latest.version);
    db.exec(migration.down);
    db.prepare('DELETE FROM schema_migration WHERE version = ?').run(latest.version);
    const finishedAt = new Date().toISOString();
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: `${resolved.processName}:ROLLBACK`, sourceVersion: resolved.sourceVersion, backup,
      status: 'ROLLED_BACK', migrations: [migration], error: null
    });
    insertMigrationExecution(db, payload);
    db.exec('COMMIT');
    writeMigrationRunLog(resolved.backupDir, payload);
    return { version: latest.version, name: latest.name, operationId: executionId, backupRef: backup.pathRef };
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch {}
    const finishedAt = new Date().toISOString();
    const payload = migrationExecutionPayload({
      id: executionId, startedAt, finishedAt, previousSchemaVersion, targetSchemaVersion,
      processName: `${resolved.processName}:ROLLBACK`, sourceVersion: resolved.sourceVersion, backup,
      status: 'FAILED', migrations: [migration], error
    });
    try {
      db.exec('BEGIN IMMEDIATE');
      insertMigrationExecution(db, payload);
      db.exec('COMMIT');
    } catch {
      try { db.exec('ROLLBACK'); } catch {}
    }
    writeMigrationRunLog(resolved.backupDir, payload);
    throw error;
  }
}

function restoreMigrationBackup(filePath, targetDbPath, options = {}) {
  const backupPath = path.resolve(filePath);
  const targetPath = path.resolve(targetDbPath);
  const verified = decodeAndVerifyMigrationBackup(backupPath, { workDir: path.dirname(targetPath) });
  const expected = `RESTORE-MIGRATION:${verified.payload.manifest.id}`;
  if (options.confirmation !== expected) {
    const error = new Error(`Confirmación requerida: ${expected}`);
    error.code = 'MIGRATION_RESTORE_CONFIRMATION_REQUIRED';
    throw error;
  }
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  const safetyPath = `${targetPath}.pre-migration-restore-${Date.now()}`;
  const restoreTemp = `${targetPath}.restore-${randomUUID()}`;
  try {
    if (fs.existsSync(targetPath)) fs.copyFileSync(targetPath, safetyPath, fs.constants.COPYFILE_EXCL);
    writeAtomic(restoreTemp, verified.dbBytes);
    fs.rmSync(targetPath, { force: true });
    fs.rmSync(`${targetPath}-wal`, { force: true });
    fs.rmSync(`${targetPath}-shm`, { force: true });
    fs.renameSync(restoreTemp, targetPath);
    fsyncDirectory(path.dirname(targetPath));
    const restoredBytes = fs.readFileSync(targetPath);
    const sqlite = verifySqliteBytes(restoredBytes, path.dirname(targetPath));
    if (sqlite.schemaVersion !== verified.sqlite.schemaVersion) throw new Error('La restauración no conservó la versión esperada.');
    const payload = migrationExecutionPayload({
      id: randomUUID(), startedAt: new Date().toISOString(), finishedAt: new Date().toISOString(),
      previousSchemaVersion: -1, targetSchemaVersion: sqlite.schemaVersion,
      processName: String(options.processName || 'MIGRATION_RESTORE'), sourceVersion: options.sourceVersion || null,
      backup: { pathRef: path.basename(backupPath), sha256: verified.compressedSha256, manifestSha256: verified.payload.manifestSha256 },
      status: 'RESTORED', migrations: [], error: null
    });
    writeMigrationRunLog(options.backupDir || path.dirname(backupPath), payload);
    return { restored: true, schemaVersion: sqlite.schemaVersion, safetyCopy: fs.existsSync(safetyPath) ? path.basename(safetyPath) : null, backupId: verified.payload.manifest.id };
  } catch (error) {
    fs.rmSync(restoreTemp, { force: true });
    try {
      fs.rmSync(targetPath, { force: true });
      fs.rmSync(`${targetPath}-wal`, { force: true });
      fs.rmSync(`${targetPath}-shm`, { force: true });
      if (fs.existsSync(safetyPath)) fs.copyFileSync(safetyPath, targetPath);
    } catch {}
    throw error;
  }
}

module.exports = {
  migrate,
  rollbackLatest,
  listMigrations,
  splitMigration,
  createPreMigrationBackup,
  decodeAndVerifyMigrationBackup,
  restoreMigrationBackup,
  verifyAppliedMigrationIntegrity
};
