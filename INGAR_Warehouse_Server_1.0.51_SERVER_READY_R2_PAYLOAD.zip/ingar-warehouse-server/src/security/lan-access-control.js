'use strict';

const net = require('node:net');

const MOBILE_ACCESS_STATIC_PATHS = new Set([
  '/',
  '/index.html',
  '/app.css',
  '/admin-warehouse-ops.css',
  '/ui-system.css',
  '/f12-visual.css',
  '/f12-visual.js',
  '/f13-visual.css',
  '/phase-g-product-polish.css',
  '/assets/c3-hero-panol.jpg',
  '/assets/ingar-logo.png',
  '/assets/icons.svg',
  '/assets/ingar-operacion-192.png',
  '/assets/ingar-operacion-512.png',
  '/mi-operacion',
  '/panol/workbench',
  '/control',
  '/gestion/config',
  '/acceso-limitado',
  '/operacion.css',
  '/operacion.js',
  '/operacion-client.js',
  '/operacion.webmanifest',
  '/sw.js',
  '/installation-validation-mobile.html',
  '/installation-validation-mobile.css',
  '/installation-validation-mobile.js',
  '/tablet',
  '/tablet/',
  '/tablet.html',
  '/terminal',
  '/terminal/',
  '/operacion',
  '/operacion/',
  '/operacion.html'
]);

function normalizeRemoteAddress(value) {
  const address = String(value || '').trim().toLowerCase();
  if (address.startsWith('::ffff:')) return address.slice(7);
  return address;
}

function isLoopbackAddress(value) {
  const address = normalizeRemoteAddress(value);
  return address === '127.0.0.1' || address === '::1' || address === 'localhost';
}

function matches(pathname, expression) {
  return expression.test(String(pathname || ''));
}

function isMobileLanRouteAllowed(method, pathname) {
  const verb = String(method || 'GET').toUpperCase();
  const path = String(pathname || '');
  if ((verb === 'GET' || verb === 'HEAD') && (MOBILE_ACCESS_STATIC_PATHS.has(path) || path.startsWith('/js/app/') || path === '/js/ui-runtime.js')) return true;
  if (verb === 'GET' && path === '/api/v1/health/live') return true;
  if (verb === 'GET' && (path === '/api/v1/public/branding' || path === '/api/v1/public/branding-logo')) return true;
  if (verb === 'GET' && path === '/api/v1/discovery/identity') return true;
  // C2: Mi operación usa la API canónica /operation con la misma sesión de Warehouse.
  if (path === '/api/v1/tablet' || path.startsWith('/api/v1/tablet/')) return true; // sólo para responder 410 legacy
  if (verb === 'GET' && path === '/api/v1/operation/home') return true;
  if (verb === 'GET' && path === '/api/v1/operation/bootstrap') return true;
  if (verb === 'GET' && path === '/api/v1/operation/kits') return true;
  if (verb === 'GET' && (path === '/api/v1/operation/availability' || path === '/api/v1/operation/requests' || path === '/api/v1/operation/custodies')) return true;
  if (verb === 'POST' && path === '/api/v1/operation/requests') return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/requests\/[^/]+\/photo$/)) return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/custodies\/[^/]+\/declare-return$/)) return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/custodies\/[^/]+\/return-photo$/)) return true;
  if (verb === 'GET' && matches(path, /^\/api\/v1\/operation\/custodies\/[^/]+\/return-receipt$/)) return true;
  if (verb === 'GET' && matches(path, /^\/api\/v1\/operation\/assets\/[^/]+\/photo$/)) return true;
  if (verb === 'POST' && path === '/api/v1/operation/vehicle-requests') return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/vehicle-requests\/[^/]+\/photo$/)) return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/vehicle-custodies\/[^/]+\/declare-return$/)) return true;
  if (verb === 'POST' && matches(path, /^\/api\/v1\/operation\/vehicle-custodies\/[^/]+\/return-photo$/)) return true;
  if (verb === 'POST' && path === '/api/v1/operation/mobile-validation/ping') return true;
  if (verb === 'POST' && path === '/api/v1/installation-validation/connect') return true;
  if (verb === 'POST' && path === '/api/v1/installation-validation/test-order') return true;
  if (verb === 'POST' && path === '/api/v1/installation-validation/ack-received') return true;
  if (verb === 'GET' && path === '/api/v1/installation-validation/mobile-status') return true;
  if (verb === 'GET' && matches(path, /^\/api\/v1\/evidence\/[^/]+$/)) return true;
  if (verb === 'GET' && path === '/api/v1/auth/me') return true;
  if (verb === 'GET' && path === '/api/v1/auth/csrf') return true;
  if (verb === 'POST' && (path === '/api/v1/auth/login' || path === '/api/v1/auth/logout' || path === '/api/v1/auth/access-state' || path === '/api/v1/auth/first-access' || path === '/api/v1/auth/password-reset')) return true;
  if (verb === 'GET' && path === '/api/v1/auth/experience') return true;
  return false;
}

function isRemoteLanRequest(req) {
  const address = normalizeRemoteAddress(req?.socket?.remoteAddress);
  if (!address || isLoopbackAddress(address)) return false;
  return net.isIP(address) !== 0;
}

module.exports = {
  MOBILE_ACCESS_STATIC_PATHS,
  normalizeRemoteAddress,
  isLoopbackAddress,
  isMobileLanRouteAllowed,
  isRemoteLanRequest
};
