'use strict';

const { getDb } = require('../db/database');
const { MANDATORY_ROLE_PERMISSIONS } = require('../config/catalogs');

function isMandatoryForRole(roleCode, permission) {
  return (MANDATORY_ROLE_PERMISSIONS[String(roleCode || '').toUpperCase()] || []).includes(permission);
}

function error() {
  return Object.assign(new Error('La operación está fuera del alcance asignado.'), { status: 403, code: 'SCOPE_FORBIDDEN' });
}

function activeAssignments(userId, db = getDb()) {
  const now = new Date().toISOString();
  return db.prepare(`SELECT site_id, location_id FROM user_role_scope
    WHERE user_id=? AND (valid_from IS NULL OR valid_from<=?) AND (valid_to IS NULL OR valid_to>=?)`).all(userId, now, now);
}

function permissionAssignments(user, permission = null, db = getDb()) {
  if (!user?.id) return [];
  if (!permission) return activeAssignments(user.id, db);
  const now = new Date().toISOString();
  const directRoles = db.prepare(`SELECT urs.site_id,urs.location_id,r.code
    FROM user_role_scope urs JOIN role r ON r.id=urs.role_id
    WHERE urs.user_id=? AND r.active=1
      AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)`).all(user.id, now, now);
  const mandatoryScopes = directRoles
    .filter((row) => isMandatoryForRole(row.code, permission))
    .map((row) => ({ site_id: row.site_id, location_id: row.location_id }));
  if (mandatoryScopes.length) return mandatoryScopes;

  const overrides = db.prepare(`SELECT p.code,upo.effect FROM user_permission_override upo JOIN permission p ON p.id=upo.permission_id
    WHERE upo.user_id=? AND p.code IN (?, '*') ORDER BY CASE WHEN p.code=? THEN 0 ELSE 1 END`).all(user.id, permission, permission);
  if (overrides.some((item) => item.effect === 'DENY')) return [];
  if (overrides.some((item) => item.effect === 'ALLOW')) return activeAssignments(user.id, db);
  const rows = db.prepare(`WITH RECURSIVE role_tree(assignment_id,role_id,site_id,location_id) AS (
      SELECT urs.id,urs.role_id,urs.site_id,urs.location_id
      FROM user_role_scope urs JOIN role r ON r.id=urs.role_id
      WHERE urs.user_id=? AND r.active=1
        AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)
      UNION ALL
      SELECT rt.assignment_id,r.parent_role_id,rt.site_id,rt.location_id
      FROM role_tree rt JOIN role r ON r.id=rt.role_id
      WHERE r.parent_role_id IS NOT NULL
    )
    SELECT DISTINCT rt.site_id,rt.location_id
    FROM role_tree rt JOIN role_permission rp ON rp.role_id=rt.role_id JOIN permission p ON p.id=rp.permission_id
    WHERE p.code IN (?, '*')`).all(user.id, now, now, permission);
  if (rows.length) return rows;
  if (user.permissions?.includes(permission) || user.permissions?.includes('*')) return activeAssignments(user.id, db);
  return [];
}

function userHasScope(user, siteId, locationId = null, permission = null, db = getDb()) {
  const scopes = permissionAssignments(user, permission, db);
  if (!scopes.length) return false;
  return scopes.some((scope) => {
    if (!scope.site_id && !scope.location_id) return true;
    if (scope.location_id) return scope.location_id === locationId && (!scope.site_id || scope.site_id === siteId);
    return scope.site_id === siteId;
  });
}

function assertUserScope(user, siteId, locationId = null, permission = null, db = getDb()) {
  if (!userHasScope(user, siteId, locationId, permission, db)) throw error();
}

function scopeWhere(user, permission, siteColumn, locationColumn, db = getDb()) {
  const scopes = permissionAssignments(user, permission, db);
  if (!scopes.length) return { sql: '0=1', params: [] };
  if (scopes.some((scope) => !scope.site_id && !scope.location_id)) return { sql: '1=1', params: [] };
  const siteIds = [...new Set(scopes.filter((scope) => scope.site_id && !scope.location_id).map((scope) => scope.site_id))];
  const locationIds = [...new Set(scopes.filter((scope) => scope.location_id).map((scope) => scope.location_id))];
  const clauses = [];
  const params = [];
  if (siteIds.length) { clauses.push(`${siteColumn} IN (${siteIds.map(() => '?').join(',')})`); params.push(...siteIds); }
  if (locationIds.length) { clauses.push(`${locationColumn} IN (${locationIds.map(() => '?').join(',')})`); params.push(...locationIds); }
  return { sql: clauses.length ? `(${clauses.join(' OR ')})` : '0=1', params };
}

function locationScope(db, locationId) {
  return db.prepare('SELECT sl.id AS location_id,sl.site_id FROM storage_location sl WHERE sl.id=?').get(locationId);
}
function assertLocationScope(user, locationId, permission, db = getDb()) {
  const location = locationScope(db, locationId);
  if (!location) throw Object.assign(new Error('Ubicación inexistente.'), { status: 422, code: 'LOCATION_INVALID' });
  assertUserScope(user, location.site_id, location.location_id, permission, db);
  return location;
}
function assetScope(db, assetId) {
  return db.prepare(`SELECT a.id,a.location_id,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
}
function assertAssetScope(user, assetId, permission, db = getDb()) {
  const asset = assetScope(db, assetId);
  if (!asset) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  assertUserScope(user, asset.site_id, asset.location_id, permission, db);
  return asset;
}

module.exports = { permissionAssignments, userHasScope, assertUserScope, scopeWhere, locationScope, assertLocationScope, assetScope, assertAssetScope };
