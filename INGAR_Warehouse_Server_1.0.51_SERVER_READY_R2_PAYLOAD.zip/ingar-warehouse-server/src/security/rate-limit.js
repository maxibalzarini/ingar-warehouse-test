'use strict';

const runtime = require('../config/runtime');

const buckets = new Map();
let lastSweepAt = 0;

function keyFor(ip) { return String(ip || 'unknown').slice(0, 128); }
function activeFailures(key, now) {
  const active = (buckets.get(key) || []).filter((timestamp) => now - timestamp < runtime.loginWindowMs);
  if (active.length) buckets.set(key, active); else buckets.delete(key);
  return active;
}
function sweep(now = Date.now()) {
  if (now - lastSweepAt < 60_000 && buckets.size < 1000) return;
  lastSweepAt = now;
  for (const key of buckets.keys()) activeFailures(key, now);
  if (buckets.size > 5000) {
    const excess = buckets.size - 5000;
    for (const key of [...buckets.keys()].slice(0, excess)) buckets.delete(key);
  }
}
function checkLoginRateLimit(ip, now = Date.now()) {
  sweep(now);
  return activeFailures(keyFor(ip), now).length < runtime.loginIpLimit;
}
function registerLoginFailure(ip, now = Date.now()) {
  sweep(now);
  const key = keyFor(ip);
  const active = activeFailures(key, now);
  active.push(now);
  buckets.set(key, active.slice(-runtime.loginIpLimit));
  return active.length;
}
function clearLoginFailures(ip) { buckets.delete(keyFor(ip)); }
function resetRateLimit() { buckets.clear(); lastSweepAt = 0; }
function rateLimitState() { return { buckets: buckets.size, failures: [...buckets.values()].reduce((n, v) => n + v.length, 0) }; }

module.exports = { checkLoginRateLimit, registerLoginFailure, clearLoginFailures, resetRateLimit, rateLimitState };
