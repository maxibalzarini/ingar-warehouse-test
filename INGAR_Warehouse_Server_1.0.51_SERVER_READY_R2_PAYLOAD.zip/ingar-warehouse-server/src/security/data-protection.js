'use strict';

const fs = require('node:fs');
const path = require('node:path');
const {
  randomBytes,
  createCipheriv,
  createDecipheriv,
  createHash,
  hkdfSync
} = require('node:crypto');
const { getMasterKey } = require('./key-manager');

const MAGIC = Buffer.from('IWCENC01', 'ascii');
const HEADER_BYTES = 4;
const MAX_HEADER_BYTES = 64 * 1024;
const MAX_PROTECTED_BYTES = 768 * 1024 * 1024;

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function purposeText(value) {
  const purpose = String(value || '').trim().toUpperCase();
  if (!purpose || purpose.length > 120 || !/^[A-Z0-9_.:-]+$/.test(purpose)) throw new Error('Propósito de cifrado inválido.');
  return purpose;
}

function deriveKey(salt, purpose) {
  return Buffer.from(hkdfSync('sha256', getMasterKey(), salt, Buffer.from(`IWC:${purpose}:V1`, 'utf8'), 32));
}

function isProtectedBuffer(value) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  return bytes.length >= MAGIC.length + HEADER_BYTES && bytes.subarray(0, MAGIC.length).equals(MAGIC);
}

function protectBuffer(value, options = {}) {
  const plaintext = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  const purpose = purposeText(options.purpose);
  const salt = randomBytes(32);
  const iv = randomBytes(12);
  const key = deriveKey(salt, purpose);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const aad = Buffer.from(`IWCENC01\0${purpose}`, 'utf8');
  cipher.setAAD(aad);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const header = Buffer.from(JSON.stringify({
    format: 'IWC_ENCRYPTED_CONTAINER_V1',
    purpose,
    cipher: 'AES-256-GCM',
    kdf: 'HKDF-SHA256',
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    authTag: cipher.getAuthTag().toString('base64'),
    plaintextSize: plaintext.length,
    plaintextSha256: sha256(plaintext)
  }), 'utf8');
  if (header.length > MAX_HEADER_BYTES) throw new Error('Cabecera cifrada fuera de límite.');
  const headerLength = Buffer.alloc(HEADER_BYTES);
  headerLength.writeUInt32BE(header.length, 0);
  return Buffer.concat([MAGIC, headerLength, header, ciphertext]);
}

function unprotectBuffer(value, options = {}) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  if (!isProtectedBuffer(bytes)) throw new Error('El archivo no es un contenedor cifrado INGAR.');
  if (bytes.length > MAX_PROTECTED_BYTES) throw new Error('El contenedor cifrado supera el límite admitido.');
  const headerLength = bytes.readUInt32BE(MAGIC.length);
  if (!headerLength || headerLength > MAX_HEADER_BYTES || MAGIC.length + HEADER_BYTES + headerLength >= bytes.length) {
    throw new Error('Cabecera cifrada inválida.');
  }
  const headerStart = MAGIC.length + HEADER_BYTES;
  const header = JSON.parse(bytes.subarray(headerStart, headerStart + headerLength).toString('utf8'));
  if (header?.format !== 'IWC_ENCRYPTED_CONTAINER_V1' || header.cipher !== 'AES-256-GCM' || header.kdf !== 'HKDF-SHA256') {
    throw new Error('Formato de cifrado no compatible.');
  }
  const purpose = purposeText(header.purpose);
  if (options.purpose && purpose !== purposeText(options.purpose)) throw new Error('El propósito del contenedor cifrado no coincide.');
  const salt = Buffer.from(header.salt || '', 'base64');
  const iv = Buffer.from(header.iv || '', 'base64');
  const tag = Buffer.from(header.authTag || '', 'base64');
  if (salt.length !== 32 || iv.length !== 12 || tag.length !== 16) throw new Error('Parámetros criptográficos inválidos.');
  const key = deriveKey(salt, purpose);
  const decipher = createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAAD(Buffer.from(`IWCENC01\0${purpose}`, 'utf8'));
  decipher.setAuthTag(tag);
  const plaintext = Buffer.concat([
    decipher.update(bytes.subarray(headerStart + headerLength)),
    decipher.final()
  ]);
  if (plaintext.length !== Number(header.plaintextSize) || sha256(plaintext) !== header.plaintextSha256) {
    throw new Error('La integridad del contenido cifrado es inválida.');
  }
  return { bytes: plaintext, header };
}

function atomicWrite(filePath, bytes, options = {}) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, bytes, { flag: 'wx', mode: options.mode || 0o600 });
  fs.renameSync(temporary, filePath);
  try { fs.chmodSync(filePath, options.mode || 0o600); } catch {}
}

function protectFile(filePath, options = {}) {
  const plaintext = fs.readFileSync(filePath);
  if (isProtectedBuffer(plaintext)) return { changed: false, bytes: plaintext.length };
  const protectedBytes = protectBuffer(plaintext, options);
  atomicWrite(filePath, protectedBytes);
  return { changed: true, bytes: protectedBytes.length };
}

function readProtectedFile(filePath, options = {}) {
  return unprotectBuffer(fs.readFileSync(filePath), options).bytes;
}

module.exports = {
  MAGIC,
  isProtectedBuffer,
  protectBuffer,
  unprotectBuffer,
  protectFile,
  readProtectedFile,
  atomicWrite
};
