'use strict';

const crypto = require('node:crypto');
const { promisify } = require('node:util');
const runtime = require('../config/runtime');

const scryptAsync = promisify(crypto.scrypt);
const KEY_LENGTH = 64;
const SCRYPT_OPTIONS = Object.freeze({ N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
const DUMMY_HASH = 'scrypt$16384$8$1$6c2ecf5ab8d73ab7583e59b3009c8f5d$4f99b641055ff86b7e5a0d042c92addca2f05e0e2e1fc1e15d29c4f36cfe063197c4201599fc0d6e4bb7679b09093617da45bbba0eed84e26432e66b79fac9f4';

function validatePassword(password, minLength = 4, maxLength = 8) {
  const value = String(password || '');
  const errors = [];
  if (value.length < minLength || value.length > maxLength) errors.push(`La contraseña debe tener entre ${minLength} y ${maxLength} caracteres.`);
  if (value && !/^[A-Za-z0-9]+$/.test(value)) errors.push('La contraseña sólo puede contener letras y números, sin símbolos ni espacios.');
  return errors;
}

function validateOperationalCredential(password, minLength = 4, maxLength = 8) {
  const value = String(password || '');
  const errors = [];
  if (value.length < minLength || value.length > maxLength) errors.push(`El PIN o clave operativa debe tener entre ${minLength} y ${maxLength} caracteres.`);
  if (value && !/^[A-Za-z0-9]+$/.test(value)) errors.push('El PIN o clave operativa sólo puede contener letras y números, sin símbolos ni espacios.');
  return errors;
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = await scryptAsync(password, salt, KEY_LENGTH, SCRYPT_OPTIONS);
  return ['scrypt', SCRYPT_OPTIONS.N, SCRYPT_OPTIONS.r, SCRYPT_OPTIONS.p, salt.toString('hex'), Buffer.from(derived).toString('hex')].join('$');
}

async function verifyPassword(password, storedHash = DUMMY_HASH) {
  try {
    const [algorithm, n, r, p, saltHex, hashHex] = String(storedHash).split('$');
    if (algorithm !== 'scrypt') return false;
    const expected = Buffer.from(hashHex, 'hex');
    const actual = Buffer.from(await scryptAsync(password, Buffer.from(saltHex, 'hex'), expected.length, {
      N: Number(n), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024
    }));
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch {
    await scryptAsync(String(password || ''), Buffer.alloc(16), KEY_LENGTH, SCRYPT_OPTIONS);
    return false;
  }
}

function randomOperationalPin(length = 6) {
  const normalizedLength = Math.min(8, Math.max(4, Number(length) || 6));
  let value = String(crypto.randomInt(1, 10));
  while (value.length < normalizedLength) value += String(crypto.randomInt(10));
  return value;
}

module.exports = {
  validatePassword,
  validateOperationalCredential,
  hashPassword,
  verifyPassword,
  randomOperationalPin,
  DUMMY_HASH
};
