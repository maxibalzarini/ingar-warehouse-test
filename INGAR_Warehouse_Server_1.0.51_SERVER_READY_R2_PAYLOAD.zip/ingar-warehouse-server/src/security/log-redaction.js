'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const SENSITIVE_KEY = /(?:password|passphrase|passwd|pwd|secret|token|authorization|cookie|csrf|session|dataurl|contentbase64|private[_-]?key|api[_-]?key|access[_-]?key|refresh[_-]?key|credential)/i;
const TOKEN_QUERY_KEY = /^(?:token|access_token|refresh_token|csrf|csrf_token|session|session_id|sid|code|key|api_key|authorization)$/i;
const MAX_STRING = 4000;

function secretMarker(value, options = {}) {
  const existing = String(value ?? '');
  if (/^\[REDACTED(?: sha256:[0-9a-f]{12})?\]$/i.test(existing)) return existing;
  if (options.noFingerprint) return '[REDACTED]';
  const digest = crypto.createHash('sha256').update(String(value ?? '')).digest('hex').slice(0, 12);
  return `[REDACTED sha256:${digest}]`;
}

function maskHomePaths(text) {
  return String(text)
    .replace(/\b[A-Za-z]:\\+Users\\+[^\\\s"']+/gi, '%USERPROFILE%')
    .replace(/\b[A-Za-z]:\\+Documents and Settings\\+[^\\\s"']+/gi, '%USERPROFILE%')
    .replace(/\/home\/[^/\s"']+/g, '$HOME')
    .replace(/\/Users\/[^/\s"']+/g, '$HOME');
}

function redactUrl(raw) {
  const source = String(raw || '');
  try {
    const absolute = /^[a-z][a-z0-9+.-]*:\/\//i.test(source);
    const url = new URL(source, absolute ? undefined : 'http://iwc.invalid');
    for (const key of [...url.searchParams.keys()]) {
      if (!TOKEN_QUERY_KEY.test(key)) continue;
      const values = url.searchParams.getAll(key);
      url.searchParams.delete(key);
      for (const value of values) url.searchParams.append(key, secretMarker(value));
    }
    if (url.username) url.username = '[REDACTED]';
    if (url.password) url.password = '[REDACTED]';
    const result = absolute ? url.toString() : `${url.pathname}${url.search}${url.hash}`;
    return maskHomePaths(result);
  } catch {
    return source.replace(/([?&](?:token|access_token|refresh_token|csrf(?:_token)?|session(?:_id)?|sid|code|api_key|key|authorization)=)([^&#\s"'<>},\]]+)/gi,
      (_match, prefix, value) => `${prefix}${encodeURIComponent(secretMarker(decodeURIComponentSafe(value)))}`);
  }
}

function decodeURIComponentSafe(value) {
  try { return decodeURIComponent(String(value).replace(/\+/g, '%20')); } catch { return value; }
}

function redactText(value) {
  let text = String(value ?? '');
  text = text.replace(/https?:\/\/[^\s"'<>]+|\/[A-Za-z0-9._~!$&'()*+,;=:@%\/-]+\?[^\s"'<>]+/gi, (candidate) => redactUrl(candidate));
  text = text.replace(/([?&](?:token|access_token|refresh_token|csrf(?:_token)?|session(?:_id)?|sid|code|api_key|key|authorization)=)([^&#\s"'<>},\]]+)/gi,
    (_match, prefix, secret) => `${prefix}${encodeURIComponent(secretMarker(decodeURIComponentSafe(secret)))}`);
  text = text.replace(/\b(Bearer|Basic)\s+([A-Za-z0-9._~+\/-]+=*)/gi,
    (_match, scheme, credential) => `${scheme} ${secretMarker(credential)}`);
  text = text.replace(/\b((?:set-)?cookie\s*[:=]\s*)([^\r\n]+)/gi, (_match, prefix, cookieText) => {
    const safe = String(cookieText).split(';').map((part, index) => {
      const eq = part.indexOf('=');
      if (eq < 0) return part;
      const name = part.slice(0, eq).trim();
      const content = part.slice(eq + 1).trim();
      if (index === 0 || /session|token|auth|csrf|sid/i.test(name)) return `${name}=${secretMarker(content)}`;
      return part;
    }).join(';');
    return `${prefix}${safe}`;
  });
  text = text.replace(/\b(password|passphrase|passwd|pwd|secret|csrf(?:Token)?|session(?:Token|Id)?|api[_-]?key|private[_-]?key)\s*([:=])\s*(["']?)([^\s,;"'}]+)\3/gi,
    (_match, key, separator) => `${key}${separator}[REDACTED]`);
  text = text.replace(/("(?:password|passphrase|passwd|pwd|secret|token|authorization|cookie|csrf(?:Token)?|session(?:Token|Id)?|api[_-]?key|private[_-]?key)"\s*:\s*")([^"]*)(")/gi,
    (_match, prefix, secret, suffix) => `${prefix}${secretMarker(secret, { noFingerprint: /pass|pwd/i.test(prefix) })}${suffix}`);
  text = text.replace(/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g,
    (token) => secretMarker(token));
  text = maskHomePaths(text);
  return text.length > MAX_STRING ? `${text.slice(0, MAX_STRING)}…[TRUNCATED]` : text;
}

function redactForLog(value, depth = 0, seen = new WeakSet(), key = '') {
  if (value === null || value === undefined) return value;
  if (SENSITIVE_KEY.test(String(key))) return /password|passphrase|passwd|pwd/i.test(String(key)) ? '[REDACTED]' : secretMarker(value);
  if (typeof value === 'string') return redactText(value);
  if (typeof value !== 'object') return value;
  if (depth > 8) return '[MAX_DEPTH]';
  if (seen.has(value)) return '[CIRCULAR]';
  seen.add(value);
  if (Buffer.isBuffer(value)) return `[BUFFER ${value.length} bytes]`;
  if (Array.isArray(value)) return value.slice(0, 200).map((item) => redactForLog(item, depth + 1, seen));
  const result = {};
  for (const [childKey, item] of Object.entries(value).slice(0, 200)) {
    result[childKey] = redactForLog(item, depth + 1, seen, childKey);
  }
  return result;
}

function sanitizeError(error) {
  if (!error) return null;
  return redactForLog({
    name: error.name || 'Error',
    code: error.code || null,
    message: error.message || String(error),
    stack: error.stack || null
  });
}

function scrubTextFile(filePath) {
  const target = path.resolve(String(filePath));
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return { file: target, changed: false, skipped: true };
  const before = fs.readFileSync(target, 'utf8');
  const after = redactText(before);
  if (after === before) return { file: target, changed: false, skipped: false };
  const temporary = `${target}.${process.pid}.${crypto.randomUUID()}.redacting`;
  try {
    fs.writeFileSync(temporary, after, { encoding: 'utf8', mode: 0o600 });
    const handle = fs.openSync(temporary, 'r+');
    try { fs.fsyncSync(handle); } finally { fs.closeSync(handle); }
    fs.renameSync(temporary, target);
    try { fs.chmodSync(target, 0o600); } catch {}
    return { file: target, changed: true, skipped: false };
  } catch (error) {
    fs.rmSync(temporary, { force: true });
    throw error;
  }
}

function scrubLogDirectory(directory) {
  const root = path.resolve(String(directory));
  if (!fs.existsSync(root)) return { directory: root, scanned: 0, changed: 0, files: [] };
  const allowed = new Set(['.log', '.json', '.jsonl', '.txt']);
  const files = [];
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    if (!entry.isFile() || !allowed.has(path.extname(entry.name).toLowerCase())) continue;
    files.push(scrubTextFile(path.join(root, entry.name)));
  }
  return { directory: maskHomePaths(root), scanned: files.length, changed: files.filter((item) => item.changed).length, files: files.map((item) => ({ ...item, file: maskHomePaths(item.file) })) };
}

function containsSensitiveLiteral(text, literals = []) {
  const haystack = String(text || '');
  return literals.some((literal) => literal && haystack.includes(String(literal)));
}

module.exports = {
  SENSITIVE_KEY,
  TOKEN_QUERY_KEY,
  secretMarker,
  redactUrl,
  redactText,
  redactForLog,
  sanitizeError,
  containsSensitiveLiteral,
  maskHomePaths,
  scrubTextFile,
  scrubLogDirectory
};
