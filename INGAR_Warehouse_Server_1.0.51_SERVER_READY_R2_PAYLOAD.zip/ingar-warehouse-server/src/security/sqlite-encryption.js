'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getMasterKey } = require('./key-manager');
const { protectBuffer, atomicWrite } = require('./data-protection');

const SQLITE_HEADER = Buffer.from('SQLite format 3\0', 'binary');

function bindingPath() {
  const runtimeName = process.versions.electron ? 'electron' : 'node';
  const abi = String(process.versions.modules || '');
  const candidate = path.join(
    runtime.projectRoot,
    'vendor',
    'sqlite-driver',
    'native',
    `${process.platform}-${process.arch}`,
    `${runtimeName}-v${abi}`,
    'better_sqlite3.node'
  );
  if (!fs.existsSync(candidate)) {
    const error = new Error(`No existe controlador SQLite cifrado para ${process.platform}-${process.arch}/${runtimeName}-v${abi}.`);
    error.code = 'ENCRYPTED_SQLITE_DRIVER_MISSING';
    throw error;
  }
  return candidate;
}

function driver() {
  return require(path.join(runtime.projectRoot, 'vendor', 'sqlite-driver', 'package', 'lib'));
}

function isPlaintextSqlite(filePath) {
  if (!fs.existsSync(filePath) || fs.statSync(filePath).size < SQLITE_HEADER.length) return false;
  const descriptor = fs.openSync(filePath, 'r');
  try {
    const header = Buffer.alloc(SQLITE_HEADER.length);
    fs.readSync(descriptor, header, 0, header.length, 0);
    return header.equals(SQLITE_HEADER);
  } finally {
    fs.closeSync(descriptor);
  }
}

function openCipherDatabase(filePath, options = {}) {
  const Database = driver();
  const database = new Database(filePath, {
    readonly: Boolean(options.readOnly),
    fileMustExist: Boolean(options.fileMustExist),
    timeout: Number(options.timeout) || 5000,
    nativeBinding: bindingPath()
  });
  try {
    database.key(options.key || getMasterKey());
    if (options.verify !== false) database.prepare('SELECT COUNT(*) AS count FROM sqlite_master').get();
    return database;
  } catch (error) {
    try { database.close(); } catch {}
    throw error;
  }
}

function openPlainDatabase(filePath, options = {}) {
  const Database = driver();
  return new Database(filePath, {
    readonly: Boolean(options.readOnly),
    fileMustExist: Boolean(options.fileMustExist),
    timeout: Number(options.timeout) || 5000,
    nativeBinding: bindingPath()
  });
}

function verifyCipherDatabase(filePath) {
  const database = openCipherDatabase(filePath, { readOnly: true, fileMustExist: true });
  try {
    const quick = database.pragma('quick_check');
    if (!quick.length || quick.some((row) => Object.values(row)[0] !== 'ok')) throw new Error('PRAGMA quick_check detectó corrupción.');
    const foreignKeys = database.pragma('foreign_key_check');
    if (foreignKeys.length) throw new Error(`Integridad referencial inválida: ${foreignKeys.length} violaciones.`);
    const hasSchema = database.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migration'").get();
    const schemaVersion = hasSchema
      ? Number(database.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migration').get().version || 0)
      : 0;
    return { quickCheck: 'ok', foreignKeyViolations: 0, schemaVersion, encrypted: true };
  } finally {
    database.close();
  }
}

function encryptPlaintextDatabase(filePath, options = {}) {
  if (!isPlaintextSqlite(filePath)) return { migrated: false, encrypted: fs.existsSync(filePath) };
  const database = openPlainDatabase(filePath, { fileMustExist: true });
  try {
    database.pragma('wal_checkpoint(TRUNCATE)');
  } finally {
    database.close();
  }
  for (const suffix of ['-wal', '-shm']) fs.rmSync(`${filePath}${suffix}`, { force: true });
  const plaintext = fs.readFileSync(filePath);
  if (options.recoveryDirectory) {
    const recoveryPath = path.join(options.recoveryDirectory, `pre-encryption-${Date.now()}-${randomUUID()}.iwclegacy.enc`);
    atomicWrite(recoveryPath, protectBuffer(plaintext, { purpose: 'LEGACY_DATABASE_RECOVERY' }));
  }
  const temporary = `${filePath}.${process.pid}.${Date.now()}.encrypting`;
  fs.copyFileSync(filePath, temporary, fs.constants.COPYFILE_EXCL);
  try {
    const candidate = openPlainDatabase(temporary, { fileMustExist: true });
    try {
      candidate.rekey(getMasterKey());
      candidate.pragma('wal_checkpoint(TRUNCATE)');
    } finally {
      candidate.close();
    }
    verifyCipherDatabase(temporary);
    const previous = `${filePath}.${process.pid}.${Date.now()}.plaintext`;
    fs.renameSync(filePath, previous);
    try {
      fs.renameSync(temporary, filePath);
      fs.rmSync(previous, { force: true });
    } catch (error) {
      if (fs.existsSync(previous) && !fs.existsSync(filePath)) fs.renameSync(previous, filePath);
      throw error;
    }
    return { migrated: true, encrypted: true };
  } finally {
    fs.rmSync(temporary, { force: true });
  }
}

function ensureEncryptedDatabase(filePath, options = {}) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  if (isPlaintextSqlite(filePath)) encryptPlaintextDatabase(filePath, options);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).size === 0) {
    const database = openCipherDatabase(filePath, { verify: false });
    database.close();
  }
  return verifyCipherDatabase(filePath);
}

function openSqliteBytes(filePath, options = {}) {
  return isPlaintextSqlite(filePath)
    ? openPlainDatabase(filePath, { readOnly: options.readOnly, fileMustExist: true })
    : openCipherDatabase(filePath, { readOnly: options.readOnly, fileMustExist: true });
}

module.exports = {
  SQLITE_HEADER,
  bindingPath,
  isPlaintextSqlite,
  openCipherDatabase,
  openPlainDatabase,
  openSqliteBytes,
  verifyCipherDatabase,
  encryptPlaintextDatabase,
  ensureEncryptedDatabase
};
