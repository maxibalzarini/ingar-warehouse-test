'use strict';

const {
  randomBytes,
  createCipheriv,
  createDecipheriv,
  createHash,
  scryptSync,
  timingSafeEqual
} = require('node:crypto');

const MAGIC = Buffer.from('IWCPORT1', 'ascii');
const HEADER_BYTES = 4;
const MAX_HEADER_BYTES = 64 * 1024;
const MAX_PORTABLE_BYTES = 768 * 1024 * 1024;
const SCRYPT_PARAMETERS = Object.freeze({ N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function validatedPassword(value) {
  const password = String(value || '').normalize('NFKC');
  if (password.length < 12 || password.length > 256) {
    const error = new Error('La contraseña portátil debe tener entre 12 y 256 caracteres.');
    error.status = 422;
    error.code = 'PORTABLE_BACKUP_PASSWORD_INVALID';
    throw error;
  }
  return password;
}

function deriveKey(password, salt, parameters = SCRYPT_PARAMETERS) {
  return scryptSync(validatedPassword(password), salt, 32, {
    N: Number(parameters.N),
    r: Number(parameters.r),
    p: Number(parameters.p),
    maxmem: SCRYPT_PARAMETERS.maxmem
  });
}

function isPortableBackup(value) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  return bytes.length >= MAGIC.length + HEADER_BYTES && bytes.subarray(0, MAGIC.length).equals(MAGIC);
}

function protectPortableBackup(value, password) {
  const plaintext = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  const salt = randomBytes(32);
  const iv = randomBytes(12);
  const key = deriveKey(password, salt);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const aad = Buffer.from('IWCPORT1\0PORTABLE_BACKUP', 'utf8');
  cipher.setAAD(aad);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const header = Buffer.from(JSON.stringify({
    format: 'IWC_PORTABLE_ENCRYPTED_BACKUP_V1',
    cipher: 'AES-256-GCM',
    kdf: 'SCRYPT',
    kdfParameters: { N: SCRYPT_PARAMETERS.N, r: SCRYPT_PARAMETERS.r, p: SCRYPT_PARAMETERS.p },
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    authTag: cipher.getAuthTag().toString('base64'),
    plaintextSize: plaintext.length,
    plaintextSha256: sha256(plaintext)
  }), 'utf8');
  if (header.length > MAX_HEADER_BYTES) throw new Error('Cabecera portátil fuera de límite.');
  const headerLength = Buffer.alloc(HEADER_BYTES);
  headerLength.writeUInt32BE(header.length, 0);
  return Buffer.concat([MAGIC, headerLength, header, ciphertext]);
}

function unprotectPortableBackup(value, password) {
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value || '');
  if (!isPortableBackup(bytes)) {
    const error = new Error('El archivo no es un backup portátil INGAR.');
    error.status = 422;
    error.code = 'PORTABLE_BACKUP_FORMAT_INVALID';
    throw error;
  }
  if (bytes.length > MAX_PORTABLE_BYTES) throw new Error('El backup portátil supera el límite admitido.');
  const headerLength = bytes.readUInt32BE(MAGIC.length);
  if (!headerLength || headerLength > MAX_HEADER_BYTES || MAGIC.length + HEADER_BYTES + headerLength >= bytes.length) {
    throw new Error('Cabecera portátil inválida.');
  }
  const headerStart = MAGIC.length + HEADER_BYTES;
  const header = JSON.parse(bytes.subarray(headerStart, headerStart + headerLength).toString('utf8'));
  if (header?.format !== 'IWC_PORTABLE_ENCRYPTED_BACKUP_V1' || header.cipher !== 'AES-256-GCM' || header.kdf !== 'SCRYPT') {
    throw new Error('Formato de backup portátil no compatible.');
  }
  const parameters = header.kdfParameters || {};
  if (Number(parameters.N) !== SCRYPT_PARAMETERS.N || Number(parameters.r) !== SCRYPT_PARAMETERS.r || Number(parameters.p) !== SCRYPT_PARAMETERS.p) {
    throw new Error('Parámetros criptográficos portátiles no compatibles.');
  }
  const salt = Buffer.from(header.salt || '', 'base64');
  const iv = Buffer.from(header.iv || '', 'base64');
  const authTag = Buffer.from(header.authTag || '', 'base64');
  if (salt.length !== 32 || iv.length !== 12 || authTag.length !== 16) throw new Error('Parámetros criptográficos portátiles inválidos.');
  try {
    const key = deriveKey(password, salt, parameters);
    const decipher = createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAAD(Buffer.from('IWCPORT1\0PORTABLE_BACKUP', 'utf8'));
    decipher.setAuthTag(authTag);
    const plaintext = Buffer.concat([
      decipher.update(bytes.subarray(headerStart + headerLength)),
      decipher.final()
    ]);
    const expectedHash = Buffer.from(String(header.plaintextSha256 || ''), 'hex');
    const actualHash = Buffer.from(sha256(plaintext), 'hex');
    if (
      plaintext.length !== Number(header.plaintextSize)
      || expectedHash.length !== actualHash.length
      || !timingSafeEqual(expectedHash, actualHash)
    ) throw new Error('Integridad portátil inválida.');
    return { bytes: plaintext, header };
  } catch (error) {
    const controlled = new Error('Contraseña incorrecta o backup portátil alterado.');
    controlled.status = 422;
    controlled.code = 'PORTABLE_BACKUP_AUTHENTICATION_FAILED';
    controlled.cause = error;
    throw controlled;
  }
}

module.exports = {
  MAGIC,
  MAX_PORTABLE_BYTES,
  isPortableBackup,
  protectPortableBackup,
  unprotectPortableBackup,
  validatedPassword
};
