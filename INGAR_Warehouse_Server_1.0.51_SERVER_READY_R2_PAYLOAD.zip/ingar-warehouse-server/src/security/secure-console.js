'use strict';

const { redactText, sanitizeError } = require('./log-redaction');

function safeErrorText(error) {
  const safe = sanitizeError(error);
  return safe?.stack || safe?.message || redactText(String(error));
}

function writeStdout(text) {
  process.stdout.write(redactText(text));
}

function writeStderr(text) {
  process.stderr.write(redactText(text));
}

module.exports = { safeErrorText, writeStdout, writeStderr };
