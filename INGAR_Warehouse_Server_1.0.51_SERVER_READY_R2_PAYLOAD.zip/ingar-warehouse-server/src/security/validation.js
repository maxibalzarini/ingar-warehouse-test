'use strict';

class ValidationError extends Error {
  constructor(message, fieldErrors = []) {
    super(message);
    this.name = 'ValidationError';
    this.status = 422;
    this.code = 'VALIDATION_ERROR';
    this.fieldErrors = fieldErrors;
  }
}

class HttpError extends Error {
  constructor(status, code, message, fieldErrors = []) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

function requiredString(value, field, { min = 1, max = 250, pattern = null } = {}) {
  if (typeof value !== 'string' || value.trim().length < min || value.trim().length > max || (pattern && !pattern.test(value.trim()))) {
    throw new ValidationError(`Campo inválido: ${field}.`, [{ field, message: `Debe tener entre ${min} y ${max} caracteres.` }]);
  }
  return value.trim();
}

function optionalString(value, field, { max = 2000 } = {}) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value !== 'string' || value.length > max) {
    throw new ValidationError(`Campo inválido: ${field}.`, [{ field, message: `Máximo ${max} caracteres.` }]);
  }
  return value.trim();
}

function requiredArray(value, field, max = 100) {
  if (!Array.isArray(value) || value.length > max) {
    throw new ValidationError(`Campo inválido: ${field}.`, [{ field, message: `Debe ser una lista de hasta ${max} elementos.` }]);
  }
  return value;
}

function parseBoolean(value, fallback = false) {
  return typeof value === 'boolean' ? value : fallback;
}

function safeInteger(value, fallback, min, max) {
  const number = Number.parseInt(value, 10);
  if (!Number.isInteger(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function normalizeUsername(value) {
  return requiredString(value, 'username', { min: 3, max: 60, pattern: /^[A-Za-z0-9._-]+$/ }).toLowerCase();
}


function normalizeTechnicalUsername(value) {
  const username = requiredString(value, 'username', { min: 3, max: 60 }).toLowerCase();
  if (!/^[a-z][a-z0-9]*\.[a-z][a-z0-9]*(?:\.[0-9]+)?$/.test(username)) {
    throw new ValidationError('El usuario técnico debe tener formato nombre.apellido.', [{ field: 'username', message: 'Formato obligatorio: nombre.apellido (opcional .2, .3, etc. sólo para homónimos).' }]);
  }
  return username;
}

function technicalUsernameBase(fullName) {
  const normalized = String(fullName || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const parts = normalized.trim().split(/\s+/).map((part) => part.replace(/[^a-z0-9]/g, '')).filter(Boolean);
  if (parts.length < 2) {
    throw new ValidationError('El nombre del usuario técnico debe incluir nombre y apellido.', [{ field: 'person.fullName', message: 'Ingresá al menos nombre y apellido para generar nombre.apellido.' }]);
  }
  return `${parts[0]}.${parts[parts.length - 1]}`;
}

function technicalUsernameMatchesFullName(username, fullName) {
  const normalized = normalizeTechnicalUsername(username);
  const base = technicalUsernameBase(fullName);
  if (normalized === base) return true;
  if (!normalized.startsWith(`${base}.`)) return false;
  return /^[0-9]+$/.test(normalized.slice(base.length + 1));
}

function normalizeEmail(value) {
  if (!value) return null;
  const email = requiredString(value, 'email', { min: 5, max: 254 }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new ValidationError('Email inválido.', [{ field: 'email', message: 'Formato de email inválido.' }]);
  }
  return email;
}

module.exports = {
  ValidationError,
  HttpError,
  requiredString,
  optionalString,
  requiredArray,
  parseBoolean,
  safeInteger,
  normalizeUsername,
  normalizeTechnicalUsername,
  technicalUsernameBase,
  technicalUsernameMatchesFullName,
  normalizeEmail
};
