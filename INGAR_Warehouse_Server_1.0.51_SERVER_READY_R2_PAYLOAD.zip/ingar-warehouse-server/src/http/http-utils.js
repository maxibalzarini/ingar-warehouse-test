'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');

const MIME = Object.freeze({
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
});

function normalizeCorrelationId(value) {
  const candidate = String(value || '').trim();
  return candidate && candidate.length <= 128 && /^[A-Za-z0-9._:-]+$/.test(candidate) ? candidate : randomUUID();
}

function requestContext(req) {
  const forwarded = runtime.serverMode ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '';
  return {
    correlationId: normalizeCorrelationId(req.headers['x-correlation-id']),
    ip: forwarded || req.socket.remoteAddress || null,
    userAgent: String(req.headers['user-agent'] || '').slice(0, 500)
  };
}

function applySecurityHeaders(res, correlationId) {
  res.setHeader('X-Correlation-Id', correlationId);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  res.setHeader('Cache-Control', 'no-store');
  if (res.iwcSecureTransport === true) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function json(res, status, payload, correlationId) {
  applySecurityHeaders(res, correlationId);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify({ ...payload, correlationId }));
}

function text(res, status, body, contentType, correlationId) {
  applySecurityHeaders(res, correlationId);
  res.statusCode = status;
  res.setHeader('Content-Type', contentType || 'text/plain; charset=utf-8');
  res.end(body);
}

function binary(res, status, body, contentType, correlationId, headers = {}) {
  applySecurityHeaders(res, correlationId);
  res.statusCode = status;
  res.setHeader('Content-Type', contentType || 'application/octet-stream');
  res.setHeader('Content-Length', Buffer.byteLength(body));
  for (const [name, value] of Object.entries(headers)) res.setHeader(name, value);
  res.end(body);
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > runtime.maxBodyBytes) {
      const error = new Error('El cuerpo de la solicitud supera el límite permitido.');
      error.status = 413; error.code = 'BODY_TOO_LARGE'; throw error;
    }
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  const contentType = String(req.headers['content-type'] || '');
  if (!contentType.startsWith('application/json')) {
    const error = new Error('Content-Type debe ser application/json.');
    error.status = 415; error.code = 'UNSUPPORTED_MEDIA_TYPE'; throw error;
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    const error = new Error('JSON inválido.');
    error.status = 400; error.code = 'INVALID_JSON'; throw error;
  }
}

async function readBinary(req, maximumBytes = runtime.maxBodyBytes) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maximumBytes) {
      const error = new Error('El archivo supera el límite permitido.');
      error.status = 413;
      error.code = 'FILE_TOO_LARGE';
      throw error;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function parseCookies(req) {
  const raw = String(req.headers.cookie || '');
  const cookies = {};
  for (const part of raw.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    try { cookies[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1).trim()); } catch { continue; }
  }
  return cookies;
}

function cookieSecuritySuffix(res, options = {}) {
  const secure = options.secure ?? (res.iwcSecureTransport === true);
  return secure ? '; Secure' : '';
}

function setNamedSessionCookie(res, cookieName, token, maxAgeSeconds, options = {}) {
  res.setHeader('Set-Cookie', `${cookieName}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.max(0, Math.floor(maxAgeSeconds))}${cookieSecuritySuffix(res, options)}`);
}

function clearNamedSessionCookie(res, cookieName, options = {}) {
  res.setHeader('Set-Cookie', `${cookieName}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${cookieSecuritySuffix(res, options)}`);
}

function setSessionCookie(res, token, maxAgeSeconds, options = {}) {
  setNamedSessionCookie(res, runtime.cookieName, token, maxAgeSeconds, options);
}

function clearSessionCookie(res, options = {}) {
  clearNamedSessionCookie(res, runtime.cookieName, options);
}


function serveStatic(res, pathname, correlationId) {
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const target = path.resolve(runtime.publicDir, relative);
  if (!target.startsWith(path.resolve(runtime.publicDir) + path.sep)) return false;
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return false;
  const extension = path.extname(target).toLowerCase();
  applySecurityHeaders(res, correlationId);
  res.statusCode = 200;
  res.setHeader('Content-Type', MIME[extension] || 'application/octet-stream');
  const desktopNoStore = new Set(['index.html', 'app.css', 'ingar-logo.png', 'sw.js', 'operacion.css', 'operacion.js', 'operacion-client.js', 'operacion.webmanifest']);
  // app.js se dividio en modulos bajo public/js/app/*.js (mismo contenido, sin cambios
  // de logica); todos requieren el mismo no-store que antes tenia el archivo unico.
  if (extension === '.html' || desktopNoStore.has(path.basename(target)) || relative.startsWith('js/app/')) {
    res.setHeader('Cache-Control', 'no-store, max-age=0, must-revalidate');
  } else {
    res.setHeader('Cache-Control', 'public, max-age=3600');
  }
  fs.createReadStream(target).pipe(res);
  return true;
}

function csvEscape(value) {
  let textValue = value === null || value === undefined ? '' : (typeof value === 'object' ? JSON.stringify(value) : String(value));
  if (/^[=+\-@\t\r]/.test(textValue)) textValue = `'${textValue}`;
  return `"${textValue.replaceAll('"', '""')}"`;
}

module.exports = { normalizeCorrelationId, requestContext, applySecurityHeaders, json, text, binary, readJson, readBinary, parseCookies, setSessionCookie, clearSessionCookie, serveStatic, csvEscape };
