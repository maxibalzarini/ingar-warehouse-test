'use strict';

const { getReportCatalog, generateReport, listReportExecutions } = require('../../services/report-service');
const { exportReport, FORMAT_CONFIG } = require('../../services/report-export-service');
const { json, readJson } = require('../http-utils');
const { match, protectedDownload, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/reports/catalog') {
    const auth = requireAuth(req, 'Reports.Read');
    json(res, 200, getReportCatalog(auth.user), baseContext.correlationId); return true;
  }

  let reportParams = match(pathname, '/api/v1/reports/:code/preview');
  if (reportParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Reports.Generate'); requireCsrf(req, auth);
    json(res, 200, generateReport(reportParams.code, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  const reportExportParams = match(pathname, '/api/v1/reports/:code/export/:format');
  if (reportExportParams && req.method === 'POST') {
    const format = String(reportExportParams.format || '').toUpperCase();
    const permission = FORMAT_CONFIG[format]?.permission;
    if (!permission) throw Object.assign(new Error('Formato de exportación no soportado.'), { status: 404, code: 'REPORT_EXPORT_FORMAT_INVALID' });
    const auth = requireAuth(req, permission); requireCsrf(req, auth);
    const file = exportReport(reportExportParams.code, format, await readJson(req), contextWithUser(baseContext, auth));
    protectedDownload(res, file.bytes, file.filename, file.mimeType, baseContext.correlationId, {
      'X-Report-Export-Id': file.exportId,
      'X-Report-Execution-Id': file.executionId,
      'X-Original-Content-SHA256': file.sha256,
      'X-Report-Row-Count': String(file.rowCount)
    }); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/reports/executions') {
    const auth = requireAuth(req, 'Reports.Audit');
    json(res, 200, listReportExecutions(auth.user, {
      dateFrom: searchParams.get('dateFrom'), dateTo: searchParams.get('dateTo'), search: searchParams.get('search'),
      page: searchParams.get('page'), pageSize: searchParams.get('pageSize')
    }), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
