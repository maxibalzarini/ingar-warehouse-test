'use strict';

const { listNotifications, markNotificationRead, markAllNotificationsRead, createSystemNotification } = require('../../services/notification-service');
const { listSchedulerJobs, updateSchedulerJob, runSchedulerJob } = require('../../services/scheduler-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/notifications') {
    const auth = requireAuth(req, 'Notifications.Read');
    json(res, 200, { items: listNotifications(auth.user, { status: searchParams.get('status'), unread: searchParams.get('unread'), type: searchParams.get('type'), limit: searchParams.get('limit') }) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/notifications') {
    const auth = requireAuth(req, 'Notifications.Manage'); requireCsrf(req, auth);
    json(res, 201, createSystemNotification(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/notifications/read-all') {
    const auth = requireAuth(req, 'Notifications.Read'); requireCsrf(req, auth);
    json(res, 200, markAllNotificationsRead(auth.user, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  let notificationParams = match(pathname, '/api/v1/notifications/:id/read');
  if (notificationParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Notifications.Read'); requireCsrf(req, auth);
    json(res, 200, { notification: markNotificationRead(notificationParams.id, auth.user, contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/scheduler/jobs') {
    requireAuth(req, 'Scheduler.Read'); json(res, 200, { items: listSchedulerJobs() }, baseContext.correlationId); return true;
  }
  let schedulerParams = match(pathname, '/api/v1/scheduler/jobs/:id');
  if (schedulerParams && (req.method === 'PATCH' || req.method === 'PUT')) {
    const auth = requireAuth(req, 'Scheduler.Manage'); requireCsrf(req, auth);
    json(res, 200, { job: updateSchedulerJob(schedulerParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  schedulerParams = match(pathname, '/api/v1/scheduler/jobs/:code/run');
  if (schedulerParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Scheduler.Run'); requireCsrf(req, auth);
    json(res, 200, runSchedulerJob(schedulerParams.code, contextWithUser({ ...baseContext, source: 'API' }, auth)), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
