'use strict';

const { hasPermission } = require('../../services/permission-service');
const { listPolicies, createPolicy, updatePolicy } = require('../../services/request-policy-service');
const { listRequestsPage, getRequest, createRequest, updateRequest, decideRequest, cancelRequest } = require('../../services/request-service');
const { prepareRequest, markRequestReady, handoverRequest, getPreparation } = require('../../services/warehouse-service');
const { quickHandoverRequest } = require('../../services/simple-warehouse-service');
const { quickHandoverSerializedRequest } = require('../../services/serialized-warehouse-service');
const { quickHandoverVehicleRequest, getVehicleRequestDetail } = require('../../services/vehicle-warehouse-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/request-policies') {
    requireAuth(req, 'Requests.Policy');
    json(res, 200, { items: listPolicies({ operationType: searchParams.get('operationType'), active: searchParams.has('active') ? searchParams.get('active') === 'true' : undefined }) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/request-policies') {
    const auth = requireAuth(req, 'Requests.Policy'); requireCsrf(req, auth);
    json(res, 201, { policy: createPolicy(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let requestParams = match(pathname, '/api/v1/request-policies/:id');
  if (requestParams && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Requests.Policy'); requireCsrf(req, auth);
    json(res, 200, { policy: updatePolicy(requestParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/requests') {
    const auth = requireAnyPermission(req, ['Requests.ReadOwn', 'Requests.ReadAll']);
    const allowAll = hasPermission(auth.user, 'Requests.ReadAll');
    json(res, 200, listRequestsPage(Object.fromEntries(searchParams), auth.user, allowAll), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/requests') {
    const auth = requireAuth(req, 'Requests.Create'); requireCsrf(req, auth);
    const body = await readJson(req); body.clientRequestId = body.clientRequestId || req.headers['idempotency-key'];
    json(res, 201, createRequest(body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/approve');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Requests.Approve'); requireCsrf(req, auth);
    json(res, 200, { request: decideRequest(requestParams.id, 'APROBADA', await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/reject');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Requests.Approve'); requireCsrf(req, auth);
    json(res, 200, { request: decideRequest(requestParams.id, 'RECHAZADA', await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/cancel');
  if (requestParams && req.method === 'POST') {
    const auth = requireAnyPermission(req, ['Requests.CancelOwn', 'Requests.CancelAny']); requireCsrf(req, auth);
    json(res, 200, { request: cancelRequest(requestParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Requests.CancelAny')) }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id');
  if (requestParams && req.method === 'GET') {
    const auth = requireAnyPermission(req, ['Requests.ReadOwn', 'Requests.ReadAll']);
    json(res, 200, { request: getRequest(requestParams.id, auth.user, hasPermission(auth.user, 'Requests.ReadAll')) }, baseContext.correlationId); return true;
  }
  if (requestParams && req.method === 'PATCH') {
    const auth = requireAnyPermission(req, ['Requests.UpdateOwn', 'Requests.UpdateAny']); requireCsrf(req, auth);
    json(res, 200, { request: updateRequest(requestParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Requests.UpdateAny')) }, baseContext.correlationId); return true;
  }

  requestParams = match(pathname, '/api/v1/requests/:id/preparation');
  if (requestParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Warehouse.Prepare');
    json(res, 200, { preparation: getPreparation(requestParams.id, auth.user, 'Warehouse.Prepare') }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/prepare');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Prepare'); requireCsrf(req, auth);
    json(res, 200, { preparation: prepareRequest(requestParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/ready');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Prepare'); requireCsrf(req, auth);
    json(res, 200, markRequestReady(requestParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/quick-handover');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickHandoverRequest(requestParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/serialized-handover');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickHandoverSerializedRequest(requestParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  requestParams = match(pathname, '/api/v1/requests/:id/vehicle-detail');
  if (requestParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Warehouse.Operate');
    json(res, 200, { vehicleDetail: getVehicleRequestDetail(requestParams.id, auth.user, 'Warehouse.Operate') }, baseContext.correlationId); return true;
  }
  requestParams = match(pathname, '/api/v1/requests/:id/vehicle-handover');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickHandoverVehicleRequest(requestParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  requestParams = match(pathname, '/api/v1/requests/:id/handover');
  if (requestParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, handoverRequest(requestParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
