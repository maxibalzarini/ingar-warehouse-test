'use strict';

const fs = require('node:fs');
const path = require('node:path');
const runtime = require('../../config/runtime');
const { getDb } = require('../../db/database');
const { listSettings, updateSettings, updateSettingsInDb, getSetting } = require('../../services/settings-service');
const { queryAudit, verifyAuditChain, getAuditHealth } = require('../../services/audit-service');
const logger = require('../../services/logger');
const { saveOwnedEvidenceDataUrl } = require('../../services/evidence-service');
const { createBackup, verifyBackup, restoreBackup, exportPortableBackup, importPortableBackup, listBackups, startBackupScheduler } = require('../../services/backup-service');
const { listLocations, updateOrganization, createSite, updateSite, deleteSite, createLocation, updateLocation, setLocationActive, deleteLocation, locationTransferOverview, transferLocationAssets, emptyAndDeactivateLocation, emptyAndDeleteLocation } = require('../../services/location-service');
const { getNetworkStatus } = require('../../services/network-service');
const { getDiscoveryIdentity, getLanDiscoveryStatus } = require('../../services/lan-discovery-service');
const { readProtectedFile } = require('../../security/data-protection');
const { json, text, binary, readJson, readBinary, csvEscape } = require('../http-utils');
const { match, protectedDownload, requireAuth, requireAnyPermission, systemStatusForUser, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  let params;
  if (req.method === 'GET' && pathname === '/api/v1/public/branding') {
    const organization = getDb().prepare('SELECT name FROM organization WHERE active=1 ORDER BY created_at LIMIT 1').get();
    const clientLogoEvidenceId = getSetting('organization.logoEvidenceId', null);
    const organizationName = String(getSetting('organization.name', organization?.name || 'Cliente') || organization?.name || 'Cliente');
    json(res, 200, { branding: { organizationName, productName: 'INGAR Warehouse', clientLogoConfigured: Boolean(clientLogoEvidenceId), clientLogoUrl: clientLogoEvidenceId ? `/api/v1/public/branding-logo?rev=${encodeURIComponent(clientLogoEvidenceId)}` : null } }, baseContext.correlationId);
    return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/public/branding-logo') {
    const evidenceId = getSetting('organization.logoEvidenceId', null);
    if (!evidenceId) throw Object.assign(new Error('Logo de cliente no configurado.'), { status:404, code:'BRANDING_LOGO_NOT_FOUND' });
    const row = getDb().prepare(`SELECT file_ref,mime_type FROM file_evidence WHERE id=? AND owner_type='ORGANIZATION' AND purpose='LOGO' AND lifecycle_state='ACTIVE'`).get(evidenceId);
    if (!row) throw Object.assign(new Error('Logo de cliente no encontrado.'), { status:404, code:'BRANDING_LOGO_NOT_FOUND' });
    const root = path.resolve(runtime.evidenceDir), full = path.resolve(runtime.evidenceDir,row.file_ref);
    if (!full.startsWith(root + path.sep) || !fs.existsSync(full)) throw Object.assign(new Error('Logo de cliente no disponible.'), { status:404, code:'BRANDING_LOGO_NOT_FOUND' });
    const bytes = readProtectedFile(full,{purpose:'EVIDENCE_FILE'});
    binary(res,200,bytes,row.mime_type,baseContext.correlationId,{'Cache-Control':'public, max-age=300'}); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/config') {
    requireAuth(req, 'Config.Read'); json(res, 200, { settings: listSettings() }, baseContext.correlationId); return true;
  }
  if (req.method === 'PUT' && pathname === '/api/v1/config') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    const body = await readJson(req);
    const settings = updateSettings(body.changes, contextWithUser(baseContext, auth));
    if (body.changes && (Object.prototype.hasOwnProperty.call(body.changes, 'backup.enabled') || Object.prototype.hasOwnProperty.call(body.changes, 'backup.intervalHours'))) {
      startBackupScheduler();
    }
    json(res, 200, { settings }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/config/logo') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    const body = await readJson(req);
    const context = contextWithUser(baseContext, auth);
    const organization = getDb().prepare('SELECT id FROM organization WHERE active=1 ORDER BY created_at LIMIT 1').get();
    if (!organization) throw Object.assign(new Error('No existe una organización activa.'), { status: 409, code: 'ORGANIZATION_NOT_FOUND' });
    const result = saveOwnedEvidenceDataUrl(
      body,
      { ownerType: 'ORGANIZATION', ownerId: organization.id, purpose: 'LOGO' },
      context,
      { allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'], maxBytes: runtime.maxImageBytes },
      (db, evidence) => ({ evidence, settings: updateSettingsInDb({ 'organization.logoEvidenceId': evidence.id }, context, db) })
    );
    json(res, 201, result, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/config/locations') {
    requireAnyPermission(req, ['Config.Read', 'Assets.Read', 'Incident.Read', 'Blocks.Read']);
    json(res, 200, listLocations(), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/organizations/:id');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { organization: updateOrganization(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/transfer-overview');
  if (params && req.method === 'GET') {
    requireAuth(req, 'Config.Read');
    json(res, 200, locationTransferOverview(params.id, {
      destinationLocationId: searchParams.get('destinationLocationId') || null,
      q: searchParams.get('q') || '',
      includeItems: searchParams.get('includeItems') === 'true',
      limit: Number(searchParams.get('limit') || 40)
    }), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/transfer-assets');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, transferLocationAssets(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/empty-and-deactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, emptyAndDeactivateLocation(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/empty-and-delete');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, emptyAndDeleteLocation(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/config/sites') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 201, { site: createSite(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/sites/:id');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { site: updateSite(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'DELETE') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, deleteSite(params.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/config/locations') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 201, { location: createLocation(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/deactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { location: setLocationActive(params.id, false, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id/reactivate');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { location: setLocationActive(params.id, true, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/config/locations/:id');
  if (params && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { location: updateLocation(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (params && req.method === 'DELETE') {
    const auth = requireAuth(req, 'Config.Update'); requireCsrf(req, auth);
    json(res, 200, { location: deleteLocation(params.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/audit') {
    requireAuth(req, 'Audit.Read');
    json(res, 200, { items: queryAudit(Object.fromEntries(searchParams)), chain: verifyAuditChain() }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/audit/verify') {
    requireAuth(req, 'Audit.Read'); json(res, 200, verifyAuditChain(), baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/audit/health') {
    requireAuth(req, 'Audit.Read');
    json(res, 200, getAuditHealth({ verify: searchParams.get('verify') === 'true' }), baseContext.correlationId); return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/logs/client') {
    const auth = requireAuth(req, 'Auth.Self'); requireCsrf(req, auth);
    const body = await readJson(req);
    const level = ['INFO', 'WARN', 'ERROR'].includes(String(body.level).toUpperCase()) ? String(body.level).toUpperCase() : 'INFO';
    logger.write(level, 'FRONTEND', String(body.message || '').slice(0, 500), body.details || null, baseContext.correlationId);
    json(res, 201, { recorded: true }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/logs') {
    requireAuth(req, 'Logs.Read');
    json(res, 200, { items: logger.queryLogs(Object.fromEntries(searchParams)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/logs/export') {
    requireAuth(req, 'Logs.Export');
    const items = logger.queryLogs({ ...Object.fromEntries(searchParams), limit: 1000 });
    const columns = ['occurred_at', 'level', 'component', 'message', 'details_json', 'correlation_id'];
    const csv = [columns.map(csvEscape).join(','), ...items.map((item) => columns.map((column) => csvEscape(item[column])).join(','))].join('\r\n');
    protectedDownload(res, csv, `iwc-logs-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv; charset=utf-8', baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/backups') {
    requireAuth(req, 'Backup.Read'); json(res, 200, { items: listBackups() }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/backups') {
    const auth = requireAuth(req, 'Backup.Create'); requireCsrf(req, auth);
    json(res, 201, { backup: createBackup(contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/backups/portable/import') {
    const auth = requireAuth(req, 'Backup.Restore'); requireCsrf(req, auth);
    const contentType = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (contentType !== 'application/vnd.ingar.portable-backup-import') {
      throw Object.assign(new Error('Tipo de archivo portátil inválido.'), { status: 415, code: 'UNSUPPORTED_MEDIA_TYPE' });
    }
    const result = importPortableBackup(await readBinary(req, runtime.maxPortableBackupBytes), contextWithUser(baseContext, auth));
    json(res, 201, result, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/backups/:id/portable');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Backup.Verify'); requireCsrf(req, auth);
    const body = await readJson(req);
    const portable = exportPortableBackup(params.id, body.password, contextWithUser(baseContext, auth));
    binary(res, 200, portable.bytes, 'application/vnd.ingar.portable-backup', baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="${portable.filename}"`,
      'X-Content-SHA256': portable.sha256,
      'X-IWC-Protection': 'IWC_PORTABLE_ENCRYPTED_BACKUP_V1'
    });
    return true;
  }
  params = match(pathname, '/api/v1/backups/:id/verify');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Backup.Verify'); requireCsrf(req, auth);
    json(res, 200, verifyBackup(params.id, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/backups/:id/restore');
  if (params && req.method === 'POST') {
    const auth = requireAuth(req, 'Backup.Restore'); requireCsrf(req, auth);
    const body = await readJson(req);
    json(res, 200, restoreBackup(params.id, body.confirmation, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }


  if (req.method === 'GET' && pathname === '/api/v1/system/status') {
    const auth = requireAnyPermission(req, ['Config.Read', 'Resilience.Read', 'Scheduler.Read', 'Backup.Read', 'Audit.Read', 'Logs.Read', 'Portal.Manage']);
    json(res, 200, systemStatusForUser(auth.user), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/resilience/status') {
    requireAuth(req, 'Resilience.Read');
    const dbOk = Boolean(getDb().prepare('SELECT 1 AS ok').get().ok);
    const scheduler = getDb().prepare("SELECT COUNT(*) AS total,SUM(CASE WHEN enabled=1 THEN 1 ELSE 0 END) AS enabled,SUM(CASE WHEN last_status='FAILED' THEN 1 ELSE 0 END) AS failed FROM scheduler_job").get();
    json(res, 200, { status: dbOk && Number(scheduler.failed || 0) === 0 ? 'READY' : 'DEGRADED', database: dbOk, scheduler, offline: { enabled: true, criticalMutationsQueued: false, storage: 'INDEXED_DB', allowed: ['REQUEST_DRAFT'] } }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/discovery/identity') {
    json(res, 200, { ...getDiscoveryIdentity(), discovery: getLanDiscoveryStatus() }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/health/live') {
    json(res, 200, { status: 'UP', version: runtime.sourceVersion }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/health/mobile') {
    const network = getNetworkStatus();
    json(res, network.available ? 200 : 503, { status: network.available ? 'READY' : 'UNAVAILABLE', network }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/health/ready') {
    const dbOk = Boolean(getDb().prepare('SELECT 1 AS ok').get().ok);
    const failedJobs = Number(getDb().prepare("SELECT COUNT(*) AS n FROM scheduler_job WHERE enabled=1 AND last_status='FAILED'").get().n || 0);
    const ready = dbOk && failedJobs === 0;
    json(res, ready ? 200 : 503, { status: ready ? 'READY' : 'DEGRADED', database: dbOk, schedulerFailedJobs: failedJobs, offlineCriticalQueue: false, dataDir: path.basename(runtime.dataDir) }, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
