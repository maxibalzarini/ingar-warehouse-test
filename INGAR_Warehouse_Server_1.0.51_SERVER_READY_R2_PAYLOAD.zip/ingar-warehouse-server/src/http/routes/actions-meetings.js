'use strict';

const { getActionOptions, listActions, getAction, createAction, updateAction, addActionEvidence, closeAction, createActionFromIndicator, listActionAlerts, weeklyAgenda, monthlyAgenda, listMeetings, createMeeting, getMeeting, updateMeeting, addMeetingDecision, createActionFromDecision, resolveMeetingDecision, closeMeeting, correctClosedMeeting, meetingMinutes } = require('../../services/action-management-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/actions/options') {
    const auth = requireAuth(req, 'Actions.Read');
    json(res, 200, getActionOptions(auth.user), baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/actions') {
    const auth = requireAuth(req, 'Actions.Read');
    json(res, 200, listActions(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/actions') {
    const auth = requireAuth(req, 'Actions.Create'); requireCsrf(req, auth);
    json(res, 201, { action: createAction(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/actions/from-indicator') {
    const auth = requireAuth(req, 'Actions.Create'); requireCsrf(req, auth);
    json(res, 201, { action: createActionFromIndicator(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/actions/alerts') {
    const auth = requireAuth(req, 'Actions.Read');
    json(res, 200, listActionAlerts(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  let f30ActionParams = match(pathname, '/api/v1/actions/:id');
  if (f30ActionParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Actions.Read');
    json(res, 200, { action: getAction(f30ActionParams.id, auth.user) }, baseContext.correlationId); return true;
  }
  if (f30ActionParams && req.method === 'PUT') {
    const auth = requireAnyPermission(req, ['Actions.EditOwn','Actions.Assign']); requireCsrf(req, auth);
    json(res, 200, { action: updateAction(f30ActionParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30ActionParams = match(pathname, '/api/v1/actions/:id/evidence');
  if (f30ActionParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Actions.EditOwn'); requireCsrf(req, auth);
    json(res, 201, { evidence: addActionEvidence(f30ActionParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30ActionParams = match(pathname, '/api/v1/actions/:id/close');
  if (f30ActionParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Actions.Close'); requireCsrf(req, auth);
    json(res, 200, { action: closeAction(f30ActionParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/meetings/agenda/weekly') {
    const auth = requireAuth(req, 'Meetings.Create');
    json(res, 200, weeklyAgenda(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/meetings/agenda/monthly') {
    const auth = requireAuth(req, 'Meetings.Create');
    json(res, 200, monthlyAgenda(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/meetings') {
    const auth = requireAuth(req, 'Meetings.Minutes.Read');
    json(res, 200, listMeetings(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/meetings') {
    const auth = requireAuth(req, 'Meetings.Create'); requireCsrf(req, auth);
    json(res, 201, { meeting: createMeeting(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let f30MeetingParams = match(pathname, '/api/v1/meetings/:id');
  if (f30MeetingParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Meetings.Minutes.Read');
    json(res, 200, { meeting: getMeeting(f30MeetingParams.id, auth.user) }, baseContext.correlationId); return true;
  }
  if (f30MeetingParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Meetings.Create'); requireCsrf(req, auth);
    json(res, 200, { meeting: updateMeeting(f30MeetingParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/decisions');
  if (f30MeetingParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Meetings.Create'); requireCsrf(req, auth);
    json(res, 201, { decision: addMeetingDecision(f30MeetingParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/decisions/:decisionId/action');
  if (f30MeetingParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Actions.Create'); requireCsrf(req, auth);
    json(res, 201, { action: createActionFromDecision(f30MeetingParams.id, f30MeetingParams.decisionId, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/decisions/:decisionId/resolve');
  if (f30MeetingParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Meetings.Close'); requireCsrf(req, auth);
    json(res, 200, { decision: resolveMeetingDecision(f30MeetingParams.id, f30MeetingParams.decisionId, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/close');
  if (f30MeetingParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Meetings.Close'); requireCsrf(req, auth);
    json(res, 200, { meeting: closeMeeting(f30MeetingParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/corrections');
  if (f30MeetingParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Meetings.Close'); requireCsrf(req, auth);
    json(res, 201, { correction: correctClosedMeeting(f30MeetingParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  f30MeetingParams = match(pathname, '/api/v1/meetings/:id/minutes');
  if (f30MeetingParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Meetings.Minutes.Read');
    json(res, 200, { minutes: meetingMinutes(f30MeetingParams.id, auth.user) }, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
