'use strict';

const { json, text } = require('../http-utils');
const { normalizeRemoteAddress, isLoopbackAddress } = require('../../security/lan-access-control');
const deployment = require('../../services/startup-deployment-service');

function requireLoopback(baseContext) {
  const address = normalizeRemoteAddress(baseContext?.ip);
  if (!isLoopbackAddress(address)) {
    throw Object.assign(new Error('Esta operación sólo puede ejecutarse desde el servidor.'), { status: 403, code: 'LOCAL_ONLY' });
  }
}

async function handle(req, res, url, baseContext) {
  const { pathname } = url;

  if (req.method === 'GET' && pathname === '/api/v1/startup-deployment/status') {
    requireLoopback(baseContext);
    const status = await deployment.refresh({ forceManifest: false });
    json(res, 200, { deployment: status }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/startup-deployment/retry') {
    requireLoopback(baseContext);
    const status = await deployment.refresh({ forceManifest: true });
    json(res, 200, { deployment: status }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/startup-deployment/provision-firewall') {
    requireLoopback(baseContext);
    const result = await deployment.provisionFirewall();
    const status = await deployment.refresh({ forceManifest: false });
    json(res, result.ok ? 200 : 409, { result, deployment: status }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/startup-deployment/qr.svg') {
    requireLoopback(baseContext);
    text(res, 200, deployment.qrSvg(), 'image/svg+xml; charset=utf-8', baseContext.correlationId);
    return true;
  }

  return false;
}

module.exports = { handle };
