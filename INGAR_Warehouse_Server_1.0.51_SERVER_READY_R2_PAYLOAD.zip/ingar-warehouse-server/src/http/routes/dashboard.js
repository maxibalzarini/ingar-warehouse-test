'use strict';

const { getOperationalDashboard } = require('../../services/dashboard-service');
const { warehouseHome, controlCenter } = require('../../services/c3-experience-service');
const { canOpenScreen } = require('../../services/experience-service');
const { json } = require('../http-utils');
const { requireAuth } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;

  if (req.method === 'GET' && pathname === '/api/v1/dashboard/warehouse-workbench') {
    const auth = requireAuth(req, 'Warehouse.Operate');
    json(res, 200, warehouseHome(auth.user), baseContext.correlationId); return true;
  }


  if (req.method === 'GET' && pathname === '/api/v1/dashboard/control-center') {
    const auth = requireAuth(req, 'Auth.Self');
    if (!canOpenScreen(auth.user, '/control')) throw Object.assign(new Error('Este perfil no tiene acceso al Centro de Control.'), { status: 403, code: 'CONTROL_CENTER_FORBIDDEN' });
    json(res, 200, controlCenter(auth.user), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/dashboard') {
    const auth = requireAuth(req, 'Auth.Self');
    json(res, 200, getOperationalDashboard(auth.user), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
