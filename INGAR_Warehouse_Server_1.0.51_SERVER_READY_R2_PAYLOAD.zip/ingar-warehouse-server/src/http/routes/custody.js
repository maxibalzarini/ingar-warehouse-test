'use strict';

const { hasPermission } = require('../../services/permission-service');
const { listCustodiesPage, getCustody, getKitReturnDetail, declareReturn, extendCustody, receiveCustody, requestTransfer, decideTransfer, listTransfersPage, listEligiblePeople, custodyDocument, getReturnReceiptBytes } = require('../../services/custody-service');
const { runCustodyIntegrity, listCustodyIntegrityAnomalies } = require('../../services/custody-integrity-service');
const { quickReceiveCustody } = require('../../services/simple-warehouse-service');
const { quickReceiveSerializedCustody } = require('../../services/serialized-warehouse-service');
const { quickReceiveVehicleCustody, getVehicleReturnDetail, superviseVehicleReturn } = require('../../services/vehicle-warehouse-service');
const { json, text, binary, readJson } = require('../http-utils');
const { match, protectedDownload, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/custody-integrity-anomalies') {
    const auth = requireAuth(req, 'Warehouse.Operate');
    json(res, 200, { items: listCustodyIntegrityAnomalies(Object.fromEntries(searchParams), auth.user) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/custody-integrity/reconcile') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    json(res, 200, { result: runCustodyIntegrity(contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/custodies') {
    const auth = requireAnyPermission(req, ['Custody.ReadOwn', 'Custody.ReadAll']);
    json(res, 200, listCustodiesPage(Object.fromEntries(searchParams), auth.user, hasPermission(auth.user, 'Custody.ReadAll')), baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/custody-people') {
    requireAnyPermission(req, ['Custody.TransferOwn', 'Custody.TransferAny']);
    json(res, 200, { items: listEligiblePeople() }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/custody-transfers') {
    const auth = requireAnyPermission(req, ['Custody.TransferOwn', 'Custody.TransferAny']);
    json(res, 200, listTransfersPage(Object.fromEntries(searchParams), auth.user, hasPermission(auth.user, 'Custody.TransferAny')), baseContext.correlationId); return true;
  }
  let custodyParams = match(pathname, '/api/v1/custodies/:id/declare-return');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAnyPermission(req, ['Custody.ReturnOwn', 'Custody.ReturnAny']); requireCsrf(req, auth);
    json(res, 200, { custody: declareReturn(custodyParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Custody.ReturnAny')) }, baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/extend');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Custody.Extend'); requireCsrf(req, auth);
    json(res, 200, { custody: extendCustody(custodyParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/quick-receive');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickReceiveCustody(custodyParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/serialized-quick-receive');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickReceiveSerializedCustody(custodyParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/receive');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, receiveCustody(custodyParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/transfer');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAnyPermission(req, ['Custody.TransferOwn', 'Custody.TransferAny']); requireCsrf(req, auth);
    json(res, 201, { transfer: requestTransfer(custodyParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Custody.TransferAny')) }, baseContext.correlationId); return true;
  }

  custodyParams = match(pathname, '/api/v1/custodies/:id/return-receipt');
  if (custodyParams && req.method === 'GET') {
    const auth = requireAnyPermission(req, ['Custody.ReadOwn', 'Custody.ReadAll']);
    getCustody(custodyParams.id, auth.user, hasPermission(auth.user, 'Custody.ReadAll'));
    const receipt = getReturnReceiptBytes(require('../../db/database').getDb(), custodyParams.id);
    if (!receipt) throw Object.assign(new Error('La constancia PDF estará disponible después de la recepción física.'), { status: 404, code: 'RETURN_RECEIPT_NOT_AVAILABLE' });
    binary(res, 200, receipt.bytes, 'application/pdf', baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="${receipt.receiptNumber}.pdf"`,
      'X-Content-SHA256': receipt.sha256
    }); return true;
  }

  custodyParams = match(pathname, '/api/v1/custodies/:id/document');
  if (custodyParams && req.method === 'GET') {
    const auth = requireAnyPermission(req, ['Custody.ReadOwn', 'Custody.ReadAll']);
    protectedDownload(res, custodyDocument(custodyParams.id, auth.user, hasPermission(auth.user, 'Custody.ReadAll')), `custodia-${custodyParams.id}.html`, 'text/html; charset=utf-8', baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id');
  if (custodyParams && req.method === 'GET') {
    const auth = requireAnyPermission(req, ['Custody.ReadOwn', 'Custody.ReadAll']);
    json(res, 200, { custody: getCustody(custodyParams.id, auth.user, hasPermission(auth.user, 'Custody.ReadAll')) }, baseContext.correlationId); return true;
  }
  let transferParams = match(pathname, '/api/v1/custody-transfers/:id/accept');
  if (transferParams && req.method === 'POST') {
    const auth = requireAnyPermission(req, ['Custody.TransferOwn', 'Custody.TransferAny']); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, decideTransfer(transferParams.id, 'ACEPTADA', body, contextWithUser(baseContext, auth), hasPermission(auth.user, 'Custody.TransferAny')), baseContext.correlationId); return true;
  }
  transferParams = match(pathname, '/api/v1/custody-transfers/:id/reject');
  if (transferParams && req.method === 'POST') {
    const auth = requireAnyPermission(req, ['Custody.TransferOwn', 'Custody.TransferAny']); requireCsrf(req, auth);
    json(res, 200, decideTransfer(transferParams.id, 'RECHAZADA', await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Custody.TransferAny')), baseContext.correlationId); return true;
  }



  custodyParams = match(pathname, '/api/v1/custodies/:id/kit-detail');
  if (custodyParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Warehouse.Operate');
    json(res, 200, getKitReturnDetail(custodyParams.id, auth.user, 'Warehouse.Operate'), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/kit-receive');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Warehouse.Operate'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    body.kitComponents = body.components;
    json(res, 200, receiveCustody(custodyParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  custodyParams = match(pathname, '/api/v1/custodies/:id/vehicle-detail');
  if (custodyParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Warehouse.Operate');
    json(res, 200, getVehicleReturnDetail(custodyParams.id, auth.user, 'Warehouse.Operate'), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/vehicle-supervisor-review');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Vehicles.SuperviseReturn'); requireCsrf(req, auth);
    json(res, 200, superviseVehicleReturn(custodyParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  custodyParams = match(pathname, '/api/v1/custodies/:id/vehicle-receive');
  if (custodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Vehicles.ReceiveReturnKeys'); requireCsrf(req, auth);
    const body = await readJson(req); body.idempotencyKey = body.idempotencyKey || req.headers['idempotency-key'];
    json(res, 200, quickReceiveVehicleCustody(custodyParams.id, body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
