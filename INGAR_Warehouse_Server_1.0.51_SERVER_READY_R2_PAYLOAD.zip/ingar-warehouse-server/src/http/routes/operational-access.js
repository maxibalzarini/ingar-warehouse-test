'use strict';

const runtime = require('../../config/runtime');
const { authenticateSession, validateCsrf } = require('../../services/auth-service');
const { hasPermission } = require('../../services/permission-service');
const { canUseRequesterTablet } = require('../../config/operational-model');
const { permissionsFor } = require('../../config/operational-api-contract');
const { getReturnReceiptBytes } = require('../../services/custody-service');
const { getDb } = require('../../db/database');
const { technicianHome } = require('../../services/c3-experience-service');
const { listOwnPersonalKits } = require('../../services/kit-personal-service');
const { listMobileAccess, mobileAccessQrSvg } = require('../../services/mobile-access-service');
const { startMobileValidation, recordMobileValidation, getMobileValidation, getMobileValidationEvidence, attestPhysicalPhone } = require('../../services/mobile-validation-service');
const { getNetworkStatus } = require('../../services/network-service');
const { svg } = require('../../services/qr-code-service');
const {
  tabletBootstrap,
  tabletAvailability,
  tabletAssetPhoto,
  tabletRequests,
  tabletCustodies,
  tabletCreateRequest,
  tabletSaveSerializedRequestPhoto,
  tabletDeclareSerializedReturn,
  tabletSaveSerializedReturnPhoto,
  createVehicleRequest,
  saveVehicleRequestPhoto,
  declareVehicleReturn,
  saveVehicleReturnPhoto
} = require('../../services/tablet-terminal-service');
const { json, text, binary, readJson, parseCookies } = require('../http-utils');
const { match, protectedDownload, authenticate, requireAuth, requestBaseUrl, requireCsrf, contextWithUser } = require('../route-helpers');

const CANONICAL_PREFIX = '/api/v1/operation';
const LEGACY_PREFIX = '/api/v1/tablet';

function permissionDenied() {
  return Object.assign(new Error('Permiso insuficiente para esta operación.'), { status: 403, code: 'FORBIDDEN' });
}

function requireOperationalAuth(req, baseContext, permissions = ['Auth.Self']) {
  const auth = authenticateSession(parseCookies(req)[runtime.cookieName], baseContext);
  if (!auth) throw Object.assign(new Error('Autenticación requerida.'), { status: 401, code: 'AUTH_REQUIRED' });
  if (!canUseRequesterTablet(auth.user.roleCodes)) {
    throw Object.assign(new Error('Este perfil no tiene acceso a Mi operación.'), { status: 403, code: 'OPERATIONAL_INTERFACE_FORBIDDEN' });
  }
  if (auth.user.mustChangePassword && permissions.some((permission) => permission !== 'Auth.Self')) {
    throw Object.assign(new Error('Debe completar el acceso antes de continuar.'), { status: 403, code: 'PASSWORD_CHANGE_REQUIRED' });
  }
  if (!permissions.every((permission) => hasPermission(auth.user, permission))) throw permissionDenied();
  return auth;
}

function requireOperationalCsrf(req, auth) {
  const token = String(req.headers['x-csrf-token'] || '');
  if (!validateCsrf(auth, token)) {
    throw Object.assign(new Error('La sesión cambió. Volvé a ingresar.'), { status: 403, code: 'CSRF_INVALID' });
  }
}

function retireLegacyPedidosApi(req, res, pathname, correlationId) {
  if (!pathname.startsWith(`${LEGACY_PREFIX}/`) && pathname !== LEGACY_PREFIX) return false;
  const canonicalEndpoint = pathname.replace(LEGACY_PREFIX, CANONICAL_PREFIX);
  json(res, 410, {
    code: 'LEGACY_PEDIDOS_API_RETIRED',
    message: 'Pedidos fue absorbido por INGAR Warehouse. Use la API operativa canónica.',
    canonicalEndpoint,
    experienceRoute: '/mi-operacion',
    authenticationEndpoint: '/api/v1/auth/login'
  }, correlationId);
  return true;
}

async function handle(req, res, url, baseContext) {
  const { pathname } = url;

  if (retireLegacyPedidosApi(req, res, pathname, baseContext.correlationId)) return true;

  if (req.method === 'POST' && pathname === `${CANONICAL_PREFIX}/mobile-validation/ping`) {
    const auth = authenticate(req);
    const result = recordMobileValidation(await readJson(req), baseContext, auth?.user || null);
    json(res, 200, { validation: result }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === `${CANONICAL_PREFIX}/mobile-validation/start`) {
    const auth = requireAuth(req, 'Portal.Manage'); requireCsrf(req, auth);
    const body = await readJson(req);
    json(res, 201, { validation: startMobileValidation({ siteId: body.siteId, actorUserId: auth.user.id }) }, baseContext.correlationId);
    return true;
  }

  let mobileValidationParams = match(pathname, `${CANONICAL_PREFIX}/mobile-validation/:id/status`);
  if (mobileValidationParams && req.method === 'GET') {
    requireAuth(req, 'Portal.Manage');
    json(res, 200, { validation: getMobileValidation(mobileValidationParams.id) }, baseContext.correlationId);
    return true;
  }

  mobileValidationParams = match(pathname, `${CANONICAL_PREFIX}/mobile-validation/:id/svg`);
  if (mobileValidationParams && req.method === 'GET') {
    requireAuth(req, 'Portal.Manage');
    const validation = getMobileValidation(mobileValidationParams.id, { includeUrl: true });
    res.setHeader('Content-Disposition', `inline; filename="mobile-validation-${mobileValidationParams.id}.svg"`);
    text(res, 200, svg(validation.url), 'image/svg+xml; charset=utf-8', baseContext.correlationId);
    return true;
  }

  mobileValidationParams = match(pathname, `${CANONICAL_PREFIX}/mobile-validation/:id/evidence`);
  if (mobileValidationParams && req.method === 'GET') {
    requireAuth(req, 'Portal.Manage');
    protectedDownload(res, `${JSON.stringify(getMobileValidationEvidence(mobileValidationParams.id), null, 2)}\n`, `mobile-validation-${mobileValidationParams.id}.json`, 'application/json; charset=utf-8', baseContext.correlationId);
    return true;
  }

  mobileValidationParams = match(pathname, `${CANONICAL_PREFIX}/mobile-validation/:id/physical-phone-attestation`);
  if (mobileValidationParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Portal.Manage'); requireCsrf(req, auth);
    json(res, 200, { validation: attestPhysicalPhone(mobileValidationParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/mobile-access`) {
    requireAuth(req, 'Portal.Manage');
    const network = getNetworkStatus();
    json(res, 200, { items: network.available ? listMobileAccess(requestBaseUrl(req)) : [], network }, baseContext.correlationId);
    return true;
  }

  const mobileAccessParams = match(pathname, `${CANONICAL_PREFIX}/mobile-access/:siteId/qr`);
  if (mobileAccessParams && req.method === 'GET') {
    requireAuth(req, 'Portal.Manage');
    const result = mobileAccessQrSvg(mobileAccessParams.siteId, requestBaseUrl(req));
    res.setHeader('Content-Disposition', `inline; filename="mi-operacion-${mobileAccessParams.siteId}.svg"`);
    text(res, 200, result.svg, 'image/svg+xml; charset=utf-8', baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/home`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('BOOTSTRAP_READ'));
    json(res, 200, technicianHome(auth.user), baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/bootstrap`) {
    requireOperationalAuth(req, baseContext, permissionsFor('BOOTSTRAP_READ'));
    json(res, 200, tabletBootstrap(), baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/availability`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('AVAILABILITY_READ'));
    json(res, 200, tabletAvailability(url.searchParams.get('flow'), Object.fromEntries(url.searchParams), auth.user), baseContext.correlationId);
    return true;
  }

  let assetPhotoParams = match(pathname, `${CANONICAL_PREFIX}/assets/:id/photo`);
  if (assetPhotoParams && req.method === 'GET') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('ASSET_PHOTO_READ'));
    const photo = tabletAssetPhoto(assetPhotoParams.id, auth.user);
    binary(res, 200, photo.bytes, photo.metadata.mime_type, baseContext.correlationId, { 'Cache-Control': 'private, max-age=300' });
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/requests`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('REQUESTS_READ_OWN'));
    json(res, 200, tabletRequests(Object.fromEntries(url.searchParams), auth.user), baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/custodies`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('CUSTODIES_READ_OWN'));
    json(res, 200, tabletCustodies(Object.fromEntries(url.searchParams), auth.user), baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === `${CANONICAL_PREFIX}/kits`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('KITS_READ'));
    json(res, 200, { items: listOwnPersonalKits(auth.user.personId) }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === `${CANONICAL_PREFIX}/requests`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('REQUEST_CREATE'));
    requireOperationalCsrf(req, auth);
    const body = await readJson(req);
    body.clientRequestId = body.clientRequestId || req.headers['idempotency-key'];
    json(res, 201, tabletCreateRequest(body, { ...baseContext, user: auth.user }), baseContext.correlationId);
    return true;
  }

  let params = match(pathname, `${CANONICAL_PREFIX}/requests/:id/photo`);
  if (params && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('REQUEST_PHOTO_WRITE'));
    requireOperationalCsrf(req, auth);
    json(res, 201, { evidence: tabletSaveSerializedRequestPhoto(params.id, await readJson(req), { ...baseContext, user: auth.user }) }, baseContext.correlationId);
    return true;
  }

  params = match(pathname, `${CANONICAL_PREFIX}/custodies/:id/return-receipt`);
  if (params && req.method === 'GET') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('RETURN_RECEIPT_READ'));
    const db = getDb();
    const ownership = db.prepare('SELECT person_id FROM custody WHERE id=?').get(params.id);
    if (!ownership) throw Object.assign(new Error('Custodia no encontrada.'), { status: 404, code: 'CUSTODY_NOT_FOUND' });
    if (ownership.person_id !== auth.user.personId) throw Object.assign(new Error('La constancia no pertenece a este usuario.'), { status: 403, code: 'CUSTODY_FORBIDDEN' });
    const receipt = getReturnReceiptBytes(db, params.id);
    if (!receipt) throw Object.assign(new Error('La constancia PDF estará disponible cuando el pañol confirme la recepción.'), { status: 404, code: 'RETURN_RECEIPT_NOT_AVAILABLE' });
    binary(res, 200, receipt.bytes, 'application/pdf', baseContext.correlationId, {
      'Content-Disposition': `attachment; filename="${receipt.receiptNumber}.pdf"`,
      'X-Content-SHA256': receipt.sha256
    });
    return true;
  }

  params = match(pathname, `${CANONICAL_PREFIX}/custodies/:id/declare-return`);
  if (params && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('RETURN_DECLARE'));
    requireOperationalCsrf(req, auth);
    json(res, 200, { custody: tabletDeclareSerializedReturn(params.id, await readJson(req), { ...baseContext, user: auth.user }) }, baseContext.correlationId);
    return true;
  }

  params = match(pathname, `${CANONICAL_PREFIX}/custodies/:id/return-photo`);
  if (params && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('RETURN_PHOTO_WRITE'));
    requireOperationalCsrf(req, auth);
    json(res, 201, { evidence: tabletSaveSerializedReturnPhoto(params.id, await readJson(req), { ...baseContext, user: auth.user }) }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === `${CANONICAL_PREFIX}/vehicle-requests`) {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('VEHICLE_REQUEST_CREATE'));
    requireOperationalCsrf(req, auth);
    const body = await readJson(req);
    body.clientRequestId = body.clientRequestId || req.headers['idempotency-key'];
    json(res, 201, createVehicleRequest(body, { ...baseContext, user: auth.user }), baseContext.correlationId);
    return true;
  }

  let vehicleParams = match(pathname, `${CANONICAL_PREFIX}/vehicle-requests/:id/photo`);
  if (vehicleParams && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('VEHICLE_REQUEST_PHOTO_WRITE'));
    requireOperationalCsrf(req, auth);
    json(res, 201, { evidence: saveVehicleRequestPhoto(vehicleParams.id, await readJson(req), { ...baseContext, user: auth.user }) }, baseContext.correlationId);
    return true;
  }

  vehicleParams = match(pathname, `${CANONICAL_PREFIX}/vehicle-custodies/:id/declare-return`);
  if (vehicleParams && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('VEHICLE_RETURN_DECLARE'));
    requireOperationalCsrf(req, auth);
    json(res, 200, declareVehicleReturn(vehicleParams.id, await readJson(req), { ...baseContext, user: auth.user }), baseContext.correlationId);
    return true;
  }

  vehicleParams = match(pathname, `${CANONICAL_PREFIX}/vehicle-custodies/:id/return-photo`);
  if (vehicleParams && req.method === 'POST') {
    const auth = requireOperationalAuth(req, baseContext, permissionsFor('VEHICLE_RETURN_PHOTO_WRITE'));
    requireOperationalCsrf(req, auth);
    json(res, 201, { evidence: saveVehicleReturnPhoto(vehicleParams.id, await readJson(req), { ...baseContext, user: auth.user }) }, baseContext.correlationId);
    return true;
  }

  return false;
}

module.exports = {
  handle,
  requireOperationalAuth,
  requireOperationalCsrf,
  CANONICAL_PREFIX,
  LEGACY_PREFIX
};
