'use strict';

const { hasPermission } = require('../../services/permission-service');
const { saveEvidenceDataUrl, saveImageDataUrl, getEvidence } = require('../../services/evidence-service');
const { json, text, readJson } = require('../http-utils');
const { match, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  let params;
  if (req.method === 'POST' && pathname === '/api/v1/evidence/files') {
    const auth = requireAuth(req, 'Incident.Evidence'); requireCsrf(req, auth);
    json(res, 201, { evidence: saveEvidenceDataUrl(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/evidence/images') {
    const auth = requireAuth(req, 'Users.Update'); requireCsrf(req, auth);
    json(res, 201, { evidence: saveImageDataUrl(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  params = match(pathname, '/api/v1/evidence/:id');
  if (params && req.method === 'GET') {
    const auth = requireAuth(req);
    const ownPhoto = require('../../db/database').getDb().prepare(`SELECT 1 FROM file_evidence WHERE id=? AND owner_type='PERSON' AND owner_id=? AND purpose='PHOTO' AND lifecycle_state='ACTIVE'`).get(params.id, auth.user.personId);
    if (!ownPhoto && !hasPermission(auth.user, 'Users.Read') && !hasPermission(auth.user, 'Config.Read') && !hasPermission(auth.user, 'Assets.Read') && !hasPermission(auth.user, 'Import.Read') && !hasPermission(auth.user, 'Incident.Read') && !hasPermission(auth.user, 'Incident.Evidence') && !hasPermission(auth.user, 'Actions.Read')) {
      throw Object.assign(new Error('Permiso insuficiente.'), { status: 403, code: 'FORBIDDEN' });
    }
    const evidence = getEvidence(params.id, auth.user);
    if (!evidence) throw Object.assign(new Error('Evidencia no encontrada.'), { status: 404, code: 'EVIDENCE_NOT_FOUND' });
    res.setHeader('Content-Length', evidence.bytes.length);
    text(res, 200, evidence.bytes, evidence.metadata.mime_type, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
