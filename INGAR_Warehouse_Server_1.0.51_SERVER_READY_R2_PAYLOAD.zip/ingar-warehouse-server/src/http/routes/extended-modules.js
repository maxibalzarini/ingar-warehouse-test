'use strict';

const { hasPermission } = require('../../services/permission-service');
const { createVehicle, updateVehicle, createKit } = require('../../services/specialized-asset-registration-service');
const { listAssets } = require('../../services/asset-service');
const { getVehicleProfile, saveVehicleProfile, listVehicleAuthorizations, createVehicleAuthorization, registerVehicleOperation, listVehicleOperations, getKitDefinition, saveKitDefinition, listKitComponentCandidates, validateKitAvailability, issueKitComponents, returnKitComponents, listKitCustodyComponents, listStock, createStockLot, createStockMovement, listStockMovements, listInventoryCounts, createInventoryCount, inventoryCountDetail, openInventoryCount, recordInventoryCountItem, reconcileInventoryItem, closeInventoryCount, listInventoryTransfers, createInventoryTransfer, transferDetail, dispatchInventoryTransfer, receiveInventoryTransfer, cancelInventoryTransfer } = require('../../services/extended-modules-service');
const { listEligibleMechanics, assignKitToPerson, unassignKit, getKitAssignmentDetail, createKitInventoryControl, listKitInventoryControls } = require('../../services/kit-personal-service');
const { transferSingleAssetLocation } = require('../../services/location-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/vehicles') {
    const auth = requireAuth(req, 'Vehicles.Read');
    json(res, 200, { items: listAssets({ nature: 'VEHICULO', limit: searchParams.get('limit'), offset: searchParams.get('offset'), active: searchParams.get('active') === null ? undefined : searchParams.get('active') === 'true' }, auth.user, 'Vehicles.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/vehicles') {
    const auth = requireAuth(req, 'Assets.Create'); requireCsrf(req, auth);
    json(res, 201, createVehicle(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/kits') {
    const auth = requireAuth(req, 'Kits.Manage'); requireCsrf(req, auth);
    json(res, 201, createKit(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  let vehicleParams;

  vehicleParams = match(pathname, '/api/v1/vehicles/:id');
  if (vehicleParams && req.method === 'PATCH') {
    const auth = requireAuth(req, 'Vehicles.Manage'); requireCsrf(req, auth);
    json(res, 200, updateVehicle(vehicleParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  vehicleParams = match(pathname, '/api/v1/vehicles/:id/move');
  if (vehicleParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Vehicles.Manage'); requireCsrf(req, auth);
    json(res, 200, transferSingleAssetLocation(vehicleParams.id, await readJson(req), contextWithUser(baseContext, auth), { permission: 'Vehicles.Manage', requiredNature: 'VEHICULO' }), baseContext.correlationId); return true;
  }

  vehicleParams = match(pathname, '/api/v1/vehicles/:id/profile');
  if (vehicleParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Vehicles.Read'); json(res, 200, { profile: getVehicleProfile(vehicleParams.id, auth.user, 'Vehicles.Read') }, baseContext.correlationId); return true;
  }
  if (vehicleParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Vehicles.Manage'); requireCsrf(req, auth);
    json(res, 200, { profile: saveVehicleProfile(vehicleParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  vehicleParams = match(pathname, '/api/v1/vehicles/:id/operations');
  if (vehicleParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Vehicles.Read'); json(res, 200, { items: listVehicleOperations(vehicleParams.id, searchParams.get('limit'), auth.user, 'Vehicles.Read') }, baseContext.correlationId); return true;
  }
  if (vehicleParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Vehicles.Operate'); requireCsrf(req, auth);
    json(res, 201, { operation: registerVehicleOperation(vehicleParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/vehicle-authorizations') {
    const auth = requireAuth(req, 'Vehicles.Read'); json(res, 200, { items: listVehicleAuthorizations(Object.fromEntries(searchParams), auth.user, 'Vehicles.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/vehicle-authorizations') {
    const auth = requireAuth(req, 'Vehicles.Manage'); requireCsrf(req, auth);
    json(res, 201, { authorization: createVehicleAuthorization(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  // FASE 12 — KITS PERSONALES POR MECÁNICO
  if (req.method === 'GET' && pathname === '/api/v1/kits/mechanics') {
    requireAuth(req, 'Kits.Manage');
    json(res, 200, { items: listEligibleMechanics() }, baseContext.correlationId); return true;
  }
  let personalKitParams = match(pathname, '/api/v1/kits/:id/assignment');
  if (personalKitParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Kits.Read');
    json(res, 200, getKitAssignmentDetail(personalKitParams.id, auth.user, 'Kits.Read'), baseContext.correlationId); return true;
  }
  personalKitParams = match(pathname, '/api/v1/kits/:id/assign');
  if (personalKitParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Kits.Manage'); requireCsrf(req, auth);
    json(res, 200, { assignment: assignKitToPerson(personalKitParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  personalKitParams = match(pathname, '/api/v1/kits/:id/unassign');
  if (personalKitParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Kits.Manage'); requireCsrf(req, auth);
    json(res, 200, { assignment: unassignKit(personalKitParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  personalKitParams = match(pathname, '/api/v1/kits/:id/inventory-control');
  if (personalKitParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Kits.Read'); requireCsrf(req, auth);
    json(res, 201, createKitInventoryControl(personalKitParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  personalKitParams = match(pathname, '/api/v1/kits/:id/inventory-controls');
  if (personalKitParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Kits.Read');
    json(res, 200, { items: listKitInventoryControls(personalKitParams.id, auth.user) }, baseContext.correlationId); return true;
  }

  // F7.1 — candidatos de composición consultados en DB en cada búsqueda.
  if (req.method === 'GET' && pathname === '/api/v1/kits/component-candidates') {
    const auth = requireAuth(req, 'Kits.Read');
    json(res, 200, { items: listKitComponentCandidates({
      search: searchParams.get('search'),
      includeIds: searchParams.get('includeIds'),
      limit: searchParams.get('limit')
    }, auth.user, 'Kits.Read') }, baseContext.correlationId); return true;
  }

  // FASE 10/12 — KITS
  let kitParams = match(pathname, '/api/v1/kits/:id/availability');
  if (kitParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Kits.Read'); json(res, 200, validateKitAvailability(kitParams.id, auth.user, 'Kits.Read'), baseContext.correlationId); return true;
  }
  kitParams = match(pathname, '/api/v1/kits/:id/issue');
  if (kitParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Kits.Operate'); requireCsrf(req, auth);
    json(res, 201, issueKitComponents(kitParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  kitParams = match(pathname, '/api/v1/kits/:id');
  if (kitParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Kits.Read'); json(res, 200, getKitDefinition(kitParams.id, auth.user, 'Kits.Read'), baseContext.correlationId); return true;
  }
  if (kitParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Kits.Manage'); requireCsrf(req, auth);
    json(res, 200, saveKitDefinition(kitParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  let kitCustodyParams = match(pathname, '/api/v1/kit-custodies/:id/components');
  if (kitCustodyParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Kits.Read'); json(res, 200, { items: listKitCustodyComponents(kitCustodyParams.id, auth.user, 'Kits.Read') }, baseContext.correlationId); return true;
  }
  kitCustodyParams = match(pathname, '/api/v1/kit-custodies/:id/return');
  if (kitCustodyParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Kits.Operate'); requireCsrf(req, auth);
    json(res, 200, returnKitComponents(kitCustodyParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  // FASE 10 — STOCK Y CONSUMIBLES
  if (req.method === 'GET' && pathname === '/api/v1/stock') {
    const auth = requireAuth(req, 'Stock.Read'); json(res, 200, { items: listStock(Object.fromEntries(searchParams), auth.user, 'Stock.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/stock/lots') {
    const auth = requireAuth(req, 'Stock.Operate'); requireCsrf(req, auth);
    json(res, 201, { lot: createStockLot(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/stock/movements') {
    const auth = requireAuth(req, 'Stock.Read'); json(res, 200, { items: listStockMovements(Object.fromEntries(searchParams), auth.user, 'Stock.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/stock/movements') {
    const auth = requireAnyPermission(req, ['Stock.Operate', 'Stock.Adjust']); requireCsrf(req, auth);
    const body = await readJson(req); const movementType = String(body.movementType || '').toUpperCase();
    if (movementType.startsWith('AJUSTE_') && !hasPermission(auth.user, 'Stock.Adjust')) throw Object.assign(new Error('El ajuste requiere permiso específico.'), { status: 403, code: 'STOCK_ADJUST_FORBIDDEN' });
    json(res, 201, createStockMovement(body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  // FASE 10 — INVENTARIOS FÍSICOS
  if (req.method === 'GET' && pathname === '/api/v1/inventory-counts') {
    const auth = requireAuth(req, 'Inventory.Read'); json(res, 200, { items: listInventoryCounts(Object.fromEntries(searchParams), auth.user, 'Inventory.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/inventory-counts') {
    const auth = requireAuth(req, 'Inventory.Execute'); requireCsrf(req, auth);
    json(res, 201, { count: createInventoryCount(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let inventoryParams = match(pathname, '/api/v1/inventory-counts/:id/open');
  if (inventoryParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Inventory.Execute'); requireCsrf(req, auth);
    json(res, 200, { count: openInventoryCount(inventoryParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryParams = match(pathname, '/api/v1/inventory-counts/:id/close');
  if (inventoryParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Inventory.Close'); requireCsrf(req, auth);
    json(res, 200, { count: closeInventoryCount(inventoryParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryParams = match(pathname, '/api/v1/inventory-counts/:id');
  if (inventoryParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Inventory.Read'); json(res, 200, { count: inventoryCountDetail(inventoryParams.id, undefined, auth.user, 'Inventory.Read') }, baseContext.correlationId); return true;
  }
  let inventoryItemParams = match(pathname, '/api/v1/inventory-count-items/:id/count');
  if (inventoryItemParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Inventory.Execute'); requireCsrf(req, auth);
    json(res, 200, { item: recordInventoryCountItem(inventoryItemParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryItemParams = match(pathname, '/api/v1/inventory-count-items/:id/reconcile');
  if (inventoryItemParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Inventory.Reconcile'); requireCsrf(req, auth);
    json(res, 200, { item: reconcileInventoryItem(inventoryItemParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Inventory.Adjust')) }, baseContext.correlationId); return true;
  }

  // FASE 10 — TRANSFERENCIAS ENTRE UBICACIONES
  if (req.method === 'GET' && pathname === '/api/v1/inventory-transfers') {
    const auth = requireAuth(req, 'Transfers.Read'); json(res, 200, { items: listInventoryTransfers(Object.fromEntries(searchParams), auth.user, 'Transfers.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/inventory-transfers') {
    const auth = requireAuth(req, 'Transfers.Create'); requireCsrf(req, auth);
    json(res, 201, { transfer: createInventoryTransfer(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let inventoryTransferParams = match(pathname, '/api/v1/inventory-transfers/:id/dispatch');
  if (inventoryTransferParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Transfers.Dispatch'); requireCsrf(req, auth);
    json(res, 200, { transfer: dispatchInventoryTransfer(inventoryTransferParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryTransferParams = match(pathname, '/api/v1/inventory-transfers/:id/receive');
  if (inventoryTransferParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Transfers.Receive'); requireCsrf(req, auth);
    json(res, 200, { transfer: receiveInventoryTransfer(inventoryTransferParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryTransferParams = match(pathname, '/api/v1/inventory-transfers/:id/cancel');
  if (inventoryTransferParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Transfers.Cancel'); requireCsrf(req, auth);
    json(res, 200, { transfer: cancelInventoryTransfer(inventoryTransferParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  inventoryTransferParams = match(pathname, '/api/v1/inventory-transfers/:id');
  if (inventoryTransferParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Transfers.Read'); json(res, 200, { transfer: transferDetail(inventoryTransferParams.id, undefined, auth.user, 'Transfers.Read') }, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
