'use strict';

const { json, text, readJson } = require('../http-utils');
const { normalizeRemoteAddress, isLoopbackAddress } = require('../../security/lan-access-control');
const validation = require('../../services/installation-validation-service');

function requireLoopback(baseContext) {
  const address = normalizeRemoteAddress(baseContext?.ip);
  if (!isLoopbackAddress(address)) {
    throw Object.assign(new Error('Esta operación sólo puede ejecutarse desde la computadora del servidor.'), { status: 403, code: 'LOCAL_ONLY' });
  }
}

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;

  if (req.method === 'GET' && pathname === '/api/v1/installation-validation/status') {
    requireLoopback(baseContext);
    json(res, 200, { validation: validation.getStatus({ observeLocal: true }) }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/installation-validation/restart') {
    requireLoopback(baseContext);
    json(res, 200, { validation: validation.restart() }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/installation-validation/qr.svg') {
    requireLoopback(baseContext);
    text(res, 200, validation.qrSvg(), 'image/svg+xml; charset=utf-8', baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/installation-validation/evidence') {
    requireLoopback(baseContext);
    json(res, 200, { evidence: validation.getEvidenceSummary() }, baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/installation-validation/connect') {
    json(res, 200, validation.connectMobile(await readJson(req), baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/installation-validation/test-order') {
    json(res, 201, validation.submitTestOrder(await readJson(req), baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/installation-validation/ack-received') {
    json(res, 200, validation.confirmPhoneReceivedAck(await readJson(req), baseContext), baseContext.correlationId);
    return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/installation-validation/mobile-status') {
    json(res, 200, { validation: validation.getMobileStatus(searchParams.get('token'), baseContext) }, baseContext.correlationId);
    return true;
  }

  return false;
}

module.exports = { handle };
