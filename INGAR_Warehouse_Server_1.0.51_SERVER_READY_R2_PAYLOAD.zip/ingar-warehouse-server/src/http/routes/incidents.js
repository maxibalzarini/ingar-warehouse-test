'use strict';

const { hasPermission } = require('../../services/permission-service');
const { listIncidentsPage, getIncident, openIncident, startInvestigation, addIncidentNote, attachIncidentEvidence, addInvestigationAction, updateInvestigationAction, resolveIncident, closeIncident, reopenIncident, listBlocksPage, getBlock, createBlock, liftBlock, requestBlockException, decideBlockException, listBlockExceptionsPage, incidentReportCsv } = require('../../services/incident-service');
const { json, text, readJson } = require('../http-utils');
const { match, protectedDownload, requireAuth, requireAnyPermission, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/incidents/export') {
    const auth = requireAuth(req, 'Incident.Export');
    protectedDownload(res, incidentReportCsv(Object.fromEntries(searchParams), auth.user), `incidentes-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv; charset=utf-8', baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/incidents') {
    const auth = requireAuth(req, 'Incident.Read');
    json(res, 200, listIncidentsPage(Object.fromEntries(searchParams), auth.user), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/incidents') {
    const auth = requireAuth(req, 'Incident.Create'); requireCsrf(req, auth);
    const body = await readJson(req); body.clientIncidentId = body.clientIncidentId || req.headers['idempotency-key'] || null;
    json(res, 201, openIncident(body, contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  let incidentParams = match(pathname, '/api/v1/incidents/:id/start-investigation');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Investigate'); requireCsrf(req, auth);
    json(res, 200, { incident: startInvestigation(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/notes');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Investigate'); requireCsrf(req, auth);
    json(res, 201, { incident: addIncidentNote(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/evidence');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Evidence'); requireCsrf(req, auth);
    json(res, 201, { incident: attachIncidentEvidence(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/actions');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Investigate'); requireCsrf(req, auth);
    json(res, 201, { action: addInvestigationAction(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/resolve');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Resolve'); requireCsrf(req, auth);
    json(res, 200, { incident: resolveIncident(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/close');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Close'); requireCsrf(req, auth);
    json(res, 200, { incident: closeIncident(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id/reopen');
  if (incidentParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Resolve'); requireCsrf(req, auth);
    json(res, 200, { incident: reopenIncident(incidentParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  incidentParams = match(pathname, '/api/v1/incidents/:id');
  if (incidentParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Incident.Read');
    json(res, 200, { incident: getIncident(incidentParams.id, auth.user) }, baseContext.correlationId); return true;
  }
  let actionParams = match(pathname, '/api/v1/incident-actions/:id/update');
  if (actionParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Incident.Investigate'); requireCsrf(req, auth);
    json(res, 200, { action: updateInvestigationAction(actionParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/blocks') {
    const auth = requireAuth(req, 'Blocks.Read');
    json(res, 200, listBlocksPage(Object.fromEntries(searchParams), auth.user), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/blocks') {
    const auth = requireAuth(req, 'Blocks.Manage'); requireCsrf(req, auth);
    json(res, 201, { block: createBlock(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let blockParams = match(pathname, '/api/v1/blocks/:id/lift');
  if (blockParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Blocks.Manage'); requireCsrf(req, auth);
    json(res, 200, { block: liftBlock(blockParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  blockParams = match(pathname, '/api/v1/blocks/:id/exceptions');
  if (blockParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Blocks.Exception.Request'); requireCsrf(req, auth);
    json(res, 201, { exception: requestBlockException(blockParams.id, await readJson(req), contextWithUser(baseContext, auth), hasPermission(auth.user, 'Blocks.Manage')) }, baseContext.correlationId); return true;
  }
  blockParams = match(pathname, '/api/v1/blocks/:id');
  if (blockParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Blocks.Read');
    json(res, 200, { block: getBlock(blockParams.id, auth.user) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/block-exceptions') {
    const auth = requireAnyPermission(req, ['Blocks.Exception.Request', 'Blocks.Exception.Decide']);
    json(res, 200, listBlockExceptionsPage(Object.fromEntries(searchParams), auth.user, hasPermission(auth.user, 'Blocks.Exception.Decide')), baseContext.correlationId); return true;
  }
  let exceptionParams = match(pathname, '/api/v1/block-exceptions/:id/approve');
  if (exceptionParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Blocks.Exception.Decide'); requireCsrf(req, auth);
    json(res, 200, { exception: decideBlockException(exceptionParams.id, 'APROBADA', await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  exceptionParams = match(pathname, '/api/v1/block-exceptions/:id/reject');
  if (exceptionParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Blocks.Exception.Decide'); requireCsrf(req, auth);
    json(res, 200, { exception: decideBlockException(exceptionParams.id, 'RECHAZADA', await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  // FASE 10 — VEHÍCULOS
  return false;
}

module.exports = { handle };
