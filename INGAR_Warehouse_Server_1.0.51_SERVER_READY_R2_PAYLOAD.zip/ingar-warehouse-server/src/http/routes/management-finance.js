'use strict';

const { getManagementModel, getManagementDashboard, evaluateManagementIndicators, upsertManagementTarget, listManagementSnapshots } = require('../../services/management-service');
const { listManagementEntities, getManagementProfile } = require('../../services/management-profile-service');
const { getFinanceOptions, getFinanceSummary, listBudgets, createBudget, updateBudget, listCosts, createCost, reverseCost, listPurchases, createPurchase, updatePurchase, executePurchase, setStockPrice, consumableCosts, upsertAssetEconomicProfile, getRepairReplaceAnalysis } = require('../../services/finance-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/management/model') {
    const auth = requireAuth(req, 'Management.Read');
    json(res, 200, getManagementModel(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/management/dashboard') {
    const auth = requireAuth(req, 'Management.Read');
    json(res, 200, getManagementDashboard(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'POST' && pathname === '/api/v1/management/evaluate') {
    const auth = requireAuth(req, 'Management.Evaluate'); requireCsrf(req, auth);
    json(res, 200, evaluateManagementIndicators(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  const managementTargetParams = match(pathname, '/api/v1/management/targets/:code');
  if (managementTargetParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Management.Configure'); requireCsrf(req, auth);
    json(res, 200, upsertManagementTarget(managementTargetParams.code, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/management/snapshots') {
    const auth = requireAuth(req, 'Management.Read');
    json(res, 200, listManagementSnapshots(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/management/entities') {
    const auth = requireAuth(req, 'Management.Read');
    json(res, 200, listManagementEntities(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/management/profile') {
    const auth = requireAuth(req, 'Management.Read');
    json(res, 200, getManagementProfile(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/finance/options') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, getFinanceOptions(auth.user), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/finance/summary') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, getFinanceSummary(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/finance/budgets') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, listBudgets(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/finance/budgets') {
    const auth = requireAuth(req, 'Finance.ConfigureBudget'); requireCsrf(req, auth);
    json(res, 201, { budget: createBudget(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let financeParams = match(pathname, '/api/v1/finance/budgets/:id');
  if (financeParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Finance.ConfigureBudget'); requireCsrf(req, auth);
    json(res, 200, { budget: updateBudget(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/finance/costs') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, listCosts(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/finance/costs') {
    const auth = requireAuth(req, 'Finance.RecordCost'); requireCsrf(req, auth);
    json(res, 201, { cost: createCost(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  financeParams = match(pathname, '/api/v1/finance/costs/:id/reverse');
  if (financeParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Finance.RecordCost'); requireCsrf(req, auth);
    json(res, 200, reverseCost(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  if (req.method === 'GET' && pathname === '/api/v1/finance/purchases') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, listPurchases(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/finance/purchases') {
    const auth = requireAuth(req, 'Finance.Commit'); requireCsrf(req, auth);
    json(res, 201, { purchase: createPurchase(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  financeParams = match(pathname, '/api/v1/finance/purchases/:id');
  if (financeParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Finance.Commit'); requireCsrf(req, auth);
    json(res, 200, { purchase: updatePurchase(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  financeParams = match(pathname, '/api/v1/finance/purchases/:id/execute');
  if (financeParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Finance.Commit'); requireCsrf(req, auth);
    json(res, 200, executePurchase(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }

  financeParams = match(pathname, '/api/v1/finance/stock-lots/:id/price');
  if (financeParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Finance.RecordCost'); requireCsrf(req, auth);
    json(res, 200, { price: setStockPrice(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/finance/consumables') {
    const auth = requireAuth(req, 'Finance.Read');
    json(res, 200, consumableCosts(auth.user, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  financeParams = match(pathname, '/api/v1/finance/assets/:id/profile');
  if (financeParams && req.method === 'PUT') {
    const auth = requireAuth(req, 'Finance.AssetAnalysis'); requireCsrf(req, auth);
    json(res, 200, { profile: upsertAssetEconomicProfile(financeParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  financeParams = match(pathname, '/api/v1/finance/assets/:id/repair-replace');
  if (financeParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Finance.AssetAnalysis');
    json(res, 200, getRepairReplaceAnalysis(auth.user, financeParams.id, Object.fromEntries(searchParams.entries())), baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
