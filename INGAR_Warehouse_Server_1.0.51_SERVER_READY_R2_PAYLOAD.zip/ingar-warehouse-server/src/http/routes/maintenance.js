'use strict';

const { getDb } = require('../../db/database');
const { listMaintenancePlans, getMaintenancePlan, createMaintenancePlan, updateMaintenancePlan, listMaintenanceOrders, getMaintenanceOrder, createMaintenanceOrder, startMaintenanceOrder, completeMaintenanceOrder, cancelMaintenanceOrder } = require('../../services/maintenance-service');
const { json, readJson } = require('../http-utils');
const { match, requireAuth, requireCsrf, contextWithUser } = require('../route-helpers');

async function handle(req, res, url, baseContext) {
  const { pathname, searchParams } = url;
  if (req.method === 'GET' && pathname === '/api/v1/maintenance/plans') {
    const auth = requireAuth(req, 'Maintenance.Read');
    json(res, 200, { items: listMaintenancePlans({ assetId: searchParams.get('assetId'), active: searchParams.has('active') ? searchParams.get('active') : undefined, triggerType: searchParams.get('triggerType'), limit: searchParams.get('limit') }, auth.user, 'Maintenance.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/maintenance/plans') {
    const auth = requireAuth(req, 'Maintenance.Manage'); requireCsrf(req, auth);
    json(res, 201, { plan: createMaintenancePlan(await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  let maintenanceParams = match(pathname, '/api/v1/maintenance/plans/:id');
  if (maintenanceParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Maintenance.Read'); json(res, 200, { plan: getMaintenancePlan(maintenanceParams.id, getDb(), auth.user, 'Maintenance.Read') }, baseContext.correlationId); return true;
  }
  if (maintenanceParams && (req.method === 'PATCH' || req.method === 'PUT')) {
    const auth = requireAuth(req, 'Maintenance.Manage'); requireCsrf(req, auth);
    json(res, 200, { plan: updateMaintenancePlan(maintenanceParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  if (req.method === 'GET' && pathname === '/api/v1/maintenance/orders') {
    const auth = requireAuth(req, 'Maintenance.Read');
    json(res, 200, { items: listMaintenanceOrders(Object.fromEntries(searchParams), auth.user, 'Maintenance.Read') }, baseContext.correlationId); return true;
  }
  if (req.method === 'POST' && pathname === '/api/v1/maintenance/orders') {
    const auth = requireAuth(req, 'Maintenance.Manage'); requireCsrf(req, auth);
    json(res, 201, createMaintenanceOrder(await readJson(req), contextWithUser(baseContext, auth)), baseContext.correlationId); return true;
  }
  maintenanceParams = match(pathname, '/api/v1/maintenance/orders/:id/start');
  if (maintenanceParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Maintenance.Execute'); requireCsrf(req, auth);
    json(res, 200, { order: startMaintenanceOrder(maintenanceParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  maintenanceParams = match(pathname, '/api/v1/maintenance/orders/:id/complete');
  if (maintenanceParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Maintenance.Complete'); requireCsrf(req, auth);
    json(res, 200, { order: completeMaintenanceOrder(maintenanceParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  maintenanceParams = match(pathname, '/api/v1/maintenance/orders/:id/cancel');
  if (maintenanceParams && req.method === 'POST') {
    const auth = requireAuth(req, 'Maintenance.Complete'); requireCsrf(req, auth);
    json(res, 200, { order: cancelMaintenanceOrder(maintenanceParams.id, await readJson(req), contextWithUser(baseContext, auth)) }, baseContext.correlationId); return true;
  }
  maintenanceParams = match(pathname, '/api/v1/maintenance/orders/:id');
  if (maintenanceParams && req.method === 'GET') {
    const auth = requireAuth(req, 'Maintenance.Read'); json(res, 200, { order: getMaintenanceOrder(maintenanceParams.id, getDb(), auth.user, 'Maintenance.Read') }, baseContext.correlationId); return true;
  }

  return false;
}

module.exports = { handle };
