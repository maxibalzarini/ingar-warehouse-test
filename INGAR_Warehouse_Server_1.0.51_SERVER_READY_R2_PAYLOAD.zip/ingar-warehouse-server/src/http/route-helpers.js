'use strict';

// Utilidades compartidas por los modulos de src/http/routes/*.js. Extraidas de
// api-router.js tal cual (sin cambios de logica) como parte del refactor que separa el
// enrutamiento HTTP monolitico en modulos por dominio de negocio, alineados con la
// division ya existente en src/services/.

const net = require('node:net');
const runtime = require('../config/runtime');
const { keyProtectionStatus } = require('../security/key-manager');
const { isPlaintextSqlite } = require('../security/sqlite-encryption');
const { getDb } = require('../db/database');
const { authenticateSession, validateCsrf } = require('../services/auth-service');
const { hasPermission } = require('../services/permission-service');
const { getAuditHealth } = require('../services/audit-service');
const { listBackups } = require('../services/backup-service');
const { getNetworkStatus } = require('../services/network-service');
const { protectExport } = require('../services/protected-export-service');
const { binary, parseCookies } = require('./http-utils');

function match(pathname, pattern) {
  const names = [];
  const regexText = pattern.replace(/:[A-Za-z][A-Za-z0-9_]*/g, (token) => {
    names.push(token.slice(1));
    return '([^/]+)';
  });
  const result = pathname.match(new RegExp(`^${regexText}$`));
  if (!result) return null;
  try {
    return Object.fromEntries(names.map((name, index) => [name, decodeURIComponent(result[index + 1])]));
  } catch {
    throw Object.assign(new Error('Parámetro de ruta codificado de forma inválida.'), { status: 400, code: 'INVALID_PATH_PARAMETER' });
  }
}

function protectedDownload(res, body, filename, mimeType, correlationId, headers = {}) {
  const file = protectExport(Buffer.isBuffer(body) ? body : Buffer.from(String(body || ''), 'utf8'), { filename, mimeType });
  binary(res, 200, file.bytes, file.mimeType, correlationId, {
    ...headers,
    'Content-Disposition': `attachment; filename="${file.filename}"`,
    'X-Content-SHA256': file.sha256,
    'X-IWC-Protection': 'IWC_ENCRYPTED_CONTAINER_V1'
  });
}

function authenticate(req) {
  return authenticateSession(parseCookies(req)[runtime.cookieName], {
    ip: req.socket.remoteAddress || null,
    userAgent: String(req.headers['user-agent'] || '').slice(0, 500),
    correlationId: req.headers['x-correlation-id'] || null
  });
}

function requireAuth(req, permission = null) {
  const auth = authenticate(req);
  if (!auth) throw Object.assign(new Error('Autenticación requerida.'), { status: 401, code: 'AUTH_REQUIRED' });
  if (auth.user.mustChangePassword && permission !== 'Auth.Self') {
    throw Object.assign(new Error('Debe cambiar la contraseña antes de continuar.'), { status: 403, code: 'PASSWORD_CHANGE_REQUIRED' });
  }
  if (permission && !hasPermission(auth.user, permission)) throw Object.assign(new Error('Permiso insuficiente.'), { status: 403, code: 'FORBIDDEN' });
  return auth;
}

function requireAnyPermission(req, permissions) {
  const auth = requireAuth(req);
  if (auth.user.mustChangePassword) throw Object.assign(new Error('Debe cambiar la contraseña antes de continuar.'), { status: 403, code: 'PASSWORD_CHANGE_REQUIRED' });
  if (!permissions.some((permission) => hasPermission(auth.user, permission))) throw Object.assign(new Error('Permiso insuficiente.'), { status: 403, code: 'FORBIDDEN' });
  return auth;
}

function databaseEncryptedAtRest() {
  return !isPlaintextSqlite(runtime.dbPath);
}

function systemStatusForUser(user) {
  const db = getDb();
  const quickCheckRows = db.prepare('PRAGMA quick_check(1)').all();
  const quickCheck = quickCheckRows.length && quickCheckRows.every((row) => Object.values(row)[0] === 'ok') ? 'ok' : 'attention';
  const encryptedAtRest = databaseEncryptedAtRest();
  const schemaVersion = Number(db.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migration').get().version || 0);
  const latestMigration = db.prepare('SELECT version,name,applied_at FROM schema_migration ORDER BY version DESC LIMIT 1').get() || null;
  const latestExecution = db.prepare("SELECT previous_schema_version,target_schema_version,status,started_at,finished_at,backup_ref FROM migration_execution ORDER BY started_at DESC LIMIT 1").get() || null;
  const result = {
    generatedAt: new Date().toISOString(),
    status: quickCheck === 'ok' && encryptedAtRest ? 'READY' : 'ATTENTION',
    server: {
      status: 'UP',
      version: runtime.sourceVersion,
      platform: process.platform,
      uptimeSeconds: Math.floor(process.uptime())
    },
    database: {
      status: quickCheck === 'ok' && encryptedAtRest ? 'OK' : 'ATTENTION',
      quickCheck,
      encryptedAtRest,
      cipher: 'SQLite3MultipleCiphers',
      keyProtection: keyProtectionStatus(),
      schemaVersion,
      latestMigration,
      latestExecution: latestExecution ? {
        previousSchemaVersion: latestExecution.previous_schema_version,
        targetSchemaVersion: latestExecution.target_schema_version,
        status: latestExecution.status,
        startedAt: latestExecution.started_at,
        finishedAt: latestExecution.finished_at,
        backupCreated: Boolean(latestExecution.backup_ref)
      } : null
    },
    session: {
      fullName: user.fullName,
      roleCodes: user.roleCodes || [],
      permissionCount: user.permissions?.includes('*') ? 'TOTAL' : Number(user.permissions?.length || 0)
    }
  };

  if (hasPermission(user, 'Scheduler.Read') || hasPermission(user, 'Resilience.Read')) {
    const scheduler = db.prepare("SELECT COUNT(*) AS total,SUM(CASE WHEN enabled=1 THEN 1 ELSE 0 END) AS enabled,SUM(CASE WHEN enabled=1 AND last_status='FAILED' THEN 1 ELSE 0 END) AS failed,MAX(last_run_at) AS last_run_at FROM scheduler_job").get();
    result.scheduler = {
      status: Number(scheduler.failed || 0) === 0 ? 'OK' : 'ATTENTION',
      total: Number(scheduler.total || 0),
      enabled: Number(scheduler.enabled || 0),
      failed: Number(scheduler.failed || 0),
      lastRunAt: scheduler.last_run_at || null
    };
  }

  if (hasPermission(user, 'Backup.Read')) {
    const backups = listBackups();
    const latest = backups[0] || null;
    result.backup = {
      status: latest ? (latest.status === 'VERIFICADO' ? 'OK' : latest.status === 'FALLIDO' ? 'ATTENTION' : 'PENDING') : 'MISSING',
      count: backups.length,
      latestAt: latest?.created_at || null,
      latestStatus: latest?.status || null,
      latestVerifiedAt: latest?.verified_at || null,
      latestSchemaVersion: latest?.schema_version ?? null,
      encryptedAtRest: true,
      cipher: 'AES-256-GCM'
    };
  }

  if (hasPermission(user, 'Audit.Read')) {
    const audit = getAuditHealth({ verify: false });
    result.audit = {
      status: audit.status,
      liveEvents: audit.live.count,
      archivedEvents: audit.archive.events,
      archivedSegments: audit.archive.segments,
      warnings: audit.warnings
    };
  }

  if (hasPermission(user, 'Portal.Manage') || hasPermission(user, 'Resilience.Read')) {
    const network = getNetworkStatus();
    result.mobileAccess = {
      status: network.available ? 'OK' : 'ATTENTION',
      available: Boolean(network.available),
      address: network.address || null,
      interfaceName: network.interfaceName || null,
      firewallStatus: network.firewallStatus || 'UNKNOWN',
      transport: network.transport || 'HTTP',
      diagnosticCode: network.diagnosticCode || null,
      checkedAt: network.checkedAt || null
    };
  }

  if ([result.scheduler, result.backup, result.audit, result.mobileAccess].some((item) => item && !['OK', 'READY'].includes(item.status))) result.status = 'ATTENTION';
  return result;
}

function isPrivateIpv4(hostname) {
  const parts = hostname.split('.').map(Number);
  if (parts.length !== 4 || parts.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return false;
  return parts[0] === 10 || parts[0] === 127 || (parts[0] === 192 && parts[1] === 168) || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 169 && parts[1] === 254);
}
function trustedLocalHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  if (host === 'localhost' || host === '::1' || host.endsWith('.local')) return true;
  if (net.isIP(host) === 4) return isPrivateIpv4(host);
  if (net.isIP(host) === 6) return host === '::1' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe8') || host.startsWith('fe9') || host.startsWith('fea') || host.startsWith('feb');
  if (/^[a-z0-9-]{1,63}$/.test(host)) return true;
  const configuredHost = String(runtime.host || '').toLowerCase();
  return !['0.0.0.0', '::', '127.0.0.1'].includes(configuredHost) && host === configuredHost;
}
function requestBaseUrl() {
  const network = getNetworkStatus();
  if (network.available && network.baseUrl) return network.baseUrl;
  throw Object.assign(new Error('Acceso móvil no disponible. Conecte la computadora y el celular a la misma red.'), { status: 503, code: 'MOBILE_ACCESS_NETWORK_UNAVAILABLE' });
}

function requireCsrf(req, auth) {
  if (!validateCsrf(auth, req.headers['x-csrf-token'])) throw Object.assign(new Error('Token CSRF inválido.'), { status: 403, code: 'CSRF_INVALID' });
}

function contextWithUser(base, auth) {
  return { ...base, user: auth.user };
}

module.exports = {
  match, protectedDownload, authenticate, requireAuth, requireAnyPermission,
  databaseEncryptedAtRest, systemStatusForUser, isPrivateIpv4, trustedLocalHost,
  requestBaseUrl, requireCsrf, contextWithUser
};
