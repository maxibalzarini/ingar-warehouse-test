'use strict';

// Enrutador principal de la API. Antes era un unico archivo de ~1380 lineas con una
// cadena secuencial de ~150 `if` por endpoint; se dividio por dominio de negocio (misma
// division que src/services/) en src/http/routes/*.js, cada uno con la funcion
// `handle(req, res, url, baseContext)` que devuelve `true` si atendio la request. Este
// archivo solo compone esos modulos en el mismo orden en que estaban originalmente.
// La logica de cada endpoint no se modifico: es codigo movido, no reescrito.

const { json } = require('./http-utils');
const { match, requireAuth } = require('./route-helpers');

const startupDeployment = require('./routes/startup-deployment');
const installationValidation = require('./routes/installation-validation');

const dashboard = require('./routes/dashboard');
const managementFinance = require('./routes/management-finance');
const actionsMeetings = require('./routes/actions-meetings');
const reports = require('./routes/reports');
const operationalAccess = require('./routes/operational-access');
const authAccess = require('./routes/auth-access');
const system = require('./routes/system');
const assets = require('./routes/assets');
const requests = require('./routes/requests');
const custody = require('./routes/custody');
const incidents = require('./routes/incidents');
const extendedModules = require('./routes/extended-modules');
const evidence = require('./routes/evidence');
const maintenance = require('./routes/maintenance');
const notificationsScheduler = require('./routes/notifications-scheduler');

// Orden identico al de la version monolitica original.
const routeModules = [
  startupDeployment, installationValidation, dashboard, managementFinance, actionsMeetings, reports, operationalAccess, authAccess, system,
  assets, requests, custody, incidents, extendedModules, evidence, maintenance,
  notificationsScheduler
];

async function routeApi(req, res, url, baseContext) {
  const { pathname } = url;
  if (!pathname.startsWith('/api/v1/')) return false;

  for (const routeModule of routeModules) {
    if (await routeModule.handle(req, res, url, baseContext)) return true;
  }

  json(res, 404, { code: 'API_ROUTE_NOT_FOUND', message: 'Ruta API inexistente.' }, baseContext.correlationId);
  return true;
}

module.exports = { routeApi, match, requireAuth };
