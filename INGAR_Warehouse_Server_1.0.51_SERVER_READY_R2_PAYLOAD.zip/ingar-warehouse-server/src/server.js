'use strict';

const http = require('node:http');
const { URL } = require('node:url');
const runtime = require('./config/runtime');
const { openDatabase, closeDatabase } = require('./db/database');
const { seedBase, adminExists } = require('./services/seed-service');
const { startBackupScheduler, stopBackupScheduler, protectLegacyBackupFiles, recoverInterruptedRestore } = require('./services/backup-service');
const { startScheduler, stopScheduler } = require('./services/scheduler-service');
const logger = require('./services/logger');
const { routeApi } = require('./http/api-router');
const { requestContext, json, serveStatic, parseCookies } = require('./http/http-utils');
const { authenticateSession } = require('./services/auth-service');
const { canOpenScreen, resolveUserExperience } = require('./services/experience-service');
const { appendAudit, shouldAuditHttpRequest, reconcileAuditArchives } = require('./services/audit-service');
const { setMobileAccessRuntime, startNetworkMonitor, stopNetworkMonitor, getNetworkStatus } = require('./services/network-service');
const { startLanDiscovery, stopLanDiscovery, getLanDiscoveryStatus } = require('./services/lan-discovery-service');
const { startMdnsHost, stopMdnsHost, getMdnsStatus } = require('./services/mdns-host-service');
const { isRemoteLanRequest, isMobileLanRouteAllowed } = require('./security/lan-access-control');
const { reconcileEvidenceStorage } = require('./services/evidence-service');
const { redactText, redactForLog } = require('./security/log-redaction');
const { safeErrorText, writeStderr } = require('./security/secure-console');

let server = null;
let lanServer = null;

function normalizeError(error) {
  if (error?.code?.startsWith('SQLITE_CONSTRAINT_UNIQUE') || /UNIQUE constraint failed/i.test(error?.message || '')) {
    return { status: 409, code: 'DUPLICATE_RECORD', message: 'Ya existe un registro con los mismos datos únicos.', fieldErrors: [] };
  }
  if (/AUDIT_IMMUTABLE/.test(error?.message || '')) {
    return { status: 403, code: 'AUDIT_IMMUTABLE', message: 'La auditoría es inmutable.', fieldErrors: [] };
  }
  return {
    status: Number(error?.status) || 500,
    code: error?.code || 'INTERNAL_ERROR',
    message: Number(error?.status) && error.status < 500 ? redactText(error.message) : 'Error interno controlado.',
    fieldErrors: redactForLog(error?.fieldErrors || []),
    details: Number(error?.status) && error.status < 500 ? redactForLog(error?.details || null) : null
  };
}

function isSecureRequest(req) {
  if (req?.socket?.encrypted === true) return true;
  if (!runtime.serverMode) return false;
  const forwarded = String(req?.headers?.['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  return forwarded === 'https';
}


const EXPERIENCE_STATIC_ROUTES = Object.freeze({
  '/mi-operacion': '/operacion.html',
  '/panol/workbench': '/index.html',
  '/control': '/index.html',
  '/gestion/config': '/index.html',
  '/acceso-limitado': '/index.html'
});

const LEGACY_OPERATIONAL_PATHS = Object.freeze(new Set([
  '/tablet', '/tablet/', '/tablet.html',
  '/terminal', '/terminal/',
  '/operacion', '/operacion/', '/operacion.html'
]));

function canonicalPathname(pathname) {
  const value = String(pathname || '/');
  if (value === '/') return '/';
  return value.replace(/\/+$/, '') || '/';
}

function redirect(res, location) {
  res.statusCode = 302;
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Location', location);
  res.end();
}

function serveExperienceRoute(req, res, url, context) {
  const route = canonicalPathname(url.pathname);
  const staticTarget = EXPERIENCE_STATIC_ROUTES[route];
  if (!staticTarget || req.method !== 'GET') return false;
  const auth = authenticateSession(parseCookies(req)[runtime.cookieName], context);
  if (!auth) {
    redirect(res, `/?next=${encodeURIComponent(`${route}${url.search}`)}`);
    return true;
  }
  if (!canOpenScreen(auth.user, route)) {
    const experience = resolveUserExperience(auth.user);
    json(res, 403, {
      code: 'EXPERIENCE_ROUTE_FORBIDDEN',
      message: 'Tu perfil no tiene acceso a esta experiencia.',
      requestedRoute: route,
      targetRoute: experience.targetRoute
    }, context.correlationId);
    return true;
  }
  return serveStatic(res, staticTarget, context.correlationId);
}


function routeProductEntry(req, res, url, context) {
  if (req.method !== 'GET') return false;
  if (LEGACY_OPERATIONAL_PATHS.has(url.pathname)) {
    redirect(res, '/mi-operacion');
    return true;
  }
  if (url.pathname !== '/') return false;
  const auth = authenticateSession(parseCookies(req)[runtime.cookieName], context);
  if (!auth) return false;
  const experience = resolveUserExperience(auth.user);
  const requested = String(url.searchParams.get('next') || '').trim();
  let requestedTarget = null;
  if (requested.startsWith('/') && !requested.startsWith('//')) {
    try {
      const parsed = new URL(requested, 'http://warehouse.local');
      const requestedRoute = canonicalPathname(parsed.pathname);
      if (parsed.origin === 'http://warehouse.local' && canOpenScreen(auth.user, requestedRoute)) {
        requestedTarget = `${requestedRoute}${parsed.search}`;
      }
    } catch {}
  }
  const target = requestedTarget || experience.targetRoute;
  redirect(res, target);
  return true;
}

async function handleRequest(req, res) {
  res.iwcSecureTransport = isSecureRequest(req);
  const context = requestContext(req);
  const started = Date.now();
  const initialAuth = req.url.startsWith('/api/v1/') ? authenticateSession(parseCookies(req)[runtime.cookieName], context) : null;
  if (req.url.startsWith('/api/v1/')) {
    res.once('finish', () => {
      try {
        if (!shouldAuditHttpRequest(req, res.statusCode)) return;
        appendAudit({
          actorUserId: initialAuth?.user?.id || null,
          actorRole: initialAuth?.user?.roleCodes?.join(',') || null,
          action: `HTTP.${req.method}`,
          entityType: 'http_request',
          entityId: String(req.url).split('?')[0],
          correlationId: context.correlationId,
          source: res.iwcSecureTransport ? 'API_HTTPS' : 'API_LOCAL',
          ipAddress: context.ip,
          equipment: context.userAgent,
          result: res.statusCode < 400 ? 'SUCCESS' : (res.statusCode < 500 ? 'DENIED' : 'ERROR'),
          durationMs: Date.now() - started,
          error: res.statusCode >= 400 ? `HTTP_${res.statusCode}` : null
        });
      } catch (auditError) {
        process.stderr.write(`AUDIT_HTTP_ERROR ${redactText(auditError.message)}\n`);
      }
    });
  }
  try {
    const remoteLan = isRemoteLanRequest(req);
    const scheme = res.iwcSecureTransport ? 'https' : 'http';
    const url = new URL(req.url, `${scheme}://${req.headers.host || `${runtime.localHost}:${runtime.port}`}`);
    if (remoteLan && !runtime.serverMode && !isMobileLanRouteAllowed(req.method, url.pathname)) {
      json(res, 403, { code: 'LAN_ROUTE_NOT_ALLOWED', message: 'Esta función solo está disponible desde la computadora del pañol.' }, context.correlationId);
      return;
    }
    if (await routeApi(req, res, url, context)) return;
    if (routeProductEntry(req, res, url, context)) return;
    if (serveExperienceRoute(req, res, url, context)) return;
    if (req.method === 'GET' && serveStatic(res, url.pathname, context.correlationId)) return;
    json(res, 404, { code: 'NOT_FOUND', message: 'Recurso no encontrado.' }, context.correlationId);
  } catch (error) {
    const normalized = normalizeError(error);
    logger[normalized.status >= 500 ? 'error' : 'warn']('HTTP', normalized.message, {
      method: req.method,
      url: req.url,
      code: normalized.code,
      error: error?.message,
      durationMs: Date.now() - started
    }, context.correlationId);
    if (!res.headersSent) json(res, normalized.status, normalized, context.correlationId);
    else res.destroy();
  }
}

function configureServerTimeouts(instance) {
  instance.headersTimeout = 15_000;
  instance.requestTimeout = 30_000;
  instance.keepAliveTimeout = 5_000;
}

function listen(instance, port, host) {
  return new Promise((resolve, reject) => {
    instance.once('error', reject);
    instance.listen(port, host, () => {
      instance.off('error', reject);
      resolve(instance.address());
    });
  });
}

async function startServer(options = {}) {
  if (server) return server;
  // Debe ejecutarse antes de abrir SQLite: un restore interrumpido se revierte
  // de forma determinista y el arranque queda bloqueado si no puede recuperarse.
  recoverInterruptedRestore();
  openDatabase();
  const backupProtection = protectLegacyBackupFiles();
  seedBase();
  const logScrub = logger.scrubPersistedLogs();
  if (logScrub.databaseChanged || logScrub.fileChanged) logger.warn('SECURITY', 'Se redactaron datos sensibles históricos de los registros técnicos.', logScrub);
  if (backupProtection.encrypted) logger.info('SECURITY', 'Backups históricos migrados a contenedores cifrados.', { encrypted: backupProtection.encrypted });
  const evidenceReconciliation = reconcileEvidenceStorage(null, { pendingMaxAgeHours: 24 });
  const auditArchiveReconciliation = reconcileAuditArchives({ orphanMaxAgeMs: 60 * 60 * 1000 });
  if (!evidenceReconciliation.clean || evidenceReconciliation.expiredPending.length) logger.warn('EVIDENCE', 'Reconciliación de evidencias aplicada al iniciar.', evidenceReconciliation);
  if (!auditArchiveReconciliation.clean || auditArchiveReconciliation.removed.length) logger.warn('AUDIT', 'Reconciliación del archivo de auditoría aplicada al iniciar.', auditArchiveReconciliation);
  if (!adminExists() && options.requireAdmin !== false) {
    throw new Error('No existe un Administrador General. Inicie INGAR Warehouse.exe para completar la configuración inicial o use RECUPERAR_ADMINISTRADOR.bat si la instalación ya tenía usuarios.');
  }
  const serverMode = options.serverMode ?? runtime.serverMode;
  const localHost = options.host || (serverMode ? runtime.lanHost : runtime.localHost);
  const localPort = options.port ?? runtime.port;
  try {
    server = http.createServer((req, res) => { handleRequest(req, res); });
    configureServerTimeouts(server);
    const primaryAddress = await listen(server, localPort, localHost);

    if (serverMode) {
      lanServer = null;
      await setMobileAccessRuntime({ port: primaryAddress.port, protocol: 'http' });
    } else {
      lanServer = http.createServer((req, res) => { handleRequest(req, res); });
      configureServerTimeouts(lanServer);
      const lanAddress = await listen(lanServer, options.lanPort ?? runtime.mobileAccessPort, options.lanHost || runtime.lanHost);
      await setMobileAccessRuntime({ port: lanAddress.port, protocol: 'http' });
    }

    if (!serverMode) {
      try {
        await startLanDiscovery();
      } catch (error) {
        logger.warn('DISCOVERY', 'Warehouse continúa operativo, pero el descubrimiento automático LAN no pudo iniciar.', {
          code: error?.code || null,
          port: runtime.discoveryPort
        });
      }

      try {
        await startMdnsHost();
      } catch (error) {
        logger.warn('MDNS', 'Warehouse continúa operativo, pero la tablet no podrá usar el nombre fijo ingar-warehouse.local.', {
          code: error?.code || null,
          port: runtime.mdnsPort
        });
      }
      startNetworkMonitor({ onChange: (status, previous) => {
        logger.info('NETWORK', 'Estado del acceso móvil actualizado.', {
          previousAddress: previous?.address || null,
          address: status.address,
          available: status.available,
          diagnosticCode: status.diagnosticCode,
          transport: status.transport,
          revision: status.revision
        });
      } });
    }

    startBackupScheduler();
    startScheduler();
    const address = server.address();
    logger.info('SERVER', 'Servidor iniciado.', {
      localHost,
      localPort: address.port,
      version: runtime.sourceVersion,
      serverMode,
      remoteWebAccess: serverMode,
      mobileLan: serverMode || Boolean(lanServer),
      mobileAccess: getNetworkStatus()
    });
    return server;
  } catch (error) {
    await stopServer();
    throw error;
  }
}

async function closeListener(instance) {
  if (!instance) return;
  await new Promise((resolve) => instance.close(resolve));
}

async function stopServer() {
  stopBackupScheduler();
  stopScheduler();
  stopNetworkMonitor();
  await stopLanDiscovery();
  await stopMdnsHost();
  const local = server;
  const lan = lanServer;
  server = null;
  lanServer = null;
  await Promise.all([closeListener(local), closeListener(lan)]);
  closeDatabase();
}

function getServerState() {
  return {
    local: server?.address?.() || null,
    lan: runtime.serverMode ? (server?.address?.() || null) : (lanServer?.address?.() || null),
    network: getNetworkStatus(),
    discovery: getLanDiscoveryStatus(),
    mdns: getMdnsStatus()
  };
}

if (require.main === module) {
  startServer().then((instance) => {
    const address = instance.address();
    process.stdout.write(`INGAR Warehouse disponible en http://${runtime.browserHost}:${address.port}\n`);
    const network = getNetworkStatus();
    if (network.available) process.stdout.write(`Mi operación disponible en LAN: ${network.baseUrl}/mi-operacion\n`);
  }).catch((error) => {
    writeStderr(`ERROR: ${safeErrorText(error)}\n`);
    process.exitCode = 1;
  });
  const shutdown = async () => { await stopServer(); process.exit(0); };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

module.exports = { startServer, stopServer, handleRequest, getServerState };
