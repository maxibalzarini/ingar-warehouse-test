'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, requiredArray, parseBoolean } = require('../security/validation');
const { assertLocationScope, assertAssetScope } = require('../security/scope');
const { appendAudit } = require('./audit-service');
const { normalizeAsset, insertAsset, assetSelect, convertUniqueError } = require('./asset-service');
const { assertKitComponentHierarchyUnique } = require('./kit-operational-control-service');
const { assignKitToPersonInDb } = require('./kit-personal-service');
const { syncKitComponentsInDb } = require('./kit-component-membership-service');

const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);
const VEHICLE_UNITS = new Set(['KILOMETROS', 'HORAS']);
const IDENTIFIER_PATTERN = /^[A-Za-z0-9._/ -]+$/;

function httpError(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function nowIso() { return new Date().toISOString(); }

function normalizeOptionalIdentifier(value, field, { min = 2, max = 80 } = {}) {
  const text = optionalString(value, field, { max });
  if (!text) return null;
  if (text.length < min || !IDENTIFIER_PATTERN.test(text)) {
    throw httpError(422, 'IDENTIFIER_INVALID', `Formato inválido: ${field}.`, [{ field, message: `Debe tener entre ${min} y ${max} caracteres alfanuméricos.` }]);
  }
  return text.toUpperCase();
}

function finiteNonNegative(value, field, fallback = 0) {
  if (value === '' || value === null || value === undefined) return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) {
    throw httpError(422, 'NUMBER_INVALID', `${field} debe ser mayor o igual que cero.`, [{ field, message: 'Debe ser un número mayor o igual que cero.' }]);
  }
  return number;
}

function finitePositive(value, field, fallback = null) {
  if ((value === '' || value === null || value === undefined) && fallback !== null) return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) {
    throw httpError(422, 'NUMBER_INVALID', `${field} debe ser mayor que cero.`, [{ field, message: 'Debe ser un número mayor que cero.' }]);
  }
  return number;
}

function normalizeVehicleMeters(input) {
  const usageUnit = String(input.usageUnit || 'KILOMETROS').toUpperCase();
  if (!VEHICLE_UNITS.has(usageUnit)) throw httpError(422, 'VEHICLE_USAGE_UNIT_INVALID', 'La unidad operativa debe ser kilómetros u horas.');
  const kmPerHour = finitePositive(input.kmPerHour, 'kmPerHour', 50);
  if (kmPerHour > 1000) throw httpError(422, 'VEHICLE_CONVERSION_INVALID', 'La equivalencia de kilómetros por hora no puede superar 1000.');
  const hasOdometer = input.currentOdometer !== '' && input.currentOdometer !== null && input.currentOdometer !== undefined;
  const hasHourmeter = input.currentHourmeter !== '' && input.currentHourmeter !== null && input.currentHourmeter !== undefined;
  let odometer = hasOdometer ? finiteNonNegative(input.currentOdometer, 'currentOdometer') : null;
  let hourmeter = hasHourmeter ? finiteNonNegative(input.currentHourmeter, 'currentHourmeter') : null;
  if (usageUnit === 'KILOMETROS') {
    if (odometer === null) odometer = 0;
    if (hourmeter === null) hourmeter = odometer / kmPerHour;
  } else {
    if (hourmeter === null) hourmeter = 0;
    if (odometer === null) odometer = hourmeter * kmPerHour;
  }
  return { usageUnit, kmPerHour, odometer, hourmeter };
}

function normalizeVehicleProfile(input) {
  const meters = normalizeVehicleMeters(input);
  const manufactureYear = input.manufactureYear === '' || input.manufactureYear === null || input.manufactureYear === undefined
    ? null
    : Number(input.manufactureYear);
  if (manufactureYear !== null && (!Number.isInteger(manufactureYear) || manufactureYear < 1900 || manufactureYear > 2200)) {
    throw httpError(422, 'YEAR_INVALID', 'Año de fabricación inválido.', [{ field: 'manufactureYear', message: 'Debe estar entre 1900 y 2200.' }]);
  }
  const fuelCapacity = input.fuelCapacity === '' || input.fuelCapacity === null || input.fuelCapacity === undefined
    ? null
    : finitePositive(input.fuelCapacity, 'fuelCapacity');
  return {
    vin: normalizeOptionalIdentifier(input.vin, 'vin', { min: 5, max: 60 }),
    chassisNumber: normalizeOptionalIdentifier(input.chassisNumber, 'chassisNumber', { min: 3, max: 80 }),
    engineNumber: normalizeOptionalIdentifier(input.engineNumber, 'engineNumber', { min: 3, max: 80 }),
    manufactureYear,
    vehicleClass: optionalString(input.vehicleClass, 'vehicleClass', { max: 80 }),
    currentOdometer: meters.odometer,
    currentHourmeter: meters.hourmeter,
    usageUnit: meters.usageUnit,
    kmPerHour: meters.kmPerHour,
    fuelType: optionalString(input.fuelType, 'fuelType', { max: 80 }),
    fuelCapacity,
    requiredLicenseClass: normalizeOptionalIdentifier(input.requiredLicenseClass, 'requiredLicenseClass', { min: 1, max: 30 }),
    active: parseBoolean(input.active, true) ? 1 : 0
  };
}


function expectedInteger(value, field) {
  const number = Number(value);
  if (!Number.isInteger(number)) throw httpError(422, 'VERSION_REQUIRED', `La versión es obligatoria: ${field}.`, [{ field, message: 'Versión obligatoria.' }]);
  return number;
}

function normalizeVehicleProfileUpdate(input, current, asset) {
  const usageUnit = String(input.usageUnit ?? current.usage_unit ?? 'KILOMETROS').toUpperCase();
  if (!VEHICLE_UNITS.has(usageUnit)) throw httpError(422, 'VEHICLE_USAGE_UNIT_INVALID', 'La unidad operativa debe ser kilómetros u horas.');
  const kmPerHour = finitePositive(input.kmPerHour ?? current.km_per_hour, 'kmPerHour', 50);
  if (kmPerHour > 1000) throw httpError(422, 'VEHICLE_CONVERSION_INVALID', 'La equivalencia de kilómetros por hora no puede superar 1000.');
  const currentOdometer = input.currentOdometer === undefined ? Number(current.current_odometer ?? asset.odometer ?? 0) : finiteNonNegative(input.currentOdometer, 'currentOdometer');
  const currentHourmeter = input.currentHourmeter === undefined ? Number(current.current_hourmeter ?? 0) : finiteNonNegative(input.currentHourmeter, 'currentHourmeter');
  if (currentOdometer < Number(current.current_odometer || 0) || currentHourmeter < Number(current.current_hourmeter || 0)) {
    throw httpError(422, 'VEHICLE_METER_ROLLBACK', 'Odómetro y horómetro no pueden disminuir.');
  }
  let manufactureYear;
  if (input.manufactureYear === undefined) manufactureYear = current.manufacture_year;
  else if (input.manufactureYear === '' || input.manufactureYear === null) manufactureYear = null;
  else manufactureYear = Number(input.manufactureYear);
  if (manufactureYear !== null && (!Number.isInteger(manufactureYear) || manufactureYear < 1900 || manufactureYear > 2200)) {
    throw httpError(422, 'YEAR_INVALID', 'Año de fabricación inválido.', [{ field: 'manufactureYear', message: 'Debe estar entre 1900 y 2200.' }]);
  }
  let fuelCapacity;
  if (input.fuelCapacity === undefined) fuelCapacity = current.fuel_capacity;
  else if (input.fuelCapacity === '' || input.fuelCapacity === null) fuelCapacity = null;
  else fuelCapacity = finitePositive(input.fuelCapacity, 'fuelCapacity');
  const opt = (key, currentKey, max) => input[key] === undefined ? current[currentKey] : optionalString(input[key], key, { max });
  const ident = (key, currentKey, min, max) => input[key] === undefined ? current[currentKey] : normalizeOptionalIdentifier(input[key], key, { min, max });
  return {
    vin: ident('vin', 'vin', 1, 60),
    chassisNumber: ident('chassisNumber', 'chassis_number', 1, 80),
    engineNumber: ident('engineNumber', 'engine_number', 1, 80),
    manufactureYear,
    vehicleClass: opt('vehicleClass', 'vehicle_class', 80),
    currentOdometer,
    currentHourmeter,
    usageUnit,
    kmPerHour,
    fuelType: input.fuelType === undefined ? (current.fuel_type || asset.fuel_type) : optionalString(input.fuelType, 'fuelType', { max: 80 }),
    fuelCapacity,
    requiredLicenseClass: input.requiredLicenseClass === undefined ? current.required_license_class : normalizeOptionalIdentifier(input.requiredLicenseClass, 'requiredLicenseClass', { min: 1, max: 30 }),
    active: Number(current.active) ? 1 : 0
  };
}

function updateVehicle(assetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, assetId, 'Vehicles.Manage', db);
    const currentAsset = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
    if (!currentAsset) throw httpError(404, 'ASSET_NOT_FOUND', 'Vehículo no encontrado.');
    if (currentAsset.category_nature !== 'VEHICULO') throw httpError(422, 'ASSET_NATURE_INVALID', 'El bien no es un vehículo.');
    if (['RESERVADO','EN_CUSTODIA'].includes(String(currentAsset.status).toUpperCase())) {
      throw httpError(409, 'VEHICLE_OPERATION_OPEN', 'No puede editarse el maestro del vehículo mientras tenga una reserva o custodia abierta.');
    }
    const currentProfile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(assetId);
    if (!currentProfile) throw httpError(409, 'VEHICLE_PROFILE_MISSING', 'Integridad inválida: el vehículo no posee perfil vehicular.');
    const assetVersion = expectedInteger(input.assetVersion, 'assetVersion');
    const profileVersion = expectedInteger(input.profileVersion, 'profileVersion');
    if (assetVersion !== Number(currentAsset.version)) throw httpError(409, 'CONCURRENCY_CONFLICT', 'El vehículo fue modificado por otra operación.');
    if (profileVersion !== Number(currentProfile.version)) throw httpError(409, 'CONCURRENCY_CONFLICT', 'El perfil vehicular fue modificado por otra operación.');
    if (input.locationId !== undefined && String(input.locationId) !== String(currentAsset.location_id)) {
      throw httpError(409, 'VEHICLE_LOCATION_TRANSFER_REQUIRED', 'La ubicación del vehículo sólo puede cambiarse mediante Mover a otra ubicación.');
    }
    const profile = normalizeVehicleProfileUpdate(input, currentProfile, currentAsset);
    const assetData = normalizeAsset({
      categoryId: input.categoryId ?? currentAsset.category_id,
      internalCode: input.internalCode ?? currentAsset.internal_code,
      serialNumber: input.serialNumber ?? currentAsset.serial_number,
      description: input.description ?? currentAsset.description,
      brand: input.brand ?? currentAsset.brand,
      model: input.model ?? currentAsset.model,
      status: currentAsset.status,
      locationId: currentAsset.location_id,
      quantityTotal: 1,
      quantityAvailable: currentAsset.quantity_available,
      unitOfMeasure: currentAsset.unit_of_measure,
      licensePlate: input.licensePlate ?? currentAsset.license_plate,
      odometer: profile.currentOdometer,
      fuelType: profile.fuelType,
      notes: input.notes ?? currentAsset.notes,
      requiresWorkOrder: false,
      active: Boolean(currentAsset.active)
    }, currentAsset, db, { systemOperation: true });
    if (assetData.category.nature !== 'VEHICULO') throw httpError(422, 'VEHICLE_CATEGORY_REQUIRED', 'La categoría seleccionada debe ser vehicular.');
    const now = nowIso();
    try {
      const changedAsset = db.prepare(`UPDATE asset SET category_id=?,internal_code=?,serial_number=?,description=?,brand=?,model=?,license_plate=?,odometer=?,fuel_type=?,notes=?,version=version+1,updated_at=? WHERE id=? AND version=? AND deleted_at IS NULL`)
        .run(assetData.categoryId, assetData.internalCode, assetData.serialNumber, assetData.description, assetData.brand, assetData.model, assetData.licensePlate, profile.currentOdometer, profile.fuelType, assetData.notes, now, assetId, assetVersion);
      if (changedAsset.changes !== 1) throw httpError(409, 'CONCURRENCY_CONFLICT', 'El vehículo fue modificado por otra operación.');
      const changedProfile = db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,version=version+1,updated_at=? WHERE asset_id=? AND version=?`)
        .run(profile.vin, profile.chassisNumber, profile.engineNumber, profile.manufactureYear, profile.vehicleClass, profile.currentOdometer, profile.currentHourmeter, profile.usageUnit, profile.kmPerHour, profile.fuelType, profile.fuelCapacity, profile.requiredLicenseClass, now, assetId, profileVersion);
      if (changedProfile.changes !== 1) throw httpError(409, 'CONCURRENCY_CONFLICT', 'El perfil vehicular fue modificado por otra operación.');
    } catch (error) {
      throw convertVehicleUniqueError(error);
    }
    const afterAsset = db.prepare(`${assetSelect()} WHERE a.id=?`).get(assetId);
    const afterProfile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(assetId);
    appendAudit({
      actorUserId: context.user.id,
      actorRole: context.user.roleCodes.join(','),
      action: 'VEHICLE.UPDATE',
      entityType: 'vehicle',
      entityId: assetId,
      before: { asset: currentAsset, profile: currentProfile },
      after: { asset: afterAsset, profile: afterProfile },
      correlationId: context.correlationId,
      source: 'API',
      reason: optionalString(input.reason, 'reason', { max: 500 }),
      ipAddress: context.ip,
      equipment: context.userAgent
    }, db);
    return { asset: afterAsset, profile: afterProfile };
  });
}

function convertVehicleUniqueError(error) {
  const message = String(error.message || '');
  if (message.includes('vehicle_profile.vin') || message.includes('vehicle_profile.chassis_number')) {
    return httpError(409, 'VEHICLE_IDENTIFIER_DUPLICATE', 'VIN o chasis ya asignado a otro vehículo.');
  }
  return convertUniqueError(error);
}

function auditCombined(db, context, action, entityType, entityId, after, reason = null) {
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action,
    entityType,
    entityId,
    after,
    reason,
    correlationId: context.correlationId,
    source: 'API',
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
}

function createVehicle(input, context, metadata = {}) {
  return transaction((db) => {
    const categoryId = requiredString(input.categoryId, 'categoryId', { min: 8, max: 80 });
    const category = db.prepare('SELECT nature,active FROM asset_category WHERE id=? AND deleted_at IS NULL').get(categoryId);
    if (!category || !category.active || category.nature !== 'VEHICULO') throw httpError(422, 'VEHICLE_CATEGORY_REQUIRED', 'La categoría seleccionada no es vehicular o está inactiva.');
    const profile = normalizeVehicleProfile(input);
    const data = normalizeAsset({
      ...input,
      odometer: profile.currentOdometer,
      fuelType: profile.fuelType,
      quantityTotal: 1,
      quantityAvailable: 1,
      status: input.status || 'DISPONIBLE',
      active: input.active !== false
    }, null, db);
    assertLocationScope(context.user, data.locationId, 'Assets.Create', db);
    const id = randomUUID();
    const now = nowIso();
    try {
      insertAsset(db, data, { id, now });
      const result = db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,active=?,updated_at=? WHERE asset_id=?`)
        .run(profile.vin, profile.chassisNumber, profile.engineNumber, profile.manufactureYear, profile.vehicleClass, profile.currentOdometer, profile.currentHourmeter, profile.usageUnit, profile.kmPerHour, profile.fuelType, profile.fuelCapacity, profile.requiredLicenseClass, profile.active, now, id);
      if (result.changes !== 1) throw httpError(409, 'VEHICLE_PROFILE_MISSING', 'No pudo crearse el perfil vehicular dentro de la misma transacción.');
    } catch (error) {
      throw convertVehicleUniqueError(error);
    }
    const asset = db.prepare(`${assetSelect()} WHERE a.id=?`).get(id);
    const createdProfile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(id);
    const created = { asset, profile: createdProfile };
    auditCombined(db, context, metadata.auditAction || 'VEHICLE.CREATE', 'vehicle', id, created, metadata.reason || optionalString(input.reason, 'reason', { max: 500 }));
    return created;
  });
}

function normalizeKitComponents(db, components, context) {
  const items = requiredArray(components, 'components', 200);
  if (!items.length) throw httpError(422, 'KIT_COMPONENTS_REQUIRED', 'El kit debe contener al menos un componente.');
  const seen = new Set();
  const normalized = items.map((item, index) => {
    const componentAssetId = requiredString(item.componentAssetId, `components[${index}].componentAssetId`, { min: 8, max: 80 });
    if (seen.has(componentAssetId)) throw httpError(422, 'KIT_COMPONENT_DUPLICATE', 'Un componente no puede repetirse dentro del kit.');
    seen.add(componentAssetId);
    assertAssetScope(context.user, componentAssetId, 'Assets.Read', db);
    const asset = db.prepare(`SELECT a.*,c.nature AS category_nature,c.code AS category_code FROM asset a JOIN asset_category c ON c.id=a.category_id WHERE a.id=? AND a.deleted_at IS NULL`).get(componentAssetId);
    if (!asset || !asset.active || asset.status === 'BAJA') throw httpError(422, 'KIT_COMPONENT_INACTIVE', 'Todos los componentes deben ser bienes activos.');
    if (asset.category_nature === 'VEHICULO') throw httpError(422, 'KIT_COMPONENT_NATURE_INVALID', 'Un vehículo no puede incorporarse como componente de un kit.');
    if (asset.category_nature === 'KIT') throw httpError(422, 'KIT_PERSONAL_NESTED_FORBIDDEN', `Un kit personal no puede contener otro kit (${asset.internal_code}). Incorporá las herramientas físicas directamente.`);
    const requiredQuantity = finitePositive(item.requiredQuantity, `components[${index}].requiredQuantity`, 1);
    if (SERIAL_NATURES.has(asset.category_nature) && requiredQuantity !== 1) {
      throw httpError(422, 'KIT_SERIAL_QUANTITY_INVALID', `El componente seriado ${asset.internal_code} requiere cantidad uno.`);
    }
    const sequence = item.sequence === '' || item.sequence === null || item.sequence === undefined ? index + 1 : Number(item.sequence);
    if (!Number.isInteger(sequence) || sequence <= 0) throw httpError(422, 'KIT_SEQUENCE_INVALID', 'La secuencia de componentes debe ser un entero positivo.');
    return {
      componentAssetId,
      requiredQuantity,
      mandatory: parseBoolean(item.mandatory, true),
      allowSubstitution: parseBoolean(item.allowSubstitution, false),
      sequence,
      asset
    };
  });
  assertKitComponentHierarchyUnique(db, normalized.map((item) => item.componentAssetId));
  return normalized;
}

function createKit(input, context, metadata = {}) {
  return transaction((db) => {
    const assignedPersonId = requiredString(input.assignedPersonId, 'assignedPersonId', { min: 8, max: 80 });
    const categoryId = requiredString(input.categoryId, 'categoryId', { min: 8, max: 80 });
    const category = db.prepare('SELECT nature,active FROM asset_category WHERE id=? AND deleted_at IS NULL').get(categoryId);
    if (!category || !category.active || category.nature !== 'KIT') throw httpError(422, 'KIT_CATEGORY_REQUIRED', 'La categoría seleccionada no es de naturaleza KIT o está inactiva.');
    const components = normalizeKitComponents(db, input.components, context);
    const data = normalizeAsset({
      ...input,
      quantityTotal: 1,
      quantityAvailable: 1,
      status: input.status || 'DISPONIBLE',
      active: input.active !== false
    }, null, db);
    assertLocationScope(context.user, data.locationId, 'Assets.Create', db);
    const id = randomUUID();
    const now = nowIso();
    try {
      insertAsset(db, data, { id, now });
      const definitionResult = db.prepare('UPDATE kit_definition SET allow_incomplete_with_authorization=?,notes=?,updated_at=? WHERE kit_asset_id=?')
        .run(parseBoolean(input.allowIncompleteWithAuthorization, false) ? 1 : 0, optionalString(input.definitionNotes ?? input.notes, 'definitionNotes', { max: 2000 }), now, id);
      if (definitionResult.changes !== 1) throw httpError(409, 'KIT_DEFINITION_MISSING', 'No pudo crearse la definición del kit dentro de la misma transacción.');
      syncKitComponentsInDb(db, id, components, context, 'Alta completa de kit por UI');
    } catch (error) {
      throw convertUniqueError(error);
    }
    const assignment = assignKitToPersonInDb(db, id, {
      personId: assignedPersonId,
      notes: input.assignmentNotes || null,
      reason: input.assignmentReason || 'Alta de kit personal por mecánico'
    }, context, { skipScope: true });
    const asset = db.prepare(`${assetSelect()} WHERE a.id=?`).get(id);
    const definition = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(id);
    const createdComponents = db.prepare(`SELECT kc.*,a.internal_code,a.description,a.status,a.quantity_available,a.unit_of_measure,c.nature AS component_nature
      FROM kit_component kc JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id
      WHERE kc.kit_asset_id=? AND kc.active=1 ORDER BY kc.sequence,a.internal_code`).all(id);
    const created = { asset, definition, components: createdComponents, assignment };
    auditCombined(db, context, metadata.auditAction || 'KIT.CREATE', 'kit', id, created, metadata.reason || optionalString(input.reason, 'reason', { max: 500 }));
    return created;
  });
}

function duplicateVehicle(assetId, input, context) {
  const db = getDb();
  assertAssetScope(context.user, assetId, 'Assets.Create', db);
  const source = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
  if (!source) throw httpError(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  if (source.category_nature !== 'VEHICULO') throw httpError(422, 'ASSET_NATURE_INVALID', 'El bien no es un vehículo.');
  const profile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(assetId);
  if (!profile) throw httpError(409, 'VEHICLE_PROFILE_MISSING', 'Integridad inválida: el vehículo no posee perfil vehicular.');
  return createVehicle({
    categoryId: source.category_id,
    internalCode: input.internalCode,
    description: input.description || `${source.description} (copia)`,
    licensePlate: input.licensePlate,
    brand: source.brand,
    model: source.model,
    locationId: input.locationId || source.location_id,
    notes: source.notes,
    vin: input.vin || null,
    chassisNumber: input.chassisNumber || null,
    engineNumber: input.engineNumber || null,
    manufactureYear: profile.manufacture_year,
    vehicleClass: profile.vehicle_class,
    usageUnit: profile.usage_unit,
    currentOdometer: 0,
    currentHourmeter: 0,
    kmPerHour: profile.km_per_hour,
    fuelType: profile.fuel_type || source.fuel_type,
    fuelCapacity: profile.fuel_capacity,
    requiredLicenseClass: profile.required_license_class,
    active: true
  }, context, { auditAction: 'VEHICLE.DUPLICATE', reason: `Duplicado completo desde ${assetId}` });
}

function duplicateKit(assetId, input, context) {
  const db = getDb();
  assertAssetScope(context.user, assetId, 'Assets.Create', db);
  const source = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
  if (!source) throw httpError(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  if (source.category_nature !== 'KIT') throw httpError(422, 'ASSET_NATURE_INVALID', 'El bien no es un kit.');
  throw httpError(422, 'KIT_PERSONAL_DUPLICATION_FORBIDDEN', 'Un kit no puede duplicarse copiando las mismas herramientas físicas. Cree un kit nuevo y seleccione las herramientas que realmente integrarán el kit del mecánico.');
}

module.exports = { createVehicle, updateVehicle, createKit, duplicateVehicle, duplicateKit, normalizeVehicleMeters, normalizeVehicleProfile, normalizeKitComponents };
