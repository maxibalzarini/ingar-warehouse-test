'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { hashPassword, validatePassword, validateOperationalCredential, randomOperationalPin } = require('../security/password');
const { normalizeUsername, normalizeTechnicalUsername, technicalUsernameMatchesFullName, normalizeEmail, requiredString, optionalString, requiredArray } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { effectiveAuthorization } = require('./permission-service');
const { revokeAllUserSessions } = require('./auth-service');
const { getSetting } = require('./settings-service');
const { claimEvidence } = require('./evidence-service');
const { usesSimpleOperationalCredential, isTechnicalUser } = require('../config/operational-model');
const { finalizeLifecycleEventInDb, persistLifecycleFailure, assertTerminationClearance, assertRequiredTerminationPdfs } = require('./user-lifecycle-service');


function activeAdminGeneralCount(db = getDb()) {
  return db.prepare(`SELECT COUNT(DISTINCT ua.id) AS count
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL' AND r.active = 1
      AND ua.active = 1 AND ua.deleted_at IS NULL AND p.status = 'ACTIVA'`).get().count;
}

function protectLastAdmin(db, user, retainingAdminRole = true) {
  if (user.roleCodes.includes('ADMIN_GENERAL') && !retainingAdminRole && activeAdminGeneralCount(db) <= 1) {
    throw Object.assign(new Error('Debe permanecer al menos un Administrador General activo.'), { status: 422, code: 'LAST_ADMIN_PROTECTED' });
  }
}

function ensurePersonEvidence(db, evidenceId, personId, purpose, context) {
  if (!evidenceId) return null;
  const row = db.prepare('SELECT * FROM file_evidence WHERE id=?').get(evidenceId);
  if (!row) throw Object.assign(new Error('La evidencia indicada no existe.'), { status: 422, code: 'EVIDENCE_NOT_FOUND' });
  if (row.lifecycle_state === 'ACTIVE') {
    if (row.owner_type !== 'PERSON' || row.owner_id !== personId || row.purpose !== purpose) {
      throw Object.assign(new Error('La evidencia pertenece a otro registro y no puede reutilizarse.'), { status: 409, code: 'EVIDENCE_ALREADY_CLAIMED' });
    }
    return row;
  }
  return claimEvidence(evidenceId, { ownerType: 'PERSON', ownerId: personId, purpose }, context, db);
}

function serializeUser(row) {
  if (!row) return null;
  const authz = effectiveAuthorization(row.id);
  return {
    id: row.id,
    personId: row.person_id,
    username: row.username,
    active: Boolean(row.active),
    mustChangePassword: Boolean(row.must_change_password),
    credentialSetupReason: row.credential_setup_reason || (row.must_change_password ? 'INITIAL_SETUP' : 'NONE'),
    failedAttempts: row.failed_attempts,
    lockedUntil: row.locked_until,
    lastLoginAt: row.last_login_at,
    version: row.version,
    person: {
      fullName: row.full_name,
      documentType: row.document_type,
      documentNumber: row.document_number,
      email: row.email,
      phone: row.phone,
      sector: row.sector,
      supervisorPersonId: row.supervisor_person_id,
      supervisorUserId: row.supervisor_user_id || null,
      supervisorName: row.supervisor_name || null,
      supervisorUsername: row.supervisor_username || null,
      costCenter: row.cost_center,
      employeeNumber: row.employee_number,
      observations: row.observations,
      photoEvidenceId: row.photo_evidence_id,
      signatureEvidenceId: row.signature_evidence_id,
      status: row.person_status,
      version: row.person_version
    },
    roles: authz.roles,
    roleCodes: authz.roleCodes,
    permissions: authz.permissions,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    deletedAt: row.deleted_at || null,
    lifecycleStatus: row.deleted_at ? 'BAJA' : (row.active ? 'ACTIVO' : 'DESHABILITADO')
  };
}

function baseUserQuery() {
  return `SELECT ua.*, p.full_name, p.document_type, p.document_number, p.email, p.phone, p.sector,
    p.supervisor_person_id, sup_ua.id AS supervisor_user_id, sup_p.full_name AS supervisor_name,
    sup_ua.username AS supervisor_username, p.cost_center, p.employee_number, p.observations, p.photo_evidence_id,
    p.signature_evidence_id, p.status AS person_status, p.version AS person_version
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    LEFT JOIN person sup_p ON sup_p.id = p.supervisor_person_id
    LEFT JOIN user_account sup_ua ON sup_ua.person_id = sup_p.id AND sup_ua.deleted_at IS NULL`;
}

function listUsers(filters = {}) {
  const lifecycle = String(filters.lifecycle || '').toUpperCase();
  const where = [];
  const params = [];
  if (lifecycle === 'BAJA') where.push('ua.deleted_at IS NOT NULL');
  else if (lifecycle === 'ACTIVO') { where.push('ua.deleted_at IS NULL'); where.push('ua.active = 1'); }
  else if (lifecycle === 'DESHABILITADO') { where.push('ua.deleted_at IS NULL'); where.push('ua.active = 0'); }
  else if (lifecycle !== 'ALL') where.push('ua.deleted_at IS NULL');
  if (filters.search) {
    where.push('(ua.username LIKE ? OR p.full_name LIKE ? OR p.document_number LIKE ? OR p.email LIKE ?)');
    const term = `%${filters.search}%`;
    params.push(term, term, term, term);
  }
  if (filters.active !== undefined && lifecycle !== 'BAJA') { where.push('ua.active = ?'); params.push(filters.active ? 1 : 0); }
  if (filters.status) { where.push('p.status = ?'); params.push(filters.status); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const whereSql = where.length ? ` WHERE ${where.join(' AND ')}` : '';
  return getDb().prepare(`${baseUserQuery()}${whereSql} ORDER BY ua.deleted_at IS NOT NULL, p.full_name LIMIT ? OFFSET ?`).all(...params, limit, offset).map(serializeUser);
}

function getUser(id, options = {}) {
  const deletedFilter = options.includeTerminated ? '' : ' AND ua.deleted_at IS NULL';
  return serializeUser(getDb().prepare(`${baseUserQuery()} WHERE ua.id = ?${deletedFilter}`).get(id));
}

function listSupervisorCandidates() {
  const now = new Date().toISOString();
  return getDb().prepare(`SELECT ua.id, p.id AS person_id, ua.username, p.full_name,
      GROUP_CONCAT(DISTINCT r.code) AS role_codes,
      MAX(CASE r.code WHEN 'ADMIN_GENERAL' THEN 3 WHEN 'ADMINISTRADOR' THEN 2 WHEN 'SUPERVISOR' THEN 1 ELSE 0 END) AS hierarchy
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE ua.active = 1 AND ua.deleted_at IS NULL
      AND p.status = 'ACTIVA' AND p.deleted_at IS NULL
      AND r.active = 1 AND r.code IN ('ADMIN_GENERAL','ADMINISTRADOR','SUPERVISOR')
      AND (urs.valid_from IS NULL OR urs.valid_from <= ?)
      AND (urs.valid_to IS NULL OR urs.valid_to >= ?)
    GROUP BY ua.id, p.id, ua.username, p.full_name
    ORDER BY hierarchy DESC, p.full_name COLLATE NOCASE`).all(now, now).map((row) => ({
      id: row.id,
      personId: row.person_id,
      username: row.username,
      fullName: row.full_name,
      roleCodes: String(row.role_codes || '').split(',').filter(Boolean),
      isDefault: String(row.role_codes || '').split(',').includes('ADMIN_GENERAL')
    }));
}

function roleCodesForIds(db, roleIds) {
  if (!Array.isArray(roleIds) || !roleIds.length) return [];
  const placeholders = roleIds.map(() => '?').join(',');
  return db.prepare(`SELECT code FROM role WHERE active = 1 AND id IN (${placeholders})`).all(...roleIds).map((row) => row.code);
}

function defaultAdministratorSupervisor(db) {
  return db.prepare(`SELECT ua.id AS user_id, p.id AS person_id, p.full_name
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL' AND r.active = 1
      AND ua.active = 1 AND ua.deleted_at IS NULL
      AND p.status = 'ACTIVA' AND p.deleted_at IS NULL
    ORDER BY ua.created_at LIMIT 1`).get();
}


function supervisorUserIdForPerson(db, supervisorPersonId) {
  if (!supervisorPersonId) return null;
  return db.prepare('SELECT id FROM user_account WHERE person_id = ? AND deleted_at IS NULL LIMIT 1').get(supervisorPersonId)?.id || null;
}

function assertSupervisorChainAcyclic(db, currentPersonId, supervisorPersonId) {
  if (!currentPersonId || !supervisorPersonId) return;
  const visited = new Set([currentPersonId]);
  let cursor = supervisorPersonId;
  for (let depth = 0; cursor && depth < 100; depth += 1) {
    if (visited.has(cursor)) {
      throw Object.assign(new Error('La asignación de supervisor generaría un ciclo jerárquico.'), { status: 422, code: 'SUPERVISOR_CYCLE_FORBIDDEN' });
    }
    visited.add(cursor);
    cursor = db.prepare('SELECT supervisor_person_id FROM person WHERE id = ? LIMIT 1').get(cursor)?.supervisor_person_id || null;
  }
}

function syncSupervisorAssignment(db, userId, supervisorPersonId, actorUserId, reason) {
  const current = db.prepare(`SELECT usa.*, sup.person_id AS supervisor_person_id
    FROM user_supervisor_assignment usa
    JOIN user_account sup ON sup.id = usa.supervisor_user_id
    WHERE usa.user_id = ? AND usa.effective_to IS NULL LIMIT 1`).get(userId);
  const supervisorUserId = supervisorUserIdForPerson(db, supervisorPersonId);
  if (!supervisorPersonId) {
    if (current) db.prepare('UPDATE user_supervisor_assignment SET effective_to = ? WHERE id = ?').run(new Date().toISOString(), current.id);
    return;
  }
  if (!supervisorUserId) throw Object.assign(new Error('El supervisor seleccionado no tiene una cuenta de usuario vigente.'), { status: 422, code: 'SUPERVISOR_USER_REQUIRED' });
  if (current?.supervisor_user_id === supervisorUserId) return;
  const now = new Date().toISOString();
  if (current) db.prepare('UPDATE user_supervisor_assignment SET effective_to = ? WHERE id = ?').run(now, current.id);
  db.prepare(`INSERT INTO user_supervisor_assignment(
    id, user_id, supervisor_user_id, assigned_by_user_id, effective_from, effective_to, reason, created_at
  ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?)`)
    .run(randomUUID(), userId, supervisorUserId, actorUserId || null, now, reason || 'USER_SUPERVISOR_ASSIGNMENT', now);
}

function enforceTechnicalIdentity(username, fullName, roleCodes) {
  if (!isTechnicalUser(roleCodes)) return normalizeUsername(username);
  const normalized = normalizeTechnicalUsername(username);
  if (!technicalUsernameMatchesFullName(normalized, fullName)) {
    throw Object.assign(new Error('El usuario técnico debe corresponder a nombre.apellido.'), { status: 422, code: 'TECHNICAL_USERNAME_NAME_MISMATCH' });
  }
  return normalized;
}

function resolveSupervisorPersonId(db, requestedPersonId, roleIds, currentPersonId = null) {
  const roleCodes = roleCodesForIds(db, roleIds);
  const isAdminGeneral = roleCodes.includes('ADMIN_GENERAL');
  const requested = requestedPersonId || null;
  if (!requested) {
    if (isAdminGeneral) return null;
    const administrator = defaultAdministratorSupervisor(db);
    if (!administrator) throw Object.assign(new Error('No existe un Administrador General activo para asignar como supervisor.'), { status: 409, code: 'SUPERVISOR_ADMIN_REQUIRED' });
    if (administrator.person_id === currentPersonId) return null;
    assertSupervisorChainAcyclic(db, currentPersonId, administrator.person_id);
    return administrator.person_id;
  }
  if (requested === currentPersonId) {
    throw Object.assign(new Error('Un usuario no puede ser su propio supervisor.'), { status: 422, code: 'SUPERVISOR_SELF_FORBIDDEN' });
  }
  const now = new Date().toISOString();
  const candidate = db.prepare(`SELECT p.id
    FROM person p
    JOIN user_account ua ON ua.person_id = p.id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE p.id = ? AND p.status = 'ACTIVA' AND p.deleted_at IS NULL
      AND ua.active = 1 AND ua.deleted_at IS NULL
      AND r.active = 1 AND r.code IN ('ADMIN_GENERAL','ADMINISTRADOR','SUPERVISOR')
      AND (urs.valid_from IS NULL OR urs.valid_from <= ?)
      AND (urs.valid_to IS NULL OR urs.valid_to >= ?)
    LIMIT 1`).get(requested, now, now);
  if (!candidate) {
    throw Object.assign(new Error('El supervisor debe tener rol Administrador General, Administrador o Supervisor.'), { status: 422, code: 'SUPERVISOR_ROLE_INVALID' });
  }
  assertSupervisorChainAcyclic(db, currentPersonId, requested);
  return requested;
}

function validateUserInput(input, creating = true) {
  const person = input.person || {};
  const result = {
    username: normalizeUsername(input.username),
    fullName: requiredString(person.fullName, 'person.fullName', { min: 3, max: 160 }),
    documentType: requiredString(person.documentType, 'person.documentType', { min: 1, max: 30 }),
    documentNumber: requiredString(person.documentNumber, 'person.documentNumber', { min: 1, max: 60 }),
    email: normalizeEmail(person.email),
    phone: optionalString(person.phone, 'person.phone', { max: 50 }),
    sector: optionalString(person.sector, 'person.sector', { max: 100 }),
    supervisorPersonId: person.supervisorPersonId || null,
    costCenter: optionalString(person.costCenter, 'person.costCenter', { max: 80 }),
    employeeNumber: optionalString(person.employeeNumber, 'person.employeeNumber', { max: 60 }),
    observations: optionalString(person.observations, 'person.observations', { max: 2000 }),
    photoEvidenceId: person.photoEvidenceId || null,
    signatureEvidenceId: person.signatureEvidenceId || null,
    roleIds: requiredArray(input.roleIds || [], 'roleIds', 20),
    siteId: input.siteId || null,
    locationId: input.locationId || null
  };
  if (creating && result.roleIds.length === 0) throw Object.assign(new Error('Debe asignarse al menos un rol.'), { status: 422, code: 'ROLE_REQUIRED' });
  return result;
}

async function createUser(input, context) {
  const normalized = validateUserInput(input, true);
  const roleCodes = roleCodesForIds(getDb(), normalized.roleIds);
  normalized.username = enforceTechnicalIdentity(normalized.username, normalized.fullName, roleCodes);
  const simpleCredential = usesSimpleOperationalCredential(roleCodes);
  const selfSetup = simpleCredential && !input.password;
  if (!simpleCredential && !input.password) {
    throw Object.assign(new Error('Ingresá una contraseña de 4 a 8 caracteres y repetila.'), { status: 422, code: 'PASSWORD_REQUIRED' });
  }
  if (input.password && String(input.password) !== String(input.confirmPassword || '')) {
    throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'PASSWORD_MISMATCH' });
  }
  const password = input.password || randomOperationalPin(8);
  const errors = validatePassword(password, 4, 8);
  if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 422, code: 'PASSWORD_POLICY' });
  const passwordHash = await hashPassword(password);
  const mustChangePassword = selfSetup ? 1 : 0;
  const created = transaction((db) => {
    const now = new Date().toISOString();
    const personId = randomUUID();
    const userId = randomUUID();
    normalized.supervisorPersonId = resolveSupervisorPersonId(db, normalized.supervisorPersonId, normalized.roleIds, personId);
    db.prepare(`INSERT INTO person(
      id, document_type, document_number, full_name, email, phone, sector, supervisor_person_id,
      cost_center, employee_number, observations, photo_evidence_id, signature_evidence_id,
      status, version, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVA', 1, ?, ?)`)
      .run(personId, normalized.documentType, normalized.documentNumber, normalized.fullName,
        normalized.email, normalized.phone, normalized.sector, normalized.supervisorPersonId,
        normalized.costCenter, normalized.employeeNumber, normalized.observations,
        normalized.photoEvidenceId, normalized.signatureEvidenceId, now, now);
    ensurePersonEvidence(db, normalized.photoEvidenceId, personId, 'PHOTO', context);
    ensurePersonEvidence(db, normalized.signatureEvidenceId, personId, 'SIGNATURE', context);
    db.prepare(`INSERT INTO user_account(
      id, person_id, username, password_hash, failed_attempts, active, must_change_password, credential_setup_reason,
      version, created_at, updated_at
    ) VALUES (?, ?, ?, ?, 0, 1, ?, ?, 1, ?, ?)`)
      .run(userId, personId, normalized.username, passwordHash, mustChangePassword, selfSetup ? 'INITIAL_SETUP' : 'NONE', now, now);
    const roleStmt = db.prepare(`INSERT INTO user_role_scope(
      id, user_id, role_id, site_id, location_id, valid_from, valid_to, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)`);
    for (const roleId of normalized.roleIds) {
      if (!db.prepare('SELECT 1 FROM role WHERE id = ? AND active = 1').get(roleId)) {
        throw Object.assign(new Error(`Rol inexistente o inactivo: ${roleId}`), { status: 422, code: 'ROLE_INVALID' });
      }
      roleStmt.run(randomUUID(), userId, roleId, normalized.siteId, normalized.locationId, now, now, now);
    }
    syncSupervisorAssignment(db, userId, normalized.supervisorPersonId, context.user.id, 'USER_CREATE');
    db.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), userId, passwordHash, now);
    appendAudit({
      actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','),
      action: 'USER.CREATE', entityType: 'user_account', entityId: userId,
      after: { username: normalized.username, person: { fullName: normalized.fullName, documentType: normalized.documentType, documentNumber: normalized.documentNumber, supervisorPersonId: normalized.supervisorPersonId }, roleIds: normalized.roleIds },
      correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent
    }, db);
    return userId;
  });
  return { user: getUser(created), temporaryPassword: null, firstAccessSetupRequired: selfSetup, credentialType: 'PASSWORD', mustChangePassword: Boolean(mustChangePassword) };
}

async function updateUser(id, input, context) {
  const current = getUser(id);
  if (!current) throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
  const normalized = validateUserInput({
    username: input.username ?? current.username,
    person: { ...current.person, ...(input.person || {}) },
    roleIds: input.roleIds ?? current.roles.map((role) => role.id),
    siteId: input.siteId,
    locationId: input.locationId
  }, false);
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion) || expectedVersion !== current.version) {
    throw Object.assign(new Error('El registro fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
  }

  const newRoleCodes = roleCodesForIds(getDb(), normalized.roleIds);
  normalized.username = enforceTechnicalIdentity(normalized.username, normalized.fullName, newRoleCodes);
  const newSimpleCredential = usesSimpleOperationalCredential(newRoleCodes);
  let replacementHash = null;
  if (input.password) {
    if (String(input.password) !== String(input.confirmPassword || '')) {
      throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'PASSWORD_MISMATCH' });
    }
    const errors = validatePassword(String(input.password), 4, 8);
    if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 422, code: 'PASSWORD_POLICY' });
    replacementHash = await hashPassword(String(input.password));
  }
  if (current.mustChangePassword && !newSimpleCredential && !replacementHash) {
    throw Object.assign(new Error('Este usuario todavía no configuró su acceso. Para asignarle un rol administrativo, ingresá una contraseña de 4 a 8 caracteres y repetila.'), { status: 422, code: 'PASSWORD_REQUIRED_FOR_ADMIN_ROLE' });
  }

  transaction((db) => {
    const now = new Date().toISOString();
    normalized.supervisorPersonId = resolveSupervisorPersonId(db, normalized.supervisorPersonId, normalized.roleIds, current.personId);
    const result = db.prepare(`UPDATE user_account SET username = ?, version = version + 1, updated_at = ?
      WHERE id = ? AND version = ?`).run(normalized.username, now, id, expectedVersion);
    if (result.changes !== 1) throw Object.assign(new Error('Conflicto de concurrencia.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    if (normalized.photoEvidenceId !== current.person.photoEvidenceId) ensurePersonEvidence(db, normalized.photoEvidenceId, current.personId, 'PHOTO', context);
    if (normalized.signatureEvidenceId !== current.person.signatureEvidenceId) ensurePersonEvidence(db, normalized.signatureEvidenceId, current.personId, 'SIGNATURE', context);
    db.prepare(`UPDATE person SET document_type = ?, document_number = ?, full_name = ?, email = ?, phone = ?,
      sector = ?, supervisor_person_id = ?, cost_center = ?, employee_number = ?, observations = ?,
      photo_evidence_id = ?, signature_evidence_id = ?, version = version + 1, updated_at = ? WHERE id = ?`)
      .run(normalized.documentType, normalized.documentNumber, normalized.fullName, normalized.email,
        normalized.phone, normalized.sector, normalized.supervisorPersonId, normalized.costCenter,
        normalized.employeeNumber, normalized.observations, normalized.photoEvidenceId,
        normalized.signatureEvidenceId, now, current.personId);
    syncSupervisorAssignment(db, id, normalized.supervisorPersonId, context.user.id, 'USER_UPDATE');
    if (input.roleIds) {
      const adminRoleId = db.prepare("SELECT id FROM role WHERE code = 'ADMIN_GENERAL'").get()?.id;
      protectLastAdmin(db, current, normalized.roleIds.includes(adminRoleId));
      db.prepare('DELETE FROM user_role_scope WHERE user_id = ?').run(id);
      const stmt = db.prepare(`INSERT INTO user_role_scope(id, user_id, role_id, site_id, location_id, valid_from, valid_to, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)`);
      for (const roleId of normalized.roleIds) {
        if (!db.prepare('SELECT 1 FROM role WHERE id = ? AND active = 1').get(roleId)) {
          throw Object.assign(new Error(`Rol inexistente o inactivo: ${roleId}`), { status: 422, code: 'ROLE_INVALID' });
        }
        stmt.run(randomUUID(), id, roleId, normalized.siteId, normalized.locationId, now, now, now);
      }
    }
    if (replacementHash) {
      db.prepare(`UPDATE user_account SET password_hash = ?, must_change_password = ?, credential_setup_reason = 'NONE', failed_attempts = 0,
        locked_until = NULL, last_password_change_at = ?, updated_at = ? WHERE id = ?`)
        .run(replacementHash, 0, now, now, id);
      db.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
        .run(randomUUID(), id, replacementHash, now);
      revokeAllUserSessions(id, 'PASSWORD_CHANGED_BY_ADMIN', null, db);
    }
    appendAudit({
      actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','),
      action: 'USER.UPDATE', entityType: 'user_account', entityId: id,
      before: current,
      after: {
        username: normalized.username,
        person: normalized,
        roleIds: normalized.roleIds,
        credentialPolicy: 'SIMPLE_4_8',
        credentialUpdated: Boolean(replacementHash)
      },
      correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent
    }, db);
  });
  return {
    user: getUser(id),
    temporaryPassword: null,
    credentialType: replacementHash ? 'PASSWORD' : null,
    mustChangePassword: Boolean(getUser(id)?.mustChangePassword)
  };
}

function setUserActive(id, active, context, lifecycleInput = {}) {
  const current = getUser(id);
  if (!current) throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
  if (id === context.user.id && !active) throw Object.assign(new Error('No puede deshabilitar su propia cuenta.'), { status: 422, code: 'SELF_DISABLE_FORBIDDEN' });
  try {
    transaction((db) => {
    const now = new Date().toISOString();
    if (!active) {
      protectLastAdmin(db, current, false);
      finalizeLifecycleEventInDb(db, {
        eventId: String(lifecycleInput.lifecycleEventId || ''), userId: id, action: 'DISABLE', reason: lifecycleInput.reason,
        context, result: { active: false, personStatus: 'INACTIVA', identityPreserved: true }
      });
    }
    let supervisorPersonId = current.person.supervisorPersonId || null;
    if (active && !current.roleCodes.includes('ADMIN_GENERAL')) {
      const roleIds = db.prepare('SELECT role_id FROM user_role_scope WHERE user_id = ?').all(id).map((row) => row.role_id);
      try {
        supervisorPersonId = resolveSupervisorPersonId(db, supervisorPersonId, roleIds, current.personId);
      } catch (error) {
        if (!['SUPERVISOR_ROLE_INVALID', 'SUPERVISOR_CYCLE_FORBIDDEN'].includes(error.code)) throw error;
        supervisorPersonId = resolveSupervisorPersonId(db, null, roleIds, current.personId);
      }
    }
    db.prepare('UPDATE user_account SET active = ?, version = version + 1, updated_at = ? WHERE id = ?').run(active ? 1 : 0, now, id);
    db.prepare("UPDATE person SET status = ?, supervisor_person_id = ?, version = version + 1, updated_at = ? WHERE id = ?")
      .run(active ? 'ACTIVA' : 'INACTIVA', supervisorPersonId, now, current.personId);
    if (active) syncSupervisorAssignment(db, id, supervisorPersonId, context.user.id, 'USER_ENABLE');
    if (!active) revokeAllUserSessions(id, 'USER_DISABLED', null, db);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: active ? 'USER.ENABLE' : 'USER.DISABLE', entityType: 'user_account', entityId: id, before: { active: current.active, lifecycleStatus: current.lifecycleStatus }, after: { active, lifecycleStatus: active ? 'ACTIVO' : 'DESHABILITADO', identityPreserved: true }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent, reason: active ? null : String(lifecycleInput.reason || '').trim() }, db);
    });
  } catch (failure) {
    persistLifecycleFailure(failure);
    throw failure;
  }
  return getUser(id);
}

function softDeleteUser(id, input, context) {
  const current = getUser(id);
  if (!current) throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
  if (id === context.user.id) throw Object.assign(new Error('No puede dar de baja su propia cuenta.'), { status: 422, code: 'SELF_DELETE_FORBIDDEN' });
  try {
    transaction((db) => {
    const now = new Date().toISOString();
    protectLastAdmin(db, current, false);
    const clearance = assertTerminationClearance(db, {
      id: current.id, person_id: current.personId, username: current.username, full_name: current.person.fullName,
      document_type: current.person.documentType, document_number: current.person.documentNumber, employee_number: current.person.employeeNumber,
      sector: current.person.sector, cost_center: current.person.costCenter, supervisor_person_id: current.person.supervisorPersonId,
      supervisor_name: current.person.supervisorName, supervisor_username: current.person.supervisorUsername
    }, input || {}, context);
    assertRequiredTerminationPdfs(db, String(input?.lifecycleEventId || ''), id);
    finalizeLifecycleEventInDb(db, {
      eventId: String(input?.lifecycleEventId || ''), userId: id, action: 'TERMINATE', reason: input?.reason,
      context, result: { active: false, deletedAt: now, personStatus: 'ELIMINADA', identityPreserved: true, physicalDelete: false,
        clearance: { ready: clearance.snapshot.clearanceReady, override: clearance.override, tools: clearance.snapshot.tools.length, kits: clearance.snapshot.kits.length, vehicles: clearance.snapshot.vehicles.length, incidents: clearance.snapshot.incidents.length } }
    });
    db.prepare('UPDATE user_account SET active = 0, deleted_at = ?, version = version + 1, updated_at = ? WHERE id = ?').run(now, now, id);
    db.prepare("UPDATE person SET status = 'ELIMINADA', deleted_at = ?, version = version + 1, updated_at = ? WHERE id = ?").run(now, now, current.personId);
    db.prepare('UPDATE user_supervisor_assignment SET effective_to = ? WHERE user_id = ? AND effective_to IS NULL').run(now, id);
    revokeAllUserSessions(id, 'USER_TERMINATED', null, db);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.TERMINATE', entityType: 'user_account', entityId: id, before: current, after: { deletedAt: now, active: false, lifecycleStatus: 'BAJA', identityPreserved: true, physicalDelete: false }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent, reason: String(input?.reason || '').trim() }, db);
    });
  } catch (failure) {
    persistLifecycleFailure(failure);
    throw failure;
  }
  return { terminated: true, userId: id, personId: current.personId, username: current.username, identityPreserved: true, physicalDelete: false };
}

function currentSupervisorUserId(db, userId) {
  return db.prepare(`SELECT supervisor_user_id
    FROM user_supervisor_assignment
    WHERE user_id = ? AND effective_to IS NULL
    ORDER BY effective_from DESC LIMIT 1`).get(userId)?.supervisor_user_id || null;
}

function passwordResetAuthority(db, targetUser, context) {
  const actorUserId = context?.user?.id || null;
  const actorRoles = new Set((context?.user?.roleCodes || []).map((code) => String(code || '').toUpperCase()));
  if (!actorUserId) throw Object.assign(new Error('No hay un usuario autenticado para realizar el blanqueo.'), { status: 401, code: 'AUTH_REQUIRED' });
  if (actorUserId === targetUser.id) {
    throw Object.assign(new Error('Para cambiar su propia contraseña use Cambiar contraseña.'), { status: 422, code: 'PASSWORD_RESET_SELF_FORBIDDEN' });
  }
  if (actorRoles.has('ADMIN_GENERAL') || actorRoles.has('ADMINISTRADOR')) return 'ADMINISTRATIVE';
  if (actorRoles.has('SUPERVISOR')) {
    const supervisorUserId = currentSupervisorUserId(db, targetUser.id);
    if (supervisorUserId === actorUserId) return 'DIRECT_SUPERVISOR';
    throw Object.assign(new Error('El Supervisor sólo puede blanquear la contraseña de usuarios que tiene asignados directamente.'), { status: 403, code: 'PASSWORD_RESET_SCOPE_FORBIDDEN' });
  }
  throw Object.assign(new Error('No tiene alcance para blanquear esta contraseña.'), { status: 403, code: 'PASSWORD_RESET_SCOPE_FORBIDDEN' });
}

function cancelPendingPasswordReset(db, targetUserId, now, source = 'REPLACED_BY_NEW_RESET') {
  db.prepare(`UPDATE password_reset_event
    SET status = 'CANCELLED', completed_at = NULL, completion_source = ?
    WHERE target_user_id = ? AND status = 'PENDING'`).run(source, targetUserId);
}

function recordPasswordResetEvent(db, targetUser, context, { mode, authorityScope, status, source }) {
  const now = new Date().toISOString();
  cancelPendingPasswordReset(db, targetUser.id, now);
  const supervisorUserId = currentSupervisorUserId(db, targetUser.id);
  const eventId = randomUUID();
  const completed = status === 'COMPLETED';
  db.prepare(`INSERT INTO password_reset_event(
    id, target_user_id, target_person_id, target_username_snapshot,
    reset_by_user_id, supervisor_user_id_snapshot, reset_mode, authority_scope,
    status, requested_at, completed_at, completion_source, created_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(eventId, targetUser.id, targetUser.personId, targetUser.username,
      context?.user?.id || null, supervisorUserId, mode, authorityScope,
      status, now, completed ? now : null, completed ? (source || 'ADMIN_API') : null, now);
  return eventId;
}

async function resetPassword(id, input, context) {
  const current = getUser(id);
  if (!current) throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
  const simpleCredential = usesSimpleOperationalCredential(current.roleCodes);
  const userSetup = simpleCredential && (input?.userSetup === true || input?.selfSetup === true || !input?.password);
  let password;
  let mustChangePassword;
  let credentialSetupReason;
  let resetMode;
  let eventStatus;
  if (userSetup) {
    password = randomOperationalPin(8);
    mustChangePassword = 1;
    credentialSetupReason = 'PASSWORD_RESET';
    resetMode = 'USER_SETUP';
    eventStatus = 'PENDING';
  } else {
    password = String(input?.password || '');
    const confirmation = String(input?.confirmPassword || '');
    if (password !== confirmation) throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'PASSWORD_MISMATCH' });
    const errors = validatePassword(password, 4, 8);
    if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 422, code: 'PASSWORD_POLICY' });
    mustChangePassword = 0;
    credentialSetupReason = 'NONE';
    resetMode = 'DIRECT_ADMIN_SET';
    eventStatus = 'COMPLETED';
  }
  const passwordHash = await hashPassword(password);
  transaction((db) => {
    const authorityScope = passwordResetAuthority(db, current, context);
    const beforeIdentity = {
      userId: current.id,
      personId: current.personId,
      username: current.username,
      supervisorUserId: current.person.supervisorUserId || null,
      roles: current.roleCodes.slice()
    };
    const now = new Date().toISOString();
    db.prepare(`UPDATE user_account SET password_hash = ?, must_change_password = ?, credential_setup_reason = ?, failed_attempts = 0,
      locked_until = NULL, last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?`)
      .run(passwordHash, mustChangePassword, credentialSetupReason, userSetup ? null : now, now, id);
    db.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), id, passwordHash, now);
    recordPasswordResetEvent(db, current, context, { mode: resetMode, authorityScope, status: eventStatus, source: 'ADMIN_API' });
    revokeAllUserSessions(id, 'PASSWORD_RESET', null, db);
    appendAudit({
      actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','),
      action: 'USER.RESET_PASSWORD', entityType: 'user_account', entityId: id,
      before: beforeIdentity,
      after: {
        userId: current.id,
        personId: current.personId,
        username: current.username,
        supervisorUserId: current.person.supervisorUserId || null,
        roles: current.roleCodes.slice(),
        credentialSetupReason,
        passwordSetupRequired: Boolean(userSetup),
        identityPreserved: true
      },
      correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent
    }, db);
  });
  return {
    temporaryPassword: null,
    passwordSetupRequired: Boolean(userSetup),
    firstAccessSetupRequired: false,
    mustChangePassword: Boolean(mustChangePassword),
    credentialSetupReason,
    credentialType: 'PASSWORD',
    username: current.username,
    identityPreserved: true
  };
}

async function resetOperationalPins(context) {
  const actorRoles = new Set((context?.user?.roleCodes || []).map((code) => String(code || '').toUpperCase()));
  if (!actorRoles.has('ADMIN_GENERAL') && !actorRoles.has('ADMINISTRADOR')) {
    throw Object.assign(new Error('El blanqueo masivo está reservado a Administradores.'), { status: 403, code: 'PASSWORD_RESET_BATCH_ADMIN_ONLY' });
  }
  const candidates = listUsers({ active: true, limit: 500 }).filter((user) => usesSimpleOperationalCredential(user.roleCodes));
  const resets = [];
  for (const user of candidates) {
    const placeholder = randomOperationalPin(8);
    resets.push({
      user,
      passwordHash: await hashPassword(placeholder)
    });
  }
  transaction((db) => {
    const now = new Date().toISOString();
    for (const item of resets) {
      db.prepare(`UPDATE user_account SET password_hash = ?, must_change_password = 1, credential_setup_reason = 'PASSWORD_RESET', failed_attempts = 0,
        locked_until = NULL, last_password_change_at = NULL, version = version + 1, updated_at = ? WHERE id = ?`)
        .run(item.passwordHash, now, item.user.id);
      db.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
        .run(randomUUID(), item.user.id, item.passwordHash, now);
      recordPasswordResetEvent(db, item.user, context, { mode: 'BATCH_USER_SETUP', authorityScope: 'ADMINISTRATIVE', status: 'PENDING', source: 'ADMIN_API' });
      revokeAllUserSessions(item.user.id, 'OPERATIONAL_ACCESS_RESET', null, db);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.RESET_OPERATIONAL_ACCESS', entityType: 'user_account', entityId: item.user.id, after: { username: item.user.username, personId: item.user.personId, identityPreserved: true, credentialSetupReason: 'PASSWORD_RESET' }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent, result: 'SUCCESS' }, db);
    }
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.RESET_OPERATIONAL_ACCESS_BATCH', entityType: 'user_account', entityId: 'OPERATIONAL', after: { count: resets.length, identityPreserved: true }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent, result: 'SUCCESS' }, db);
  });
  return { count: resets.length, passwordSetupRequired: true, identityPreserved: true };
}


module.exports = { listUsers, getUser, listSupervisorCandidates, createUser, updateUser, setUserActive, softDeleteUser, resetPassword, resetOperationalPins };
