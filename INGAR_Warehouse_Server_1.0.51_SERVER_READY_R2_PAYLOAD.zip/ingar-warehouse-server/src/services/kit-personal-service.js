'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString } = require('../security/validation');
const { assertAssetScope } = require('../security/scope');
const { appendAudit } = require('./audit-service');
const { hasPermission } = require('./permission-service');
const { isTechnicalUser } = require('../config/operational-model');
const { activateKitMembershipsForAssignmentInDb, releaseAllKitMembershipsInDb } = require('./kit-component-membership-service');

function error(status, code, message, fieldErrors = []) { return Object.assign(new Error(message), { status, code, fieldErrors }); }
function nowIso() { return new Date().toISOString(); }
function esc(value) { return String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[ch])); }

function audit(db, context, action, entityType, entityId, before, after, reason = null) {
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action, entityType, entityId, before, after, reason, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
}

function getKitRow(db, kitAssetId) {
  const row = db.prepare(`SELECT a.*,c.nature AS category_nature,c.code AS category_code,c.name AS category_name,
      kd.version AS definition_version,kd.ownership_mode,kd.notes AS definition_notes,
      sl.code AS location_code,sl.name AS location_name,s.code AS site_code,s.name AS site_name
    FROM asset a
    JOIN asset_category c ON c.id=a.category_id
    JOIN kit_definition kd ON kd.kit_asset_id=a.id
    JOIN storage_location sl ON sl.id=a.location_id
    JOIN site s ON s.id=sl.site_id
    WHERE a.id=? AND a.deleted_at IS NULL`).get(kitAssetId);
  if (!row) throw error(404, 'KIT_NOT_FOUND', 'Kit no encontrado.');
  if (row.category_nature !== 'KIT') throw error(422, 'KIT_REQUIRED', 'El bien seleccionado no es un kit.');
  return row;
}

function getActiveAssignment(db, kitAssetId) {
  return db.prepare(`SELECT kpa.*,p.full_name,p.employee_number,p.sector,p.status AS person_status,
      ua.username,ua.active AS user_active
    FROM kit_person_assignment kpa
    JOIN person p ON p.id=kpa.person_id
    LEFT JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
    WHERE kpa.kit_asset_id=? AND kpa.status='ACTIVE'
    ORDER BY kpa.assigned_at DESC LIMIT 1`).get(kitAssetId) || null;
}

function activeOpenCustody(db, kitAssetId) {
  return db.prepare(`SELECT c.id,c.person_id,c.status,c.opened_at,p.full_name
    FROM custody c JOIN person p ON p.id=c.person_id
    WHERE c.asset_id=? AND c.status<>'CERRADA'
    ORDER BY c.opened_at DESC LIMIT 1`).get(kitAssetId) || null;
}

function assertAssignablePerson(db, personId) {
  const row = db.prepare(`SELECT p.id,p.full_name,p.employee_number,p.sector,p.status,ua.id AS user_id,ua.username,ua.active,
      GROUP_CONCAT(DISTINCT r.code) AS role_codes
    FROM person p
    JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
    LEFT JOIN user_role_scope urs ON urs.user_id=ua.id
      AND (urs.valid_from IS NULL OR julianday(urs.valid_from)<=julianday('now'))
      AND (urs.valid_to IS NULL OR julianday(urs.valid_to)>=julianday('now'))
    LEFT JOIN role r ON r.id=urs.role_id AND r.active=1
    WHERE p.id=? AND p.deleted_at IS NULL
    GROUP BY p.id,ua.id`).get(personId);
  if (!row || row.status !== 'ACTIVA' || Number(row.active) !== 1) throw error(422, 'KIT_MECHANIC_INVALID', 'El mecánico seleccionado no posee un usuario activo.');
  const roleCodes = String(row.role_codes || '').split(',').filter(Boolean);
  if (!isTechnicalUser(roleCodes)) throw error(422, 'KIT_MECHANIC_ROLE_REQUIRED', 'El kit personal sólo puede asignarse a un usuario técnico con rol Solicitante.');
  return { ...row, roleCodes };
}

function listEligibleMechanics() {
  const now = nowIso();
  return getDb().prepare(`SELECT p.id AS person_id,p.full_name,p.employee_number,p.sector,ua.id AS user_id,ua.username,
      GROUP_CONCAT(DISTINCT r.code) AS role_codes
    FROM person p
    JOIN user_account ua ON ua.person_id=p.id
    LEFT JOIN user_role_scope urs ON urs.user_id=ua.id
      AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)
    LEFT JOIN role r ON r.id=urs.role_id AND r.active=1
    WHERE p.status='ACTIVA' AND p.deleted_at IS NULL AND ua.active=1 AND ua.deleted_at IS NULL
      AND EXISTS (
        SELECT 1 FROM user_role_scope tech_urs JOIN role tech_role ON tech_role.id=tech_urs.role_id
        WHERE tech_urs.user_id=ua.id AND tech_role.code='SOLICITANTE' AND tech_role.active=1
          AND (tech_urs.valid_from IS NULL OR julianday(tech_urs.valid_from)<=julianday(?))
          AND (tech_urs.valid_to IS NULL OR julianday(tech_urs.valid_to)>=julianday(?))
      )
    GROUP BY p.id,ua.id
    ORDER BY p.full_name COLLATE NOCASE`).all(now, now, now, now).map((row) => ({
      personId: row.person_id,
      userId: row.user_id,
      fullName: row.full_name,
      employeeNumber: row.employee_number,
      sector: row.sector,
      username: row.username,
      roleCodes: String(row.role_codes || '').split(',').filter(Boolean)
    }));
}

function insertAssignmentEvent(db, assignment, eventType, context, reason, details = {}) {
  const now = nowIso();
  db.prepare(`INSERT INTO kit_person_assignment_event(
    id,assignment_id,kit_asset_id,person_id,event_type,actor_user_id,reason,occurred_at,correlation_id,details_json,created_at
  ) VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
    randomUUID(), assignment.id, assignment.kit_asset_id, assignment.person_id, eventType,
    context.user.id, reason || null, now, context.correlationId, JSON.stringify(details || {}), now
  );
}

function closeAssignmentInDb(db, assignment, context, reason) {
  const why = requiredString(reason, 'reason', { min: 3, max: 1000 });
  const now = nowIso();
  const result = db.prepare(`UPDATE kit_person_assignment
    SET status='CLOSED',ended_at=?,ended_by_user_id=?,end_reason=?,version=version+1,updated_at=?
    WHERE id=? AND status='ACTIVE' AND version=?`).run(now, context.user.id, why, now, assignment.id, assignment.version);
  if (result.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La asignación del kit cambió mientras se procesaba la operación.');
  const closed = db.prepare('SELECT * FROM kit_person_assignment WHERE id=?').get(assignment.id);
  insertAssignmentEvent(db, closed, 'CLOSED', context, why, { previousPersonId: assignment.person_id });
  return closed;
}

function closeStaleInactiveKitAssignmentsForComponentsInDb(db, componentAssetIds, context, reason = 'Saneamiento de asignación obsoleta de kit inactivo') {
  const ids = [...new Set((componentAssetIds || []).map(String).filter(Boolean))];
  if (!ids.length) return [];
  const rows = db.prepare(`SELECT DISTINCT kpa.*
    FROM kit_person_assignment kpa
    JOIN asset ka ON ka.id=kpa.kit_asset_id
    JOIN kit_component kc ON kc.kit_asset_id=kpa.kit_asset_id AND kc.active=1
    WHERE kpa.status='ACTIVE'
      AND (ka.deleted_at IS NOT NULL OR ka.active=0 OR ka.status='BAJA')
      AND kc.component_asset_id IN (${ids.map(() => '?').join(',')})
    ORDER BY kpa.assigned_at`).all(...ids);
  const closed = [];
  for (const current of rows) {
    const after = closeAssignmentInDb(db, current, context, reason);
    releaseAllKitMembershipsInDb(db, current.kit_asset_id, context, reason);
    audit(db, context, 'KIT.UNASSIGN_PERSON_AUTO_STALE', 'kit_person_assignment', after.id, current, after, reason);
    closed.push(after);
  }
  return closed;
}

function assignKitToPersonInDb(db, kitAssetId, input, context, options = {}) {
  if (!options.skipScope) assertAssetScope(context.user, kitAssetId, 'Kits.Manage', db);
  const kit = getKitRow(db, kitAssetId);
  if (!kit.active || kit.status === 'BAJA') throw error(409, 'KIT_INACTIVE', 'El kit no está activo para asignación.');
  const nestedKit = db.prepare(`SELECT a.internal_code FROM kit_component kc
    JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE kc.kit_asset_id=? AND kc.active=1 AND c.nature='KIT' LIMIT 1`).get(kitAssetId);
  if (nestedKit) throw error(422, 'KIT_PERSONAL_NESTED_FORBIDDEN', `Un kit personal no puede contener otro kit (${nestedKit.internal_code}). Incorporá las herramientas físicas directamente.`);
  const personId = requiredString(input.personId || input.assignedPersonId, 'personId', { min: 8, max: 80 });
  const mechanic = assertAssignablePerson(db, personId);
  const notes = optionalString(input.notes || input.assignmentNotes, 'notes', { max: 2000 });
  const componentIds = db.prepare('SELECT component_asset_id FROM kit_component WHERE kit_asset_id=? AND active=1').all(kitAssetId).map((row) => row.component_asset_id);
  closeStaleInactiveKitAssignmentsForComponentsInDb(db, componentIds, context);
  const current = getActiveAssignment(db, kitAssetId);
  if (current && current.person_id === personId) {
    if (notes !== null && notes !== current.assignment_notes) {
      db.prepare('UPDATE kit_person_assignment SET assignment_notes=?,version=version+1,updated_at=? WHERE id=? AND version=?')
        .run(notes, nowIso(), current.id, current.version);
    }
    activateKitMembershipsForAssignmentInDb(db, kitAssetId, context, 'Reconciliación de componentes para asignación existente');
    return db.prepare(`SELECT kpa.*,p.full_name,p.employee_number,p.sector,ua.username
      FROM kit_person_assignment kpa JOIN person p ON p.id=kpa.person_id LEFT JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
      WHERE kpa.id=?`).get(current.id);
  }
  const openCustody = activeOpenCustody(db, kitAssetId);
  if (openCustody && openCustody.person_id !== personId) {
    throw error(409, 'KIT_ASSIGNMENT_CUSTODY_CONFLICT', `El kit está en custodia de ${openCustody.full_name}. Debe cerrarse esa custodia antes de reasignarlo.`);
  }
  if (current) {
    if (input.reassign !== true && options.allowReassign !== true) throw error(409, 'KIT_ALREADY_ASSIGNED', `El kit ya está asignado a ${current.full_name}.`);
    if (openCustody) throw error(409, 'KIT_REASSIGN_OPEN_CUSTODY', 'No puede reasignarse un kit mientras mantiene una custodia abierta.');
    closeAssignmentInDb(db, current, context, input.reason || `Reasignación a ${mechanic.full_name}`);
  }
  const now = nowIso();
  activateKitMembershipsForAssignmentInDb(db, kitAssetId, context, 'Activación de reserva lógica de componentes al asignar kit');
  const id = randomUUID();
  db.prepare(`INSERT INTO kit_person_assignment(
    id,kit_asset_id,person_id,status,assigned_at,assigned_by_user_id,assignment_notes,version,created_at,updated_at
  ) VALUES (?,?,?,'ACTIVE',?,?,?,1,?,?)`).run(id, kitAssetId, personId, now, context.user.id, notes, now, now);
  db.prepare("UPDATE kit_definition SET ownership_mode='PERSONAL',version=version+1,updated_at=? WHERE kit_asset_id=? AND ownership_mode<>'PERSONAL'").run(now, kitAssetId);
  const assignment = db.prepare(`SELECT kpa.*,p.full_name,p.employee_number,p.sector,ua.username
    FROM kit_person_assignment kpa JOIN person p ON p.id=kpa.person_id LEFT JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
    WHERE kpa.id=?`).get(id);
  insertAssignmentEvent(db, assignment, 'ASSIGNED', context, input.reason || notes || 'Asignación nominal de kit', { mechanicUsername: mechanic.username, roleCodes: mechanic.roleCodes });
  audit(db, context, current ? 'KIT.REASSIGN_PERSON' : 'KIT.ASSIGN_PERSON', 'kit_person_assignment', id, current || null, assignment, input.reason || notes);
  return assignment;
}

function assignKitToPerson(kitAssetId, input, context) {
  return transaction((db) => assignKitToPersonInDb(db, kitAssetId, input, context));
}

function unassignKit(kitAssetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, kitAssetId, 'Kits.Manage', db);
    getKitRow(db, kitAssetId);
    const current = getActiveAssignment(db, kitAssetId);
    if (!current) throw error(404, 'KIT_ASSIGNMENT_NOT_FOUND', 'El kit no posee una asignación activa.');
    const openCustody = activeOpenCustody(db, kitAssetId);
    if (openCustody) throw error(409, 'KIT_UNASSIGN_OPEN_CUSTODY', `El kit mantiene una custodia abierta de ${openCustody.full_name}.`);
    const closed = closeAssignmentInDb(db, current, context, input.reason);
    releaseAllKitMembershipsInDb(db, kitAssetId, context, input.reason || 'Liberación de componentes al desasignar kit');
    audit(db, context, 'KIT.UNASSIGN_PERSON', 'kit_person_assignment', closed.id, current, closed, input.reason);
    return closed;
  });
}

function closeActiveAssignmentForKitLifecycleInDb(db, kitAssetId, context, reason = 'Cierre automático por cambio de ciclo de vida del kit') {
  const current = getActiveAssignment(db, kitAssetId);
  let closed = null;
  if (current) {
    closed = closeAssignmentInDb(db, current, context, reason);
    audit(db, context, 'KIT.UNASSIGN_PERSON_AUTO', 'kit_person_assignment', closed.id, current, closed, reason);
  }
  releaseAllKitMembershipsInDb(db, kitAssetId, context, reason);
  return closed;
}

function getKitAssignmentDetail(kitAssetId, user, permission = 'Kits.Read') {
  const db = getDb();
  assertAssetScope(user, kitAssetId, permission, db);
  const kit = getKitRow(db, kitAssetId);
  const assignment = kit.active && kit.status !== 'BAJA' ? getActiveAssignment(db, kitAssetId) : null;
  const history = db.prepare(`SELECT e.*,p.full_name,ua.username AS actor_username
    FROM kit_person_assignment_event e
    JOIN person p ON p.id=e.person_id
    JOIN user_account ua ON ua.id=e.actor_user_id
    WHERE e.kit_asset_id=? ORDER BY e.occurred_at DESC`).all(kitAssetId);
  return { kit, assignment, history };
}

function assertPersonalKitRequester(db, kitAssetId, personId) {
  const definition = db.prepare('SELECT ownership_mode FROM kit_definition WHERE kit_asset_id=?').get(kitAssetId);
  if (!definition || definition.ownership_mode !== 'PERSONAL') return true;
  const assignment = db.prepare("SELECT person_id FROM kit_person_assignment WHERE kit_asset_id=? AND status='ACTIVE'").get(kitAssetId);
  if (!assignment) throw error(409, 'KIT_PERSONAL_UNASSIGNED', 'Este kit es personal y todavía no tiene un mecánico asignado.');
  if (assignment.person_id !== personId) throw error(403, 'KIT_ASSIGNED_TO_OTHER_PERSON', 'Este kit está asignado a otro mecánico.');
  return true;
}

function isPersonalKitAvailableToPerson(db, kitAssetId, personId) {
  const definition = db.prepare('SELECT ownership_mode FROM kit_definition WHERE kit_asset_id=?').get(kitAssetId);
  if (!definition || definition.ownership_mode !== 'PERSONAL') return true;
  const assignment = db.prepare("SELECT person_id FROM kit_person_assignment WHERE kit_asset_id=? AND status='ACTIVE'").get(kitAssetId);
  return Boolean(assignment && assignment.person_id === personId);
}

function personalKitReservationForComponent(db, componentAssetId) {
  return db.prepare(`SELECT kpa.kit_asset_id,kpa.person_id,p.full_name,ka.internal_code AS kit_code,ka.description AS kit_description
    FROM kit_component kc
    JOIN kit_person_assignment kpa ON kpa.kit_asset_id=kc.kit_asset_id AND kpa.status='ACTIVE'
    JOIN kit_definition kd ON kd.kit_asset_id=kpa.kit_asset_id AND kd.ownership_mode='PERSONAL'
    JOIN person p ON p.id=kpa.person_id
    JOIN asset ka ON ka.id=kpa.kit_asset_id
    WHERE kc.component_asset_id=? AND kc.active=1
      AND ka.deleted_at IS NULL AND ka.active=1 AND ka.status<>'BAJA'
    ORDER BY kpa.assigned_at DESC LIMIT 1`).get(componentAssetId) || null;
}

function isAssetReservedByPersonalKit(db, componentAssetId) {
  return Boolean(personalKitReservationForComponent(db, componentAssetId));
}

function assertAssetNotReservedByPersonalKit(db, componentAssetId) {
  const reserved = personalKitReservationForComponent(db, componentAssetId);
  if (reserved) throw error(409, 'ASSET_IN_PERSONAL_KIT', `La herramienta forma parte del kit personal ${reserved.kit_code} asignado a ${reserved.full_name}.`);
  return true;
}

function listOwnPersonalKits(personId) {
  const db = getDb();
  const rows = db.prepare(`SELECT kpa.id AS assignment_id,kpa.assigned_at,kpa.assignment_notes,kpa.version AS assignment_version,
      a.id AS kit_asset_id,a.internal_code,a.serial_number,a.description,a.status,a.location_id,a.photo_evidence_id,
      kd.ownership_mode,kd.version AS definition_version,sl.code AS location_code,sl.name AS location_name,s.name AS site_name
    FROM kit_person_assignment kpa
    JOIN asset a ON a.id=kpa.kit_asset_id
    JOIN kit_definition kd ON kd.kit_asset_id=a.id
    JOIN storage_location sl ON sl.id=a.location_id
    JOIN site s ON s.id=sl.site_id
    WHERE kpa.person_id=? AND kpa.status='ACTIVE' AND a.deleted_at IS NULL
      AND a.active=1 AND a.status<>'BAJA'
    ORDER BY a.internal_code`).all(personId);
  return rows.map((row) => ({
    ...row,
    photoAvailable: Boolean(row.photo_evidence_id),
    photoUrl: row.photo_evidence_id ? `/api/v1/operation/assets/${encodeURIComponent(row.kit_asset_id)}/photo` : null,
    components: db.prepare(`SELECT kc.component_asset_id,kc.required_quantity,kc.mandatory,kc.sequence,
        a.internal_code,a.description,a.serial_number,a.status,a.unit_of_measure,a.photo_evidence_id,c.name AS category_name,c.nature AS category_nature
      FROM kit_component kc JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id
      WHERE kc.kit_asset_id=? AND kc.active=1 ORDER BY kc.sequence,a.internal_code`).all(row.kit_asset_id).map((item) => ({
        ...item,
        photoAvailable: Boolean(item.photo_evidence_id),
        photoUrl: item.photo_evidence_id ? `/api/v1/operation/assets/${encodeURIComponent(item.component_asset_id)}/photo` : null
      }))
  }));
}

function nextControlNumber(db, date = new Date()) {
  const year = date.getUTCFullYear();
  const n = db.prepare('SELECT COUNT(*) AS n FROM kit_inventory_control WHERE control_number LIKE ?').get(`KIC-${year}-%`).n + 1;
  return `KIC-${year}-${String(n).padStart(6, '0')}`;
}

function inventoryControlSnapshot(db, controlId) {
  const control = db.prepare('SELECT * FROM kit_inventory_control WHERE id=?').get(controlId);
  if (!control) return null;
  const items = db.prepare('SELECT * FROM kit_inventory_control_item WHERE control_id=? ORDER BY sequence,component_code_snapshot').all(controlId);
  return { control, items };
}

function buildInventoryPrintHtml(snapshot) {
  const { control, items } = snapshot;
  const rows = items.map((item) => `<tr>
    <td>${item.sequence}</td><td><strong>${esc(item.component_code_snapshot)}</strong><br><span>${esc(item.component_description_snapshot)}</span></td>
    <td>${esc(item.component_serial_snapshot || '—')}</td><td>${esc(item.expected_quantity)}</td><td>${item.mandatory ? 'Sí' : 'No'}</td>
    <td class="blank"></td><td class="blank"></td><td class="blank wide"></td>
  </tr>`).join('');
  const assigned = control.person_name_snapshot || 'SIN ASIGNACIÓN NOMINAL';
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${esc(control.control_number)} · ${esc(control.kit_code_snapshot)}</title>
<style>@page{size:A4;margin:12mm}*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;color:#17212b;margin:0;font-size:11px}header{display:flex;justify-content:space-between;gap:20px;border-bottom:2px solid #17212b;padding-bottom:8px;margin-bottom:12px}h1{font-size:18px;margin:0 0 3px}h2{font-size:14px;margin:14px 0 6px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:5px 18px;margin:8px 0}.meta div{border-bottom:1px solid #ccd5dd;padding:4px 0}.label{font-size:9px;color:#586775;text-transform:uppercase;font-weight:700}table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border:1px solid #7f8d99;padding:5px;vertical-align:top}th{background:#eef2f5;font-size:9px;text-transform:uppercase}.blank{height:28px;min-width:48px}.wide{min-width:100px}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:35px;margin-top:45px}.signature{border-top:1px solid #333;padding-top:5px;text-align:center}.notes{border:1px solid #7f8d99;min-height:54px;padding:6px;margin-top:8px}.no-print{margin-bottom:10px}@media print{.no-print{display:none}}</style></head><body>
<div class="no-print"><button onclick="window.print()">IMPRIMIR</button></div>
<header><div><h1>CONTROL DE KIT DE HERRAMIENTAS</h1><strong>${esc(control.kit_code_snapshot)} · ${esc(control.kit_description_snapshot)}</strong></div><div><strong>${esc(control.control_number)}</strong><br>${esc(new Date(control.generated_at).toLocaleString('es-AR'))}</div></header>
<div class="meta"><div><span class="label">Mecánico</span><br><strong>${esc(assigned)}</strong></div><div><span class="label">Legajo</span><br>${esc(control.employee_number_snapshot || '—')}</div><div><span class="label">Sector</span><br>${esc(control.sector_snapshot || '—')}</div><div><span class="label">Serie del kit</span><br>${esc(control.kit_serial_snapshot || '—')}</div></div>
<h2>Inventario esperado</h2><table><thead><tr><th>#</th><th>Herramienta / componente</th><th>Serie</th><th>Cant. esperada</th><th>Oblig.</th><th>Cant. real</th><th>Estado</th><th>Observación</th></tr></thead><tbody>${rows || '<tr><td colspan="8">Sin componentes.</td></tr>'}</tbody></table>
<h2>Observaciones del control</h2><div class="notes">${esc(control.notes || '')}</div>
<div class="signatures"><div class="signature">Mecánico / responsable del kit</div><div class="signature">Control de pañol / supervisor</div></div>
</body></html>`;
}

function createKitInventoryControl(kitAssetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, kitAssetId, 'Kits.Read', db);
    const kit = getKitRow(db, kitAssetId);
    const assignment = getActiveAssignment(db, kitAssetId);
    if (assignment && assignment.person_id !== context.user.personId && !hasPermission(context.user, 'Kits.Manage')) {
      throw error(403, 'KIT_INVENTORY_CONTROL_FORBIDDEN', 'Sólo el mecánico asignado o un administrador de kits puede generar este control.');
    }
    if (!assignment && !hasPermission(context.user, 'Kits.Manage')) throw error(403, 'KIT_INVENTORY_CONTROL_FORBIDDEN', 'El kit no está asignado a este usuario.');
    const components = db.prepare(`SELECT kc.component_asset_id,kc.required_quantity,kc.mandatory,kc.sequence,
        a.internal_code,a.description,a.serial_number,a.status,a.location_id,c.name AS category_name,
        sl.code AS location_code,sl.name AS location_name
      FROM kit_component kc
      JOIN asset a ON a.id=kc.component_asset_id
      JOIN asset_category c ON c.id=a.category_id
      JOIN storage_location sl ON sl.id=a.location_id
      WHERE kc.kit_asset_id=? AND kc.active=1 ORDER BY kc.sequence,a.internal_code`).all(kitAssetId);
    if (!components.length) throw error(409, 'KIT_COMPONENTS_REQUIRED', 'El kit no posee componentes activos para inventariar.');
    const now = nowIso();
    const id = randomUUID();
    const number = nextControlNumber(db);
    const notes = optionalString(input?.notes, 'notes', { max: 2000 });
    db.prepare(`INSERT INTO kit_inventory_control(
      id,control_number,kit_asset_id,assignment_id,person_id,kit_code_snapshot,kit_description_snapshot,kit_serial_snapshot,
      person_name_snapshot,employee_number_snapshot,sector_snapshot,component_count,definition_version,generated_by_user_id,generated_at,notes,correlation_id,created_at
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      id, number, kitAssetId, assignment?.id || null, assignment?.person_id || null, kit.internal_code, kit.description, kit.serial_number || null,
      assignment?.full_name || null, assignment?.employee_number || null, assignment?.sector || null, components.length, kit.definition_version,
      context.user.id, now, notes, context.correlationId, now
    );
    const insertItem = db.prepare(`INSERT INTO kit_inventory_control_item(
      id,control_id,component_asset_id,component_code_snapshot,component_description_snapshot,component_serial_snapshot,component_category_snapshot,
      expected_quantity,mandatory,sequence,asset_status_snapshot,asset_location_snapshot,created_at
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const component of components) insertItem.run(
      randomUUID(), id, component.component_asset_id, component.internal_code, component.description, component.serial_number || null, component.category_name,
      component.required_quantity, component.mandatory ? 1 : 0, component.sequence, component.status,
      `${component.location_code} · ${component.location_name}`, now
    );
    const snapshot = inventoryControlSnapshot(db, id);
    audit(db, context, 'KIT.INVENTORY_CONTROL_CREATE', 'kit_inventory_control', id, null, snapshot.control, notes);
    return { ...snapshot, printHtml: buildInventoryPrintHtml(snapshot) };
  });
}

function listKitInventoryControls(kitAssetId, user) {
  const db = getDb();
  assertAssetScope(user, kitAssetId, 'Kits.Read', db);
  return db.prepare(`SELECT kic.*,ua.username AS generated_by_username
    FROM kit_inventory_control kic JOIN user_account ua ON ua.id=kic.generated_by_user_id
    WHERE kic.kit_asset_id=? ORDER BY kic.generated_at DESC LIMIT 100`).all(kitAssetId);
}

module.exports = {
  getActiveAssignment,
  listEligibleMechanics,
  assignKitToPerson,
  assignKitToPersonInDb,
  unassignKit,
  closeActiveAssignmentForKitLifecycleInDb,
  closeStaleInactiveKitAssignmentsForComponentsInDb,
  getKitAssignmentDetail,
  assertPersonalKitRequester,
  isPersonalKitAvailableToPerson,
  personalKitReservationForComponent,
  isAssetReservedByPersonalKit,
  assertAssetNotReservedByPersonalKit,
  listOwnPersonalKits,
  createKitInventoryControl,
  listKitInventoryControls,
  buildInventoryPrintHtml
};
