'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const runtime = require('../config/runtime');

const IDENTITY_SCHEMA = 'IWC_SERVER_IDENTITY_V1';
const IDENTITY_FILE = 'server-identity.json';
let cached = null;

function identityPath() {
  return path.join(runtime.dataDir, IDENTITY_FILE);
}

function validUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ''));
}

function readExisting(filePath) {
  try {
    const value = JSON.parse(fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, ''));
    if (value?.schema !== IDENTITY_SCHEMA || !validUuid(value?.instanceId)) return null;
    return Object.freeze({
      schema: IDENTITY_SCHEMA,
      instanceId: value.instanceId,
      createdAt: value.createdAt || null,
      persistent: true
    });
  } catch {
    return null;
  }
}

function writeAtomic(filePath, payload) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(payload, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temporary, filePath);
}

function fallbackIdentity() {
  const seed = `${os.hostname()}|${runtime.dataDir}|${runtime.sourceVersion}`;
  const digest = crypto.createHash('sha256').update(seed, 'utf8').digest('hex');
  return Object.freeze({
    schema: IDENTITY_SCHEMA,
    instanceId: `volatile-${digest.slice(0, 24)}`,
    createdAt: null,
    persistent: false
  });
}

function getServerIdentity() {
  if (cached) return { ...cached };
  const filePath = identityPath();
  const existing = readExisting(filePath);
  if (existing) {
    cached = existing;
    return { ...cached };
  }

  const payload = {
    schema: IDENTITY_SCHEMA,
    instanceId: crypto.randomUUID(),
    createdAt: new Date().toISOString()
  };
  try {
    writeAtomic(filePath, payload);
    cached = Object.freeze({ ...payload, persistent: true });
  } catch {
    cached = fallbackIdentity();
  }
  return { ...cached };
}

function resetForTests() {
  cached = null;
}

module.exports = {
  IDENTITY_SCHEMA,
  IDENTITY_FILE,
  getServerIdentity,
  resetForTests
};
