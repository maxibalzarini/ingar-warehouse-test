'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, requiredArray } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const { resolvePolicy } = require('./request-policy-service');
const { evaluateOperationalBlocks, assertOperationAllowed, consumeExceptions } = require('./incident-service');
const { getKitOperationalStatus, assertKitOperationallyComplete } = require('./kit-operational-control-service');
const { assertPersonalKitRequester, isPersonalKitAvailableToPerson, isAssetReservedByPersonalKit, assertAssetNotReservedByPersonalKit } = require('./kit-personal-service');
const { userHasScope, assertUserScope, scopeWhere } = require('../security/scope');
const { canSelfApproveOwnRequest } = require('../config/operational-model');
const { diagnoseAssetRequestAvailabilityRow } = require('./asset-service');

const OPEN_EDITABLE = new Set(['PENDIENTE_AUTORIZACION', 'BLOQUEADA']);
const FINAL = new Set(['CANCELADA', 'EXPIRADA', 'ENTREGADA']);
const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);

function error(status, code, message, fieldErrors = []) { return Object.assign(new Error(message), { status, code, fieldErrors }); }
function iso(value, field, { required = false } = {}) {
  if ((value === null || value === undefined || value === '') && !required) return null;
  const date = new Date(value); if (!Number.isFinite(date.getTime())) throw error(422, 'DATE_INVALID', `Fecha inválida: ${field}.`, [{ field, message: 'Fecha y hora inválidas.' }]);
  return date.toISOString();
}
function quantity(value, field = 'quantity') { const n = Number(value); if (!Number.isFinite(n) || n <= 0) throw error(422, 'QUANTITY_INVALID', 'Cantidad inválida.', [{ field, message: 'Debe ser mayor que cero.' }]); return n; }

function workOrder(value, field = 'workOrderReference') {
  const text = String(value ?? '').trim();
  if (!text) throw error(422, 'WORK_ORDER_REQUIRED', 'Ingresá la OT antes de enviar el pedido.', [{ field, message: 'La OT es obligatoria.' }]);
  if (text.length > 120 || !/^[A-Za-z0-9][A-Za-z0-9 ._:/#-]*$/.test(text)) throw error(422, 'WORK_ORDER_REFERENCE_INVALID', 'La OT no tiene un formato válido.', [{ field, message: 'Usá hasta 120 caracteres: letras, números, espacio, punto, guion, guion bajo, /, :, #.' }]);
  return text;
}

function optionalWorkOrder(value, field = 'workOrderReference') {
  const text = String(value ?? '').trim();
  return text ? workOrder(text, field) : null;
}

function requireScope(user, siteId, locationId = null, permission = null) {
  assertUserScope(user, siteId, locationId, permission);
}

function expireReservations(db = getDb(), now = new Date().toISOString(), context = null) {
  const expiredRequests = db.prepare(`SELECT DISTINCT r.id,r.status FROM asset_reservation ar JOIN "request" r ON r.id = ar.request_id
    WHERE ar.status = 'ACTIVA' AND ar.expires_at <= ? AND r.status IN ('PENDIENTE_AUTORIZACION','APROBADA','PREPARANDO','LISTA_PARA_ENTREGA')`).all(now);
  for (const item of expiredRequests) {
    releaseReservations(db, item.id, 'EXPIRACION', 'EXPIRADA');
    db.prepare(`UPDATE request_preparation SET status='CANCELADA',version=version+1,updated_at=? WHERE request_id=? AND status IN ('EN_PREPARACION','LISTA')`).run(now,item.id);
    db.prepare(`UPDATE "request" SET status='EXPIRADA', version=version+1, updated_at=? WHERE id=? AND status=?`).run(now, item.id, item.status);
    addStatusEvent(db, item.id, item.status, 'EXPIRADA', context?.user?.id || null, 'Reserva vencida automáticamente.', context?.correlationId || randomUUID(), now);
  }
  return expiredRequests.length;
}

function addStatusEvent(db, requestId, fromStatus, toStatus, actorUserId, reason, correlationId, now = new Date().toISOString()) {
  db.prepare(`INSERT INTO request_status_event(id, request_id, from_status, to_status, actor_user_id, reason, occurred_at, correlation_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(randomUUID(), requestId, fromStatus || null, toStatus, actorUserId || null, reason || null, now, correlationId, now);
}

function nextRequestNumber(db, now = new Date()) {
  const year = now.getUTCFullYear();
  const count = db.prepare('SELECT COUNT(*) AS n FROM "request" WHERE request_number LIKE ?').get(`SOL-${year}-%`).n + 1;
  return `SOL-${year}-${String(count).padStart(6, '0')}`;
}

function listAvailableAssetsPage(filters, user) {
  expireReservations();
  const db = getDb();
  const where = ["a.deleted_at IS NULL", 'a.active = 1', "a.status = 'DISPONIBLE'", 'a.quantity_available > 0', 'c.deleted_at IS NULL', 'c.active = 1', 'sl.active = 1', 's.active = 1', `EXISTS (SELECT 1 FROM site_asset_category sac WHERE sac.site_id=s.id AND sac.category_id=c.id AND sac.active=1)`];
  const params = [];
  const scope = scopeWhere(user, 'Requests.Availability', 's.id', 'sl.id', db);
  where.push(`(${scope.sql})`);
  params.push(...scope.params);
  if (filters.siteId) { where.push('s.id = ?'); params.push(filters.siteId); }
  if (filters.locationId) { where.push('sl.id = ?'); params.push(filters.locationId); }
  if (filters.categoryId) { where.push('c.id = ?'); params.push(filters.categoryId); }
  if (filters.assetId) { where.push('a.id = ?'); params.push(filters.assetId); }
  if (filters.nature) { where.push('c.nature = ?'); params.push(String(filters.nature).toUpperCase()); }
  if (filters.natures) { const natures = String(filters.natures).split(',').map((value) => value.trim().toUpperCase()).filter(Boolean); if (natures.length) { where.push(`c.nature IN (${natures.map(() => '?').join(',')})`); params.push(...natures); } }
  if (filters.search) { where.push('(a.internal_code LIKE ? OR a.serial_number LIKE ? OR a.description LIKE ? OR a.license_plate LIKE ?)'); const q = `%${String(filters.search).trim()}%`; params.push(q, q, q, q); }
  const limit = Math.min(250, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const fromSql = 'FROM asset a JOIN asset_category c ON c.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const selectSql = `SELECT a.id, a.internal_code, a.serial_number, a.description, a.brand, a.model, a.status, a.quantity_total, a.quantity_available, a.unit_of_measure, a.license_plate, a.requires_work_order, a.photo_evidence_id,
      a.active, a.deleted_at, a.source_import_batch_id, a.location_id, c.id AS category_id, c.code AS category_code, c.name AS category_name, c.nature AS category_nature, c.requires_return,
      sl.code AS location_code, sl.name AS location_name, sl.active AS location_active,
      s.id AS site_id, s.code AS site_code, s.name AS site_name, s.active AS site_active,
      EXISTS (SELECT 1 FROM site_asset_category sac2 WHERE sac2.site_id=s.id AND sac2.category_id=c.id AND sac2.active=1) AS category_enabled_in_site`;
  const operationType = String(filters.operationType || 'RETIRO').toUpperCase();
  const now = new Date().toISOString();
  const potentialBlock = db.prepare(`SELECT 1 FROM operational_block
    WHERE status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?)
      AND ((target_type='PERSONA' AND target_id=?) OR target_type IN ('ACTIVO','CATEGORIA'))
    LIMIT 1`).get(now, now, user.personId);

  const items = [];
  let total = 0;
  for (const item of db.prepare(`${selectSql} ${fromSql} ${whereSql} ORDER BY c.name,a.internal_code`).iterate(...params)) {
    if (diagnoseAssetRequestAvailabilityRow(db, item).blockers.length) continue;
    if (item.category_nature === 'KIT' && !isPersonalKitAvailableToPerson(db, item.id, user.personId)) continue;
    if (potentialBlock) {
      const allowed = evaluateOperationalBlocks(db, {
        personId: user.personId,
        asset: { ...item, category_id: item.category_id },
        operationType,
        siteId: item.site_id,
        locationId: item.location_id
      }).allowed;
      if (!allowed) continue;
    }
    if (total >= offset && items.length < limit) items.push(item);
    total += 1;
  }
  return { items, total, limit, offset };
}

function listAvailableAssets(filters, user) {
  return listAvailableAssetsPage(filters, user).items;
}

function loadAssetForRequest(db, assetId) {
  return db.prepare(`SELECT a.*, c.code AS category_code, c.name AS category_name, c.nature AS category_nature, c.requires_return,
      sl.site_id, sl.active AS location_active, s.active AS site_active,
      EXISTS (SELECT 1 FROM site_asset_category sac WHERE sac.site_id=s.id AND sac.category_id=c.id AND sac.active=1) AS category_enabled_in_site
    FROM asset a JOIN asset_category c ON c.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id
    WHERE a.id=? AND a.deleted_at IS NULL AND c.deleted_at IS NULL`).get(assetId);
}

function normalizeRequest(input, user, db, options = {}) {
  const operationType = String(input.operationType || '').toUpperCase();
  if (!['RETIRO', 'RESERVA'].includes(operationType)) throw error(422, 'REQUEST_OPERATION_INVALID', 'Operación inválida.');
  const siteId = requiredString(input.siteId, 'siteId', { min: 8, max: 80 });
  const locationId = requiredString(input.locationId, 'locationId', { min: 8, max: 80 });
  const location = db.prepare('SELECT sl.*, s.active AS site_active FROM storage_location sl JOIN site s ON s.id=sl.site_id WHERE sl.id=? AND sl.site_id=?').get(locationId, siteId);
  if (!location || !location.active || !location.site_active) throw error(422, 'REQUEST_LOCATION_INVALID', 'Sede o ubicación inválida.');
  requireScope(user, siteId, locationId, 'Requests.Create');
  const now = Date.now(); const neededAt = iso(input.neededAt || new Date().toISOString(), 'neededAt', { required: true });
  if (new Date(neededAt).getTime() < now - 5 * 60_000 || new Date(neededAt).getTime() > now + 365 * 24 * 3600_000) throw error(422, 'REQUEST_NEEDED_AT_INVALID', 'La fecha requerida está fuera del rango permitido.');
  const dueAt = iso(input.dueAt, 'dueAt');
  if (dueAt && new Date(dueAt) <= new Date(neededAt)) throw error(422, 'REQUEST_DUE_AT_INVALID', 'La devolución prevista debe ser posterior a la fecha requerida.');
  const reasonInput = String(input.reason || '').trim();
  if (reasonInput.length > 1000) throw error(422, 'REQUEST_REASON_INVALID', 'El comentario no puede superar 1000 caracteres.');
  const suppliedWorkOrderReference = input.workOrderReference ?? input.work_order_reference;
  const maxItems = Number(getSetting('request.maxItems', 20));
  const rawItems = requiredArray(input.items, 'items', maxItems); if (!rawItems.length) throw error(422, 'REQUEST_ITEMS_REQUIRED', 'Debe seleccionar al menos un bien.');
  const seen = new Set(); const items = []; const exceptionIds = []; let requiresApproval = false; let serializedRequested = false; const approvalReasons = [];
  for (const raw of rawItems) {
    const assetId = requiredString(raw.assetId, 'assetId', { min: 8, max: 80 });
    if (seen.has(assetId)) throw error(422, 'REQUEST_ITEM_DUPLICATE', 'Un bien no puede repetirse en la misma solicitud.'); seen.add(assetId);
    const asset = loadAssetForRequest(db, assetId); const qty = quantity(raw.quantity || 1);
    if (!asset || !asset.active || !asset.location_active || !asset.site_active || !asset.category_enabled_in_site || asset.site_id !== siteId || asset.location_id !== locationId) throw error(422, 'ASSET_NOT_AVAILABLE', 'El bien no pertenece a la sede y ubicación seleccionadas o su categoría no está habilitada en esa sede.');
    requireScope(user, asset.site_id, asset.location_id, 'Requests.Create');
    // La creación debe usar el mismo diagnóstico autoritativo que alimenta Mi operación.
    // Así una card nunca puede decir DISPONIBLE mientras el backend conoce una reserva,
    // custodia, bloqueo, mantenimiento, incidente o inconsistencia que impide pedirla.
    const availability = diagnoseAssetRequestAvailabilityRow(db, asset);
    if (availability.blockers.length || asset.quantity_available < qty) {
      const detail = availability.blockers[0]?.detail || `No está disponible en la cantidad solicitada.`;
      throw error(409, 'ASSET_NOT_AVAILABLE', `${asset.internal_code}: ${detail}`);
    }
    if (asset.category_nature === 'KIT') {
      assertKitOperationallyComplete(db, asset.id, 'solicitud o reserva');
      assertPersonalKitRequester(db, asset.id, user.personId);
    } else {
      assertAssetNotReservedByPersonalKit(db, asset.id);
    }
    const blockEvaluation = assertOperationAllowed(db, { personId: user.personId, asset, operationType, siteId, locationId, requestId: options.requestId || null });
    exceptionIds.push(...blockEvaluation.exceptions.map((item) => item.id));
    if (SERIAL_NATURES.has(asset.category_nature) && qty !== 1) throw error(422, 'SERIAL_QUANTITY_INVALID', `El bien ${asset.internal_code} requiere cantidad 1.`);
    if (SERIAL_NATURES.has(asset.category_nature)) serializedRequested = true;
    const policy = resolvePolicy(asset, operationType, siteId, db);
    if (policy?.max_quantity && qty > policy.max_quantity) throw error(422, 'POLICY_MAX_QUANTITY', `La cantidad de ${asset.internal_code} supera el máximo permitido por ${policy.name}.`);
    if (policy?.max_duration_hours && dueAt && (new Date(dueAt) - new Date(neededAt)) / 3600_000 > policy.max_duration_hours) throw error(422, 'POLICY_MAX_DURATION', `La duración solicitada supera la política ${policy.name}.`);
    if (policy?.requires_approval || asset.category_nature === 'VEHICULO' || operationType === 'RESERVA') { requiresApproval = true; approvalReasons.push(policy?.name || (operationType === 'RESERVA' ? 'Toda reserva requiere autorización.' : 'Los vehículos requieren autorización.')); }
    items.push({ asset, quantity: qty, policy, workOrderRequired: Boolean(asset.requires_work_order) });
  }
  const requiresWorkOrder = items.some((item) => item.workOrderRequired);
  const workOrderReference = requiresWorkOrder ? workOrder(suppliedWorkOrderReference) : optionalWorkOrder(suppliedWorkOrderReference);
  for (const item of items) item.workOrderReference = workOrderReference;
  if (serializedRequested && !dueAt) throw error(422, 'SERIAL_DUE_AT_REQUIRED', 'Indicá cuándo pensás devolver el bien serializado.');
  // F7: un SOLICITANTE puede pedir, pero nunca puede quedar autoaprobado por una regla automática.
  // Los roles habilitados para autoaprobarse conservan ese comportamiento.
  if (!canSelfApproveOwnRequest(user.roleCodes)) {
    requiresApproval = true;
    approvalReasons.push('Requiere autorización del pañol.');
  }
  const reason = reasonInput;
  const reservationHours = Number(getSetting('request.defaultReservationHours', 24));
  const expiresAt = dueAt || new Date(Math.max(new Date(neededAt).getTime() + reservationHours * 3600_000, now + reservationHours * 3600_000)).toISOString();
  return { operationType, siteId, locationId, neededAt, dueAt, reason, workOrderReference, items, exceptionIds: [...new Set(exceptionIds)], requiresApproval, approvalReason: [...new Set(approvalReasons)].join(' '), reservationExpiresAt: expiresAt };
}

function reserveRequest(db, requestId, now, context) {
  const request = db.prepare('SELECT * FROM "request" WHERE id=?').get(requestId);
  const items = db.prepare('SELECT * FROM request_item WHERE request_id=? ORDER BY created_at').all(requestId);
  for (const item of items) {
    const asset = loadAssetForRequest(db, item.asset_id);
    if (asset) assertOperationAllowed(db, { personId: request.requester_person_id, asset, operationType: request.operation_type, siteId: request.site_id, locationId: request.location_id, requestId });
    if (!asset || !asset.active || asset.status !== 'DISPONIBLE' || Number(asset.quantity_available) < Number(item.quantity)) {
      throw error(409, 'ASSET_RESERVATION_CONFLICT', `${asset?.description || 'Bien'} código ${asset?.internal_code || item.asset_id} — ya fue solicitado por otro usuario o dejó de estar disponible.`);
    }
    if (asset.category_nature === 'KIT') assertKitOperationallyComplete(db, asset.id, 'reserva');
    try {
      db.prepare(`INSERT INTO asset_reservation(id,request_id,request_item_id,asset_id,quantity,starts_at,expires_at,status,created_at,updated_at,work_order_reference_snapshot)
        VALUES (?,?,?,?,?,?,?,'ACTIVA',?,?,?)`).run(randomUUID(),requestId,item.id,asset.id,item.quantity,now,request.reservation_expires_at,now,now,item.work_order_reference || null);
    } catch (cause) {
      const message = String(cause?.message || '');
      if (message.includes('KIT_COMPONENT_RESERVED_BY_KIT')) throw error(409,'KIT_COMPONENT_RESERVED',`${asset.description} código ${asset.internal_code} — pertenece a un kit reservado.`);
      if (message.includes('KIT_COMPONENT_NOT_AVAILABLE')) throw error(409,'KIT_COMPONENT_NOT_AVAILABLE',`${asset.description} código ${asset.internal_code} — uno de sus componentes ya está reservado o en custodia.`);
      if (message.includes('ASSET_RESERVATION_NOT_AVAILABLE')) throw error(409,'ASSET_RESERVATION_CONFLICT',`${asset.description} código ${asset.internal_code} — ya fue solicitado por otro usuario o dejó de estar disponible.`);
      throw cause;
    }
    db.prepare("UPDATE request_item SET status='RESERVADO', updated_at=? WHERE id=?").run(now, item.id);
  }
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'REQUEST.RESERVE', entityType: 'request', entityId: requestId, after: { items: items.length, expiresAt: request.reservation_expires_at, workOrderReference: request.work_order_reference }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
}

function releaseReservations(db, requestId, reason, reservationStatus = 'LIBERADA') {
  const rows = db.prepare(`SELECT ar.*, a.version, a.status, a.quantity_available, c.nature AS category_nature
    FROM asset_reservation ar JOIN asset a ON a.id=ar.asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE ar.request_id=? AND ar.status='ACTIVA'`).all(requestId);
  const now = new Date().toISOString();
  for (const row of rows) {
    db.prepare('UPDATE asset_reservation SET status=?, release_reason=?, updated_at=? WHERE id=?').run(reservationStatus, reason, now, row.id);
    db.prepare("UPDATE request_item SET status='CANCELADO', updated_at=? WHERE id=? AND status='RESERVADO'").run(now, row.request_item_id);
  }
  return rows.length;
}

function requestSelect() {
  return `SELECT r.*, p.full_name AS requester_name, p.document_number AS requester_document, s.code AS site_code, s.name AS site_name,
    sl.code AS location_code, sl.name AS location_name, ua.username AS created_by_username
    FROM "request" r JOIN person p ON p.id=r.requester_person_id JOIN site s ON s.id=r.site_id JOIN storage_location sl ON sl.id=r.location_id
    JOIN user_account ua ON ua.id=r.created_by_user_id`;
}

function hydrate(row, db = getDb()) {
  if (!row) return null;
  return {
    ...row,
    items: db.prepare(`SELECT ri.*, a.internal_code, a.description, a.serial_number, a.license_plate, a.category_id, c.code AS category_code, c.name AS category_name, c.nature AS category_nature, c.requires_return, c.requires_inspection, a.unit_of_measure
      FROM request_item ri JOIN asset a ON a.id=ri.asset_id JOIN asset_category c ON c.id=a.category_id WHERE ri.request_id=? ORDER BY a.internal_code`).all(row.id),
    approvals: db.prepare(`SELECT ap.*, ua.username, p.full_name AS approver_name FROM approval ap JOIN user_account ua ON ua.id=ap.approver_user_id JOIN person p ON p.id=ua.person_id WHERE ap.request_id=? ORDER BY ap.decided_at`).all(row.id),
    reservations: db.prepare('SELECT * FROM asset_reservation WHERE request_id=? ORDER BY created_at').all(row.id),
    events: db.prepare(`SELECT rse.*, ua.username FROM request_status_event rse LEFT JOIN user_account ua ON ua.id=rse.actor_user_id WHERE rse.request_id=? ORDER BY rse.occurred_at`).all(row.id),
    preparation: db.prepare('SELECT * FROM request_preparation WHERE request_id=?').get(row.id) || null,
    preparationItems: db.prepare(`SELECT rpi.*, ra.internal_code AS requested_code, pa.internal_code AS prepared_code FROM request_preparation_item rpi
      JOIN request_preparation rp ON rp.id=rpi.preparation_id JOIN asset ra ON ra.id=rpi.requested_asset_id JOIN asset pa ON pa.id=rpi.prepared_asset_id
      WHERE rp.request_id=? ORDER BY rpi.created_at`).all(row.id),
    handovers: db.prepare('SELECT * FROM handover WHERE request_id=? ORDER BY occurred_at').all(row.id),
    evidence: db.prepare(`SELECT id,filename,mime_type,size,created_at,purpose FROM file_evidence
      WHERE owner_type='REQUEST' AND owner_id=? AND lifecycle_state='ACTIVE' ORDER BY created_at`).all(row.id),
    custodies: db.prepare(`SELECT c.*, ac.nature AS category_nature, ac.requires_return, ac.requires_inspection
      FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id
      WHERE c.request_id=? ORDER BY c.opened_at`).all(row.id)
  };
}

function getRequest(id, user, allowAll = false) {
  expireReservations();
  const row = getDb().prepare(`${requestSelect()} WHERE r.id=?`).get(id);
  if (!row) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
  if (!allowAll && row.requester_person_id !== user.personId) throw error(403, 'REQUEST_FORBIDDEN', 'No puede consultar esta solicitud.');
  requireScope(user, row.site_id, row.location_id, allowAll ? 'Requests.ReadAll' : 'Requests.ReadOwn');
  return hydrate(row);
}

function listRequestsPage(filters, user, allowAll = false) {
  expireReservations();
  const db = getDb();
  const where = []; const params = [];
  const permission = allowAll ? 'Requests.ReadAll' : 'Requests.ReadOwn';
  const scope = scopeWhere(user, permission, 'r.site_id', 'r.location_id', db);
  where.push(`(${scope.sql})`); params.push(...scope.params);
  if (!allowAll) { where.push('r.requester_person_id=?'); params.push(user.personId); }
  const statuses = String(filters.statuses || '').split(',').map((value) => value.trim().toUpperCase()).filter(Boolean);
  if (statuses.length) { where.push(`r.status IN (${statuses.map(() => '?').join(',')})`); params.push(...statuses); }
  else if (filters.status) { where.push('r.status=?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.siteId) { where.push('r.site_id=?'); params.push(filters.siteId); }
  if (filters.locationId) { where.push('r.location_id=?'); params.push(filters.locationId); }
  if (filters.overdue === 'true' || filters.overdue === true) { where.push("r.status IN ('PENDIENTE_AUTORIZACION','APROBADA','PREPARANDO','LISTA_PARA_ENTREGA') AND r.needed_at<?"); params.push(new Date().toISOString()); }
  if (filters.neededFrom) { where.push('r.needed_at>=?'); params.push(new Date(filters.neededFrom).toISOString()); }
  if (filters.neededTo) { where.push('r.needed_at<?'); params.push(new Date(filters.neededTo).toISOString()); }
  if (filters.neededBefore) { where.push('r.needed_at<?'); params.push(new Date(filters.neededBefore).toISOString()); }
  if (filters.createdFrom) { where.push('r.created_at>=?'); params.push(new Date(filters.createdFrom).toISOString()); }
  if (filters.createdTo) { where.push('r.created_at<?'); params.push(new Date(filters.createdTo).toISOString()); }
  if (filters.handoverType || filters.handoverFrom || filters.handoverTo) {
    const handoverWhere = ['h.request_id=r.id']; const handoverParams = [];
    if (filters.handoverType) { handoverWhere.push('h.type=?'); handoverParams.push(String(filters.handoverType).toUpperCase()); }
    if (filters.handoverFrom) { handoverWhere.push('h.occurred_at>=?'); handoverParams.push(new Date(filters.handoverFrom).toISOString()); }
    if (filters.handoverTo) { handoverWhere.push('h.occurred_at<?'); handoverParams.push(new Date(filters.handoverTo).toISOString()); }
    where.push(`EXISTS (SELECT 1 FROM handover h WHERE ${handoverWhere.join(' AND ')})`); params.push(...handoverParams);
  }
  if (filters.workOrderReference) { where.push('r.work_order_reference=?'); params.push(String(filters.workOrderReference).trim()); }
  if (filters.search) { where.push('(r.request_number LIKE ? OR p.full_name LIKE ? OR r.reason LIKE ? OR r.work_order_reference LIKE ?)'); const q=`%${filters.search}%`; params.push(q,q,q,q); }
  const limit = Math.min(300, Math.max(1, Number(filters.limit)||100));
  const offset = Math.max(0, Number(filters.offset)||0);
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = Number(db.prepare(`SELECT COUNT(*) AS n FROM "request" r JOIN person p ON p.id=r.requester_person_id JOIN site s ON s.id=r.site_id JOIN storage_location sl ON sl.id=r.location_id JOIN user_account ua ON ua.id=r.created_by_user_id ${whereSql}`).get(...params)?.n || 0);
  const items = db.prepare(`${requestSelect()} ${whereSql} ORDER BY r.created_at DESC LIMIT ? OFFSET ?`).all(...params, limit, offset).map((row) => hydrate(row));
  return { items, total, limit, offset };
}

function listRequests(filters, user, allowAll = false) {
  return listRequestsPage(filters, user, allowAll).items;
}

function createRequest(input, context, options = {}) {
  const clientRequestId = requiredString(input.clientRequestId, 'clientRequestId', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ });
  const existing = getDb().prepare('SELECT id FROM "request" WHERE client_request_id=?').get(clientRequestId);
  if (existing) return { request: getRequest(existing.id, context.user, false), idempotent: true };
  return transaction((db) => {
    const repeated = db.prepare('SELECT id FROM "request" WHERE client_request_id=?').get(clientRequestId);
    if (repeated) {
      const row = db.prepare(`${requestSelect()} WHERE r.id=?`).get(repeated.id);
      if (!row || row.requester_person_id !== context.user.personId || !userHasScope(context.user, row.site_id, row.location_id, 'Requests.ReadOwn', db)) {
        throw error(409, 'CLIENT_REQUEST_ID_CONFLICT', 'El identificador idempotente ya pertenece a otra solicitud.');
      }
      return { request: hydrate(row, db), idempotent: true };
    }
    const now = new Date().toISOString();
    expireReservations(db, now, context);
    const data = normalizeRequest(input, context.user, db); const id = randomUUID();
    const status = data.requiresApproval ? 'PENDIENTE_AUTORIZACION' : 'APROBADA'; const number = nextRequestNumber(db, new Date(now));
    db.prepare(`INSERT INTO "request"(id,request_number,requester_person_id,site_id,location_id,operation_type,status,needed_at,due_at,reservation_expires_at,reason,source,approval_required,approval_reason,client_request_id,created_by_user_id,version,created_at,updated_at,work_order_reference)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)`).run(id, number, context.user.personId, data.siteId, data.locationId, data.operationType, status, data.neededAt, data.dueAt, data.reservationExpiresAt, data.reason, input.source === 'ADMIN' ? 'ADMIN' : 'PORTAL', data.requiresApproval ? 1 : 0, data.approvalReason || null, clientRequestId, context.user.id, now, now, data.workOrderReference);
    for (const item of data.items) db.prepare(`INSERT INTO request_item(id,request_id,asset_id,quantity,status,work_order_required,work_order_reference,created_at,updated_at) VALUES (?,?,?,?, 'VALIDADO',?,?,?,?)`).run(randomUUID(), id, item.asset.id, item.quantity, item.workOrderRequired ? 1 : 0, item.workOrderReference, now, now);
    consumeExceptions(db, data.exceptionIds, id, now);
    addStatusEvent(db, id, null, status, context.user.id, data.requiresApproval ? data.approvalReason : 'Validación automática aprobada.', context.correlationId, now);
    reserveRequest(db, id, now, context);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'REQUEST.CREATE', entityType: 'request', entityId: id, after: { requestNumber: number, status, operationType: data.operationType, itemCount: data.items.length, approvalRequired: data.requiresApproval }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    if (typeof options.afterCreate === 'function') options.afterCreate(db, { id, number, status, data, now });
    return { request: hydrate(db.prepare(`${requestSelect()} WHERE r.id=?`).get(id), db), idempotent: false };
  });
}

function updateRequest(id, input, context, allowAll = false) {
  return transaction((db) => {
    const current = db.prepare(`${requestSelect()} WHERE r.id=?`).get(id); if (!current) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
    if (!allowAll && current.requester_person_id !== context.user.personId) throw error(403, 'REQUEST_FORBIDDEN', 'No puede modificar esta solicitud.');
    requireScope(context.user, current.site_id, current.location_id, allowAll ? 'Requests.UpdateAny' : 'Requests.UpdateOwn');
    const version = Number(input.version); if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La solicitud fue modificada por otra operación.');
    if (!OPEN_EDITABLE.has(current.status)) throw error(409, 'REQUEST_NOT_EDITABLE', 'La solicitud ya no admite modificaciones.');
    if (input.workOrderReference !== undefined && String(input.workOrderReference).trim() !== String(current.work_order_reference || '')) throw error(409,'WORK_ORDER_IMMUTABLE','La OT queda congelada al enviar el pedido.');
    const merged = { operationType: input.operationType ?? current.operation_type, siteId: input.siteId ?? current.site_id, locationId: input.locationId ?? current.location_id, neededAt: input.neededAt ?? current.needed_at, dueAt: input.dueAt === undefined ? current.due_at : input.dueAt, reason: input.reason ?? current.reason, workOrderReference: current.work_order_reference, items: input.items || db.prepare('SELECT asset_id AS assetId, quantity FROM request_item WHERE request_id=?').all(id) };
    const data = normalizeRequest(merged, context.user, db, { requestId: id }); const now = new Date().toISOString(); const status = data.requiresApproval ? 'PENDIENTE_AUTORIZACION' : 'APROBADA';
    releaseReservations(db,id,'REVALIDACION_SOLICITUD','LIBERADA');
    db.prepare('DELETE FROM request_item WHERE request_id=?').run(id);
    for (const item of data.items) db.prepare(`INSERT INTO request_item(id,request_id,asset_id,quantity,status,work_order_required,work_order_reference,created_at,updated_at) VALUES (?,?,?,?, 'VALIDADO',?,?,?,?)`).run(randomUUID(), id, item.asset.id, item.quantity, item.workOrderRequired ? 1 : 0, item.workOrderReference, now, now);
    consumeExceptions(db, data.exceptionIds, id, now);
    const changed = db.prepare(`UPDATE "request" SET site_id=?,location_id=?,operation_type=?,status=?,needed_at=?,due_at=?,reservation_expires_at=?,reason=?,approval_required=?,approval_reason=?,block_code=NULL,block_reason=NULL,version=version+1,updated_at=? WHERE id=? AND version=?`).run(data.siteId,data.locationId,data.operationType,status,data.neededAt,data.dueAt,data.reservationExpiresAt,data.reason,data.requiresApproval?1:0,data.approvalReason||null,now,id,version);
    if (changed.changes !== 1) throw error(409,'CONCURRENCY_CONFLICT','Conflicto de concurrencia en solicitud.');
    addStatusEvent(db,id,current.status,status,context.user.id,'Solicitud modificada y revalidada.',context.correlationId,now);
    reserveRequest(db,id,now,context);
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'REQUEST.UPDATE',entityType:'request',entityId:id,before:current,after:{status,itemCount:data.items.length},correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent},db);
    return hydrate(db.prepare(`${requestSelect()} WHERE r.id=?`).get(id),db);
  });
}

function decideRequest(id, decision, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${requestSelect()} WHERE r.id=?`).get(id); if (!current) throw error(404,'REQUEST_NOT_FOUND','Solicitud no encontrada.');
    requireScope(context.user,current.site_id,current.location_id,'Requests.Approve');
    const version=Number(input.version); if(!Number.isInteger(version)||version!==current.version) throw error(409,'CONCURRENCY_CONFLICT','La solicitud fue modificada por otra operación.');
    if(current.status!=='PENDIENTE_AUTORIZACION') throw error(409,'REQUEST_NOT_PENDING','La solicitud no está pendiente de autorización.');
    if(current.requester_person_id===context.user.personId&&!canSelfApproveOwnRequest(context.user.roleCodes)) throw error(403,'SELF_APPROVAL_FORBIDDEN','Un solicitante común no puede autorizar su propia solicitud.');
    const reason = decision === 'APROBADA'
      ? String(input.reason || '').trim() || 'Aprobación operativa.'
      : requiredString(input.reason,'reason',{min:5,max:1000});
    if (reason.length > 1000) throw error(400,'VALIDATION_ERROR','El motivo no puede superar 1000 caracteres.');
    const now=new Date().toISOString();
    const target=decision==='APROBADA'?'APROBADA':'BLOQUEADA';
    if(decision==='RECHAZADA') releaseReservations(db,id,reason,'LIBERADA');
    db.prepare(`INSERT INTO approval(id,request_id,approver_user_id,decision,reason,decided_at,correlation_id,created_at,work_order_reference_snapshot) VALUES (?,?,?,?,?,?,?,?,?)`).run(randomUUID(),id,context.user.id,decision,reason,now,context.correlationId,now,current.work_order_reference);
    const changed=db.prepare(`UPDATE "request" SET status=?, block_code=?, block_reason=?, version=version+1, updated_at=? WHERE id=? AND version=?`).run(target,decision==='RECHAZADA'?'APPROVAL_REJECTED':null,decision==='RECHAZADA'?reason:null,now,id,version);
    if(changed.changes!==1) throw error(409,'CONCURRENCY_CONFLICT','Conflicto de concurrencia en autorización.');
    addStatusEvent(db,id,current.status,target,context.user.id,reason,context.correlationId,now);
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:`REQUEST.${decision}`,entityType:'request',entityId:id,before:{status:current.status},after:{status:target,reason},correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent,reason},db);
    return hydrate(db.prepare(`${requestSelect()} WHERE r.id=?`).get(id),db);
  });
}

function cancelRequest(id,input,context,allowAny=false){
  return transaction((db)=>{
    const current=db.prepare(`${requestSelect()} WHERE r.id=?`).get(id); if(!current) throw error(404,'REQUEST_NOT_FOUND','Solicitud no encontrada.');
    if(!allowAny&&current.requester_person_id!==context.user.personId) throw error(403,'REQUEST_FORBIDDEN','No puede cancelar esta solicitud.');
    requireScope(context.user,current.site_id,current.location_id,allowAny ? 'Requests.CancelAny' : 'Requests.CancelOwn'); const version=Number(input.version);
    if(!Number.isInteger(version)||version!==current.version) throw error(409,'CONCURRENCY_CONFLICT','La solicitud fue modificada por otra operación.');
    if(FINAL.has(current.status)||['PREPARANDO','LISTA_PARA_ENTREGA'].includes(current.status)) throw error(409,'REQUEST_NOT_CANCELLABLE','La solicitud ya no puede cancelarse.');
    const reason=requiredString(input.reason,'reason',{min:5,max:1000}); const now=new Date().toISOString(); releaseReservations(db,id,reason,'LIBERADA');
    db.prepare("UPDATE request_item SET status='CANCELADO', updated_at=? WHERE request_id=? AND status<>'ENTREGADO'").run(now,id);
    const changed=db.prepare(`UPDATE "request" SET status='CANCELADA',cancelled_at=?,cancellation_reason=?,version=version+1,updated_at=? WHERE id=? AND version=?`).run(now,reason,now,id,version);
    if(changed.changes!==1) throw error(409,'CONCURRENCY_CONFLICT','Conflicto de concurrencia en cancelación.');
    addStatusEvent(db,id,current.status,'CANCELADA',context.user.id,reason,context.correlationId,now);
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'REQUEST.CANCEL',entityType:'request',entityId:id,before:{status:current.status},after:{status:'CANCELADA'},correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent,reason},db);
    return hydrate(db.prepare(`${requestSelect()} WHERE r.id=?`).get(id),db);
  });
}

module.exports={listAvailableAssets,listAvailableAssetsPage,listRequests,listRequestsPage,getRequest,createRequest,updateRequest,decideRequest,cancelRequest,expireReservations,userHasScope,releaseReservations};
