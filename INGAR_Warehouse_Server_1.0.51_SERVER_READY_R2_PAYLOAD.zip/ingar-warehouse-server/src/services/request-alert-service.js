'use strict';

const { getDb } = require('../db/database');
const { enqueueNotification } = require('./notification-service');
const { warehouseOperatorsForScope } = require('./custody-alert-service');

const MONITORED_STATUSES = new Set(['PENDIENTE_AUTORIZACION', 'APROBADA', 'BLOQUEADA', 'PREPARANDO', 'LISTA_PARA_ENTREGA']);

function cancelRequestAlert(db, requestId, exceptUserIds = null) {
  const now = new Date().toISOString();
  const params = [now, requestId];
  let extra = '';
  if (Array.isArray(exceptUserIds) && exceptUserIds.length) {
    extra = ` AND (recipient_user_id IS NULL OR recipient_user_id NOT IN (${exceptUserIds.map(() => '?').join(',')}))`;
    params.push(...exceptUserIds);
  }
  return db.prepare(`UPDATE notification SET status='CANCELADA',updated_at=?
    WHERE entity_type='request' AND entity_id=? AND type='SOLICITUD_ATRASADA'
      AND status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA')${extra}`).run(...params).changes;
}

function loadRequest(db, requestId) {
  return db.prepare(`SELECT r.id,r.request_number,r.status,r.due_at,r.needed_at,r.site_id,r.location_id,
      p.full_name AS requester_name,s.name AS site_name,sl.name AS location_name
    FROM request r JOIN person p ON p.id=r.requester_person_id JOIN site s ON s.id=r.site_id
    JOIN storage_location sl ON sl.id=r.location_id WHERE r.id=?`).get(requestId);
}

function syncRequestOperationalAlert(db = getDb(), requestOrId, nowValue = new Date()) {
  const request = typeof requestOrId === 'string' ? loadRequest(db, requestOrId) : requestOrId;
  if (!request) return { processed: 0, generated: 0, reactivated: 0, cancelled: 0, recipients: 0 };
  const now = nowValue instanceof Date ? nowValue : new Date(nowValue);
  if (!Number.isFinite(now.getTime())) throw new Error('Fecha de sincronización de solicitudes inválida.');
  const operators = warehouseOperatorsForScope(db, request.site_id, request.location_id);
  const operatorIds = operators.map((item) => item.id);
  let cancelled = cancelRequestAlert(db, request.id, operatorIds);
  const needed = request.needed_at ? new Date(request.needed_at) : null;
  const overdue = Boolean(MONITORED_STATUSES.has(request.status) && needed && Number.isFinite(needed.getTime()) && needed.getTime() <= now.getTime());
  if (!overdue) {
    cancelled += cancelRequestAlert(db, request.id);
    return { processed: 1, generated: 0, reactivated: 0, cancelled, recipients: operators.length, overdue: false };
  }
  let generated = 0;
  let reactivated = 0;
  for (const operator of operators) {
    const result = enqueueNotification({
      recipientUserId: operator.id,
      recipientPersonId: operator.person_id,
      type: 'SOLICITUD_ATRASADA',
      subject: `Solicitud atrasada: ${request.request_number}`,
      body: `${request.requester_name} tiene la solicitud ${request.request_number} en estado ${request.status}. La fecha requerida para la entrega fue ${request.needed_at}${request.due_at ? ` y la devolución prevista es ${request.due_at}` : ''}. La entrega todavía no fue confirmada.`,
      entityType: 'request',
      entityId: request.id,
      dedupKey: `solicitud-atrasada:${request.id}:${operator.id}`,
      reactivateCancelled: true
    }, db);
    if (!result.idempotent) generated += 1;
    if (result.reactivated) reactivated += 1;
  }
  return { processed: 1, generated, reactivated, cancelled, recipients: operators.length, overdue: true, missingOperator: operators.length === 0 };
}

function syncAllRequestOperationalAlerts(db = getDb(), now = new Date()) {
  const rows = db.prepare(`SELECT r.id,r.request_number,r.status,r.due_at,r.needed_at,r.site_id,r.location_id,
      p.full_name AS requester_name,s.name AS site_name,sl.name AS location_name
    FROM request r JOIN person p ON p.id=r.requester_person_id JOIN site s ON s.id=r.site_id
    JOIN storage_location sl ON sl.id=r.location_id
    WHERE r.needed_at IS NOT NULL`).all();
  const summary = { processed: 0, generated: 0, reactivated: 0, cancelled: 0, missingOperators: 0 };
  for (const row of rows) {
    const result = syncRequestOperationalAlert(db, row, now);
    summary.processed += result.processed;
    summary.generated += result.generated;
    summary.reactivated += result.reactivated;
    summary.cancelled += result.cancelled;
    if (result.missingOperator) summary.missingOperators += 1;
  }
  return summary;
}

module.exports = { syncRequestOperationalAlert, syncAllRequestOperationalAlerts, cancelRequestAlert };
