'use strict';

const { getDb } = require('../db/database');
const { getSetting } = require('./settings-service');
const { enqueueNotification } = require('./notification-service');
const { userHasScope } = require('../security/scope');

const OPEN_STATUSES = new Set(['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE']);
const OPERATIONAL_TYPES = ['CUSTODIA_PROXIMA', 'CUSTODIA_VENCIDA', 'DEVOLUCION_DECLARADA'];

function warehouseOperatorsForScope(db, siteId, locationId) {
  const now = new Date().toISOString();
  const users = db.prepare(`SELECT DISTINCT ua.id,ua.person_id,p.full_name,ua.username
    FROM user_account ua JOIN person p ON p.id=ua.person_id
    JOIN user_role_scope urs ON urs.user_id=ua.id
    JOIN role r ON r.id=urs.role_id AND r.active=1
    WHERE ua.active=1 AND ua.deleted_at IS NULL AND p.status='ACTIVA' AND p.deleted_at IS NULL
      AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)
    ORDER BY p.full_name`).all(now, now);
  return users.filter((user) => userHasScope({ id: user.id }, siteId, locationId, 'Warehouse.Operate', db));
}

function cancelOperationalNotifications(db, custodyId, types = OPERATIONAL_TYPES, exceptUserIds = null) {
  const now = new Date().toISOString();
  const placeholders = types.map(() => '?').join(',');
  const params = [now, custodyId, ...types];
  let extra = '';
  if (Array.isArray(exceptUserIds) && exceptUserIds.length) {
    extra = ` AND (recipient_user_id IS NULL OR recipient_user_id NOT IN (${exceptUserIds.map(() => '?').join(',')}))`;
    params.push(...exceptUserIds);
  }
  return db.prepare(`UPDATE notification SET status='CANCELADA',updated_at=?
    WHERE entity_type='custody' AND entity_id=? AND type IN (${placeholders})
      AND status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA')${extra}`).run(...params).changes;
}

function cancelType(db, custodyId, type) {
  const now = new Date().toISOString();
  return db.prepare(`UPDATE notification SET status='CANCELADA',updated_at=?
    WHERE entity_type='custody' AND entity_id=? AND type=?
      AND status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA')`).run(now, custodyId, type).changes;
}

function enqueueForOperators(db, custody, type, subject, body, operators) {
  let generated = 0;
  let reactivated = 0;
  for (const operator of operators) {
    const result = enqueueNotification({
      recipientUserId: operator.id,
      recipientPersonId: operator.person_id,
      type,
      subject,
      body,
      entityType: 'custody',
      entityId: custody.id,
      dedupKey: `${type.toLowerCase()}:${custody.id}:${operator.id}`,
      reactivateCancelled: true
    }, db);
    if (!result.idempotent) generated += 1;
    if (result.reactivated) reactivated += 1;
  }
  return { generated, reactivated };
}

function loadCustody(db, custodyId) {
  return db.prepare(`SELECT c.id,c.status,c.due_at,c.declared_return_at,c.person_id,a.internal_code,a.description,
      p.full_name AS custodian_name,sl.id AS location_id,sl.site_id,r.request_number
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id
    JOIN storage_location sl ON sl.id=a.location_id JOIN request r ON r.id=c.request_id
    WHERE c.id=?`).get(custodyId);
}

function syncCustodyOperationalAlerts(db = getDb(), custodyOrId, nowValue = new Date()) {
  const custody = typeof custodyOrId === 'string' ? loadCustody(db, custodyOrId) : custodyOrId;
  if (!custody) return { processed: 0, generated: 0, reactivated: 0, cancelled: 0, recipients: 0 };
  const now = nowValue instanceof Date ? nowValue : new Date(nowValue);
  if (!Number.isFinite(now.getTime())) throw new Error('Fecha de sincronización de alertas inválida.');

  if (!OPEN_STATUSES.has(custody.status)) {
    return { processed: 1, generated: 0, reactivated: 0, cancelled: cancelOperationalNotifications(db, custody.id), recipients: 0 };
  }

  const operators = warehouseOperatorsForScope(db, custody.site_id, custody.location_id);
  const operatorIds = operators.map((item) => item.id);
  let generated = 0;
  let reactivated = 0;
  let cancelled = cancelOperationalNotifications(db, custody.id, OPERATIONAL_TYPES, operatorIds);

  const dueAt = custody.due_at ? new Date(custody.due_at) : null;
  const overdueMinutes = Math.max(0, Number(getSetting('notification.custodyOverdueMinutes', 0)) || 0);
  const dueSoonMinutes = Math.max(0, Number(getSetting('notification.custodyDueSoonMinutes', 1440)) || 0);
  const overdueThreshold = now.getTime() - overdueMinutes * 60_000;
  const isOverdue = Boolean(dueAt && Number.isFinite(dueAt.getTime()) && dueAt.getTime() <= overdueThreshold);
  const isDueSoon = Boolean(dueAt && Number.isFinite(dueAt.getTime()) && !isOverdue && dueSoonMinutes > 0 && dueAt.getTime() <= now.getTime() + dueSoonMinutes * 60_000);

  // F8: una devolución declarada ya no se gestiona como atraso; se gestiona como recepción pendiente.
  if (custody.status === 'DEVOLUCION_DECLARADA') {
    cancelled += cancelType(db, custody.id, 'CUSTODIA_PROXIMA');
    cancelled += cancelType(db, custody.id, 'CUSTODIA_VENCIDA');
  } else if (isOverdue) {
    cancelled += cancelType(db, custody.id, 'CUSTODIA_PROXIMA');
    const result = enqueueForOperators(db, custody, 'CUSTODIA_VENCIDA',
      `Devolución vencida: ${custody.internal_code}`,
      `${custody.custodian_name} debe devolver ${custody.description}. Solicitud ${custody.request_number}. Vencimiento: ${custody.due_at}.`, operators);
    generated += result.generated; reactivated += result.reactivated;
  } else if (isDueSoon) {
    cancelled += cancelType(db, custody.id, 'CUSTODIA_VENCIDA');
    const result = enqueueForOperators(db, custody, 'CUSTODIA_PROXIMA',
      `Devolución próxima: ${custody.internal_code}`,
      `${custody.custodian_name} debe devolver ${custody.description}. Solicitud ${custody.request_number}. Vencimiento: ${custody.due_at}.`, operators);
    generated += result.generated; reactivated += result.reactivated;
  } else {
    cancelled += cancelType(db, custody.id, 'CUSTODIA_PROXIMA');
    cancelled += cancelType(db, custody.id, 'CUSTODIA_VENCIDA');
  }

  if (custody.status === 'DEVOLUCION_DECLARADA') {
    const result = enqueueForOperators(db, custody, 'DEVOLUCION_DECLARADA',
      `Devolución declarada: ${custody.internal_code}`,
      `${custody.custodian_name} declaró la devolución de ${custody.description}. Debe registrarse la recepción física.`, operators);
    generated += result.generated; reactivated += result.reactivated;
  } else {
    cancelled += cancelType(db, custody.id, 'DEVOLUCION_DECLARADA');
  }

  return { processed: 1, generated, reactivated, cancelled, recipients: operators.length, missingOperator: operators.length === 0 };
}

function syncAllCustodyOperationalAlerts(db = getDb(), now = new Date()) {
  const rows = db.prepare(`SELECT c.id,c.status,c.due_at,c.declared_return_at,c.person_id,a.internal_code,a.description,
      p.full_name AS custodian_name,sl.id AS location_id,sl.site_id,r.request_number
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id
    JOIN storage_location sl ON sl.id=a.location_id JOIN request r ON r.id=c.request_id
    WHERE c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','CERRADA','INCIDENTE')`).all();
  const summary = { processed: 0, generated: 0, reactivated: 0, cancelled: 0, missingOperators: 0 };
  for (const row of rows) {
    const result = syncCustodyOperationalAlerts(db, row, now);
    summary.processed += result.processed;
    summary.generated += result.generated;
    summary.reactivated += result.reactivated;
    summary.cancelled += result.cancelled;
    if (result.missingOperator) summary.missingOperators += 1;
  }
  return summary;
}

function notifyCustodyIncidentToOperators(db, custodyId, incident) {
  const custody = loadCustody(db, custodyId);
  if (!custody || !incident) return { generated: 0, recipients: 0 };
  const operators = warehouseOperatorsForScope(db, custody.site_id, custody.location_id);
  let generated = 0;
  for (const operator of operators) {
    const result = enqueueNotification({
      recipientUserId: operator.id,
      recipientPersonId: operator.person_id,
      type: 'INCIDENTE',
      subject: `Incidente en devolución: ${custody.internal_code}`,
      body: `${incident.incident_number || 'Incidente'} · ${incident.type} · ${incident.severity}. ${incident.description}`,
      entityType: 'incident',
      entityId: incident.id,
      dedupKey: `custody-incident:${custody.id}:${incident.id}:${operator.id}`
    }, db);
    if (!result.idempotent) generated += 1;
  }
  return { generated, recipients: operators.length };
}

module.exports = {
  warehouseOperatorsForScope,
  syncCustodyOperationalAlerts,
  syncAllCustodyOperationalAlerts,
  cancelOperationalNotifications,
  notifyCustodyIncidentToOperators
};
