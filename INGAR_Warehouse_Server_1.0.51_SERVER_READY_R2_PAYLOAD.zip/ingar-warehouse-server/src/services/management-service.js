'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { permissionAssignments, userHasScope } = require('../security/scope');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');

const DEFAULT_TIME_ZONE = 'America/Argentina/Buenos_Aires';
const PERIODICITIES = ['DAILY', 'WEEKLY', 'MONTHLY'];
const OPEN_CUSTODY_STATUSES = ['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE'];
const OPEN_INCIDENT_STATUSES = ['ABIERTO', 'EN_INVESTIGACION'];

const INDICATOR_DEFINITIONS = Object.freeze([
  {
    code: 'REQUESTS_ON_TIME_PERCENT', name: 'Pedidos entregados a tiempo',
    description: 'Porcentaje de pedidos entregados antes o en el momento solicitado.',
    category: 'SOLICITUDES', unit: 'PERCENT', direction: 'HIGHER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'ON_TIME_DELIVERIES_DIV_DELIVERIES_X100',
    formulaDescription: 'Pedidos entregados a tiempo ÷ pedidos entregados × 100.',
    sources: ['request', 'handover'], defaultTarget: 95, defaultWarning: 90, periodicity: 'MONTHLY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'APPROVAL_TIME_AVG_HOURS', name: 'Tiempo para aprobar pedidos',
    description: 'Horas promedio desde que se crea el pedido hasta que queda aprobado.',
    category: 'SOLICITUDES', unit: 'HOURS', direction: 'LOWER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'AVG_APPROVED_AT_MINUS_CREATED_AT_HOURS',
    formulaDescription: 'Promedio de horas entre creación y primera aprobación.',
    sources: ['request', 'request_status_event'], defaultTarget: 4, defaultWarning: 8, periodicity: 'MONTHLY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'PREPARATION_TIME_AVG_HOURS', name: 'Tiempo para preparar pedidos',
    description: 'Horas promedio desde el inicio de preparación hasta que el pedido queda listo.',
    category: 'SOLICITUDES', unit: 'HOURS', direction: 'LOWER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'AVG_READY_AT_MINUS_PREPARED_AT_HOURS',
    formulaDescription: 'Promedio de horas entre inicio y finalización de la preparación.',
    sources: ['request_preparation', 'request'], defaultTarget: 2, defaultWarning: 4, periodicity: 'MONTHLY', responsibleRole: 'PANOLERO'
  },
  {
    code: 'DELIVERY_TIME_AVG_HOURS', name: 'Tiempo total hasta la entrega',
    description: 'Horas promedio desde la creación del pedido hasta la primera entrega.',
    category: 'SOLICITUDES', unit: 'HOURS', direction: 'LOWER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'AVG_FIRST_DELIVERY_MINUS_CREATED_AT_HOURS',
    formulaDescription: 'Promedio de horas entre creación y primera entrega.',
    sources: ['request', 'handover'], defaultTarget: 8, defaultWarning: 16, periodicity: 'MONTHLY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'RETURNS_ON_TIME_PERCENT', name: 'Devoluciones a tiempo',
    description: 'Porcentaje de herramientas devueltas dentro del plazo previsto.',
    category: 'DEVOLUCIONES', unit: 'PERCENT', direction: 'HIGHER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'ON_TIME_RETURNS_DIV_RETURNS_X100',
    formulaDescription: 'Devoluciones en término ÷ devoluciones registradas × 100.',
    sources: ['custody_return_record', 'custody', 'request'], defaultTarget: 95, defaultWarning: 90, periodicity: 'MONTHLY', responsibleRole: 'PANOLERO'
  },
  {
    code: 'OVERDUE_CUSTODIES_COUNT', name: 'Herramientas con devolución atrasada',
    description: 'Cantidad de herramientas todavía entregadas cuya fecha de devolución ya venció.',
    category: 'DEVOLUCIONES', unit: 'COUNT', direction: 'LOWER_BETTER', calculationMode: 'SNAPSHOT',
    formulaCode: 'COUNT_OPEN_CUSTODIES_PAST_DUE',
    formulaDescription: 'Cantidad de custodias abiertas con fecha de devolución vencida.',
    sources: ['custody', 'request'], defaultTarget: 0, defaultWarning: 3, periodicity: 'DAILY', responsibleRole: 'PANOLERO'
  },
  {
    code: 'RETURNS_WITH_ISSUES_PERCENT', name: 'Devoluciones con problemas',
    description: 'Porcentaje de devoluciones observadas, dañadas o incompletas.',
    category: 'DEVOLUCIONES', unit: 'PERCENT', direction: 'LOWER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'NON_CONFORMING_RETURNS_DIV_RETURNS_X100',
    formulaDescription: 'Devoluciones no conformes ÷ devoluciones registradas × 100.',
    sources: ['custody_return_record', 'custody', 'request'], defaultTarget: 2, defaultWarning: 5, periodicity: 'MONTHLY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'TOOL_AVAILABILITY_PERCENT', name: 'Herramientas disponibles',
    description: 'Porcentaje de herramientas retornables activas que están disponibles para entregar.',
    category: 'ACTIVOS', unit: 'PERCENT', direction: 'HIGHER_BETTER', calculationMode: 'SNAPSHOT',
    formulaCode: 'AVAILABLE_RETURNABLE_TOOLS_DIV_ACTIVE_RETURNABLE_TOOLS_X100',
    formulaDescription: 'Herramientas disponibles ÷ herramientas retornables activas × 100.',
    sources: ['asset', 'asset_category', 'storage_location'], defaultTarget: 90, defaultWarning: 75, periodicity: 'DAILY', responsibleRole: 'PANOLERO'
  },
  {
    code: 'OPEN_INCIDENTS_COUNT', name: 'Problemas abiertos',
    description: 'Cantidad de incidentes abiertos o en investigación.',
    category: 'INCIDENTES', unit: 'COUNT', direction: 'LOWER_BETTER', calculationMode: 'SNAPSHOT',
    formulaCode: 'COUNT_OPEN_INCIDENTS',
    formulaDescription: 'Cantidad de incidentes abiertos o en investigación.',
    sources: ['incident', 'asset', 'storage_location'], defaultTarget: 0, defaultWarning: 5, periodicity: 'DAILY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'MAINTENANCE_ON_TIME_PERCENT', name: 'Mantenimientos terminados a tiempo',
    description: 'Porcentaje de órdenes terminadas antes o en su fecha límite.',
    category: 'MANTENIMIENTO', unit: 'PERCENT', direction: 'HIGHER_BETTER', calculationMode: 'PERIOD',
    formulaCode: 'ON_TIME_COMPLETED_MAINTENANCE_DIV_COMPLETED_WITH_DUE_DATE_X100',
    formulaDescription: 'Mantenimientos terminados a tiempo ÷ mantenimientos terminados con fecha límite × 100.',
    sources: ['maintenance_order', 'asset', 'storage_location'], defaultTarget: 95, defaultWarning: 85, periodicity: 'MONTHLY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'OVERDUE_MAINTENANCE_COUNT', name: 'Mantenimientos atrasados',
    description: 'Cantidad de órdenes activas cuya fecha límite ya venció.',
    category: 'MANTENIMIENTO', unit: 'COUNT', direction: 'LOWER_BETTER', calculationMode: 'SNAPSHOT',
    formulaCode: 'COUNT_OPEN_MAINTENANCE_PAST_DUE',
    formulaDescription: 'Cantidad de órdenes no terminadas ni canceladas con fecha límite vencida.',
    sources: ['maintenance_order', 'asset', 'storage_location'], defaultTarget: 0, defaultWarning: 3, periodicity: 'DAILY', responsibleRole: 'SUPERVISOR'
  },
  {
    code: 'STOCKOUT_ITEMS_COUNT', name: 'Consumibles sin disponibilidad',
    description: 'Cantidad de artículos consumibles activos sin unidades disponibles.',
    category: 'STOCK', unit: 'COUNT', direction: 'LOWER_BETTER', calculationMode: 'SNAPSHOT',
    formulaCode: 'COUNT_ACTIVE_CONSUMABLES_WITH_AVAILABLE_STOCK_LE_ZERO',
    formulaDescription: 'Cantidad de consumibles activos cuya existencia disponible es cero o menor.',
    sources: ['asset', 'asset_category', 'stock_lot', 'storage_location'], defaultTarget: 0, defaultWarning: 3, periodicity: 'DAILY', responsibleRole: 'PANOLERO'
  }
]);

function managementError(message, code = 'MANAGEMENT_INVALID', status = 422) {
  return Object.assign(new Error(message), { code, status });
}

function can(user, permission) {
  return Boolean(user && hasPermission(user, permission));
}

function safeTimeZone(value) {
  const candidate = String(value || DEFAULT_TIME_ZONE);
  try { new Intl.DateTimeFormat('es-AR', { timeZone: candidate }).format(new Date()); return candidate; }
  catch { return DEFAULT_TIME_ZONE; }
}

function zonedParts(date, timeZone) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  }).formatToParts(date);
  return Object.fromEntries(parts.filter((part) => part.type !== 'literal').map((part) => [part.type, Number(part.value)]));
}

function timeZoneOffsetMs(date, timeZone) {
  const parts = zonedParts(date, timeZone);
  const representedUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
  return representedUtc - Math.floor(date.getTime() / 1000) * 1000;
}

function localDateTimeToUtc(parts, timeZone) {
  const targetUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour || 0, parts.minute || 0, parts.second || 0, parts.millisecond || 0);
  let estimate = targetUtc;
  for (let iteration = 0; iteration < 3; iteration += 1) estimate = targetUtc - timeZoneOffsetMs(new Date(estimate), timeZone);
  return new Date(estimate);
}

function parseDateKey(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) throw managementError('Fecha inválida. Use AAAA-MM-DD.', 'MANAGEMENT_DATE_INVALID');
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12));
  if (date.toISOString().slice(0, 10) !== value) throw managementError('Fecha inexistente.', 'MANAGEMENT_DATE_INVALID');
  return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
}

function shiftDateKey(dateKey, days) {
  const parts = parseDateKey(dateKey);
  return new Date(Date.UTC(parts.year, parts.month - 1, parts.day + days, 12)).toISOString().slice(0, 10);
}

function localDateKey(date, timeZone) {
  const parts = zonedParts(date, timeZone);
  return `${String(parts.year).padStart(4, '0')}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
}

function defaultPeriod(now, timeZone) {
  const today = localDateKey(now, timeZone);
  return { dateFrom: `${today.slice(0, 7)}-01`, dateTo: today };
}

function normalizePeriod(input = {}, now = new Date(), timeZone = safeTimeZone(getSetting('locale.timezone', DEFAULT_TIME_ZONE))) {
  const defaults = defaultPeriod(now, timeZone);
  const dateFrom = String(input.dateFrom || defaults.dateFrom);
  const dateTo = String(input.dateTo || defaults.dateTo);
  const startParts = parseDateKey(dateFrom);
  const endNextParts = parseDateKey(shiftDateKey(dateTo, 1));
  if (dateFrom > dateTo) throw managementError('La fecha desde no puede superar la fecha hasta.', 'MANAGEMENT_DATE_RANGE_INVALID');
  const days = Math.round((Date.UTC(endNextParts.year, endNextParts.month - 1, endNextParts.day) - Date.UTC(startParts.year, startParts.month - 1, startParts.day)) / 86400000);
  if (days > 366) throw managementError('El período no puede superar 366 días.', 'MANAGEMENT_DATE_RANGE_TOO_LARGE');
  return {
    dateFrom, dateTo,
    startUtc: localDateTimeToUtc(startParts, timeZone).toISOString(),
    endUtc: localDateTimeToUtc(endNextParts, timeZone).toISOString(),
    timeZone
  };
}

function ensureManagementCatalog(db = getDb()) {
  const now = new Date().toISOString();
  const definitionStmt = db.prepare(`INSERT INTO management_indicator_definition(
      id,code,name,description,category,unit,direction,calculation_mode,formula_code,formula_description,source_json,
      default_target_value,default_warning_value,default_periodicity,active,system_indicator,version,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,1,1,?,?)
    ON CONFLICT(code) DO UPDATE SET
      name=excluded.name,description=excluded.description,category=excluded.category,unit=excluded.unit,direction=excluded.direction,
      calculation_mode=excluded.calculation_mode,formula_code=excluded.formula_code,formula_description=excluded.formula_description,
      source_json=excluded.source_json,default_target_value=excluded.default_target_value,default_warning_value=excluded.default_warning_value,
      default_periodicity=excluded.default_periodicity,active=1,updated_at=excluded.updated_at`);
  for (const item of INDICATOR_DEFINITIONS) {
    definitionStmt.run(randomUUID(), item.code, item.name, item.description, item.category, item.unit, item.direction, item.calculationMode,
      item.formulaCode, item.formulaDescription, JSON.stringify(item.sources), item.defaultTarget, item.defaultWarning, item.periodicity, now, now);
  }
  const defaultValidFrom = '2000-01-01T00:00:00.000Z';
  const targetStmt = db.prepare(`INSERT INTO management_indicator_target(
      id,indicator_id,scope_type,site_id,location_id,target_value,warning_value,responsible_user_id,responsible_role_id,
      periodicity,active,version,valid_from,valid_to,created_by_user_id,updated_by_user_id,created_at,updated_at)
    VALUES (?,?, 'GLOBAL',NULL,NULL,?,?,NULL,?, ?,1,1,?,NULL,NULL,NULL,?,?) ON CONFLICT DO NOTHING`);
  for (const item of INDICATOR_DEFINITIONS) {
    const definition = db.prepare('SELECT id FROM management_indicator_definition WHERE code=?').get(item.code);
    const role = db.prepare('SELECT id FROM role WHERE code=? AND active=1').get(item.responsibleRole);
    targetStmt.run(randomUUID(), definition.id, item.defaultTarget, item.defaultWarning, role?.id || null, item.periodicity, defaultValidFrom, now, now);
  }
  return INDICATOR_DEFINITIONS.length;
}

function accessibleOptions(user, db = getDb()) {
  const scopes = permissionAssignments(user, 'Management.Read', db);
  const unrestricted = scopes.some((scope) => !scope.site_id && !scope.location_id);
  const siteIds = new Set(scopes.map((scope) => scope.site_id).filter(Boolean));
  const locationIds = new Set(scopes.map((scope) => scope.location_id).filter(Boolean));
  if (locationIds.size) {
    const placeholders = [...locationIds].map(() => '?').join(',');
    for (const row of db.prepare(`SELECT site_id FROM storage_location WHERE id IN (${placeholders})`).all(...locationIds)) siteIds.add(row.site_id);
  }
  const sites = unrestricted
    ? db.prepare('SELECT id,code,name FROM site WHERE active=1 ORDER BY code').all()
    : [...siteIds].length ? db.prepare(`SELECT id,code,name FROM site WHERE active=1 AND id IN (${[...siteIds].map(() => '?').join(',')}) ORDER BY code`).all(...siteIds) : [];
  const locations = unrestricted
    ? db.prepare('SELECT id,site_id,code,name FROM storage_location WHERE active=1 ORDER BY code').all()
    : db.prepare(`SELECT id,site_id,code,name FROM storage_location WHERE active=1 AND (${[
      locationIds.size ? `id IN (${[...locationIds].map(() => '?').join(',')})` : null,
      siteIds.size ? `site_id IN (${[...siteIds].map(() => '?').join(',')})` : null
    ].filter(Boolean).join(' OR ') || '0=1'}) ORDER BY code`).all(...locationIds, ...siteIds);
  const users = can(user, 'Management.Assign') ? db.prepare(`SELECT ua.id,p.full_name,ua.username FROM user_account ua JOIN person p ON p.id=ua.person_id
    WHERE ua.active=1 AND ua.deleted_at IS NULL AND p.deleted_at IS NULL ORDER BY p.full_name`).all() : [];
  const roles = can(user, 'Management.Assign') ? db.prepare('SELECT id,code,name FROM role WHERE active=1 ORDER BY name').all() : [];
  return { canUseGlobalScope: unrestricted, sites, locations, users, roles, periodicities: PERIODICITIES };
}

function scopeFromInput(input, user, permission, db = getDb()) {
  const siteId = input?.siteId ? String(input.siteId) : null;
  const locationId = input?.locationId ? String(input.locationId) : null;
  if (locationId) {
    const location = db.prepare('SELECT id,site_id,code,name FROM storage_location WHERE id=? AND active=1').get(locationId);
    if (!location) throw managementError('Ubicación inexistente o inactiva.', 'MANAGEMENT_LOCATION_INVALID');
    if (siteId && siteId !== location.site_id) throw managementError('La ubicación no pertenece a la sede indicada.', 'MANAGEMENT_SCOPE_MISMATCH');
    if (!userHasScope(user, location.site_id, location.id, permission, db)) throw managementError('La ubicación está fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
    return { type: 'LOCATION', siteId: location.site_id, locationId: location.id, label: location.name };
  }
  if (siteId) {
    const site = db.prepare('SELECT id,code,name FROM site WHERE id=? AND active=1').get(siteId);
    if (!site) throw managementError('Sede inexistente o inactiva.', 'MANAGEMENT_SITE_INVALID');
    if (!userHasScope(user, site.id, null, permission, db)) throw managementError('La sede está fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
    return { type: 'SITE', siteId: site.id, locationId: null, label: site.name };
  }
  const scopes = permissionAssignments(user, permission, db);
  if (scopes.some((scope) => !scope.site_id && !scope.location_id)) return { type: 'GLOBAL', siteId: null, locationId: null, label: 'Toda la organización' };
  const firstLocation = scopes.find((scope) => scope.location_id);
  if (firstLocation) {
    const location = db.prepare('SELECT id,site_id,name FROM storage_location WHERE id=? AND active=1').get(firstLocation.location_id);
    if (location) return { type: 'LOCATION', siteId: location.site_id, locationId: location.id, label: location.name };
  }
  const firstSite = scopes.find((scope) => scope.site_id);
  if (firstSite) {
    const site = db.prepare('SELECT id,name FROM site WHERE id=? AND active=1').get(firstSite.site_id);
    if (site) return { type: 'SITE', siteId: site.id, locationId: null, label: site.name };
  }
  throw managementError('No existe un alcance habilitado para gestión.', 'SCOPE_FORBIDDEN', 403);
}

function scopeSql(scope, siteColumn, locationColumn) {
  if (scope.type === 'LOCATION') return { sql: `${locationColumn}=?`, params: [scope.locationId] };
  if (scope.type === 'SITE') return { sql: `${siteColumn}=?`, params: [scope.siteId] };
  return { sql: '1=1', params: [] };
}

function effectiveTarget(db, indicatorId, scope, at = new Date().toISOString()) {
  const candidates = db.prepare(`SELECT mit.*,ua.username AS responsible_username,p.full_name AS responsible_user_name,
      r.code AS responsible_role_code,r.name AS responsible_role_name
    FROM management_indicator_target mit
    LEFT JOIN user_account ua ON ua.id=mit.responsible_user_id
    LEFT JOIN person p ON p.id=ua.person_id
    LEFT JOIN role r ON r.id=mit.responsible_role_id
    WHERE mit.indicator_id=? AND mit.active=1 AND mit.valid_from<=? AND (mit.valid_to IS NULL OR mit.valid_to>=?)
      AND (
        (mit.scope_type='LOCATION' AND mit.location_id=?) OR
        (mit.scope_type='SITE' AND mit.site_id=?) OR
        mit.scope_type='GLOBAL'
      )
    ORDER BY CASE mit.scope_type WHEN 'LOCATION' THEN 1 WHEN 'SITE' THEN 2 ELSE 3 END LIMIT 1`)
    .get(indicatorId, at, at, scope.locationId, scope.siteId);
  if (!candidates) throw managementError('No existe objetivo configurado para el indicador.', 'MANAGEMENT_TARGET_MISSING', 500);
  return candidates;
}

function percentage(numerator, denominator) {
  return denominator > 0 ? numerator / denominator * 100 : null;
}

function numericResult(row, mode = 'value') {
  const numerator = Number(row?.numerator || 0);
  const denominator = Number(row?.denominator || 0);
  if (mode === 'percentage') return { value: percentage(numerator, denominator), numerator, denominator };
  const raw = row?.value;
  return { value: raw === null || raw === undefined ? null : Number(raw), numerator: row?.numerator === undefined ? null : numerator, denominator: row?.denominator === undefined ? null : denominator };
}

function requestScopeFilter(scope) { return scopeSql(scope, 'r.site_id', 'r.location_id'); }
function assetScopeFilter(scope) { return scopeSql(scope, 'sl.site_id', 'a.location_id'); }

const CALCULATORS = Object.freeze({
  REQUESTS_ON_TIME_PERCENT(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`WITH first_delivery AS (
      SELECT r.id,r.needed_at,MIN(h.occurred_at) AS delivered_at
      FROM request r JOIN handover h ON h.request_id=r.id AND h.type='ENTREGA'
      WHERE (${scoped.sql}) AND h.occurred_at>=? AND h.occurred_at<?
      GROUP BY r.id,r.needed_at
    ) SELECT SUM(CASE WHEN delivered_at<=needed_at THEN 1 ELSE 0 END) AS numerator,COUNT(*) AS denominator FROM first_delivery`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row, 'percentage');
  },
  APPROVAL_TIME_AVG_HOURS(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`WITH approvals AS (
      SELECT r.id,r.created_at,MIN(rse.occurred_at) AS approved_at
      FROM request r JOIN request_status_event rse ON rse.request_id=r.id AND rse.to_status='APROBADA'
      WHERE (${scoped.sql}) AND rse.occurred_at>=? AND rse.occurred_at<?
      GROUP BY r.id,r.created_at
    ) SELECT AVG(MAX(0,(julianday(approved_at)-julianday(created_at))*24.0)) AS value,COUNT(*) AS denominator FROM approvals`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row);
  },
  PREPARATION_TIME_AVG_HOURS(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`SELECT AVG(MAX(0,(julianday(rp.ready_at)-julianday(rp.prepared_at))*24.0)) AS value,COUNT(*) AS denominator
      FROM request_preparation rp JOIN request r ON r.id=rp.request_id
      WHERE (${scoped.sql}) AND rp.ready_at IS NOT NULL AND rp.ready_at>=? AND rp.ready_at<?`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row);
  },
  DELIVERY_TIME_AVG_HOURS(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`WITH deliveries AS (
      SELECT r.id,r.created_at,MIN(h.occurred_at) AS delivered_at
      FROM request r JOIN handover h ON h.request_id=r.id AND h.type='ENTREGA'
      WHERE (${scoped.sql}) AND h.occurred_at>=? AND h.occurred_at<?
      GROUP BY r.id,r.created_at
    ) SELECT AVG(MAX(0,(julianday(delivered_at)-julianday(created_at))*24.0)) AS value,COUNT(*) AS denominator FROM deliveries`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row);
  },
  RETURNS_ON_TIME_PERCENT(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`SELECT SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END) AS numerator,COUNT(*) AS denominator
      FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id
      WHERE (${scoped.sql}) AND crr.received_at>=? AND crr.received_at<?`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row, 'percentage');
  },
  OVERDUE_CUSTODIES_COUNT(db, scope, period, now) {
    const scoped = requestScopeFilter(scope);
    const placeholders = OPEN_CUSTODY_STATUSES.map(() => '?').join(',');
    const row = db.prepare(`SELECT COUNT(*) AS value FROM custody c JOIN request r ON r.id=c.request_id
      WHERE (${scoped.sql}) AND c.status IN (${placeholders}) AND c.status<>'DEVOLUCION_DECLARADA' AND c.due_at IS NOT NULL AND c.due_at<?`)
      .get(...scoped.params, ...OPEN_CUSTODY_STATUSES, now.toISOString());
    return numericResult(row);
  },
  RETURNS_WITH_ISSUES_PERCENT(db, scope, period) {
    const scoped = requestScopeFilter(scope);
    const row = db.prepare(`SELECT SUM(CASE WHEN crr.condition<>'CONFORME' THEN 1 ELSE 0 END) AS numerator,COUNT(*) AS denominator
      FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id
      WHERE (${scoped.sql}) AND crr.received_at>=? AND crr.received_at<?`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row, 'percentage');
  },
  TOOL_AVAILABILITY_PERCENT(db, scope) {
    const scoped = assetScopeFilter(scope);
    const row = db.prepare(`SELECT SUM(CASE WHEN a.status='DISPONIBLE' AND a.quantity_available>0 THEN 1 ELSE 0 END) AS numerator,COUNT(*) AS denominator
      FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE (${scoped.sql}) AND a.active=1 AND a.deleted_at IS NULL AND ac.active=1 AND ac.deleted_at IS NULL
        AND ac.requires_return=1 AND ac.serialized=1`)
      .get(...scoped.params);
    return numericResult(row, 'percentage');
  },
  OPEN_INCIDENTS_COUNT(db, scope) {
    const scoped = assetScopeFilter(scope);
    const placeholders = OPEN_INCIDENT_STATUSES.map(() => '?').join(',');
    const row = db.prepare(`SELECT COUNT(*) AS value FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE (${scoped.sql}) AND i.status IN (${placeholders})`).get(...scoped.params, ...OPEN_INCIDENT_STATUSES);
    return numericResult(row);
  },
  MAINTENANCE_ON_TIME_PERCENT(db, scope, period) {
    const scoped = assetScopeFilter(scope);
    const row = db.prepare(`SELECT SUM(CASE WHEN mo.completed_at<=mo.due_at THEN 1 ELSE 0 END) AS numerator,COUNT(*) AS denominator
      FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE (${scoped.sql}) AND mo.status='COMPLETADA' AND mo.due_at IS NOT NULL AND mo.completed_at>=? AND mo.completed_at<?`)
      .get(...scoped.params, period.startUtc, period.endUtc);
    return numericResult(row, 'percentage');
  },
  OVERDUE_MAINTENANCE_COUNT(db, scope, period, now) {
    const scoped = assetScopeFilter(scope);
    const row = db.prepare(`SELECT COUNT(*) AS value FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE (${scoped.sql}) AND mo.status NOT IN ('COMPLETADA','CANCELADA') AND mo.due_at IS NOT NULL AND mo.due_at<?`)
      .get(...scoped.params, now.toISOString());
    return numericResult(row);
  },
  STOCKOUT_ITEMS_COUNT(db, scope) {
    const scoped = assetScopeFilter(scope);
    const row = db.prepare(`SELECT COUNT(*) AS value FROM (
      SELECT a.id FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
      LEFT JOIN stock_lot lot ON lot.asset_id=a.id AND lot.active=1
      WHERE (${scoped.sql}) AND a.active=1 AND a.deleted_at IS NULL AND ac.active=1 AND ac.deleted_at IS NULL AND ac.nature='CONSUMIBLE'
      GROUP BY a.id HAVING COALESCE(SUM(lot.quantity_on_hand-lot.quantity_reserved),0)<=0
    ) unavailable`).get(...scoped.params);
    return numericResult(row);
  }
});

function indicatorStatus(definition, result, target) {
  if (result.value === null || !Number.isFinite(result.value)) return 'SIN_DATOS';
  if (definition.direction === 'HIGHER_BETTER') {
    if (result.value >= target.target_value) return 'BIEN';
    if (result.value >= target.warning_value) return 'ATENCION';
    return 'URGENTE';
  }
  if (result.value <= target.target_value) return 'BIEN';
  if (result.value <= target.warning_value) return 'ATENCION';
  return 'URGENTE';
}

function definitionRows(db = getDb()) {
  ensureManagementCatalog(db);
  return db.prepare('SELECT * FROM management_indicator_definition WHERE active=1 ORDER BY category,name').all();
}

function hydrateDefinition(row) {
  return {
    id: row.id, code: row.code, name: row.name, description: row.description, category: row.category, unit: row.unit,
    direction: row.direction, calculationMode: row.calculation_mode, formulaCode: row.formula_code,
    formulaDescription: row.formula_description, sources: JSON.parse(row.source_json || '[]'),
    defaultTarget: row.default_target_value, defaultWarning: row.default_warning_value, defaultPeriodicity: row.default_periodicity,
    version: row.version
  };
}

function hydrateTarget(row) {
  return {
    id: row.id, scopeType: row.scope_type, siteId: row.site_id, locationId: row.location_id,
    targetValue: row.target_value, warningValue: row.warning_value, periodicity: row.periodicity,
    responsibleUserId: row.responsible_user_id, responsibleUserName: row.responsible_user_name || null,
    responsibleUsername: row.responsible_username || null, responsibleRoleId: row.responsible_role_id,
    responsibleRoleCode: row.responsible_role_code || null, responsibleRoleName: row.responsible_role_name || null,
    validFrom: row.valid_from, validTo: row.valid_to, active: Boolean(row.active), version: row.version
  };
}

function latestSnapshot(db, indicatorId, scope) {
  return db.prepare(`SELECT * FROM management_indicator_snapshot WHERE indicator_id=? AND scope_type=?
      AND IFNULL(site_id,'')=IFNULL(?, '') AND IFNULL(location_id,'')=IFNULL(?, '') ORDER BY measured_at DESC LIMIT 1`)
    .get(indicatorId, scope.type, scope.siteId, scope.locationId);
}

function hydrateSnapshot(row) {
  if (!row) return null;
  return {
    id: row.id, measurementDate: row.measurement_date, periodStart: row.period_start, periodEnd: row.period_end,
    measuredAt: row.measured_at, value: row.value, numerator: row.numerator, denominator: row.denominator,
    targetValue: row.target_value, warningValue: row.warning_value, status: row.status,
    details: JSON.parse(row.details_json || '{}'), source: row.source
  };
}

function getManagementModel(user, input = {}, options = {}) {
  if (!can(user, 'Management.Read')) throw managementError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const db = options.db || getDb(); ensureManagementCatalog(db);
  const scope = scopeFromInput(input, user, 'Management.Read', db);
  const now = options.now instanceof Date ? options.now : new Date();
  const period = normalizePeriod(input, now);
  const definitions = definitionRows(db).map((row) => {
    const definition = hydrateDefinition(row);
    const target = effectiveTarget(db, row.id, scope, now.toISOString());
    return { ...definition, target: hydrateTarget(target), latest: hydrateSnapshot(latestSnapshot(db, row.id, scope)) };
  });
  return { generatedAt: now.toISOString(), scope, period, indicators: definitions, options: accessibleOptions(user, db) };
}


const MANAGEMENT_DETAIL_TARGETS = Object.freeze({
  REQUESTS_ON_TIME_PERCENT: { view: 'requests', label: 'Ver pedidos entregados', filter: { status: 'ENTREGADA' } },
  APPROVAL_TIME_AVG_HOURS: { view: 'requests', label: 'Ver pedidos para aprobar', filter: { statuses: ['PENDIENTE_AUTORIZACION', 'APROBADA'] } },
  PREPARATION_TIME_AVG_HOURS: { view: 'requests', label: 'Ver pedidos para preparar', filter: { statuses: ['APROBADA', 'EN_PREPARACION', 'LISTA_PARA_ENTREGA'] } },
  DELIVERY_TIME_AVG_HOURS: { view: 'requests', label: 'Ver entregas', filter: { status: 'ENTREGADA' } },
  RETURNS_ON_TIME_PERCENT: { view: 'custodies', label: 'Ver devoluciones', filter: { mode: 'returns' } },
  OVERDUE_CUSTODIES_COUNT: { view: 'custodies', label: 'Ver devoluciones atrasadas', filter: { overdue: true, statuses: OPEN_CUSTODY_STATUSES } },
  RETURNS_WITH_ISSUES_PERCENT: { view: 'incidents', label: 'Ver problemas de devolución', filter: { statuses: OPEN_INCIDENT_STATUSES } },
  TOOL_AVAILABILITY_PERCENT: { view: 'assets', label: 'Ver herramientas', filter: { active: true } },
  OPEN_INCIDENTS_COUNT: { view: 'incidents', label: 'Ver problemas abiertos', filter: { statuses: OPEN_INCIDENT_STATUSES } },
  MAINTENANCE_ON_TIME_PERCENT: { view: 'maintenance', label: 'Ver mantenimiento', filter: { status: 'COMPLETADA' } },
  OVERDUE_MAINTENANCE_COUNT: { view: 'maintenance', label: 'Ver mantenimiento atrasado', filter: { overdue: true } },
  STOCKOUT_ITEMS_COUNT: { view: 'stock', label: 'Ver consumibles sin stock', filter: { unavailable: true } }
});

const PANOLERO_INDICATOR_CODES = Object.freeze([
  'PREPARATION_TIME_AVG_HOURS', 'RETURNS_ON_TIME_PERCENT', 'OVERDUE_CUSTODIES_COUNT',
  'RETURNS_WITH_ISSUES_PERCENT', 'TOOL_AVAILABILITY_PERCENT', 'OPEN_INCIDENTS_COUNT',
  'OVERDUE_MAINTENANCE_COUNT', 'STOCKOUT_ITEMS_COUNT'
]);

function managementRoleView(user) {
  const roles = new Set(user?.roleCodes || []);
  const isAdmin = roles.has('ADMIN_GENERAL') || roles.has('ADMINISTRADOR');
  if (roles.has('PANOLERO') && !isAdmin && !roles.has('SUPERVISOR')) {
    return { code: 'OPERATIVA', label: 'Vista del pañol', description: 'Muestra los indicadores sobre los que el pañol puede actuar.', indicatorCodes: [...PANOLERO_INDICATOR_CODES], readOnly: !can(user, 'Management.Evaluate') };
  }
  if (roles.has('AUDITOR') && !isAdmin && !roles.has('SUPERVISOR')) {
    return { code: 'AUDITORIA', label: 'Vista de auditoría', description: 'Muestra todos los indicadores sin habilitar cambios ni recálculos.', indicatorCodes: null, readOnly: true };
  }
  return { code: 'GERENCIAL', label: 'Vista gerencial', description: 'Muestra el estado completo, las tendencias y los responsables.', indicatorCodes: null, readOnly: !can(user, 'Management.Evaluate') };
}

function previousPeriod(period, now, timeZone) {
  const start = parseDateKey(period.dateFrom);
  const end = parseDateKey(period.dateTo);
  const days = Math.round((Date.UTC(end.year, end.month - 1, end.day) - Date.UTC(start.year, start.month - 1, start.day)) / 86400000) + 1;
  const dateTo = shiftDateKey(period.dateFrom, -1);
  const dateFrom = shiftDateKey(dateTo, -(days - 1));
  return normalizePeriod({ dateFrom, dateTo }, now, timeZone);
}

function dashboardComparison(definition, current, previous) {
  if (current.value === null || previous.value === null || !Number.isFinite(current.value) || !Number.isFinite(previous.value)) {
    return { trend: 'SIN_DATOS', delta: null, deltaPercent: null };
  }
  const delta = Math.round((current.value - previous.value) * 100) / 100;
  const deltaPercent = previous.value === 0 ? null : Math.round((delta / Math.abs(previous.value)) * 10000) / 100;
  if (Math.abs(delta) < 0.01) return { trend: 'ESTABLE', delta: 0, deltaPercent: 0 };
  const improved = definition.direction === 'HIGHER_BETTER' ? delta > 0 : delta < 0;
  return { trend: improved ? 'MEJORA' : 'EMPEORA', delta, deltaPercent };
}

function currentIndicatorResult(db, definitionRow, scope, period, now) {
  const calculator = CALCULATORS[definitionRow.code];
  if (!calculator) throw managementError(`Indicador sin cálculo: ${definitionRow.code}.`, 'MANAGEMENT_CALCULATOR_MISSING', 500);
  const target = effectiveTarget(db, definitionRow.id, scope, now.toISOString());
  const result = calculator(db, scope, period, now);
  if (result.value !== null && Number.isFinite(result.value)) result.value = Math.round(result.value * 100) / 100;
  return { target, result: { ...result, status: indicatorStatus(definitionRow, result, target) } };
}

function historicalSnapshotResult(db, definitionRow, scope, period, target) {
  const row = db.prepare(`SELECT value,numerator,denominator,status FROM management_indicator_snapshot
    WHERE indicator_id=? AND scope_type=? AND IFNULL(site_id,'')=IFNULL(?, '') AND IFNULL(location_id,'')=IFNULL(?, '')
      AND measurement_date<=? ORDER BY measurement_date DESC,measured_at DESC LIMIT 1`)
    .get(definitionRow.id, scope.type, scope.siteId, scope.locationId, period.dateTo);
  if (!row) return { value: null, numerator: null, denominator: null, status: 'SIN_DATOS' };
  const result = { value: row.value === null ? null : Number(row.value), numerator: row.numerator === null ? null : Number(row.numerator), denominator: row.denominator === null ? null : Number(row.denominator) };
  return { ...result, status: result.value === null ? 'SIN_DATOS' : indicatorStatus(definitionRow, result, target) };
}

function managementPriorityText(code, status) {
  const texts = {
    REQUESTS_ON_TIME_PERCENT: 'Revisar por qué los pedidos no se entregan a tiempo.',
    APPROVAL_TIME_AVG_HOURS: 'Reducir la demora para aprobar pedidos.',
    PREPARATION_TIME_AVG_HOURS: 'Revisar la preparación de pedidos pendientes.',
    DELIVERY_TIME_AVG_HOURS: 'Revisar el tiempo total hasta la entrega.',
    RETURNS_ON_TIME_PERCENT: 'Contactar a quienes devuelven fuera de término.',
    OVERDUE_CUSTODIES_COUNT: 'Recuperar las herramientas cuya devolución está vencida.',
    RETURNS_WITH_ISSUES_PERCENT: 'Revisar daños, faltantes y devoluciones observadas.',
    TOOL_AVAILABILITY_PERCENT: 'Liberar, reparar o reponer herramientas no disponibles.',
    OPEN_INCIDENTS_COUNT: 'Resolver los problemas abiertos más antiguos.',
    MAINTENANCE_ON_TIME_PERCENT: 'Revisar el cumplimiento del mantenimiento programado.',
    OVERDUE_MAINTENANCE_COUNT: 'Completar o reprogramar mantenimientos vencidos.',
    STOCKOUT_ITEMS_COUNT: 'Reponer los consumibles sin disponibilidad.'
  };
  return status === 'URGENTE' ? texts[code] : `Atención: ${texts[code] || 'Revisar el indicador y su detalle.'}`;
}

function managementTrendPoints(db, definitionRow, scope, previous, current, previousPeriodValue, currentPeriodValue) {
  const rows = db.prepare(`SELECT measurement_date,period_start,period_end,measured_at,value,target_value,status
    FROM management_indicator_snapshot WHERE indicator_id=? AND scope_type=?
      AND IFNULL(site_id,'')=IFNULL(?, '') AND IFNULL(location_id,'')=IFNULL(?, '')
    ORDER BY measured_at DESC LIMIT 10`).all(definitionRow.id, scope.type, scope.siteId, scope.locationId).reverse();
  const points = rows.map((row) => ({
    key: `${row.period_start}:${row.period_end}`, label: row.period_end, periodStart: row.period_start, periodEnd: row.period_end,
    measuredAt: row.measured_at, value: row.value === null ? null : Number(row.value), targetValue: Number(row.target_value), status: row.status, source: 'HISTORICO'
  }));
  const synthetic = [
    { key: `${previous.dateFrom}:${previous.dateTo}`, label: previous.dateTo, periodStart: previous.dateFrom, periodEnd: previous.dateTo, value: previousPeriodValue.value, targetValue: currentPeriodValue.targetValue, status: previousPeriodValue.status, source: 'COMPARACION' },
    { key: `${current.dateFrom}:${current.dateTo}`, label: current.dateTo, periodStart: current.dateFrom, periodEnd: current.dateTo, value: currentPeriodValue.value, targetValue: currentPeriodValue.targetValue, status: currentPeriodValue.status, source: 'ACTUAL' }
  ];
  for (const point of synthetic) {
    const index = points.findIndex((item) => item.key === point.key);
    if (index >= 0) points[index] = { ...points[index], ...point };
    else points.push(point);
  }
  return points.sort((a, b) => a.periodEnd.localeCompare(b.periodEnd)).slice(-12);
}

function getManagementDashboard(user, input = {}, options = {}) {
  if (!can(user, 'Management.Read')) throw managementError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const db = options.db || getDb(); ensureManagementCatalog(db);
  const now = options.now instanceof Date ? options.now : new Date();
  const timeZone = safeTimeZone(getSetting('locale.timezone', DEFAULT_TIME_ZONE));
  const scope = scopeFromInput(input, user, 'Management.Read', db);
  const period = normalizePeriod(input, now, timeZone);
  const comparisonPeriod = previousPeriod(period, now, timeZone);
  const view = managementRoleView(user);
  const allowedCodes = view.indicatorCodes ? new Set(view.indicatorCodes) : null;
  const rows = definitionRows(db).filter((row) => !allowedCodes || allowedCodes.has(row.code));
  const indicators = rows.map((row) => {
    const definition = hydrateDefinition(row);
    const currentCalc = currentIndicatorResult(db, row, scope, period, now);
    const previousResult = row.calculation_mode === 'SNAPSHOT'
      ? historicalSnapshotResult(db, row, scope, comparisonPeriod, currentCalc.target)
      : currentIndicatorResult(db, row, scope, comparisonPeriod, now).result;
    const current = { ...currentCalc.result, targetValue: Number(currentCalc.target.target_value), warningValue: Number(currentCalc.target.warning_value) };
    const previous = { ...previousResult, targetValue: Number(currentCalc.target.target_value), warningValue: Number(currentCalc.target.warning_value) };
    return {
      ...definition, target: hydrateTarget(currentCalc.target), current, previous,
      comparison: dashboardComparison(definition, current, previous),
      detail: MANAGEMENT_DETAIL_TARGETS[row.code] || null,
      actionText: managementPriorityText(row.code, current.status)
    };
  });
  const counts = { BIEN: 0, ATENCION: 0, URGENTE: 0, SIN_DATOS: 0 };
  const trends = { MEJORA: 0, EMPEORA: 0, ESTABLE: 0, SIN_DATOS: 0 };
  for (const item of indicators) { counts[item.current.status] += 1; trends[item.comparison.trend] += 1; }
  const overallStatus = counts.URGENTE ? 'URGENTE' : counts.ATENCION ? 'ATENCION' : counts.BIEN ? 'BIEN' : 'SIN_DATOS';
  const priorities = indicators.filter((item) => ['URGENTE', 'ATENCION'].includes(item.current.status))
    .sort((a, b) => (a.current.status === b.current.status ? a.name.localeCompare(b.name) : a.current.status === 'URGENTE' ? -1 : 1))
    .slice(0, 8).map((item) => ({ code: item.code, name: item.name, status: item.current.status, value: item.current.value, unit: item.unit,
      responsible: item.target.responsibleUserName || item.target.responsibleRoleName || 'Sin responsable', actionText: item.actionText, detail: item.detail }));
  const categories = [...new Set(indicators.map((item) => item.category))].map((category) => {
    const items = indicators.filter((item) => item.category === category);
    const urgent = items.filter((item) => item.current.status === 'URGENTE').length;
    const attention = items.filter((item) => item.current.status === 'ATENCION').length;
    return { category, total: items.length, urgent, attention, good: items.filter((item) => item.current.status === 'BIEN').length,
      status: urgent ? 'URGENTE' : attention ? 'ATENCION' : items.some((item) => item.current.status === 'BIEN') ? 'BIEN' : 'SIN_DATOS' };
  });
  const requestedTrendCode = String(input.trendCode || '').toUpperCase();
  const trendIndicator = indicators.find((item) => item.code === requestedTrendCode) || indicators.find((item) => item.current.status === 'URGENTE') || indicators[0] || null;
  let trend = null;
  if (trendIndicator) {
    const definitionRow = rows.find((row) => row.code === trendIndicator.code);
    trend = { code: trendIndicator.code, name: trendIndicator.name, unit: trendIndicator.unit,
      points: managementTrendPoints(db, definitionRow, scope, comparisonPeriod, period, trendIndicator.previous, trendIndicator.current) };
  }
  return {
    generatedAt: now.toISOString(), timeZone, scope, period, comparisonPeriod,
    view, summary: { overallStatus, total: indicators.length, good: counts.BIEN, attention: counts.ATENCION, urgent: counts.URGENTE,
      noData: counts.SIN_DATOS, improved: trends.MEJORA, worsened: trends.EMPEORA, stable: trends.ESTABLE, actionRequired: counts.URGENTE + counts.ATENCION },
    categories, priorities, indicators, trend, options: accessibleOptions(user, db)
  };
}

function saveSnapshot(db, definitionRow, target, scope, period, result, status, context, now, timeZone) {
  const measurementDate = localDateKey(now, timeZone);
  const details = { formulaCode: definitionRow.formula_code, formulaDescription: definitionRow.formula_description, sources: JSON.parse(definitionRow.source_json || '[]'), calculationMode: definitionRow.calculation_mode };
  const existing = db.prepare(`SELECT id FROM management_indicator_snapshot WHERE indicator_id=? AND scope_type=?
      AND IFNULL(site_id,'')=IFNULL(?, '') AND IFNULL(location_id,'')=IFNULL(?, '') AND measurement_date=? AND period_start=? AND period_end=?`)
    .get(definitionRow.id, scope.type, scope.siteId, scope.locationId, measurementDate, period.dateFrom, period.dateTo);
  const id = existing?.id || randomUUID();
  db.prepare(`INSERT INTO management_indicator_snapshot(id,indicator_id,target_id,scope_type,site_id,location_id,measurement_date,period_start,period_end,measured_at,
      value,numerator,denominator,target_value,warning_value,status,details_json,source,calculated_by_user_id,correlation_id,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET target_id=excluded.target_id,measured_at=excluded.measured_at,value=excluded.value,numerator=excluded.numerator,
      denominator=excluded.denominator,target_value=excluded.target_value,warning_value=excluded.warning_value,status=excluded.status,
      details_json=excluded.details_json,source=excluded.source,calculated_by_user_id=excluded.calculated_by_user_id,correlation_id=excluded.correlation_id,updated_at=excluded.updated_at`)
    .run(id, definitionRow.id, target.id, scope.type, scope.siteId, scope.locationId, measurementDate, period.dateFrom, period.dateTo, now.toISOString(),
      result.value, result.numerator, result.denominator, target.target_value, target.warning_value, status, JSON.stringify(details),
      context.source === 'SCHEDULER' ? 'SCHEDULER' : 'API', context.user?.id || null, context.correlationId || randomUUID(), now.toISOString(), now.toISOString());
  return db.prepare('SELECT * FROM management_indicator_snapshot WHERE id=?').get(id);
}

function evaluateWithDb(db, input, context, options = {}) {
  ensureManagementCatalog(db);
  const user = context.user;
  const permission = context.source === 'SCHEDULER' ? 'Management.Read' : 'Management.Evaluate';
  if (!can(user, permission) && !can(user, '*')) throw managementError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const now = options.now instanceof Date ? options.now : new Date();
  const timeZone = safeTimeZone(getSetting('locale.timezone', DEFAULT_TIME_ZONE));
  const period = normalizePeriod(input, now, timeZone);
  const scope = options.trustedScope || scopeFromInput(input, user, permission, db);
  const selectedCodes = Array.isArray(input.codes) && input.codes.length ? new Set(input.codes.map((value) => String(value).toUpperCase())) : null;
  const definitions = definitionRows(db).filter((row) => !selectedCodes || selectedCodes.has(row.code));
  if (selectedCodes && definitions.length !== selectedCodes.size) throw managementError('Uno o más indicadores no existen.', 'MANAGEMENT_INDICATOR_UNKNOWN');
  const results = [];
  for (const definitionRow of definitions) {
    const calculator = CALCULATORS[definitionRow.code];
    if (!calculator) throw managementError(`Indicador sin cálculo: ${definitionRow.code}.`, 'MANAGEMENT_CALCULATOR_MISSING', 500);
    const target = effectiveTarget(db, definitionRow.id, scope, now.toISOString());
    const result = calculator(db, scope, period, now);
    if (result.value !== null && Number.isFinite(result.value)) result.value = Math.round(result.value * 100) / 100;
    const status = indicatorStatus(definitionRow, result, target);
    const snapshot = saveSnapshot(db, definitionRow, target, scope, period, result, status, context, now, timeZone);
    results.push({ ...hydrateDefinition(definitionRow), target: hydrateTarget(target), result: hydrateSnapshot(snapshot) });
  }
  appendAudit({ actorUserId: context.user?.id || null, actorRole: context.user?.roleCodes?.join(',') || 'SYSTEM', action: 'MANAGEMENT.EVALUATE',
    entityType: 'management_indicator_snapshot', entityId: null, after: { scope, period: { dateFrom: period.dateFrom, dateTo: period.dateTo }, indicators: results.map((item) => ({ code: item.code, value: item.result.value, status: item.result.status })) },
    correlationId: context.correlationId || randomUUID(), source: context.source || 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
  return { generatedAt: now.toISOString(), timeZone, scope, period, indicators: results };
}

function evaluateManagementIndicators(input, context, options = {}) {
  return transaction((db) => evaluateWithDb(db, input || {}, context, { ...options, db }));
}

function validateTargetValues(definition, targetValue, warningValue) {
  if (!Number.isFinite(targetValue) || !Number.isFinite(warningValue) || targetValue < 0 || warningValue < 0) throw managementError('Objetivo y nivel de atención deben ser números no negativos.', 'MANAGEMENT_TARGET_VALUE_INVALID');
  if (definition.unit === 'PERCENT' && (targetValue > 100 || warningValue > 100)) throw managementError('Los porcentajes deben estar entre 0 y 100.', 'MANAGEMENT_TARGET_VALUE_INVALID');
  if (definition.direction === 'HIGHER_BETTER' && warningValue > targetValue) throw managementError('En este indicador, el nivel de atención no puede superar el objetivo.', 'MANAGEMENT_TARGET_ORDER_INVALID');
  if (definition.direction === 'LOWER_BETTER' && warningValue < targetValue) throw managementError('En este indicador, el nivel de atención no puede ser menor que el objetivo.', 'MANAGEMENT_TARGET_ORDER_INVALID');
}

function upsertManagementTarget(code, input, context) {
  return transaction((db) => {
    ensureManagementCatalog(db);
    if (!can(context.user, 'Management.Configure')) throw managementError('Permiso insuficiente.', 'FORBIDDEN', 403);
    const definitionRow = db.prepare('SELECT * FROM management_indicator_definition WHERE code=? AND active=1').get(String(code || '').toUpperCase());
    if (!definitionRow) throw managementError('Indicador inexistente.', 'MANAGEMENT_INDICATOR_UNKNOWN', 404);
    const scope = scopeFromInput(input, context.user, 'Management.Configure', db);
    const targetValue = Number(input.targetValue);
    const warningValue = Number(input.warningValue);
    validateTargetValues(definitionRow, targetValue, warningValue);
    const periodicity = String(input.periodicity || definitionRow.default_periodicity).toUpperCase();
    if (!PERIODICITIES.includes(periodicity)) throw managementError('Frecuencia de revisión inválida.', 'MANAGEMENT_PERIODICITY_INVALID');
    let responsibleUserId = input.responsibleUserId ? String(input.responsibleUserId) : null;
    let responsibleRoleId = input.responsibleRoleId ? String(input.responsibleRoleId) : null;
    if ((responsibleUserId || responsibleRoleId) && !can(context.user, 'Management.Assign')) throw managementError('No puede cambiar responsables.', 'FORBIDDEN', 403);
    if (responsibleUserId && !db.prepare('SELECT 1 FROM user_account WHERE id=? AND active=1 AND deleted_at IS NULL').get(responsibleUserId)) throw managementError('Responsable inexistente o inactivo.', 'MANAGEMENT_RESPONSIBLE_USER_INVALID');
    if (responsibleRoleId && !db.prepare('SELECT 1 FROM role WHERE id=? AND active=1').get(responsibleRoleId)) throw managementError('Rol responsable inexistente o inactivo.', 'MANAGEMENT_RESPONSIBLE_ROLE_INVALID');
    if (!responsibleUserId && !responsibleRoleId) throw managementError('Debe indicar una persona o un rol responsable.', 'MANAGEMENT_RESPONSIBLE_REQUIRED');
    const now = new Date().toISOString();
    const current = db.prepare(`SELECT * FROM management_indicator_target WHERE indicator_id=? AND scope_type=?
      AND IFNULL(site_id,'')=IFNULL(?, '') AND IFNULL(location_id,'')=IFNULL(?, '') AND active=1`)
      .get(definitionRow.id, scope.type, scope.siteId, scope.locationId);
    let id;
    if (current) {
      const version = Number(input.version);
      if (!Number.isInteger(version) || version !== current.version) throw managementError('La configuración fue modificada por otra operación.', 'CONCURRENCY_CONFLICT', 409);
      db.prepare(`UPDATE management_indicator_target SET target_value=?,warning_value=?,responsible_user_id=?,responsible_role_id=?,periodicity=?,
          version=version+1,updated_by_user_id=?,updated_at=? WHERE id=? AND version=?`)
        .run(targetValue, warningValue, responsibleUserId, responsibleRoleId, periodicity, context.user.id, now, current.id, current.version);
      id = current.id;
    } else {
      id = randomUUID();
      db.prepare(`INSERT INTO management_indicator_target(id,indicator_id,scope_type,site_id,location_id,target_value,warning_value,responsible_user_id,
          responsible_role_id,periodicity,active,version,valid_from,valid_to,created_by_user_id,updated_by_user_id,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,1,1,?,NULL,?,?,?,?)`)
        .run(id, definitionRow.id, scope.type, scope.siteId, scope.locationId, targetValue, warningValue, responsibleUserId, responsibleRoleId,
          periodicity, now, context.user.id, context.user.id, now, now);
    }
    const after = effectiveTarget(db, definitionRow.id, scope, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'MANAGEMENT.TARGET_UPDATE', entityType: 'management_indicator_target', entityId: id,
      before: current || null, after, correlationId: context.correlationId, source: context.source || 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return { indicator: hydrateDefinition(definitionRow), scope, target: hydrateTarget(after) };
  });
}

function listManagementSnapshots(user, input = {}, options = {}) {
  if (!can(user, 'Management.Read')) throw managementError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const db = options.db || getDb(); ensureManagementCatalog(db);
  const scope = scopeFromInput(input, user, 'Management.Read', db);
  const limit = Math.min(1000, Math.max(1, Number(input.limit) || 200));
  const code = input.code ? String(input.code).toUpperCase() : null;
  const rows = db.prepare(`SELECT mis.*,mid.code,mid.name,mid.unit,mid.category FROM management_indicator_snapshot mis
    JOIN management_indicator_definition mid ON mid.id=mis.indicator_id
    WHERE mis.scope_type=? AND IFNULL(mis.site_id,'')=IFNULL(?, '') AND IFNULL(mis.location_id,'')=IFNULL(?, '')
      AND (? IS NULL OR mid.code=?) ORDER BY mis.measured_at DESC LIMIT ?`)
    .all(scope.type, scope.siteId, scope.locationId, code, code, limit);
  return { scope, items: rows.map((row) => ({ code: row.code, name: row.name, unit: row.unit, category: row.category, ...hydrateSnapshot(row) })) };
}

function evaluateConfiguredScopes(db, context, options = {}) {
  ensureManagementCatalog(db);
  const scopes = db.prepare(`SELECT DISTINCT scope_type,site_id,location_id FROM management_indicator_target WHERE active=1 ORDER BY scope_type,site_id,location_id`).all();
  let processed = 0; let generated = 0;
  const details = [];
  for (const row of scopes) {
    const scope = { type: row.scope_type, siteId: row.site_id, locationId: row.location_id, label: row.scope_type };
    const result = evaluateWithDb(db, {}, context, { now: options.now, trustedScope: scope });
    processed += result.indicators.length; generated += result.indicators.length;
    details.push({ scope, indicators: result.indicators.length });
  }
  return { processed, generated, scopes: scopes.length, details };
}

module.exports = {
  INDICATOR_DEFINITIONS,
  ensureManagementCatalog,
  getManagementModel,
  getManagementDashboard,
  evaluateManagementIndicators,
  evaluateConfiguredScopes,
  upsertManagementTarget,
  listManagementSnapshots,
  normalizePeriod,
  indicatorStatus,
  scopeFromInput
};
