'use strict';

const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb } = require('../db/database');
const { scopeWhere } = require('../security/scope');
const { getSetting } = require('./settings-service');
const { listAvailableAssetsPage, createRequest } = require('./request-service');
const { listCustodiesPage, getCustody, declareReturn } = require('./custody-service');
const { saveOwnedEvidenceDataUrl, getOwnedEvidence } = require('./evidence-service');
const { getVehicleRequestDetail, getVehicleReturnDetail, createVehicleRequest, saveVehicleRequestPhoto, declareVehicleReturn, saveVehicleReturnPhoto } = require('./vehicle-warehouse-service');

function error(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function tabletBootstrap() {
  return {
    application: 'INGAR Warehouse',
    organizationName: String(getSetting('organization.name', 'Organización') || 'Organización'),
    terminalTitle: 'Mi operación',
    credential: {
      minLength: Number(getSetting('security.operationalCredentialMinLength', runtime.operationalCredentialMinLength)),
      maxLength: Number(getSetting('security.operationalCredentialMaxLength', runtime.operationalCredentialMaxLength)),
      acceptedIdentifiers: ['USUARIO', 'LEGAJO', 'DNI', 'ALTA_SIN_IDENTIFICADOR']
    },
    session: {
      authority: 'UNIFIED_AUTH',
      cookie: runtime.cookieName,
      maxSeconds: Number(getSetting('security.sessionSeconds', runtime.normalSessionSeconds))
    }
  };
}

function compactAsset(item) {
  return {
    id: item.id,
    internalCode: item.internal_code,
    description: item.description,
    brand: item.brand || null,
    model: item.model || null,
    serialNumber: item.serial_number || null,
    licensePlate: item.license_plate || null,
    quantityAvailable: Number(item.quantity_available || 0),
    unitOfMeasure: item.unit_of_measure || null,
    categoryId: item.category_id,
    categoryCode: item.category_code,
    categoryName: item.category_name,
    nature: item.category_nature,
    requiresReturn: Boolean(item.requires_return),
    requiresWorkOrder: Boolean(item.requires_work_order),
    photoAvailable: Boolean(item.photo_evidence_id),
    photoUrl: item.photo_evidence_id ? `/api/v1/operation/assets/${encodeURIComponent(item.id)}/photo` : null,
    locationId: item.location_id,
    locationCode: item.location_code,
    locationName: item.location_name,
    siteId: item.site_id,
    siteCode: item.site_code,
    siteName: item.site_name
  };
}

function tabletAssetPhoto(assetId, user) {
  const db = getDb();
  const asset = db.prepare(`SELECT a.id,a.photo_evidence_id
    FROM asset a
    WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
  if (!asset || !asset.photo_evidence_id) throw error(404, 'ASSET_PHOTO_NOT_FOUND', 'Esta herramienta todavía no tiene foto.');

  const ownOpenCustody = db.prepare(`SELECT 1 FROM custody
    WHERE asset_id=? AND person_id=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE') LIMIT 1`).get(assetId, user.personId);
  const ownPersonalKit = db.prepare(`SELECT 1 FROM kit_person_assignment kpa
    JOIN kit_definition kd ON kd.kit_asset_id=kpa.kit_asset_id AND kd.ownership_mode='PERSONAL'
    WHERE kpa.person_id=? AND kpa.status='ACTIVE' AND (kpa.kit_asset_id=? OR EXISTS(
      SELECT 1 FROM kit_component kc WHERE kc.kit_asset_id=kpa.kit_asset_id AND kc.component_asset_id=? AND kc.active=1
    )) LIMIT 1`).get(user.personId, assetId, assetId);
  const ownRequestHistory = db.prepare(`SELECT 1 FROM request_item ri
    JOIN "request" r ON r.id=ri.request_id
    WHERE ri.asset_id=? AND r.requester_person_id=? LIMIT 1`).get(assetId, user.personId);

  // Reutiliza el motor de disponibilidad para operación nueva y, además, conserva la identificación
  // visual de bienes que el propio técnico pidió en el pasado. Esto no abre archivos ajenos: sólo la
  // foto maestra del asset que está vinculado a una solicitud de esa misma identidad persistente.
  const normallyVisible = listAvailableAssetsPage({ assetId, limit: 1, offset: 0, operationType: 'RETIRO' }, user).items.some((item) => item.id === assetId);

  if (!normallyVisible && !ownOpenCustody && !ownPersonalKit && !ownRequestHistory) throw error(403, 'ASSET_PHOTO_FORBIDDEN', 'La foto no corresponde a un bien disponible, asignado o pedido por este usuario.');
  const evidence = getOwnedEvidence(asset.photo_evidence_id, 'ASSET', asset.id, 'PHOTO');
  if (!evidence) throw error(404, 'ASSET_PHOTO_NOT_FOUND', 'La foto de esta herramienta no está disponible.');
  return evidence;
}

function tabletAvailability(flow, filters, user) {
  const mode = String(flow || '').toUpperCase();
  if (!['TOOLS', 'VEHICLES'].includes(mode)) throw error(422, 'TABLET_FLOW_INVALID', 'Opción no disponible.');
  const common = {
    search: filters.search || null,
    limit: Math.min(100, Math.max(1, Number(filters.limit) || 60)),
    offset: Math.max(0, Number(filters.offset) || 0),
    operationType: 'RETIRO'
  };
  if (mode === 'VEHICLES') {
    const page = listAvailableAssetsPage({ ...common, nature: 'VEHICULO' }, user);
    const db = getDb();
    const items = page.items.map((row) => {
      const item = compactAsset(row);
      const profile = db.prepare('SELECT current_odometer,current_hourmeter,fuel_type,usage_unit FROM vehicle_profile WHERE asset_id=?').get(item.id);
      return { ...item, currentOdometer: Number(profile?.current_odometer ?? row.odometer ?? 0), currentHourmeter: Number(profile?.current_hourmeter ?? 0), fuelType: profile?.fuel_type || row.fuel_type || null, usageUnit: profile?.usage_unit || 'KILOMETROS' };
    });
    return { flow: mode, items, total: page.total };
  }
  const page = listAvailableAssetsPage({ ...common, natures: 'CANTIDAD,CONSUMIBLE,SERIADO,KIT' }, user);
  return { flow: mode, items: page.items.map(compactAsset), total: page.total };
}

function historyDateBoundary(value, endOfDay = false) {
  const text = String(value || '').trim();
  if (!text) return null;
  const date = new Date(`${text}T${endOfDay ? '23:59:59.999' : '00:00:00'}`);
  return Number.isFinite(date.getTime()) ? date.toISOString() : null;
}

function requestLifecycleCte(baseWhereSql) {
  return `WITH eligible AS (
      SELECT r.* FROM "request" r WHERE ${baseWhereSql}
    ), item_stats AS (
      SELECT ri.request_id,
        SUM(CASE WHEN COALESCE(rihs.requires_return_snapshot,ac.requires_return,0)=1 THEN 1 ELSE 0 END) AS returnable_count,
        SUM(CASE WHEN COALESCE(rihs.requires_return_snapshot,ac.requires_return,0)=1 AND crr.received_at IS NOT NULL THEN 1 ELSE 0 END) AS returned_count,
        MAX(CASE WHEN COALESCE(rihs.requires_return_snapshot,ac.requires_return,0)=1 THEN crr.received_at END) AS max_returned_at,
        MAX(CASE WHEN COALESCE(rihs.requires_return_snapshot,ac.requires_return,0)=1 AND crr.received_at IS NOT NULL AND COALESCE(crr.condition,'CONFORME')<>'CONFORME' THEN 1 ELSE 0 END) AS observed_return
      FROM eligible er
      JOIN request_item ri ON ri.request_id=er.id
      LEFT JOIN request_item_history_snapshot rihs ON rihs.request_id=ri.request_id AND rihs.request_item_id=ri.id
      LEFT JOIN asset a ON a.id=ri.asset_id
      LEFT JOIN asset_category ac ON ac.id=a.category_id
      LEFT JOIN custody c ON c.request_item_id=ri.id
      LEFT JOIN custody_return_record crr ON crr.custody_id=c.id
      GROUP BY ri.request_id
    ), handover_stats AS (
      SELECT h.request_id,MAX(CASE WHEN h.type='ENTREGA' THEN h.occurred_at END) AS last_handover_at
      FROM eligible er JOIN handover h ON h.request_id=er.id GROUP BY h.request_id
    ), event_stats AS (
      SELECT rse.request_id,
        MAX(CASE WHEN rse.to_status='EXPIRADA' THEN rse.occurred_at END) AS expired_at,
        MAX(CASE WHEN rse.to_status='CANCELADA' THEN rse.occurred_at END) AS cancelled_event_at
      FROM eligible er JOIN request_status_event rse ON rse.request_id=er.id GROUP BY rse.request_id
    ), raw AS (
      SELECT r.*,
        COALESCE(rhs.site_name_snapshot,s.name) AS site_name,
        COALESCE(rhs.location_name_snapshot,sl.name) AS location_name,
        COALESCE(rhs.requester_name_snapshot,p.full_name) AS requester_name,
        COALESCE(rhs.requester_username_snapshot,ua.username) AS requester_username,
        COALESCE(ist.returnable_count,0) AS returnable_count,
        COALESCE(ist.returned_count,0) AS returned_count,
        COALESCE(ist.observed_return,0) AS observed_return,
        ist.max_returned_at,hs.last_handover_at,es.expired_at,es.cancelled_event_at
      FROM eligible r
      LEFT JOIN request_history_snapshot rhs ON rhs.request_id=r.id
      LEFT JOIN person p ON p.id=r.requester_person_id
      LEFT JOIN user_account ua ON ua.person_id=r.requester_person_id
      LEFT JOIN site s ON s.id=r.site_id
      LEFT JOIN storage_location sl ON sl.id=r.location_id
      LEFT JOIN item_stats ist ON ist.request_id=r.id
      LEFT JOIN handover_stats hs ON hs.request_id=r.id
      LEFT JOIN event_stats es ON es.request_id=r.id
    ), lifecycle AS (
      SELECT raw.*,
        CASE
          WHEN status IN ('CANCELADA','EXPIRADA') THEN 1
          WHEN returnable_count>0 AND returned_count=returnable_count THEN 1
          WHEN returnable_count=0 AND status='ENTREGADA' THEN 1
          ELSE 0
        END AS completed,
        CASE
          WHEN status='CANCELADA' THEN COALESCE(cancelled_at,cancelled_event_at,updated_at)
          WHEN status='EXPIRADA' THEN COALESCE(expired_at,updated_at)
          WHEN returnable_count>0 AND returned_count=returnable_count THEN max_returned_at
          WHEN returnable_count=0 AND status='ENTREGADA' THEN COALESCE(last_handover_at,updated_at)
          ELSE NULL
        END AS completion_at,
        CASE
          WHEN status='CANCELADA' THEN 'CANCELADA'
          WHEN status='EXPIRADA' THEN 'EXPIRADA'
          WHEN returnable_count>0 AND returned_count=returnable_count AND observed_return=1 THEN 'DEVUELTO_CON_OBSERVACION'
          WHEN returnable_count>0 AND returned_count=returnable_count THEN 'DEVUELTO'
          WHEN returnable_count=0 AND status='ENTREGADA' THEN 'ENTREGADA'
          ELSE NULL
        END AS completion_result
      FROM raw
    )`;
}

function tabletRequestPage(filters, user) {
  const db = getDb();
  const view = String(filters.view || 'active').toLowerCase() === 'history' ? 'history' : 'active';
  const limit = Math.min(view === 'history' ? 200 : 100, Math.max(1, Number(filters.limit) || (view === 'history' ? 50 : 100)));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const baseWhere = ['r.requester_person_id=?'];
  const baseParams = [user.personId];

  // El histórico propio depende de la identidad persistente de la persona, no del
  // alcance operativo actual. Así un cambio de sede/rol no hace desaparecer pedidos viejos.
  if (view !== 'history') {
    const scope = scopeWhere(user, 'Requests.ReadOwn', 'r.site_id', 'r.location_id', db);
    baseWhere.unshift(`(${scope.sql})`);
    baseParams.unshift(...scope.params);
  }

  const q = String(filters.search || '').trim();
  if (q) {
    baseWhere.push(`(r.request_number LIKE ? OR r.reason LIKE ? OR EXISTS (
      SELECT 1 FROM request_item sri
      LEFT JOIN request_item_history_snapshot sihs ON sihs.request_id=sri.request_id AND sihs.request_item_id=sri.id
      LEFT JOIN asset sa ON sa.id=sri.asset_id
      WHERE sri.request_id=r.id AND (
        COALESCE(sihs.internal_code_snapshot,sa.internal_code,'') LIKE ? OR
        COALESCE(sihs.description_snapshot,sa.description,'') LIKE ? OR
        COALESCE(sihs.license_plate_snapshot,sa.license_plate,'') LIKE ? OR
        COALESCE(sihs.serial_number_snapshot,sa.serial_number,'') LIKE ?)
    ) OR EXISTS (
      SELECT 1 FROM request_history_snapshot shs
      WHERE shs.request_id=r.id AND (shs.site_name_snapshot LIKE ? OR shs.location_name_snapshot LIKE ?)
    ))`);
    const like = `%${q}%`; baseParams.push(like,like,like,like,like,like,like,like);
  }
  const type = String(filters.type || '').trim().toUpperCase();
  if (type) {
    baseWhere.push(`EXISTS (SELECT 1 FROM request_item tri
      LEFT JOIN request_item_history_snapshot tihs ON tihs.request_id=tri.request_id AND tihs.request_item_id=tri.id
      LEFT JOIN asset ta ON ta.id=tri.asset_id
      LEFT JOIN asset_category tac ON tac.id=ta.category_id
      WHERE tri.request_id=r.id AND COALESCE(tihs.category_nature_snapshot,tac.nature)=?)`);
    baseParams.push(type === 'HERRAMIENTA' ? 'CANTIDAD' : type);
  }
  if (view === 'history') {
    const from = historyDateBoundary(filters.dateFrom, false);
    const to = historyDateBoundary(filters.dateTo, true);
    if (from) { baseWhere.push('r.created_at>=?'); baseParams.push(from); }
    if (to) { baseWhere.push('r.created_at<=?'); baseParams.push(to); }
  }

  const cte = requestLifecycleCte(baseWhere.join(' AND '));
  const outerWhere = [];
  const outerParams = [];
  if (view === 'history') {
    outerWhere.push('completed=1');
    const result = String(filters.result || '').trim().toUpperCase();
    if (result) { outerWhere.push('completion_result=?'); outerParams.push(result); }
  } else {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    outerWhere.push('(completed=0 OR (completion_at IS NOT NULL AND completion_at>=?))');
    outerParams.push(cutoff);
  }
  const outerSql = outerWhere.length ? `WHERE ${outerWhere.join(' AND ')}` : '';
  const allParams = [...baseParams, ...outerParams];
  const total = Number(db.prepare(`${cte} SELECT COUNT(*) AS n FROM lifecycle ${outerSql}`).get(...allParams)?.n || 0);
  const rows = db.prepare(`${cte} SELECT * FROM lifecycle ${outerSql}
    ORDER BY ${view === 'history' ? 'created_at DESC,completion_at DESC' : 'created_at DESC'} LIMIT ? OFFSET ?`).all(...allParams, limit, offset);
  if (!rows.length) return { items: [], total, limit, offset, hasMore: false, view };

  const ids = rows.map((row) => row.id);
  const placeholders = ids.map(() => '?').join(',');
  const itemRows = db.prepare(`SELECT ri.request_id,ri.id AS request_item_id,ri.asset_id,ri.quantity,ri.status,ri.work_order_required,ri.work_order_reference,
      COALESCE(rihs.internal_code_snapshot,a.internal_code) AS internal_code,
      COALESCE(rihs.description_snapshot,a.description) AS description,
      COALESCE(rihs.license_plate_snapshot,a.license_plate) AS license_plate,
      COALESCE(rihs.serial_number_snapshot,a.serial_number) AS serial_number,
      COALESCE(rihs.category_nature_snapshot,ac.nature) AS category_nature,
      COALESCE(rihs.category_name_snapshot,ac.name) AS category_name,
      COALESCE(rihs.requires_return_snapshot,ac.requires_return,0) AS requires_return,
      COALESCE(rihs.work_order_required_snapshot,ri.work_order_required,0) AS work_order_required_effective,
      COALESCE(rihs.work_order_reference_snapshot,ri.work_order_reference) AS work_order_reference_effective,
      a.photo_evidence_id,
      c.id AS custody_id,c.status AS custody_status,c.opened_at,c.closed_at,crr.received_at,crr.condition,crr.timing_status,crr.overdue_seconds,
      rr.id AS receipt_id,rr.receipt_number
    FROM request_item ri
    LEFT JOIN request_item_history_snapshot rihs ON rihs.request_id=ri.request_id AND rihs.request_item_id=ri.id
    LEFT JOIN asset a ON a.id=ri.asset_id
    LEFT JOIN asset_category ac ON ac.id=a.category_id
    LEFT JOIN custody c ON c.request_item_id=ri.id
    LEFT JOIN custody_return_record crr ON crr.custody_id=c.id
    LEFT JOIN custody_return_receipt rr ON rr.custody_id=c.id
    WHERE ri.request_id IN (${placeholders})
    ORDER BY ri.request_id,COALESCE(rihs.internal_code_snapshot,a.internal_code)`).all(...ids);
  const byRequest = new Map(ids.map((id) => [id, []]));
  for (const row of itemRows) byRequest.get(row.request_id)?.push(row);

  const eventRows = db.prepare(`SELECT rse.request_id,rse.from_status,rse.to_status,rse.reason,rse.occurred_at,
      ua.username AS actor_username,p.full_name AS actor_name
    FROM request_status_event rse
    LEFT JOIN user_account ua ON ua.id=rse.actor_user_id
    LEFT JOIN person p ON p.id=ua.person_id
    WHERE rse.request_id IN (${placeholders})
    ORDER BY rse.request_id,rse.occurred_at`).all(...ids);
  const eventsByRequest = new Map(ids.map((id) => [id, []]));
  for (const event of eventRows) eventsByRequest.get(event.request_id)?.push({
    fromStatus: event.from_status || null,
    toStatus: event.to_status,
    reason: event.reason || null,
    occurredAt: event.occurred_at,
    actorUsername: event.actor_username || null,
    actorName: event.actor_name || null
  });

  const items = rows.map((row) => {
    const requestItems = (byRequest.get(row.id) || []).map((entry) => {
      let lifecycleStatus = entry.status || null;
      if (entry.received_at) lifecycleStatus = entry.condition && entry.condition !== 'CONFORME' ? 'DEVUELTO_CON_OBSERVACION' : 'DEVUELTO';
      else if (['DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE'].includes(entry.custody_status)) lifecycleStatus = 'DEVOLUCION_DECLARADA';
      else if (['ABIERTA','TRANSFERENCIA_PENDIENTE'].includes(entry.custody_status)) lifecycleStatus = 'EN_USO';
      return {
        assetId: entry.asset_id,
        internalCode: entry.internal_code,
        description: entry.description,
        quantity: Number(entry.quantity || 1),
        status: entry.status,
        lifecycleStatus,
        openedAt: entry.opened_at || null,
        returnedAt: entry.received_at || null,
        returnCondition: entry.condition || null,
        timingStatus: entry.timing_status || null,
        overdueSeconds: Number(entry.overdue_seconds || 0),
        custodyId: entry.custody_id || null,
        hasReturnReceipt: Boolean(entry.receipt_id),
        returnReceiptNumber: entry.receipt_number || null,
        nature: entry.category_nature || null,
        categoryName: entry.category_name || null,
        requiresReturn: Boolean(entry.requires_return),
        workOrderRequired: Boolean(entry.work_order_required_effective),
        workOrderReference: entry.work_order_reference_effective || null,
        licensePlate: entry.license_plate || null,
        serialNumber: entry.serial_number || null,
        photoAvailable: Boolean(entry.photo_evidence_id),
        photoUrl: entry.photo_evidence_id && entry.asset_id ? `/api/v1/operation/assets/${encodeURIComponent(entry.asset_id)}/photo` : null
      };
    });
    const returnable = requestItems.filter((entry) => entry.requiresReturn);
    let displayStatus = row.status;
    if (row.completed && row.completion_result) displayStatus = row.completion_result;
    else if (returnable.some((entry) => entry.lifecycleStatus === 'DEVOLUCION_DECLARADA')) displayStatus = 'DEVOLUCION_DECLARADA';
    else if (returnable.some((entry) => entry.lifecycleStatus === 'EN_USO') && row.status === 'ENTREGADA') displayStatus = 'EN_USO';
    return {
      id: row.id,
      requestNumber: row.request_number,
      status: row.status,
      displayStatus,
      operationType: row.operation_type,
      workOrderReference: row.work_order_reference || null,
      reason: row.reason,
      neededAt: row.needed_at,
      dueAt: row.due_at,
      createdAt: row.created_at,
      lastHandoverAt: row.last_handover_at || null,
      requesterName: row.requester_name || null,
      requesterUsername: row.requester_username || null,
      siteName: row.site_name,
      locationName: row.location_name,
      itemCount: requestItems.length,
      items: requestItems,
      events: eventsByRequest.get(row.id) || [],
      history: { completed: Boolean(row.completed), completionAt: row.completion_at || null, result: row.completion_result || null }
    };
  });
  return { items, total, limit, offset, hasMore: offset + items.length < total, view };
}

function tabletRequests(filters, user) {
  return tabletRequestPage(filters, user);
}

function compactCustody(item) {
  const returnRecord = item.returnRecord || null;
  const physicallyReturned = Boolean(returnRecord?.received_at);
  const returnedWithObservation = physicallyReturned && String(returnRecord?.condition || '').toUpperCase() !== 'CONFORME';
  const displayStatus = physicallyReturned ? (returnedWithObservation ? 'DEVUELTO_CON_OBSERVACION' : 'DEVUELTO') : item.status;
  return {
    id: item.id,
    status: item.status,
    displayStatus,
    returnedAt: returnRecord?.received_at || item.closed_at || null,
    returnCondition: returnRecord?.condition || null,
    version: item.version,
    openedAt: item.opened_at,
    dueAt: item.due_at,
    declaredReturnAt: item.declared_return_at || null,
    internalCode: item.internal_code,
    description: item.description,
    serialNumber: item.serial_number || null,
    licensePlate: item.license_plate || null,
    nature: item.category_nature,
    categoryName: item.category_name,
    siteName: item.site_name,
    locationName: item.location_name,
    requestNumber: item.request_number,
    quantity: Number(item.quantity || 0),
    returnedQuantity: Number(item.returned_quantity || 0),
    quantityOutstanding: Number(item.quantity_outstanding ?? item.quantity ?? 0),
    assetId: item.asset_id,
    photoAvailable: Boolean(item.photo_evidence_id),
    photoUrl: item.photo_evidence_id ? `/api/v1/operation/assets/${encodeURIComponent(item.asset_id)}/photo` : null,
    overdue: Boolean(item.overdue),
    returnDeclaration: item.returnDeclaration || null,
    returnEvidence: Array.isArray(item.returnEvidence) ? item.returnEvidence : [],
    returnReceipt: item.returnReceipt || null,
    canDeclareReturn: ['CANTIDAD','SERIADO','KIT'].includes(String(item.category_nature || '').toUpperCase()) && Number(item.requires_return || 0) === 1 && item.status === 'ABIERTA'
  };
}

function tabletCustodies(filters, user) {
  const page = listCustodiesPage({
    statuses: filters.statuses || 'ABIERTA,DEVOLUCION_DECLARADA,RECEPCION_PENDIENTE,TRANSFERENCIA_PENDIENTE',
    limit: Math.min(100, Math.max(1, Number(filters.limit) || 50)),
    offset: Math.max(0, Number(filters.offset) || 0),
    search: filters.search || undefined
  }, user, false);
  const items = page.items
    .filter((row) => !row.returnRecord?.received_at)
    .map((row) => {
      const item = compactCustody(row);
      if (String(item.nature || '').toUpperCase() === 'VEHICULO') {
        try {
          const detail = getVehicleReturnDetail(item.id, user);
          item.vehicleDeparture = detail.request;
          item.vehicleReturn = detail.returnDetail;
          item.canDeclareReturn = item.status === 'ABIERTA';
        } catch {}
      }
      return item;
    });
  return { items, total: page.total, limit: page.limit, offset: page.offset };
}

function tabletCreateRequest(input, context) {
  const rawItems = Array.isArray(input?.items) ? input.items : (input?.assetId ? [{ assetId: input.assetId, quantity: input.quantity || 1 }] : []);
  if (!rawItems.length) throw error(422, 'TABLET_ITEMS_REQUIRED', 'Agregá al menos una herramienta al pedido.');
  const maxItems = Number(getSetting('request.maxItems', 20));
  if (rawItems.length > maxItems) throw error(422, 'TABLET_ITEMS_LIMIT', `El pedido no puede superar ${maxItems} renglones.`);
  const reason = String(input?.reason || '').trim();
  if (reason.length > 1000) throw error(422, 'TABLET_REASON_INVALID', 'La observación no puede superar 1000 caracteres.');
  const workOrderReference = String(input?.workOrderReference || '').trim();
  if (!workOrderReference) throw error(422, 'WORK_ORDER_REQUIRED', 'Ingresá la OT antes de enviar el pedido.');

  const db = getDb();
  const seen = new Set();
  const items = [];
  let siteId = null;
  let locationId = null;
  let requiresDueAt = false;
  for (const raw of rawItems) {
    const assetId = String(raw?.assetId || '').trim();
    if (!assetId) throw error(422, 'TABLET_ASSET_REQUIRED', 'Seleccioná un bien.');
    if (seen.has(assetId)) throw error(422, 'REQUEST_ITEM_DUPLICATE', 'Una herramienta no puede aparecer dos veces en el pedido.');
    seen.add(assetId);
    const quantity = Number(raw?.quantity || 1);
    if (!Number.isFinite(quantity) || quantity <= 0) throw error(422, 'TABLET_QUANTITY_INVALID', 'Cantidad inválida.');
    const asset = db.prepare(`SELECT a.id,a.location_id,ac.nature,ac.requires_return,sl.site_id
      FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
    if (!asset) throw error(404, 'ASSET_NOT_FOUND', 'Uno de los bienes ya no está disponible.');
    const nature = String(asset.nature || '').toUpperCase();
    if (nature === 'VEHICULO') throw error(409, 'VEHICLE_FORM_REQUIRED', 'Los vehículos usan su formulario específico.');
    if (['SERIADO','KIT'].includes(nature) && quantity !== 1) throw error(422, 'SERIAL_QUANTITY_INVALID', 'Un bien individualizado se pide de a una unidad.');
    if (siteId === null) { siteId = asset.site_id; locationId = asset.location_id; }
    if (asset.site_id !== siteId || asset.location_id !== locationId) throw error(422, 'TABLET_CART_LOCATION_MIXED', 'Todas las herramientas del pedido deben pertenecer al mismo pañol.');
    if (['SERIADO','KIT'].includes(nature) || Number(asset.requires_return || 0) === 1) requiresDueAt = true;
    items.push({ assetId, quantity });
  }

  const neededAtRaw = input?.neededAt || new Date().toISOString();
  const neededDate = new Date(neededAtRaw);
  if (!Number.isFinite(neededDate.getTime()) || neededDate.getTime() < Date.now() - 5 * 60_000 || neededDate.getTime() > Date.now() + 365 * 24 * 3600_000) {
    throw error(422, 'TABLET_NEEDED_AT_INVALID', 'La fecha en que necesitás el bien no es válida.');
  }
  let dueAt = input?.dueAt || null;
  if (requiresDueAt) {
    if (!dueAt) throw error(422, 'SERIAL_DUE_AT_REQUIRED', 'Indicá cuándo pensás devolver los bienes retornables.');
    const parsedDue = new Date(dueAt);
    if (!Number.isFinite(parsedDue.getTime()) || parsedDue.getTime() <= neededDate.getTime()) throw error(422, 'SERIAL_DUE_AT_INVALID', 'La devolución prevista debe ser posterior al momento en que necesitás los bienes.');
    dueAt = parsedDue.toISOString();
  }

  return createRequest({
    operationType: 'RETIRO',
    siteId,
    locationId,
    neededAt: neededDate.toISOString(),
    dueAt,
    reason,
    workOrderReference,
    clientRequestId: String(input?.clientRequestId || `tablet-${randomUUID()}`),
    items
  }, context);
}

function requireOwnSerializedRequest(requestId, user) {
  const db = getDb();
  const row = db.prepare(`SELECT r.id,r.requester_person_id,COUNT(*) AS item_count,
      SUM(CASE WHEN ac.nature IN ('SERIADO','KIT') THEN 1 ELSE 0 END) AS serialized_count
    FROM "request" r JOIN request_item ri ON ri.request_id=r.id JOIN asset a ON a.id=ri.asset_id JOIN asset_category ac ON ac.id=a.category_id
    WHERE r.id=? GROUP BY r.id`).get(requestId);
  if (!row) throw error(404, 'REQUEST_NOT_FOUND', 'Pedido no encontrado.');
  if (row.requester_person_id !== user.personId) throw error(403, 'REQUEST_FORBIDDEN', 'Ese pedido no es tuyo.');
  if (Number(row.serialized_count) < 1) throw error(409, 'SERIAL_REQUEST_REQUIRED', 'La foto corresponde a pedidos que incluyen al menos un bien individualizado.');
  return row;
}

function tabletSaveSerializedRequestPhoto(requestId, input, context) {
  requireOwnSerializedRequest(requestId, context.user);
  return saveOwnedEvidenceDataUrl(input, { ownerType: 'REQUEST', ownerId: requestId, purpose: 'SERIALIZED_REQUEST_PHOTO' }, context, {
    allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'],
    maxBytes: runtime.maxImageBytes
  });
}

function tabletDeclareSerializedReturn(custodyId, input, context) {
  const custody = getCustody(custodyId, context.user, false);
  if (!['CANTIDAD','SERIADO','KIT'].includes(String(custody.category_nature || '').toUpperCase()) || Number(custody.requires_return || 0) !== 1) throw error(409, 'RETURNABLE_CUSTODY_REQUIRED', 'Esta devolución no corresponde a un bien retornable.');
  const condition = String(input?.condition || 'CONFORME').toUpperCase();
  const problemReported = input?.problemReported === true || condition !== 'CONFORME';
  const notes = String(input?.notes || '').trim() || null;
  const reason = notes || (problemReported ? 'Devolución con observación informada por el custodio.' : 'Devolución solicitada por el custodio.');
  return declareReturn(custodyId, {
    version: Number(input?.version),
    condition,
    problemReported,
    notes,
    reason,
    returnQuantity: input?.returnQuantity
  }, context, false);
}

function tabletSaveSerializedReturnPhoto(custodyId, input, context) {
  const custody = getCustody(custodyId, context.user, false);
  if (!['CANTIDAD','SERIADO','KIT'].includes(String(custody.category_nature || '').toUpperCase()) || Number(custody.requires_return || 0) !== 1) throw error(409, 'RETURNABLE_CUSTODY_REQUIRED', 'La foto corresponde a la devolución de un bien retornable.');
  if (custody.status !== 'DEVOLUCION_DECLARADA') throw error(409, 'SERIAL_RETURN_NOT_DECLARED', 'Primero solicitá la devolución del bien.');
  return saveOwnedEvidenceDataUrl(input, { ownerType: 'CUSTODY', ownerId: custodyId, purpose: 'SERIALIZED_RETURN_PHOTO' }, context, {
    allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'],
    maxBytes: runtime.maxImageBytes
  });
}

module.exports = {
  tabletBootstrap,
  tabletAvailability,
  tabletAssetPhoto,
  tabletRequests,
  tabletCustodies,
  tabletCreateRequest,
  tabletSaveSerializedRequestPhoto,
  tabletDeclareSerializedReturn,
  tabletSaveSerializedReturnPhoto,
  createVehicleRequest,
  saveVehicleRequestPhoto,
  declareVehicleReturn,
  saveVehicleReturnPhoto,
  getVehicleRequestDetail,
  getVehicleReturnDetail
};
