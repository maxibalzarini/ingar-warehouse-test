'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { ROLE_DEFINITIONS, PERMISSIONS, DEFAULT_ROLE_PERMISSIONS, MANDATORY_ROLE_PERMISSIONS } = require('../config/catalogs');
const { appendAudit } = require('./audit-service');

function mandatoryPermissionsForRoles(roleCodes) {
  const out = new Set();
  for (const roleCode of roleCodes || []) for (const code of (MANDATORY_ROLE_PERMISSIONS[String(roleCode || '').toUpperCase()] || [])) out.add(code);
  return out;
}

function seedAuthorizationCatalog(db = getDb()) {
  const now = new Date().toISOString();
  const permissionStmt = db.prepare('INSERT OR IGNORE INTO permission(id, code, name, module, action, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
  for (const [code, name] of PERMISSIONS) {
    const [module, action = '*'] = code === '*' ? ['*', '*'] : code.split('.');
    permissionStmt.run(randomUUID(), code, name, module, action, now, now);
  }
  const roleStmt = db.prepare(`INSERT OR IGNORE INTO role(id, code, name, parent_role_id, system_role, active, version, created_at, updated_at)
    VALUES (?, ?, ?, NULL, 1, 1, 1, ?, ?)`);
  for (const role of ROLE_DEFINITIONS) roleStmt.run(randomUUID(), role.code, role.name, now, now);
  const relationStmt = db.prepare('INSERT OR IGNORE INTO role_permission(role_id, permission_id, created_at) VALUES (?, ?, ?)');
  for (const [roleCode, permissionCodes] of Object.entries(DEFAULT_ROLE_PERMISSIONS)) {
    const role = db.prepare('SELECT id FROM role WHERE code = ?').get(roleCode);
    for (const code of permissionCodes) {
      const permission = db.prepare('SELECT id FROM permission WHERE code = ?').get(code);
      relationStmt.run(role.id, permission.id, now);
    }
  }
  const configPermissionIds = db.prepare("SELECT id FROM permission WHERE code IN ('Config.Read','Config.Update')").all().map((row) => row.id);
  const lowerRoles = ['PANOLERO', 'AUDITOR', 'SOLICITANTE', 'CONSULTA', 'INVITADO'];
  const deleteRelation = db.prepare('DELETE FROM role_permission WHERE role_id = ? AND permission_id = ?');
  for (const roleCode of lowerRoles) {
    const role = db.prepare('SELECT id FROM role WHERE code = ?').get(roleCode);
    if (!role) continue;
    for (const permissionId of configPermissionIds) deleteRelation.run(role.id, permissionId);
  }
}

function effectiveAuthorization(userId) {
  seedAuthorizationCatalog();
  const db = getDb();
  const now = new Date().toISOString();
  const roles = db.prepare(`SELECT r.id, r.code, r.name, r.parent_role_id, urs.site_id, urs.location_id
    FROM user_role_scope urs JOIN role r ON r.id = urs.role_id
    WHERE urs.user_id = ? AND r.active = 1
      AND (urs.valid_from IS NULL OR urs.valid_from <= ?)
      AND (urs.valid_to IS NULL OR urs.valid_to >= ?)`)
    .all(userId, now, now);
  const roleIds = new Set();
  const queue = roles.map((role) => role.id);
  while (queue.length) {
    const id = queue.shift();
    if (roleIds.has(id)) continue;
    roleIds.add(id);
    const parent = db.prepare('SELECT parent_role_id FROM role WHERE id = ?').get(id)?.parent_role_id;
    if (parent) queue.push(parent);
  }
  const permissions = new Set();
  if (roleIds.size) {
    const placeholders = [...roleIds].map(() => '?').join(',');
    for (const row of db.prepare(`SELECT p.code FROM role_permission rp JOIN permission p ON p.id = rp.permission_id WHERE rp.role_id IN (${placeholders})`).all(...roleIds)) {
      permissions.add(row.code);
    }
  }
  const overrides = db.prepare(`SELECT p.code, upo.effect FROM user_permission_override upo
    JOIN permission p ON p.id = upo.permission_id WHERE upo.user_id = ?`).all(userId);
  const deniedPermissions = new Set();
  for (const override of overrides) {
    if (override.effect === 'DENY') {
      permissions.delete(override.code);
      deniedPermissions.add(override.code);
    } else {
      permissions.add(override.code);
      deniedPermissions.delete(override.code);
    }
  }
  const roleCodes = roles.map((role) => role.code);
  for (const code of mandatoryPermissionsForRoles(roleCodes)) {
    permissions.add(code);
    deniedPermissions.delete(code);
  }
  const mayManageConfiguration = roleCodes.some((code) => ['ADMIN_GENERAL', 'ADMINISTRADOR', 'SUPERVISOR'].includes(code));
  if (!mayManageConfiguration) {
    for (const code of ['Config.Read', 'Config.Update']) {
      permissions.delete(code);
      deniedPermissions.add(code);
    }
  }
  return { roles, roleCodes, permissions: [...permissions].sort(), deniedPermissions: [...deniedPermissions].sort() };
}

function hasPermission(authz, permission) {
  if (authz.deniedPermissions?.includes(permission) || authz.deniedPermissions?.includes('*')) return false;
  return authz.permissions.includes('*') || authz.permissions.includes(permission);
}

function listRoles() {
  seedAuthorizationCatalog();
  const db = getDb();
  return db.prepare('SELECT * FROM role ORDER BY system_role DESC, name').all().map((role) => ({
    ...role,
    permissions: db.prepare('SELECT p.code FROM role_permission rp JOIN permission p ON p.id = rp.permission_id WHERE rp.role_id = ? ORDER BY p.code').all(role.id).map((row) => row.code)
  }));
}

function listPermissions() {
  seedAuthorizationCatalog();
  return getDb().prepare('SELECT id, code, name, module, action FROM permission ORDER BY module, action').all();
}

function createRole(input, context) {
  const code = String(input.code || '').trim().toUpperCase();
  const name = String(input.name || '').trim();
  if (!/^[A-Z][A-Z0-9_]{2,39}$/.test(code) || name.length < 3 || name.length > 80) {
    const error = new Error('Código o nombre de rol inválido.'); error.status = 422; error.code = 'ROLE_INVALID'; throw error;
  }
  return transaction((db) => {
    const id = randomUUID(); const now = new Date().toISOString();
    const parentRoleId = input.parentRoleId || null;
    if (parentRoleId && !db.prepare('SELECT 1 FROM role WHERE id = ? AND active = 1').get(parentRoleId)) {
      throw Object.assign(new Error('Rol padre inexistente o inactivo.'), { status: 422, code: 'PARENT_ROLE_INVALID' });
    }
    db.prepare(`INSERT INTO role(id, code, name, parent_role_id, system_role, active, version, created_at, updated_at)
      VALUES (?, ?, ?, ?, 0, 1, 1, ?, ?)`).run(id, code, name, parentRoleId, now, now);
    setRolePermissionsInDb(db, id, input.permissions || []);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ROLE.CREATE', entityType: 'role', entityId: id, after: { code, name, permissions: input.permissions || [] }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return listRoles().find((role) => role.id === id);
  });
}

function setRolePermissionsInDb(db, roleId, codes) {
  const unique = [...new Set(codes)];
  db.prepare('DELETE FROM role_permission WHERE role_id = ?').run(roleId);
  const stmt = db.prepare('INSERT INTO role_permission(role_id, permission_id, created_at) SELECT ?, id, ? FROM permission WHERE code = ?');
  const now = new Date().toISOString();
  for (const code of unique) {
    const result = stmt.run(roleId, now, code);
    if (result.changes !== 1) throw Object.assign(new Error(`Permiso desconocido: ${code}`), { status: 422, code: 'PERMISSION_UNKNOWN' });
  }
}

function updateRole(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM role WHERE id = ?').get(id);
    if (!current) throw Object.assign(new Error('Rol no encontrado.'), { status: 404, code: 'ROLE_NOT_FOUND' });
    const expectedVersion = Number(input.version);
    if (!Number.isInteger(expectedVersion) || expectedVersion !== current.version) {
      throw Object.assign(new Error('El rol fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    }
    const name = input.name === undefined ? current.name : String(input.name).trim();
    const parentRoleId = input.parentRoleId === undefined ? current.parent_role_id : (input.parentRoleId || null);
    const active = input.active === undefined ? current.active : (input.active ? 1 : 0);
    if (parentRoleId && !db.prepare('SELECT 1 FROM role WHERE id = ? AND active = 1').get(parentRoleId)) {
      throw Object.assign(new Error('Rol padre inexistente o inactivo.'), { status: 422, code: 'PARENT_ROLE_INVALID' });
    }
    if (roleCreatesCycle(db, id, parentRoleId)) throw Object.assign(new Error('La herencia genera un ciclo de roles.'), { status: 422, code: 'ROLE_CYCLE' });
    if (current.code === 'ADMIN_GENERAL' && !active) throw Object.assign(new Error('El rol Administrador General no puede deshabilitarse.'), { status: 422, code: 'SYSTEM_ROLE_REQUIRED' });
    const update = db.prepare('UPDATE role SET name = ?, parent_role_id = ?, active = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ?')
      .run(name, parentRoleId, active, new Date().toISOString(), id, expectedVersion);
    if (update.changes !== 1) throw Object.assign(new Error('Conflicto de concurrencia en rol.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    if (input.permissions) setRolePermissionsInDb(db, id, input.permissions);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ROLE.UPDATE', entityType: 'role', entityId: id, before: current, after: { name, parentRoleId, active, permissions: input.permissions }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return listRoles().find((role) => role.id === id);
  });
}


function getUserPermissionOverrides(userId) {
  seedAuthorizationCatalog();
  return getDb().prepare(`SELECT p.code, p.name, upo.effect
    FROM user_permission_override upo JOIN permission p ON p.id = upo.permission_id
    WHERE upo.user_id = ? ORDER BY p.code`).all(userId);
}

function setUserPermissionOverrides(userId, overrides, context) {
  if (!getDb().prepare('SELECT 1 FROM user_account WHERE id = ? AND deleted_at IS NULL').get(userId)) {
    throw Object.assign(new Error('Usuario no encontrado.'), { status: 404, code: 'USER_NOT_FOUND' });
  }
  if (!Array.isArray(overrides) || overrides.length > 100) {
    throw Object.assign(new Error('Lista de permisos individuales inválida.'), { status: 422, code: 'OVERRIDES_INVALID' });
  }
  return transaction((db) => {
    const targetRoleCodes = db.prepare(`SELECT r.code FROM user_role_scope urs JOIN role r ON r.id=urs.role_id WHERE urs.user_id=? AND r.active=1`).all(userId).map((row) => row.code);
    const mandatory = mandatoryPermissionsForRoles(targetRoleCodes);
    const before = getUserPermissionOverrides(userId);
    db.prepare('DELETE FROM user_permission_override WHERE user_id = ?').run(userId);
    const now = new Date().toISOString();
    const stmt = db.prepare(`INSERT INTO user_permission_override(id, user_id, permission_id, effect, created_at, updated_at)
      SELECT ?, ?, id, ?, ?, ? FROM permission WHERE code = ?`);
    const seen = new Set();
    for (const item of overrides) {
      const code = String(item.code || '');
      const effect = String(item.effect || '').toUpperCase();
      if (seen.has(code) || !['ALLOW', 'DENY'].includes(effect) || (code === 'Auth.Self' && effect === 'DENY') || (effect === 'DENY' && mandatory.has(code))) {
        throw Object.assign(new Error('Permiso individual inválido, duplicado o incompatible con el acceso propio.'), { status: 422, code: 'OVERRIDE_INVALID' });
      }
      seen.add(code);
      const result = stmt.run(randomUUID(), userId, effect, now, now, code);
      if (result.changes !== 1) throw Object.assign(new Error(`Permiso desconocido: ${code}`), { status: 422, code: 'PERMISSION_UNKNOWN' });
    }
    const after = getUserPermissionOverrides(userId);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.PERMISSION_OVERRIDES_UPDATE', entityType: 'user_account', entityId: userId, before, after, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return after;
  });
}

function roleCreatesCycle(db, roleId, parentRoleId) {
  let current = parentRoleId;
  const seen = new Set([roleId]);
  while (current) {
    if (seen.has(current)) return true;
    seen.add(current);
    current = db.prepare('SELECT parent_role_id FROM role WHERE id = ?').get(current)?.parent_role_id || null;
  }
  return false;
}

module.exports = { seedAuthorizationCatalog, effectiveAuthorization, hasPermission, mandatoryPermissionsForRoles, listRoles, listPermissions, createRole, updateRole, getUserPermissionOverrides, setUserPermissionOverrides };
