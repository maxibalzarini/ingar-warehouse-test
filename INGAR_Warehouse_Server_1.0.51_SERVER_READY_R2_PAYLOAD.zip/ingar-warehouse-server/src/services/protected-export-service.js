'use strict';

const { createHash } = require('node:crypto');
const { protectBuffer, unprotectBuffer } = require('../security/data-protection');

const PROTECTED_EXPORT_MIME = 'application/vnd.ingar.encrypted-export';

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function safeName(value) {
  const name = String(value || 'exportacion.bin').normalize('NFKC').replace(/[\\/:*?"<>|\u0000-\u001F]/g, '_').trim();
  return name.slice(0, 180) || 'exportacion.bin';
}

function protectedName(filename) {
  return `${safeName(filename).replace(/\.[A-Za-z0-9]{1,8}$/i, '')}.iwcexport`;
}

function protectExport(bytesInput, metadata = {}) {
  const bytes = Buffer.isBuffer(bytesInput) ? bytesInput : Buffer.from(bytesInput || '');
  const filename = safeName(metadata.filename);
  const mimeType = String(metadata.mimeType || 'application/octet-stream').slice(0, 160);
  const payload = Buffer.from(JSON.stringify({
    format: 'IWC_PROTECTED_EXPORT_V1',
    createdAt: new Date().toISOString(),
    filename,
    mimeType,
    byteSize: bytes.length,
    sha256: sha256(bytes),
    contentBase64: bytes.toString('base64')
  }), 'utf8');
  const protectedBytes = protectBuffer(payload, { purpose: 'PROTECTED_EXPORT' });
  return {
    bytes: protectedBytes,
    filename: protectedName(filename),
    mimeType: PROTECTED_EXPORT_MIME,
    sha256: sha256(protectedBytes),
    originalFilename: filename,
    originalMimeType: mimeType,
    originalSha256: sha256(bytes)
  };
}

function unprotectExport(bytesInput) {
  const payload = JSON.parse(unprotectBuffer(bytesInput, { purpose: 'PROTECTED_EXPORT' }).bytes.toString('utf8'));
  if (payload?.format !== 'IWC_PROTECTED_EXPORT_V1') throw new Error('Formato de exportación protegida inválido.');
  const bytes = Buffer.from(payload.contentBase64 || '', 'base64');
  if (bytes.length !== Number(payload.byteSize) || sha256(bytes) !== payload.sha256) throw new Error('Integridad de exportación protegida inválida.');
  return {
    bytes,
    filename: safeName(payload.filename),
    mimeType: String(payload.mimeType || 'application/octet-stream'),
    sha256: payload.sha256,
    createdAt: payload.createdAt
  };
}

module.exports = {
  PROTECTED_EXPORT_MIME,
  protectExport,
  unprotectExport,
  protectedName
};
