'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { createHash, randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { isProtectedBuffer, unprotectBuffer } = require('../security/data-protection');

const PAGE = Object.freeze({ width: 595, height: 842 });

function sha256(value) { return createHash('sha256').update(value).digest('hex'); }
function safeText(value) {
  return String(value ?? '')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/[^\x20-\xFF]/g, '?');
}
function latinHex(value) { return Buffer.from(safeText(value), 'latin1').toString('hex').toUpperCase(); }
function txt(value, x, y, size = 9, bold = false) { return `BT /${bold?'F2':'F1'} ${size} Tf 1 0 0 1 ${x} ${y} Tm <${latinHex(value)}> Tj ET`; }
function line(x1,y1,x2,y2,w=.5){return `${w} w ${x1} ${y1} m ${x2} ${y2} l S`;}
function rect(x,y,w,h,gray=null){const out=[]; if(gray!==null) out.push(`${gray} g ${x} ${y} ${w} ${h} re f`,`0 g`); out.push(`0.75 G 0.45 w ${x} ${y} ${w} ${h} re S`,`0 G`); return out.join('\n');}
function wrap(value, max=86){
  const words=safeText(value).replace(/\s+/g,' ').trim().split(' ').filter(Boolean); const lines=[]; let cur='';
  for(const word of words){const next=cur?`${cur} ${word}`:word; if(next.length>max&&cur){lines.push(cur);cur=word;}else cur=next;} if(cur)lines.push(cur); return lines.length?lines:['-'];
}
function formatDate(value){ if(!value)return '-'; const d=new Date(value); if(!Number.isFinite(d.getTime()))return safeText(value); return new Intl.DateTimeFormat('es-AR',{dateStyle:'short',timeStyle:'medium',timeZone:'America/Argentina/Buenos_Aires'}).format(d); }
function normalizeChecklist(raw){ try{return typeof raw==='string'?JSON.parse(raw||'{}'):(raw||{});}catch{return{};} }

function parseJpegSize(bytes){
  if(!Buffer.isBuffer(bytes)||bytes.length<4||bytes[0]!==0xFF||bytes[1]!==0xD8)return null;
  let i=2; while(i+8<bytes.length){ if(bytes[i]!==0xFF){i++;continue;} const marker=bytes[i+1]; i+=2; if(marker===0xD8||marker===0xD9)continue; if(i+2>bytes.length)break; const len=bytes.readUInt16BE(i); if(len<2||i+len>bytes.length)break;
    if([0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF].includes(marker)){return{height:bytes.readUInt16BE(i+3),width:bytes.readUInt16BE(i+5)};} i+=len; }
  return null;
}
function toJpeg(bytes,mimeType){
  if(mimeType==='image/jpeg'){ const size=parseJpegSize(bytes); if(size)return{bytes,width:size.width,height:size.height}; }
  try{
    const { nativeImage } = require('electron');
    const image=nativeImage.createFromBuffer(bytes); if(!image||image.isEmpty())return null; const size=image.getSize(); const jpeg=image.toJPEG(82); if(!jpeg?.length||!size.width||!size.height)return null; return{bytes:jpeg,width:size.width,height:size.height};
  }catch{return null;}
}
function readEvidenceBytes(row){
  if(!row?.file_ref)return null; const base=path.resolve(runtime.evidenceDir); const full=path.resolve(base,row.file_ref); if(!full.startsWith(base+path.sep)||!fs.existsSync(full))return null;
  const stored=fs.readFileSync(full); try{return isProtectedBuffer(stored)?unprotectBuffer(stored,{purpose:'EVIDENCE_FILE'}).bytes:stored;}catch{return null;}
}

function pdfFromPages(pages){
  // pages: {commands:string[], images:[{name,bytes,width,height,x,y,w,h}]}
  const objects=[null,'<< /Type /Catalog /Pages 2 0 R >>',null,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];
  const pageIds=[];
  for(const page of pages){
    const imageRefs=[];
    for(const im of page.images||[]){ const id=objects.length; imageRefs.push({name:im.name,id}); objects.push(Buffer.concat([Buffer.from(`<< /Type /XObject /Subtype /Image /Width ${im.width} /Height ${im.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.bytes.length} >>\nstream\n`,'ascii'),im.bytes,Buffer.from('\nendstream','ascii')])); }
    const xobjects=imageRefs.length?` /XObject << ${imageRefs.map(r=>`/${r.name} ${r.id} 0 R`).join(' ')} >>`:'';
    const stream=Buffer.from((page.commands||[]).join('\n'),'binary');
    const pageId=objects.length, contentId=pageId+1; pageIds.push(pageId);
    objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE.width} ${PAGE.height}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>${xobjects} >> /Contents ${contentId} 0 R >>`);
    objects.push(Buffer.concat([Buffer.from(`<< /Length ${stream.length} >>\nstream\n`,'ascii'),stream,Buffer.from('\nendstream','ascii')]));
  }
  objects[2]=`<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map(id=>`${id} 0 R`).join(' ')}] >>`;
  const header=Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n','binary'); const chunks=[header], offsets=[0]; let cursor=header.length;
  for(let i=1;i<objects.length;i++){ offsets[i]=cursor; const body=Buffer.isBuffer(objects[i])?objects[i]:Buffer.from(String(objects[i]),'binary'); const pre=Buffer.from(`${i} 0 obj\n`,'ascii'), post=Buffer.from('\nendobj\n','ascii'); chunks.push(pre,body,post); cursor+=pre.length+body.length+post.length; }
  const xrefOffset=cursor; let xref=`xref\n0 ${objects.length}\n0000000000 65535 f \n`; for(let i=1;i<objects.length;i++)xref+=`${String(offsets[i]).padStart(10,'0')} 00000 n \n`; xref+=`trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`; chunks.push(Buffer.from(xref,'ascii')); return Buffer.concat(chunks);
}

function addPair(commands,label,value,x,y,w=250){ commands.push(txt(label,x,y,7,true),txt(value||'-',x,y-13,9,false),line(x,y-18,x+w,y-18,.35)); }
function addWrapped(commands,value,x,y,{size=8,max=96,maxLines=999}={}){let cursor=y;for(const ln of wrap(value,max).slice(0,maxLines)){commands.push(txt(ln,x,cursor,size));cursor-=12;}return cursor;}
function detailHeader(snapshot,title){return [txt('INGAR Warehouse',34,805,13,true),txt(title,34,783,11,true),txt(snapshot.receiptNumber,430,805,8,true),line(34,768,560,768,.6)];}
function addOperationalDetailPages(pages,snapshot){
  if(!snapshot.vehicle && !snapshot.kitComponents?.length && !snapshot.incident)return;
  let c=null,y=0;
  const startPage=()=>{c=detailHeader(snapshot,'DETALLE OPERATIVO DE DEVOLUCION');y=742;pages.push({commands:c,images:[]});};
  const ensure=(need=36)=>{if(!c||y-need<55)startPage();};
  const heading=(value)=>{ensure(32);c.push(txt(value,34,y,10,true));y-=18;};
  const row=(value,size=8,max=96)=>{const lines=wrap(value,max);ensure(lines.length*12+8);for(const ln of lines){c.push(txt(ln,42,y,size));y-=12;}y-=3;};
  if(snapshot.vehicle){
    heading('VEHICULO'); const v=snapshot.vehicle;
    row(`Kilometraje salida: ${v.departureOdometer ?? '-'} km | Kilometraje devolucion: ${v.returnOdometer ?? '-'} km | Distancia recorrida: ${v.distance ?? '-'} km`);
    row(`Combustible salida: ${v.departureFuel ?? '-'}% | Combustible devolucion: ${v.returnFuel ?? '-'}%`);
    heading('Checklist de salida'); const departure=Object.entries(v.departureChecklist||{}); if(!departure.length)row('Sin checklist de salida.'); else for(const [key,value] of departure)row(`${key}: ${value}`,7.5,104);
    heading('Checklist de devolucion'); const returned=Object.entries(v.returnChecklist||{}); if(!returned.length)row('Sin checklist de devolucion.'); else for(const [key,value] of returned)row(`${key}: ${value}`,7.5,104);
    heading('Observaciones del vehiculo'); row(v.returnNotes||snapshot.declaration.notes||'Sin observaciones del vehiculo.');
    if(v.departureNotes){heading('Observaciones de salida');row(v.departureNotes);}
    if(v.supervisor){
      heading('V°B° DEL SUPERVISOR');
      row(`Supervisor: ${v.supervisor.name||'-'} | Seguridad: ${v.supervisor.safetyObservation?'SI - VEHICULO BLOQUEADO':'NO'} | Inspeccion: ${formatDate(v.supervisor.inspectedAt)}`);
      if(v.supervisor.comment)row(`Comentario general: ${v.supervisor.comment}`);
      if(Array.isArray(v.supervisor.checklistAssessments)&&v.supervisor.checklistAssessments.length){
        heading('Checklist evaluado por Supervisor');
        for(const item of v.supervisor.checklistAssessments){
          row(`${item.label}: mecanico=${item.technicianValue} | supervisor=${item.supervisorValue} | seguridad=${item.safetyObservation?'SI':'NO'}${item.comment?` | ${item.comment}`:''}`,7.5,105);
        }
      } else row('V°B° legado F24 sin evaluacion de checklist item por item.',7.5,105);
    }
  }
  if(snapshot.kitComponents?.length){
    heading('COMPONENTES DEL KIT');
    for(const item of snapshot.kitComponents){
      row(`${item.internalCode} - ${item.description} | Entregado: ${item.issuedQuantity} | Devuelto: ${item.returnedQuantity} | Faltante: ${item.missingQuantity} | Estado: ${item.status} | Condicion: ${item.condition}`,7.5,105);
    }
  }
  if(snapshot.incident){
    heading('INCIDENTE ASOCIADO'); const i=snapshot.incident;
    row(`${i.number||i.id} | Tipo: ${i.type||'-'} | Severidad: ${i.severity||'-'} | Estado: ${i.status||'-'}`);
    row(i.title||'Incidente asociado a la recepcion.');
    row(i.description||'Sin descripcion adicional.');
  }
}
function buildReturnReceiptPdf(snapshot, imageInputs=[]){
  const pages=[]; const c=[]; let y=804;
  const resultLabel=String(snapshot.reception.condition||'').toUpperCase()==='CONFORME'?'CONFORME':'CON OBSERVACIÓN';
  c.push(txt('INGAR Warehouse',34,y,16,true)); y-=22; c.push(txt('CONSTANCIA DE DEVOLUCION Y RECEPCION',34,y,13,true)); c.push(txt(snapshot.receiptNumber,430,y,9,true)); y-=24; c.push(line(34,y,560,y,.8)); y-=24;
  addPair(c,'Bien',`${snapshot.asset.internalCode} - ${snapshot.asset.description}`,34,y,245); addPair(c,'Tipo',snapshot.asset.nature,310,y,250); y-=48;
  addPair(c,'Solicitud',snapshot.request.number,34,y,245); addPair(c,'Custodio',snapshot.custodian.fullName,310,y,250); y-=48;
  addPair(c,'Identificacion',snapshot.asset.identity||snapshot.asset.id||'-',34,y,245); addPair(c,'Documento',snapshot.custodian.document||'Sin documento',310,y,250); y-=48;
  if(String(snapshot.asset.nature||'').toUpperCase()==='CANTIDAD'){ addPair(c,'Cantidad entregada',snapshot.asset.issuedQuantity,34,y,245); addPair(c,'Cantidad devuelta',snapshot.asset.returnedQuantity,310,y,250); y-=48; }
  addPair(c,'Entrega original',formatDate(snapshot.timeline.openedAt),34,y,245); addPair(c,'Devolucion prevista',formatDate(snapshot.timeline.dueAt),310,y,250); y-=48;
  addPair(c,'Devolucion declarada',formatDate(snapshot.timeline.declaredAt),34,y,245); addPair(c,'Recepcion fisica',formatDate(snapshot.timeline.receivedAt),310,y,250); y-=48;
  addPair(c,'Resultado',resultLabel,34,y,245); addPair(c,'Incidente asociado',snapshot.incident?.number||snapshot.incident?.id||'NO',310,y,250); y-=48;
  addPair(c,'Condicion recibida',snapshot.reception.condition,34,y,245); addPair(c,'Situacion temporal',snapshot.reception.timingStatus,310,y,250); y-=50;
  c.push(txt('Declaracion del usuario',34,y,9,true)); y-=16; y=addWrapped(c,snapshot.declaration.notes||snapshot.declaration.summary||'Sin observaciones.',42,y,{size:8,max:96,maxLines:5}); y-=8;
  c.push(txt('Observacion del panolero',34,y,9,true)); y-=16; y=addWrapped(c,snapshot.reception.notes||'Recepcion conforme, sin observaciones.',42,y,{size:8,max:96,maxLines:5});
  c.push(line(34,126,560,126,.6)); c.push(txt('ACEPTACIONES ELECTRONICAS AUTENTICADAS',34,108,8,true));
  c.push(txt(`Devuelve: ${snapshot.signatures.returner.name} (${snapshot.signatures.returner.username})`,34,88,8)); c.push(txt(`Declarado: ${formatDate(snapshot.signatures.returner.at)}`,34,75,7));
  c.push(txt(`Recibe: ${snapshot.signatures.receiver.name} (${snapshot.signatures.receiver.username})`,310,88,8)); c.push(txt(`Recibido: ${formatDate(snapshot.signatures.receiver.at)}`,310,75,7));
  c.push(txt(`Snapshot SHA-256: ${snapshot.snapshotSha256 || ''}`,34,42,6)); c.push(txt('Documento generado y congelado al momento de la recepcion fisica.',34,29,6.5));
  pages.push({commands:c,images:[]});
  addOperationalDetailPages(pages,snapshot);

  const converted=[]; for(const input of imageInputs){ const image=toJpeg(input.bytes,input.mimeType); if(image) converted.push({...input,...image}); }
  for(let i=0;i<converted.length;i+=2){ const batch=converted.slice(i,i+2); const commands=[txt('INGAR Warehouse - Evidencias de devolucion',34,805,13,true),txt(snapshot.receiptNumber,420,805,8,true),line(34,786,560,786,.6)]; const images=[]; let top=744; batch.forEach((im,j)=>{ const maxW=500,maxH=290; const scale=Math.min(maxW/im.width,maxH/im.height,1); const w=Math.max(1,Math.round(im.width*scale)),h=Math.max(1,Math.round(im.height*scale)); const x=Math.round((595-w)/2); const yImg=top-h; const name=`Im${j+1}`; commands.push(txt(im.label||im.filename||`Evidencia ${i+j+1}`,47,top+10,8,true),`q ${w} 0 0 ${h} ${x} ${yImg} cm /${name} Do Q`,rect(x-1,yImg-1,w+2,h+2,null)); images.push({name,bytes:im.bytes,width:im.width,height:im.height}); top=yImg-55; }); pages.push({commands,images}); }
  return pdfFromPages(pages);
}

function evidenceRowsForReceipt(db,custodyId,people=[]){
  const rows=db.prepare(`SELECT * FROM file_evidence WHERE lifecycle_state='ACTIVE' AND ((owner_type='CUSTODY' AND owner_id=? AND purpose IN ('SERIALIZED_RETURN_PHOTO','VEHICLE_RETURN_PHOTO')) OR id IN (${people.length?people.map(()=>'?').join(','):"''"})) ORDER BY created_at`).all(custodyId,...people);
  return rows;
}
function snapshotForReceipt(db,custodyId,receiptNumber,returnRecordId,context){
  const row=db.prepare(`SELECT c.*,a.internal_code,a.description,a.serial_number,a.license_plate,ac.nature AS category_nature,r.request_number,
    p.full_name AS custodian_name,p.document_type,p.document_number,p.signature_evidence_id AS custodian_signature_id,
    rr.received_at,rr.timing_status,rr.overdue_seconds,rr.condition AS received_condition,rr.notes AS received_notes,rr.incident_id,
    rvw.source_mode AS reception_review_source,rvw.operator_comment AS receiver_comment,rvw.operator_condition AS receiver_selected_condition,
    rvw.comment_forced_observation,rvw.blocked_after_receipt,rvw.reviewed_at,
    d.condition AS declared_condition,d.problem_reported,d.notes AS declared_notes,d.declared_at,d.declared_by_user_id,
    du.username AS declarer_username,dp.full_name AS declarer_name,dp.signature_evidence_id AS declarer_signature_id,
    ru.username AS receiver_username,rp.full_name AS receiver_name,rp.signature_evidence_id AS receiver_signature_id
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN request r ON r.id=c.request_id
    JOIN person p ON p.id=c.person_id JOIN custody_return_record rr ON rr.id=?
    LEFT JOIN custody_reception_review rvw ON rvw.return_record_id=rr.id
    LEFT JOIN custody_return_declaration d ON d.custody_id=c.id
    LEFT JOIN user_account du ON du.id=COALESCE(d.declared_by_user_id,(SELECT declared_by_user_id FROM vehicle_return_detail WHERE custody_id=c.id))
    LEFT JOIN person dp ON dp.id=du.person_id JOIN user_account ru ON ru.id=? JOIN person rp ON rp.id=ru.person_id
    WHERE c.id=?`).get(returnRecordId,context.user.id,custodyId);
  if(!row) throw Object.assign(new Error('No fue posible construir la constancia de devolucion.'),{status:500,code:'RETURN_RECEIPT_SOURCE_MISSING'});
  const vehicleRequest=db.prepare('SELECT * FROM vehicle_request_detail WHERE request_id=?').get(row.request_id)||null;
  const vehicleReturn=db.prepare('SELECT * FROM vehicle_return_detail WHERE custody_id=?').get(custodyId)||null;
  const vehicleSupervision=db.prepare(`SELECT vrs.*,p.full_name AS supervisor_name FROM vehicle_return_supervision vrs JOIN person p ON p.id=vrs.supervisor_person_id WHERE vrs.custody_id=?`).get(custodyId)||null;
  const vehicleChecklistAssessments=vehicleSupervision?db.prepare(`SELECT checklist_key,checklist_label_snapshot,technician_value_snapshot,supervisor_value,safety_observation,supervisor_comment,assessed_at FROM vehicle_return_checklist_assessment WHERE supervision_id=? ORDER BY CASE checklist_key WHEN 'exterior' THEN 1 WHEN 'neumaticos' THEN 2 WHEN 'luces' THEN 3 WHEN 'interior' THEN 4 WHEN 'documentacion' THEN 5 ELSE 99 END`).all(vehicleSupervision.id):[];
  const kitComponents=String(row.category_nature||'').toUpperCase()==='KIT'?db.prepare(`SELECT kcc.*,a.internal_code,a.description FROM kit_custody_component kcc JOIN asset a ON a.id=kcc.component_asset_id WHERE kcc.custody_id=? ORDER BY a.internal_code`).all(custodyId):[];
  const quantityReturnPortions=String(row.category_nature||'').toUpperCase()==='CANTIDAD'?db.prepare(`SELECT quantity,remaining_after,is_final,condition,notes,received_at FROM custody_return_portion WHERE custody_id=? ORDER BY received_at,created_at`).all(custodyId):[];
  const quantityDeclaration=String(row.category_nature||'').toUpperCase()==='CANTIDAD'?db.prepare(`SELECT qrd.*,ua.username AS declarer_username,p.full_name AS declarer_name,p.signature_evidence_id AS declarer_signature_id
    FROM custody_quantity_return_declaration qrd
    JOIN user_account ua ON ua.id=qrd.declared_by_user_id
    JOIN person p ON p.id=ua.person_id
    WHERE qrd.custody_id=? ORDER BY qrd.declared_at DESC,qrd.created_at DESC LIMIT 1`).get(custodyId)||null:null;
  const incident=row.incident_id?db.prepare('SELECT id,incident_number,type,severity,status,title,description,occurred_at,opened_at FROM incident WHERE id=?').get(row.incident_id)||null:null;
  const declaredAt=quantityDeclaration?.declared_at||row.declared_at||vehicleReturn?.declared_at||row.declared_return_at||null;
  const declarationNotes=quantityDeclaration?.notes||row.declared_notes||vehicleReturn?.notes||null;
  const snapshot={
    schema:'INGAR_RETURN_RECEIPT_V3',receiptNumber,custodyId,returnRecordId,
    asset:{id:row.asset_id,internalCode:row.internal_code,description:row.description,nature:row.category_nature,identity:row.license_plate||row.serial_number||row.internal_code,issuedQuantity:Number(row.quantity||0),returnedQuantity:quantityReturnPortions.reduce((sum,x)=>sum+Number(x.quantity||0),0)},
    request:{id:row.request_id,number:row.request_number},
    custodian:{id:row.person_id,fullName:row.custodian_name,document:(row.document_type&&row.document_number)?`${row.document_type} ${row.document_number}`:null},
    timeline:{openedAt:row.opened_at,dueAt:row.due_at,declaredAt,receivedAt:row.received_at},
    declaration:{condition:quantityDeclaration?.condition||row.declared_condition||vehicleReturn?.return_condition||'CONFORME',problemReported:Boolean(quantityDeclaration?.problem_reported||row.problem_reported||vehicleReturn?.problem_reported),notes:declarationNotes,summary:declarationNotes||'Devolucion declarada por el usuario.'},
    reception:{condition:row.received_condition,selectedCondition:row.receiver_selected_condition||row.received_condition,notes:row.reception_review_source==='F22_REVIEW'?(row.receiver_comment||null):(row.receiver_comment||row.received_notes||null),notesSource:row.reception_review_source==='F22_REVIEW'?'PANOLERO':'LEGACY_NOT_SEPARABLE',sourceMode:row.reception_review_source||'LEGACY_NOT_SEPARABLE',commentForcedObservation:Boolean(row.comment_forced_observation),blockedAfterReceipt:Boolean(row.blocked_after_receipt),reviewedAt:row.reviewed_at||row.received_at,timingStatus:row.timing_status,overdueSeconds:Number(row.overdue_seconds||0),incidentId:row.incident_id||null},
    incident:incident?{id:incident.id,number:incident.incident_number,type:incident.type,severity:incident.severity,status:incident.status,title:incident.title,description:incident.description,occurredAt:incident.occurred_at,openedAt:incident.opened_at}:null,
    vehicle:vehicleRequest&&vehicleReturn?{departureOdometer:vehicleRequest.departure_odometer,returnOdometer:vehicleReturn.return_odometer,distance:Math.max(0,Number(vehicleReturn.return_odometer||0)-Number(vehicleRequest.departure_odometer||0)),departureFuel:vehicleRequest.departure_fuel_percent,returnFuel:vehicleReturn.return_fuel_percent,departureChecklist:normalizeChecklist(vehicleRequest.departure_checklist_json),returnChecklist:normalizeChecklist(vehicleReturn.return_checklist_json),departureNotes:vehicleRequest.departure_notes||null,returnNotes:vehicleReturn.notes||null,supervisor:vehicleSupervision?{name:vehicleSupervision.supervisor_name||null,comment:vehicleSupervision.supervisor_comment||null,safetyObservation:Boolean(vehicleSupervision.safety_observation),inspectedAt:vehicleSupervision.inspected_at||null,checklistAssessments:vehicleChecklistAssessments.map(x=>({key:x.checklist_key,label:x.checklist_label_snapshot,technicianValue:x.technician_value_snapshot,supervisorValue:x.supervisor_value,safetyObservation:Boolean(x.safety_observation),comment:x.supervisor_comment||null,assessedAt:x.assessed_at}))}:null}:null,
    kitComponents:kitComponents.map(x=>({internalCode:x.internal_code,description:x.description,issuedQuantity:x.issued_quantity,returnedQuantity:x.returned_quantity,missingQuantity:x.missing_quantity,status:x.status,condition:x.condition})),
    quantityReturnPortions:quantityReturnPortions.map(x=>({quantity:Number(x.quantity||0),remainingAfter:Number(x.remaining_after||0),isFinal:Boolean(x.is_final),condition:x.condition,notes:x.notes||null,receivedAt:x.received_at})),
    signatures:{returner:{userId:quantityDeclaration?.declared_by_user_id||row.declared_by_user_id||vehicleReturn?.declared_by_user_id||null,username:quantityDeclaration?.declarer_username||row.declarer_username||'usuario',name:quantityDeclaration?.declarer_name||row.declarer_name||row.custodian_name,at:declaredAt,evidenceId:quantityDeclaration?.declarer_signature_id||row.declarer_signature_id||row.custodian_signature_id||null},receiver:{userId:context.user.id,username:row.receiver_username||context.user.username||'panolero',name:row.receiver_name||context.user.fullName||context.user.username||'Pañolero',at:row.received_at,evidenceId:row.receiver_signature_id||null}},
    createdAt:new Date().toISOString()
  };
  return snapshot;
}
function createReturnReceiptInDb(db,custodyId,{handoverId,returnRecordId,context}){
  const existing=db.prepare('SELECT * FROM custody_return_receipt WHERE custody_id=?').get(custodyId); if(existing)return existing;
  const rr=db.prepare('SELECT received_at FROM custody_return_record WHERE id=? AND custody_id=?').get(returnRecordId,custodyId); if(!rr)throw Object.assign(new Error('Registro de devolucion inexistente.'),{status:500,code:'RETURN_RECORD_MISSING'});
  const year=new Date(rr.received_at||Date.now()).getUTCFullYear(); const receiptNumber=`DEV-${year}-${String(returnRecordId).replace(/-/g,'').slice(0,10).toUpperCase()}`;
  const snapshot=snapshotForReceipt(db,custodyId,receiptNumber,returnRecordId,context);
  const canonical=JSON.stringify(snapshot);
  const snapshotHash=sha256(Buffer.from(canonical,'utf8'));
  const pdfSnapshot={...snapshot,snapshotSha256:snapshotHash};
  const signatureIds=[snapshot.signatures.returner.evidenceId,snapshot.signatures.receiver.evidenceId].filter(Boolean); const evidenceRows=evidenceRowsForReceipt(db,custodyId,signatureIds); const images=[];
  for(const row of evidenceRows){const bytes=readEvidenceBytes(row); if(!bytes)continue; const isSignature=signatureIds.includes(row.id); images.push({bytes,mimeType:row.mime_type,filename:row.filename,label:isSignature?`Firma registrada - ${row.id===snapshot.signatures.receiver.evidenceId?'pañolero receptor':'usuario que devuelve'}`:`Foto de devolucion - ${row.filename}`});}
  const pdf=buildReturnReceiptPdf(pdfSnapshot,images); const pdfHash=sha256(pdf); const now=new Date().toISOString(); const id=randomUUID();
  db.prepare(`INSERT INTO custody_return_receipt(id,custody_id,handover_id,return_record_id,receipt_number,asset_nature,snapshot_json,snapshot_sha256,pdf_bytes,pdf_sha256,pdf_size,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id,custodyId,handoverId,returnRecordId,receiptNumber,snapshot.asset.nature,canonical,snapshotHash,pdf,pdfHash,pdf.length,context.user.id,now);
  return db.prepare('SELECT id,custody_id,handover_id,return_record_id,receipt_number,asset_nature,snapshot_sha256,pdf_sha256,pdf_size,created_by_user_id,created_at FROM custody_return_receipt WHERE id=?').get(id);
}
function getReturnReceiptMetadata(db,custodyId){return db.prepare('SELECT id,custody_id,receipt_number,asset_nature,snapshot_sha256,pdf_sha256,pdf_size,created_at FROM custody_return_receipt WHERE custody_id=?').get(custodyId)||null;}
function getReturnReceiptBytes(db,custodyId){const row=db.prepare('SELECT receipt_number,pdf_bytes,pdf_sha256,pdf_size FROM custody_return_receipt WHERE custody_id=?').get(custodyId); if(!row)return null; return{receiptNumber:row.receipt_number,bytes:Buffer.from(row.pdf_bytes),sha256:row.pdf_sha256,size:row.pdf_size};}

module.exports={buildReturnReceiptPdf,createReturnReceiptInDb,getReturnReceiptMetadata,getReturnReceiptBytes};
