'use strict';

const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb, transaction } = require('../db/database');
const { sha256 } = require('../security/tokens');
const { requiredString } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { parseDataUrl, saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { parseCsv, parseXlsx, createXlsx } = require('./spreadsheet-service');
const { normalizeAsset, insertAsset, assetSelect, convertUniqueError } = require('./asset-service');
const { normalizeVehicleProfile, normalizeKitComponents } = require('./specialized-asset-registration-service');
const { assignKitToPersonInDb, closeActiveAssignmentForKitLifecycleInDb } = require('./kit-personal-service');
const { syncKitComponentsInDb } = require('./kit-component-membership-service');
const { assertLocationScope, assertAssetScope } = require('../security/scope');

const SPECIALIZED_KINDS = new Set(['VEHICLE', 'KIT']);
const MODES = new Set(['CREATE_ONLY', 'UPDATE_ONLY', 'CREATE_OR_UPDATE']);
const MASTER_STATUSES = new Set(['DISPONIBLE', 'BLOQUEADO', 'MANTENIMIENTO', 'PERDIDO', 'BAJA']);

const VEHICLE_TEMPLATE_HEADERS = Object.freeze([
  'codigo_interno', 'categoria_codigo', 'descripcion', 'ubicacion_codigo', 'sede_codigo',
  'patente', 'numero_serie', 'marca', 'modelo', 'vin', 'numero_chasis', 'numero_motor',
  'anio_fabricacion', 'clase_vehiculo', 'unidad_uso', 'lectura_kilometraje',
  'lectura_horometro', 'km_por_hora', 'combustible', 'capacidad_combustible',
  'clase_licencia_requerida', 'estado', 'activo', 'observaciones'
]);

const KIT_TEMPLATE_HEADERS = Object.freeze([
  'kit_codigo_interno', 'categoria_codigo', 'descripcion', 'ubicacion_codigo', 'sede_codigo',
  'mecanico_usuario', 'mecanico_legajo',
  'numero_serie', 'marca', 'modelo', 'componente_codigo', 'cantidad_requerida',
  'obligatorio', 'permite_sustitucion', 'secuencia',
  'permite_kit_incompleto_con_autorizacion', 'observaciones_kit', 'estado', 'activo'
]);

const VEHICLE_ALIASES = Object.freeze({
  internalCode: ['codigo_interno', 'código_interno', 'internal_code', 'codigo'],
  categoryCode: ['categoria_codigo', 'categoría_codigo', 'category_code', 'categoria'],
  description: ['descripcion', 'descripción', 'description', 'vehiculo', 'vehículo'],
  locationCode: ['ubicacion_codigo', 'ubicación_codigo', 'location_code', 'ubicacion'],
  siteCode: ['sede_codigo', 'site_code', 'sede'],
  mechanicUsername: ['mecanico_usuario', 'mecánico_usuario', 'mechanic_username', 'usuario_mecanico'],
  mechanicEmployeeNumber: ['mecanico_legajo', 'mecánico_legajo', 'mechanic_employee_number', 'legajo_mecanico'],
  licensePlate: ['patente', 'license_plate', 'matricula', 'matrícula'],
  serialNumber: ['numero_serie', 'número_serie', 'serial_number', 'serie'],
  brand: ['marca', 'brand'],
  model: ['modelo', 'model'],
  vin: ['vin'],
  chassisNumber: ['numero_chasis', 'número_chasis', 'chassis_number', 'chasis'],
  engineNumber: ['numero_motor', 'número_motor', 'engine_number', 'motor'],
  manufactureYear: ['anio_fabricacion', 'año_fabricacion', 'manufacture_year', 'anio', 'año'],
  vehicleClass: ['clase_vehiculo', 'vehicle_class', 'clase'],
  usageUnit: ['unidad_uso', 'usage_unit', 'unidad_operativa'],
  currentOdometer: ['lectura_kilometraje', 'kilometraje', 'current_odometer', 'odometer'],
  currentHourmeter: ['lectura_horometro', 'lectura_horómetro', 'horometro', 'horómetro', 'current_hourmeter'],
  kmPerHour: ['km_por_hora', 'km_per_hour', 'equivalencia_km_h'],
  fuelType: ['combustible', 'fuel_type'],
  fuelCapacity: ['capacidad_combustible', 'fuel_capacity'],
  requiredLicenseClass: ['clase_licencia_requerida', 'required_license_class', 'licencia_requerida'],
  status: ['estado', 'status'],
  active: ['activo', 'active'],
  notes: ['observaciones', 'notas', 'notes']
});

const KIT_ALIASES = Object.freeze({
  internalCode: ['kit_codigo_interno', 'codigo_interno', 'código_interno', 'kit_code'],
  categoryCode: ['categoria_codigo', 'categoría_codigo', 'category_code', 'categoria'],
  description: ['descripcion', 'descripción', 'description', 'kit'],
  locationCode: ['ubicacion_codigo', 'ubicación_codigo', 'location_code', 'ubicacion'],
  siteCode: ['sede_codigo', 'site_code', 'sede'],
  mechanicUsername: ['mecanico_usuario', 'mecánico_usuario', 'mechanic_username', 'usuario_mecanico'],
  mechanicEmployeeNumber: ['mecanico_legajo', 'mecánico_legajo', 'mechanic_employee_number', 'legajo_mecanico'],
  serialNumber: ['numero_serie', 'número_serie', 'serial_number', 'serie'],
  brand: ['marca', 'brand'],
  model: ['modelo', 'model'],
  componentCode: ['componente_codigo', 'component_code', 'codigo_componente'],
  requiredQuantity: ['cantidad_requerida', 'required_quantity', 'cantidad'],
  mandatory: ['obligatorio', 'mandatory'],
  allowSubstitution: ['permite_sustitucion', 'allow_substitution', 'sustitucion'],
  sequence: ['secuencia', 'sequence', 'orden'],
  allowIncompleteWithAuthorization: ['permite_kit_incompleto_con_autorizacion', 'allow_incomplete_with_authorization'],
  definitionNotes: ['observaciones_kit', 'definition_notes', 'notas_kit'],
  status: ['estado', 'status'],
  active: ['activo', 'active']
});

function importError(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function normalizeHeader(value) {
  return String(value || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '_');
}

function resolveMapping(headers, aliases, requiredFields, templateLabel) {
  const normalizedHeaders = new Map(headers.map((header) => [normalizeHeader(header), header]));
  const mapping = {};
  for (const [field, names] of Object.entries(aliases)) {
    const found = names.map(normalizeHeader).find((alias) => normalizedHeaders.has(alias));
    if (found) mapping[field] = normalizedHeaders.get(found);
  }
  const missing = requiredFields.filter((field) => !mapping[field]);
  if (missing.length) {
    const detected = headers.map((header) => String(header || '').trim()).filter(Boolean);
    throw Object.assign(importError(422, 'IMPORT_MAPPING_INCOMPLETE', `El archivo no corresponde a la ${templateLabel}. Faltan columnas obligatorias: ${missing.join(', ')}.`), {
      details: { detectedHeaders: detected, missingColumns: missing }
    });
  }
  return mapping;
}

function cell(row, mapping, field) {
  const value = mapping[field] ? row[mapping[field]] : '';
  return typeof value === 'string' ? value.trim() : value;
}

function blank(value) {
  return value === '' || value === null || value === undefined;
}

function choose(value, fallback) {
  return blank(value) ? fallback : value;
}

function parseBooleanCell(value, fallback, field) {
  if (blank(value)) return fallback;
  if (typeof value === 'boolean') return value;
  const normalized = String(value).trim().toUpperCase();
  if (['1', 'SI', 'SÍ', 'TRUE', 'VERDADERO', 'YES'].includes(normalized)) return true;
  if (['0', 'NO', 'FALSE', 'FALSO'].includes(normalized)) return false;
  throw importError(422, 'BOOLEAN_INVALID', `${field} debe indicar SI o NO.`);
}

function parsePositive(value, fallback, field, { integer = false } = {}) {
  if (blank(value)) return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0 || (integer && !Number.isInteger(number))) {
    throw importError(422, 'NUMBER_INVALID', `${field} debe ser ${integer ? 'un entero ' : ''}mayor que cero.`);
  }
  return number;
}

function parseRows(filename, mimeType, bytes) {
  const lower = filename.toLowerCase();
  const isZip = bytes.length >= 4 && bytes.readUInt32LE(0) === 0x04034b50;
  if (lower.endsWith('.csv')) {
    if (isZip || !['text/csv', 'text/plain'].includes(mimeType)) throw importError(422, 'IMPORT_CONTENT_MISMATCH', 'El contenido no coincide con un archivo CSV.');
    return parseCsv(bytes.toString('utf8'));
  }
  if (lower.endsWith('.xlsx')) {
    if (!isZip || mimeType !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') throw importError(422, 'IMPORT_CONTENT_MISMATCH', 'El contenido no coincide con un archivo XLSX.');
    return parseXlsx(bytes);
  }
  throw importError(422, 'IMPORT_FORMAT_INVALID', 'La extensión debe ser .csv o .xlsx.');
}

function objectRows(rows) {
  const headers = rows[0].map((value) => String(value || '').trim());
  return rows.slice(1).map((values, index) => ({
    rowNumber: index + 2,
    raw: Object.fromEntries(headers.map((header, column) => [header, values[column] ?? '']))
  })).filter((item) => Object.values(item.raw).some((value) => !blank(String(value).trim())));
}

function resolveCategory(code, expectedNature, db) {
  const category = db.prepare('SELECT * FROM asset_category WHERE code=? COLLATE NOCASE AND active=1 AND deleted_at IS NULL').get(String(code || '').trim());
  if (!category) throw importError(422, 'CATEGORY_INVALID', `Categoría inexistente o inactiva: ${code || 'vacía'}.`);
  if (category.nature !== expectedNature) throw importError(422, expectedNature === 'VEHICULO' ? 'VEHICLE_CATEGORY_REQUIRED' : 'KIT_CATEGORY_REQUIRED', `La categoría ${category.code} no es de naturaleza ${expectedNature}.`);
  return category;
}

function resolveLocation(locationCode, siteCode, db) {
  const params = [String(locationCode || '').trim()];
  let sql = `SELECT sl.*,s.code AS site_code,s.active AS site_active FROM storage_location sl JOIN site s ON s.id=sl.site_id
    WHERE sl.code=? COLLATE NOCASE AND sl.active=1 AND s.active=1`;
  if (!blank(siteCode)) { sql += ' AND s.code=? COLLATE NOCASE'; params.push(String(siteCode).trim()); }
  const matches = db.prepare(sql).all(...params);
  if (!matches.length) throw importError(422, 'LOCATION_INVALID', `Ubicación inexistente o inactiva: ${locationCode || 'vacía'}.`);
  if (matches.length > 1) throw importError(422, 'LOCATION_AMBIGUOUS', `Ubicación ambigua: ${locationCode}. Indique sede_codigo.`);
  return matches[0];
}

function assertMode(mode, existing, code) {
  if (mode === 'CREATE_ONLY' && existing) throw importError(409, 'IMPORT_CREATE_ONLY_CONFLICT', `El bien ${code} ya existe y el lote es solo alta.`);
  if (mode === 'UPDATE_ONLY' && !existing) throw importError(422, 'IMPORT_UPDATE_ONLY_MISSING', `El bien ${code} no existe y el lote es solo actualización.`);
}

function explicitStatus(value, currentStatus) {
  if (blank(value)) return currentStatus || 'DISPONIBLE';
  const status = String(value).trim().toUpperCase();
  if (!MASTER_STATUSES.has(status)) throw importError(422, 'ASSET_STATUS_INVALID', 'El estado indicado no es administrable mediante importación.');
  return status;
}

function profileSnapshot(db, assetId) {
  return db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(assetId);
}

function componentSnapshot(db, kitAssetId) {
  return db.prepare('SELECT * FROM kit_component WHERE kit_asset_id=? ORDER BY sequence,id').all(kitAssetId);
}

function hasKitPath(db, fromId, targetId, visited = new Set()) {
  if (fromId === targetId) return true;
  if (visited.has(fromId)) return false;
  visited.add(fromId);
  const children = db.prepare(`SELECT kc.component_asset_id FROM kit_component kc
    JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE kc.kit_asset_id=? AND kc.active=1 AND c.nature='KIT'`).all(fromId);
  return children.some((row) => hasKitPath(db, row.component_asset_id, targetId, visited));
}

function vehicleMeterInput(raw, mapping, current) {
  const usageCell = cell(raw, mapping, 'usageUnit');
  const conversionCell = cell(raw, mapping, 'kmPerHour');
  const usageUnit = String(choose(usageCell, current?.usage_unit || 'KILOMETROS')).toUpperCase();
  const kmPerHour = choose(conversionCell, current?.km_per_hour || 50);
  const odometerCell = cell(raw, mapping, 'currentOdometer');
  const hourmeterCell = cell(raw, mapping, 'currentHourmeter');
  const hasOdometer = !blank(odometerCell);
  const hasHourmeter = !blank(hourmeterCell);
  const conversionChanged = !blank(conversionCell) || !blank(usageCell);
  if (hasOdometer && hasHourmeter) {
    const odometer = Number(odometerCell);
    const hourmeter = Number(hourmeterCell);
    const conversion = Number(kmPerHour);
    if (!Number.isFinite(odometer) || !Number.isFinite(hourmeter) || !Number.isFinite(conversion) || Math.abs(odometer - hourmeter * conversion) > Math.max(0.01, conversion * 0.001)) {
      throw importError(422, 'VEHICLE_METERS_INCONSISTENT', 'Kilometraje, horómetro y equivalencia no son consistentes entre sí.');
    }
    return { usageUnit, kmPerHour, currentOdometer: odometerCell, currentHourmeter: hourmeterCell };
  }
  if (usageUnit === 'HORAS') {
    const primaryHourmeter = hasHourmeter
      ? hourmeterCell
      : (hasOdometer ? Number(odometerCell) / Number(kmPerHour) : current?.current_hourmeter ?? 0);
    return {
      usageUnit,
      kmPerHour,
      currentHourmeter: primaryHourmeter,
      currentOdometer: hasOdometer ? odometerCell : (hasHourmeter || conversionChanged ? null : current?.current_odometer ?? null)
    };
  }
  const primaryOdometer = hasOdometer
    ? odometerCell
    : (hasHourmeter ? Number(hourmeterCell) * Number(kmPerHour) : current?.current_odometer ?? 0);
  return {
    usageUnit,
    kmPerHour,
    currentOdometer: primaryOdometer,
    currentHourmeter: hasHourmeter ? hourmeterCell : (hasOdometer || conversionChanged ? null : current?.current_hourmeter ?? null)
  };
}

function validateVehicleRows(sourceRows, mapping, mode, db, context) {
  const records = [];
  const seen = { codes: new Set(), serials: new Set(), plates: new Set(), vins: new Set(), chassis: new Set() };
  for (const source of sourceRows) {
    const errors = [];
    let normalized = null;
    let operation = null;
    let before = null;
    try {
      const rawCode = cell(source.raw, mapping, 'internalCode');
      const code = requiredString(String(rawCode || ''), 'codigo_interno', { min: 2, max: 60 }).toUpperCase();
      if (seen.codes.has(code)) throw importError(422, 'FILE_DUPLICATE_CODE', `Código interno duplicado dentro del archivo: ${code}.`);
      const existing = db.prepare(`${assetSelect()} WHERE a.internal_code=? COLLATE NOCASE AND a.deleted_at IS NULL`).get(code);
      assertMode(mode, existing, code);
      if (existing && existing.category_nature !== 'VEHICULO') throw importError(409, 'IMPORT_NATURE_MISMATCH', `El código ${code} pertenece a un bien que no es vehículo.`);
      const currentProfile = existing ? profileSnapshot(db, existing.id) : null;
      if (existing && !currentProfile) throw importError(409, 'VEHICLE_PROFILE_MISSING', `El vehículo ${code} no posee perfil estructural.`);

      const categoryCode = choose(cell(source.raw, mapping, 'categoryCode'), existing?.category_code);
      const category = resolveCategory(categoryCode, 'VEHICULO', db);
      const locationCode = choose(cell(source.raw, mapping, 'locationCode'), existing?.location_code);
      const siteCode = choose(cell(source.raw, mapping, 'siteCode'), existing?.site_code);
      const location = resolveLocation(locationCode, siteCode, db);
      assertLocationScope(context.user, location.id, 'Import.Create', db);
      if (existing) assertAssetScope(context.user, existing.id, 'Import.Create', db);

      const active = parseBooleanCell(cell(source.raw, mapping, 'active'), existing ? Boolean(existing.active) : true, 'activo');
      const status = explicitStatus(cell(source.raw, mapping, 'status'), existing?.status);
      const meterInput = vehicleMeterInput(source.raw, mapping, currentProfile);
      const profile = normalizeVehicleProfile({
        vin: choose(cell(source.raw, mapping, 'vin'), currentProfile?.vin),
        chassisNumber: choose(cell(source.raw, mapping, 'chassisNumber'), currentProfile?.chassis_number),
        engineNumber: choose(cell(source.raw, mapping, 'engineNumber'), currentProfile?.engine_number),
        manufactureYear: choose(cell(source.raw, mapping, 'manufactureYear'), currentProfile?.manufacture_year),
        vehicleClass: choose(cell(source.raw, mapping, 'vehicleClass'), currentProfile?.vehicle_class),
        ...meterInput,
        fuelType: choose(cell(source.raw, mapping, 'fuelType'), currentProfile?.fuel_type ?? existing?.fuel_type),
        fuelCapacity: choose(cell(source.raw, mapping, 'fuelCapacity'), currentProfile?.fuel_capacity),
        requiredLicenseClass: choose(cell(source.raw, mapping, 'requiredLicenseClass'), currentProfile?.required_license_class),
        active
      });
      const asset = normalizeAsset({
        categoryId: category.id,
        internalCode: code,
        description: choose(cell(source.raw, mapping, 'description'), existing?.description),
        locationId: location.id,
        licensePlate: choose(cell(source.raw, mapping, 'licensePlate'), existing?.license_plate),
        serialNumber: choose(cell(source.raw, mapping, 'serialNumber'), existing?.serial_number),
        brand: choose(cell(source.raw, mapping, 'brand'), existing?.brand),
        model: choose(cell(source.raw, mapping, 'model'), existing?.model),
        status,
        active,
        odometer: profile.currentOdometer,
        fuelType: profile.fuelType,
        notes: choose(cell(source.raw, mapping, 'notes'), existing?.notes),
        quantityTotal: 1,
        quantityAvailable: active && status === 'DISPONIBLE' ? 1 : 0
      }, existing || null, db, { systemOperation: blank(cell(source.raw, mapping, 'status')) });

      const uniqueValues = [
        ['serials', asset.serialNumber, 'FILE_DUPLICATE_SERIAL', 'Número de serie'],
        ['plates', asset.licensePlate, 'FILE_DUPLICATE_LICENSE', 'Patente'],
        ['vins', profile.vin, 'FILE_DUPLICATE_VIN', 'VIN'],
        ['chassis', profile.chassisNumber, 'FILE_DUPLICATE_CHASSIS', 'Chasis']
      ];
      for (const [setName, value, errorCode, label] of uniqueValues) {
        const key = value ? String(value).toUpperCase() : null;
        if (key && seen[setName].has(key)) throw importError(422, errorCode, `${label} duplicado dentro del archivo: ${key}.`);
      }
      const duplicateSerial = asset.serialNumber && db.prepare("SELECT id FROM asset WHERE serial_number=? COLLATE NOCASE AND deleted_at IS NULL AND id<>COALESCE(?, '')").get(asset.serialNumber, existing?.id || null);
      const duplicatePlate = asset.licensePlate && db.prepare("SELECT id FROM asset WHERE license_plate=? COLLATE NOCASE AND deleted_at IS NULL AND id<>COALESCE(?, '')").get(asset.licensePlate, existing?.id || null);
      const duplicateVin = profile.vin && db.prepare("SELECT asset_id FROM vehicle_profile WHERE vin=? COLLATE NOCASE AND asset_id<>COALESCE(?, '')").get(profile.vin, existing?.id || null);
      const duplicateChassis = profile.chassisNumber && db.prepare("SELECT asset_id FROM vehicle_profile WHERE chassis_number=? COLLATE NOCASE AND asset_id<>COALESCE(?, '')").get(profile.chassisNumber, existing?.id || null);
      if (duplicateSerial) throw importError(409, 'ASSET_SERIAL_DUPLICATE', `El número de serie ${asset.serialNumber} pertenece a otro bien.`);
      if (duplicatePlate) throw importError(409, 'ASSET_LICENSE_DUPLICATE', `La patente ${asset.licensePlate} pertenece a otro bien.`);
      if (duplicateVin || duplicateChassis) throw importError(409, 'VEHICLE_IDENTIFIER_DUPLICATE', 'VIN o chasis asignado a otro vehículo.');

      for (const [setName, value] of uniqueValues) { if (value) seen[setName].add(String(value).toUpperCase()); }
      seen.codes.add(code);
      operation = existing ? 'UPDATE' : 'CREATE';
      before = existing ? { asset: existing, vehicleProfile: currentProfile } : null;
      normalized = { importKind: 'VEHICLE', asset, vehicleProfile: profile, siteId: location.site_id, locationId: location.id };
    } catch (error) {
      errors.push({ code: error.code || 'ROW_INVALID', message: error.message, fieldErrors: error.fieldErrors || [] });
    }
    records.push({ rowNumber: source.rowNumber, raw: source.raw, normalized, operation, before, errors });
  }
  return records;
}

function consistentGroupValue(group, mapping, field) {
  const values = group.map((item) => cell(item.raw, mapping, field)).filter((value) => !blank(value));
  const normalized = [...new Set(values.map((value) => String(value).trim()))];
  if (normalized.length > 1) throw importError(422, 'KIT_MASTER_DATA_CONFLICT', `El campo ${field} posee valores diferentes para el mismo kit.`);
  return values[0] ?? '';
}

function resolveKitMechanic(group, mapping, db) {
  const username = String(consistentGroupValue(group, mapping, 'mechanicUsername') || '').trim();
  const employeeNumber = String(consistentGroupValue(group, mapping, 'mechanicEmployeeNumber') || '').trim();
  if (!username && !employeeNumber) return null;
  const where = ['p.deleted_at IS NULL', 'p.status=\'ACTIVA\'', 'ua.deleted_at IS NULL', 'ua.active=1'];
  const params = [];
  if (username) { where.push('ua.username=? COLLATE NOCASE'); params.push(username); }
  if (employeeNumber) { where.push('p.employee_number=? COLLATE NOCASE'); params.push(employeeNumber); }
  const matches = db.prepare(`SELECT p.id AS person_id,p.employee_number,ua.id AS user_id,ua.username
    FROM person p JOIN user_account ua ON ua.person_id=p.id WHERE ${where.join(' AND ')}`).all(...params);
  if (!matches.length) throw importError(422, 'KIT_MECHANIC_NOT_FOUND', `No existe un mecánico activo para ${username || employeeNumber}.`);
  if (matches.length !== 1) throw importError(422, 'KIT_MECHANIC_AMBIGUOUS', 'La identificación del mecánico es ambigua. Indique usuario y/o legajo correctos.');
  return { personId: matches[0].person_id, userId: matches[0].user_id, username: matches[0].username, employeeNumber: matches[0].employee_number };
}

function validateKitRows(sourceRows, mapping, mode, db, context) {
  const groups = new Map();
  const seenSerials = new Set();
  for (const source of sourceRows) {
    const code = String(cell(source.raw, mapping, 'internalCode') || '').trim().toUpperCase();
    const key = code || `__ROW_${source.rowNumber}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(source);
  }
  const records = [];
  for (const group of groups.values()) {
    const errors = [];
    let normalized = null;
    let operation = null;
    let before = null;
    const first = group[0];
    try {
      const code = requiredString(String(cell(first.raw, mapping, 'internalCode') || ''), 'kit_codigo_interno', { min: 2, max: 60 }).toUpperCase();
      const existing = db.prepare(`${assetSelect()} WHERE a.internal_code=? COLLATE NOCASE AND a.deleted_at IS NULL`).get(code);
      assertMode(mode, existing, code);
      if (existing && existing.category_nature !== 'KIT') throw importError(409, 'IMPORT_NATURE_MISMATCH', `El código ${code} pertenece a un bien que no es kit.`);
      const currentDefinition = existing ? db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(existing.id) : null;
      if (existing && !currentDefinition) throw importError(409, 'KIT_DEFINITION_MISSING', `El kit ${code} no posee definición estructural.`);

      const categoryCode = choose(consistentGroupValue(group, mapping, 'categoryCode'), existing?.category_code);
      const category = resolveCategory(categoryCode, 'KIT', db);
      const locationCode = choose(consistentGroupValue(group, mapping, 'locationCode'), existing?.location_code);
      const siteCode = choose(consistentGroupValue(group, mapping, 'siteCode'), existing?.site_code);
      const location = resolveLocation(locationCode, siteCode, db);
      assertLocationScope(context.user, location.id, 'Import.Create', db);
      if (existing) assertAssetScope(context.user, existing.id, 'Import.Create', db);
      const mechanic = resolveKitMechanic(group, mapping, db);

      const active = parseBooleanCell(consistentGroupValue(group, mapping, 'active'), existing ? Boolean(existing.active) : true, 'activo');
      const statusCell = consistentGroupValue(group, mapping, 'status');
      const status = explicitStatus(statusCell, existing?.status);
      const asset = normalizeAsset({
        categoryId: category.id,
        internalCode: code,
        description: choose(consistentGroupValue(group, mapping, 'description'), existing?.description),
        locationId: location.id,
        serialNumber: choose(consistentGroupValue(group, mapping, 'serialNumber'), existing?.serial_number),
        brand: choose(consistentGroupValue(group, mapping, 'brand'), existing?.brand),
        model: choose(consistentGroupValue(group, mapping, 'model'), existing?.model),
        status,
        active,
        notes: choose(consistentGroupValue(group, mapping, 'definitionNotes'), existing?.notes),
        quantityTotal: 1,
        quantityAvailable: active && status === 'DISPONIBLE' ? 1 : 0
      }, existing || null, db, { systemOperation: blank(statusCell) });

      const rawComponents = group.map((source, index) => {
        const componentCode = requiredString(String(cell(source.raw, mapping, 'componentCode') || ''), `componente_codigo fila ${source.rowNumber}`, { min: 2, max: 60 }).toUpperCase();
        const component = db.prepare(`${assetSelect()} WHERE a.internal_code=? COLLATE NOCASE AND a.deleted_at IS NULL`).get(componentCode);
        if (!component) throw importError(422, 'KIT_COMPONENT_NOT_FOUND', `No existe el componente ${componentCode}.`);
        if (existing && (component.id === existing.id || (component.category_nature === 'KIT' && hasKitPath(db, component.id, existing.id)))) {
          throw importError(422, 'KIT_CYCLE', `El componente ${componentCode} genera un ciclo de kits.`);
        }
        return {
          componentAssetId: component.id,
          requiredQuantity: parsePositive(cell(source.raw, mapping, 'requiredQuantity'), 1, `cantidad_requerida fila ${source.rowNumber}`),
          mandatory: parseBooleanCell(cell(source.raw, mapping, 'mandatory'), true, `obligatorio fila ${source.rowNumber}`),
          allowSubstitution: parseBooleanCell(cell(source.raw, mapping, 'allowSubstitution'), false, `permite_sustitucion fila ${source.rowNumber}`),
          sequence: parsePositive(cell(source.raw, mapping, 'sequence'), index + 1, `secuencia fila ${source.rowNumber}`, { integer: true }),
          componentCode
        };
      });
      const components = normalizeKitComponents(db, rawComponents, context).map((item, index) => ({
        componentAssetId: item.componentAssetId,
        requiredQuantity: item.requiredQuantity,
        mandatory: item.mandatory,
        allowSubstitution: item.allowSubstitution,
        sequence: item.sequence,
        componentCode: rawComponents[index].componentCode
      }));
      const serialKey = asset.serialNumber ? String(asset.serialNumber).toUpperCase() : null;
      if (serialKey && seenSerials.has(serialKey)) throw importError(422, 'FILE_DUPLICATE_SERIAL', `Número de serie duplicado dentro del archivo: ${serialKey}.`);
      const serialDuplicate = asset.serialNumber && db.prepare("SELECT id FROM asset WHERE serial_number=? COLLATE NOCASE AND deleted_at IS NULL AND id<>COALESCE(?, '')").get(asset.serialNumber, existing?.id || null);
      if (serialDuplicate) throw importError(409, 'ASSET_SERIAL_DUPLICATE', `El número de serie ${asset.serialNumber} pertenece a otro bien.`);
      if (serialKey) seenSerials.add(serialKey);

      operation = existing ? 'UPDATE' : 'CREATE';
      before = existing ? { asset: existing, kitDefinition: currentDefinition, components: componentSnapshot(db, existing.id) } : null;
      normalized = {
        importKind: 'KIT', asset, components,
        allowIncompleteWithAuthorization: parseBooleanCell(consistentGroupValue(group, mapping, 'allowIncompleteWithAuthorization'), currentDefinition ? Boolean(currentDefinition.allow_incomplete_with_authorization) : false, 'permite_kit_incompleto_con_autorizacion'),
        definitionNotes: choose(consistentGroupValue(group, mapping, 'definitionNotes'), currentDefinition?.notes),
        siteId: location.site_id,
        mechanic,
        locationId: location.id
      };
    } catch (error) {
      errors.push({ code: error.code || 'ROW_INVALID', message: error.message, fieldErrors: error.fieldErrors || [] });
    }
    records.push({
      rowNumber: first.rowNumber,
      raw: { kit_codigo_interno: cell(first.raw, mapping, 'internalCode'), source_rows: group.map((item) => ({ rowNumber: item.rowNumber, ...item.raw })) },
      normalized, operation, before, errors
    });
  }
  return records;
}

function validateSpecializedImport(input, context, kind) {
  const normalizedKind = String(kind || input.kind || '').toUpperCase();
  if (!SPECIALIZED_KINDS.has(normalizedKind)) throw importError(422, 'IMPORT_KIND_INVALID', 'Tipo de importación especializada inválido.');
  const filename = requiredString(input.filename, 'filename', { min: 5, max: 180 });
  const mode = String(input.mode || 'CREATE_OR_UPDATE').toUpperCase();
  if (!MODES.has(mode)) throw importError(422, 'IMPORT_MODE_INVALID', 'Modo de importación inválido.');
  const parsed = parseDataUrl(input.dataUrl);
  if (parsed.bytes.length > runtime.maxImportBytes) throw importError(413, 'IMPORT_TOO_LARGE', 'El archivo de importación supera 5 MiB.');
  const rows = parseRows(filename, parsed.mimeType, parsed.bytes);
  if (rows.length < 2) throw importError(422, 'IMPORT_EMPTY', 'El archivo no contiene filas de datos.');
  if (rows.length > 10_001) throw importError(422, 'IMPORT_TOO_MANY_ROWS', 'El lote supera 10.000 filas.');
  const headers = rows[0].map((value) => String(value || '').trim());
  const mapping = normalizedKind === 'VEHICLE'
    ? resolveMapping(headers, VEHICLE_ALIASES, ['internalCode', 'categoryCode', 'description', 'locationCode', 'licensePlate'], 'plantilla de vehículos')
    : resolveMapping(headers, KIT_ALIASES, ['internalCode', 'categoryCode', 'description', 'locationCode', 'componentCode'], 'plantilla de kits');
  const sources = objectRows(rows);
  const db = getDb();
  const records = normalizedKind === 'VEHICLE'
    ? validateVehicleRows(sources, mapping, mode, db, context)
    : validateKitRows(sources, mapping, mode, db, context);
  const validRows = records.filter((record) => !record.errors.length).length;
  const invalidRows = records.length - validRows;
  const id = randomUUID();
  return saveOwnedEvidenceDataUrl(
    { dataUrl: input.dataUrl, originalFilename: filename },
    { ownerType: 'IMPORT_BATCH', ownerId: id, purpose: 'SOURCE_FILE' },
    context,
    { allowedMimeTypes: ['text/csv', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'], maxBytes: runtime.maxImportBytes },
    (tx, evidence) => {
      const now = new Date().toISOString();
      const status = invalidRows ? 'VALIDADA_CON_ERRORES' : 'VALIDADA';
      const storedMapping = { ...mapping, __importKind: normalizedKind, __sourceRows: sources.length };
      tx.prepare(`INSERT INTO import_batch(id,type,filename,mime_type,file_evidence_id,sha256,status,mode,mapping_json,total_rows,valid_rows,invalid_rows,created_by,created_at,validated_at,version)
        VALUES (?, 'ASSET', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`)
        .run(id, filename, parsed.mimeType, evidence.id, sha256(parsed.bytes), status, mode, JSON.stringify(storedMapping), records.length, validRows, invalidRows, context.user.id, now, now);
      const insertRow = tx.prepare(`INSERT INTO import_row(id,batch_id,row_number,raw_json,normalized_json,operation,validation_status,errors_json,before_json,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
      for (const record of records) {
        insertRow.run(randomUUID(), id, record.rowNumber, JSON.stringify(record.raw), record.normalized ? JSON.stringify(record.normalized) : null, record.operation, record.errors.length ? 'INVALID' : 'VALID', JSON.stringify(record.errors), record.before ? JSON.stringify(record.before) : null, now, now);
      }
      appendAudit({
        actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','),
        action: `IMPORT.${normalizedKind}_VALIDATE`, entityType: 'import_batch', entityId: id,
        after: { filename, sha256: sha256(parsed.bytes), status, mode, importKind: normalizedKind, totalRows: records.length, sourceRows: sources.length, validRows, invalidRows },
        correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent
      }, tx);
      return id;
    }
  );
}

function updateAssetFromImport(db, normalized, beforeAsset, batchId, now) {
  const result = db.prepare(`UPDATE asset SET category_id=?,internal_code=?,serial_number=?,description=?,brand=?,model=?,status=?,location_id=?,quantity_total=?,quantity_available=?,unit_of_measure=?,license_plate=?,odometer=?,fuel_type=?,notes=?,active=?,source_import_batch_id=?,version=version+1,updated_at=?
    WHERE id=? AND version=? AND deleted_at IS NULL`)
    .run(normalized.categoryId, normalized.internalCode, normalized.serialNumber, normalized.description, normalized.brand, normalized.model, normalized.status, normalized.locationId, normalized.quantityTotal, normalized.quantityAvailable, normalized.unitOfMeasure, normalized.licensePlate, normalized.odometer, normalized.fuelType, normalized.notes, normalized.active ? 1 : 0, batchId, now, beforeAsset.id, beforeAsset.version);
  if (result.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'El bien fue modificado después de validar el lote.');
}

function applyVehicleRow(db, row, normalized, before, batchId, context, now) {
  let assetId;
  if (row.operation === 'CREATE') {
    try { assetId = insertAsset(db, normalized.asset, { sourceImportBatchId: batchId, now }); } catch (error) { throw convertUniqueError(error); }
    const changed = db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,active=?,updated_at=? WHERE asset_id=?`)
      .run(normalized.vehicleProfile.vin, normalized.vehicleProfile.chassisNumber, normalized.vehicleProfile.engineNumber, normalized.vehicleProfile.manufactureYear, normalized.vehicleProfile.vehicleClass, normalized.vehicleProfile.currentOdometer, normalized.vehicleProfile.currentHourmeter, normalized.vehicleProfile.usageUnit, normalized.vehicleProfile.kmPerHour, normalized.vehicleProfile.fuelType, normalized.vehicleProfile.fuelCapacity, normalized.vehicleProfile.requiredLicenseClass, normalized.vehicleProfile.active, now, assetId);
    if (changed.changes !== 1) throw importError(409, 'VEHICLE_PROFILE_MISSING', 'No pudo completarse el perfil vehicular importado.');
  } else {
    assetId = before.asset.id;
    assertAssetScope(context.user, assetId, 'Import.Apply', db);
    updateAssetFromImport(db, normalized.asset, before.asset, batchId, now);
    const changed = db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,active=?,version=version+1,updated_at=? WHERE asset_id=? AND version=?`)
      .run(normalized.vehicleProfile.vin, normalized.vehicleProfile.chassisNumber, normalized.vehicleProfile.engineNumber, normalized.vehicleProfile.manufactureYear, normalized.vehicleProfile.vehicleClass, normalized.vehicleProfile.currentOdometer, normalized.vehicleProfile.currentHourmeter, normalized.vehicleProfile.usageUnit, normalized.vehicleProfile.kmPerHour, normalized.vehicleProfile.fuelType, normalized.vehicleProfile.fuelCapacity, normalized.vehicleProfile.requiredLicenseClass, normalized.vehicleProfile.active, now, assetId, before.vehicleProfile.version);
    if (changed.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'El perfil vehicular fue modificado después de validar el lote.');
  }
  const asset = db.prepare(`${assetSelect()} WHERE a.id=?`).get(assetId);
  const profile = profileSnapshot(db, assetId);
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: row.operation === 'CREATE' ? 'VEHICLE.IMPORT_CREATE' : 'VEHICLE.IMPORT_UPDATE', entityType: 'vehicle', entityId: assetId, before, after: { asset, vehicleProfile: profile }, correlationId: context.correlationId, source: 'IMPORT', reason: `Lote ${batchId}, fila ${row.row_number}`, ipAddress: context.ip, equipment: context.userAgent }, db);
  return { asset, applied: { profileVersion: profile.version } };
}

function writeKitComponents(db, kitAssetId, components, context, reason) {
  return syncKitComponentsInDb(db, kitAssetId, components, context, reason);
}

function applyKitRow(db, row, normalized, before, batchId, context, now) {
  let assetId;
  if (row.operation === 'CREATE') {
    try { assetId = insertAsset(db, normalized.asset, { sourceImportBatchId: batchId, now }); } catch (error) { throw convertUniqueError(error); }
    const changed = db.prepare('UPDATE kit_definition SET allow_incomplete_with_authorization=?,notes=?,updated_at=? WHERE kit_asset_id=?')
      .run(normalized.allowIncompleteWithAuthorization ? 1 : 0, normalized.definitionNotes || null, now, assetId);
    if (changed.changes !== 1) throw importError(409, 'KIT_DEFINITION_MISSING', 'No pudo completarse la definición del kit importado.');
    writeKitComponents(db, assetId, normalized.components, context, 'Importación especializada de kit');
  } else {
    assetId = before.asset.id;
    assertAssetScope(context.user, assetId, 'Import.Apply', db);
    updateAssetFromImport(db, normalized.asset, before.asset, batchId, now);
    const changed = db.prepare('UPDATE kit_definition SET allow_incomplete_with_authorization=?,notes=?,version=version+1,updated_at=? WHERE kit_asset_id=? AND version=?')
      .run(normalized.allowIncompleteWithAuthorization ? 1 : 0, normalized.definitionNotes || null, now, assetId, before.kitDefinition.version);
    if (changed.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'La definición del kit fue modificada después de validar el lote.');
    writeKitComponents(db, assetId, normalized.components, context, 'Importación especializada de kit');
  }
  let assignment = null;
  if (normalized.mechanic) {
    assignment = assignKitToPersonInDb(db, assetId, {
      personId: normalized.mechanic.personId,
      assignmentNotes: `Importación de kit ${batchId}`,
      reason: `Importación de kit ${batchId}`,
      reassign: true
    }, context, { skipScope: true, allowReassign: true });
  }
  const asset = db.prepare(`${assetSelect()} WHERE a.id=?`).get(assetId);
  const definition = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(assetId);
  const components = componentSnapshot(db, assetId);
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: row.operation === 'CREATE' ? 'KIT.IMPORT_CREATE' : 'KIT.IMPORT_UPDATE', entityType: 'kit', entityId: assetId, before, after: { asset, kitDefinition: definition, components, assignment }, correlationId: context.correlationId, source: 'IMPORT', reason: `Lote ${batchId}, fila ${row.row_number}`, ipAddress: context.ip, equipment: context.userAgent }, db);
  return { asset, applied: { definitionVersion: definition.version, assignmentVersion: assignment?.version || null, components: components.map((component) => ({ id: component.id, version: component.version })) } };
}

function applySpecializedImport(id, context, kind) {
  const current = getDb().prepare('SELECT * FROM import_batch WHERE id=?').get(id);
  if (!current) throw importError(404, 'IMPORT_NOT_FOUND', 'Lote no encontrado.');
  if (current.status === 'APLICADA') return id;
  if (current.status !== 'VALIDADA' || current.invalid_rows !== 0) throw importError(409, 'IMPORT_NOT_APPLICABLE', 'El lote debe estar validado sin errores antes de aplicar.');
  return transaction((db) => {
    const batch = db.prepare('SELECT * FROM import_batch WHERE id=?').get(id);
    const storedKind = String(JSON.parse(batch.mapping_json || '{}').__importKind || '').toUpperCase();
    if (batch.status !== 'VALIDADA' || storedKind !== kind) throw importError(409, 'IMPORT_STATE_CONFLICT', 'El lote cambió de estado o tipo.');
    const rows = db.prepare("SELECT * FROM import_row WHERE batch_id=? AND validation_status='VALID' ORDER BY row_number").all(id);
    const now = new Date().toISOString();
    for (const row of rows) {
      const normalized = JSON.parse(row.normalized_json);
      const before = row.before_json ? JSON.parse(row.before_json) : null;
      assertLocationScope(context.user, normalized.locationId, 'Import.Apply', db);
      const result = kind === 'VEHICLE'
        ? applyVehicleRow(db, row, normalized, before, id, context, now)
        : applyKitRow(db, row, normalized, before, id, context, now);
      normalized.applied = result.applied;
      db.prepare("UPDATE import_row SET validation_status='APPLIED',resulting_entity_id=?,applied_entity_version=?,normalized_json=?,updated_at=? WHERE id=?")
        .run(result.asset.id, result.asset.version, JSON.stringify(normalized), now, row.id);
    }
    db.prepare("UPDATE import_batch SET status='APLICADA',applied_at=?,version=version+1 WHERE id=? AND status='VALIDADA'").run(now, id);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: `IMPORT.${kind}_APPLY`, entityType: 'import_batch', entityId: id, before: { status: 'VALIDADA' }, after: { status: 'APLICADA', appliedAt: now, rows: rows.length, importKind: kind }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return id;
  });
}

function assertAppliedComponentsUnchanged(db, kitAssetId, applied) {
  const current = componentSnapshot(db, kitAssetId).map((item) => ({ id: item.id, version: item.version }));
  const expected = applied?.components || [];
  if (current.length !== expected.length || current.some((item, index) => item.id !== expected[index]?.id || item.version !== expected[index]?.version)) {
    throw importError(409, 'IMPORT_REVERSE_CONFLICT', 'La composición del kit fue modificada después de la importación.');
  }
}

function restoreAsset(db, asset, current, now) {
  const result = db.prepare(`UPDATE asset SET category_id=?,internal_code=?,serial_number=?,description=?,brand=?,model=?,status=?,location_id=?,custodian_person_id=?,quantity_total=?,quantity_available=?,unit_of_measure=?,license_plate=?,odometer=?,fuel_type=?,notes=?,photo_evidence_id=?,source_import_batch_id=?,active=?,deleted_at=?,version=version+1,updated_at=? WHERE id=? AND version=?`)
    .run(asset.category_id, asset.internal_code, asset.serial_number, asset.description, asset.brand, asset.model, asset.status, asset.location_id, asset.custodian_person_id, asset.quantity_total, asset.quantity_available, asset.unit_of_measure, asset.license_plate, asset.odometer, asset.fuel_type, asset.notes, asset.photo_evidence_id, asset.source_import_batch_id, asset.active, asset.deleted_at, now, current.id, current.version);
  if (result.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'El bien cambió durante la reversión.');
}

function reverseVehicleRow(db, row, normalized, before, asset, id, context, now) {
  const profile = profileSnapshot(db, asset.id);
  if (!profile || profile.version !== normalized.applied?.profileVersion) throw importError(409, 'IMPORT_REVERSE_CONFLICT', 'El perfil vehicular fue modificado después de la importación.');
  if (row.operation === 'CREATE') {
    db.prepare("UPDATE asset SET active=0,status='BAJA',quantity_available=0,deleted_at=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now, now, asset.id, asset.version);
    db.prepare('UPDATE vehicle_profile SET active=0,version=version+1,updated_at=? WHERE asset_id=? AND version=?').run(now, asset.id, profile.version);
  } else {
    restoreAsset(db, before.asset, asset, now);
    const restored = db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,active=?,version=version+1,updated_at=? WHERE asset_id=? AND version=?`)
      .run(before.vehicleProfile.vin, before.vehicleProfile.chassis_number, before.vehicleProfile.engine_number, before.vehicleProfile.manufacture_year, before.vehicleProfile.vehicle_class, before.vehicleProfile.current_odometer, before.vehicleProfile.current_hourmeter, before.vehicleProfile.usage_unit, before.vehicleProfile.km_per_hour, before.vehicleProfile.fuel_type, before.vehicleProfile.fuel_capacity, before.vehicleProfile.required_license_class, before.vehicleProfile.active, now, asset.id, profile.version);
    if (restored.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'El perfil cambió durante la reversión.');
  }
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: row.operation === 'CREATE' ? 'VEHICLE.IMPORT_REVERSE_CREATE' : 'VEHICLE.IMPORT_REVERSE_UPDATE', entityType: 'vehicle', entityId: asset.id, before: asset, after: before, correlationId: context.correlationId, source: 'IMPORT', reason: `Reversión lote ${id}`, ipAddress: context.ip, equipment: context.userAgent }, db);
}

function reverseKitRow(db, row, normalized, before, asset, id, context, now) {
  const definition = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(asset.id);
  if (!definition || definition.version !== normalized.applied?.definitionVersion) throw importError(409, 'IMPORT_REVERSE_CONFLICT', 'La definición del kit fue modificada después de la importación.');
  assertAppliedComponentsUnchanged(db, asset.id, normalized.applied);
  if (row.operation === 'CREATE') {
    closeActiveAssignmentForKitLifecycleInDb(db, asset.id, context, 'Reversión de importación de kit');
    db.prepare("UPDATE asset SET active=0,status='BAJA',quantity_available=0,deleted_at=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now, now, asset.id, asset.version);
    db.prepare('UPDATE kit_component SET active=0,version=version+1,updated_at=? WHERE kit_asset_id=?').run(now, asset.id);
  } else {
    restoreAsset(db, before.asset, asset, now);
    const restored = db.prepare('UPDATE kit_definition SET allow_incomplete_with_authorization=?,notes=?,version=version+1,updated_at=? WHERE kit_asset_id=? AND version=?')
      .run(before.kitDefinition.allow_incomplete_with_authorization, before.kitDefinition.notes, now, asset.id, definition.version);
    if (restored.changes !== 1) throw importError(409, 'CONCURRENCY_CONFLICT', 'La definición cambió durante la reversión.');
    const previousComponents = before.components.filter((component) => component.active).map((component) => ({
      componentAssetId: component.component_asset_id,
      requiredQuantity: Number(component.required_quantity),
      mandatory: Boolean(component.mandatory),
      allowSubstitution: Boolean(component.allow_substitution),
      sequence: Number(component.sequence)
    }));
    syncKitComponentsInDb(db, asset.id, previousComponents, context, 'Reversión de actualización importada de kit');
  }
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: row.operation === 'CREATE' ? 'KIT.IMPORT_REVERSE_CREATE' : 'KIT.IMPORT_REVERSE_UPDATE', entityType: 'kit', entityId: asset.id, before: asset, after: before, correlationId: context.correlationId, source: 'IMPORT', reason: `Reversión lote ${id}`, ipAddress: context.ip, equipment: context.userAgent }, db);
}

function reverseSpecializedImport(id, input, context, kind) {
  const current = getDb().prepare('SELECT * FROM import_batch WHERE id=?').get(id);
  if (!current) throw importError(404, 'IMPORT_NOT_FOUND', 'Lote no encontrado.');
  if (current.status === 'REVERTIDA') return id;
  if (current.status !== 'APLICADA') throw importError(409, 'IMPORT_NOT_REVERSIBLE', 'Solo puede revertirse un lote aplicado.');
  if (String(input.confirmation || '') !== `REVERTIR:${id}`) throw importError(422, 'IMPORT_CONFIRMATION_INVALID', 'Confirmación de reversión inválida.');
  return transaction((db) => {
    const batch = db.prepare('SELECT * FROM import_batch WHERE id=?').get(id);
    const storedKind = String(JSON.parse(batch.mapping_json || '{}').__importKind || '').toUpperCase();
    if (batch.status !== 'APLICADA' || storedKind !== kind) throw importError(409, 'IMPORT_STATE_CONFLICT', 'El lote cambió de estado o tipo.');
    const rows = db.prepare("SELECT * FROM import_row WHERE batch_id=? AND validation_status='APPLIED' ORDER BY row_number DESC").all(id);
    const now = new Date().toISOString();
    for (const row of rows) {
      const normalized = JSON.parse(row.normalized_json);
      const before = row.before_json ? JSON.parse(row.before_json) : null;
      const asset = db.prepare('SELECT * FROM asset WHERE id=?').get(row.resulting_entity_id);
      if (!asset || asset.version !== row.applied_entity_version) throw importError(409, 'IMPORT_REVERSE_CONFLICT', `No puede revertirse la fila ${row.row_number}: el bien fue modificado después de la importación.`);
      assertAssetScope(context.user, asset.id, 'Import.Reverse', db);
      if (kind === 'VEHICLE') reverseVehicleRow(db, row, normalized, before, asset, id, context, now);
      else reverseKitRow(db, row, normalized, before, asset, id, context, now);
      db.prepare("UPDATE import_row SET validation_status='REVERTED',updated_at=? WHERE id=?").run(now, row.id);
    }
    db.prepare("UPDATE import_batch SET status='REVERTIDA',reverted_at=?,version=version+1 WHERE id=? AND status='APLICADA'").run(now, id);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: `IMPORT.${kind}_REVERSE`, entityType: 'import_batch', entityId: id, before: { status: 'APLICADA' }, after: { status: 'REVERTIDA', revertedAt: now, rows: rows.length, importKind: kind }, correlationId: context.correlationId, source: 'API', reason: input.reason || null, ipAddress: context.ip, equipment: context.userAgent }, db);
    return id;
  });
}

function specializedTemplate(kind, format = 'csv') {
  const normalizedKind = String(kind || '').toUpperCase();
  if (!SPECIALIZED_KINDS.has(normalizedKind)) throw importError(422, 'IMPORT_KIND_INVALID', 'Tipo de plantilla especializada inválido.');
  const headers = normalizedKind === 'VEHICLE' ? VEHICLE_TEMPLATE_HEADERS : KIT_TEMPLATE_HEADERS;
  const stem = normalizedKind === 'VEHICLE' ? 'plantilla_vehiculos_ingar' : 'plantilla_kits_componentes_ingar';
  if (format === 'xlsx') return { bytes: createXlsx([headers], { sheetName: normalizedKind === 'VEHICLE' ? 'Vehiculos' : 'Kits y componentes', headerRow: 1, freezeRow: 2, autoFilter: true }), mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename: `${stem}.xlsx` };
  return { bytes: Buffer.from(`\uFEFF${headers.join(';')}\r\n`, 'utf8'), mimeType: 'text/csv; charset=utf-8', filename: `${stem}.csv` };
}

module.exports = {
  SPECIALIZED_KINDS,
  VEHICLE_TEMPLATE_HEADERS,
  KIT_TEMPLATE_HEADERS,
  validateSpecializedImport,
  applySpecializedImport,
  reverseSpecializedImport,
  specializedTemplate
};
