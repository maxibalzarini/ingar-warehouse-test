'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { protectBuffer, atomicWrite } = require('../security/data-protection');
const { getDb } = require('../db/database');
const { getNetworkStatus, isLocalMachineAddress } = require('./network-service');
const logger = require('./logger');
const { appendAudit } = require('./audit-service');
const { requiredString, optionalString } = require('../security/validation');

const SESSION_TTL_MS = 10 * 60 * 1000;
const sessionsById = new Map();
const sessionIdByToken = new Map();

function error(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function normalizeRemoteAddress(value) {
  const address = String(value || '').trim().toLowerCase();
  return address.startsWith('::ffff:') ? address.slice(7) : address;
}

function isLoopback(value) {
  const address = normalizeRemoteAddress(value);
  return !address || address === '127.0.0.1' || address === '::1' || address === 'localhost';
}

function cleanUserAgent(value) {
  return String(value || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 300) || null;
}

function classifyUserAgent(value) {
  const userAgent = cleanUserAgent(value) || '';
  if (/android|iphone|ipad|ipod|windows phone|mobile/i.test(userAgent)) return 'MOBILE_LIKE';
  if (/windows nt|macintosh|x11|cros|linux x86_64/i.test(userAgent)) return 'DESKTOP_LIKE';
  return 'UNKNOWN';
}

function boundedInteger(value, min, max) {
  const number = Number.parseInt(value, 10);
  return Number.isInteger(number) ? Math.min(max, Math.max(min, number)) : null;
}

function cleanDeviceEvidence(value) {
  const input = value && typeof value === 'object' ? value : {};
  return Object.freeze({
    screenWidth: boundedInteger(input.screenWidth, 0, 10000),
    screenHeight: boundedInteger(input.screenHeight, 0, 10000),
    viewportWidth: boundedInteger(input.viewportWidth, 0, 10000),
    viewportHeight: boundedInteger(input.viewportHeight, 0, 10000),
    maxTouchPoints: boundedInteger(input.maxTouchPoints, 0, 32) || 0,
    touchEvent: input.touchEvent === true,
    coarsePointer: input.coarsePointer === true,
    standalone: input.standalone === true,
    platform: String(input.platform || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 100) || null,
    vendor: String(input.vendor || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 120) || null,
    orientation: String(input.orientation || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 60) || null
  });
}

function hasTouchSignals(evidence) {
  return Boolean(evidence && evidence.maxTouchPoints > 0 && (evidence.touchEvent || evidence.coarsePointer));
}

function physicalConfirmationCode(session) {
  return `CONFIRMAR_TELEFONO_FISICO:${session.id.slice(0, 8).toUpperCase()}`;
}


function ensureSecondLanDevice(secondDevice) {
  if (!secondDevice) {
    throw error(409, 'MOBILE_VALIDATION_SECOND_DEVICE_REQUIRED', 'Esta etapa debe registrarse desde un segundo dispositivo de la red local.');
  }
}

function ensureSameRemoteDevice(session, remoteAddress) {
  if (session.remoteAddress && session.remoteAddress !== remoteAddress) {
    throw error(409, 'MOBILE_VALIDATION_DEVICE_MISMATCH', 'La prueba debe completarse desde el mismo dispositivo que abrió el QR.');
  }
}

function ensureStageOrder(session, stage) {
  if (stage === 'AUTHENTICATED' && !session.operationOpenedRemote) {
    throw error(409, 'MOBILE_VALIDATION_STAGE_ORDER', 'Primero debe abrirse Mi operación desde el segundo dispositivo.');
  }
  if (stage === 'REQUEST_CREATED' && !session.authenticatedRemote) {
    throw error(409, 'MOBILE_VALIDATION_STAGE_ORDER', 'Primero debe autenticarse el usuario desde el mismo segundo dispositivo.');
  }
}

function bindSecondDevice(session, remoteAddress, userAgent, deviceEvidence = null) {
  ensureSameRemoteDevice(session, remoteAddress);
  session.remoteAddress ||= remoteAddress;
  session.userAgent ||= cleanUserAgent(userAgent);
  if (!session.deviceClass || session.deviceClass === 'UNKNOWN') session.deviceClass = classifyUserAgent(userAgent);
  if (!session.deviceEvidence && deviceEvidence) session.deviceEvidence = cleanDeviceEvidence(deviceEvidence);
  session.secondDeviceDetected = true;
}

function hasValidStageSequence(session) {
  if (!session.operationOpenedAt || !session.authenticatedAt || !session.requestCreatedAt) return false;
  const operationMs = Date.parse(session.operationOpenedAt);
  const authMs = Date.parse(session.authenticatedAt);
  const requestMs = Date.parse(session.requestCreatedAt);
  return [operationMs, authMs, requestMs].every(Number.isFinite) && operationMs <= authMs && authMs <= requestMs;
}

function publicStatus(session, { includeUrl = false } = {}) {
  const now = Date.now();
  const expired = now > session.expiresAtMs && !session.passed;
  const status = session.passed ? 'PASSED' : expired ? 'EXPIRED' : session.requestCreatedRemote ? 'REQUEST_CREATED' : session.authenticatedRemote ? 'AUTHENTICATED' : session.operationOpenedRemote ? 'OPERATION_OPENED' : 'WAITING_SCAN';
  const result = {
    id: session.id,
    siteId: session.siteId,
    siteCode: session.siteCode,
    siteName: session.siteName,
    status,
    passed: Boolean(session.passed),
    validationScope: session.physicalPhoneAttestation ? 'PHYSICAL_PHONE_ATTESTED' : 'SECOND_DEVICE_LAN',
    physicalPhoneVerified: Boolean(session.physicalPhoneAttestation),
    productAcceptanceReady: Boolean(session.passed && session.physicalPhoneAttestation),
    physicalConfirmationCode: session.passed && !session.physicalPhoneAttestation ? physicalConfirmationCode(session) : null,
    stageSequenceValid: Boolean(session.stageSequenceValid),
    secondDeviceDetected: Boolean(session.secondDeviceDetected),
    operationOpenedRemote: Boolean(session.operationOpenedRemote),
    authenticatedRemote: Boolean(session.authenticatedRemote),
    requestCreatedRemote: Boolean(session.requestCreatedRemote),
    createdAt: session.createdAt,
    expiresAt: session.expiresAt,
    operationOpenedAt: session.operationOpenedAt || null,
    authenticatedAt: session.authenticatedAt || null,
    requestCreatedAt: session.requestCreatedAt || null,
    remoteAddress: session.remoteAddress || null,
    userAgent: session.userAgent || null,
    deviceClass: session.deviceClass || 'UNKNOWN',
    deviceEvidence: session.deviceEvidence || null,
    physicalPhoneAttestation: session.physicalPhoneAttestation || null,
    username: session.username || null,
    requestId: session.requestId || null,
    requestNumber: session.requestNumber || null,
    evidenceFile: session.evidenceFile || null
  };
  if (includeUrl) result.url = session.url;
  return result;
}

function evidencePayload(session) {
  const status = publicStatus(session);
  return {
    schema: 'iwc-mobile-validation-r14.4-v3',
    generatedAt: new Date().toISOString(),
    validation: status,
    checks: {
      operationOpenedFromSecondLanDevice: Boolean(session.operationOpenedRemote),
      authenticatedFromSameSecondLanDevice: Boolean(session.authenticatedRemote),
      requestCreatedFromSameSecondLanDevice: Boolean(session.requestCreatedRemote),
      sameRemoteAddressAcrossStages: Boolean(session.remoteAddress),
      sequentialStageOrder: Boolean(session.stageSequenceValid),
      requestCreatedDuringValidationWindow: Boolean(session.requestCreatedWithinWindow),
      requestCreatedAfterAuthentication: Boolean(session.requestCreatedAfterAuthentication),
      secondDeviceLanFlow: session.passed ? 'PASS' : 'PENDING',
      deviceReportsMobileUserAgent: session.deviceClass === 'MOBILE_LIKE',
      touchSignalsPresent: hasTouchSignals(session.deviceEvidence),
      physicalPhoneVerified: Boolean(session.physicalPhoneAttestation),
      physicalPhoneFlow: session.physicalPhoneAttestation ? 'PASS_ATTESTED' : 'NOT_VERIFIED',
      productAcceptanceReady: Boolean(session.passed && session.physicalPhoneAttestation)
    },
    security: {
      validationTokenPersisted: false,
      parallelAuthenticationRequired: false,
      fullOperationUrlPersisted: false
    }
  };
}

function persistEvidence(session) {
  try {
    fs.mkdirSync(runtime.evidenceDir, { recursive: true });
    const filename = `mobile-validation-${session.id}.json`;
    const target = path.join(runtime.evidenceDir, filename);
    session.evidenceFile = filename;
    const protectedBytes = protectBuffer(Buffer.from(`${JSON.stringify(evidencePayload(session), null, 2)}\n`, 'utf8'), { purpose: 'SYSTEM_EVIDENCE' });
    atomicWrite(target, protectedBytes);
    atomicWrite(path.join(runtime.evidenceDir, 'mobile-validation-latest.json'), protectedBytes);
    if (session.physicalPhoneAttestation) atomicWrite(path.join(runtime.evidenceDir, 'physical-phone-validation-latest.json'), protectedBytes);
  } catch (writeError) {
    logger.warn('MOBILE_VALIDATION', 'No fue posible persistir la evidencia de validación móvil.', { validationId: session.id, error: writeError.message });
  }
}

function cleanupExpired() {
  const now = Date.now();
  for (const [id, session] of sessionsById.entries()) {
    if (now <= session.expiresAtMs + SESSION_TTL_MS) continue;
    sessionsById.delete(id);
    sessionIdByToken.delete(session.validationToken);
  }
}

function requireSessionById(id) {
  cleanupExpired();
  const session = sessionsById.get(String(id || ''));
  if (!session) throw error(404, 'MOBILE_VALIDATION_NOT_FOUND', 'La prueba móvil no existe o ya venció.');
  return session;
}

function requireSessionByToken(token) {
  cleanupExpired();
  const normalized = String(token || '').trim();
  const id = sessionIdByToken.get(normalized);
  const session = id ? sessionsById.get(id) : null;
  if (!session) throw error(404, 'MOBILE_VALIDATION_NOT_FOUND', 'La prueba móvil no existe o ya venció.');
  if (Date.now() > session.expiresAtMs && !session.passed) throw error(410, 'MOBILE_VALIDATION_EXPIRED', 'La prueba móvil venció. Inicie una nueva desde la computadora.');
  return session;
}

function startMobileValidation({ siteId, actorUserId = null } = {}) {
  const network = getNetworkStatus();
  if (!network.available || !network.baseUrl) throw error(503, 'MOBILE_ACCESS_NETWORK_UNAVAILABLE', 'Mi operación no está disponible en la red local.');
  const site = getDb().prepare(`SELECT id AS site_id, code AS site_code, name AS site_name
    FROM site WHERE id = ? AND active = 1`).get(String(siteId || ''));
  if (!site) throw error(404, 'SITE_NOT_FOUND', 'La sede seleccionada no existe o está inactiva.');

  const id = randomUUID();
  const validationToken = randomBytes(12).toString('base64url');
  const createdAtMs = Date.now();
  const expiresAtMs = createdAtMs + SESSION_TTL_MS;
  const url = `${String(network.baseUrl).replace(/\/+$/, '')}/mi-operacion?v=${encodeURIComponent(validationToken)}`;
  const session = {
    id,
    validationToken,
    siteId: site.site_id,
    siteCode: site.site_code,
    siteName: site.site_name,
    actorUserId,
    url,
    createdAtMs,
    expiresAtMs,
    createdAt: new Date(createdAtMs).toISOString(),
    expiresAt: new Date(expiresAtMs).toISOString(),
    operationOpenedAt: null,
    authenticatedAt: null,
    requestCreatedAt: null,
    remoteAddress: null,
    userAgent: null,
    username: null,
    requestId: null,
    requestNumber: null,
    secondDeviceDetected: false,
    operationOpenedRemote: false,
    authenticatedRemote: false,
    requestCreatedRemote: false,
    requestCreatedWithinWindow: false,
    requestCreatedAfterAuthentication: false,
    stageSequenceValid: false,
    deviceClass: 'UNKNOWN',
    deviceEvidence: null,
    physicalPhoneAttestation: null,
    passed: false,
    evidenceFile: null
  };
  sessionsById.set(id, session);
  sessionIdByToken.set(validationToken, id);
  persistEvidence(session);
  logger.info('MOBILE_VALIDATION', 'Prueba móvil iniciada.', { validationId: id, siteId: site.site_id, expiresAt: session.expiresAt });
  return publicStatus(session, { includeUrl: true });
}

function recordMobileValidation({ validationToken, stage, requestId = null, deviceEvidence = null } = {}, context = {}, authUser = null) {
  const session = requireSessionByToken(validationToken);
  const normalizedStage = String(stage || '').trim().toUpperCase();
  if (!['OPERATION_OPENED', 'AUTHENTICATED', 'REQUEST_CREATED'].includes(normalizedStage)) throw error(400, 'MOBILE_VALIDATION_STAGE_INVALID', 'Etapa de validación móvil inválida.');

  const remoteAddress = normalizeRemoteAddress(context.ip);
  const secondDevice = !isLoopback(remoteAddress) && !isLocalMachineAddress(remoteAddress);
  const now = new Date().toISOString();

  if (normalizedStage === 'OPERATION_OPENED') {
    if (secondDevice) {
      bindSecondDevice(session, remoteAddress, context.userAgent, deviceEvidence);
      session.operationOpenedAt ||= now;
      session.operationOpenedRemote = true;
    }
  }

  if (normalizedStage === 'AUTHENTICATED') {
    if (!authUser) throw error(401, 'AUTH_REQUIRED', 'Debe iniciar sesión para continuar la prueba móvil.');
    ensureSecondLanDevice(secondDevice);
    ensureStageOrder(session, normalizedStage);
    ensureSameRemoteDevice(session, remoteAddress);
    bindSecondDevice(session, remoteAddress, context.userAgent, deviceEvidence);
    session.authenticatedAt ||= now;
    session.authenticatedRemote = true;
    session.username = authUser.username || authUser.fullName || null;
  }

  if (normalizedStage === 'REQUEST_CREATED') {
    if (!authUser) throw error(401, 'AUTH_REQUIRED', 'Debe iniciar sesión para completar la prueba móvil.');
    ensureSecondLanDevice(secondDevice);
    ensureStageOrder(session, normalizedStage);
    ensureSameRemoteDevice(session, remoteAddress);
    bindSecondDevice(session, remoteAddress, context.userAgent, deviceEvidence);
    const request = getDb().prepare(`SELECT id, request_number, site_id, requester_person_id, source, created_by_user_id, created_at
      FROM "request" WHERE id = ?`).get(String(requestId || ''));
    if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'La solicitud indicada no existe.');
    const requestCreatedMs = Date.parse(request.created_at || '');
    const authenticatedMs = Date.parse(session.authenticatedAt || '');
    const createdWithinWindow = Number.isFinite(requestCreatedMs)
      && requestCreatedMs >= session.createdAtMs - 1_000
      && requestCreatedMs <= Date.now() + 5_000;
    const createdAfterAuthentication = Number.isFinite(requestCreatedMs)
      && Number.isFinite(authenticatedMs)
      && requestCreatedMs >= authenticatedMs - 1_000;
    if (request.site_id !== session.siteId
      || request.requester_person_id !== authUser.personId
      || request.created_by_user_id !== authUser.id
      || request.source !== 'PORTAL'
      || !createdWithinWindow
      || !createdAfterAuthentication) {
      throw error(403, 'MOBILE_VALIDATION_REQUEST_MISMATCH', 'La solicitud no corresponde a esta prueba, fue creada antes de iniciarla o precede a la autenticación validada.');
    }
    if (session.requestId && session.requestId !== request.id) {
      throw error(409, 'MOBILE_VALIDATION_REQUEST_ALREADY_RECORDED', 'La prueba ya quedó asociada a otra solicitud.');
    }
    session.requestCreatedAt ||= request.created_at || now;
    session.requestCreatedRemote = true;
    session.requestCreatedWithinWindow = true;
    session.requestCreatedAfterAuthentication = true;
    session.username = authUser.username || authUser.fullName || null;
    session.requestId = request.id;
    session.requestNumber = request.request_number;
  }

  session.stageSequenceValid = hasValidStageSequence(session);
  session.passed = Boolean(
    session.operationOpenedRemote
    && session.authenticatedRemote
    && session.requestCreatedRemote
    && session.requestCreatedWithinWindow
    && session.requestCreatedAfterAuthentication
    && session.stageSequenceValid
  );
  persistEvidence(session);
  logger.info('MOBILE_VALIDATION', 'Avance de validación de segundo dispositivo LAN registrado.', {
    validationId: session.id,
    stage: normalizedStage,
    validationScope: 'SECOND_DEVICE_LAN',
    deviceClass: session.deviceClass,
    secondDeviceDetected: session.secondDeviceDetected,
    stageSequenceValid: session.stageSequenceValid,
    passed: session.passed,
    requestId: session.requestId
  }, context.correlationId || null);
  return publicStatus(session);
}


function attestPhysicalPhone(id, input = {}, context = {}) {
  const session = requireSessionById(id);
  if (!session.passed) throw error(409, 'PHYSICAL_PHONE_LAN_FLOW_REQUIRED', 'Primero debe completarse la validación desde el segundo dispositivo LAN.');
  if (session.physicalPhoneAttestation) throw error(409, 'PHYSICAL_PHONE_ALREADY_ATTESTED', 'El teléfono físico ya fue atestiguado para esta prueba.');
  if (session.deviceClass !== 'MOBILE_LIKE' || !hasTouchSignals(session.deviceEvidence)) {
    throw error(409, 'PHYSICAL_PHONE_SIGNALS_INSUFFICIENT', 'El segundo dispositivo no informó señales técnicas compatibles con un equipo móvil táctil.');
  }
  if (input.observedPhysicalPhone !== true) throw error(422, 'PHYSICAL_PHONE_OBSERVATION_REQUIRED', 'Debe confirmar que observó físicamente el teléfono utilizado.');
  const expected = physicalConfirmationCode(session);
  if (String(input.confirmation || '').trim().toUpperCase() !== expected) {
    throw error(422, 'PHYSICAL_PHONE_CONFIRMATION_INVALID', `Escriba exactamente ${expected}.`);
  }
  const witnessName = requiredString(input.witnessName, 'witnessName', { min: 3, max: 120 });
  const deviceBrandModel = requiredString(input.deviceBrandModel, 'deviceBrandModel', { min: 2, max: 120 });
  const notes = optionalString(input.notes, 'notes', { max: 1000 });
  const user = context.user || {};
  if (!user.id) throw error(401, 'AUTH_REQUIRED', 'Se requiere un operador autenticado para atestiguar el teléfono físico.');
  const baseAttestation = {
    method: 'LOCAL_OPERATOR_VISUAL_ATTESTATION',
    confirmedAt: new Date().toISOString(),
    actorUserId: user.id,
    actorUsername: user.username || null,
    actorFullName: user.fullName || null,
    actorRoles: Array.isArray(user.roleCodes) ? [...user.roleCodes] : [],
    witnessName,
    deviceBrandModel,
    notes,
    observedPhysicalPhone: true,
    remoteAddress: session.remoteAddress,
    userAgent: session.userAgent,
    deviceClass: session.deviceClass,
    deviceEvidence: session.deviceEvidence
  };
  const audit = appendAudit({
    actorUserId: user.id,
    actorRole: Array.isArray(user.roleCodes) ? user.roleCodes.join(',') : null,
    action: 'MOBILE.PHYSICAL_PHONE_ATTEST',
    entityType: 'mobile_validation',
    entityId: session.id,
    after: baseAttestation,
    correlationId: context.correlationId || randomUUID(),
    source: 'LOCAL_UI',
    reason: notes || 'Aceptación física del teléfono validada por el operador',
    ipAddress: context.ip || null,
    equipment: context.userAgent || null
  });
  session.physicalPhoneAttestation = Object.freeze({ ...baseAttestation, auditEventId: audit.id, auditEvidenceHash: audit.evidenceHash });
  persistEvidence(session);
  logger.info('MOBILE_VALIDATION', 'Teléfono físico atestiguado por operador local.', { validationId: session.id, actorUserId: user.id, auditEvidenceHash: audit.evidenceHash }, context.correlationId || null);
  return publicStatus(session);
}

function getMobileValidation(id, options = {}) {
  const session = requireSessionById(id);
  if (Date.now() > session.expiresAtMs && !session.passed) persistEvidence(session);
  return publicStatus(session, { includeUrl: Boolean(options.includeUrl) });
}

function getMobileValidationEvidence(id) {
  const session = requireSessionById(id);
  return evidencePayload(session);
}

function resetForTests() {
  sessionsById.clear();
  sessionIdByToken.clear();
}

module.exports = {
  SESSION_TTL_MS,
  startMobileValidation,
  recordMobileValidation,
  getMobileValidation,
  getMobileValidationEvidence,
  attestPhysicalPhone,
  physicalConfirmationCode,
  cleanDeviceEvidence,
  hasTouchSignals,
  normalizeRemoteAddress,
  isLoopback,
  classifyUserAgent,
  resetForTests
};
