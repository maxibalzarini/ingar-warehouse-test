'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb, closeDatabase, reopenDatabase, currentSchemaVersion, safeSqlitePath, transaction } = require('../db/database');
const { sha256, stableJson } = require('../security/tokens');
const { openSqliteBytes, openCipherDatabase, isPlaintextSqlite, encryptPlaintextDatabase } = require('../security/sqlite-encryption');
const { isProtectedBuffer, protectBuffer, unprotectBuffer, atomicWrite } = require('../security/data-protection');
const { protectPortableBackup, unprotectPortableBackup, validatedPassword } = require('../security/portable-backup');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const logger = require('./logger');

function collectFiles(rootDir) {
  if (!fs.existsSync(rootDir)) return [];
  const result = [];
  for (const entry of fs.readdirSync(rootDir, { withFileTypes: true })) {
    const fullPath = path.join(rootDir, entry.name);
    if (entry.isDirectory()) {
      for (const nested of collectFiles(fullPath)) result.push({ ...nested, name: path.join(entry.name, nested.name).replaceAll('\\', '/') });
    } else if (entry.isFile()) {
      const stored = fs.readFileSync(fullPath);
      const bytes = isProtectedBuffer(stored) ? unprotectBuffer(stored).bytes : stored;
      result.push({ name: entry.name, size: bytes.length, sha256: sha256(bytes), contentBase64: bytes.toString('base64') });
    }
  }
  return result;
}

function archivePayload(dbBytes, evidenceFiles, schemaVersion, options = {}) {
  const portable = options.portable === true;
  const manifest = {
    format: portable ? 'IWC_PORTABLE_BACKUP_V1' : 'IWC_BACKUP_V2',
    createdAt: options.createdAt || new Date().toISOString(),
    schemaVersion,
    database: {
      name: 'iwc.sqlite',
      size: dbBytes.length,
      sha256: sha256(dbBytes),
      encryptedAtRest: !dbBytes.subarray(0, 16).equals(Buffer.from('SQLite format 3\0', 'binary'))
    },
    archiveProtection: {
      format: portable ? 'IWC_PORTABLE_ENCRYPTED_BACKUP_V1' : 'IWC_ENCRYPTED_CONTAINER_V1',
      cipher: 'AES-256-GCM',
      keyProvider: portable ? 'USER_PASSWORD_SCRYPT' : 'LOCAL_PROTECTED_MASTER_KEY'
    },
    evidence: evidenceFiles.map(({ name, size, sha256: hash }) => ({ name, size, sha256: hash }))
  };
  const manifestSha256 = sha256(stableJson(manifest));
  return {
    manifest,
    manifestSha256,
    databaseBase64: dbBytes.toString('base64'),
    evidence: evidenceFiles
  };
}

function createBackup(context = {}) {
  const id = randomUUID();
  const tempDb = path.join(runtime.backupDir, `${id}.snapshot.sqlite`);
  const backupFile = path.join(runtime.backupDir, `${id}.iwcbak.gz`);
  fs.mkdirSync(runtime.backupDir, { recursive: true });
  const now = new Date().toISOString();
  getDb().prepare(`INSERT INTO backup_set(id, created_at, created_by, schema_version, manifest_sha256, status, verified_at, path_ref, size, error, updated_at)
    VALUES (?, ?, ?, ?, '', 'CREANDO', NULL, ?, NULL, NULL, ?)`)
    .run(id, now, context.user?.id || null, currentSchemaVersion(), path.basename(backupFile), now);
  try {
    getDb().exec(`VACUUM INTO '${safeSqlitePath(tempDb)}'`);
    const dbBytes = fs.readFileSync(tempDb);
    const evidenceFiles = collectFiles(runtime.evidenceDir);
    const payload = archivePayload(dbBytes, evidenceFiles, currentSchemaVersion());
    const compressed = zlib.gzipSync(Buffer.from(JSON.stringify(payload)), { level: 9 });
    const protectedBytes = protectBuffer(compressed, { purpose: 'BACKUP' });
    fs.writeFileSync(backupFile, protectedBytes, { flag: 'wx', mode: 0o600 });
    fs.rmSync(tempDb, { force: true });
    transaction((db) => {
      db.prepare(`UPDATE backup_set SET manifest_sha256 = ?, status = 'CREADO', size = ?, updated_at = ? WHERE id = ?`)
        .run(payload.manifestSha256, protectedBytes.length, new Date().toISOString(), id);
      appendAudit({ actorUserId: context.user?.id || null, actorRole: context.user?.roleCodes?.join(',') || null, action: 'BACKUP.CREATE', entityType: 'backup_set', entityId: id, after: { schemaVersion: payload.manifest.schemaVersion, manifestSha256: payload.manifestSha256, size: protectedBytes.length, encrypted: true }, correlationId: context.correlationId || randomUUID(), source: context.source || 'SCHEDULER', ipAddress: context.ip, equipment: context.userAgent }, db);
    });
    rotateBackups();
    return getBackup(id);
  } catch (error) {
    fs.rmSync(tempDb, { force: true });
    fs.rmSync(backupFile, { force: true });
    getDb().prepare("UPDATE backup_set SET status = 'FALLIDO', error = ?, updated_at = ? WHERE id = ?").run(error.message, new Date().toISOString(), id);
    logger.error('BACKUP', 'Falló la creación del backup.', { id, error: error.message }, context.correlationId);
    throw error;
  }
}

function validateArchiveName(name) {
  const normalized = String(name || '').replaceAll('\\', '/');
  if (!normalized || normalized.startsWith('/') || normalized.includes('../') || normalized.includes('/..') || normalized.includes('\0')) throw new Error('Ruta de evidencia inválida en backup.');
  return normalized;
}

function verifySqliteBytes(dbBytes) {
  fs.mkdirSync(runtime.backupDir, { recursive: true });
  const tempPath = path.join(runtime.backupDir, `${randomUUID()}.verify.sqlite`);
  fs.writeFileSync(tempPath, dbBytes, { flag: 'wx' });
  let database;
  try {
    database = openSqliteBytes(tempPath, { readOnly: true });
    const quick = database.prepare('PRAGMA quick_check').all();
    if (!quick.length || quick.some((row) => Object.values(row)[0] !== 'ok')) throw new Error('PRAGMA quick_check detectó corrupción.');
    const foreignKeys = database.prepare('PRAGMA foreign_key_check').all();
    if (foreignKeys.length) throw new Error(`Integridad referencial inválida: ${foreignKeys.length} violaciones.`);
    const schemaVersion = Number(database.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migration').get().version || 0);
    return { quickCheck: 'ok', foreignKeyViolations: 0, schemaVersion };
  } finally {
    try { database?.close(); } catch {}
    fs.rmSync(tempPath, { force: true });
  }
}

function decodeCompressedPayload(compressed, acceptedFormats = ['IWC_BACKUP_V1', 'IWC_BACKUP_V2']) {
  const uncompressed = zlib.gunzipSync(compressed, { maxOutputLength: 512 * 1024 * 1024 });
  const payload = JSON.parse(uncompressed.toString('utf8'));
  if (!acceptedFormats.includes(payload?.manifest?.format) || !Array.isArray(payload.manifest.evidence) || !Array.isArray(payload.evidence)) throw new Error('Formato de backup inválido.');
  const manifestHash = sha256(stableJson(payload.manifest));
  if (manifestHash !== payload.manifestSha256) throw new Error('Hash del manifiesto inválido.');
  const dbBytes = Buffer.from(payload.databaseBase64 || '', 'base64');
  if (!dbBytes.length || dbBytes.length !== payload.manifest.database.size || sha256(dbBytes) !== payload.manifest.database.sha256) throw new Error('Integridad de la base de datos inválida.');
  const expectedEvidence = new Map();
  for (const item of payload.manifest.evidence) {
    const name = validateArchiveName(item.name);
    if (expectedEvidence.has(name)) throw new Error(`Evidencia duplicada en manifiesto: ${name}.`);
    expectedEvidence.set(name, item);
  }
  const actualNames = new Set();
  for (const file of payload.evidence) {
    const name = validateArchiveName(file.name);
    if (actualNames.has(name)) throw new Error(`Evidencia duplicada en contenido: ${name}.`);
    actualNames.add(name);
    const expected = expectedEvidence.get(name);
    const bytes = Buffer.from(file.contentBase64 || '', 'base64');
    if (!expected || bytes.length !== expected.size || sha256(bytes) !== expected.sha256) throw new Error(`Integridad inválida en evidencia ${name}.`);
  }
  if (actualNames.size !== expectedEvidence.size || [...expectedEvidence.keys()].some((name) => !actualNames.has(name))) throw new Error('El contenido de evidencias está incompleto respecto del manifiesto.');
  const sqlite = verifySqliteBytes(dbBytes);
  if (sqlite.schemaVersion !== Number(payload.manifest.schemaVersion)) throw new Error('La versión SQLite no coincide con el manifiesto.');
  return { payload, dbBytes, sqlite };
}

function decodeAndVerify(filePath) {
  const stored = fs.readFileSync(filePath);
  const compressed = isProtectedBuffer(stored)
    ? unprotectBuffer(stored, { purpose: 'BACKUP' }).bytes
    : stored;
  return { ...decodeCompressedPayload(compressed), encryptedContainer: isProtectedBuffer(stored) };
}

function transformDatabaseBytes(dbBytes, mode) {
  fs.mkdirSync(runtime.backupDir, { recursive: true });
  const temporary = path.join(runtime.backupDir, `${randomUUID()}.portable.sqlite`);
  fs.writeFileSync(temporary, dbBytes, { flag: 'wx', mode: 0o600 });
  try {
    if (mode === 'PLAINTEXT') {
      if (!isPlaintextSqlite(temporary)) {
        const database = openCipherDatabase(temporary, { fileMustExist: true });
        try {
          database.rekey(Buffer.alloc(0));
          database.pragma('wal_checkpoint(TRUNCATE)');
        } finally {
          database.close();
        }
      }
      if (!isPlaintextSqlite(temporary)) throw new Error('No fue posible preparar una base portátil.');
    } else if (mode === 'LOCAL_ENCRYPTED') {
      if (!isPlaintextSqlite(temporary)) throw new Error('El backup portátil no contiene una base transportable.');
      encryptPlaintextDatabase(temporary);
      if (isPlaintextSqlite(temporary)) throw new Error('No fue posible cifrar la base con la instalación actual.');
    } else {
      throw new Error('Transformación de base no reconocida.');
    }
    return fs.readFileSync(temporary);
  } finally {
    fs.rmSync(temporary, { force: true });
    fs.rmSync(`${temporary}-wal`, { force: true });
    fs.rmSync(`${temporary}-shm`, { force: true });
  }
}

function exportPortableBackup(id, password, context = {}) {
  validatedPassword(password);
  const backup = getBackup(id);
  if (!backup || backup.status !== 'VERIFICADO') {
    throw Object.assign(new Error('Solo puede exportarse un backup verificado.'), { status: 422, code: 'BACKUP_NOT_VERIFIED' });
  }
  const decoded = decodeAndVerify(path.join(runtime.backupDir, backup.path_ref));
  const portableDatabase = transformDatabaseBytes(decoded.dbBytes, 'PLAINTEXT');
  const payload = archivePayload(portableDatabase, decoded.payload.evidence, decoded.sqlite.schemaVersion, {
    portable: true,
    createdAt: decoded.payload.manifest.createdAt
  });
  const compressed = zlib.gzipSync(Buffer.from(JSON.stringify(payload)), { level: 9 });
  const bytes = protectPortableBackup(compressed, password);
  const filename = `INGAR-backup-portatil-${new Date().toISOString().replaceAll(':', '-').replaceAll('.', '-')}.iwcportable`;
  transaction((db) => appendAudit({
    actorUserId: context.user?.id || null,
    actorRole: context.user?.roleCodes?.join(',') || null,
    action: 'BACKUP.PORTABLE_EXPORT',
    entityType: 'backup_set',
    entityId: id,
    after: {
      portable: true,
      schemaVersion: decoded.sqlite.schemaVersion,
      manifestSha256: payload.manifestSha256,
      size: bytes.length
    },
    correlationId: context.correlationId || randomUUID(),
    source: context.source || 'API',
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db));
  return { bytes, filename, sha256: sha256(bytes), schemaVersion: decoded.sqlite.schemaVersion };
}

function parsePortableUploadBody(body) {
  if (!Buffer.isBuffer(body) || body.length < 5) throw Object.assign(new Error('Carga de backup portátil incompleta.'), { status: 422, code: 'PORTABLE_BACKUP_UPLOAD_INVALID' });
  const headerLength = body.readUInt32BE(0);
  if (!headerLength || headerLength > 16 * 1024 || 4 + headerLength >= body.length) throw Object.assign(new Error('Cabecera de importación inválida.'), { status: 422, code: 'PORTABLE_BACKUP_UPLOAD_INVALID' });
  let header;
  try {
    header = JSON.parse(body.subarray(4, 4 + headerLength).toString('utf8'));
  } catch {
    throw Object.assign(new Error('Cabecera de importación inválida.'), { status: 422, code: 'PORTABLE_BACKUP_UPLOAD_INVALID' });
  }
  const filename = path.basename(String(header.filename || ''));
  if (!filename.toLowerCase().endsWith('.iwcportable') || filename.length > 255) throw Object.assign(new Error('Seleccione un archivo .iwcportable válido.'), { status: 422, code: 'PORTABLE_BACKUP_FILENAME_INVALID' });
  return { filename, password: validatedPassword(header.password), bytes: body.subarray(4 + headerLength) };
}

function importPortableBackup(body, context = {}) {
  const upload = parsePortableUploadBody(body);
  const compressed = unprotectPortableBackup(upload.bytes, upload.password).bytes;
  const decoded = decodeCompressedPayload(compressed, ['IWC_PORTABLE_BACKUP_V1']);
  if (!isPlaintextSqliteBuffer(decoded.dbBytes) || decoded.payload.manifest.database.encryptedAtRest !== false) {
    throw Object.assign(new Error('El backup no es transportable entre instalaciones.'), { status: 422, code: 'PORTABLE_BACKUP_DATABASE_INVALID' });
  }
  const installedSchema = currentSchemaVersion();
  if (decoded.sqlite.schemaVersion > installedSchema) {
    throw Object.assign(new Error(`El backup usa un esquema más nuevo (${decoded.sqlite.schemaVersion}) que esta instalación (${installedSchema}).`), { status: 422, code: 'PORTABLE_BACKUP_VERSION_TOO_NEW' });
  }
  const encryptedDatabase = transformDatabaseBytes(decoded.dbBytes, 'LOCAL_ENCRYPTED');
  const localPayload = archivePayload(encryptedDatabase, decoded.payload.evidence, decoded.sqlite.schemaVersion, {
    createdAt: decoded.payload.manifest.createdAt
  });
  const localCompressed = zlib.gzipSync(Buffer.from(JSON.stringify(localPayload)), { level: 9 });
  const localBytes = protectBuffer(localCompressed, { purpose: 'BACKUP' });
  const id = randomUUID();
  const backupFile = path.join(runtime.backupDir, `${id}.iwcbak.gz`);
  atomicWrite(backupFile, localBytes);
  try {
    transaction((db) => {
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO backup_set(id, created_at, created_by, schema_version, manifest_sha256, status, verified_at, path_ref, size, error, updated_at)
        VALUES (?, ?, ?, ?, ?, 'VERIFICADO', ?, ?, ?, NULL, ?)`)
        .run(id, now, context.user?.id || null, decoded.sqlite.schemaVersion, localPayload.manifestSha256, now, path.basename(backupFile), localBytes.length, now);
      appendAudit({
        actorUserId: context.user?.id || null,
        actorRole: context.user?.roleCodes?.join(',') || null,
        action: 'BACKUP.PORTABLE_IMPORT',
        entityType: 'backup_set',
        entityId: id,
        after: {
          originalFilename: upload.filename,
          portable: true,
          verified: true,
          schemaVersion: decoded.sqlite.schemaVersion,
          manifestSha256: localPayload.manifestSha256,
          sourceManifestSha256: decoded.payload.manifestSha256
        },
        correlationId: context.correlationId || randomUUID(),
        source: context.source || 'API',
        ipAddress: context.ip,
        equipment: context.userAgent
      }, db);
    });
    rotateBackups();
    return { imported: true, verified: true, backup: getBackup(id) };
  } catch (error) {
    fs.rmSync(backupFile, { force: true });
    throw error;
  }
}

function isPlaintextSqliteBuffer(bytes) {
  return Buffer.isBuffer(bytes)
    && bytes.length >= 16
    && bytes.subarray(0, 16).equals(Buffer.from('SQLite format 3\0', 'binary'));
}

function verifyBackup(id, context = {}) {
  const backup = getBackup(id);
  if (!backup) throw Object.assign(new Error('Backup no encontrado.'), { status: 404, code: 'BACKUP_NOT_FOUND' });
  const filePath = path.join(runtime.backupDir, backup.path_ref);
  try {
    const { payload, sqlite } = decodeAndVerify(filePath);
    transaction((db) => {
      const now = new Date().toISOString();
      db.prepare("UPDATE backup_set SET status = 'VERIFICADO', verified_at = ?, error = NULL, updated_at = ? WHERE id = ?").run(now, now, id);
      appendAudit({ actorUserId: context.user?.id || null, actorRole: context.user?.roleCodes?.join(',') || null, action: 'BACKUP.VERIFY', entityType: 'backup_set', entityId: id, after: { valid: true, schemaVersion: payload.manifest.schemaVersion, sqlite }, correlationId: context.correlationId || randomUUID(), source: context.source || 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    });
    return { valid: true, backup: getBackup(id), manifest: payload.manifest, sqlite };
  } catch (error) {
    getDb().prepare("UPDATE backup_set SET status = 'FALLIDO', error = ?, updated_at = ? WHERE id = ?").run(error.message, new Date().toISOString(), id);
    throw Object.assign(error, { status: 422, code: 'BACKUP_INVALID' });
  }
}


const RESTORE_MARKER_NAME = 'restore.pending.json';

function restoreMarkerPath() {
  return path.join(runtime.dataDir, RESTORE_MARKER_NAME);
}

function durableWriteJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  const handle = fs.openSync(tempPath, 'wx');
  try {
    fs.writeFileSync(handle, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
    fs.fsyncSync(handle);
  } finally {
    fs.closeSync(handle);
  }
  fs.renameSync(tempPath, filePath);
  try {
    const dirHandle = fs.openSync(path.dirname(filePath), 'r');
    try { fs.fsyncSync(dirHandle); } finally { fs.closeSync(dirHandle); }
  } catch (_) { /* Windows puede no permitir fsync del directorio; el archivo ya fue fsync. */ }
}

function readRestoreMarker() {
  const markerPath = restoreMarkerPath();
  if (!fs.existsSync(markerPath)) return null;
  return JSON.parse(fs.readFileSync(markerPath, 'utf8'));
}

function validateRestoreRecoveryPath(candidate, expectedPrefix) {
  const resolved = path.resolve(String(candidate || ''));
  const prefix = path.resolve(expectedPrefix);
  if (!resolved.startsWith(`${prefix}.`) && resolved !== prefix) {
    throw new Error(`Ruta de recuperación de restore inválida: ${resolved}`);
  }
  return resolved;
}

function rollbackInterruptedRestore(marker) {
  const safetyPath = validateRestoreRecoveryPath(marker.safetyPath, runtime.dbPath);
  const safetyEvidencePath = validateRestoreRecoveryPath(marker.safetyEvidencePath, runtime.evidenceDir);
  const stagingEvidencePath = validateRestoreRecoveryPath(marker.stagingEvidencePath, runtime.evidenceDir);
  const dbRestorePath = `${runtime.dbPath}.restore`;

  closeDatabase();
  fs.rmSync(runtime.dbPath, { force: true });
  fs.rmSync(`${runtime.dbPath}-wal`, { force: true });
  fs.rmSync(`${runtime.dbPath}-shm`, { force: true });
  fs.rmSync(dbRestorePath, { force: true });

  if (marker.hadDatabase) {
    if (!fs.existsSync(safetyPath)) throw new Error('No existe la copia de seguridad de DB requerida para recuperar un restore interrumpido.');
    fs.copyFileSync(safetyPath, runtime.dbPath);
  }

  fs.rmSync(runtime.evidenceDir, { recursive: true, force: true });
  if (marker.hadEvidenceDirectory) {
    if (!fs.existsSync(safetyEvidencePath)) throw new Error('No existe la copia de seguridad de evidencias requerida para recuperar un restore interrumpido.');
    fs.cpSync(safetyEvidencePath, runtime.evidenceDir, { recursive: true, force: false, errorOnExist: true });
  } else {
    fs.mkdirSync(runtime.evidenceDir, { recursive: true });
  }
  fs.rmSync(stagingEvidencePath, { recursive: true, force: true });
}

function recoverInterruptedRestore() {
  const markerPath = restoreMarkerPath();
  if (!fs.existsSync(markerPath)) return { recovered: false };
  let marker;
  try {
    marker = readRestoreMarker();
    if (!marker || marker.kind !== 'INGAR_WAREHOUSE_RESTORE_V1') throw new Error('Marcador de restore inválido.');
    rollbackInterruptedRestore(marker);
    fs.rmSync(markerPath, { force: true });
    logger.warn('BACKUP', 'Se recuperó automáticamente un restore interrumpido antes de iniciar el servidor.', {
      restoreToken: marker.restoreToken,
      backupId: marker.backupId,
      phase: marker.phase || null
    });
    return { recovered: true, restoreToken: marker.restoreToken, backupId: marker.backupId };
  } catch (error) {
    logger.error('BACKUP', 'No fue posible recuperar un restore interrumpido; se bloquea el arranque para proteger los datos.', { error: error.message });
    throw Object.assign(new Error('Existe una restauración interrumpida que no pudo recuperarse automáticamente. No iniciar operación hasta resolverla.'), {
      code: 'RESTORE_RECOVERY_REQUIRED',
      cause: error
    });
  }
}

function restoreBackup(id, confirmation, context) {
  if (confirmation !== `RESTORE:${id}`) throw Object.assign(new Error(`Confirmación requerida: RESTORE:${id}`), { status: 422, code: 'RESTORE_CONFIRMATION_REQUIRED' });
  const backup = getBackup(id);
  if (!backup || backup.status !== 'VERIFICADO') throw Object.assign(new Error('Solo puede restaurarse un backup verificado.'), { status: 422, code: 'BACKUP_NOT_VERIFIED' });
  const filePath = path.join(runtime.backupDir, backup.path_ref);
  const { payload, dbBytes } = decodeAndVerify(filePath);
  const restoreToken = `${Date.now()}-${randomUUID()}`;
  const safetyPath = `${runtime.dbPath}.pre-restore-${restoreToken}`;
  const safetyEvidencePath = `${runtime.evidenceDir}.pre-restore-${restoreToken}`;
  const stagingEvidencePath = `${runtime.evidenceDir}.restore-${restoreToken}`;
  const hadEvidenceDirectory = fs.existsSync(runtime.evidenceDir);
  const hadDatabase = fs.existsSync(runtime.dbPath);
  const markerPath = restoreMarkerPath();

  // Construye la evidencia restaurada fuera del directorio activo. Si falla una
  // escritura, la operación productiva todavía no fue modificada.
  fs.rmSync(stagingEvidencePath, { recursive: true, force: true });
  fs.mkdirSync(stagingEvidencePath, { recursive: true });
  try {
    for (const file of payload.evidence) {
      const target = path.resolve(stagingEvidencePath, file.name);
      if (!target.startsWith(path.resolve(stagingEvidencePath) + path.sep)) throw new Error('Ruta de evidencia inválida en backup.');
      fs.mkdirSync(path.dirname(target), { recursive: true });
      const plaintext = Buffer.from(file.contentBase64, 'base64');
      atomicWrite(target, protectBuffer(plaintext, { purpose: 'EVIDENCE_FILE' }));
    }

    // La copia de seguridad previa incluye DB y evidencia. No se toca el estado
    // activo hasta que ambos respaldos de rollback están disponibles.
    if (hadDatabase) fs.copyFileSync(runtime.dbPath, safetyPath, fs.constants.COPYFILE_EXCL);
    if (hadEvidenceDirectory) fs.cpSync(runtime.evidenceDir, safetyEvidencePath, {
      recursive: true,
      force: false,
      errorOnExist: true
    });

    // El marcador se escribe y fuerza a disco ANTES del primer cambio destructivo.
    // Si el proceso muere o se corta la energía, el próximo arranque revierte
    // DB + evidencia al estado previo antes de abrir SQLite.
    durableWriteJson(markerPath, {
      kind: 'INGAR_WAREHOUSE_RESTORE_V1',
      restoreToken,
      backupId: id,
      createdAt: new Date().toISOString(),
      phase: 'PREPARED',
      hadDatabase,
      hadEvidenceDirectory,
      safetyPath,
      safetyEvidencePath,
      stagingEvidencePath
    });

    closeDatabase();
    fs.rmSync(`${runtime.dbPath}.restore`, { force: true });
    fs.writeFileSync(`${runtime.dbPath}.restore`, dbBytes, { flag: 'wx' });
    fs.rmSync(runtime.dbPath, { force: true });
    fs.rmSync(`${runtime.dbPath}-wal`, { force: true });
    fs.rmSync(`${runtime.dbPath}-shm`, { force: true });
    fs.renameSync(`${runtime.dbPath}.restore`, runtime.dbPath);
    durableWriteJson(markerPath, { ...readRestoreMarker(), phase: 'DB_SWAPPED' });

    fs.rmSync(runtime.evidenceDir, { recursive: true, force: true });
    fs.renameSync(stagingEvidencePath, runtime.evidenceDir);
    durableWriteJson(markerPath, { ...readRestoreMarker(), phase: 'EVIDENCE_SWAPPED' });

    reopenDatabase();
    transaction((db) => {
      const now = new Date().toISOString();
      const actorExists = context.user?.id
        ? Boolean(db.prepare('SELECT 1 FROM user_account WHERE id = ?').get(context.user.id))
        : false;
      db.prepare(`INSERT OR REPLACE INTO backup_set(id, created_at, created_by, schema_version, manifest_sha256, status, verified_at, path_ref, size, error, updated_at)
        VALUES (?, ?, NULL, ?, ?, 'RESTAURADO', ?, ?, ?, NULL, ?)`)
        .run(id, backup.created_at || now, Number(payload.manifest.schemaVersion), backup.manifest_sha256, backup.verified_at || now, backup.path_ref, backup.size, now);
      appendAudit({
        actorUserId: actorExists ? context.user.id : null,
        actorRole: context.user?.roleCodes?.join(',') || null,
        action: 'BACKUP.RESTORE',
        entityType: 'backup_set',
        entityId: id,
        after: {
          restored: true,
          schemaVersion: payload.manifest.schemaVersion,
          safetyPath: path.basename(safetyPath),
          safetyEvidencePath: hadEvidenceDirectory ? path.basename(safetyEvidencePath) : null,
          portableCompatible: true,
          reauthenticationRequired: true
        },
        correlationId: context.correlationId,
        source: 'API',
        ipAddress: context.ip,
        equipment: context.userAgent
      }, db);
    });
    fs.rmSync(markerPath, { force: true });
    return {
      restored: true,
      backupId: id,
      safetyCopy: path.basename(safetyPath),
      safetyEvidenceCopy: hadEvidenceDirectory ? path.basename(safetyEvidencePath) : null,
      requiresReauthentication: true
    };
  } catch (error) {
    try {
      if (fs.existsSync(markerPath)) {
        // Sólo hay rollback destructivo si el marcador durable confirma que el
        // restore ya cruzó el punto de no retorno. Antes de ese punto el estado
        // activo nunca fue tocado y debe dejarse intacto.
        const marker = readRestoreMarker();
        rollbackInterruptedRestore(marker);
        fs.rmSync(markerPath, { force: true });
        reopenDatabase();
      }
    } catch (recoveryError) {
      logger.error('BACKUP', 'Falló la recuperación posterior a una restauración; el marcador queda retenido para bloquear el próximo arranque.', { error: recoveryError.message });
    } finally {
      fs.rmSync(stagingEvidencePath, { recursive: true, force: true });
    }
    throw error;
  }
}

function getBackup(id) {
  return getDb().prepare('SELECT * FROM backup_set WHERE id = ?').get(id) || null;
}

function listBackups() {
  return getDb().prepare('SELECT * FROM backup_set ORDER BY created_at DESC LIMIT 500').all();
}

function rotateBackups() {
  const keep = Math.max(1, Number(getSetting('backup.rotationCount', 14)) || 14);
  const rows = getDb().prepare("SELECT id, path_ref FROM backup_set WHERE status IN ('CREADO','VERIFICADO','FALLIDO') ORDER BY created_at DESC").all();
  for (const row of rows.slice(keep)) {
    fs.rmSync(path.join(runtime.backupDir, row.path_ref), { force: true });
    getDb().prepare('DELETE FROM backup_set WHERE id = ?').run(row.id);
  }
}

let scheduler = null;
function startBackupScheduler() {
  stopBackupScheduler();
  scheduler = setInterval(() => {
    try {
      if (getSetting('backup.enabled', false)) createBackup({ source: 'SCHEDULER', correlationId: randomUUID() });
    } catch (error) {
      logger.error('BACKUP', 'Backup automático fallido.', { error: error.message });
    }
  }, Math.max(1, Number(getSetting('backup.intervalHours', 24))) * 60 * 60 * 1000);
  scheduler.unref();
}
function stopBackupScheduler() { if (scheduler) clearInterval(scheduler); scheduler = null; }

function protectLegacyBackupFiles() {
  fs.mkdirSync(runtime.backupDir, { recursive: true });
  const changed = [];
  for (const name of fs.readdirSync(runtime.backupDir)) {
    if (!name.endsWith('.iwcbak.gz') && !name.endsWith('.iwcmigbak.gz')) continue;
    const filePath = path.join(runtime.backupDir, name);
    if (!fs.statSync(filePath).isFile()) continue;
    const bytes = fs.readFileSync(filePath);
    if (isProtectedBuffer(bytes)) continue;
    const purpose = name.endsWith('.iwcmigbak.gz') ? 'MIGRATION_BACKUP' : 'BACKUP';
    atomicWrite(filePath, protectBuffer(bytes, { purpose }));
    changed.push(name);
  }
  return { changed, encrypted: changed.length };
}

module.exports = {
  createBackup,
  verifyBackup,
  restoreBackup,
  exportPortableBackup,
  importPortableBackup,
  listBackups,
  getBackup,
  startBackupScheduler,
  stopBackupScheduler,
  decodeAndVerify,
  decodeCompressedPayload,
  parsePortableUploadBody,
  protectLegacyBackupFiles,
  recoverInterruptedRestore
};
