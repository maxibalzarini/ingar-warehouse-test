'use strict';

const { randomUUID } = require('node:crypto');
const { getDb } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { scopeWhere, permissionAssignments } = require('../security/scope');
const { appendAudit, iterateAuditRows } = require('./audit-service');
const { getSetting } = require('./settings-service');

const CATEGORY_DEFINITIONS = Object.freeze([
  { code: 'OPERACION', name: 'Operación', description: 'Solicitudes, entregas y actividad del pañol.' },
  { code: 'CUSTODIAS', name: 'Custodias y devoluciones', description: 'Herramientas entregadas, vencimientos y devoluciones.' },
  { code: 'INVENTARIO', name: 'Inventario', description: 'Disponibilidad y estado de bienes.' },
  { code: 'INCIDENTES_MANTENIMIENTO', name: 'Incidentes y mantenimiento', description: 'Anomalías, bloqueos y órdenes técnicas.' },
  { code: 'GESTION', name: 'Gestión', description: 'Indicadores consolidados para seguimiento.' },
  { code: 'ECONOMIA', name: 'Costos y presupuesto', description: 'Ejecución presupuestaria, costos, compras y decisiones económicas.' },
  { code: 'GESTION_ACCIONES', name: 'Planes y reuniones', description: 'Acciones, responsables, vencimientos, decisiones y actas de gestión.' },
  { code: 'AUDITORIA', name: 'Auditoría', description: 'Trazabilidad de generación y uso de informes.' }
]);

const FILTER_DEFINITIONS = Object.freeze({
  dateFrom: { key: 'dateFrom', label: 'Desde', type: 'date' },
  dateTo: { key: 'dateTo', label: 'Hasta', type: 'date' },
  siteId: { key: 'siteId', label: 'Sede', type: 'site' },
  locationId: { key: 'locationId', label: 'Ubicación', type: 'location' },
  status: { key: 'status', label: 'Estado', type: 'text' },
  categoryId: { key: 'categoryId', label: 'Categoría', type: 'category' },
  search: { key: 'search', label: 'Buscar', type: 'text' }
});

function reportError(message, code = 'REPORT_INVALID', status = 422) {
  return Object.assign(new Error(message), { code, status });
}

function can(user, permission) {
  return Boolean(user && hasPermission(user, permission));
}

function parseDateFilter(value, endOfDay = false) {
  if (!value) return null;
  const text = String(value).trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw reportError('Fecha de filtro inválida.', 'REPORT_FILTER_DATE_INVALID');
  return `${text}T${endOfDay ? '23:59:59.999' : '00:00:00.000'}Z`;
}

function normalizeText(value, max = 120) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim();
  if (!text) return null;
  if (text.length > max) throw reportError('Un filtro supera la longitud permitida.', 'REPORT_FILTER_TOO_LONG');
  return text;
}

function normalizeRequest(input = {}, allowedFilters = []) {
  const rawFilters = input.filters && typeof input.filters === 'object' && !Array.isArray(input.filters) ? input.filters : {};
  const filters = {};
  const allowed = new Set(allowedFilters);
  for (const key of Object.keys(rawFilters)) {
    if (!allowed.has(key)) throw reportError(`Filtro no permitido: ${key}.`, 'REPORT_FILTER_NOT_ALLOWED');
  }
  if (allowed.has('dateFrom')) filters.dateFrom = parseDateFilter(rawFilters.dateFrom, false);
  if (allowed.has('dateTo')) filters.dateTo = parseDateFilter(rawFilters.dateTo, true);
  if (filters.dateFrom && filters.dateTo && filters.dateFrom > filters.dateTo) throw reportError('La fecha desde no puede superar la fecha hasta.', 'REPORT_FILTER_RANGE_INVALID');
  for (const key of ['siteId', 'locationId', 'status', 'categoryId', 'search']) {
    if (allowed.has(key)) filters[key] = normalizeText(rawFilters[key]);
  }
  const page = Math.max(1, Number.parseInt(input.page, 10) || 1);
  const pageSize = Math.min(100, Math.max(1, Number.parseInt(input.pageSize, 10) || 25));
  return { filters, page, pageSize };
}

function addCommonScopeFilters({ where, params, filters, siteColumn, locationColumn }) {
  if (filters.siteId) { where.push(`${siteColumn} = ?`); params.push(filters.siteId); }
  if (filters.locationId) { where.push(`${locationColumn} = ?`); params.push(filters.locationId); }
}

function pagedQuery(db, { selectSql, countSql, params, page, pageSize }) {
  const total = Number(db.prepare(countSql).get(...params)?.total || 0);
  const offset = (page - 1) * pageSize;
  const rows = db.prepare(`${selectSql} LIMIT ? OFFSET ?`).all(...params, pageSize, offset);
  return { rows, total, page, pageSize, pages: Math.max(1, Math.ceil(total / pageSize)) };
}

function requestsByStatus(db, user, request) {
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('r.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('r.created_at <= ?'); params.push(request.filters.dateTo); }
  const sql = `FROM request r WHERE ${where.join(' AND ')} GROUP BY r.status`;
  return pagedQuery(db, {
    selectSql: `SELECT r.status AS status, COUNT(*) AS total, MIN(r.created_at) AS first_created_at, MAX(r.created_at) AS last_created_at ${sql} ORDER BY total DESC, r.status`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT r.status ${sql})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function pagedQuerySeparateParams(db, { selectSql, countSql, selectParams, countParams, page, pageSize }) {
  const total = Number(db.prepare(countSql).get(...countParams)?.total || 0);
  const offset = (page - 1) * pageSize;
  const rows = db.prepare(`${selectSql} LIMIT ? OFFSET ?`).all(...selectParams, pageSize, offset);
  return { rows, total, page, pageSize, pages: Math.max(1, Math.ceil(total / pageSize)) };
}

function activeCustodiesSafe(db, user, request) {
  const scope = scopeWhere(user, 'Custody.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`, "c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')"];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('c.opened_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('c.opened_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('c.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR p.full_name LIKE ? OR r.request_number LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT c.id, r.request_number, a.internal_code, a.description AS asset_description, p.full_name AS custodian, c.quantity, c.opened_at, c.due_at, c.status, CASE WHEN c.due_at IS NOT NULL AND c.due_at < ? THEN 1 ELSE 0 END AS overdue ${from} ${whereSql} ORDER BY COALESCE(c.due_at,'9999-12-31') ASC, c.opened_at ASC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    selectParams: [new Date().toISOString(), ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function assetsByStatus(db, user, request) {
  const scope = scopeWhere(user, 'Assets.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, 'a.deleted_at IS NULL'];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  const sql = `FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE ${where.join(' AND ')} GROUP BY a.status`;
  return pagedQuery(db, {
    selectSql: `SELECT a.status AS status, COUNT(*) AS total, SUM(a.quantity_total) AS quantity_total, SUM(a.quantity_available) AS quantity_available ${sql} ORDER BY total DESC, a.status`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT a.status ${sql})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function openIncidents(db, user, request) {
  const scope = scopeWhere(user, 'Incident.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, "i.status IN ('ABIERTO','EN_INVESTIGACION')"];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('i.opened_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('i.opened_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('i.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    where.push('(i.incident_number LIKE ? OR i.title LIKE ? OR a.internal_code LIKE ? OR a.description LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT i.id, i.incident_number, i.type, i.severity, i.status, i.title, a.internal_code, a.description AS asset_description, i.opened_at, i.assigned_to_user_id ${from} ${whereSql} ORDER BY CASE i.severity WHEN 'CRITICA' THEN 1 WHEN 'ALTA' THEN 2 WHEN 'MEDIA' THEN 3 ELSE 4 END, i.opened_at ASC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function maintenanceByStatusSafe(db, user, request) {
  const scope = scopeWhere(user, 'Maintenance.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('mo.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('mo.created_at <= ?'); params.push(request.filters.dateTo); }
  const groupSql = `FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE ${where.join(' AND ')} GROUP BY mo.status`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT mo.status AS status, COUNT(*) AS total, SUM(CASE WHEN mo.due_at IS NOT NULL AND mo.due_at < ? AND mo.status NOT IN ('COMPLETADA','CANCELADA') THEN 1 ELSE 0 END) AS overdue ${groupSql} ORDER BY total DESC, mo.status`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT mo.status ${groupSql})`,
    selectParams: [new Date().toISOString(), ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}


function overdueRequests(db, user, request) {
  const now = new Date().toISOString();
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [
    `(${scope.sql})`,
    "r.status NOT IN ('BORRADOR','EXPIRADA','CANCELADA','ENTREGADA')",
    'r.needed_at < ?'
  ];
  const params = [...scope.params, now];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('r.needed_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('r.needed_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('r.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    where.push('(r.request_number LIKE ? OR p.full_name LIKE ? OR r.reason LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value);
  }
  const from = 'FROM request r JOIN person p ON p.id=r.requester_person_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT r.id, r.request_number, p.full_name AS requester, r.operation_type, r.status, r.created_at, r.needed_at, ROUND((julianday(?) - julianday(r.needed_at))*24,2) AS delay_hours, r.reason ${from} ${whereSql} ORDER BY r.needed_at ASC, r.created_at ASC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    selectParams: [now, ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function completedHandovers(db, user, request) {
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`, "h.type='ENTREGA'"];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('h.occurred_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('h.occurred_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.search) {
    where.push('(r.request_number LIKE ? OR receiver.full_name LIKE ? OR operator_person.full_name LIKE ? OR h.observations LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = `FROM handover h
    JOIN request r ON r.id=h.request_id
    JOIN person receiver ON receiver.id=h.person_id
    JOIN user_account operator_user ON operator_user.id=h.operator_user_id
    JOIN person operator_person ON operator_person.id=operator_user.person_id
    LEFT JOIN handover_item hi ON hi.handover_id=h.id`;
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT h.id, r.request_number, receiver.full_name AS recipient, operator_person.full_name AS operator, h.occurred_at, COUNT(hi.id) AS item_count, COALESCE(SUM(hi.quantity),0) AS total_quantity, h.acceptance_method, h.observations ${from} ${whereSql} GROUP BY h.id ORDER BY h.occurred_at DESC`,
    countSql: `SELECT COUNT(DISTINCT h.id) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function overdueCustodies(db, user, request) {
  const now = new Date().toISOString();
  const scope = scopeWhere(user, 'Custody.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [
    `(${scope.sql})`,
    "c.status IN ('ABIERTA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')",
    'c.due_at IS NOT NULL',
    'c.due_at < ?'
  ];
  const params = [...scope.params, now];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('c.due_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('c.due_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('c.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR p.full_name LIKE ? OR r.request_number LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT c.id, r.request_number, a.internal_code, a.description AS asset_description, p.full_name AS custodian, c.quantity, c.opened_at, c.due_at, c.status, ROUND((julianday(?) - julianday(c.due_at))*24,2) AS overdue_hours ${from} ${whereSql} ORDER BY c.due_at ASC, c.opened_at ASC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    selectParams: [now, ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function custodyReturns(db, user, request, lateOnly = false) {
  const scope = scopeWhere(user, 'Custody.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  if (lateOnly) where.push("crr.timing_status='FUERA_DE_TERMINO'");
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('crr.received_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('crr.received_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) {
    const value = request.filters.status.toUpperCase();
    where.push('(crr.timing_status = ? OR crr.condition = ?)');
    params.push(value, value);
  }
  if (request.filters.search) {
    where.push('(r.request_number LIKE ? OR a.internal_code LIKE ? OR a.description LIKE ? OR p.full_name LIKE ? OR crr.notes LIKE ? OR crd.notes LIKE ? OR rvw.operator_comment LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value, value, value, value);
  }
  const from = `FROM custody_return_record crr
    JOIN custody c ON c.id=crr.custody_id
    JOIN request r ON r.id=c.request_id
    JOIN asset a ON a.id=c.asset_id
    JOIN person p ON p.id=c.person_id
    LEFT JOIN custody_return_declaration crd ON crd.custody_id=c.id
    LEFT JOIN custody_reception_review rvw ON rvw.custody_id=c.id
    LEFT JOIN incident i ON i.id=crr.incident_id`;
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT crr.id, r.request_number, a.internal_code, a.description AS asset_description, p.full_name AS custodian, crr.due_at_snapshot, crr.received_at, crr.timing_status, ROUND(crr.overdue_seconds/3600.0,2) AS overdue_hours, crr.condition, i.incident_number, crd.notes AS technician_comment, rvw.operator_comment AS warehouse_comment, rvw.source_mode AS review_source, rvw.comment_forced_observation, rvw.blocked_after_receipt, crr.notes AS legacy_reception_note ${from} ${whereSql} ORDER BY crr.received_at DESC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function completedCustodyReturns(db, user, request) {
  return custodyReturns(db, user, request, false);
}

function lateCustodyReturns(db, user, request) {
  return custodyReturns(db, user, request, true);
}

function blockedAssets(db, user, request) {
  const scope = scopeWhere(user, 'Assets.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, 'a.deleted_at IS NULL', 'a.active=1', "a.status='BLOQUEADO'"];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR ac.name LIKE ? OR sl.name LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT a.id, a.internal_code, a.description AS asset_description, ac.name AS category, sl.name AS location,
      (SELECT ob.block_number FROM operational_block ob WHERE ob.target_type='ACTIVO' AND ob.target_id=a.id AND ob.status='ACTIVO' ORDER BY ob.starts_at DESC LIMIT 1) AS block_number,
      (SELECT ob.reason FROM operational_block ob WHERE ob.target_type='ACTIVO' AND ob.target_id=a.id AND ob.status='ACTIVO' ORDER BY ob.starts_at DESC LIMIT 1) AS block_reason,
      (SELECT ob.severity FROM operational_block ob WHERE ob.target_type='ACTIVO' AND ob.target_id=a.id AND ob.status='ACTIVO' ORDER BY ob.starts_at DESC LIMIT 1) AS block_severity,
      (SELECT i.incident_number FROM incident i WHERE i.asset_id=a.id AND i.status IN ('ABIERTO','EN_INVESTIGACION') ORDER BY i.opened_at DESC LIMIT 1) AS incident_number,
      a.updated_at ${from} ${whereSql} ORDER BY COALESCE(block_severity,'MEDIA') DESC, a.internal_code`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function unavailableStock(db, user, request) {
  const scope = scopeWhere(user, 'Stock.Read', 'sl.site_id', 'sl.id', db);
  const where = [
    `(${scope.sql})`,
    'lot.active=1',
    'a.active=1',
    'a.deleted_at IS NULL',
    "ac.nature IN ('CANTIDAD','CONSUMIBLE')",
    '(lot.quantity_on_hand-lot.quantity_reserved)<=0'
  ];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'sl.id' });
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR lot.lot_code LIKE ? OR sl.name LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM stock_lot lot JOIN asset a ON a.id=lot.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=lot.location_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT lot.id, a.internal_code, a.description AS asset_description, ac.name AS category, sl.name AS location, lot.lot_code, lot.quantity_on_hand, lot.quantity_reserved, (lot.quantity_on_hand-lot.quantity_reserved) AS quantity_available, lot.expires_at, lot.updated_at ${from} ${whereSql} ORDER BY quantity_available ASC, a.internal_code, lot.lot_code`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function executionHistory(db, user, request) {
  const where = ['1=1'];
  const params = [];
  if (!can(user, '*') && !can(user, 'Reports.Audit')) {
    where.push('re.generated_by_user_id = ?');
    params.push(user.id);
  }
  if (request.filters.dateFrom) { where.push('re.generated_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('re.generated_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.search) {
    where.push('(re.report_code LIKE ? OR re.report_name LIKE ? OR p.full_name LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value);
  }
  const from = 'FROM report_execution re JOIN user_account ua ON ua.id=re.generated_by_user_id JOIN person p ON p.id=ua.person_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT re.id, re.report_code, re.report_name, re.category, p.full_name AS generated_by, re.generated_at, re.row_count, re.total_count, re.status, re.duration_ms ${from} ${whereSql} ORDER BY re.generated_at DESC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}


function auditActorIdentity(db, actorUserId, cache) {
  const key = actorUserId || '__SYSTEM__';
  if (cache.has(key)) return cache.get(key);
  if (!actorUserId) {
    const value = { actor: 'Sistema / anónimo', username: '—' };
    cache.set(key, value);
    return value;
  }
  const row = db.prepare(`SELECT COALESCE(p.full_name,'Sistema / anónimo') AS actor, COALESCE(ua.username,'—') AS username
    FROM user_account ua LEFT JOIN person p ON p.id=ua.person_id WHERE ua.id=?`).get(actorUserId);
  const value = row || { actor: 'Usuario no disponible', username: '—' };
  cache.set(key, value);
  return value;
}

function auditRequestFilters(request) {
  return {
    from: request.filters.dateFrom || undefined,
    to: request.filters.dateTo || undefined,
    result: request.filters.status ? request.filters.status.toUpperCase() : undefined,
    includeArchived: true
  };
}

function auditTextMatches(row, identity, search) {
  if (!search) return true;
  const needle = String(search).toLowerCase();
  return [
    row.action, row.entity_type, row.entity_id, row.reason, row.error, row.correlation_id,
    row.before_json, row.after_json, identity.actor, identity.username
  ].some((value) => String(value || '').toLowerCase().includes(needle));
}

function pageArray(rows, request) {
  const total = rows.length;
  const offset = (request.page - 1) * request.pageSize;
  return {
    rows: rows.slice(offset, offset + request.pageSize),
    total,
    page: request.page,
    pageSize: request.pageSize,
    pages: Math.max(1, Math.ceil(total / request.pageSize))
  };
}

function auditActionsByUser(db, user, request) {
  const actorCache = new Map();
  const groups = new Map();
  for (const row of iterateAuditRows(auditRequestFilters(request), { db, order: 'DESC' })) {
    const identity = auditActorIdentity(db, row.actor_user_id, actorCache);
    if (!auditTextMatches(row, identity, request.filters.search)) continue;
    const key = `${row.actor_user_id || ''}\u0000${row.action || ''}`;
    const current = groups.get(key) || {
      actor_user_id: row.actor_user_id || null,
      actor: identity.actor,
      username: identity.username,
      action: row.action,
      total_actions: 0,
      successful: 0,
      denied: 0,
      failed: 0,
      last_action_at: row.occurred_at
    };
    current.total_actions += 1;
    if (row.result === 'SUCCESS') current.successful += 1;
    else if (row.result === 'DENIED') current.denied += 1;
    else current.failed += 1;
    if (!current.last_action_at || row.occurred_at > current.last_action_at) current.last_action_at = row.occurred_at;
    groups.set(key, current);
  }
  const rows = [...groups.values()].sort((a, b) =>
    b.total_actions - a.total_actions || String(b.last_action_at).localeCompare(String(a.last_action_at)) ||
    String(a.actor).localeCompare(String(b.actor)) || String(a.action).localeCompare(String(b.action))
  );
  return pageArray(rows, request);
}

function auditEventDetail(db, request, predicate) {
  const actorCache = new Map();
  const rows = [];
  for (const row of iterateAuditRows(auditRequestFilters(request), { db, order: 'DESC' })) {
    if (!predicate(row)) continue;
    const identity = auditActorIdentity(db, row.actor_user_id, actorCache);
    if (!auditTextMatches(row, identity, request.filters.search)) continue;
    rows.push({
      id: row.id,
      actor: identity.actor,
      username: identity.username,
      action: row.action,
      entity_type: row.entity_type,
      entity_id: row.entity_id,
      before_snapshot: String(row.before_json || '').slice(0, 500),
      after_snapshot: String(row.after_json || '').slice(0, 500),
      reason: row.reason,
      result: row.result,
      error: row.error,
      source: row.source,
      ip_address: row.ip_address,
      equipment: row.equipment,
      occurred_at: row.occurred_at,
      correlation_id: row.correlation_id,
      evidence_hash: row.evidence_hash,
      archived: Boolean(row.archived),
      archive_segment_id: row.archive_segment_id || null
    });
  }
  return pageArray(rows, request);
}

function actionStartsWith(row, prefixes) {
  const action = String(row.action || '');
  return prefixes.some((prefix) => action.startsWith(prefix));
}

function auditCriticalChanges(db, user, request) {
  return auditEventDetail(db, request, (row) => actionStartsWith(row, [
    'ROLE.', 'USER.', 'CONFIG.', 'SITE.', 'LOCATION.', 'REQUEST_POLICY.', 'SCHEDULER.JOB_UPDATE',
    'BACKUP.RESTORE', 'SECURITY.', 'ASSET.DELETE', 'STOCK.ADJUST'
  ]));
}

function auditPermissionChanges(db, user, request) {
  return auditEventDetail(db, request, (row) => ['ROLE.CREATE', 'ROLE.UPDATE', 'USER.PERMISSION_OVERRIDES_UPDATE'].includes(row.action));
}

function auditConfigurationChanges(db, user, request) {
  return auditEventDetail(db, request, (row) => actionStartsWith(row, [
    'CONFIG.', 'SITE.', 'LOCATION.', 'REQUEST_POLICY.', 'ASSET_CATEGORY.'
  ]) || ['SCHEDULER.JOB_UPDATE', 'PORTAL_QR.REGENERATE'].includes(row.action));
}

function auditDeniedAttempts(db, user, request) {
  return auditEventDetail(db, request, (row) => ['DENIED', 'FAILED'].includes(row.result) || Boolean(row.error));
}

function auditReportExports(db, user, request) {
  const where = ['1=1'];
  const params = [];
  if (request.filters.dateFrom) { where.push('rex.generated_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('rex.generated_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('rex.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    where.push('(rex.report_code LIKE ? OR rex.report_name LIKE ? OR rex.filename LIKE ? OR rex.format LIKE ? OR ua.username LIKE ? OR p.full_name LIKE ? OR rex.sha256 LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value, value, value, value);
  }
  const from = 'FROM report_export rex JOIN user_account ua ON ua.id=rex.generated_by_user_id JOIN person p ON p.id=ua.person_id';
  const whereSql = `WHERE ${where.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT rex.id, rex.report_code, rex.report_name, rex.format, rex.filename, rex.row_count, rex.byte_size,
      rex.sha256, p.full_name AS generated_by, ua.username, rex.generated_at, rex.status, rex.duration_ms,
      rex.error_code, rex.correlation_id ${from} ${whereSql} ORDER BY rex.generated_at DESC`,
    countSql: `SELECT COUNT(*) AS total ${from} ${whereSql}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function auditStatusChanges(db, user, request) {
  function scoped(permission, siteColumn, locationColumn) {
    const scope = scopeWhere(user, permission, siteColumn, locationColumn, db);
    const where = [`(${scope.sql})`];
    const params = [...scope.params];
    addCommonScopeFilters({ where, params, filters: request.filters, siteColumn, locationColumn });
    return { sql: where.join(' AND '), params };
  }
  const requestScope = scoped('Audit.Read', 'r.site_id', 'r.location_id');
  const custodyScope = scoped('Audit.Read', 'r.site_id', 'r.location_id');
  const incidentScope = scoped('Audit.Read', 'sl.site_id', 'a.location_id');
  const maintenanceScope = scoped('Audit.Read', 'sl.site_id', 'a.location_id');
  const union = `
    SELECT 'SOLICITUD' AS event_source, r.request_number AS reference, r.id AS entity_id, rse.from_status, rse.to_status,
      COALESCE(p.full_name,ua.username,'Sistema') AS actor, rse.reason, rse.occurred_at, rse.correlation_id, r.site_id, r.location_id
      FROM request_status_event rse JOIN request r ON r.id=rse.request_id
      LEFT JOIN user_account ua ON ua.id=rse.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      WHERE ${requestScope.sql}
    UNION ALL
    SELECT 'CUSTODIA', r.request_number || ' · ' || a.internal_code, c.id, ce.from_status, ce.to_status,
      COALESCE(p.full_name,ua.username,'Sistema'), ce.reason, ce.occurred_at, ce.correlation_id, r.site_id, r.location_id
      FROM custody_event ce JOIN custody c ON c.id=ce.custody_id JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id
      LEFT JOIN user_account ua ON ua.id=ce.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      WHERE ${custodyScope.sql}
    UNION ALL
    SELECT 'INCIDENTE', i.incident_number, i.id, ie.from_status, ie.to_status,
      COALESCE(p.full_name,ua.username,'Sistema'), ie.details, ie.occurred_at, ie.correlation_id, sl.site_id, a.location_id
      FROM incident_event ie JOIN incident i ON i.id=ie.incident_id JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id
      LEFT JOIN user_account ua ON ua.id=ie.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      WHERE ie.event_type IN ('CAMBIO_ESTADO','RESOLUCION','CIERRE','REAPERTURA','APERTURA') AND ${incidentScope.sql}
    UNION ALL
    SELECT 'MANTENIMIENTO', mo.order_number, mo.id, me.from_status, me.to_status,
      COALESCE(p.full_name,ua.username,'Sistema'), me.reason, me.occurred_at, me.correlation_id, sl.site_id, a.location_id
      FROM maintenance_event me JOIN maintenance_order mo ON mo.id=me.order_id JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id
      LEFT JOIN user_account ua ON ua.id=me.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      WHERE ${maintenanceScope.sql}`;
  const outer = ['1=1'];
  const outerParams = [];
  if (request.filters.dateFrom) { outer.push('ev.occurred_at >= ?'); outerParams.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { outer.push('ev.occurred_at <= ?'); outerParams.push(request.filters.dateTo); }
  if (request.filters.status) { outer.push('ev.to_status = ?'); outerParams.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    outer.push('(ev.event_source LIKE ? OR ev.reference LIKE ? OR ev.actor LIKE ? OR ev.reason LIKE ? OR ev.correlation_id LIKE ?)');
    const value = `%${request.filters.search}%`;
    outerParams.push(value, value, value, value, value);
  }
  const params = [...requestScope.params, ...custodyScope.params, ...incidentScope.params, ...maintenanceScope.params, ...outerParams];
  const from = `FROM (${union}) ev WHERE ${outer.join(' AND ')}`;
  return pagedQuery(db, {
    selectSql: `SELECT ev.event_source,ev.reference,ev.entity_id,ev.from_status,ev.to_status,ev.actor,ev.reason,ev.occurred_at,ev.correlation_id ${from}
      ORDER BY ev.occurred_at DESC, ev.reference`,
    countSql: `SELECT COUNT(*) AS total ${from}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function auditRequestTrace(db, user, request) {
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const baseWhere = [`(${scope.sql})`];
  const baseParams = [...scope.params];
  addCommonScopeFilters({ where: baseWhere, params: baseParams, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  const cte = `WITH scoped_requests AS (
    SELECT r.id,r.request_number,r.site_id,r.location_id FROM request r WHERE ${baseWhere.join(' AND ')}
  )`;
  const union = `
    SELECT sr.id AS request_id,sr.request_number,'ESTADO_SOLICITUD' AS event_type,rse.from_status,rse.to_status,
      COALESCE(p.full_name,ua.username,'Sistema') AS actor,rse.reason AS detail,rse.occurred_at,rse.correlation_id,
      'request_status_event' AS related_entity_type,rse.id AS related_entity_id
      FROM scoped_requests sr JOIN request_status_event rse ON rse.request_id=sr.id
      LEFT JOIN user_account ua ON ua.id=rse.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
    UNION ALL
    SELECT sr.id,sr.request_number,'APROBACION',NULL,ap.decision,COALESCE(p.full_name,ua.username,'Sistema'),ap.reason,ap.decided_at,ap.correlation_id,'approval',ap.id
      FROM scoped_requests sr JOIN approval ap ON ap.request_id=sr.id
      LEFT JOIN user_account ua ON ua.id=ap.approver_user_id LEFT JOIN person p ON p.id=ua.person_id
    UNION ALL
    SELECT sr.id,sr.request_number,'MOVIMIENTO_' || h.type,NULL,h.type,COALESCE(p.full_name,ua.username,'Sistema'),h.observations,h.occurred_at,h.correlation_id,'handover',h.id
      FROM scoped_requests sr JOIN handover h ON h.request_id=sr.id
      LEFT JOIN user_account ua ON ua.id=h.operator_user_id LEFT JOIN person p ON p.id=ua.person_id
    UNION ALL
    SELECT sr.id,sr.request_number,'ESTADO_CUSTODIA',ce.from_status,ce.to_status,COALESCE(p.full_name,ua.username,'Sistema'),ce.reason,ce.occurred_at,ce.correlation_id,'custody',c.id
      FROM scoped_requests sr JOIN custody c ON c.request_id=sr.id JOIN custody_event ce ON ce.custody_id=c.id
      LEFT JOIN user_account ua ON ua.id=ce.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
    UNION ALL
    SELECT sr.id,sr.request_number,'INCIDENTE_' || ie.event_type,ie.from_status,ie.to_status,COALESCE(p.full_name,ua.username,'Sistema'),ie.details,ie.occurred_at,ie.correlation_id,'incident',i.id
      FROM scoped_requests sr JOIN custody c ON c.request_id=sr.id JOIN incident i ON i.custody_id=c.id JOIN incident_event ie ON ie.incident_id=i.id
      LEFT JOIN user_account ua ON ua.id=ie.actor_user_id LEFT JOIN person p ON p.id=ua.person_id`;
  const outer = ['1=1'];
  const outerParams = [];
  if (request.filters.dateFrom) { outer.push('ev.occurred_at >= ?'); outerParams.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { outer.push('ev.occurred_at <= ?'); outerParams.push(request.filters.dateTo); }
  if (request.filters.status) { outer.push('ev.to_status = ?'); outerParams.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) {
    outer.push('(ev.request_number LIKE ? OR ev.event_type LIKE ? OR ev.actor LIKE ? OR ev.detail LIKE ? OR ev.correlation_id LIKE ? OR ev.related_entity_id LIKE ?)');
    const value = `%${request.filters.search}%`;
    outerParams.push(value, value, value, value, value, value);
  }
  const from = `FROM (${union}) ev WHERE ${outer.join(' AND ')}`;
  const params = [...baseParams, ...outerParams];
  return pagedQuery(db, {
    selectSql: `${cte} SELECT ev.request_number,ev.event_type,ev.from_status,ev.to_status,ev.actor,ev.detail,ev.occurred_at,ev.correlation_id,ev.related_entity_type,ev.related_entity_id ${from}
      ORDER BY ev.request_number,ev.occurred_at ASC`,
    countSql: `${cte} SELECT COUNT(*) AS total ${from}`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function auditAssetTrace(db, user, request) {
  const scope = scopeWhere(user, 'Assets.Read', 'sl.site_id', 'a.location_id', db);
  const baseWhere = [`(${scope.sql})`, 'a.deleted_at IS NULL'];
  const baseParams = [...scope.params];
  addCommonScopeFilters({ where: baseWhere, params: baseParams, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.categoryId) { baseWhere.push('a.category_id = ?'); baseParams.push(request.filters.categoryId); }

  const scopedAssets = db.prepare(`SELECT a.id,a.internal_code,a.description,ac.name AS category
    FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE ${baseWhere.join(' AND ')}`).all(...baseParams);
  const scopedAssetMap = new Map(scopedAssets.map((row) => [row.id, row]));
  const archiveTable = `temp_audit_asset_archive_${randomUUID().replaceAll('-', '')}`;
  db.exec(`CREATE TEMP TABLE ${archiveTable}(
    asset_id TEXT NOT NULL, internal_code TEXT, asset_description TEXT, category TEXT, event_type TEXT,
    from_status TEXT, to_status TEXT, actor TEXT, detail TEXT, occurred_at TEXT, correlation_id TEXT,
    related_entity_type TEXT, related_entity_id TEXT
  )`);
  try {
    const actorCache = new Map();
    const insertArchive = db.prepare(`INSERT INTO ${archiveTable}(
      asset_id,internal_code,asset_description,category,event_type,from_status,to_status,actor,detail,
      occurred_at,correlation_id,related_entity_type,related_entity_id
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    const archiveFilters = {
      entityType: 'asset',
      from: request.filters.dateFrom || undefined,
      to: request.filters.dateTo || undefined,
      includeArchived: true
    };
    for (const event of iterateAuditRows(archiveFilters, { db, order: 'ASC', live: false })) {
      const asset = scopedAssetMap.get(event.entity_id);
      if (!asset) continue;
      const identity = auditActorIdentity(db, event.actor_user_id, actorCache);
      const detail = event.reason || event.error || String(event.after_json || '').slice(0, 300) || null;
      insertArchive.run(
        asset.id, asset.internal_code, asset.description, asset.category, event.action,
        event.before?.status || null, event.after?.status || null, identity.actor, detail,
        event.occurred_at, event.correlation_id, event.entity_type, event.entity_id
      );
    }

    const cte = `WITH scoped_assets AS (
      SELECT a.id,a.internal_code,a.description,ac.name AS category,a.location_id,sl.site_id
        FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
        WHERE ${baseWhere.join(' AND ')}
    )`;
    const union = `
      SELECT sa.id AS asset_id,sa.internal_code,sa.description AS asset_description,sa.category,ae.action AS event_type,
        json_extract(ae.before_json,'$.status') AS from_status,json_extract(ae.after_json,'$.status') AS to_status,
        COALESCE(p.full_name,ua.username,'Sistema') AS actor,COALESCE(ae.reason,ae.error,substr(ae.after_json,1,300)) AS detail,
        ae.occurred_at,ae.correlation_id,ae.entity_type AS related_entity_type,ae.entity_id AS related_entity_id
        FROM scoped_assets sa JOIN audit_event ae ON ae.entity_type='asset' AND ae.entity_id=sa.id
        LEFT JOIN user_account ua ON ua.id=ae.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT asset_id,internal_code,asset_description,category,event_type,from_status,to_status,actor,detail,
        occurred_at,correlation_id,related_entity_type,related_entity_id FROM ${archiveTable}
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'MOVIMIENTO_' || h.type,NULL,hi.condition,
        COALESCE(p.full_name,ua.username,'Sistema'),'Cantidad ' || hi.quantity || COALESCE(' · ' || hi.notes,''),h.occurred_at,h.correlation_id,'handover',h.id
        FROM scoped_assets sa JOIN handover_item hi ON hi.asset_id=sa.id JOIN handover h ON h.id=hi.handover_id
        LEFT JOIN user_account ua ON ua.id=h.operator_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'ESTADO_CUSTODIA',ce.from_status,ce.to_status,
        COALESCE(p.full_name,ua.username,'Sistema'),ce.reason,ce.occurred_at,ce.correlation_id,'custody',c.id
        FROM scoped_assets sa JOIN custody c ON c.asset_id=sa.id JOIN custody_event ce ON ce.custody_id=c.id
        LEFT JOIN user_account ua ON ua.id=ce.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'INCIDENTE_' || ie.event_type,ie.from_status,ie.to_status,
        COALESCE(p.full_name,ua.username,'Sistema'),ie.details,ie.occurred_at,ie.correlation_id,'incident',i.id
        FROM scoped_assets sa JOIN incident i ON i.asset_id=sa.id JOIN incident_event ie ON ie.incident_id=i.id
        LEFT JOIN user_account ua ON ua.id=ie.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'MANTENIMIENTO',me.from_status,me.to_status,
        COALESCE(p.full_name,ua.username,'Sistema'),me.reason,me.occurred_at,me.correlation_id,'maintenance_order',mo.id
        FROM scoped_assets sa JOIN maintenance_order mo ON mo.asset_id=sa.id JOIN maintenance_event me ON me.order_id=mo.id
        LEFT JOIN user_account ua ON ua.id=me.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'STOCK_' || sm.movement_type,CAST(sm.quantity_before AS TEXT),CAST(sm.quantity_after AS TEXT),
        COALESCE(p.full_name,ua.username,'Sistema'),sm.reason || ' · Cantidad ' || sm.quantity,sm.occurred_at,sm.correlation_id,'stock_movement',sm.id
        FROM scoped_assets sa JOIN stock_movement sm ON sm.asset_id=sa.id
        LEFT JOIN user_account ua ON ua.id=sm.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      UNION ALL
      SELECT sa.id,sa.internal_code,sa.description,sa.category,'INSPECCION_' || ins.phase,NULL,ins.result,
        COALESCE(p.full_name,ua.username,'Sistema'),ins.condition || COALESCE(' · ' || ins.notes,''),ins.occurred_at,NULL,'inspection',ins.id
        FROM scoped_assets sa JOIN inspection ins ON ins.asset_id=sa.id
        LEFT JOIN user_account ua ON ua.id=ins.inspector_user_id LEFT JOIN person p ON p.id=ua.person_id`;
    const outer = ['1=1'];
    const outerParams = [];
    if (request.filters.dateFrom) { outer.push('ev.occurred_at >= ?'); outerParams.push(request.filters.dateFrom); }
    if (request.filters.dateTo) { outer.push('ev.occurred_at <= ?'); outerParams.push(request.filters.dateTo); }
    if (request.filters.status) { outer.push('ev.to_status = ?'); outerParams.push(request.filters.status.toUpperCase()); }
    if (request.filters.search) {
      outer.push('(ev.internal_code LIKE ? OR ev.asset_description LIKE ? OR ev.category LIKE ? OR ev.event_type LIKE ? OR ev.actor LIKE ? OR ev.detail LIKE ? OR ev.related_entity_id LIKE ?)');
      const value = `%${request.filters.search}%`;
      outerParams.push(value, value, value, value, value, value, value);
    }
    const from = `FROM (${union}) ev WHERE ${outer.join(' AND ')}`;
    const params = [...baseParams, ...outerParams];
    return pagedQuery(db, {
      selectSql: `${cte} SELECT ev.internal_code,ev.asset_description,ev.category,ev.event_type,ev.from_status,ev.to_status,ev.actor,ev.detail,ev.occurred_at,ev.correlation_id,ev.related_entity_type,ev.related_entity_id ${from}
        ORDER BY ev.internal_code,ev.occurred_at ASC`,
      countSql: `${cte} SELECT COUNT(*) AS total ${from}`,
      params,
      page: request.page,
      pageSize: request.pageSize
    });
  } finally {
    db.exec(`DROP TABLE IF EXISTS ${archiveTable}`);
  }
}

function managementRequestTrend(db, user, request) {
  const now = new Date().toISOString();
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('r.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('r.created_at <= ?'); params.push(request.filters.dateTo); }
  const grouped = `FROM request r WHERE ${where.join(' AND ')} GROUP BY substr(r.created_at,1,7)`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT substr(r.created_at,1,7) AS period, COUNT(*) AS total_requests,
      SUM(CASE WHEN r.status='ENTREGADA' THEN 1 ELSE 0 END) AS delivered,
      SUM(CASE WHEN r.status='CANCELADA' THEN 1 ELSE 0 END) AS cancelled,
      SUM(CASE WHEN r.approval_required=1 THEN 1 ELSE 0 END) AS approval_required,
      SUM(CASE WHEN r.needed_at < ? AND r.status NOT IN ('BORRADOR','EXPIRADA','CANCELADA','ENTREGADA') THEN 1 ELSE 0 END) AS delayed
      ${grouped} ORDER BY period ASC`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT substr(r.created_at,1,7) AS period ${grouped})`,
    selectParams: [now, ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementServiceTimes(db, user, request) {
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('r.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('r.created_at <= ?'); params.push(request.filters.dateTo); }
  const from = `FROM request r
    LEFT JOIN (SELECT request_id,MIN(decided_at) AS decided_at FROM approval GROUP BY request_id) ap ON ap.request_id=r.id
    LEFT JOIN (SELECT request_id,MIN(occurred_at) AS delivered_at FROM handover WHERE type='ENTREGA' GROUP BY request_id) hd ON hd.request_id=r.id`;
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY substr(r.created_at,1,7)`;
  return pagedQuery(db, {
    selectSql: `SELECT substr(r.created_at,1,7) AS period, COUNT(*) AS total_requests,
      SUM(CASE WHEN ap.decided_at IS NOT NULL THEN 1 ELSE 0 END) AS approval_samples,
      ROUND(AVG(CASE WHEN ap.decided_at IS NOT NULL THEN (julianday(ap.decided_at)-julianday(r.created_at))*24 END),2) AS avg_approval_hours,
      SUM(CASE WHEN hd.delivered_at IS NOT NULL THEN 1 ELSE 0 END) AS delivery_samples,
      ROUND(AVG(CASE WHEN hd.delivered_at IS NOT NULL THEN (julianday(hd.delivered_at)-julianday(r.created_at))*24 END),2) AS avg_delivery_hours
      ${grouped} ORDER BY period ASC`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT substr(r.created_at,1,7) AS period ${grouped})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementAssetRotation(db, user, request) {
  const scope = scopeWhere(user, 'Assets.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, "h.type='ENTREGA'", 'a.deleted_at IS NULL'];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('h.occurred_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('h.occurred_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR ac.name LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value);
  }
  const from = `FROM handover_item hi
    JOIN handover h ON h.id=hi.handover_id
    JOIN asset a ON a.id=hi.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id
    LEFT JOIN custody c ON c.request_item_id=hi.request_item_id
    LEFT JOIN custody_return_record crr ON crr.custody_id=c.id`;
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY a.id`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT a.id, a.internal_code, a.description AS asset_description, ac.name AS category,
      COUNT(DISTINCT h.id) AS delivery_count, ROUND(COALESCE(SUM(hi.quantity),0),2) AS quantity_delivered,
      ROUND(COALESCE(SUM(CASE WHEN c.id IS NOT NULL THEN (julianday(COALESCE(c.closed_at,?))-julianday(c.opened_at))*24 ELSE 0 END),0),2) AS custody_hours,
      SUM(CASE WHEN crr.timing_status='FUERA_DE_TERMINO' THEN 1 ELSE 0 END) AS late_returns,
      MAX(h.occurred_at) AS last_delivery_at
      ${grouped} ORDER BY delivery_count DESC, quantity_delivered DESC, a.internal_code`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT a.id ${grouped})`,
    selectParams: [new Date().toISOString(), ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementReturnCompliance(db, user, request) {
  const scope = scopeWhere(user, 'Custody.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('crr.received_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('crr.received_at <= ?'); params.push(request.filters.dateTo); }
  const from = 'FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id';
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY substr(crr.received_at,1,7)`;
  return pagedQuery(db, {
    selectSql: `SELECT substr(crr.received_at,1,7) AS period, COUNT(*) AS total_returns,
      SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END) AS on_time,
      SUM(CASE WHEN crr.timing_status='FUERA_DE_TERMINO' THEN 1 ELSE 0 END) AS late,
      SUM(CASE WHEN crr.timing_status='SIN_VENCIMIENTO' THEN 1 ELSE 0 END) AS without_due,
      ROUND(100.0*SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END)/NULLIF(SUM(CASE WHEN crr.timing_status IN ('EN_TERMINO','FUERA_DE_TERMINO') THEN 1 ELSE 0 END),0),2) AS compliance_percent,
      ROUND(AVG(CASE WHEN crr.timing_status='FUERA_DE_TERMINO' THEN crr.overdue_seconds/3600.0 END),2) AS avg_late_hours
      ${grouped} ORDER BY period ASC`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT substr(crr.received_at,1,7) AS period ${grouped})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementActivityBySector(db, user, request) {
  const now = new Date().toISOString();
  const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'r.site_id', locationColumn: 'r.location_id' });
  if (request.filters.dateFrom) { where.push('r.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('r.created_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.search) {
    where.push("(COALESCE(p.sector,'SIN SECTOR') LIKE ? OR p.full_name LIKE ?)");
    const value = `%${request.filters.search}%`;
    params.push(value, value);
  }
  const from = 'FROM request r JOIN person p ON p.id=r.requester_person_id LEFT JOIN request_item ri ON ri.request_id=r.id';
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY COALESCE(NULLIF(TRIM(p.sector),''),'SIN SECTOR')`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT COALESCE(NULLIF(TRIM(p.sector),''),'SIN SECTOR') AS sector,
      COUNT(DISTINCT r.id) AS total_requests,
      COUNT(DISTINCT CASE WHEN r.status='ENTREGADA' THEN r.id END) AS delivered,
      COUNT(DISTINCT CASE WHEN r.needed_at < ? AND r.status NOT IN ('BORRADOR','EXPIRADA','CANCELADA','ENTREGADA') THEN r.id END) AS delayed,
      ROUND(COALESCE(SUM(ri.quantity),0),2) AS requested_quantity,
      COUNT(DISTINCT r.requester_person_id) AS active_requesters
      ${grouped} ORDER BY total_requests DESC, sector`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT COALESCE(NULLIF(TRIM(p.sector),''),'SIN SECTOR') AS sector ${grouped})`,
    selectParams: [now, ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementIncidentRecurrence(db, user, request) {
  const scope = scopeWhere(user, 'Incident.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, 'a.deleted_at IS NULL'];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('i.opened_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('i.opened_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('i.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  if (request.filters.search) {
    where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR ac.name LIKE ? OR i.title LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value, value, value);
  }
  const from = 'FROM incident i JOIN asset a ON a.id=i.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id';
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY a.id`;
  return pagedQuery(db, {
    selectSql: `SELECT a.id, a.internal_code, a.description AS asset_description, ac.name AS category,
      COUNT(*) AS incident_count,
      SUM(CASE WHEN i.status IN ('ABIERTO','EN_INVESTIGACION') THEN 1 ELSE 0 END) AS open_count,
      SUM(CASE WHEN i.severity='CRITICA' THEN 1 ELSE 0 END) AS critical_count,
      ROUND(COALESCE(SUM(i.actual_cost),0),2) AS actual_cost,
      MAX(i.opened_at) AS last_incident_at
      ${grouped} ORDER BY incident_count DESC, critical_count DESC, a.internal_code`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT a.id ${grouped})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementMaintenancePerformance(db, user, request) {
  const now = new Date().toISOString();
  const scope = scopeWhere(user, 'Maintenance.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('mo.created_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('mo.created_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('mo.status = ?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  const from = 'FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id';
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY substr(mo.created_at,1,7)`;
  return pagedQuerySeparateParams(db, {
    selectSql: `SELECT substr(mo.created_at,1,7) AS period, COUNT(*) AS total_orders,
      SUM(CASE WHEN mo.status='COMPLETADA' THEN 1 ELSE 0 END) AS completed,
      SUM(CASE WHEN mo.status='VENCIDA' OR (mo.due_at IS NOT NULL AND mo.due_at < ? AND mo.status NOT IN ('COMPLETADA','CANCELADA')) THEN 1 ELSE 0 END) AS overdue,
      SUM(CASE WHEN mo.status='EN_PROGRESO' THEN 1 ELSE 0 END) AS in_progress,
      ROUND(AVG(CASE WHEN mo.completed_at IS NOT NULL THEN (julianday(mo.completed_at)-julianday(COALESCE(mo.started_at,mo.created_at)))*24 END),2) AS avg_cycle_hours
      ${grouped} ORDER BY period ASC`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT substr(mo.created_at,1,7) AS period ${grouped})`,
    selectParams: [now, ...params],
    countParams: params,
    page: request.page,
    pageSize: request.pageSize
  });
}

function managementCategoryUtilization(db, user, request) {
  const scope = scopeWhere(user, 'Assets.Read', 'sl.site_id', 'a.location_id', db);
  const where = [`(${scope.sql})`, "h.type='ENTREGA'", 'a.deleted_at IS NULL'];
  const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'sl.site_id', locationColumn: 'a.location_id' });
  if (request.filters.dateFrom) { where.push('h.occurred_at >= ?'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('h.occurred_at <= ?'); params.push(request.filters.dateTo); }
  if (request.filters.categoryId) { where.push('a.category_id = ?'); params.push(request.filters.categoryId); }
  if (request.filters.search) {
    where.push('(ac.code LIKE ? OR ac.name LIKE ?)');
    const value = `%${request.filters.search}%`;
    params.push(value, value);
  }
  const from = 'FROM handover_item hi JOIN handover h ON h.id=hi.handover_id JOIN asset a ON a.id=hi.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id';
  const grouped = `${from} WHERE ${where.join(' AND ')} GROUP BY ac.id`;
  return pagedQuery(db, {
    selectSql: `SELECT ac.id, ac.code AS category_code, ac.name AS category,
      COUNT(DISTINCT a.id) AS assets_used, COUNT(DISTINCT h.id) AS delivery_count,
      ROUND(COALESCE(SUM(hi.quantity),0),2) AS quantity_delivered,
      ROUND(1.0*COUNT(DISTINCT h.id)/NULLIF(COUNT(DISTINCT a.id),0),2) AS deliveries_per_asset,
      MAX(h.occurred_at) AS last_activity_at
      ${grouped} ORDER BY delivery_count DESC, category`,
    countSql: `SELECT COUNT(*) AS total FROM (SELECT ac.id ${grouped})`,
    params,
    page: request.page,
    pageSize: request.pageSize
  });
}


function moneyDiv(alias = 'cur') {
  return `(CASE ${alias}.minor_units WHEN 0 THEN 1.0 WHEN 1 THEN 10.0 WHEN 2 THEN 100.0 WHEN 3 THEN 1000.0 ELSE 10000.0 END)`;
}
function financeBudgetExecution(db, user, request) {
  const scope = scopeWhere(user, 'Finance.Read', 'b.site_id', 'b.location_id', db);
  const where = [`(${scope.sql})`]; const params = [...scope.params];
  addCommonScopeFilters({ where, params, filters: request.filters, siteColumn: 'b.site_id', locationColumn: 'b.location_id' });
  if (request.filters.dateFrom) { where.push('b.period_end >= substr(?,1,10)'); params.push(request.filters.dateFrom); }
  if (request.filters.dateTo) { where.push('b.period_start <= substr(?,1,10)'); params.push(request.filters.dateTo); }
  if (request.filters.status) { where.push('b.status=?'); params.push(request.filters.status.toUpperCase()); }
  if (request.filters.search) { where.push('(b.name LIKE ? OR b.category LIKE ? OR IFNULL(b.sector,\'\') LIKE ?)'); const q=`%${request.filters.search}%`; params.push(q,q,q); }
  const from = `FROM economic_budget b JOIN economic_currency cur ON cur.code=b.currency_code
    LEFT JOIN site s ON s.id=b.site_id LEFT JOIN storage_location l ON l.id=b.location_id
    LEFT JOIN (SELECT budget_id,SUM(sign*amount_minor) executed_minor FROM economic_cost_record WHERE status IN ('EJECUTADO','REVERSADO') GROUP BY budget_id) ec ON ec.budget_id=b.id
    LEFT JOIN (SELECT budget_id,SUM(MAX(committed_amount_minor-executed_amount_minor,0)) committed_minor FROM economic_purchase WHERE status IN ('COMPROMETIDA','PARCIAL','RECIBIDA') GROUP BY budget_id) ep ON ep.budget_id=b.id`;
  return pagedQuery(db,{selectSql:`SELECT b.id,b.name,b.category,b.status,COALESCE(s.name,'Toda la organización') AS site,COALESCE(l.name,'Todas') AS location,COALESCE(b.sector,'Todos') AS sector,b.period_start,b.period_end,b.currency_code,
    ROUND(b.approved_amount_minor/${moneyDiv()},2) AS approved,ROUND(COALESCE(ec.executed_minor,0)/${moneyDiv()},2) AS executed,ROUND(COALESCE(ep.committed_minor,0)/${moneyDiv()},2) AS committed,
    ROUND((b.approved_amount_minor-COALESCE(ec.executed_minor,0)-COALESCE(ep.committed_minor,0))/${moneyDiv()},2) AS available,
    ROUND(100.0*(COALESCE(ec.executed_minor,0)+COALESCE(ep.committed_minor,0))/NULLIF(b.approved_amount_minor,0),2) AS utilization_percent ${from} WHERE ${where.join(' AND ')} ORDER BY b.period_start DESC,b.name`,countSql:`SELECT COUNT(*) total ${from} WHERE ${where.join(' AND ')}`,params,page:request.page,pageSize:request.pageSize});
}
function financeCostsGrouped(db,user,request,mode){
  const scope=scopeWhere(user,'Finance.Read','c.site_id','c.location_id',db);const where=[`(${scope.sql})`,"c.status IN ('EJECUTADO','REVERSADO')"];const params=[...scope.params];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'c.site_id',locationColumn:'c.location_id'});if(request.filters.dateFrom){where.push('c.occurred_on>=substr(?,1,10)');params.push(request.filters.dateFrom);}if(request.filters.dateTo){where.push('c.occurred_on<=substr(?,1,10)');params.push(request.filters.dateTo);}if(request.filters.search){where.push('(c.description LIKE ? OR IFNULL(c.provider,\'\') LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q);}
  const map={sector:{key:"COALESCE(NULLIF(TRIM(c.sector),''),'SIN CLASIFICAR')",label:'sector'},category:{key:'c.cost_type',label:'cost_type'},asset:{key:"COALESCE(a.internal_code,'SIN ACTIVO')",label:'asset_code'}}[mode];const joins=mode==='asset'?'LEFT JOIN asset a ON a.id=c.asset_id':'';const grouped=`FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code ${joins} WHERE ${where.join(' AND ')} GROUP BY ${map.key},c.currency_code,cur.minor_units`;
  return pagedQuery(db,{selectSql:`SELECT ${map.key} AS ${map.label},c.currency_code,ROUND(SUM(c.sign*c.amount_minor)/${moneyDiv()},2) AS amount,COUNT(*) AS records ${grouped} ORDER BY ABS(SUM(c.sign*c.amount_minor)) DESC`,countSql:`SELECT COUNT(*) total FROM (SELECT ${map.key},c.currency_code ${grouped})`,params,page:request.page,pageSize:request.pageSize});
}
function financeCostsBySector(db,u,r){return financeCostsGrouped(db,u,r,'sector');}
function financeCostsByCategory(db,u,r){return financeCostsGrouped(db,u,r,'category');}
function financeCostsByAsset(db,u,r){return financeCostsGrouped(db,u,r,'asset');}
function financePurchasesReport(db,user,request){const scope=scopeWhere(user,'Finance.Read','p.site_id','p.location_id',db);const where=[`(${scope.sql})`];const params=[...scope.params];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'p.site_id',locationColumn:'p.location_id'});if(request.filters.dateFrom){where.push('p.requested_at>=substr(?,1,10)');params.push(request.filters.dateFrom);}if(request.filters.dateTo){where.push('p.requested_at<=substr(?,1,10)');params.push(request.filters.dateTo);}if(request.filters.status){where.push('p.status=?');params.push(request.filters.status.toUpperCase());}if(request.filters.search){where.push('(p.concept LIKE ? OR IFNULL(p.provider,\'\') LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q);}const from=`FROM economic_purchase p JOIN economic_currency cur ON cur.code=p.currency_code JOIN site s ON s.id=p.site_id LEFT JOIN storage_location l ON l.id=p.location_id LEFT JOIN economic_budget b ON b.id=p.budget_id WHERE ${where.join(' AND ')}`;return pagedQuery(db,{selectSql:`SELECT p.id,p.concept,p.provider,p.requested_at,p.status,s.name AS site,l.name AS location,p.sector,p.currency_code,ROUND(p.estimated_amount_minor/${moneyDiv()},2) estimated,ROUND(p.committed_amount_minor/${moneyDiv()},2) committed,ROUND(p.executed_amount_minor/${moneyDiv()},2) executed,ROUND(MAX(p.committed_amount_minor-p.executed_amount_minor,0)/${moneyDiv()},2) pending,b.name AS budget ${from} ORDER BY p.requested_at DESC`,countSql:`SELECT COUNT(*) total ${from}`,params,page:request.page,pageSize:request.pageSize});}
function financeConsumablesReport(db,user,request){const scope=scopeWhere(user,'Finance.Read','loc.site_id','sl.location_id',db);const where=[`(${scope.sql})`,"sm.movement_type='CONSUMO'"];const params=[...scope.params];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'loc.site_id',locationColumn:'sl.location_id'});if(request.filters.dateFrom){where.push('sm.occurred_at>=?');params.push(request.filters.dateFrom);}if(request.filters.dateTo){where.push('sm.occurred_at<=?');params.push(request.filters.dateTo);}if(request.filters.search){where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR sl.lot_code LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q,q);}const stale=Number(getSetting('economic.priceStaleDays',365));const from=`FROM stock_movement sm JOIN stock_lot sl ON sl.id=sm.lot_id JOIN storage_location loc ON loc.id=sl.location_id JOIN asset a ON a.id=sm.asset_id LEFT JOIN economic_stock_price esp ON esp.lot_id=sl.id LEFT JOIN economic_currency cur ON cur.code=esp.currency_code WHERE ${where.join(' AND ')}`;return pagedQuerySeparateParams(db,{selectSql:`SELECT sm.movement_number,sm.occurred_at,a.internal_code,a.description AS asset,sl.lot_code,sm.quantity,esp.currency_code,CASE WHEN esp.id IS NULL OR esp.valid_from>substr(sm.occurred_at,1,10) THEN 'SIN PRECIO' WHEN julianday(substr(sm.occurred_at,1,10))-julianday(esp.valid_from)>? THEN 'PRECIO DESACTUALIZADO' ELSE 'VALORIZADO' END AS price_status,CASE WHEN esp.id IS NULL OR esp.valid_from>substr(sm.occurred_at,1,10) THEN NULL ELSE ROUND(sm.quantity*esp.unit_cost_minor/${moneyDiv()},2) END consumed_cost ${from} ORDER BY sm.occurred_at DESC`,countSql:`SELECT COUNT(*) total ${from}`,selectParams:[stale,...params],countParams:params,page:request.page,pageSize:request.pageSize});}
function financeRepairReplaceReport(db,user,request){const scope=scopeWhere(user,'Finance.AssetAnalysis','sl.site_id','a.location_id',db);const where=[`(${scope.sql})`,'a.deleted_at IS NULL'];const params=[...scope.params];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'sl.site_id',locationColumn:'a.location_id'});if(request.filters.search){where.push('(a.internal_code LIKE ? OR a.description LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q);}const review=Number(getSetting('economic.repairReviewRatio',.5)),replace=Number(getSetting('economic.replaceReviewRatio',.8));const from=`FROM asset a JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN asset_economic_profile aep ON aep.asset_id=a.id LEFT JOIN economic_currency cur ON cur.code=aep.currency_code LEFT JOIN (SELECT asset_id,currency_code,SUM(CASE WHEN cost_type IN ('REPARACION','MANTENIMIENTO','REPUESTOS','SERVICIO_EXTERNO') AND status IN ('EJECUTADO','REVERSADO') THEN sign*amount_minor ELSE 0 END) repair_minor,COUNT(CASE WHEN cost_type IN ('REPARACION','MANTENIMIENTO') AND entry_kind<>'REVERSA' THEN 1 END) interventions FROM economic_cost_record GROUP BY asset_id,currency_code) ec ON ec.asset_id=a.id AND ec.currency_code=aep.currency_code WHERE ${where.join(' AND ')}`;return pagedQuerySeparateParams(db,{selectSql:`SELECT a.id,a.internal_code,a.description,a.status,aep.currency_code,CASE WHEN aep.replacement_amount_minor IS NULL THEN NULL ELSE ROUND(aep.replacement_amount_minor/${moneyDiv()},2) END replacement_cost,ROUND(COALESCE(ec.repair_minor,0)/${moneyDiv()},2) accumulated_repair_cost,ec.interventions,CASE WHEN aep.replacement_amount_minor IS NULL OR aep.replacement_amount_minor=0 OR COALESCE(ec.repair_minor,0)=0 THEN 'DATOS INSUFICIENTES' WHEN 1.0*ec.repair_minor/aep.replacement_amount_minor>=? THEN 'EVALUAR REEMPLAZO' WHEN 1.0*ec.repair_minor/aep.replacement_amount_minor>=? THEN 'REVISAR ANTES DE DECIDIR' ELSE 'REPARAR PARECE CONVENIENTE' END recommendation ${from} ORDER BY a.internal_code`,countSql:`SELECT COUNT(*) total ${from}`,selectParams:[replace,review,...params],countParams:params,page:request.page,pageSize:request.pageSize});}
function financeUnclassifiedReport(db,user,request){const scope=scopeWhere(user,'Finance.Read','c.site_id','c.location_id',db);const where=[`(${scope.sql})`,"c.status IN ('EJECUTADO','REVERSADO')","(c.budget_id IS NULL OR TRIM(IFNULL(c.sector,''))='')"];const params=[...scope.params];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'c.site_id',locationColumn:'c.location_id'});if(request.filters.dateFrom){where.push('c.occurred_on>=substr(?,1,10)');params.push(request.filters.dateFrom);}if(request.filters.dateTo){where.push('c.occurred_on<=substr(?,1,10)');params.push(request.filters.dateTo);}const from=`FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code JOIN site s ON s.id=c.site_id LEFT JOIN storage_location l ON l.id=c.location_id WHERE ${where.join(' AND ')}`;return pagedQuery(db,{selectSql:`SELECT c.id,c.occurred_on,c.cost_type,c.description,s.name AS site,l.name AS location,c.sector,c.currency_code,ROUND(c.sign*c.amount_minor/${moneyDiv()},2) amount,CASE WHEN c.budget_id IS NULL THEN 'SIN PRESUPUESTO' ELSE 'SIN SECTOR' END classification_issue ${from} ORDER BY c.occurred_on DESC`,countSql:`SELECT COUNT(*) total ${from}`,params,page:request.page,pageSize:request.pageSize});}


function actionReportQuery(db,user,request,mode='ALL'){
  const scope=scopeWhere(user,'Actions.Read','a.site_id','a.location_id',db);const global=permissionAssignments(user,'Actions.Read',db).some((x)=>!x.site_id&&!x.location_id);
  const where=[global?`(a.scope_type='GLOBAL' OR ${scope.sql})`:`(${scope.sql})`],params=[...scope.params];
  addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'a.site_id',locationColumn:'a.location_id'});
  if(request.filters.dateFrom){where.push('a.created_at>=?');params.push(request.filters.dateFrom);}if(request.filters.dateTo){where.push('a.created_at<=?');params.push(request.filters.dateTo);}
  if(request.filters.status){const st=request.filters.status.toUpperCase();if(st==='VENCIDA'){where.push("a.status<>'CERRADA' AND a.target_date<date('now','localtime')");}else{where.push('a.status=?');params.push(st);}}
  if(mode==='OPEN')where.push("a.status<>'CERRADA'");if(mode==='OVERDUE')where.push("a.status<>'CERRADA' AND a.target_date<date('now','localtime')");
  if(request.filters.search){where.push('(a.code LIKE ? OR a.title LIKE ? OR a.problem LIKE ? OR a.action_text LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q,q,q);}
  const from=`FROM management_action a LEFT JOIN site s ON s.id=a.site_id LEFT JOIN storage_location l ON l.id=a.location_id LEFT JOIN person p ON p.id=a.assigned_person_id LEFT JOIN role r ON r.id=a.assigned_role_id`;
  const fields=`a.id,a.code,a.title,a.problem,a.action_text,a.expected_result,a.priority,a.status,CASE WHEN a.status<>'CERRADA' AND a.target_date<date('now','localtime') THEN 'VENCIDA' ELSE a.status END effective_status,a.progress_percent,a.target_date,a.indicator_code,COALESCE(p.full_name,r.name,a.assigned_sector,'Sin responsable') responsible,s.name site,l.name location,a.assigned_sector sector,a.created_at,a.closed_at,a.actual_result`;
  return pagedQuery(db,{selectSql:`SELECT ${fields} ${from} WHERE ${where.join(' AND ')} ORDER BY CASE WHEN a.status<>'CERRADA' AND a.target_date<date('now','localtime') THEN 0 ELSE 1 END,CASE a.priority WHEN 'URGENTE' THEN 1 WHEN 'ALTA' THEN 2 WHEN 'MEDIA' THEN 3 ELSE 4 END,a.target_date`,countSql:`SELECT COUNT(*) total ${from} WHERE ${where.join(' AND ')}`,params,page:request.page,pageSize:request.pageSize});
}
function actionsOpenReport(db,user,request){return actionReportQuery(db,user,request,'OPEN');}
function actionsOverdueReport(db,user,request){return actionReportQuery(db,user,request,'OVERDUE');}
function groupedActionsReport(db,user,request,keyField,outputKey){const base=actionReportQuery(db,user,{...request,page:1,pageSize:100000},'ALL').rows;const map=new Map();for(const row of base){const key=row[keyField]||('Sin '+outputKey.toLowerCase());const current=map.get(key)||{[outputKey]:key,total:0,open:0,overdue:0,closed:0};current.total++;if(row.status==='CERRADA')current.closed++;else current.open++;if(row.effective_status==='VENCIDA')current.overdue++;map.set(key,current);}const rows=[...map.values()].sort((a,b)=>b.overdue-a.overdue||b.total-a.total);const total=rows.length,offset=(request.page-1)*request.pageSize;return{rows:rows.slice(offset,offset+request.pageSize),total,page:request.page,pageSize:request.pageSize,pages:Math.max(1,Math.ceil(total/request.pageSize))};}
function actionsByResponsibleReport(db,user,request){return groupedActionsReport(db,user,request,'responsible','responsible');}
function actionsBySectorReport(db,user,request){return groupedActionsReport(db,user,request,'sector','sector');}
function actionsByIndicatorReport(db,user,request){return groupedActionsReport(db,user,request,'indicator_code','indicator_code');}
function actionEffectivenessReport(db,user,request){const result=actionReportQuery(db,user,{...request,filters:{...(request.filters||{}),status:'CERRADA'},page:1,pageSize:100000},'ALL').rows;const rows=result.map((r)=>({...r,closed_on_time:r.closed_at&&r.target_date?String(r.closed_at).slice(0,10)<=r.target_date:null,evidence_count:Number(db.prepare('SELECT COUNT(*) n FROM management_action_evidence WHERE action_id=?').get(r.id).n||0),result_recorded:Boolean(r.actual_result)}));const total=rows.length,offset=(request.page-1)*request.pageSize;return{rows:rows.slice(offset,offset+request.pageSize),total,page:request.page,pageSize:request.pageSize,pages:Math.max(1,Math.ceil(total/request.pageSize))};}
function meetingReportQuery(db,user,request,type){const scope=scopeWhere(user,'Meetings.Minutes.Read','m.site_id','m.location_id',db);const global=permissionAssignments(user,'Meetings.Minutes.Read',db).some((x)=>!x.site_id&&!x.location_id);const where=[global?`(m.scope_type='GLOBAL' OR ${scope.sql})`:`(${scope.sql})`,'m.meeting_type=?'],params=[...scope.params,type];addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'m.site_id',locationColumn:'m.location_id'});if(request.filters.dateFrom){where.push('m.meeting_date>=?');params.push(request.filters.dateFrom.slice(0,10));}if(request.filters.dateTo){where.push('m.meeting_date<=?');params.push(request.filters.dateTo.slice(0,10));}if(request.filters.status){where.push('m.status=?');params.push(request.filters.status.toUpperCase());}if(request.filters.search){where.push("(m.code LIKE ? OR m.title LIKE ? OR IFNULL(m.executive_summary,'') LIKE ?)");const q=`%${request.filters.search}%`;params.push(q,q,q);}const from='FROM management_meeting m LEFT JOIN site s ON s.id=m.site_id LEFT JOIN storage_location l ON l.id=m.location_id';return pagedQuery(db,{selectSql:`SELECT m.id,m.code,m.title,m.meeting_type,m.meeting_date,m.period_from,m.period_to,m.status,s.name site,l.name location,m.executive_summary,m.observations,m.integrity_hash,(SELECT COUNT(*) FROM management_meeting_participant p WHERE p.meeting_id=m.id) participants,(SELECT COUNT(*) FROM management_meeting_topic t WHERE t.meeting_id=m.id) topics,(SELECT COUNT(*) FROM management_meeting_decision d WHERE d.meeting_id=m.id) decisions ${from} WHERE ${where.join(' AND ')} ORDER BY m.meeting_date DESC`,countSql:`SELECT COUNT(*) total ${from} WHERE ${where.join(' AND ')}`,params,page:request.page,pageSize:request.pageSize});}
function weeklyMinutesReport(db,user,request){return meetingReportQuery(db,user,request,'SEMANAL');}
function monthlyMeetingsReport(db,user,request){return meetingReportQuery(db,user,request,'MENSUAL');}
function pendingDecisionsReport(db,user,request){
  const scope=scopeWhere(user,'Meetings.Minutes.Read','m.site_id','m.location_id',db);
  const global=permissionAssignments(user,'Meetings.Minutes.Read',db).some((x)=>!x.site_id&&!x.location_id);
  const effectiveStatus="COALESCE((SELECT e.to_status FROM management_meeting_decision_event e WHERE e.decision_id=d.id ORDER BY e.occurred_at DESC,e.rowid DESC LIMIT 1),d.status)";
  const effectiveAction="COALESCE((SELECT e.action_id FROM management_meeting_decision_event e WHERE e.decision_id=d.id AND e.action_id IS NOT NULL ORDER BY e.occurred_at DESC,e.rowid DESC LIMIT 1),d.action_id)";
  const where=[global?`(m.scope_type='GLOBAL' OR ${scope.sql})`:`(${scope.sql})`,`${effectiveStatus}='PENDIENTE'`],params=[...scope.params];
  addCommonScopeFilters({where,params,filters:request.filters,siteColumn:'m.site_id',locationColumn:'m.location_id'});
  if(request.filters.dateFrom){where.push('m.meeting_date>=?');params.push(request.filters.dateFrom.slice(0,10));}
  if(request.filters.dateTo){where.push('m.meeting_date<=?');params.push(request.filters.dateTo.slice(0,10));}
  if(request.filters.search){where.push('(m.code LIKE ? OR d.decision_text LIKE ?)');const q=`%${request.filters.search}%`;params.push(q,q);}
  const from=`FROM management_meeting_decision d JOIN management_meeting m ON m.id=d.meeting_id LEFT JOIN person p ON p.id=d.responsible_person_id LEFT JOIN role r ON r.id=d.responsible_role_id LEFT JOIN management_action a ON a.id=${effectiveAction}`;
  return pagedQuery(db,{selectSql:`SELECT d.id,m.code meeting_code,m.meeting_date,d.decision_text,COALESCE(p.full_name,r.name,d.responsible_sector,'Sin responsable') responsible,d.target_date,${effectiveStatus} status,a.code action_code ${from} WHERE ${where.join(' AND ')} ORDER BY COALESCE(d.target_date,'9999-12-31'),m.meeting_date`,countSql:`SELECT COUNT(*) total ${from} WHERE ${where.join(' AND ')}`,params,page:request.page,pageSize:request.pageSize});
}

const REPORT_DEFINITIONS = Object.freeze([
  {
    code:'ACT_OPEN',name:'Acciones abiertas',category:'GESTION_ACCIONES',description:'Acciones pendientes o en curso con responsable, prioridad y vencimiento.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','status','search'],columns:[{key:'code',label:'Código',type:'code'},{key:'title',label:'Qué pasa',type:'text'},{key:'action_text',label:'Qué vamos a hacer',type:'text'},{key:'responsible',label:'Quién lo hace',type:'text'},{key:'target_date',label:'Cuándo termina',type:'date'},{key:'effective_status',label:'Estado',type:'status'},{key:'priority',label:'Prioridad',type:'status'}],execute:actionsOpenReport
  },
  {
    code:'ACT_OVERDUE',name:'Acciones vencidas',category:'GESTION_ACCIONES',description:'Acciones abiertas cuya fecha objetivo ya venció.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'code',label:'Código',type:'code'},{key:'title',label:'Acción',type:'text'},{key:'responsible',label:'Responsable',type:'text'},{key:'target_date',label:'Vencimiento',type:'date'},{key:'priority',label:'Prioridad',type:'status'},{key:'progress_percent',label:'Avance %',type:'number'}],execute:actionsOverdueReport
  },
  {
    code:'ACT_BY_RESPONSIBLE',name:'Acciones por responsable',category:'GESTION_ACCIONES',description:'Carga y vencimientos agrupados por responsable.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'responsible',label:'Responsable',type:'text'},{key:'total',label:'Total',type:'number'},{key:'open',label:'Abiertas',type:'number'},{key:'overdue',label:'Vencidas',type:'number'},{key:'closed',label:'Cerradas',type:'number'}],execute:actionsByResponsibleReport
  },
  {
    code:'ACT_BY_SECTOR',name:'Acciones por sector',category:'GESTION_ACCIONES',description:'Acciones abiertas, vencidas y cerradas agrupadas por sector.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'sector',label:'Sector',type:'text'},{key:'total',label:'Total',type:'number'},{key:'open',label:'Abiertas',type:'number'},{key:'overdue',label:'Vencidas',type:'number'},{key:'closed',label:'Cerradas',type:'number'}],execute:actionsBySectorReport
  },
  {
    code:'ACT_BY_INDICATOR',name:'Acciones por indicador',category:'GESTION_ACCIONES',description:'Seguimiento de acciones relacionadas con indicadores de gestión.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'indicator_code',label:'Indicador',type:'code'},{key:'total',label:'Total',type:'number'},{key:'open',label:'Abiertas',type:'number'},{key:'overdue',label:'Vencidas',type:'number'},{key:'closed',label:'Cerradas',type:'number'}],execute:actionsByIndicatorReport
  },
  {
    code:'ACT_EFFECTIVENESS',name:'Eficacia de acciones',category:'GESTION_ACCIONES',description:'Resultados, evidencia y cumplimiento de plazo de las acciones cerradas.',requiredPermission:'Actions.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'code',label:'Código',type:'code'},{key:'title',label:'Acción',type:'text'},{key:'responsible',label:'Responsable',type:'text'},{key:'target_date',label:'Objetivo',type:'date'},{key:'closed_at',label:'Cierre',type:'datetime'},{key:'closed_on_time',label:'En término',type:'boolean'},{key:'evidence_count',label:'Evidencias',type:'number'},{key:'actual_result',label:'Resultado',type:'text'}],execute:actionEffectivenessReport
  },
  {
    code:'MEET_WEEKLY_MINUTES',name:'Actas semanales',category:'GESTION_ACCIONES',description:'Actas de las reuniones semanales del pañol.',requiredPermission:'Meetings.Minutes.Read',filters:['dateFrom','dateTo','siteId','locationId','status','search'],columns:[{key:'code',label:'Acta',type:'code'},{key:'meeting_date',label:'Fecha',type:'date'},{key:'title',label:'Reunión',type:'text'},{key:'status',label:'Estado',type:'status'},{key:'participants',label:'Participantes',type:'number'},{key:'topics',label:'Temas',type:'number'},{key:'decisions',label:'Decisiones',type:'number'},{key:'integrity_hash',label:'Integridad',type:'code'}],execute:weeklyMinutesReport
  },
  {
    code:'MEET_MONTHLY_REPORT',name:'Revisiones mensuales',category:'GESTION_ACCIONES',description:'Resumen de las revisiones mensuales de gestión.',requiredPermission:'Meetings.Minutes.Read',filters:['dateFrom','dateTo','siteId','locationId','status','search'],columns:[{key:'code',label:'Acta',type:'code'},{key:'meeting_date',label:'Fecha',type:'date'},{key:'title',label:'Revisión',type:'text'},{key:'status',label:'Estado',type:'status'},{key:'executive_summary',label:'Resumen',type:'text'},{key:'decisions',label:'Decisiones',type:'number'},{key:'integrity_hash',label:'Integridad',type:'code'}],execute:monthlyMeetingsReport
  },
  {
    code:'MEET_PENDING_DECISIONS',name:'Decisiones pendientes',category:'GESTION_ACCIONES',description:'Decisiones de reuniones que todavía requieren ejecución.',requiredPermission:'Meetings.Minutes.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'meeting_code',label:'Acta',type:'code'},{key:'meeting_date',label:'Fecha',type:'date'},{key:'decision_text',label:'Decisión',type:'text'},{key:'responsible',label:'Responsable',type:'text'},{key:'target_date',label:'Fecha objetivo',type:'date'},{key:'status',label:'Estado',type:'status'},{key:'action_code',label:'Acción',type:'code'}],execute:pendingDecisionsReport
  },

  {
    code: 'FIN_BUDGET_EXECUTION', name: 'Ejecución presupuestaria', category: 'ECONOMIA', description: 'Presupuesto aprobado, ejecutado, comprometido y disponible, sin mezclar monedas.',
    requiredPermission: 'Finance.Read', filters: ['dateFrom','dateTo','siteId','locationId','status','search'],
    columns: [{key:'name',label:'Presupuesto',type:'text'},{key:'category',label:'Categoría',type:'text'},{key:'status',label:'Estado',type:'status'},{key:'site',label:'Sede',type:'text'},{key:'location',label:'Ubicación',type:'text'},{key:'sector',label:'Sector',type:'text'},{key:'period_start',label:'Desde',type:'date'},{key:'period_end',label:'Hasta',type:'date'},{key:'currency_code',label:'Moneda',type:'code'},{key:'approved',label:'Aprobado',type:'number'},{key:'executed',label:'Ejecutado',type:'number'},{key:'committed',label:'Comprometido',type:'number'},{key:'available',label:'Disponible',type:'number'},{key:'utilization_percent',label:'Uso %',type:'number'}], execute: financeBudgetExecution
  },
  {
    code:'FIN_COSTS_BY_SECTOR',name:'Costos por sector',category:'ECONOMIA',description:'Costos ejecutados agrupados por sector y moneda.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'sector',label:'Sector',type:'text'},{key:'currency_code',label:'Moneda',type:'code'},{key:'amount',label:'Costo',type:'number'},{key:'records',label:'Registros',type:'number'}],execute:financeCostsBySector
  },
  {
    code:'FIN_COSTS_BY_ASSET',name:'Costos por activo',category:'ECONOMIA',description:'Costos ejecutados vinculados a activos, separados por moneda.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'asset_code',label:'Activo',type:'code'},{key:'currency_code',label:'Moneda',type:'code'},{key:'amount',label:'Costo',type:'number'},{key:'records',label:'Registros',type:'number'}],execute:financeCostsByAsset
  },
  {
    code:'FIN_COSTS_BY_CATEGORY',name:'Costos por categoría',category:'ECONOMIA',description:'Costos ejecutados agrupados por tipo económico.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'cost_type',label:'Tipo de costo',type:'code'},{key:'currency_code',label:'Moneda',type:'code'},{key:'amount',label:'Costo',type:'number'},{key:'records',label:'Registros',type:'number'}],execute:financeCostsByCategory
  },
  {
    code:'FIN_CONSUMABLES_VALUED',name:'Consumibles valorizados',category:'ECONOMIA',description:'Consumos reales valorizados por lote; los faltantes se muestran como SIN PRECIO.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId','search'],columns:[{key:'movement_number',label:'Movimiento',type:'code'},{key:'occurred_at',label:'Fecha',type:'datetime'},{key:'internal_code',label:'Código',type:'code'},{key:'asset',label:'Artículo',type:'text'},{key:'lot_code',label:'Lote',type:'code'},{key:'quantity',label:'Cantidad',type:'number'},{key:'currency_code',label:'Moneda',type:'code'},{key:'price_status',label:'Precio',type:'status'},{key:'consumed_cost',label:'Costo consumido',type:'number'}],execute:financeConsumablesReport
  },
  {
    code:'FIN_PURCHASES_COMMITMENTS',name:'Compras y compromisos',category:'ECONOMIA',description:'Estimado, comprometido, ejecutado y pendiente de cada compra.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId','status','search'],columns:[{key:'concept',label:'Concepto',type:'text'},{key:'provider',label:'Proveedor',type:'text'},{key:'requested_at',label:'Fecha',type:'date'},{key:'status',label:'Estado',type:'status'},{key:'site',label:'Sede',type:'text'},{key:'sector',label:'Sector',type:'text'},{key:'currency_code',label:'Moneda',type:'code'},{key:'estimated',label:'Estimado',type:'number'},{key:'committed',label:'Comprometido',type:'number'},{key:'executed',label:'Ejecutado',type:'number'},{key:'pending',label:'Pendiente',type:'number'},{key:'budget',label:'Presupuesto',type:'text'}],execute:financePurchasesReport
  },
  {
    code:'FIN_REPAIR_REPLACE',name:'Reparar versus reemplazar',category:'ECONOMIA',description:'Ayuda orientativa basada en costos registrados; nunca reemplaza la decisión humana.',requiredPermission:'Finance.AssetAnalysis',filters:['siteId','locationId','search'],columns:[{key:'internal_code',label:'Código',type:'code'},{key:'description',label:'Activo',type:'text'},{key:'status',label:'Estado',type:'status'},{key:'currency_code',label:'Moneda',type:'code'},{key:'replacement_cost',label:'Reposición',type:'number'},{key:'accumulated_repair_cost',label:'Reparaciones',type:'number'},{key:'interventions',label:'Intervenciones',type:'number'},{key:'recommendation',label:'Resultado',type:'status'}],execute:financeRepairReplaceReport
  },
  {
    code:'FIN_UNCLASSIFIED',name:'Gastos sin clasificar',category:'ECONOMIA',description:'Registros ejecutados sin presupuesto o sin sector definido.',requiredPermission:'Finance.Read',filters:['dateFrom','dateTo','siteId','locationId'],columns:[{key:'occurred_on',label:'Fecha',type:'date'},{key:'cost_type',label:'Tipo',type:'code'},{key:'description',label:'Descripción',type:'text'},{key:'site',label:'Sede',type:'text'},{key:'location',label:'Ubicación',type:'text'},{key:'sector',label:'Sector',type:'text'},{key:'currency_code',label:'Moneda',type:'code'},{key:'amount',label:'Importe',type:'number'},{key:'classification_issue',label:'Pendiente',type:'status'}],execute:financeUnclassifiedReport
  },
  {
    code: 'OP_REQUESTS_BY_STATUS', name: 'Solicitudes por estado', category: 'OPERACION', description: 'Resumen de solicitudes agrupadas por estado dentro del alcance.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId'],
    columns: [
      { key: 'status', label: 'Estado', type: 'status' }, { key: 'total', label: 'Cantidad', type: 'number' },
      { key: 'first_created_at', label: 'Primera solicitud', type: 'datetime' }, { key: 'last_created_at', label: 'Última solicitud', type: 'datetime' }
    ], execute: requestsByStatus
  },
  {
    code: 'OP_REQUESTS_OVERDUE', name: 'Solicitudes demoradas', category: 'OPERACION', description: 'Solicitudes cuya fecha requerida ya venció y todavía no fueron entregadas, canceladas ni expiradas.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'requester', label: 'Solicitante', type: 'text' },
      { key: 'operation_type', label: 'Operación', type: 'text' }, { key: 'status', label: 'Estado', type: 'status' },
      { key: 'created_at', label: 'Creada', type: 'datetime' }, { key: 'needed_at', label: 'Requerida', type: 'datetime' },
      { key: 'delay_hours', label: 'Demora (h)', type: 'number' }, { key: 'reason', label: 'Motivo', type: 'text' }
    ], execute: overdueRequests
  },
  {
    code: 'OP_HANDOVERS_COMPLETED', name: 'Entregas realizadas', category: 'OPERACION', description: 'Entregas físicas registradas, con receptor, pañolero, cantidades y aceptación.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'recipient', label: 'Receptor', type: 'text' },
      { key: 'operator', label: 'Pañolero', type: 'text' }, { key: 'occurred_at', label: 'Entrega', type: 'datetime' },
      { key: 'item_count', label: 'Renglones', type: 'number' }, { key: 'total_quantity', label: 'Cantidad', type: 'number' },
      { key: 'acceptance_method', label: 'Aceptación', type: 'text' }, { key: 'observations', label: 'Observaciones', type: 'text' }
    ], execute: completedHandovers
  },
  {
    code: 'CUSTODY_ACTIVE', name: 'Custodias activas', category: 'CUSTODIAS', description: 'Detalle de herramientas entregadas que todavía no cerraron su devolución.',
    requiredPermission: 'Custody.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'internal_code', label: 'Código', type: 'text' },
      { key: 'asset_description', label: 'Bien', type: 'text' }, { key: 'custodian', label: 'Custodio', type: 'text' },
      { key: 'quantity', label: 'Cantidad', type: 'number' }, { key: 'opened_at', label: 'Entrega', type: 'datetime' },
      { key: 'due_at', label: 'Vencimiento', type: 'datetime' }, { key: 'status', label: 'Estado', type: 'status' },
      { key: 'overdue', label: 'Vencida', type: 'boolean' }
    ], execute: activeCustodiesSafe
  },
  {
    code: 'CUSTODY_OVERDUE', name: 'Custodias vencidas', category: 'CUSTODIAS', description: 'Herramientas no devueltas cuya fecha prevista de devolución ya venció.',
    requiredPermission: 'Custody.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'internal_code', label: 'Código', type: 'text' },
      { key: 'asset_description', label: 'Bien', type: 'text' }, { key: 'custodian', label: 'Custodio', type: 'text' },
      { key: 'quantity', label: 'Cantidad', type: 'number' }, { key: 'opened_at', label: 'Entrega', type: 'datetime' },
      { key: 'due_at', label: 'Vencimiento', type: 'datetime' }, { key: 'overdue_hours', label: 'Atraso (h)', type: 'number' },
      { key: 'status', label: 'Estado', type: 'status' }
    ], execute: overdueCustodies
  },
  {
    code: 'CUSTODY_RETURNS_COMPLETED', name: 'Devoluciones realizadas', category: 'CUSTODIAS', description: 'Recepciones físicas registradas con plazo, condición, observaciones e incidente asociado.',
    requiredPermission: 'Custody.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'internal_code', label: 'Código', type: 'text' },
      { key: 'asset_description', label: 'Bien', type: 'text' }, { key: 'custodian', label: 'Custodio', type: 'text' },
      { key: 'due_at_snapshot', label: 'Vencimiento', type: 'datetime' }, { key: 'received_at', label: 'Recepción', type: 'datetime' },
      { key: 'timing_status', label: 'Cumplimiento', type: 'status' }, { key: 'overdue_hours', label: 'Atraso (h)', type: 'number' },
      { key: 'condition', label: 'Condición', type: 'status' }, { key: 'incident_number', label: 'Incidente', type: 'text' },
      { key: 'technician_comment', label: 'Comentario técnico', type: 'text' }, { key: 'warehouse_comment', label: 'Comentario pañolero', type: 'text' },
      { key: 'review_source', label: 'Origen revisión', type: 'text' }, { key: 'comment_forced_observation', label: 'Comentario forzó observación', type: 'boolean' },
      { key: 'blocked_after_receipt', label: 'Bloqueado al recibir', type: 'boolean' }, { key: 'legacy_reception_note', label: 'Nota histórica recepción', type: 'text' }
    ], execute: completedCustodyReturns
  },
  {
    code: 'CUSTODY_RETURNS_LATE', name: 'Devoluciones fuera de término', category: 'CUSTODIAS', description: 'Devoluciones recibidas después del vencimiento, separadas de la condición física del bien.',
    requiredPermission: 'Custody.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'text' }, { key: 'internal_code', label: 'Código', type: 'text' },
      { key: 'asset_description', label: 'Bien', type: 'text' }, { key: 'custodian', label: 'Custodio', type: 'text' },
      { key: 'due_at_snapshot', label: 'Vencimiento', type: 'datetime' }, { key: 'received_at', label: 'Recepción', type: 'datetime' },
      { key: 'overdue_hours', label: 'Atraso (h)', type: 'number' }, { key: 'condition', label: 'Condición', type: 'status' },
      { key: 'incident_number', label: 'Incidente', type: 'text' },
      { key: 'technician_comment', label: 'Comentario técnico', type: 'text' }, { key: 'warehouse_comment', label: 'Comentario pañolero', type: 'text' },
      { key: 'review_source', label: 'Origen revisión', type: 'text' }, { key: 'comment_forced_observation', label: 'Comentario forzó observación', type: 'boolean' },
      { key: 'blocked_after_receipt', label: 'Bloqueado al recibir', type: 'boolean' }, { key: 'legacy_reception_note', label: 'Nota histórica recepción', type: 'text' }
    ], execute: lateCustodyReturns
  },
  {
    code: 'INV_ASSETS_BY_STATUS', name: 'Bienes por estado', category: 'INVENTARIO', description: 'Resumen del maestro de bienes por disponibilidad y condición operativa.',
    requiredPermission: 'Assets.Read', filters: ['siteId', 'locationId', 'categoryId'],
    columns: [
      { key: 'status', label: 'Estado', type: 'status' }, { key: 'total', label: 'Bienes', type: 'number' },
      { key: 'quantity_total', label: 'Cantidad total', type: 'number' }, { key: 'quantity_available', label: 'Disponible', type: 'number' }
    ], execute: assetsByStatus
  },
  {
    code: 'INV_BLOCKED_ASSETS', name: 'Bienes bloqueados', category: 'INVENTARIO', description: 'Bienes bloqueados con su bloqueo operativo e incidente abierto más reciente, cuando existen.',
    requiredPermission: 'Assets.Read', filters: ['siteId', 'locationId', 'categoryId', 'search'],
    columns: [
      { key: 'internal_code', label: 'Código', type: 'text' }, { key: 'asset_description', label: 'Bien', type: 'text' },
      { key: 'category', label: 'Categoría', type: 'text' }, { key: 'location', label: 'Ubicación', type: 'text' },
      { key: 'block_number', label: 'Bloqueo', type: 'text' }, { key: 'block_severity', label: 'Severidad', type: 'status' },
      { key: 'block_reason', label: 'Motivo', type: 'text' }, { key: 'incident_number', label: 'Incidente', type: 'text' },
      { key: 'updated_at', label: 'Actualizado', type: 'datetime' }
    ], execute: blockedAssets
  },
  {
    code: 'INV_STOCK_UNAVAILABLE', name: 'Stock crítico sin disponibilidad', category: 'INVENTARIO', description: 'Lotes de bienes por cantidad o consumibles sin saldo libre. No aplica un mínimo configurable porque el modelo actual todavía no lo posee.',
    requiredPermission: 'Stock.Read', filters: ['siteId', 'locationId', 'categoryId', 'search'],
    columns: [
      { key: 'internal_code', label: 'Código', type: 'text' }, { key: 'asset_description', label: 'Bien', type: 'text' },
      { key: 'category', label: 'Categoría', type: 'text' }, { key: 'location', label: 'Ubicación', type: 'text' },
      { key: 'lot_code', label: 'Lote', type: 'text' }, { key: 'quantity_on_hand', label: 'Existencia', type: 'number' },
      { key: 'quantity_reserved', label: 'Reservado', type: 'number' }, { key: 'quantity_available', label: 'Libre', type: 'number' },
      { key: 'expires_at', label: 'Vencimiento', type: 'datetime' }, { key: 'updated_at', label: 'Actualizado', type: 'datetime' }
    ], execute: unavailableStock
  },
  {
    code: 'INC_OPEN', name: 'Incidentes abiertos', category: 'INCIDENTES_MANTENIMIENTO', description: 'Incidentes abiertos o en investigación ordenados por severidad.',
    requiredPermission: 'Incident.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'],
    columns: [
      { key: 'incident_number', label: 'Incidente', type: 'text' }, { key: 'severity', label: 'Severidad', type: 'status' },
      { key: 'status', label: 'Estado', type: 'status' }, { key: 'type', label: 'Tipo', type: 'text' },
      { key: 'title', label: 'Título', type: 'text' }, { key: 'internal_code', label: 'Bien', type: 'text' },
      { key: 'asset_description', label: 'Descripción', type: 'text' }, { key: 'opened_at', label: 'Apertura', type: 'datetime' }
    ], execute: openIncidents
  },
  {
    code: 'MNT_ORDERS_BY_STATUS', name: 'Mantenimiento por estado', category: 'INCIDENTES_MANTENIMIENTO', description: 'Resumen de órdenes de mantenimiento y cantidad vencida.',
    requiredPermission: 'Maintenance.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId'],
    columns: [
      { key: 'status', label: 'Estado', type: 'status' }, { key: 'total', label: 'Órdenes', type: 'number' },
      { key: 'overdue', label: 'Vencidas', type: 'number' }
    ], execute: maintenanceByStatusSafe
  },
  {
    code: 'GEST_REQUEST_TREND_MONTHLY', name: 'Tendencia mensual de solicitudes', category: 'GESTION', description: 'Evolución mensual de solicitudes, entregas, cancelaciones y demoras operativas.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId'], detailView: 'requests',
    chart: { type: 'line', title: 'Evolución de solicitudes', categoryKey: 'period', series: [
      { key: 'total_requests', label: 'Solicitudes' }, { key: 'delivered', label: 'Entregadas' }, { key: 'delayed', label: 'Demoradas' }
    ] },
    summary: [
      { key: 'total_requests', label: 'Solicitudes', aggregate: 'sum' }, { key: 'delivered', label: 'Entregadas', aggregate: 'sum' },
      { key: 'delayed', label: 'Demoradas', aggregate: 'sum' }, { key: 'cancelled', label: 'Canceladas', aggregate: 'sum' }
    ],
    columns: [
      { key: 'period', label: 'Período', type: 'text' }, { key: 'total_requests', label: 'Solicitudes', type: 'number' },
      { key: 'delivered', label: 'Entregadas', type: 'number' }, { key: 'cancelled', label: 'Canceladas', type: 'number' },
      { key: 'approval_required', label: 'Con aprobación', type: 'number' }, { key: 'delayed', label: 'Demoradas', type: 'number' }
    ], execute: managementRequestTrend
  },
  {
    code: 'GEST_SERVICE_TIMES_MONTHLY', name: 'Tiempos de atención', category: 'GESTION', description: 'Tiempo promedio entre creación, decisión de aprobación y entrega física, agrupado por mes.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId'], detailView: 'requests',
    chart: { type: 'line', title: 'Horas promedio de atención', categoryKey: 'period', series: [
      { key: 'avg_approval_hours', label: 'Aprobación (h)' }, { key: 'avg_delivery_hours', label: 'Entrega (h)' }
    ] },
    summary: [
      { key: 'avg_approval_hours', label: 'Promedio aprobación (h)', aggregate: 'average' },
      { key: 'avg_delivery_hours', label: 'Promedio entrega (h)', aggregate: 'average' },
      { key: 'approval_samples', label: 'Aprobaciones medidas', aggregate: 'sum' },
      { key: 'delivery_samples', label: 'Entregas medidas', aggregate: 'sum' }
    ],
    columns: [
      { key: 'period', label: 'Período', type: 'text' }, { key: 'total_requests', label: 'Solicitudes', type: 'number' },
      { key: 'approval_samples', label: 'Aprobaciones medidas', type: 'number' }, { key: 'avg_approval_hours', label: 'Promedio aprobación (h)', type: 'number' },
      { key: 'delivery_samples', label: 'Entregas medidas', type: 'number' }, { key: 'avg_delivery_hours', label: 'Promedio entrega (h)', type: 'number' }
    ], execute: managementServiceTimes
  },
  {
    code: 'GEST_ASSET_ROTATION', name: 'Rotación de bienes', category: 'GESTION', description: 'Bienes con mayor cantidad de entregas, horas de custodia y devoluciones tardías.',
    requiredPermission: 'Assets.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'categoryId', 'search'], detailView: 'assets',
    chart: { type: 'bar', title: 'Bienes con mayor rotación', categoryKey: 'internal_code', series: [{ key: 'delivery_count', label: 'Entregas' }], limit: 15 },
    summary: [
      { key: 'delivery_count', label: 'Entregas', aggregate: 'sum' }, { key: 'quantity_delivered', label: 'Cantidad entregada', aggregate: 'sum' },
      { key: 'custody_hours', label: 'Horas de custodia', aggregate: 'sum' }, { key: 'late_returns', label: 'Devoluciones tardías', aggregate: 'sum' }
    ],
    columns: [
      { key: 'internal_code', label: 'Código', type: 'text' }, { key: 'asset_description', label: 'Bien', type: 'text' },
      { key: 'category', label: 'Categoría', type: 'text' }, { key: 'delivery_count', label: 'Entregas', type: 'number' },
      { key: 'quantity_delivered', label: 'Cantidad entregada', type: 'number' }, { key: 'custody_hours', label: 'Custodia (h)', type: 'number' },
      { key: 'late_returns', label: 'Devoluciones tardías', type: 'number' }, { key: 'last_delivery_at', label: 'Última entrega', type: 'datetime' }
    ], execute: managementAssetRotation
  },
  {
    code: 'GEST_RETURN_COMPLIANCE', name: 'Cumplimiento de devoluciones', category: 'GESTION', description: 'Cumplimiento mensual de fechas previstas de devolución y atraso promedio.',
    requiredPermission: 'Custody.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId'], detailView: 'custodies',
    chart: { type: 'line', title: 'Cumplimiento mensual de devoluciones', categoryKey: 'period', series: [
      { key: 'compliance_percent', label: 'Cumplimiento (%)' }, { key: 'late', label: 'Fuera de término' }
    ] },
    summary: [
      { key: 'total_returns', label: 'Devoluciones', aggregate: 'sum' }, { key: 'on_time', label: 'En término', aggregate: 'sum' },
      { key: 'late', label: 'Fuera de término', aggregate: 'sum' }, { key: 'compliance_percent', label: 'Cumplimiento medio (%)', aggregate: 'average' }
    ],
    columns: [
      { key: 'period', label: 'Período', type: 'text' }, { key: 'total_returns', label: 'Devoluciones', type: 'number' },
      { key: 'on_time', label: 'En término', type: 'number' }, { key: 'late', label: 'Fuera de término', type: 'number' },
      { key: 'without_due', label: 'Sin vencimiento', type: 'number' }, { key: 'compliance_percent', label: 'Cumplimiento (%)', type: 'number' },
      { key: 'avg_late_hours', label: 'Atraso promedio (h)', type: 'number' }
    ], execute: managementReturnCompliance
  },
  {
    code: 'GEST_ACTIVITY_BY_SECTOR', name: 'Actividad por sector', category: 'GESTION', description: 'Demanda operativa agrupada por sector de los solicitantes.',
    requiredPermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'search'], detailView: 'requests',
    chart: { type: 'bar', title: 'Solicitudes por sector', categoryKey: 'sector', series: [{ key: 'total_requests', label: 'Solicitudes' }], limit: 15 },
    summary: [
      { key: 'total_requests', label: 'Solicitudes', aggregate: 'sum' }, { key: 'delivered', label: 'Entregadas', aggregate: 'sum' },
      { key: 'delayed', label: 'Demoradas', aggregate: 'sum' }, { key: 'requested_quantity', label: 'Cantidad solicitada', aggregate: 'sum' }
    ],
    columns: [
      { key: 'sector', label: 'Sector', type: 'text' }, { key: 'total_requests', label: 'Solicitudes', type: 'number' },
      { key: 'delivered', label: 'Entregadas', type: 'number' }, { key: 'delayed', label: 'Demoradas', type: 'number' },
      { key: 'requested_quantity', label: 'Cantidad solicitada', type: 'number' }, { key: 'active_requesters', label: 'Solicitantes activos', type: 'number' }
    ], execute: managementActivityBySector
  },
  {
    code: 'GEST_INCIDENT_RECURRENCE', name: 'Reincidencia de incidentes', category: 'GESTION', description: 'Bienes con incidentes repetidos, abiertos, críticos y costos registrados.',
    requiredPermission: 'Incident.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'categoryId', 'status', 'search'], detailView: 'incidents',
    chart: { type: 'bar', title: 'Bienes con más incidentes', categoryKey: 'internal_code', series: [{ key: 'incident_count', label: 'Incidentes' }], limit: 15 },
    summary: [
      { key: 'incident_count', label: 'Incidentes', aggregate: 'sum' }, { key: 'open_count', label: 'Abiertos', aggregate: 'sum' },
      { key: 'critical_count', label: 'Críticos', aggregate: 'sum' }, { key: 'actual_cost', label: 'Costo registrado', aggregate: 'sum' }
    ],
    columns: [
      { key: 'internal_code', label: 'Código', type: 'text' }, { key: 'asset_description', label: 'Bien', type: 'text' },
      { key: 'category', label: 'Categoría', type: 'text' }, { key: 'incident_count', label: 'Incidentes', type: 'number' },
      { key: 'open_count', label: 'Abiertos', type: 'number' }, { key: 'critical_count', label: 'Críticos', type: 'number' },
      { key: 'actual_cost', label: 'Costo registrado', type: 'number' }, { key: 'last_incident_at', label: 'Último incidente', type: 'datetime' }
    ], execute: managementIncidentRecurrence
  },
  {
    code: 'GEST_MAINTENANCE_PERFORMANCE', name: 'Desempeño de mantenimiento', category: 'GESTION', description: 'Órdenes creadas, completadas, vencidas y tiempo promedio de ejecución por mes.',
    requiredPermission: 'Maintenance.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'categoryId', 'status'], detailView: 'maintenance',
    chart: { type: 'line', title: 'Órdenes de mantenimiento', categoryKey: 'period', series: [
      { key: 'total_orders', label: 'Órdenes' }, { key: 'completed', label: 'Completadas' }, { key: 'overdue', label: 'Vencidas' }
    ] },
    summary: [
      { key: 'total_orders', label: 'Órdenes', aggregate: 'sum' }, { key: 'completed', label: 'Completadas', aggregate: 'sum' },
      { key: 'overdue', label: 'Vencidas', aggregate: 'sum' }, { key: 'avg_cycle_hours', label: 'Ciclo promedio (h)', aggregate: 'average' }
    ],
    columns: [
      { key: 'period', label: 'Período', type: 'text' }, { key: 'total_orders', label: 'Órdenes', type: 'number' },
      { key: 'completed', label: 'Completadas', type: 'number' }, { key: 'overdue', label: 'Vencidas', type: 'number' },
      { key: 'in_progress', label: 'En progreso', type: 'number' }, { key: 'avg_cycle_hours', label: 'Ciclo promedio (h)', type: 'number' }
    ], execute: managementMaintenancePerformance
  },
  {
    code: 'GEST_CATEGORY_UTILIZATION', name: 'Utilización por categoría', category: 'GESTION', description: 'Entregas, cantidades y frecuencia de utilización agrupadas por categoría.',
    requiredPermission: 'Assets.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'categoryId', 'search'], detailView: 'assets',
    chart: { type: 'bar', title: 'Entregas por categoría', categoryKey: 'category', series: [{ key: 'delivery_count', label: 'Entregas' }], limit: 15 },
    summary: [
      { key: 'assets_used', label: 'Bienes utilizados', aggregate: 'sum' }, { key: 'delivery_count', label: 'Entregas', aggregate: 'sum' },
      { key: 'quantity_delivered', label: 'Cantidad entregada', aggregate: 'sum' }, { key: 'deliveries_per_asset', label: 'Entregas por bien', aggregate: 'average' }
    ],
    columns: [
      { key: 'category_code', label: 'Código', type: 'text' }, { key: 'category', label: 'Categoría', type: 'text' },
      { key: 'assets_used', label: 'Bienes utilizados', type: 'number' }, { key: 'delivery_count', label: 'Entregas', type: 'number' },
      { key: 'quantity_delivered', label: 'Cantidad entregada', type: 'number' }, { key: 'deliveries_per_asset', label: 'Entregas por bien', type: 'number' },
      { key: 'last_activity_at', label: 'Última actividad', type: 'datetime' }
    ], execute: managementCategoryUtilization
  },
  {
    code: 'AUD_ACTIONS_BY_USER', name: 'Acciones por usuario', category: 'AUDITORIA', description: 'Cantidad y resultado de acciones registradas por usuario y tipo de operación.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'audit',
    columns: [
      { key: 'actor', label: 'Usuario', type: 'text' }, { key: 'username', label: 'Cuenta', type: 'code' },
      { key: 'action', label: 'Acción', type: 'code' }, { key: 'total_actions', label: 'Total', type: 'number' },
      { key: 'successful', label: 'Exitosas', type: 'number' }, { key: 'denied', label: 'Denegadas', type: 'number' },
      { key: 'failed', label: 'Fallidas', type: 'number' }, { key: 'last_action_at', label: 'Última acción', type: 'datetime' }
    ], execute: auditActionsByUser
  },
  {
    code: 'AUD_CRITICAL_CHANGES', name: 'Cambios críticos', category: 'AUDITORIA', description: 'Cambios de seguridad, usuarios, roles, configuración, restauraciones y operaciones críticas.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'audit',
    columns: [
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'action', label: 'Acción', type: 'code' },
      { key: 'entity_type', label: 'Entidad', type: 'code' }, { key: 'entity_id', label: 'ID entidad', type: 'code' },
      { key: 'before_snapshot', label: 'Antes', type: 'code' }, { key: 'after_snapshot', label: 'Después', type: 'code' },
      { key: 'reason', label: 'Motivo', type: 'text' }, { key: 'result', label: 'Resultado', type: 'status' },
      { key: 'occurred_at', label: 'Fecha', type: 'datetime' }, { key: 'correlation_id', label: 'Correlación', type: 'code' }
    ], execute: auditCriticalChanges
  },
  {
    code: 'AUD_STATUS_CHANGES', name: 'Cambios de estado operativos', category: 'AUDITORIA', description: 'Transiciones de solicitudes, custodias, incidentes y órdenes de mantenimiento.',
    requiredPermission: 'Reports.Audit', scopePermission: 'Audit.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'], detailView: 'audit',
    columns: [
      { key: 'event_source', label: 'Módulo', type: 'text' }, { key: 'reference', label: 'Referencia', type: 'code' },
      { key: 'from_status', label: 'Estado anterior', type: 'status' }, { key: 'to_status', label: 'Estado nuevo', type: 'status' },
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'reason', label: 'Motivo', type: 'text' },
      { key: 'occurred_at', label: 'Fecha', type: 'datetime' }, { key: 'correlation_id', label: 'Correlación', type: 'code' }
    ], execute: auditStatusChanges
  },
  {
    code: 'AUD_PERMISSION_CHANGES', name: 'Cambios de roles y permisos', category: 'AUDITORIA', description: 'Creación o modificación de roles y cambios de permisos particulares de usuarios.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'roles',
    columns: [
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'action', label: 'Acción', type: 'code' },
      { key: 'entity_type', label: 'Entidad', type: 'code' }, { key: 'entity_id', label: 'ID entidad', type: 'code' },
      { key: 'before_snapshot', label: 'Antes', type: 'code' }, { key: 'after_snapshot', label: 'Después', type: 'code' },
      { key: 'result', label: 'Resultado', type: 'status' }, { key: 'occurred_at', label: 'Fecha', type: 'datetime' },
      { key: 'evidence_hash', label: 'Hash', type: 'code' }
    ], execute: auditPermissionChanges
  },
  {
    code: 'AUD_CONFIGURATION_CHANGES', name: 'Cambios de configuración', category: 'AUDITORIA', description: 'Cambios de parámetros, sedes, ubicaciones, políticas, categorías, scheduler y acceso móvil.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'config',
    columns: [
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'action', label: 'Acción', type: 'code' },
      { key: 'entity_type', label: 'Entidad', type: 'code' }, { key: 'entity_id', label: 'ID entidad', type: 'code' },
      { key: 'before_snapshot', label: 'Antes', type: 'code' }, { key: 'after_snapshot', label: 'Después', type: 'code' },
      { key: 'reason', label: 'Motivo', type: 'text' }, { key: 'occurred_at', label: 'Fecha', type: 'datetime' },
      { key: 'evidence_hash', label: 'Hash', type: 'code' }
    ], execute: auditConfigurationChanges
  },
  {
    code: 'AUD_REQUEST_TRACE', name: 'Trazabilidad completa de solicitud', category: 'AUDITORIA', description: 'Secuencia cronológica de estados, aprobaciones, entregas, custodias e incidentes vinculados a solicitudes.',
    requiredPermission: 'Reports.Audit', scopePermission: 'Requests.ReadAll', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'status', 'search'], detailView: 'requests',
    columns: [
      { key: 'request_number', label: 'Solicitud', type: 'code' }, { key: 'event_type', label: 'Evento', type: 'code' },
      { key: 'from_status', label: 'Estado anterior', type: 'status' }, { key: 'to_status', label: 'Estado nuevo', type: 'status' },
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'detail', label: 'Detalle', type: 'text' },
      { key: 'occurred_at', label: 'Fecha', type: 'datetime' }, { key: 'correlation_id', label: 'Correlación', type: 'code' },
      { key: 'related_entity_type', label: 'Entidad vinculada', type: 'code' }, { key: 'related_entity_id', label: 'ID vinculado', type: 'code' }
    ], execute: auditRequestTrace
  },
  {
    code: 'AUD_ASSET_TRACE', name: 'Trazabilidad completa de bien', category: 'AUDITORIA', description: 'Secuencia cronológica de cambios, entregas, custodias, inspecciones, incidentes, stock y mantenimiento por bien.',
    requiredPermission: 'Reports.Audit', scopePermission: 'Assets.Read', filters: ['dateFrom', 'dateTo', 'siteId', 'locationId', 'categoryId', 'status', 'search'], detailView: 'assets',
    columns: [
      { key: 'internal_code', label: 'Código', type: 'code' }, { key: 'asset_description', label: 'Bien', type: 'text' },
      { key: 'category', label: 'Categoría', type: 'text' }, { key: 'event_type', label: 'Evento', type: 'code' },
      { key: 'from_status', label: 'Estado anterior', type: 'status' }, { key: 'to_status', label: 'Estado nuevo', type: 'status' },
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'detail', label: 'Detalle', type: 'text' },
      { key: 'occurred_at', label: 'Fecha', type: 'datetime' }, { key: 'correlation_id', label: 'Correlación', type: 'code' },
      { key: 'related_entity_type', label: 'Entidad vinculada', type: 'code' }, { key: 'related_entity_id', label: 'ID vinculado', type: 'code' }
    ], execute: auditAssetTrace
  },
  {
    code: 'AUD_DENIED_ATTEMPTS', name: 'Intentos rechazados y fallos', category: 'AUDITORIA', description: 'Accesos denegados, autenticaciones fallidas, bloqueos de seguridad y operaciones con error auditado.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'audit',
    columns: [
      { key: 'actor', label: 'Actor', type: 'text' }, { key: 'action', label: 'Acción', type: 'code' },
      { key: 'entity_type', label: 'Entidad', type: 'code' }, { key: 'entity_id', label: 'ID entidad', type: 'code' },
      { key: 'result', label: 'Resultado', type: 'status' }, { key: 'error', label: 'Error', type: 'code' },
      { key: 'ip_address', label: 'IP', type: 'code' }, { key: 'equipment', label: 'Equipo', type: 'text' },
      { key: 'occurred_at', label: 'Fecha', type: 'datetime' }, { key: 'correlation_id', label: 'Correlación', type: 'code' }
    ], execute: auditDeniedAttempts
  },
  {
    code: 'AUD_REPORT_EXPORTS', name: 'Exportaciones generadas', category: 'AUDITORIA', description: 'Trazabilidad de archivos CSV, XLSX y PDF generados desde el módulo de informes.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'status', 'search'], detailView: 'reports',
    columns: [
      { key: 'report_code', label: 'Código', type: 'code' }, { key: 'report_name', label: 'Informe', type: 'text' },
      { key: 'format', label: 'Formato', type: 'status' }, { key: 'filename', label: 'Archivo', type: 'text' },
      { key: 'row_count', label: 'Filas', type: 'number' }, { key: 'byte_size', label: 'Bytes', type: 'number' },
      { key: 'sha256', label: 'SHA-256', type: 'code' }, { key: 'generated_by', label: 'Generado por', type: 'text' },
      { key: 'generated_at', label: 'Fecha', type: 'datetime' }, { key: 'status', label: 'Resultado', type: 'status' },
      { key: 'error_code', label: 'Error', type: 'code' }
    ], execute: auditReportExports
  },
  {
    code: 'AUD_REPORT_EXECUTIONS', name: 'Ejecuciones de informes', category: 'AUDITORIA', description: 'Historial de generación de informes y resultados.',
    requiredPermission: 'Reports.Audit', filters: ['dateFrom', 'dateTo', 'search'],
    columns: [
      { key: 'report_code', label: 'Código', type: 'text' }, { key: 'report_name', label: 'Informe', type: 'text' },
      { key: 'generated_by', label: 'Generado por', type: 'text' }, { key: 'generated_at', label: 'Fecha', type: 'datetime' },
      { key: 'row_count', label: 'Filas', type: 'number' }, { key: 'total_count', label: 'Total', type: 'number' },
      { key: 'status', label: 'Resultado', type: 'status' }, { key: 'duration_ms', label: 'Duración ms', type: 'number' }
    ], execute: executionHistory
  }
]);

function reportAllowed(user, report) {
  return can(user, report.requiredPermission) && (!report.scopePermission || can(user, report.scopePermission));
}

function reportForUser(code, user) {
  const report = REPORT_DEFINITIONS.find((item) => item.code === code);
  if (!report) throw reportError('Informe inexistente.', 'REPORT_NOT_FOUND', 404);
  if (!reportAllowed(user, report)) throw reportError('No tiene permiso sobre los datos de este informe.', 'REPORT_SOURCE_FORBIDDEN', 403);
  return report;
}

function serializeReport(report) {
  return {
    code: report.code,
    name: report.name,
    category: report.category,
    description: report.description,
    filters: report.filters.map((key) => FILTER_DEFINITIONS[key]),
    columns: report.columns,
    chart: report.chart || null,
    summary: report.summary || [],
    detailView: report.detailView || null
  };
}

function reportFilterOptions(user, availableDefinitions, db = getDb()) {
  const scopes = availableDefinitions.flatMap((report) => permissionAssignments(user, report.scopePermission || report.requiredPermission, db));
  const globalScope = scopes.some((scope) => !scope.site_id && !scope.location_id);
  const siteIds = new Set(scopes.filter((scope) => scope.site_id).map((scope) => scope.site_id));
  const locationIds = new Set(scopes.filter((scope) => scope.location_id).map((scope) => scope.location_id));
  for (const row of db.prepare(`SELECT id,site_id FROM storage_location WHERE id IN (${locationIds.size ? [...locationIds].map(() => '?').join(',') : "''"})`).all(...locationIds)) siteIds.add(row.site_id);

  let sites;
  let locations;
  if (globalScope) {
    sites = db.prepare('SELECT id,code,name FROM site WHERE active=1 ORDER BY code').all();
    locations = db.prepare('SELECT id,site_id,code,name FROM storage_location WHERE active=1 ORDER BY code').all();
  } else {
    const siteList = [...siteIds];
    const locationList = [...locationIds];
    sites = siteList.length ? db.prepare(`SELECT id,code,name FROM site WHERE active=1 AND id IN (${siteList.map(() => '?').join(',')}) ORDER BY code`).all(...siteList) : [];
    const clauses = [];
    const params = [];
    if (siteList.length) { clauses.push(`site_id IN (${siteList.map(() => '?').join(',')})`); params.push(...siteList); }
    if (locationList.length) { clauses.push(`id IN (${locationList.map(() => '?').join(',')})`); params.push(...locationList); }
    locations = clauses.length ? db.prepare(`SELECT id,site_id,code,name FROM storage_location WHERE active=1 AND (${clauses.join(' OR ')}) ORDER BY code`).all(...params) : [];
  }
  const categories = availableDefinitions.some((report) => report.filters.includes('categoryId'))
    ? db.prepare('SELECT id,code,name FROM asset_category WHERE active=1 AND deleted_at IS NULL ORDER BY code').all()
    : [];
  return { sites, locations, categories };
}

function getReportCatalog(user) {
  if (!can(user, 'Reports.Read')) throw reportError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const availableDefinitions = REPORT_DEFINITIONS.filter((report) => reportAllowed(user, report));
  const reports = availableDefinitions.map(serializeReport);
  const categoryCodes = new Set(reports.map((report) => report.category));
  return {
    phase: 30,
    categories: CATEGORY_DEFINITIONS.filter((category) => categoryCodes.has(category.code)),
    reports,
    options: reportFilterOptions(user, availableDefinitions)
  };
}

function recordExecution(db, { report, request, context, result, status, durationMs, errorCode = null }) {
  const id = randomUUID();
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO report_execution(id,report_code,report_name,category,parameters_json,page,page_size,row_count,total_count,generated_by_user_id,site_id,location_id,generated_at,status,duration_ms,error_code,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, report.code, report.name, report.category, JSON.stringify(request.filters || {}), request.page, request.pageSize,
      result?.rows?.length || 0, result?.total || 0, context.user.id, request.filters.siteId || null, request.filters.locationId || null,
      now, status, durationMs, errorCode, context.correlationId || null, now);
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action: 'REPORT.GENERATE',
    entityType: 'report_execution',
    entityId: id,
    after: { reportCode: report.code, filters: request.filters, page: request.page, pageSize: request.pageSize, rowCount: result?.rows?.length || 0, totalCount: result?.total || 0 },
    correlationId: context.correlationId,
    ipAddress: context.ip,
    equipment: context.userAgent,
    result: status,
    durationMs,
    error: errorCode
  }, db);
  return id;
}

function generateReport(code, input, context) {
  const report = reportForUser(code, context.user);
  const request = normalizeRequest(input, report.filters);
  const db = getDb();
  const started = Date.now();
  try {
    const result = report.execute(db, context.user, request);
    const durationMs = Date.now() - started;
    const executionId = recordExecution(db, { report, request, context, result, status: 'SUCCESS', durationMs });
    return {
      executionId,
      generatedAt: new Date().toISOString(),
      report: serializeReport(report),
      filters: request.filters,
      pagination: { page: result.page, pageSize: result.pageSize, pages: result.pages, total: result.total },
      rows: result.rows
    };
  } catch (error) {
    const durationMs = Date.now() - started;
    try { recordExecution(db, { report, request, context, result: null, status: 'FAILED', durationMs, errorCode: error.code || 'REPORT_EXECUTION_FAILED' }); } catch {}
    throw error;
  }
}

function listReportExecutions(user, input = {}) {
  if (!can(user, 'Reports.Audit')) throw reportError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const { page, pageSize, ...filters } = input;
  const request = normalizeRequest({ filters, page, pageSize }, ['dateFrom', 'dateTo', 'search']);
  return executionHistory(getDb(), user, request);
}

module.exports = { getReportCatalog, generateReport, listReportExecutions, REPORT_DEFINITIONS, CATEGORY_DEFINITIONS, normalizeRequest, reportForUser, serializeReport, recordExecution };
