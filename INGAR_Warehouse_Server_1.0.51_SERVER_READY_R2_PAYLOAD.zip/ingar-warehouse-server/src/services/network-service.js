'use strict';

const os = require('node:os');
const http = require('node:http');
const { execFile } = require('node:child_process');
const { EventEmitter } = require('node:events');

const DEFAULT_OPERATION_PATH = '/mi-operacion';
const DEFAULT_POLL_INTERVAL_MS = 15_000;
const PROBE_PATH = '/api/v1/health/live';
const VIRTUAL_NAME = /(virtual|vmware|vbox|hyper-v|vethernet|docker|wsl|loopback|tunnel|tap|tun|bluetooth|hamachi|zerotier|tailscale|vpn|wireguard|openvpn)/i;
const ETHERNET_NAME = /(ethernet|eth\d*|en\d|eno\d|enp\d|lan)/i;
const WIFI_NAME = /(wi-?fi|wireless|wlan|wl\d|airport)/i;

let runtimePort = null;
let runtimeProtocol = 'http';
let monitorTimer = null;
let monitorListener = null;
let refreshInFlight = null;
let interfacesProvider = () => os.networkInterfaces();
let platformProvider = () => process.platform;
let metadataProvider = loadWindowsInterfaceMetadata;
let probeProvider = probeLanEndpoint;
let firewallProvider = readFirewallStatus;
let currentMetadata = [];
let revision = 0;
let currentStatus = unavailableStatus('NOT_INITIALIZED', 'El acceso móvil todavía no fue verificado.');
const events = new EventEmitter();

function safeNetworkInterfaces() {
  try {
    return interfacesProvider() || {};
  } catch {
    return {};
  }
}

function normalizeIpAddress(value) {
  const address = String(value || '').trim().toLowerCase();
  return address.startsWith('::ffff:') ? address.slice(7) : address;
}

function isLocalMachineAddress(value, networkInterfaces = safeNetworkInterfaces()) {
  const address = normalizeIpAddress(value);
  if (!address || address === '127.0.0.1' || address === '::1' || address === 'localhost') return true;
  for (const records of Object.values(networkInterfaces || {})) {
    for (const record of records || []) {
      if (normalizeIpAddress(record?.address) === address) return true;
    }
  }
  return false;
}

function isIpv4Private(address) {
  const parts = String(address || '').split('.').map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  if (parts[0] === 10) return true;
  if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return true;
  return parts[0] === 192 && parts[1] === 168;
}

function normalizeBoolean(value) {
  if (typeof value === 'boolean') return value;
  const text = String(value ?? '').trim().toLowerCase();
  if (['true', '1', 'yes', 'si', 'sí'].includes(text)) return true;
  if (['false', '0', 'no'].includes(text)) return false;
  return null;
}

function classifyInterface(name, metadata = {}) {
  const joined = `${name || ''} ${metadata.interfaceDescription || ''} ${metadata.mediaType || ''} ${metadata.physicalMediaType || ''}`;
  if (metadata.virtual === true || metadata.hardwareInterface === false || VIRTUAL_NAME.test(joined)) return 'virtual';
  if (/802\.11|native\s*802\.11|wireless|wi-?fi/i.test(joined) || WIFI_NAME.test(name || '')) return 'wifi';
  if (/802\.3|ethernet/i.test(joined) || ETHERNET_NAME.test(name || '')) return 'ethernet';
  return 'other';
}

function metadataMap(items = currentMetadata) {
  const map = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    const name = String(item?.name || item?.interfaceAlias || '').trim().toLowerCase();
    if (name) map.set(name, item);
  }
  return map;
}

function getLanAddresses(networkInterfaces = safeNetworkInterfaces(), metadataItems = currentMetadata) {
  const candidates = [];
  const metaByName = metadataMap(metadataItems);
  for (const [name, records] of Object.entries(networkInterfaces || {})) {
    const metadata = metaByName.get(String(name).toLowerCase()) || {};
    const status = String(metadata.status || '').toUpperCase();
    if (status && status !== 'UP') continue;
    for (const record of records || []) {
      const family = typeof record.family === 'string' ? record.family : (record.family === 4 ? 'IPv4' : String(record.family));
      const address = String(record.address || '');
      if (family !== 'IPv4' || record.internal || !isIpv4Private(address)) continue;
      const type = classifyInterface(name, metadata);
      candidates.push({
        name,
        address,
        family: 'IPv4',
        type,
        cidr: record.cidr || null,
        netmask: record.netmask || null,
        mac: record.mac || null,
        interfaceIndex: Number.isFinite(Number(metadata.interfaceIndex)) ? Number(metadata.interfaceIndex) : null,
        interfaceMetric: Number.isFinite(Number(metadata.interfaceMetric)) ? Number(metadata.interfaceMetric) : null,
        hasDefaultGateway: normalizeBoolean(metadata.hasDefaultGateway) === true,
        hardwareInterface: normalizeBoolean(metadata.hardwareInterface),
        virtual: normalizeBoolean(metadata.virtual) === true || type === 'virtual',
        status: status || null,
        metadataSource: metadata.source || null
      });
    }
  }
  return candidates.sort((left, right) => left.name.localeCompare(right.name) || left.address.localeCompare(right.address));
}

function candidateScore(candidate, hasNonVirtual) {
  let score = 0;
  if (candidate.hasDefaultGateway) score += 1000;
  if (candidate.status === 'UP') score += 250;
  if (candidate.hardwareInterface === true) score += 180;
  if (candidate.type === 'ethernet') score += 140;
  else if (candidate.type === 'wifi') score += 130;
  else if (candidate.type === 'other') score += 80;
  if (Number.isFinite(candidate.interfaceMetric)) score += Math.max(0, 100 - Math.min(candidate.interfaceMetric, 100));
  if (candidate.virtual) score -= hasNonVirtual ? 2000 : 500;
  return score;
}

function selectPreferredLanAddress(networkInterfaces = safeNetworkInterfaces(), metadataItems = currentMetadata) {
  const candidates = getLanAddresses(networkInterfaces, metadataItems);
  if (!candidates.length) return null;
  const hasNonVirtual = candidates.some((candidate) => !candidate.virtual);
  return [...candidates].sort((left, right) => {
    const score = candidateScore(right, hasNonVirtual) - candidateScore(left, hasNonVirtual);
    if (score) return score;
    const metricLeft = Number.isFinite(left.interfaceMetric) ? left.interfaceMetric : Number.MAX_SAFE_INTEGER;
    const metricRight = Number.isFinite(right.interfaceMetric) ? right.interfaceMetric : Number.MAX_SAFE_INTEGER;
    return metricLeft - metricRight || left.name.localeCompare(right.name) || left.address.localeCompare(right.address);
  })[0];
}

function normalizeOperationPath(pathname = DEFAULT_OPERATION_PATH) {
  const clean = String(pathname || DEFAULT_OPERATION_PATH).trim();
  return clean.startsWith('/') ? clean : `/${clean}`;
}

function normalizeProtocol(value = runtimeProtocol) {
  const protocol = String(value || '').trim().toLowerCase();
  return protocol === 'http' ? 'http' : null;
}

function buildOperationBaseUrl(port = runtimePort, networkInterfaces = safeNetworkInterfaces(), metadataItems = currentMetadata, protocol = runtimeProtocol) {
  const selected = selectPreferredLanAddress(networkInterfaces, metadataItems);
  const numericPort = Number(port);
  const activeProtocol = normalizeProtocol(protocol);
  if (!selected || !activeProtocol || !Number.isInteger(numericPort) || numericPort < 1 || numericPort > 65535) return null;
  return `${activeProtocol}://${selected.address}:${numericPort}`;
}

function buildOperationUrl(port = runtimePort, pathname = DEFAULT_OPERATION_PATH, networkInterfaces = safeNetworkInterfaces(), metadataItems = currentMetadata, protocol = runtimeProtocol) {
  const baseUrl = buildOperationBaseUrl(port, networkInterfaces, metadataItems, protocol);
  return baseUrl ? `${baseUrl}${normalizeOperationPath(pathname)}` : null;
}

function unavailableStatus(code, userMessage, details = {}) {
  return Object.freeze({
    available: false,
    message: 'ACCESO MÓVIL NO DISPONIBLE',
    userMessage,
    diagnosticCode: code,
    address: details.address || null,
    interfaceName: details.interfaceName || null,
    interfaceType: details.interfaceType || null,
    port: details.port || null,
    baseUrl: details.baseUrl || null,
    candidateCount: details.candidateCount || 0,
    selfProbe: details.selfProbe || 'NOT_RUN',
    firewallStatus: details.firewallStatus || 'UNKNOWN',
    metadataSource: details.metadataSource || null,
    transport: details.transport || 'HTTP',
    revision,
    checkedAt: new Date().toISOString()
  });
}

function readFirewallStatus() {
  const platform = platformProvider();
  if (platform !== 'win32') return { status: 'NOT_REQUIRED', ready: true };
  const status = String(process.env.IWC_FIREWALL_STATUS || 'UNKNOWN').trim().toUpperCase();
  return { status, ready: ['READY', 'NOT_REQUIRED'].includes(status) };
}

function statusSignature(status) {
  return JSON.stringify({
    available: status.available,
    address: status.address,
    diagnosticCode: status.diagnosticCode,
    selfProbe: status.selfProbe,
    firewallStatus: status.firewallStatus,
    transport: status.transport
  });
}

async function probeLanEndpoint({ address, port, timeoutMs = 1800 } = {}) {
  if (!address || !Number.isInteger(Number(port))) return { ok: false, code: 'INVALID_TARGET' };
  return new Promise((resolve) => {
    const request = http.get({
      hostname: address,
      port: Number(port),
      path: PROBE_PATH,
      timeout: timeoutMs,
      headers: { Accept: 'application/json' }
    }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => {
        try {
          const payload = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve({ ok: response.statusCode === 200 && payload.status === 'UP', statusCode: response.statusCode });
        } catch {
          resolve({ ok: false, code: 'INVALID_RESPONSE', statusCode: response.statusCode });
        }
      });
    });
    request.on('timeout', () => request.destroy(new Error('PROBE_TIMEOUT')));
    request.on('error', (error) => resolve({ ok: false, code: error.code || error.message || 'PROBE_ERROR' }));
  });
}

function powershellJson(script, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], {
      windowsHide: true,
      timeout: timeoutMs,
      maxBuffer: 1024 * 1024
    }, (error, stdout, stderr) => {
      if (error) return reject(Object.assign(error, { stderr }));
      try {
        const text = String(stdout || '').trim();
        if (!text) return resolve([]);
        const parsed = JSON.parse(text);
        resolve(Array.isArray(parsed) ? parsed : [parsed]);
      } catch (parseError) {
        reject(parseError);
      }
    });
  });
}

async function loadWindowsInterfaceMetadata() {
  if (platformProvider() !== 'win32') return [];
  const script = String.raw`
$ErrorActionPreference = 'Stop'
$adapters = @(Get-NetAdapter -IncludeHidden -ErrorAction Stop)
$configurations = @(Get-NetIPConfiguration -ErrorAction Stop)
$metrics = @(Get-NetIPInterface -AddressFamily IPv4 -ErrorAction Stop)
$result = foreach ($adapter in $adapters) {
  $configuration = $configurations | Where-Object { $_.InterfaceIndex -eq $adapter.ifIndex } | Select-Object -First 1
  $metric = $metrics | Where-Object { $_.InterfaceIndex -eq $adapter.ifIndex } | Sort-Object InterfaceMetric | Select-Object -First 1
  [pscustomobject]@{
    name = [string]$adapter.Name
    interfaceDescription = [string]$adapter.InterfaceDescription
    interfaceIndex = [int]$adapter.ifIndex
    status = [string]$adapter.Status
    hardwareInterface = [bool]$adapter.HardwareInterface
    virtual = [bool]$adapter.Virtual
    mediaType = [string]$adapter.MediaType
    physicalMediaType = [string]$adapter.PhysicalMediaType
    interfaceMetric = if ($metric) { [int]$metric.InterfaceMetric } else { $null }
    hasDefaultGateway = [bool]($configuration -and $configuration.IPv4DefaultGateway)
    source = 'WINDOWS_NETTCPIP'
  }
}
@($result) | ConvertTo-Json -Compress -Depth 4
`;
  try {
    return await powershellJson(script);
  } catch {
    return [];
  }
}

async function computeNetworkStatus() {
  const port = Number(runtimePort);
  if (normalizeProtocol(runtimeProtocol) !== 'http') {
    return unavailableStatus('MOBILE_ACCESS_TRANSPORT_NOT_READY', 'El acceso móvil todavía no está publicado en la red local.', { port: Number.isInteger(port) ? port : null, transport: String(runtimeProtocol || '').toUpperCase() });
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return unavailableStatus('PORT_NOT_READY', 'El servidor de acceso móvil todavía no está disponible.', { port: null });
  }
  currentMetadata = await metadataProvider();
  // Un usuario corporativo estándar puede no tener acceso a los cmdlets NetTCPIP.
  // En ese caso se continúa con os.networkInterfaces(), que no requiere elevación.
  const networkInterfaces = safeNetworkInterfaces();
  const candidates = getLanAddresses(networkInterfaces, currentMetadata);
  const selected = selectPreferredLanAddress(networkInterfaces, currentMetadata);
  if (!selected) {
    return unavailableStatus('NO_LAN_ADDRESS', 'Conecte la computadora y el celular a la misma red local.', { port, candidateCount: candidates.length, metadataSource: currentMetadata.length ? 'WINDOWS_NETTCPIP' : 'OS_FALLBACK' });
  }
  const baseUrl = `http://${selected.address}:${port}`;
  const probe = await probeProvider({ address: selected.address, port });
  if (!probe?.ok) {
    return unavailableStatus('LAN_SELF_PROBE_FAILED', 'El servidor no responde por la red local. Reinicie la aplicación o revise la conexión.', {
      address: selected.address,
      interfaceName: selected.name,
      interfaceType: selected.type,
      port,
      baseUrl,
      candidateCount: candidates.length,
      selfProbe: probe?.code || 'FAILED',
      firewallStatus: firewallProvider().status,
      metadataSource: selected.metadataSource || 'OS_FALLBACK',
      transport: 'HTTP',
    });
  }
  const firewall = firewallProvider();
  return Object.freeze({
    available: true,
    message: 'CÓDIGO QR DISPONIBLE',
    userMessage: 'El QR fue generado sin permisos administrativos. Verifique el acceso desde el celular en la misma red.',
    diagnosticCode: firewall.status === 'READY' ? 'READY' : 'QR_READY_LAN_UNCONFIRMED',
    address: selected.address,
    interfaceName: selected.name,
    interfaceType: selected.type,
    port,
    baseUrl,
    candidateCount: candidates.length,
    selfProbe: 'PASS',
    firewallStatus: firewall.status,
    metadataSource: selected.metadataSource || 'OS_FALLBACK',
    transport: 'HTTP',
    revision,
    checkedAt: new Date().toISOString()
  });
}

async function refreshNetworkStatus() {
  if (refreshInFlight) return refreshInFlight;
  refreshInFlight = (async () => {
    const previous = currentStatus;
    let next = await computeNetworkStatus();
    if (statusSignature(previous) !== statusSignature(next)) revision += 1;
    next = Object.freeze({ ...next, revision });
    currentStatus = next;
    if (statusSignature(previous) !== statusSignature(next)) events.emit('change', next, previous);
    return next;
  })().finally(() => { refreshInFlight = null; });
  return refreshInFlight;
}

function getNetworkStatus() {
  return { ...currentStatus };
}

function setInsecureTestMobileAccessRuntime({ port } = {}) {
  if (process.env.IWC_TEST_MODE !== '1') throw new Error('TEST_MOBILE_ACCESS_RUNTIME_FORBIDDEN');
  runtimePort = Number(port);
  runtimeProtocol = 'test-http';
  revision += 1;
  currentStatus = Object.freeze({
    available: true,
    message: 'ACCESO MÓVIL DE PRUEBA DISPONIBLE',
    userMessage: 'Entorno aislado de pruebas.',
    diagnosticCode: 'TEST_ONLY_HTTP',
    address: '127.0.0.1',
    interfaceName: 'TEST_LOOPBACK',
    interfaceType: 'test',
    port: runtimePort,
    baseUrl: `http://127.0.0.1:${runtimePort}`,
    candidateCount: 1,
    selfProbe: 'TEST',
    firewallStatus: 'NOT_REQUIRED',
    metadataSource: 'TEST_ONLY',
    transport: 'TEST_HTTP',
    revision,
    checkedAt: new Date().toISOString()
  });
  return { ...currentStatus };
}

async function setMobileAccessRuntime({ port, protocol = 'http' } = {}) {
  if (port !== undefined) runtimePort = Number(port);
  runtimeProtocol = String(protocol || '').toLowerCase();
  return refreshNetworkStatus();
}

function startNetworkMonitor({ intervalMs = DEFAULT_POLL_INTERVAL_MS, onChange } = {}) {
  stopNetworkMonitor();
  monitorListener = typeof onChange === 'function' ? onChange : null;
  if (monitorListener) events.on('change', monitorListener);
  monitorTimer = setInterval(() => { refreshNetworkStatus().catch(() => {}); }, Math.max(5_000, Number(intervalMs) || DEFAULT_POLL_INTERVAL_MS));
  monitorTimer.unref?.();
  return stopNetworkMonitor;
}

function stopNetworkMonitor() {
  if (monitorTimer) clearInterval(monitorTimer);
  monitorTimer = null;
  if (monitorListener) events.off('change', monitorListener);
  monitorListener = null;
}

function resetForTests() {
  stopNetworkMonitor();
  runtimePort = null;
  runtimeProtocol = 'http';
  currentMetadata = [];
  revision = 0;
  currentStatus = unavailableStatus('NOT_INITIALIZED', 'El acceso móvil todavía no fue verificado.');
  interfacesProvider = () => os.networkInterfaces();
  platformProvider = () => process.platform;
  metadataProvider = loadWindowsInterfaceMetadata;
  probeProvider = probeLanEndpoint;
  firewallProvider = readFirewallStatus;
  events.removeAllListeners();
}

function setTestProviders({ interfaces, platform, metadata, probe, firewall } = {}) {
  if (interfaces) interfacesProvider = interfaces;
  if (platform) platformProvider = platform;
  if (metadata) metadataProvider = metadata;
  if (probe) probeProvider = probe;
  if (firewall) firewallProvider = firewall;
}

module.exports = {
  DEFAULT_POLL_INTERVAL_MS,
  DEFAULT_OPERATION_PATH,
  PROBE_PATH,
  normalizeIpAddress,
  isLocalMachineAddress,
  isIpv4Private,
  classifyInterface,
  getLanAddresses,
  selectPreferredLanAddress,
  buildOperationBaseUrl,
  buildOperationUrl,
  normalizeProtocol,
  getNetworkStatus,
  setMobileAccessRuntime,
  setInsecureTestMobileAccessRuntime,
  refreshNetworkStatus,
  startNetworkMonitor,
  stopNetworkMonitor,
  loadWindowsInterfaceMetadata,
  probeLanEndpoint,
  setTestProviders,
  resetForTests,
  events
};
