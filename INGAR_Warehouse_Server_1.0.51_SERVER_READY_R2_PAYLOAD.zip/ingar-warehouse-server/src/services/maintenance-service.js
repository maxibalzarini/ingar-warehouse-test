'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, parseBoolean, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { enqueueNotification } = require('./notification-service');
const { scopeWhere, assertAssetScope, userHasScope } = require('../security/scope');

function error(status, code, message) { return Object.assign(new Error(message), { status, code }); }
function nowIso() { return new Date().toISOString(); }
function expectedVersion(input, row) {
  const version = Number(input.version);
  if (!Number.isInteger(version)) throw error(422, 'VERSION_REQUIRED', 'La versión es obligatoria.');
  if (version !== row.version) throw error(409, 'CONCURRENCY_CONFLICT', 'El registro fue modificado por otra operación.');
}
function audit(db, context, action, entityType, entityId, before, after, reason = null) {
  appendAudit({ actorUserId: context.user?.id || null, actorRole: context.user?.roleCodes?.join(',') || null, action, entityType, entityId, before, after, reason, correlationId: context.correlationId || randomUUID(), source: context.source || 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
}
function getAsset(id, db = getDb()) {
  const row = db.prepare(`SELECT a.*,c.nature AS category_nature,c.name AS category_name FROM asset a JOIN asset_category c ON c.id=a.category_id WHERE a.id=? AND a.deleted_at IS NULL`).get(id);
  if (!row) throw error(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  return row;
}
function nextNumber(db) {
  const year = new Date().getUTCFullYear();
  const n = db.prepare("SELECT COUNT(*) AS n FROM maintenance_order WHERE order_number LIKE ?").get(`MNT-${year}-%`).n + 1;
  return `MNT-${year}-${String(n).padStart(6, '0')}`;
}
function currentMeter(assetId, triggerType, db = getDb()) {
  if (triggerType === 'ODOMETRO') {
    const profile = db.prepare('SELECT current_odometer AS value FROM vehicle_profile WHERE asset_id=?').get(assetId);
    return Number(profile?.value ?? db.prepare('SELECT odometer AS value FROM asset WHERE id=?').get(assetId)?.value ?? 0);
  }
  if (triggerType === 'HOROMETRO') return Number(db.prepare('SELECT current_hourmeter AS value FROM vehicle_profile WHERE asset_id=?').get(assetId)?.value ?? 0);
  return null;
}
function computeNextDue(plan, baseDate = nowIso(), baseValue = null) {
  if (plan.trigger_type === 'CALENDARIO') {
    const from = new Date(baseDate);
    from.setUTCDate(from.getUTCDate() + Number(plan.interval_days));
    return { nextDueAt: from.toISOString(), nextDueValue: null };
  }
  if (plan.trigger_type === 'ODOMETRO' || plan.trigger_type === 'HOROMETRO') {
    return { nextDueAt: null, nextDueValue: Number(baseValue || 0) + Number(plan.interval_value) };
  }
  return { nextDueAt: null, nextDueValue: null };
}
function normalizePlan(input, asset, current = null, db = getDb()) {
  const triggerType = String(input.triggerType ?? current?.trigger_type ?? '').toUpperCase();
  if (!['CALENDARIO','ODOMETRO','HOROMETRO','MANUAL'].includes(triggerType)) throw error(422, 'MAINTENANCE_TRIGGER_INVALID', 'Tipo de disparador inválido.');
  if ((triggerType === 'ODOMETRO' || triggerType === 'HOROMETRO') && asset.category_nature !== 'VEHICULO') throw error(422, 'MAINTENANCE_METER_UNAVAILABLE', 'Odómetro y horómetro requieren un vehículo.');
  const intervalDays = triggerType === 'CALENDARIO' ? Number(input.intervalDays ?? current?.interval_days) : null;
  const intervalValue = ['ODOMETRO','HOROMETRO'].includes(triggerType) ? Number(input.intervalValue ?? current?.interval_value) : null;
  if (triggerType === 'CALENDARIO' && (!Number.isInteger(intervalDays) || intervalDays <= 0)) throw error(422, 'MAINTENANCE_INTERVAL_INVALID', 'El intervalo en días debe ser entero positivo.');
  if (['ODOMETRO','HOROMETRO'].includes(triggerType) && (!Number.isFinite(intervalValue) || intervalValue <= 0)) throw error(422, 'MAINTENANCE_INTERVAL_INVALID', 'El intervalo de medición debe ser positivo.');
  let nextDueAt = input.nextDueAt ? new Date(input.nextDueAt).toISOString() : current?.next_due_at || null;
  let nextDueValue = input.nextDueValue === '' || input.nextDueValue == null ? current?.next_due_value ?? null : Number(input.nextDueValue);
  if (!current && triggerType === 'CALENDARIO' && !nextDueAt) nextDueAt = computeNextDue({ trigger_type: triggerType, interval_days: intervalDays }).nextDueAt;
  if (!current && ['ODOMETRO','HOROMETRO'].includes(triggerType) && nextDueValue == null) nextDueValue = computeNextDue({ trigger_type: triggerType, interval_value: intervalValue }, nowIso(), currentMeter(asset.id, triggerType, db)).nextDueValue;
  return {
    code: requiredString(input.code ?? current?.code, 'code', { min: 2, max: 40, pattern: /^[A-Za-z0-9._-]+$/ }).toUpperCase(),
    name: requiredString(input.name ?? current?.name, 'name', { min: 3, max: 160 }),
    maintenanceType: String(input.maintenanceType ?? current?.maintenance_type ?? 'PREVENTIVO').toUpperCase(),
    triggerType, intervalDays, intervalValue,
    leadDays: safeInteger(input.leadDays ?? current?.lead_days, 7, 0, 365),
    blockingWhenOverdue: parseBoolean(input.blockingWhenOverdue, current ? Boolean(current.blocking_when_overdue) : true) ? 1 : 0,
    instructions: optionalString(input.instructions ?? current?.instructions, 'instructions', { max: 4000 }),
    nextDueAt, nextDueValue,
    active: parseBoolean(input.active, current ? Boolean(current.active) : true) ? 1 : 0
  };
}
function planSelect() {
  return `SELECT mp.*,a.internal_code,a.description,a.status AS asset_status,a.location_id,sl.site_id,c.nature AS category_nature,c.name AS category_name,
    vp.usage_unit,vp.km_per_hour,vp.current_odometer,vp.current_hourmeter
    FROM maintenance_plan mp JOIN asset a ON a.id=mp.asset_id JOIN asset_category c ON c.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN vehicle_profile vp ON vp.asset_id=a.id`;
}
function meterLabel(triggerType) { return triggerType === 'ODOMETRO' ? 'km' : triggerType === 'HOROMETRO' ? 'h' : ''; }
function meterStatusText(plan, db) {
  if (!['ODOMETRO','HOROMETRO'].includes(plan.trigger_type) || plan.next_due_value == null) return '';
  const current = currentMeter(plan.asset_id, plan.trigger_type, db);
  return `${current.toLocaleString('es-AR')} / ${Number(plan.next_due_value).toLocaleString('es-AR')} ${meterLabel(plan.trigger_type)}`;
}
function listMaintenancePlans(filters = {}, user = null, permission = 'Maintenance.Read') {
  const where = ['a.deleted_at IS NULL']; const args = [];
  if (filters.assetId) { where.push('mp.asset_id=?'); args.push(filters.assetId); }
  if (filters.active !== undefined) { where.push('mp.active=?'); args.push(filters.active === true || filters.active === 'true' ? 1 : 0); }
  if (filters.triggerType) { where.push('mp.trigger_type=?'); args.push(String(filters.triggerType).toUpperCase()); }
  if (user) { const scoped=scopeWhere(user,permission,'sl.site_id','a.location_id'); where.push(scoped.sql); args.push(...scoped.params); }
  return getDb().prepare(`${planSelect()} WHERE ${where.join(' AND ')} ORDER BY mp.active DESC,COALESCE(mp.next_due_at,'9999'),a.internal_code LIMIT ?`).all(...args, safeInteger(filters.limit, 300, 1, 1000));
}
function getMaintenancePlan(id, db = getDb(), user = null, permission = 'Maintenance.Read') {
  const row = db.prepare(`${planSelect()} WHERE mp.id=?`).get(id);
  if (!row) throw error(404, 'MAINTENANCE_PLAN_NOT_FOUND', 'Plan de mantenimiento no encontrado.');
  if (user) assertAssetScope(user,row.asset_id,permission,db);
  return row;
}

function createMaintenancePlan(input, context) {
  return transaction((db) => {
    const asset = getAsset(input.assetId, db); assertAssetScope(context.user,asset.id,'Maintenance.Manage',db); const data = normalizePlan(input, asset, null, db); const now = nowIso(); const id = randomUUID();
    if (!['PREVENTIVO','CORRECTIVO','INSPECCION_TECNICA'].includes(data.maintenanceType)) throw error(422, 'MAINTENANCE_TYPE_INVALID', 'Tipo de mantenimiento inválido.');
    db.prepare(`INSERT INTO maintenance_plan(id,asset_id,code,name,maintenance_type,trigger_type,interval_days,interval_value,lead_days,blocking_when_overdue,instructions,last_completed_at,last_completed_value,next_due_at,next_due_value,active,version,created_by_user_id,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,?,?,?,1,?,?,?)`).run(id, asset.id, data.code, data.name, data.maintenanceType, data.triggerType, data.intervalDays, data.intervalValue, data.leadDays, data.blockingWhenOverdue, data.instructions, data.nextDueAt, data.nextDueValue, data.active, context.user.id, now, now);
    const after = getMaintenancePlan(id, db); audit(db, context, 'MAINTENANCE.PLAN_CREATE', 'maintenance_plan', id, null, after); return after;
  });
}
function updateMaintenancePlan(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM maintenance_plan WHERE id=?').get(id); if (!current) throw error(404, 'MAINTENANCE_PLAN_NOT_FOUND', 'Plan no encontrado.'); assertAssetScope(context.user,current.asset_id,'Maintenance.Manage',db); expectedVersion(input, current);
    const asset = getAsset(current.asset_id, db); const data = normalizePlan(input, asset, current, db); const now = nowIso();
    db.prepare(`UPDATE maintenance_plan SET code=?,name=?,maintenance_type=?,trigger_type=?,interval_days=?,interval_value=?,lead_days=?,blocking_when_overdue=?,instructions=?,next_due_at=?,next_due_value=?,active=?,version=version+1,updated_at=? WHERE id=? AND version=?`)
      .run(data.code,data.name,data.maintenanceType,data.triggerType,data.intervalDays,data.intervalValue,data.leadDays,data.blockingWhenOverdue,data.instructions,data.nextDueAt,data.nextDueValue,data.active,now,id,current.version);
    const after=getMaintenancePlan(id,db); audit(db,context,'MAINTENANCE.PLAN_UPDATE','maintenance_plan',id,current,after); return after;
  });
}
function orderSelect() {
  return `SELECT mo.*,a.internal_code,a.description,a.status AS asset_status,a.location_id,sl.site_id,mp.code AS plan_code,mp.name AS plan_name,p.full_name AS assigned_person_name
    FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id
    LEFT JOIN maintenance_plan mp ON mp.id=mo.plan_id LEFT JOIN person p ON p.id=mo.assigned_person_id`;
}

function hydrateOrder(row, db = getDb()) {
  if (!row) return null;
  return { ...row,
    inspections: db.prepare('SELECT * FROM maintenance_inspection WHERE order_id=? ORDER BY inspected_at').all(row.id).map((x)=>({...x,checklist:JSON.parse(x.checklist_json||'{}')})),
    events: db.prepare('SELECT * FROM maintenance_event WHERE order_id=? ORDER BY occurred_at').all(row.id)
  };
}
function getMaintenanceOrder(id, db = getDb(), user = null, permission = 'Maintenance.Read') {
  const row = db.prepare(`${orderSelect()} WHERE mo.id=?`).get(id); if (!row) throw error(404,'MAINTENANCE_ORDER_NOT_FOUND','Orden de mantenimiento no encontrada.'); if(user)assertAssetScope(user,row.asset_id,permission,db); return hydrateOrder(row,db);
}
function listMaintenanceOrders(filters = {}, user = null, permission = 'Maintenance.Read') {
  const where=['1=1'];const args=[];
  const statuses=String(filters.statuses||'').split(',').map((value)=>value.trim().toUpperCase()).filter(Boolean);
  if(filters.assetId){where.push('mo.asset_id=?');args.push(filters.assetId);}
  if(statuses.length){where.push(`mo.status IN (${statuses.map(()=>'?').join(',')})`);args.push(...statuses);}
  else if(filters.status){where.push('mo.status=?');args.push(String(filters.status).toUpperCase());}
  if(filters.type){where.push('mo.maintenance_type=?');args.push(String(filters.type).toUpperCase());}
  if(filters.overdue==='true'||filters.overdue===true){where.push("(mo.status='VENCIDA' OR (mo.status IN ('PROGRAMADA','EN_PROGRESO') AND mo.due_at IS NOT NULL AND mo.due_at<?))");args.push(filters.dueBefore?new Date(filters.dueBefore).toISOString():new Date().toISOString());}
  else if(filters.dueBefore){where.push('mo.due_at<?');args.push(new Date(filters.dueBefore).toISOString());}
  if(filters.dueFrom){where.push('mo.due_at>=?');args.push(new Date(filters.dueFrom).toISOString());}
  if(filters.dueTo){where.push('mo.due_at<?');args.push(new Date(filters.dueTo).toISOString());}
  if(user){const scoped=scopeWhere(user,permission,'sl.site_id','a.location_id');where.push(scoped.sql);args.push(...scoped.params);}
  return getDb().prepare(`${orderSelect()} WHERE ${where.join(' AND ')} ORDER BY CASE mo.status WHEN 'EN_PROGRESO' THEN 0 WHEN 'VENCIDA' THEN 1 WHEN 'PROGRAMADA' THEN 2 ELSE 3 END,COALESCE(mo.due_at,mo.scheduled_at),mo.created_at DESC LIMIT ?`).all(...args,safeInteger(filters.limit,300,1,1000)).map((r)=>hydrateOrder(r));
}
function addEvent(db, orderId, from, to, context, reason, at = nowIso()) {
  db.prepare('INSERT INTO maintenance_event(id,order_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(randomUUID(),orderId,from||null,to,context.user?.id||null,reason||null,at,context.correlationId||randomUUID(),at);
}
function createMaintenanceOrder(input, context, options = {}) {
  return transaction((db)=>createMaintenanceOrderInDb(db,input,context,options));
}
function createMaintenanceOrderInDb(db,input,context,options={}) {
  if(input.clientOrderId){const existing=db.prepare('SELECT id FROM maintenance_order WHERE client_order_id=?').get(input.clientOrderId);if(existing)return{order:getMaintenanceOrder(existing.id,db),idempotent:true};}
  const plan=input.planId?db.prepare('SELECT * FROM maintenance_plan WHERE id=? AND active=1').get(input.planId):null;if(input.planId&&!plan)throw error(422,'MAINTENANCE_PLAN_INVALID','Plan inexistente o inactivo.');
  const asset=getAsset(input.assetId||plan?.asset_id,db); assertAssetScope(context.user,asset.id,'Maintenance.Manage',db); if(plan&&plan.asset_id!==asset.id)throw error(422,'MAINTENANCE_PLAN_ASSET_MISMATCH','El plan no corresponde al bien.');
  const type=String(input.maintenanceType||plan?.maintenance_type||'CORRECTIVO').toUpperCase();if(!['PREVENTIVO','CORRECTIVO','INSPECCION_TECNICA'].includes(type))throw error(422,'MAINTENANCE_TYPE_INVALID','Tipo inválido.');
  const scheduledAt=input.scheduledAt?new Date(input.scheduledAt).toISOString():nowIso(); const dueAt=input.dueAt?new Date(input.dueAt).toISOString():(plan?.next_due_at||null); const now=nowIso();
  const status=dueAt&&dueAt<now?'VENCIDA':'PROGRAMADA';const id=randomUUID();const description=requiredString(input.description||plan?.instructions||plan?.name||'Mantenimiento programado','description',{min:3,max:3000});
  const meterType=plan&&['ODOMETRO','HOROMETRO'].includes(plan.trigger_type)?plan.trigger_type:null;const meterAtOpen=meterType?currentMeter(asset.id,meterType,db):null;
  db.prepare(`INSERT INTO maintenance_order(id,order_number,client_order_id,plan_id,asset_id,maintenance_type,priority,status,scheduled_at,due_at,started_at,completed_at,assigned_person_id,meter_type,meter_at_open,meter_at_close,description,findings,work_performed,result,asset_status_before,generated_by_scheduler,version,created_by_user_id,correlation_id,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,NULL,NULL,?,?,?,NULL,?,NULL,NULL,NULL,?, ?,1,?,?,?,?)`)
    .run(id,nextNumber(db),input.clientOrderId||null,plan?.id||null,asset.id,type,String(input.priority||'MEDIA').toUpperCase(),status,scheduledAt,dueAt,input.assignedPersonId||null,meterType,meterAtOpen,description,asset.status,options.generatedByScheduler?1:0,context.user?.id||options.systemUserId,context.correlationId||randomUUID(),now,now);
  addEvent(db,id,null,status,context,options.reason||'Orden creada.',now);
  const after=getMaintenanceOrder(id,db);audit(db,context,'MAINTENANCE.ORDER_CREATE','maintenance_order',id,null,after,options.reason);return{order:after,idempotent:false};
}
function startMaintenanceOrder(id,input,context){return transaction((db)=>{const current=db.prepare('SELECT * FROM maintenance_order WHERE id=?').get(id);if(!current)throw error(404,'MAINTENANCE_ORDER_NOT_FOUND','Orden no encontrada.');assertAssetScope(context.user,current.asset_id,'Maintenance.Execute',db);expectedVersion(input,current);if(!['PROGRAMADA','VENCIDA'].includes(current.status))throw error(409,'MAINTENANCE_START_NOT_ALLOWED','La orden no puede iniciarse.');const asset=getAsset(current.asset_id,db);if(['PERDIDO','BAJA'].includes(asset.status))throw error(409,'ASSET_MAINTENANCE_UNAVAILABLE','El bien no admite mantenimiento en su estado actual.');const now=nowIso();db.prepare("UPDATE maintenance_order SET status='EN_PROGRESO',started_at=?,started_by_user_id=?,asset_status_before=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now,context.user.id,asset.status,now,id,current.version);db.prepare("UPDATE asset SET status='MANTENIMIENTO',version=version+1,updated_at=? WHERE id=? AND status NOT IN ('PERDIDO','BAJA')").run(now,asset.id);addEvent(db,id,current.status,'EN_PROGRESO',context,requiredString(input.reason,'reason',{min:5,max:1500}),now);const after=getMaintenanceOrder(id,db);audit(db,context,'MAINTENANCE.ORDER_START','maintenance_order',id,current,after,input.reason);return after;});}
function assetDispositionAfterMaintenance(db,assetId,result){if(result==='NO_APTO')return'BLOQUEADO';if(db.prepare("SELECT 1 FROM operational_block WHERE status='ACTIVO' AND target_type='ACTIVO' AND target_id=? LIMIT 1").get(assetId))return'BLOQUEADO';if(db.prepare("SELECT 1 FROM custody WHERE asset_id=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA') LIMIT 1").get(assetId))return'EN_CUSTODIA';if(db.prepare("SELECT 1 FROM asset_reservation WHERE asset_id=? AND status='ACTIVA' LIMIT 1").get(assetId))return'RESERVADO';return'DISPONIBLE';}
function completeMaintenanceOrder(id,input,context){return transaction((db)=>{const current=db.prepare('SELECT * FROM maintenance_order WHERE id=?').get(id);if(!current)throw error(404,'MAINTENANCE_ORDER_NOT_FOUND','Orden no encontrada.');assertAssetScope(context.user,current.asset_id,'Maintenance.Complete',db);expectedVersion(input,current);if(current.status!=='EN_PROGRESO')throw error(409,'MAINTENANCE_COMPLETE_NOT_ALLOWED','La orden debe estar en progreso.');const result=String(input.result||'').toUpperCase();if(!['APTO','APTO_CON_OBSERVACIONES','NO_APTO'].includes(result))throw error(422,'MAINTENANCE_RESULT_INVALID','Resultado inválido.');const findings=requiredString(input.findings,'findings',{min:3,max:4000});const work=requiredString(input.workPerformed,'workPerformed',{min:3,max:4000});const now=nowIso();let meterAtClose=input.meterAtClose==null?current.meter_at_open:Number(input.meterAtClose);if(current.meter_at_open!=null&&meterAtClose<current.meter_at_open)throw error(422,'MAINTENANCE_METER_ROLLBACK','La medición final no puede disminuir.');
    db.prepare("UPDATE maintenance_order SET status='COMPLETADA',completed_at=?,completed_by_user_id=?,meter_at_close=?,findings=?,work_performed=?,result=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now,context.user.id,meterAtClose,findings,work,result,now,id,current.version);
    if(input.checklist||current.maintenance_type==='INSPECCION_TECNICA'){const inspectionId=randomUUID();const condition=String(input.condition||(result==='NO_APTO'?'DANADO':result==='APTO_CON_OBSERVACIONES'?'OBSERVADO':'CONFORME')).toUpperCase();db.prepare('INSERT INTO maintenance_inspection(id,order_id,asset_id,inspector_person_id,checklist_json,condition,result,observations,inspected_at,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(inspectionId,id,current.asset_id,input.inspectorPersonId||context.user.personId,JSON.stringify(input.checklist||{}),condition,result,optionalString(input.observations,'observations',{max:3000}),now,context.user.id,now);}
    const plan=current.plan_id?db.prepare('SELECT * FROM maintenance_plan WHERE id=?').get(current.plan_id):null;if(plan){const next=computeNextDue(plan,now,meterAtClose);db.prepare('UPDATE maintenance_plan SET last_completed_at=?,last_completed_value=?,next_due_at=?,next_due_value=?,version=version+1,updated_at=? WHERE id=?').run(now,meterAtClose,next.nextDueAt,next.nextDueValue,now,plan.id);}
    const status=assetDispositionAfterMaintenance(db,current.asset_id,result);db.prepare('UPDATE asset SET status=?,version=version+1,updated_at=? WHERE id=?').run(status,now,current.asset_id);addEvent(db,id,'EN_PROGRESO','COMPLETADA',context,requiredString(input.reason||'Trabajo completado.','reason',{min:5,max:1500}),now);const after=getMaintenanceOrder(id,db);audit(db,context,'MAINTENANCE.ORDER_COMPLETE','maintenance_order',id,current,after,input.reason);return after;});}
function cancelMaintenanceOrder(id,input,context){return transaction((db)=>{const current=db.prepare('SELECT * FROM maintenance_order WHERE id=?').get(id);if(!current)throw error(404,'MAINTENANCE_ORDER_NOT_FOUND','Orden no encontrada.');assertAssetScope(context.user,current.asset_id,'Maintenance.Complete',db);expectedVersion(input,current);if(!['BORRADOR','PROGRAMADA','VENCIDA'].includes(current.status))throw error(409,'MAINTENANCE_CANCEL_NOT_ALLOWED','La orden no puede cancelarse.');const reason=requiredString(input.reason,'reason',{min:5,max:1500});const now=nowIso();db.prepare("UPDATE maintenance_order SET status='CANCELADA',cancelled_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(context.user.id,now,id,current.version);addEvent(db,id,current.status,'CANCELADA',context,reason,now);const after=getMaintenanceOrder(id,db);audit(db,context,'MAINTENANCE.ORDER_CANCEL','maintenance_order',id,current,after,reason);return after;});}
function planIsDue(plan, db, now=new Date()){if(plan.trigger_type==='CALENDARIO')return plan.next_due_at&&new Date(plan.next_due_at)<=now;if(['ODOMETRO','HOROMETRO'].includes(plan.trigger_type))return plan.next_due_value!=null&&currentMeter(plan.asset_id,plan.trigger_type,db)>=Number(plan.next_due_value);return false;}
function planIsApproaching(plan, db, now=new Date()){if(plan.trigger_type==='CALENDARIO'&&plan.next_due_at){const lead=new Date(now.getTime()+Number(plan.lead_days||0)*86400000);return new Date(plan.next_due_at)<=lead;}if(['ODOMETRO','HOROMETRO'].includes(plan.trigger_type)&&plan.next_due_value!=null){const value=currentMeter(plan.asset_id,plan.trigger_type,db);const margin=Math.max(1,Number(plan.interval_value||0)*0.1);return value>=Number(plan.next_due_value)-margin;}return false;}
function maintenanceRecipients(db, plan) {
  const users = db.prepare("SELECT ua.id,ua.person_id FROM user_account ua WHERE ua.active=1 AND ua.deleted_at IS NULL").all();
  return users.filter((user) => userHasScope({ id: user.id }, plan.site_id, plan.location_id, 'Maintenance.Read', db));
}

function scanMaintenanceDue(db, context) {
  const plans = db.prepare(`${planSelect()} WHERE mp.active=1 AND a.deleted_at IS NULL`).all();
  let processed = 0; let generated = 0; let blocked = 0; let notified = 0;
  const now = new Date();
  for (const plan of plans) {
    processed += 1;
    const due = planIsDue(plan, db, now);
    const approaching = !due && planIsApproaching(plan, db, now);
    if (!due && !approaching) continue;
    const keyBase = `maintenance:${plan.id}:${plan.next_due_at || plan.next_due_value || 'manual'}`;
    const users = maintenanceRecipients(db, plan);
    if (due) {
      let open = db.prepare("SELECT id FROM maintenance_order WHERE plan_id=? AND status IN ('PROGRAMADA','VENCIDA','EN_PROGRESO') ORDER BY created_at DESC LIMIT 1").get(plan.id);
      if (!open) {
        const created = createMaintenanceOrderInDb(db, {
          clientOrderId: `scheduler:${keyBase}`, planId: plan.id, assetId: plan.asset_id,
          maintenanceType: plan.maintenance_type, priority: plan.blocking_when_overdue ? 'ALTA' : 'MEDIA',
          scheduledAt: now.toISOString(), dueAt: plan.next_due_at, description: plan.instructions || plan.name
        }, context, { generatedByScheduler: true, reason: 'Generada automáticamente por vencimiento.' });
        open = { id: created.order.id }; generated += 1;
      }
      const order = db.prepare('SELECT * FROM maintenance_order WHERE id=?').get(open.id);
      if (order.status === 'PROGRAMADA') {
        db.prepare("UPDATE maintenance_order SET status='VENCIDA',version=version+1,updated_at=? WHERE id=?").run(now.toISOString(), order.id);
        addEvent(db, order.id, 'PROGRAMADA', 'VENCIDA', context, 'Vencimiento detectado por scheduler.', now.toISOString());
      }
      if (plan.blocking_when_overdue && !['MANTENIMIENTO','PERDIDO','BAJA','EN_CUSTODIA'].includes(plan.asset_status)) {
        db.prepare("UPDATE asset SET status='MANTENIMIENTO',version=version+1,updated_at=? WHERE id=?").run(now.toISOString(), plan.asset_id); blocked += 1;
      }
      for (const user of users) {
        const meterText = meterStatusText(plan, db);
        const result = enqueueNotification({ recipientUserId: user.id, recipientPersonId: user.person_id, type: 'MANTENIMIENTO_VENCIDO', subject: `Mantenimiento vencido: ${plan.internal_code}`, body: `${plan.name} requiere intervención${meterText ? ` (${meterText})` : ''}. El bien quedó ${plan.blocking_when_overdue ? 'fuera de disponibilidad' : 'señalizado'}.`, entityType: 'maintenance_plan', entityId: plan.id, dedupKey: `${keyBase}:overdue:${user.id}` }, db);
        if (!result.idempotent) notified += 1;
      }
    } else {
      for (const user of users) {
        const meterText = meterStatusText(plan, db);
        const result = enqueueNotification({ recipientUserId: user.id, recipientPersonId: user.person_id, type: 'MANTENIMIENTO_PROXIMO', subject: `Mantenimiento próximo: ${plan.internal_code}`, body: `${plan.name} se aproxima a su condición de vencimiento${meterText ? ` (${meterText})` : ''}.`, entityType: 'maintenance_plan', entityId: plan.id, dedupKey: `${keyBase}:upcoming:${user.id}` }, db);
        if (!result.idempotent) notified += 1;
      }
    }
  }
  return { processed, generated, blocked, notified };
}

module.exports={listMaintenancePlans,getMaintenancePlan,createMaintenancePlan,updateMaintenancePlan,listMaintenanceOrders,getMaintenanceOrder,createMaintenanceOrder,startMaintenanceOrder,completeMaintenanceOrder,cancelMaintenanceOrder,scanMaintenanceDue,currentMeter};
