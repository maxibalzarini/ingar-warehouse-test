'use strict';

const zlib = require('node:zlib');

function decodeXml(value) {
  return String(value || '')
    .replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"')
    .replaceAll('&apos;', "'").replaceAll('&amp;', '&');
}

function parseCsv(text) {
  const source = String(text || '').replace(/^\uFEFF/, '');
  const firstLine = source.split(/\r?\n/, 1)[0] || '';
  const delimiter = (firstLine.match(/;/g) || []).length > (firstLine.match(/,/g) || []).length ? ';' : ',';
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quoted) {
      if (char === '"' && source[index + 1] === '"') { field += '"'; index += 1; }
      else if (char === '"') quoted = false;
      else field += char;
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === delimiter) { row.push(field); field = ''; }
    else if (char === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += char;
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows.filter((item) => item.some((cell) => String(cell).trim() !== ''));
}

function unzipEntries(buffer) {
  const signature = 0x06054b50;
  let eocd = -1;
  for (let offset = Math.max(0, buffer.length - 65557); offset <= buffer.length - 22; offset += 1) {
    if (buffer.readUInt32LE(offset) === signature) eocd = offset;
  }
  if (eocd < 0) throw new Error('XLSX inválido: no se encontró el directorio ZIP.');
  const entriesCount = buffer.readUInt16LE(eocd + 10);
  if (entriesCount > 1000) throw new Error('XLSX inválido: demasiadas entradas ZIP.');
  let totalUncompressed = 0;
  let cursor = buffer.readUInt32LE(eocd + 16);
  const entries = new Map();
  for (let count = 0; count < entriesCount; count += 1) {
    if (buffer.readUInt32LE(cursor) !== 0x02014b50) throw new Error('XLSX inválido: directorio ZIP corrupto.');
    const method = buffer.readUInt16LE(cursor + 10);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    if (uncompressedSize > 10 * 1024 * 1024) throw new Error('XLSX inválido: entrada ZIP demasiado grande.');
    totalUncompressed += uncompressedSize;
    if (totalUncompressed > 25 * 1024 * 1024) throw new Error('XLSX inválido: contenido descomprimido excesivo.');
    const filenameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localOffset = buffer.readUInt32LE(cursor + 42);
    const name = buffer.subarray(cursor + 46, cursor + 46 + filenameLength).toString('utf8');
    if (buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new Error('XLSX inválido: entrada ZIP corrupta.');
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataStart, dataStart + compressedSize);
    const bytes = method === 0 ? Buffer.from(compressed) : method === 8 ? zlib.inflateRawSync(compressed) : null;
    if (!bytes) throw new Error(`XLSX inválido: compresión ZIP no soportada (${method}).`);
    entries.set(name, bytes);
    cursor += 46 + filenameLength + extraLength + commentLength;
  }
  return entries;
}

function columnIndex(reference) {
  const letters = String(reference || '').match(/^[A-Z]+/i)?.[0]?.toUpperCase() || 'A';
  let result = 0;
  for (const letter of letters) result = result * 26 + letter.charCodeAt(0) - 64;
  return result - 1;
}

function xmlAttribute(attrs, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return decodeXml(String(attrs || '').match(new RegExp(`(?:^|\\s)${escaped}="([^"]*)"`))?.[1] || '');
}

function resolveWorkbookSheets(entries) {
  const workbookXml = entries.get('xl/workbook.xml')?.toString('utf8') || '';
  const relsXml = entries.get('xl/_rels/workbook.xml.rels')?.toString('utf8') || '';
  const relationships = new Map();
  for (const match of relsXml.matchAll(/<Relationship\b([^>]*?)(?:\/>|>\s*<\/Relationship>)/g)) {
    const id = xmlAttribute(match[1], 'Id');
    const target = xmlAttribute(match[1], 'Target');
    const type = xmlAttribute(match[1], 'Type');
    if (id && target && /\/worksheet$/i.test(type)) relationships.set(id, target);
  }
  const sheets = [];
  for (const match of workbookXml.matchAll(/<sheet\b([^>]*?)(?:\/>|>\s*<\/sheet>)/g)) {
    const name = xmlAttribute(match[1], 'name');
    const relId = xmlAttribute(match[1], 'r:id');
    const target = relationships.get(relId);
    if (!target) continue;
    const normalized = require('node:path').posix.normalize(`xl/${target.replace(/^\/+/, '')}`.replace(/^xl\/xl\//, 'xl/'));
    sheets.push({ name, path: normalized });
  }
  if (sheets.length) return sheets;
  return [...entries.keys()]
    .filter((name) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(name))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
    .map((sheetPath, index) => ({ name: `Hoja ${index + 1}`, path: sheetPath }));
}

function parseWorksheetXml(sheetXml, sharedStrings) {
  const rows = [];
  for (const rowMatch of sheetXml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
    const row = [];
    const cellPattern = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;
    for (const cellMatch of rowMatch[1].matchAll(cellPattern)) {
      const attrs = cellMatch[1] || '';
      const body = cellMatch[2] || '';
      const reference = xmlAttribute(attrs, 'r') || `A${rows.length + 1}`;
      const type = xmlAttribute(attrs, 't');
      const valueMatch = body.match(/<v>([\s\S]*?)<\/v>/);
      let value = '';
      if (type === 'inlineStr') {
        value = decodeXml([...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((part) => part[1]).join(''));
      } else if (type === 's') {
        const sharedIndex = Number.parseInt(valueMatch?.[1] || '', 10);
        value = Number.isInteger(sharedIndex) ? (sharedStrings[sharedIndex] ?? '') : '';
      } else if (type === 'b') {
        value = valueMatch?.[1] === '1' ? 'TRUE' : 'FALSE';
      } else {
        value = decodeXml(valueMatch?.[1] ?? body.match(/<t\b[^>]*>([\s\S]*?)<\/t>/)?.[1] ?? '');
      }
      row[columnIndex(reference)] = value;
    }
    rows.push(Array.from({ length: row.length }, (_, index) => row[index] ?? ''));
  }
  return rows.filter((item) => item.some((cell) => String(cell).trim() !== ''));
}

function parseXlsx(buffer, options = {}) {
  const entries = unzipEntries(buffer);
  const sharedXml = entries.get('xl/sharedStrings.xml')?.toString('utf8') || '';
  const sharedStrings = [...sharedXml.matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)]
    .map((match) => decodeXml([...match[1].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((part) => part[1]).join('')));
  const sheets = resolveWorkbookSheets(entries);
  if (!sheets.length) throw new Error('XLSX inválido: no contiene hojas legibles.');
  const requestedName = String(options.sheetName || '').trim().toLocaleLowerCase('es');
  const selected = requestedName
    ? sheets.find((sheet) => sheet.name.toLocaleLowerCase('es') === requestedName)
    : sheets[0];
  if (!selected) throw new Error(`XLSX inválido: no existe la hoja ${options.sheetName}.`);
  const sheetXml = entries.get(selected.path)?.toString('utf8');
  if (!sheetXml) throw new Error(`XLSX inválido: no fue posible leer la hoja ${selected.name}.`);
  return parseWorksheetXml(sheetXml, sharedStrings);
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let value = n;
    for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xEDB88320 ^ (value >>> 1) : value >>> 1;
    table[n] = value >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let crc = 0xFFFFFFFF;
  for (const byte of buffer) crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function zipStore(files) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  for (const [name, content] of files) {
    const nameBytes = Buffer.from(name, 'utf8');
    const data = Buffer.isBuffer(content) ? content : Buffer.from(content, 'utf8');
    const crc = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0, 6); local.writeUInt16LE(0, 8);
    local.writeUInt32LE(crc, 14); local.writeUInt32LE(data.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(nameBytes.length, 26);
    localParts.push(local, nameBytes, data);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(0, 8); central.writeUInt16LE(0, 10);
    central.writeUInt32LE(crc, 16); central.writeUInt32LE(data.length, 20); central.writeUInt32LE(data.length, 24); central.writeUInt16LE(nameBytes.length, 28); central.writeUInt32LE(offset, 42);
    centralParts.push(central, nameBytes);
    offset += local.length + nameBytes.length + data.length;
  }
  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(files.length, 8); eocd.writeUInt16LE(files.length, 10); eocd.writeUInt32LE(centralSize, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...localParts, ...centralParts, eocd]);
}

function xmlEscape(value) {
  return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&apos;');
}

function excelColumnName(index) {
  let number = index + 1;
  let letters = '';
  while (number > 0) {
    const remainder = (number - 1) % 26;
    letters = String.fromCharCode(65 + remainder) + letters;
    number = Math.floor((number - 1) / 26);
  }
  return letters;
}

function safeSheetName(value) {
  return String(value || 'Bienes').replace(/[\\/*?:\[\]]/g, ' ').trim().slice(0, 31) || 'Bienes';
}

function createXlsx(rows, options = {}) {
  const titleRow = Number(options.titleRow) || 0;
  const metadataRows = new Set((options.metadataRows || []).map(Number));
  const headerRow = Number(options.headerRow) || 1;
  const freezeRow = Number(options.freezeRow) || 0;
  const maxColumns = Math.max(1, ...rows.map((row) => row.length));
  const lastColumn = excelColumnName(maxColumns - 1);
  const columnWidths = Array.from({ length: maxColumns }, (_, index) => {
    const configured = Number(options.columnWidths?.[index]);
    if (Number.isFinite(configured) && configured > 0) return Math.min(80, Math.max(5, configured));
    const maxText = rows.slice(0, 250).reduce((max, row) => Math.max(max, String(row[index] ?? '').length), 8);
    return Math.min(38, Math.max(10, maxText + 2));
  });
  const sheetRows = rows.map((row, rowIndex) => {
    const rowNumber = rowIndex + 1;
    const style = rowNumber === titleRow ? 1 : metadataRows.has(rowNumber) ? 2 : rowNumber === headerRow ? 3 : 4;
    const height = rowNumber === titleRow ? ' ht="24" customHeight="1"' : rowNumber === headerRow ? ' ht="22" customHeight="1"' : '';
    const cells = row.map((cell, column) => {
      const reference = `${excelColumnName(column)}${rowNumber}`;
      if (typeof cell === 'number' && Number.isFinite(cell)) return `<c r="${reference}" s="${style}" t="n"><v>${cell}</v></c>`;
      return `<c r="${reference}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(cell)}</t></is></c>`;
    }).join('');
    return `<row r="${rowNumber}"${height}>${cells}</row>`;
  }).join('');
  const cols = `<cols>${columnWidths.map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`).join('')}</cols>`;
  const pane = freezeRow > 0 ? `<sheetViews><sheetView workbookViewId="0"><pane ySplit="${Math.max(0, freezeRow - 1)}" topLeftCell="A${freezeRow}" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>` : '<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
  const autoFilter = options.autoFilter && rows.length >= headerRow ? `<autoFilter ref="A${headerRow}:${lastColumn}${rows.length}"/>` : '';
  const worksheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${pane}${cols}<sheetData>${sheetRows}</sheetData>${autoFilter}<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="16"/><color rgb="FF173A2A"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F5A3C"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FFD6DEDA"/></left><right style="thin"><color rgb="FFD6DEDA"/></right><top style="thin"><color rgb="FFD6DEDA"/></top><bottom style="thin"><color rgb="FFD6DEDA"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf><xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const files = [
    ['[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'],
    ['_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
    ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${xmlEscape(safeSheetName(options.sheetName))}" sheetId="1" r:id="rId1"/></sheets></workbook>`],
    ['xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
    ['xl/styles.xml', styles],
    ['xl/worksheets/sheet1.xml', worksheet]
  ];
  return zipStore(files);
}

function rowsToObjects(rows) {
  if (!rows.length) return [];
  const headers = rows[0].map((value) => String(value || '').trim());
  return rows.slice(1).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ''])));
}

module.exports = { parseCsv, parseXlsx, createXlsx, rowsToObjects, zipStore };
