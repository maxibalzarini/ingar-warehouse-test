'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, parseBoolean } = require('../security/validation');
const { appendAudit } = require('./audit-service');

const NATURES = new Set(['SERIADO', 'CANTIDAD', 'CONSUMIBLE', 'KIT', 'VEHICULO']);

function categoryError(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function normalizeCode(value) {
  return requiredString(value, 'code', { min: 2, max: 40, pattern: /^[A-Za-z0-9._-]+$/ }).toUpperCase();
}

function expectedVersion(input) {
  const version = Number(input?.version);
  if (!Number.isInteger(version)) throw categoryError(422, 'VERSION_REQUIRED', 'La versión de la categoría es obligatoria.');
  return version;
}

function normalizeCategory(input, current = null) {
  const nature = String(input.nature ?? current?.nature ?? 'SERIADO').toUpperCase();
  if (!NATURES.has(nature)) throw categoryError(422, 'CATEGORY_NATURE_INVALID', 'Naturaleza de categoría inválida.');
  const serializedDefault = ['SERIADO', 'KIT', 'VEHICULO'].includes(nature);
  const returnDefault = nature !== 'CONSUMIBLE';
  return {
    code: normalizeCode(input.code ?? current?.code),
    name: requiredString(input.name ?? current?.name, 'name', { min: 2, max: 120 }),
    nature,
    serialized: parseBoolean(input.serialized, current ? Boolean(current.serialized) : serializedDefault),
    requiresInspection: parseBoolean(input.requiresInspection, current ? Boolean(current.requires_inspection) : true),
    requiresReturn: parseBoolean(input.requiresReturn, current ? Boolean(current.requires_return) : returnDefault),
    defaultUnit: optionalString(input.defaultUnit ?? current?.default_unit, 'defaultUnit', { max: 30 })
  };
}

function auditContext(context, action, entityId, before, after, db, reason = null) {
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action,
    entityType: 'asset_category',
    entityId,
    before,
    after,
    correlationId: context.correlationId,
    source: 'API',
    reason,
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
}

function listCategories(filters = {}) {
  const where = ['deleted_at IS NULL'];
  const params = [];
  if (filters.active !== undefined) { where.push('active = ?'); params.push(filters.active ? 1 : 0); }
  if (filters.nature) { where.push('nature = ?'); params.push(String(filters.nature).toUpperCase()); }
  if (filters.siteId) {
    where.push(`EXISTS (SELECT 1 FROM site_asset_category sac WHERE sac.category_id=asset_category.id AND sac.site_id=? AND sac.active=1)`);
    params.push(String(filters.siteId));
  }
  if (filters.search) {
    where.push('(code LIKE ? OR name LIKE ?)');
    const search = `%${String(filters.search).trim()}%`;
    params.push(search, search);
  }
  return getDb().prepare(`SELECT * FROM asset_category WHERE ${where.join(' AND ')} ORDER BY name COLLATE NOCASE, code`).all(...params);
}

function getCategory(id) {
  return getDb().prepare('SELECT * FROM asset_category WHERE id = ? AND deleted_at IS NULL').get(id) || null;
}

function currentCategory(id, db = getDb()) {
  const current = db.prepare('SELECT * FROM asset_category WHERE id = ? AND deleted_at IS NULL').get(id);
  if (!current) throw categoryError(404, 'CATEGORY_NOT_FOUND', 'Categoría no encontrada.');
  return current;
}

function createCategory(input, context) {
  if (input?.active !== undefined && !parseBoolean(input.active, true)) {
    throw categoryError(422, 'CATEGORY_CREATE_INACTIVE_FORBIDDEN', 'Las categorías nuevas se crean activas. Desactívelas luego mediante la acción controlada correspondiente.');
  }
  const data = normalizeCategory(input);
  return transaction((db) => {
    const now = new Date().toISOString();
    const id = randomUUID();
    try {
      db.prepare(`INSERT INTO asset_category(id, code, name, nature, serialized, requires_inspection, requires_return, default_unit, active, version, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?)`)
        .run(id, data.code, data.name, data.nature, data.serialized ? 1 : 0, data.requiresInspection ? 1 : 0, data.requiresReturn ? 1 : 0, data.defaultUnit, now, now);
    } catch (error) {
      if (String(error.message).includes('UNIQUE')) throw categoryError(409, 'CATEGORY_DUPLICATE', 'Ya existe una categoría con ese código.');
      throw error;
    }
    const siteRows = db.prepare('SELECT id FROM site WHERE active=1').all();
    const link = db.prepare(`INSERT OR IGNORE INTO site_asset_category(site_id, category_id, active, version, created_at, updated_at)
      VALUES (?, ?, 1, 1, ?, ?)`);
    for (const site of siteRows) link.run(site.id, id, now, now);
    const created = db.prepare('SELECT * FROM asset_category WHERE id = ?').get(id);
    auditContext(context, 'ASSET_CATEGORY.CREATE', id, null, created, db);
    return created;
  });
}

function updateCategory(id, input, context) {
  const version = expectedVersion(input);
  return transaction((db) => {
    const current = currentCategory(id, db);
    if (version !== current.version) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
    if (Object.prototype.hasOwnProperty.call(input, 'active') && parseBoolean(input.active, Boolean(current.active)) !== Boolean(current.active)) {
      throw categoryError(409, 'CATEGORY_STATE_ACTION_REQUIRED', 'El estado de la categoría sólo puede modificarse mediante las acciones Desactivar o Reactivar.');
    }
    const data = normalizeCategory(input, current);
    if (data.nature !== current.nature && db.prepare('SELECT 1 FROM asset WHERE category_id = ? LIMIT 1').get(id)) {
      throw categoryError(409, 'CATEGORY_NATURE_LOCKED', 'No puede cambiarse la naturaleza de una categoría con bienes asociados, incluidos los registros históricos.');
    }
    try {
      const result = db.prepare(`UPDATE asset_category
        SET code = ?, name = ?, nature = ?, serialized = ?, requires_inspection = ?, requires_return = ?, default_unit = ?, version = version + 1, updated_at = ?
        WHERE id = ? AND version = ? AND deleted_at IS NULL`)
        .run(data.code, data.name, data.nature, data.serialized ? 1 : 0, data.requiresInspection ? 1 : 0, data.requiresReturn ? 1 : 0, data.defaultUnit, new Date().toISOString(), id, version);
      if (result.changes !== 1) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
    } catch (error) {
      if (String(error.message).includes('UNIQUE')) throw categoryError(409, 'CATEGORY_DUPLICATE', 'Ya existe una categoría con ese código.');
      if (String(error.message).includes('CATEGORY_NATURE_CHANGE_WITH_ASSETS_FORBIDDEN')) {
        throw categoryError(409, 'CATEGORY_NATURE_LOCKED', 'No puede cambiarse la naturaleza de una categoría con bienes asociados, incluidos los registros históricos.');
      }
      throw error;
    }
    const updated = currentCategory(id, db);
    auditContext(context, 'ASSET_CATEGORY.UPDATE', id, current, updated, db);
    return updated;
  });
}

function setCategoryActiveInTransaction(db, current, active, version, context) {
  if (version !== current.version) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
  if (Boolean(current.active) === active) return current;
  const now = new Date().toISOString();
  const result = db.prepare(`UPDATE asset_category
    SET active = ?, version = version + 1, updated_at = ?
    WHERE id = ? AND version = ? AND deleted_at IS NULL`)
    .run(active ? 1 : 0, now, current.id, version);
  if (result.changes !== 1) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
  const updated = currentCategory(current.id, db);
  auditContext(context, active ? 'ASSET_CATEGORY.REACTIVATE' : 'ASSET_CATEGORY.DEACTIVATE', current.id, current, updated, db);
  return updated;
}

function setCategoryActive(id, active, input, context) {
  const version = expectedVersion(input);
  return transaction((db) => setCategoryActiveInTransaction(db, currentCategory(id, db), Boolean(active), version, context));
}

function associatedAssetSummary(db, categoryId) {
  const row = db.prepare(`SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN deleted_at IS NULL THEN 1 ELSE 0 END) AS current_count,
      SUM(CASE WHEN deleted_at IS NOT NULL THEN 1 ELSE 0 END) AS historical_count
    FROM asset WHERE category_id = ?`).get(categoryId);
  return {
    total: Number(row.total || 0),
    current: Number(row.current_count || 0),
    historical: Number(row.historical_count || 0)
  };
}

function categoryAssetBlockMessage(summary) {
  const noun = summary.total === 1 ? 'bien asociado' : 'bienes asociados';
  return `No puede eliminarse la categoría porque tiene ${summary.total} ${noun} (${summary.current} vigente${summary.current === 1 ? '' : 's'} y ${summary.historical} histórico${summary.historical === 1 ? '' : 's'}). Debe conservarse para mantener la trazabilidad; desactívela para impedir nuevas altas.`;
}

function deleteCategory(id, input, context) {
  const version = expectedVersion(input);
  const reason = optionalString(input?.reason, 'reason', { max: 500 }) || 'Eliminación lógica desde administración de categorías';
  return transaction((db) => {
    const current = currentCategory(id, db);
    if (version !== current.version) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
    const summary = associatedAssetSummary(db, id);
    if (summary.total > 0) throw categoryError(409, 'CATEGORY_DELETE_BLOCKED_ASSETS', categoryAssetBlockMessage(summary));
    const now = new Date().toISOString();
    try {
      const result = db.prepare(`UPDATE asset_category
        SET active = 0, deleted_at = ?, version = version + 1, updated_at = ?
        WHERE id = ? AND version = ? AND deleted_at IS NULL`)
        .run(now, now, id, version);
      if (result.changes !== 1) throw categoryError(409, 'CONCURRENCY_CONFLICT', 'La categoría fue modificada por otra operación.');
    } catch (error) {
      if (String(error.message).includes('CATEGORY_DELETE_BLOCKED_ASSETS')) {
        const latest = associatedAssetSummary(db, id);
        throw categoryError(409, 'CATEGORY_DELETE_BLOCKED_ASSETS', categoryAssetBlockMessage(latest));
      }
      throw error;
    }
    const deleted = db.prepare('SELECT * FROM asset_category WHERE id = ?').get(id);
    auditContext(context, 'ASSET_CATEGORY.DELETE', id, current, deleted, db, reason);
    return deleted;
  });
}

module.exports = {
  NATURES,
  listCategories,
  getCategory,
  createCategory,
  updateCategory,
  setCategoryActive,
  deleteCategory,
  normalizeCode
};
