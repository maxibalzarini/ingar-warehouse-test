'use strict';

const { getDb } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { scopeWhere, permissionAssignments } = require('../security/scope');
const { getSetting } = require('./settings-service');
const { getWarehouseWorkbench } = require('./warehouse-workbench-service');

const DEFAULT_TIME_ZONE = 'America/Argentina/Buenos_Aires';
const OPEN_REQUEST = ['RECIBIDA','VALIDANDO','BLOQUEADA','PENDIENTE_AUTORIZACION','APROBADA','PREPARANDO','LISTA_PARA_ENTREGA'];
const OPEN_CUSTODY = ['ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE'];
const OPEN_INCIDENT = ['ABIERTO','EN_INVESTIGACION'];

function can(user, permission) { return Boolean(user && hasPermission(user, permission)); }
function placeholders(rows) { return rows.map(() => '?').join(','); }
function number(value) { return Number(value || 0); }

function safeTimeZone(value) {
  const candidate = String(value || DEFAULT_TIME_ZONE);
  try { new Intl.DateTimeFormat('es-AR', { timeZone: candidate }).format(new Date()); return candidate; }
  catch { return DEFAULT_TIME_ZONE; }
}
function zonedParts(date, timeZone) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit', hourCycle:'h23' }).formatToParts(date);
  return Object.fromEntries(parts.filter((p) => p.type !== 'literal').map((p) => [p.type, Number(p.value)]));
}
function timeZoneOffsetMs(date, timeZone) {
  const p = zonedParts(date, timeZone);
  return Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second) - Math.floor(date.getTime()/1000)*1000;
}
function localUtc(parts, timeZone) {
  const target = Date.UTC(parts.year,parts.month-1,parts.day,parts.hour||0,parts.minute||0,parts.second||0);
  let estimate = target;
  for (let i=0;i<3;i+=1) estimate = target - timeZoneOffsetMs(new Date(estimate),timeZone);
  return new Date(estimate);
}
function dayRange(now, timeZone) {
  const p = zonedParts(now,timeZone);
  const start = localUtc({year:p.year,month:p.month,day:p.day},timeZone);
  const noon = new Date(Date.UTC(p.year,p.month-1,p.day+1,12));
  const np = {year:noon.getUTCFullYear(),month:noon.getUTCMonth()+1,day:noon.getUTCDate()};
  const end = localUtc(np,timeZone);
  return { start:start.toISOString(), end:end.toISOString(), key:`${p.year}-${String(p.month).padStart(2,'0')}-${String(p.day).padStart(2,'0')}` };
}
function scope(db,user,permission,site='sl.site_id',location='sl.id') {
  if (!can(user,permission)) return null;
  return scopeWhere(user,permission,site,location,db);
}

function technicianHome(user, options={}) {
  const db = getDb();
  const now = options.now instanceof Date ? options.now : new Date();
  const timeZone = safeTimeZone(options.timeZone || getSetting('locale.timezone',DEFAULT_TIME_ZONE));
  const today = dayRange(now,timeZone);
  const personId = user?.personId || null;
  if (!personId) return { generatedAt:now.toISOString(), timeZone, localDate:today.key, metrics:{activeRequests:0,activeCustodies:0,dueToday:0,overdueReturns:0}, notifications:[] };

  const activeRequests = number(db.prepare(`SELECT COUNT(*) n FROM request WHERE requester_person_id=? AND status IN (${placeholders(OPEN_REQUEST)})`).get(personId,...OPEN_REQUEST)?.n);
  const activeCustodies = number(db.prepare(`SELECT COUNT(*) n FROM custody WHERE person_id=? AND status IN (${placeholders(OPEN_CUSTODY)})`).get(personId,...OPEN_CUSTODY)?.n);
  const dueToday = number(db.prepare(`SELECT COUNT(*) n FROM custody WHERE person_id=? AND status IN (${placeholders(OPEN_CUSTODY)}) AND status<>'DEVOLUCION_DECLARADA' AND due_at>=? AND due_at<?`).get(personId,...OPEN_CUSTODY,today.start,today.end)?.n);
  const overdueReturns = number(db.prepare(`SELECT COUNT(*) n FROM custody WHERE person_id=? AND status IN (${placeholders(OPEN_CUSTODY)}) AND status<>'DEVOLUCION_DECLARADA' AND due_at IS NOT NULL AND due_at<?`).get(personId,...OPEN_CUSTODY,now.toISOString())?.n);
  const notifications = db.prepare(`SELECT id,type,status,subject,body,entity_type,entity_id,scheduled_at,sent_at,read_at,created_at
    FROM notification WHERE (recipient_user_id=? OR recipient_person_id=?) AND status<>'CANCELADA'
    ORDER BY COALESCE(sent_at,scheduled_at,created_at) DESC LIMIT 12`).all(user.id,personId);
  return { generatedAt:now.toISOString(), timeZone, localDate:today.key, metrics:{activeRequests,activeCustodies,dueToday,overdueReturns}, notifications };
}

function criticalStock(db,user,limit=8) {
  const s = scope(db,user,'Stock.Read','sloc.site_id','sloc.id');
  if (!s) return { items:[], total:null };
  const where = `(${s.sql}) AND sl.active=1 AND a.active=1 AND a.deleted_at IS NULL AND ac.active=1 AND ac.deleted_at IS NULL AND ac.nature IN ('CANTIDAD','CONSUMIBLE') AND (sl.quantity_on_hand-sl.quantity_reserved)<=0`;
  const total = number(db.prepare(`SELECT COUNT(*) n FROM stock_lot sl JOIN asset a ON a.id=sl.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sloc ON sloc.id=sl.location_id JOIN site s2 ON s2.id=sloc.site_id WHERE ${where}`).get(...s.params)?.n);
  const items = db.prepare(`SELECT a.id,a.internal_code,a.description,ac.name AS category_name,sl.lot_code,sl.quantity_on_hand,sl.quantity_reserved,a.unit_of_measure,sloc.name AS location_name
    FROM stock_lot sl JOIN asset a ON a.id=sl.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sloc ON sloc.id=sl.location_id JOIN site s2 ON s2.id=sloc.site_id
    WHERE ${where} ORDER BY (sl.quantity_on_hand-sl.quantity_reserved) ASC,a.description COLLATE NOCASE LIMIT ?`).all(...s.params,limit);
  return { items,total };
}

function warehouseHome(user, options={}) {
  const db=getDb();
  const feed=getWarehouseWorkbench(user,options);
  return { ...feed, criticalStock:criticalStock(db,user,8) };
}

function scopedAssetRows(db,user,natures) {
  const s=scope(db,user,'Assets.Read');
  if (!s) return [];
  return db.prepare(`SELECT a.id,a.internal_code,a.description,a.status,a.quantity_total,a.quantity_available,a.unit_of_measure,a.license_plate,ac.nature,sl.name AS location_name,sl.site_id
    FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE (${s.sql}) AND a.active=1 AND a.deleted_at IS NULL AND ac.active=1 AND ac.deleted_at IS NULL AND ac.nature IN (${placeholders(natures)})`).all(...s.params,...natures);
}

function scopedOpenIncidents(db,user,limit=8) {
  const s=scope(db,user,'Incident.Read','sl.site_id','a.location_id'); if(!s) return {total:null,items:[]};
  const total=number(db.prepare(`SELECT COUNT(*) n FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE (${s.sql}) AND i.status IN (${placeholders(OPEN_INCIDENT)})`).get(...s.params,...OPEN_INCIDENT)?.n);
  const items=db.prepare(`SELECT i.id,i.incident_number,i.title,i.severity,i.status,i.opened_at,a.internal_code,a.description AS asset_description
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE (${s.sql}) AND i.status IN (${placeholders(OPEN_INCIDENT)}) ORDER BY CASE i.severity WHEN 'CRITICA' THEN 0 WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 ELSE 3 END,i.opened_at DESC LIMIT ?`).all(...s.params,...OPEN_INCIDENT,limit);
  return {total,items};
}

function scopedCustodies(db,user,now,limit=8) {
  const s=scope(db,user,'Custody.ReadAll','r.site_id','r.location_id'); if(!s) return {pending:null,overdue:null,items:[]};
  const base=`FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN person p ON p.id=c.person_id WHERE (${s.sql}) AND c.status IN (${placeholders(OPEN_CUSTODY)})`;
  const pending=number(db.prepare(`SELECT COUNT(*) n ${base}`).get(...s.params,...OPEN_CUSTODY)?.n);
  const overdue=number(db.prepare(`SELECT COUNT(*) n ${base} AND c.status<>'DEVOLUCION_DECLARADA' AND c.due_at IS NOT NULL AND c.due_at<?`).get(...s.params,...OPEN_CUSTODY,now.toISOString())?.n);
  const items=db.prepare(`SELECT c.id,c.status,c.due_at,c.opened_at,c.quantity,r.request_number,a.internal_code,a.description,ac.nature,p.full_name AS custodian_name
    ${base} AND c.due_at IS NOT NULL ORDER BY CASE WHEN c.due_at<? THEN 0 ELSE 1 END,c.due_at ASC LIMIT ?`).all(...s.params,...OPEN_CUSTODY,now.toISOString(),limit);
  return {pending,overdue,items};
}

function scopedManagementActions(db,user,now,timeZone,limit=6) {
  if (!can(user,'Actions.Read')) return [];
  const s=scope(db,user,'Actions.Read','ma.site_id','ma.location_id');
  if (!s) return [];
  const globalAllowed=permissionAssignments(user,'Actions.Read',db).some((x)=>!x.site_id&&!x.location_id);
  const today=dayRange(now,timeZone).key;
  const where=globalAllowed?`(ma.scope_type='GLOBAL' OR ${s.sql})`:`(${s.sql})`;
  return db.prepare(`SELECT ma.id,ma.code,ma.title,ma.priority,ma.status,ma.target_date,ma.progress_percent,
      COALESCE(p.full_name,r.name,ma.assigned_sector,'Sin responsable') AS assignee
    FROM management_action ma
    LEFT JOIN person p ON p.id=ma.assigned_person_id
    LEFT JOIN role r ON r.id=ma.assigned_role_id
    WHERE ${where} AND ma.status<>'CERRADA'
    ORDER BY CASE WHEN ma.target_date<? THEN 0 ELSE 1 END,
      CASE ma.priority WHEN 'URGENTE' THEN 0 WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 ELSE 3 END,
      ma.target_date ASC,ma.updated_at DESC LIMIT ?`).all(...s.params,today,limit);
}

function scopedMaintenance(db,user,now,limit=8) {
  const s=scope(db,user,'Maintenance.Read','sl.site_id','a.location_id'); if(!s) return {next30:null,items:[]};
  const end30=new Date(now.getTime()+30*86400000).toISOString();
  const where=`(${s.sql}) AND mo.status IN ('PROGRAMADA','VENCIDA','EN_PROGRESO')`;
  const next30=number(db.prepare(`SELECT COUNT(*) n FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE ${where} AND COALESCE(mo.due_at,mo.scheduled_at)>=? AND COALESCE(mo.due_at,mo.scheduled_at)<?`).get(...s.params,now.toISOString(),end30)?.n);
  const items=db.prepare(`SELECT mo.id,mo.order_number,mo.status,mo.priority,mo.scheduled_at,mo.due_at,mo.description,a.internal_code,a.description AS asset_description
    FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE ${where}
    ORDER BY CASE mo.status WHEN 'VENCIDA' THEN 0 WHEN 'EN_PROGRESO' THEN 1 ELSE 2 END,COALESCE(mo.due_at,mo.scheduled_at) ASC LIMIT ?`).all(...s.params,limit);
  return {next30,items};
}


function supervisorVehicleApprovals(db,user,limit=8) {
  const roles = new Set(user?.roleCodes || []);
  if (!roles.has('SUPERVISOR') || roles.has('ADMIN_GENERAL') || roles.has('ADMINISTRADOR')) return [];
  return db.prepare(`SELECT vrs.id,vrs.custody_id,vrs.status,vrs.requested_at,vrs.requester_person_id,
      a.internal_code,a.description,a.license_plate,p.full_name AS requester_name,c.due_at
    FROM vehicle_return_supervision vrs
    JOIN custody c ON c.id=vrs.custody_id
    JOIN asset a ON a.id=vrs.vehicle_asset_id
    JOIN person p ON p.id=vrs.requester_person_id
    WHERE vrs.supervisor_user_id=? AND vrs.status='PENDIENTE'
    ORDER BY vrs.requested_at ASC LIMIT ?`).all(user.id,limit);
}

function adminVehiclesOutside(db,user,limit=8) {
  const roles = new Set(user?.roleCodes || []);
  if (!roles.has('ADMIN_GENERAL') && !roles.has('ADMINISTRADOR')) return [];
  const s=scope(db,user,'Custody.ReadAll','r.site_id','r.location_id');
  if (!s) return [];
  return db.prepare(`SELECT c.id AS custody_id,c.status,c.opened_at,c.due_at,r.request_number,
      a.id AS asset_id,a.internal_code,a.description,a.license_plate,p.full_name AS custodian_name,
      sp.full_name AS supervisor_name
    FROM custody c
    JOIN request r ON r.id=c.request_id
    JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN person p ON p.id=c.person_id
    LEFT JOIN person sp ON sp.id=p.supervisor_person_id
    WHERE (${s.sql}) AND ac.nature='VEHICULO' AND c.status IN (${placeholders(OPEN_CUSTODY)})
    ORDER BY CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 0 ELSE 1 END,c.due_at ASC,c.opened_at ASC LIMIT ?`).all(...s.params,...OPEN_CUSTODY,new Date().toISOString(),limit);
}


function adminSerializedOutside(db,user,limit=8) {
  const roles = new Set(user?.roleCodes || []);
  if (!roles.has('ADMIN_GENERAL') && !roles.has('ADMINISTRADOR')) return [];
  const s=scope(db,user,'Custody.ReadAll','r.site_id','r.location_id');
  if (!s) return [];
  return db.prepare(`SELECT c.id AS custody_id,c.status,c.opened_at,c.due_at,r.request_number,
      a.id AS asset_id,a.internal_code,a.serial_number,a.description,p.full_name AS custodian_name,
      sp.full_name AS supervisor_name
    FROM custody c
    JOIN request r ON r.id=c.request_id
    JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN person p ON p.id=c.person_id
    LEFT JOIN person sp ON sp.id=p.supervisor_person_id
    WHERE (${s.sql}) AND ac.nature='SERIADO' AND c.status IN (${placeholders(OPEN_CUSTODY)})
    ORDER BY CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 0 ELSE 1 END,c.due_at ASC,c.opened_at ASC LIMIT ?`).all(...s.params,...OPEN_CUSTODY,new Date().toISOString(),limit);
}

function adminCustodySnapshot(db,user,limit=8) {
  const roles = new Set(user?.roleCodes || []);
  if (!roles.has('ADMIN_GENERAL') && !roles.has('ADMINISTRADOR')) return [];
  const s=scope(db,user,'Custody.ReadAll','r.site_id','r.location_id');
  if (!s) return [];
  return db.prepare(`SELECT c.id AS custody_id,c.status,c.opened_at,c.due_at,r.request_number,
      a.internal_code,a.description,ac.nature,p.full_name AS custodian_name,sp.full_name AS supervisor_name
    FROM custody c
    JOIN request r ON r.id=c.request_id
    JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN person p ON p.id=c.person_id
    LEFT JOIN person sp ON sp.id=p.supervisor_person_id
    WHERE (${s.sql}) AND c.status IN (${placeholders(OPEN_CUSTODY)})
    ORDER BY CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 0 ELSE 1 END,c.due_at ASC,c.opened_at ASC LIMIT ?`).all(...s.params,...OPEN_CUSTODY,new Date().toISOString(),limit);
}

function controlCenter(user, options={}) {
  const db=getDb(); const now=options.now instanceof Date?options.now:new Date();
  const timeZone=safeTimeZone(options.timeZone || getSetting('locale.timezone',DEFAULT_TIME_ZONE));
  const vehicles=scopedAssetRows(db,user,['VEHICULO']);
  const equipment=scopedAssetRows(db,user,['SERIADO','CANTIDAD','CONSUMIBLE','KIT']);
  const incident=scopedOpenIncidents(db,user,8);
  const custody=scopedCustodies(db,user,now,8);
  const maintenance=scopedMaintenance(db,user,now,8);
  const managementActions=scopedManagementActions(db,user,now,timeZone,6);
  const fleetTotal=vehicles.length;
  const fleetOperational=vehicles.filter((x)=>!['BLOQUEADO','MANTENIMIENTO','PERDIDO','BAJA'].includes(String(x.status))).length;
  const equipmentInCustody=equipment.filter((x)=>x.status==='EN_CUSTODIA').length;
  const fleetByStatus={ disponible:0,reservado:0,enCustodia:0,mantenimiento:0,fueraServicio:0 };
  for(const v of vehicles){
    if(v.status==='DISPONIBLE') fleetByStatus.disponible+=1;
    else if(v.status==='RESERVADO') fleetByStatus.reservado+=1;
    else if(v.status==='EN_CUSTODIA') fleetByStatus.enCustodia+=1;
    else if(v.status==='MANTENIMIENTO') fleetByStatus.mantenimiento+=1;
    else fleetByStatus.fueraServicio+=1;
  }
  const roleSet=new Set(user?.roleCodes||[]);
  const dashboardMode=(roleSet.has('ADMIN_GENERAL')||roleSet.has('ADMINISTRADOR'))?'ADMIN':roleSet.has('SUPERVISOR')?'SUPERVISOR':'CONTROL';
  const vehicleApprovals=supervisorVehicleApprovals(db,user,8);
  const vehiclesOutNow=adminVehiclesOutside(db,user,8);
  const serializedOutNow=adminSerializedOutside(db,user,8);
  const custodySnapshot=adminCustodySnapshot(db,user,8);
  return {
    generatedAt:now.toISOString(),
    dashboardMode,
    metrics:{ fleetOperational,fleetTotal,equipmentInCustody,equipmentTotal:equipment.length,openIncidents:incident.total,pendingReturns:custody.pending,maintenanceNext30:maintenance.next30,vehicleApprovalsPending:vehicleApprovals.length,vehiclesOutNow:vehiclesOutNow.length,serializedOutNow:serializedOutNow.length },
    vehicleApprovals,vehiclesOutNow,serializedOutNow,custodySnapshot,
    fleetByStatus,
    alerts:[
      ...managementActions.map((x)=>({kind:'ACTION',id:x.id,severity:x.priority==='URGENTE'?'CRITICA':x.priority,title:`${x.code} · ${x.title}`,detail:`${x.assignee} · ${x.progress_percent}%`,at:x.target_date})),
      ...incident.items.map((x)=>({kind:'INCIDENT',id:x.id,severity:x.severity,title:`${x.incident_number} · ${x.title}`,detail:[x.internal_code,x.asset_description].filter(Boolean).join(' · '),at:x.opened_at})),
      ...custody.items.filter((x)=>x.due_at && new Date(x.due_at)<now).map((x)=>({kind:'CUSTODY',id:x.id,severity:'ALTA',title:`Devolución vencida · ${x.internal_code}`,detail:x.custodian_name,at:x.due_at}))
    ].sort((a,b)=>new Date(a.at||0)-new Date(b.at||0)).slice(0,8),
    maintenance:maintenance.items,
    pendingReturnEquipment:custody.items.filter((x)=>x.nature!=='VEHICULO').slice(0,8)
  };
}

module.exports={ technicianHome, warehouseHome, controlCenter };
