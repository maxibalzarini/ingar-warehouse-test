'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting, updateSettingsInDb } = require('./settings-service');
const { assertAssetScope, assertLocationScope } = require('../security/scope');

const TRANSFER_SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);
const LOCATION_TYPES = new Set(['PANOL','GARAJE','ESTACIONAMIENTO','TALLER','DEPOSITO','OFICINA','OTRO']);

function error(status, code, message, details = null) {
  return Object.assign(new Error(message), { status, code, details });
}

function expectedVersion(input) {
  const value = Number(input?.version);
  if (!Number.isInteger(value)) throw error(422, 'VERSION_REQUIRED', 'La versión es obligatoria.');
  return value;
}

function auditContext(context, action, entityType, entityId, before, after, db, reason = null) {
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action,
    entityType,
    entityId,
    before,
    after,
    correlationId: context.correlationId,
    source: 'API',
    reason,
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
}

function normalizeOptionalSiteCode(value, fallback) {
  const normalized = optionalString(value, 'code', { max: 40 });
  if (!normalized) return fallback;
  if (!/^[A-Za-z0-9._-]+$/.test(normalized)) throw error(422, 'SITE_CODE_INVALID', 'El código de sede sólo admite letras, números, punto, guion y guion bajo.');
  return normalized.toUpperCase();
}

function normalizeOptionalSiteName(value, fallback) {
  return optionalString(value, 'name', { max: 120 }) || fallback;
}

function activeCategoryIds(db) {
  return db.prepare('SELECT id FROM asset_category WHERE active = 1 AND deleted_at IS NULL ORDER BY name COLLATE NOCASE, code').all().map((row) => row.id);
}

function normalizeCategoryIds(db, input, fallback = null) {
  if (input === undefined || input === null) return fallback === null ? activeCategoryIds(db) : fallback;
  if (!Array.isArray(input)) throw error(422, 'SITE_CATEGORIES_INVALID', 'Las categorías habilitadas de la sede son inválidas.');
  const ids = [...new Set(input.map((value) => String(value || '').trim()).filter(Boolean))];
  if (!ids.length) return [];
  const placeholders = ids.map(() => '?').join(',');
  const found = db.prepare(`SELECT id FROM asset_category WHERE id IN (${placeholders}) AND deleted_at IS NULL`).all(...ids);
  if (found.length !== ids.length) throw error(422, 'SITE_CATEGORY_NOT_FOUND', 'Una o más categorías seleccionadas no existen.');
  return ids;
}

function siteCategoryIds(db, siteId) {
  return db.prepare('SELECT category_id FROM site_asset_category WHERE site_id = ? AND active = 1 ORDER BY category_id').all(siteId).map((row) => row.category_id);
}

function setSiteCategoriesInTransaction(db, siteId, categoryIds, now) {
  const desired = new Set(categoryIds);
  const existing = db.prepare('SELECT category_id, active, version FROM site_asset_category WHERE site_id = ?').all(siteId);
  const byId = new Map(existing.map((row) => [row.category_id, row]));
  const allCategoryIds = db.prepare('SELECT id FROM asset_category WHERE deleted_at IS NULL').all().map((row) => row.id);
  const insert = db.prepare(`INSERT INTO site_asset_category(site_id, category_id, active, version, created_at, updated_at)
    VALUES (?, ?, ?, 1, ?, ?)`);
  const update = db.prepare(`UPDATE site_asset_category SET active = ?, version = version + 1, updated_at = ?
    WHERE site_id = ? AND category_id = ?`);
  for (const categoryId of allCategoryIds) {
    const active = desired.has(categoryId) ? 1 : 0;
    const current = byId.get(categoryId);
    if (!current) insert.run(siteId, categoryId, active, now, now);
    else if (Number(current.active) !== active) update.run(active, now, siteId, categoryId);
  }
}

function siteUsage(db, siteId) {
  return {
    assetCount: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset a JOIN storage_location sl ON sl.id=a.location_id
      WHERE sl.site_id=? AND a.deleted_at IS NULL`).get(siteId).n || 0),
    activeAssetCount: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset a JOIN storage_location sl ON sl.id=a.location_id
      WHERE sl.site_id=? AND a.deleted_at IS NULL AND a.active=1`).get(siteId).n || 0),
    userScopeCount: Number(db.prepare('SELECT COUNT(*) AS n FROM user_role_scope WHERE site_id=?').get(siteId).n || 0),
    locationCount: Number(db.prepare('SELECT COUNT(*) AS n FROM storage_location WHERE site_id=? AND deleted_at IS NULL').get(siteId).n || 0)
  };
}

function locationUsage(db, locationId) {
  return {
    assetCount: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset WHERE location_id=? AND deleted_at IS NULL`).get(locationId).n || 0),
    activeAssetCount: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset WHERE location_id=? AND deleted_at IS NULL AND active=1`).get(locationId).n || 0),
    availableAssetCount: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset WHERE location_id=? AND deleted_at IS NULL AND active=1 AND status='DISPONIBLE'`).get(locationId).n || 0)
  };
}

function activeSiteDependencies(db, siteId) {
  const now = new Date().toISOString();
  return {
    activeAssets: Number(db.prepare(`SELECT COUNT(*) AS n FROM asset a JOIN storage_location sl ON sl.id=a.location_id
      WHERE sl.site_id=? AND a.deleted_at IS NULL AND a.active=1`).get(siteId).n || 0),
    activeLocations: Number(db.prepare(`SELECT COUNT(*) AS n FROM storage_location
      WHERE site_id=? AND deleted_at IS NULL AND active=1`).get(siteId).n || 0),
    activeUserScopes: Number(db.prepare(`SELECT COUNT(*) AS n FROM user_role_scope urs
      JOIN user_account ua ON ua.id=urs.user_id
      JOIN role r ON r.id=urs.role_id AND r.active=1
      WHERE urs.site_id=? AND ua.active=1 AND ua.deleted_at IS NULL
        AND (urs.valid_from IS NULL OR urs.valid_from<=?)
        AND (urs.valid_to IS NULL OR urs.valid_to>=?)`).get(siteId, now, now).n || 0)
  };
}

function activeAssetsForDisabledCategories(db, siteId, disabledCategoryIds) {
  if (!disabledCategoryIds.length) return [];
  const placeholders = disabledCategoryIds.map(() => '?').join(',');
  return db.prepare(`SELECT ac.code,ac.name,COUNT(*) AS asset_count
    FROM asset a
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id
    WHERE sl.site_id=? AND a.deleted_at IS NULL AND a.active=1
      AND a.category_id IN (${placeholders})
    GROUP BY ac.id,ac.code,ac.name ORDER BY ac.name COLLATE NOCASE`).all(siteId, ...disabledCategoryIds);
}

function listLocations() {
  const db = getDb();
  const organizations = db.prepare('SELECT * FROM organization ORDER BY name').all();
  if (organizations.length === 1) {
    const configuredName = String(getSetting('organization.name', organizations[0].name) || '').trim();
    if (configuredName) organizations[0].name = configuredName;
  }
  const sites = db.prepare('SELECT * FROM site WHERE deleted_at IS NULL ORDER BY is_primary DESC, name COLLATE NOCASE, code').all().map((site) => ({ ...site, ...siteUsage(db, site.id) }));
  const locations = db.prepare('SELECT * FROM storage_location WHERE deleted_at IS NULL ORDER BY name').all().map((location) => ({ ...location, ...locationUsage(db, location.id) }));
  const categories = db.prepare(`SELECT id, code, name, nature, active FROM asset_category
    WHERE deleted_at IS NULL ORDER BY name COLLATE NOCASE, code`).all();
  const siteCategories = db.prepare(`SELECT site_id, category_id, active, version, updated_at
    FROM site_asset_category ORDER BY site_id, category_id`).all();
  return { organizations, sites, locations, categories, siteCategories };
}


function updateOrganization(id, input, context) {
  const version = expectedVersion(input);
  const name = requiredString(input.name, 'name', { min: 2, max: 120 });
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM organization WHERE id=?').get(id);
    if (!current) throw error(404, 'ORGANIZATION_NOT_FOUND', 'Organización no encontrada.');
    if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La organización fue modificada por otra operación.');
    const now = new Date().toISOString();
    const changed = db.prepare('UPDATE organization SET name=?, version=version+1, updated_at=? WHERE id=? AND version=?')
      .run(name, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La organización fue modificada por otra operación.');
    // Mantiene sincronizado el nombre institucional ya usado por encabezados y reportes.
    updateSettingsInDb({ 'organization.name': name }, context, db);
    const updated = db.prepare('SELECT * FROM organization WHERE id=?').get(id);
    auditContext(context, 'ORGANIZATION.UPDATE', 'organization', id, current, updated, db);
    return updated;
  });
}

function createSite(input, context) {
  const organizationId = requiredString(input.organizationId, 'organizationId', { min: 10, max: 80 });
  return transaction((db) => {
    if (!db.prepare('SELECT 1 FROM organization WHERE id = ? AND active = 1').get(organizationId)) {
      throw error(422, 'ORGANIZATION_INVALID', 'Organización inexistente o inactiva.');
    }
    const id = randomUUID();
    const generatedCode = `SEDE-${id.slice(0, 8).toUpperCase()}`;
    const code = normalizeOptionalSiteCode(input.code, generatedCode);
    const name = normalizeOptionalSiteName(input.name, code);
    const description = optionalString(input.description, 'description', { max: 500 });
    const categoryIds = normalizeCategoryIds(db, input.categoryIds);
    const hasSite = Boolean(db.prepare('SELECT 1 FROM site WHERE organization_id=? AND deleted_at IS NULL LIMIT 1').get(organizationId));
    const isPrimary = !hasSite ? true : Boolean(input.isPrimary);
    const now = new Date().toISOString();
    try {
      if (isPrimary) {
        const previousPrimary = db.prepare('SELECT * FROM site WHERE organization_id=? AND is_primary=1 AND deleted_at IS NULL LIMIT 1').get(organizationId);
        if (previousPrimary) {
          db.prepare('UPDATE site SET is_primary=0, version=version+1, updated_at=? WHERE id=?').run(now, previousPrimary.id);
          const replaced = db.prepare('SELECT * FROM site WHERE id=?').get(previousPrimary.id);
          auditContext(context, 'SITE.PRIMARY.REPLACED', 'site', previousPrimary.id, previousPrimary, replaced, db, 'NEW_PRIMARY_SITE_CREATED');
        }
      }
      db.prepare(`INSERT INTO site(id, organization_id, code, name, active, version, created_at, updated_at, is_primary, description)
        VALUES (?, ?, ?, ?, 1, 1, ?, ?, ?, ?)`)
        .run(id, organizationId, code, name, now, now, isPrimary ? 1 : 0, description);
    } catch (cause) {
      if (String(cause.message).includes('UNIQUE')) throw error(409, 'SITE_DUPLICATE', 'Ya existe una sede con ese código en la organización.');
      throw cause;
    }
    setSiteCategoriesInTransaction(db, id, categoryIds, now);
    const created = { ...db.prepare('SELECT * FROM site WHERE id = ?').get(id), categoryIds: siteCategoryIds(db, id) };
    auditContext(context, 'SITE.CREATE', 'site', id, null, created, db);
    return created;
  });
}

function updateSite(id, input, context) {
  const version = expectedVersion(input);
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM site WHERE id = ? AND deleted_at IS NULL').get(id);
    if (!current) throw error(404, 'SITE_NOT_FOUND', 'Sede no encontrada.');
    if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La sede fue modificada por otra operación.');
    const code = input.code === undefined ? current.code : normalizeOptionalSiteCode(input.code, current.code);
    const name = input.name === undefined ? current.name : normalizeOptionalSiteName(input.name, current.name);
    const description = input.description === undefined ? current.description : optionalString(input.description, 'description', { max: 500 });
    const active = input.active === undefined ? Boolean(current.active) : Boolean(input.active);
    const wantsPrimary = input.isPrimary === undefined ? Boolean(current.is_primary) : Boolean(input.isPrimary);
    if (Boolean(current.is_primary) && !wantsPrimary) {
      throw error(409, 'SITE_PRIMARY_REPLACEMENT_REQUIRED', 'Para cambiar la sede principal, marque otra sede como principal.');
    }
    if (wantsPrimary && !active) {
      throw error(409, 'SITE_PRIMARY_MUST_BE_ACTIVE', 'La sede principal debe permanecer activa.');
    }
    if (!active && Boolean(current.is_primary)) {
      throw error(409, 'SITE_PRIMARY_DEACTIVATE_FORBIDDEN', 'La sede principal no puede deshabilitarse. Defina primero otra sede principal.');
    }
    const before = { ...current, categoryIds: siteCategoryIds(db, id) };
    const categoryIds = normalizeCategoryIds(db, input.categoryIds, before.categoryIds);
    if (Boolean(current.active) && !active) {
      const deps = activeSiteDependencies(db, id);
      if (deps.activeAssets || deps.activeLocations || deps.activeUserScopes) {
        throw error(409, 'SITE_DEACTIVATE_DEPENDENCIES', `No puede desactivarse la sede mientras tenga dependencias operativas: ${deps.activeAssets} bienes activos, ${deps.activeLocations} ubicaciones activas y ${deps.activeUserScopes} alcances de usuario activos. Reasigne o cierre esas dependencias antes de continuar.`);
      }
    }
    const disabledCategoryIds = before.categoryIds.filter((categoryId) => !categoryIds.includes(categoryId));
    const categoryUsage = activeAssetsForDisabledCategories(db, id, disabledCategoryIds);
    if (categoryUsage.length) {
      const detail = categoryUsage.map((row) => `${row.code}: ${row.asset_count}`).join(', ');
      throw error(409, 'SITE_CATEGORY_DEACTIVATE_ACTIVE_ASSETS', `No puede deshabilitar categorías que todavía tienen bienes activos en la sede (${detail}). Reubique, reclasifique o inactive esos bienes antes de continuar.`);
    }
    const now = new Date().toISOString();
    try {
      if (wantsPrimary && !Boolean(current.is_primary)) {
        const previousPrimary = db.prepare('SELECT * FROM site WHERE organization_id=? AND is_primary=1 AND id<>? AND deleted_at IS NULL LIMIT 1').get(current.organization_id, id);
        if (previousPrimary) {
          db.prepare('UPDATE site SET is_primary=0, version=version+1, updated_at=? WHERE id=?').run(now, previousPrimary.id);
          const replaced = db.prepare('SELECT * FROM site WHERE id=?').get(previousPrimary.id);
          auditContext(context, 'SITE.PRIMARY.REPLACED', 'site', previousPrimary.id, previousPrimary, replaced, db, 'ANOTHER_SITE_MARKED_PRIMARY');
        }
      }
      const result = db.prepare(`UPDATE site
        SET code=?, name=?, description=?, active=?, is_primary=?, version=version+1, updated_at=?
        WHERE id=? AND version=?`)
        .run(code, name, description, active ? 1 : 0, wantsPrimary ? 1 : 0, now, id, version);
      if (result.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La sede fue modificada por otra operación.');
    } catch (cause) {
      if (String(cause.message).includes('UNIQUE')) throw error(409, 'SITE_DUPLICATE', 'Ya existe una sede con ese código en la organización.');
      throw cause;
    }
    setSiteCategoriesInTransaction(db, id, categoryIds, now);
    const updated = { ...db.prepare('SELECT * FROM site WHERE id = ?').get(id), categoryIds: siteCategoryIds(db, id) };
    auditContext(context, 'SITE.UPDATE', 'site', id, before, updated, db);
    return updated;
  });
}

function createLocation(input, context) {
  const siteId = requiredString(input.siteId, 'siteId', { min: 10, max: 80 });
  const name = requiredString(input.name, 'name', { min: 3, max: 120 });
  const type = requiredString(input.type || 'PANOL', 'type', { min: 2, max: 40 }).toUpperCase();
  if (!LOCATION_TYPES.has(type)) throw error(422, 'LOCATION_TYPE_INVALID', 'Tipo de ubicación inválido.');
  return transaction((db) => {
    if (!db.prepare('SELECT 1 FROM site WHERE id = ? AND active = 1 AND deleted_at IS NULL').get(siteId)) {
      throw error(422, 'SITE_INVALID', 'Sede inexistente o inactiva.');
    }
    const id = randomUUID(); const now = new Date().toISOString();
    const code = normalizeOptionalSiteCode(input.code, `LOC-${id.slice(0, 8).toUpperCase()}`);
    try {
      db.prepare('INSERT INTO storage_location(id, site_id, code, name, type, active, version, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, ?, ?)')
        .run(id, siteId, code, name, type, now, now);
    } catch (cause) {
      if (String(cause.message).includes('UNIQUE')) throw error(409, 'LOCATION_DUPLICATE', 'Ya existe una ubicación con ese código en la sede seleccionada.');
      throw cause;
    }
    const created = db.prepare('SELECT * FROM storage_location WHERE id = ?').get(id);
    auditContext(context, 'LOCATION.CREATE', 'storage_location', id, null, created, db);
    return created;
  });
}

function currentLocation(id, db = getDb()) {
  const row = db.prepare('SELECT * FROM storage_location WHERE id = ? AND deleted_at IS NULL').get(id);
  if (!row) throw error(404, 'LOCATION_NOT_FOUND', 'Ubicación no encontrada.');
  return row;
}

function updateLocation(id, input, context) {
  const version = expectedVersion(input);
  return transaction((db) => {
    const current = currentLocation(id, db);
    if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
    if (input.active !== undefined && Boolean(input.active) !== Boolean(current.active)) {
      return setLocationActiveInTransaction(db, current, Boolean(input.active), version, context);
    }
    const name = input.name === undefined ? current.name : requiredString(input.name, 'name', { min: 3, max: 120 });
    const type = input.type === undefined ? current.type : requiredString(input.type, 'type', { min: 2, max: 40 }).toUpperCase();
    if (!LOCATION_TYPES.has(type)) throw error(422, 'LOCATION_TYPE_INVALID', 'Tipo de ubicación inválido.');
    const result = db.prepare(`UPDATE storage_location
      SET name = ?, type = ?, version = version + 1, updated_at = ?
      WHERE id = ? AND version = ? AND deleted_at IS NULL`)
      .run(name, type, new Date().toISOString(), id, version);
    if (result.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
    const updated = currentLocation(id, db);
    auditContext(context, 'LOCATION.UPDATE', 'storage_location', id, current, updated, db);
    return updated;
  });
}

function activeAssetCount(db, locationId) {
  return Number(db.prepare(`SELECT COUNT(*) AS count FROM asset
    WHERE location_id = ? AND deleted_at IS NULL AND active = 1`).get(locationId).count || 0);
}

function associatedAssetCount(db, locationId) {
  return Number(db.prepare(`SELECT COUNT(*) AS count FROM asset
    WHERE location_id = ? AND deleted_at IS NULL`).get(locationId).count || 0);
}

function setLocationActiveInTransaction(db, current, active, version, context) {
  if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
  if (Boolean(current.active) === active) return current;
  if (!active) {
    const count = activeAssetCount(db, current.id);
    if (count > 0) {
      throw error(409, 'LOCATION_DEACTIVATE_BLOCKED_ACTIVE_ASSETS', `No puede desactivarse la ubicación porque contiene ${count} bien${count === 1 ? '' : 'es'} activo${count === 1 ? '' : 's'}. Reubique o inactive esos bienes antes de continuar.`);
    }
  } else if (!db.prepare('SELECT 1 FROM site WHERE id = ? AND active = 1 AND deleted_at IS NULL').get(current.site_id)) {
    throw error(409, 'LOCATION_REACTIVATE_BLOCKED_SITE_INACTIVE', 'No puede reactivarse la ubicación porque la sede asociada está inactiva. Reactive primero la sede.');
  }
  const now = new Date().toISOString();
  try {
    const result = db.prepare(`UPDATE storage_location
      SET active = ?, version = version + 1, updated_at = ?
      WHERE id = ? AND version = ? AND deleted_at IS NULL`)
      .run(active ? 1 : 0, now, current.id, version);
    if (result.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
  } catch (cause) {
    if (String(cause.message).includes('LOCATION_DEACTIVATE_BLOCKED_ACTIVE_ASSETS')) {
      const count = activeAssetCount(db, current.id);
      throw error(409, 'LOCATION_DEACTIVATE_BLOCKED_ACTIVE_ASSETS', `No puede desactivarse la ubicación porque contiene ${count} bien${count === 1 ? '' : 'es'} activo${count === 1 ? '' : 's'}. Reubique o inactive esos bienes antes de continuar.`);
    }
    if (String(cause.message).includes('LOCATION_REACTIVATE_BLOCKED_SITE_INACTIVE')) {
      throw error(409, 'LOCATION_REACTIVATE_BLOCKED_SITE_INACTIVE', 'No puede reactivarse la ubicación porque la sede asociada está inactiva. Reactive primero la sede.');
    }
    throw cause;
  }
  const updated = currentLocation(current.id, db);
  auditContext(context, active ? 'LOCATION.REACTIVATE' : 'LOCATION.DEACTIVATE', 'storage_location', current.id, current, updated, db);
  return updated;
}

function setLocationActive(id, active, input, context) {
  const version = expectedVersion(input);
  return transaction((db) => setLocationActiveInTransaction(db, currentLocation(id, db), active, version, context));
}

function locationDeleteBlockers(db, locationId) {
  const activeAssets = activeAssetCount(db, locationId);
  const activeReservations = Number(db.prepare(`SELECT COUNT(*) AS n FROM asset_reservation ar JOIN asset a ON a.id=ar.asset_id
    WHERE a.location_id=? AND ar.status='ACTIVA'`).get(locationId).n || 0);
  const activeCustodies = Number(db.prepare(`SELECT COUNT(*) AS n FROM custody c JOIN asset a ON a.id=c.asset_id
    WHERE a.location_id=? AND c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')`).get(locationId).n || 0);
  const activeMaintenance = Number(db.prepare(`SELECT COUNT(*) AS n FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id
    WHERE a.location_id=? AND mo.status IN ('BORRADOR','PROGRAMADA','EN_PROGRESO','VENCIDA')`).get(locationId).n || 0);
  const activeIncidents = Number(db.prepare(`SELECT COUNT(*) AS n FROM incident i JOIN asset a ON a.id=i.asset_id
    WHERE a.location_id=? AND i.status IN ('ABIERTO','EN_INVESTIGACION')`).get(locationId).n || 0);
  const stockUnits = Number(db.prepare(`SELECT COALESCE(SUM(quantity_on_hand),0) AS n FROM stock_lot
    WHERE location_id=? AND active=1`).get(locationId).n || 0);
  const stockReserved = Number(db.prepare(`SELECT COALESCE(SUM(quantity_reserved),0) AS n FROM stock_lot
    WHERE location_id=? AND active=1`).get(locationId).n || 0);
  return { activeAssets, activeReservations, activeCustodies, activeMaintenance, activeIncidents, stockUnits, stockReserved };
}

function hasDeleteBlockers(blockers) {
  return Object.values(blockers).some((value) => Number(value || 0) > 0);
}

function deleteLocationInTransaction(db, current, version, context, reason = 'Eliminación lógica desde administración', action = 'LOCATION.DELETE') {
  if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
  const blockers = locationDeleteBlockers(db, current.id);
  if (hasDeleteBlockers(blockers)) {
    throw error(409, 'LOCATION_DELETE_BLOCKED', 'La ubicación todavía tiene bienes u operaciones activas. Transferí o cerrá esas operaciones antes de eliminarla.', { blockers });
  }
  const now = new Date().toISOString();
  const result = db.prepare(`UPDATE storage_location
    SET active=0, deleted_at=?, version=version+1, updated_at=?
    WHERE id=? AND version=? AND deleted_at IS NULL`).run(now, now, current.id, version);
  if (result.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación.');
  const deleted = db.prepare('SELECT * FROM storage_location WHERE id=?').get(current.id);
  auditContext(context, action, 'storage_location', current.id, current, deleted, db, reason);
  return deleted;
}

function deleteLocation(id, input, context) {
  const version = expectedVersion(input);
  const reason = optionalString(input?.reason, 'reason', { max: 500 }) || 'Eliminación desde administración';
  return transaction((db) => deleteLocationInTransaction(db, currentLocation(id, db), version, context, reason));
}

function deleteSite(id, input, context) {
  const version = expectedVersion(input);
  const reason = optionalString(input?.reason, 'reason', { max: 500 }) || 'Eliminación de sede desde administración';
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM site WHERE id=? AND deleted_at IS NULL').get(id);
    if (!current) throw error(404, 'SITE_NOT_FOUND', 'Sede no encontrada.');
    const before = { ...current };
    if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La sede fue modificada por otra operación.');
    const remainingSites = db.prepare('SELECT * FROM site WHERE organization_id=? AND id<>? AND active=1 AND deleted_at IS NULL ORDER BY is_primary DESC, created_at, id').all(current.organization_id, id);
    if (!remainingSites.length) throw error(409, 'SITE_DELETE_LAST_SITE', 'No se puede eliminar la única sede activa. Creá otra sede primero.');
    const deps = activeSiteDependencies(db, id);
    if (deps.activeAssets || deps.activeUserScopes) {
      throw error(409, 'SITE_DELETE_BLOCKED', 'La sede todavía tiene bienes o alcances de usuario activos.', { activeAssets: deps.activeAssets, activeUserScopes: deps.activeUserScopes, activeLocations: deps.activeLocations });
    }
    const locations = db.prepare('SELECT * FROM storage_location WHERE site_id=? AND deleted_at IS NULL ORDER BY name').all(id);
    const blockedLocations = [];
    for (const location of locations) {
      const blockers = locationDeleteBlockers(db, location.id);
      if (hasDeleteBlockers(blockers)) blockedLocations.push({ id: location.id, name: location.name, blockers });
    }
    if (blockedLocations.length) throw error(409, 'SITE_DELETE_LOCATIONS_BLOCKED', 'Una o más ubicaciones de la sede todavía tienen operaciones activas.', { locations: blockedLocations });
    const now = new Date().toISOString();
    for (const location of locations) deleteLocationInTransaction(db, location, location.version, context, 'Eliminación automática por eliminación de sede', 'LOCATION.DELETE.WITH_SITE');
    let replacementPrimarySiteId = null;
    if (current.is_primary) {
      const replacement = remainingSites[0];
      replacementPrimarySiteId = replacement.id;
      db.prepare('UPDATE site SET is_primary=0,version=version+1,updated_at=? WHERE id=? AND version=?').run(now, current.id, current.version);
      const currentAfterPrimary = db.prepare('SELECT * FROM site WHERE id=?').get(current.id);
      db.prepare('UPDATE site SET is_primary=1,version=version+1,updated_at=? WHERE id=?').run(now, replacement.id);
      auditContext(context, 'SITE.PRIMARY.REPLACED', 'site', replacement.id, replacement, db.prepare('SELECT * FROM site WHERE id=?').get(replacement.id), db, 'PRIMARY_SITE_DELETED');
      current.version = currentAfterPrimary.version;
      current.is_primary = 0;
    }
    const changed = db.prepare(`UPDATE site SET active=0,is_primary=0,deleted_at=?,version=version+1,updated_at=?
      WHERE id=? AND version=? AND deleted_at IS NULL`).run(now, now, id, current.version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'La sede fue modificada durante la eliminación.');
    const deleted = db.prepare('SELECT * FROM site WHERE id=?').get(id);
    auditContext(context, 'SITE.DELETE', 'site', id, before, deleted, db, reason);
    return { site: deleted, replacementPrimarySiteId, deletedLocations: locations.length };
  });
}

function transferNumber(now = new Date()) {
  const stamp = now.toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  return `MOV-${stamp}-${randomUUID().slice(0, 6).toUpperCase()}`;
}

function activeOperationalDependency(db, assetId) {
  const reservation = db.prepare("SELECT id FROM asset_reservation WHERE asset_id=? AND status='ACTIVA' LIMIT 1").get(assetId);
  if (reservation) return { code: 'RESERVADO', message: 'Tiene una reserva activa.' };
  const custody = db.prepare("SELECT id FROM custody WHERE asset_id=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE') LIMIT 1").get(assetId);
  if (custody) return { code: 'EN_CUSTODIA', message: 'Está entregado o tiene una devolución/transferencia pendiente.' };
  const maintenance = db.prepare("SELECT id FROM maintenance_order WHERE asset_id=? AND status IN ('BORRADOR','PROGRAMADA','EN_PROGRESO','VENCIDA') LIMIT 1").get(assetId);
  if (maintenance) return { code: 'MANTENIMIENTO', message: 'Tiene mantenimiento activo o pendiente.' };
  const incident = db.prepare("SELECT id FROM incident WHERE asset_id=? AND status IN ('ABIERTO','EN_INVESTIGACION') LIMIT 1").get(assetId);
  if (incident) return { code: 'INCIDENTE', message: 'Tiene un incidente abierto.' };
  return null;
}

function destinationAcceptsCategory(db, destination, categoryId) {
  return Boolean(db.prepare(`SELECT 1 FROM site_asset_category
    WHERE site_id=? AND category_id=? AND active=1`).get(destination.site_id, categoryId));
}

function assetTransferRow(db, assetId) {
  return db.prepare(`SELECT a.*, ac.code AS category_code, ac.name AS category_name, ac.nature AS category_nature,
      sl.name AS location_name, sl.code AS location_code, sl.site_id
    FROM asset a
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id
    WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
}

function quantityStockTransferBlocker(db, asset, source) {
  if (!asset || TRANSFER_SERIAL_NATURES.has(String(asset.category_nature || '').toUpperCase())) return null;
  const reserved = Number(db.prepare(`SELECT COALESCE(SUM(quantity_reserved),0) AS n FROM stock_lot
    WHERE asset_id=? AND location_id=? AND active=1`).get(asset.id, source.id).n || 0);
  if (reserved > 0) return { code: 'STOCK_RESERVED', message: `Tiene ${reserved} unidad${reserved === 1 ? '' : 'es'} de stock reservada${reserved === 1 ? '' : 's'}.` };
  return null;
}

function transferBlocker(db, asset, source, destination, selectedIds) {
  if (!asset) return { code: 'ASSET_NOT_FOUND', message: 'El bien ya no existe.' };
  if (asset.location_id !== source.id) return { code: 'ASSET_SOURCE_CHANGED', message: 'El bien ya no pertenece a la ubicación de origen.' };
  if (!asset.active) return { code: 'ASSET_INACTIVE', message: 'El bien está inactivo.' };
  if (String(asset.status).toUpperCase() !== 'DISPONIBLE') return { code: `STATUS_${String(asset.status).toUpperCase()}`, message: `Estado actual: ${asset.status}.` };
  const dependency = activeOperationalDependency(db, asset.id);
  if (dependency) return dependency;
  const stockBlocker = quantityStockTransferBlocker(db, asset, source);
  if (stockBlocker) return stockBlocker;
  if (destination && destination.site_id !== source.site_id && !destinationAcceptsCategory(db, destination, asset.category_id)) return { code: 'CATEGORY_NOT_ENABLED_DESTINATION', message: 'La categoría no está habilitada en la sede destino.' };
  const parentKit = db.prepare(`SELECT kc.kit_asset_id, ka.internal_code AS kit_code
    FROM kit_component kc JOIN asset ka ON ka.id=kc.kit_asset_id
    WHERE kc.component_asset_id=? AND kc.active=1 AND ka.deleted_at IS NULL LIMIT 1`).get(asset.id);
  if (parentKit && !selectedIds.has(parentKit.kit_asset_id)) return { code: 'KIT_COMPONENT_REQUIRES_KIT', message: `Es componente del kit ${parentKit.kit_code}; debe transferirse el kit completo.` };
  return null;
}

function expandKitSelection(db, sourceId, selectedIds) {
  const blockers = [];
  for (const assetId of [...selectedIds]) {
    const asset = assetTransferRow(db, assetId);
    if (!asset || String(asset.category_nature).toUpperCase() !== 'KIT') continue;
    const components = db.prepare(`SELECT kc.component_asset_id, ca.internal_code, ca.location_id
      FROM kit_component kc JOIN asset ca ON ca.id=kc.component_asset_id
      WHERE kc.kit_asset_id=? AND kc.active=1 AND ca.deleted_at IS NULL ORDER BY kc.sequence`).all(assetId);
    for (const component of components) {
      if (component.location_id !== sourceId) {
        blockers.push({ assetId, internalCode: asset.internal_code, description: asset.description, code: 'KIT_FRAGMENTED', message: `El componente ${component.internal_code} está en otra ubicación.` });
      } else selectedIds.add(component.component_asset_id);
    }
  }
  return blockers;
}

function validateTransferDestination(db, source, destinationId) {
  const destination = currentLocation(destinationId, db);
  if (destination.id === source.id) throw error(422, 'LOCATION_TRANSFER_SAME_LOCATION', 'Origen y destino deben ser distintos.');
  const sourceSite = db.prepare('SELECT organization_id FROM site WHERE id=?').get(source.site_id);
  const destinationSite = db.prepare('SELECT organization_id,active,deleted_at FROM site WHERE id=?').get(destination.site_id);
  if (!sourceSite || !destinationSite || sourceSite.organization_id !== destinationSite.organization_id) {
    throw error(409, 'LOCATION_TRANSFER_CROSS_ORGANIZATION', 'La transferencia entre organizaciones distintas no está permitida.');
  }
  if (!destination.active || !destinationSite.active || destinationSite.deleted_at) throw error(409, 'LOCATION_DESTINATION_INACTIVE', 'La ubicación de destino o su sede están inactivas.');
  return destination;
}

function parentKitForAsset(db, assetId) {
  return db.prepare(`SELECT kc.kit_asset_id, ka.internal_code AS kit_code
    FROM kit_component kc JOIN asset ka ON ka.id=kc.kit_asset_id
    WHERE kc.component_asset_id=? AND kc.active=1 AND ka.deleted_at IS NULL LIMIT 1`).get(assetId) || null;
}

function buildTransferPlan(db, source, destination = null) {
  const rows = db.prepare(`SELECT a.id FROM asset a
    WHERE a.location_id=? AND a.deleted_at IS NULL
    ORDER BY a.internal_code COLLATE NOCASE`).all(source.id);
  const items = [];
  const transferableAssetIds = new Set();
  for (const { id: assetId } of rows) {
    const root = assetTransferRow(db, assetId);
    if (!root) continue;
    const parentKit = parentKitForAsset(db, root.id);
    if (parentKit) continue; // Los componentes se gestionan con su kit y nunca como opción independiente.
    const selectedIds = new Set([root.id]);
    const blockers = expandKitSelection(db, source.id, selectedIds);
    for (const memberId of selectedIds) {
      const member = assetTransferRow(db, memberId);
      const blocked = transferBlocker(db, member, source, destination, selectedIds);
      if (blocked) blockers.push({ assetId: memberId, internalCode: member?.internal_code || null, description: member?.description || null, ...blocked });
    }
    const transferable = blockers.length === 0;
    if (transferable) for (const memberId of selectedIds) transferableAssetIds.add(memberId);
    items.push({
      id: root.id,
      internalCode: root.internal_code,
      description: root.description,
      categoryName: root.category_name,
      categoryNature: root.category_nature,
      status: root.status,
      active: Boolean(root.active),
      groupAssetCount: selectedIds.size,
      transferable,
      blockedReason: transferable ? null : blockers[0]?.message || 'No disponible para transferir.'
    });
  }
  return {
    items,
    transferableAssetIds,
    summary: {
      total: items.length,
      transferable: items.filter((item) => item.transferable).length,
      blocked: items.filter((item) => !item.transferable).length,
      transferableAssetRecords: transferableAssetIds.size,
      associatedAssetRecords: rows.length
    }
  };
}

function locationTransferOverview(id, options = {}) {
  const db = getDb();
  const source = currentLocation(id, db);
  const destinationId = String(options.destinationLocationId || '').trim();
  const destination = destinationId ? validateTransferDestination(db, source, destinationId) : null;
  const plan = buildTransferPlan(db, source, destination);
  const query = String(options.q || '').trim().toLowerCase();
  const includeItems = options.includeItems === true || String(options.includeItems || '').toLowerCase() === 'true';
  const limit = Math.max(1, Math.min(100, Number(options.limit) || 40));
  let items = [];
  if (includeItems) {
    items = plan.items.filter((item) => item.transferable && (!query || [item.internalCode, item.description, item.categoryName].join(' ').toLowerCase().includes(query))).slice(0, limit);
  }
  return { location: source, destination, summary: plan.summary, items };
}

function directStockMovementNumber(transferNumber, index, suffix) {
  return `${transferNumber}-${String(index).padStart(4, '0')}-${suffix}`;
}

function moveQuantityStockInTransaction(db, asset, source, destination, transferId, transferNumber, now, context, movementIndexRef) {
  if (TRANSFER_SERIAL_NATURES.has(String(asset.category_nature || '').toUpperCase())) return;
  const lots = db.prepare(`SELECT * FROM stock_lot WHERE asset_id=? AND location_id=? AND active=1 ORDER BY lot_code COLLATE NOCASE`).all(asset.id, source.id);
  for (const lot of lots) {
    const quantity = Number(lot.quantity_on_hand || 0);
    const reserved = Number(lot.quantity_reserved || 0);
    if (reserved > 0) throw error(409, 'STOCK_RESERVED', `El stock ${asset.internal_code} tiene unidades reservadas.`);
    if (quantity <= 0) continue;
    let destinationLot = db.prepare(`SELECT * FROM stock_lot WHERE asset_id=? AND location_id=? AND lot_code=?`).get(asset.id, destination.id, lot.lot_code);
    if (!destinationLot) {
      const destinationLotId = randomUUID();
      db.prepare(`INSERT INTO stock_lot(id,asset_id,location_id,lot_code,expires_at,quantity_on_hand,quantity_reserved,active,version,created_at,updated_at)
        VALUES (?,?,?,?,?,0,0,1,1,?,?)`).run(destinationLotId, asset.id, destination.id, lot.lot_code, lot.expires_at || null, now, now);
      destinationLot = db.prepare('SELECT * FROM stock_lot WHERE id=?').get(destinationLotId);
    }
    const sourceBefore = quantity;
    const destBefore = Number(destinationLot.quantity_on_hand || 0);
    db.prepare(`UPDATE stock_lot SET quantity_on_hand=0,quantity_reserved=0,active=0,version=version+1,updated_at=? WHERE id=? AND version=?`)
      .run(now, lot.id, lot.version);
    const destChanged = db.prepare(`UPDATE stock_lot SET quantity_on_hand=quantity_on_hand+?,active=1,version=version+1,updated_at=? WHERE id=? AND version=?`)
      .run(quantity, now, destinationLot.id, destinationLot.version);
    if (destChanged.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', `El stock de ${asset.internal_code} cambió durante la transferencia.`);
    movementIndexRef.value += 1;
    db.prepare(`INSERT INTO stock_movement(id,movement_number,client_movement_id,asset_id,lot_id,movement_type,quantity,quantity_before,quantity_after,reserved_before,reserved_after,reference_type,reference_id,reason,actor_user_id,occurred_at,correlation_id,created_at)
      VALUES (?,?,?,?,?,'TRANSFERENCIA_SALIDA',?,?,?,?,?,'ASSET_LOCATION_TRANSFER',?,?,?,?,?,?)`)
      .run(randomUUID(), directStockMovementNumber(transferNumber, movementIndexRef.value, 'S'), null, asset.id, lot.id, quantity, sourceBefore, 0, reserved, 0, transferId, `Transferencia directa ${transferNumber}`, context.user.id, now, context.correlationId, now);
    movementIndexRef.value += 1;
    db.prepare(`INSERT INTO stock_movement(id,movement_number,client_movement_id,asset_id,lot_id,movement_type,quantity,quantity_before,quantity_after,reserved_before,reserved_after,reference_type,reference_id,reason,actor_user_id,occurred_at,correlation_id,created_at)
      VALUES (?,?,?,?,?,'TRANSFERENCIA_ENTRADA',?,?,?,?,?,'ASSET_LOCATION_TRANSFER',?,?,?,?,?,?)`)
      .run(randomUUID(), directStockMovementNumber(transferNumber, movementIndexRef.value, 'E'), null, asset.id, destinationLot.id, quantity, destBefore, destBefore + quantity, Number(destinationLot.quantity_reserved || 0), Number(destinationLot.quantity_reserved || 0), transferId, `Transferencia directa ${transferNumber}`, context.user.id, now, context.correlationId, now);
  }
}

function recordLocationTransfer(db, source, destination, selectedIds, mode, input, context) {
  if (!selectedIds.size) return { transfer: null, moved: [], source, destination };
  const now = new Date().toISOString();
  const transferId = randomUUID();
  const number = transferNumber(new Date(now));
  const reason = optionalString(input.reason, 'reason', { max: 500 });
  const storedMode = mode === 'AVAILABLE' ? 'ALL' : mode;
  const assets = [...selectedIds].map((assetId) => assetTransferRow(db, assetId));
  db.prepare(`INSERT INTO asset_location_transfer(id,transfer_number,source_location_id,destination_location_id,mode,item_count,reason,created_by_user_id,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?)`).run(transferId, number, source.id, destination.id, storedMode, assets.length, reason, context.user.id, context.correlationId, now);
  const insertItem = db.prepare(`INSERT INTO asset_location_transfer_item(id,transfer_id,asset_id,asset_code_snapshot,asset_description_snapshot,asset_status_snapshot,source_location_id,destination_location_id,asset_version_before,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?)`);
  const updateAsset = db.prepare(`UPDATE asset SET location_id=?,version=version+1,updated_at=? WHERE id=? AND location_id=? AND version=?`);
  const movementIndexRef = { value: 0 };
  for (const asset of assets) {
    insertItem.run(randomUUID(), transferId, asset.id, asset.internal_code, asset.description, asset.status, source.id, destination.id, asset.version, now);
    moveQuantityStockInTransaction(db, asset, source, destination, transferId, number, now, context, movementIndexRef);
    const moved = updateAsset.run(destination.id, now, asset.id, source.id, asset.version);
    if (moved.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', `El bien ${asset.internal_code} cambió durante la transferencia.`);
  }
  const transfer = db.prepare('SELECT * FROM asset_location_transfer WHERE id=?').get(transferId);
  auditContext(context, 'LOCATION.ASSETS.TRANSFER', 'asset_location_transfer', transferId, null,
    { transferNumber: number, sourceLocationId: source.id, destinationLocationId: destination.id, mode: storedMode, itemCount: assets.length, assetIds: assets.map((asset) => asset.id) }, db, reason);
  return { transfer, moved: assets.map((asset) => ({ id: asset.id, internalCode: asset.internal_code, description: asset.description })), source, destination };
}

function transferLocationAssetsInTransaction(db, sourceId, input, context, forcedMode = null) {
  const source = currentLocation(sourceId, db);
  if (!source.active) throw error(409, 'LOCATION_SOURCE_INACTIVE', 'La ubicación de origen está inactiva.');
  const version = expectedVersion(input);
  if (version !== source.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación. Actualizá la pantalla e intentá nuevamente.');
  const destinationId = requiredString(input.destinationLocationId, 'destinationLocationId', { min: 10, max: 80 });
  const destination = validateTransferDestination(db, source, destinationId);
  const requestedMode = String(forcedMode || input.mode || 'SELECTED').toUpperCase();
  const mode = ['AVAILABLE','EMPTY_AND_DEACTIVATE'].includes(requestedMode) ? requestedMode : 'SELECTED';
  if (mode === 'AVAILABLE' || mode === 'EMPTY_AND_DEACTIVATE') {
    const plan = buildTransferPlan(db, source, destination);
    const result = recordLocationTransfer(db, source, destination, plan.transferableAssetIds, mode, input, context);
    return { ...result, skipped: plan.items.filter((item) => !item.transferable), summary: plan.summary };
  }
  if (!Array.isArray(input.assetIds) || !input.assetIds.length) throw error(422, 'LOCATION_TRANSFER_ASSETS_REQUIRED', 'Elegí al menos un bien.');
  const selectedIds = new Set([...new Set(input.assetIds.map((value) => String(value || '').trim()).filter(Boolean))]);
  const blockers = expandKitSelection(db, source.id, selectedIds);
  for (const assetId of selectedIds) {
    const asset = assetTransferRow(db, assetId);
    const blocked = transferBlocker(db, asset, source, destination, selectedIds);
    if (blocked) blockers.push({ assetId, internalCode: asset?.internal_code || null, description: asset?.description || null, ...blocked });
  }
  if (blockers.length) throw error(409, 'LOCATION_TRANSFER_BLOCKED', 'Uno o más bienes ya no están disponibles para transferir.', { blockers });
  return recordLocationTransfer(db, source, destination, selectedIds, mode, input, context);
}


function transferSingleAssetLocation(assetId, input, context, options = {}) {
  return transaction((db) => {
    const permission = options.permission || 'Assets.Update';
    assertAssetScope(context.user, assetId, permission, db);
    const asset = assetTransferRow(db, assetId);
    if (!asset) throw error(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
    if (options.requiredNature && String(asset.category_nature || '').toUpperCase() !== String(options.requiredNature).toUpperCase()) {
      throw error(422, 'ASSET_NATURE_INVALID', `El bien no es de naturaleza ${options.requiredNature}.`);
    }
    if (options.forbiddenNature && String(asset.category_nature || '').toUpperCase() === String(options.forbiddenNature).toUpperCase()) {
      throw error(409, 'ASSET_MOVE_USE_SPECIALIZED_ENDPOINT', `Los bienes de naturaleza ${options.forbiddenNature} deben moverse desde su módulo específico.`);
    }
    const assetVersion = Number(input?.assetVersion);
    if (!Number.isInteger(assetVersion)) throw error(422, 'VERSION_REQUIRED', 'La versión del bien es obligatoria.');
    if (assetVersion !== Number(asset.version)) throw error(409, 'CONCURRENCY_CONFLICT', 'El bien fue modificado por otra operación. Actualizá la pantalla e intentá nuevamente.');
    const destinationId = requiredString(input.destinationLocationId, 'destinationLocationId', { min: 10, max: 80 });
    assertLocationScope(context.user, destinationId, permission, db);
    const source = currentLocation(asset.location_id, db);
    const destination = validateTransferDestination(db, source, destinationId);
    const selectedIds = new Set([assetId]);
    const blockers = expandKitSelection(db, source.id, selectedIds);
    for (const selectedId of selectedIds) {
      const selected = assetTransferRow(db, selectedId);
      const blocked = transferBlocker(db, selected, source, destination, selectedIds);
      if (blocked) blockers.push({ assetId: selectedId, internalCode: selected?.internal_code || null, description: selected?.description || null, ...blocked });
    }
    if (blockers.length) throw error(409, 'LOCATION_TRANSFER_BLOCKED', blockers[0].message || 'El bien no está disponible para transferir.', { blockers });
    const result = recordLocationTransfer(db, source, destination, selectedIds, 'SELECTED', input, context);
    return { ...result, asset: assetTransferRow(db, assetId) };
  });
}

function transferLocationAssets(sourceId, input, context) {
  return transaction((db) => transferLocationAssetsInTransaction(db, sourceId, input, context));
}

function emptyAndDeleteLocation(sourceId, input, context) {
  return transaction((db) => {
    const source = currentLocation(sourceId, db);
    const version = expectedVersion(input);
    if (version !== source.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La ubicación fue modificada por otra operación. Actualizá la pantalla e intentá nuevamente.');
    const destinationId = requiredString(input.destinationLocationId, 'destinationLocationId', { min: 10, max: 80 });
    const destination = validateTransferDestination(db, source, destinationId);
    const plan = buildTransferPlan(db, source, destination);
    const result = recordLocationTransfer(db, source, destination, plan.transferableAssetIds, 'EMPTY_AND_DEACTIVATE', input, context);
    let location = currentLocation(sourceId, db);
    const blockers = locationDeleteBlockers(db, sourceId);
    let deleted = false;
    if (!hasDeleteBlockers(blockers)) {
      location = deleteLocationInTransaction(db, location, location.version, context, input.reason || 'Vaciar y eliminar ubicación', 'LOCATION.EMPTY_AND_DELETE');
      deleted = true;
    } else {
      auditContext(context, 'LOCATION.EMPTY_PROGRESS', 'storage_location', sourceId, source,
        { location, movedCount: result.moved.length, blockers, deleted: false }, db, input.reason || 'Vaciar ubicación');
    }
    return { ...result, location, deleted, blockers, remainingCount: Number(blockers.activeAssets || 0), skipped: plan.items.filter((item) => !item.transferable), summary: plan.summary };
  });
}

function emptyAndDeactivateLocation(sourceId, input, context) {
  return emptyAndDeleteLocation(sourceId, input, context);
}

module.exports = {
  listLocations,
  updateOrganization,
  createSite,
  updateSite,
  deleteSite,
  createLocation,
  updateLocation,
  setLocationActive,
  deleteLocation,
  locationTransferOverview,
  transferLocationAssets,
  transferSingleAssetLocation,
  emptyAndDeactivateLocation,
  emptyAndDeleteLocation
};
