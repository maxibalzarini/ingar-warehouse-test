'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, parseBoolean } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const { claimEvidence, saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { permissionAssignments, userHasScope, assertUserScope, scopeWhere } = require('../security/scope');

const INCIDENT_TYPES = new Set(['DANO', 'FALTANTE', 'CONDICION_INSEGURA', 'PERDIDA', 'ROBO', 'INCUMPLIMIENTO', 'OTRO']);
const SEVERITIES = new Set(['BAJA', 'MEDIA', 'ALTA', 'CRITICA']);
const RESOLUTION_CODES = new Set(['RECUPERADO_CONFORME', 'RECUPERADO_BLOQUEADO', 'REPARACION_REQUERIDA', 'BAJA_DEFINITIVA', 'SIN_RECUPERACION', 'SIN_RESPONSABILIDAD', 'RESPONSABILIDAD_DETERMINADA', 'OTRA']);
const RECOVERY_CONDITIONS = new Set(['CONFORME', 'OBSERVADO', 'DANADO', 'INCOMPLETO']);
const OPEN_CUSTODY_STATUSES = new Set(['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE']);
const ACTION_TYPES = new Set(['ENTREVISTA', 'INSPECCION', 'VERIFICACION', 'DOCUMENTACION', 'CORRECTIVA', 'PREVENTIVA', 'OTRA']);

function error(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function iso(value, field, { required = false } = {}) {
  if ((value === null || value === undefined || value === '') && !required) return null;
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) throw error(422, 'DATE_INVALID', `Fecha inválida: ${field}.`, [{ field, message: 'Fecha y hora inválidas.' }]);
  return date.toISOString();
}

function amount(value, field) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0 || number > 1_000_000_000_000) throw error(422, 'AMOUNT_INVALID', `Importe inválido: ${field}.`);
  return Math.round(number * 100) / 100;
}

function requireScope(user, siteId, locationId = null, permission = null, db = getDb()) {
  assertUserScope(user, siteId, locationId, permission, db);
}


function uniqueScopeRows(rows) {
  const seen = new Set();
  const output = [];
  for (const row of rows || []) {
    const siteId = row?.site_id || row?.siteId || null;
    const locationId = row?.location_id || row?.locationId || null;
    const key = `${siteId || '*'}|${locationId || '*'}`;
    if (seen.has(key)) continue;
    seen.add(key);
    output.push({ siteId, locationId });
  }
  return output;
}

function personOperationalScopes(db, personId) {
  const now = new Date().toISOString();
  const assigned = db.prepare(`SELECT DISTINCT urs.site_id,urs.location_id
    FROM user_account ua JOIN user_role_scope urs ON urs.user_id=ua.id JOIN role r ON r.id=urs.role_id
    WHERE ua.person_id=? AND ua.active=1 AND ua.deleted_at IS NULL AND r.active=1
      AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)`).all(personId, now, now);
  if (assigned.some((row) => !row.site_id && !row.location_id)) return { global: true, known: true, scopes: [] };
  const assetCustody = db.prepare(`SELECT DISTINCT sl.site_id,a.location_id
    FROM asset a JOIN storage_location sl ON sl.id=a.location_id
    WHERE a.custodian_person_id=? AND a.deleted_at IS NULL
    UNION
    SELECT DISTINCT sl.site_id,a.location_id
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE c.person_id=? AND c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE')`).all(personId, personId);
  const scopes = uniqueScopeRows([...assigned, ...assetCustody]);
  return { global: false, known: scopes.length > 0, scopes };
}

function blockAccessDescriptor(db, block) {
  if (!block) return { global: true, readableByScoped: false, scopes: [] };
  if (block.scope_type === 'UBICACION' && block.location_id) {
    const location = db.prepare('SELECT site_id FROM storage_location WHERE id=?').get(block.location_id);
    return location ? { global: false, readableByScoped: false, scopes: [{ siteId: location.site_id, locationId: block.location_id }] } : { global: true, readableByScoped: false, scopes: [] };
  }
  if (block.scope_type === 'SEDE' && block.site_id) return { global: false, readableByScoped: false, scopes: [{ siteId: block.site_id, locationId: null }] };
  if (block.target_type === 'ACTIVO') {
    const asset = db.prepare('SELECT a.location_id,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL').get(block.target_id);
    return asset ? { global: false, readableByScoped: false, scopes: [{ siteId: asset.site_id, locationId: asset.location_id }] } : { global: true, readableByScoped: false, scopes: [] };
  }
  if (block.target_type === 'PERSONA') {
    const personScopes = personOperationalScopes(db, block.target_id);
    if (personScopes.global) return { global: true, readableByScoped: true, scopes: [] };
    if (!personScopes.known) return { global: true, readableByScoped: false, scopes: [] };
    return { ...personScopes, readableByScoped: false };
  }
  // Una categoría sin sede/ubicación explícita afecta a todo el sistema.
  if (block.target_type === 'CATEGORIA') return { global: true, readableByScoped: true, scopes: [] };
  return { global: true, readableByScoped: false, scopes: [] };
}

function assignmentMatchesScope(assignment, scope) {
  if (!assignment.site_id && !assignment.location_id) return true;
  if (assignment.location_id) return assignment.location_id === scope.locationId && (!assignment.site_id || assignment.site_id === scope.siteId);
  return assignment.site_id === scope.siteId;
}

function userCanAccessBlock(user, block, permission, mode = 'read', db = getDb()) {
  const assignments = permissionAssignments(user, permission, db);
  if (!assignments.length) return false;
  const hasGlobal = assignments.some((assignment) => !assignment.site_id && !assignment.location_id);
  if (hasGlobal) return true;
  const descriptor = blockAccessDescriptor(db, block);
  if (descriptor.global) {
    // Los bloqueos globales son visibles para quien tenga permiso, pero sólo
    // pueden crearse/modificarse con una asignación global del permiso.
    return mode === 'read' && descriptor.readableByScoped === true;
  }
  if (!descriptor.scopes.length) return false;
  if (mode === 'manage') return descriptor.scopes.every((scope) => assignments.some((assignment) => assignmentMatchesScope(assignment, scope)));
  return descriptor.scopes.some((scope) => assignments.some((assignment) => assignmentMatchesScope(assignment, scope)));
}

function assertBlockAccess(user, block, permission, mode = 'read', db = getDb()) {
  if (!userCanAccessBlock(user, block, permission, mode, db)) {
    throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
  }
}

function exceptionAccessDescriptor(db, block, assetId = null) {
  if (assetId) {
    const asset = db.prepare('SELECT a.location_id,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL').get(assetId);
    if (asset) return { global: false, scopes: [{ siteId: asset.site_id, locationId: asset.location_id }] };
  }
  return blockAccessDescriptor(db, block);
}

function userCanAccessException(user, block, exception, permission, mode = 'read', db = getDb()) {
  const assignments = permissionAssignments(user, permission, db);
  if (!assignments.length) return false;
  const hasGlobal = assignments.some((assignment) => !assignment.site_id && !assignment.location_id);
  if (hasGlobal) return true;
  const descriptor = exceptionAccessDescriptor(db, block, exception?.asset_id || null);
  if (descriptor.global) return mode === 'read' && descriptor.readableByScoped === true;
  if (mode === 'manage') return descriptor.scopes.every((scope) => assignments.some((assignment) => assignmentMatchesScope(assignment, scope)));
  return descriptor.scopes.some((scope) => assignments.some((assignment) => assignmentMatchesScope(assignment, scope)));
}

function assertExceptionAccess(user, block, exception, permission, mode = 'read', db = getDb()) {
  if (!userCanAccessException(user, block, exception, permission, mode, db)) {
    throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
  }
}

function nextNumber(db, table, column, prefix, now = new Date()) {
  const year = now.getUTCFullYear();
  const pattern = `${prefix}-${year}-%`;
  const count = db.prepare(`SELECT COUNT(*) AS n FROM ${table} WHERE ${column} LIKE ?`).get(pattern).n + 1;
  return `${prefix}-${year}-${String(count).padStart(6, '0')}`;
}

function incidentSelect() {
  return `SELECT i.*, a.internal_code, a.description AS asset_description, a.serial_number, a.license_plate, a.status AS asset_status,
    a.location_id, a.category_id, ac.code AS category_code, ac.name AS category_name, ac.nature AS category_nature,
    sl.code AS location_code, sl.name AS location_name, s.id AS site_id, s.code AS site_code, s.name AS site_name,
    rp.full_name AS reporter_name, ap.full_name AS assigned_name, lp.full_name AS liability_name,
    c.person_id AS custody_person_id, cp.full_name AS custody_person_name, c.status AS custody_status
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN asset_category ac ON ac.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id
    JOIN user_account ru ON ru.id=i.reported_by_user_id JOIN person rp ON rp.id=ru.person_id
    LEFT JOIN user_account au ON au.id=i.assigned_to_user_id LEFT JOIN person ap ON ap.id=au.person_id
    LEFT JOIN person lp ON lp.id=i.liability_person_id LEFT JOIN custody c ON c.id=i.custody_id LEFT JOIN person cp ON cp.id=c.person_id`;
}

function hydrateIncident(db, row) {
  if (!row) return null;
  let assetSnapshot = {};
  try { assetSnapshot = JSON.parse(row.asset_snapshot_json || '{}'); } catch { assetSnapshot = {}; }
  return {
    ...row,
    assetSnapshot,
    events: db.prepare(`SELECT ie.*, ua.username, p.full_name AS actor_name FROM incident_event ie
      LEFT JOIN user_account ua ON ua.id=ie.actor_user_id LEFT JOIN person p ON p.id=ua.person_id
      WHERE ie.incident_id=? ORDER BY ie.occurred_at,ie.created_at`).all(row.id),
    evidence: db.prepare(`SELECT ie.*, fe.filename,fe.mime_type,fe.size,fe.sha256,fe.file_ref,p.full_name AS added_by_name
      FROM incident_evidence ie JOIN file_evidence fe ON fe.id=ie.evidence_id
      JOIN user_account ua ON ua.id=ie.added_by_user_id JOIN person p ON p.id=ua.person_id
      WHERE ie.incident_id=? ORDER BY ie.created_at`).all(row.id),
    actions: db.prepare(`SELECT ia.*, p.full_name AS assigned_name, cp.full_name AS created_by_name
      FROM incident_investigation_action ia LEFT JOIN user_account au ON au.id=ia.assigned_to_user_id LEFT JOIN person p ON p.id=au.person_id
      JOIN user_account cu ON cu.id=ia.created_by_user_id JOIN person cp ON cp.id=cu.person_id
      WHERE ia.incident_id=? ORDER BY ia.created_at`).all(row.id),
    blocks: db.prepare(`SELECT ob.* FROM operational_block ob WHERE ob.incident_id=? ORDER BY ob.created_at`).all(row.id)
  };
}

function getIncidentFromDb(db, id) {
  return hydrateIncident(db, db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id));
}

function getIncident(id, user) {
  const incident = getIncidentFromDb(getDb(), id);
  if (!incident) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
  requireScope(user, incident.site_id, incident.location_id, 'Incident.Read');
  return incident;
}

function listIncidentsPage(filters, user, options = {}) {
  const db = getDb();
  const where = [];
  const params = [];
  const scope = scopeWhere(user, 'Incident.Read', 's.id', 'a.location_id', db);
  where.push(`(${scope.sql})`); params.push(...scope.params);
  const statuses = String(filters.statuses || '').split(',').map((value) => value.trim().toUpperCase()).filter(Boolean);
  if (statuses.length) { where.push(`i.status IN (${statuses.map(() => '?').join(',')})`); params.push(...statuses); }
  else if (filters.status) { where.push('i.status=?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.severity) { where.push('i.severity=?'); params.push(String(filters.severity).toUpperCase()); }
  if (filters.type) { where.push('i.type=?'); params.push(String(filters.type).toUpperCase()); }
  if (filters.assetId) { where.push('i.asset_id=?'); params.push(filters.assetId); }
  if (filters.openedFrom) { where.push('i.opened_at>=?'); params.push(new Date(filters.openedFrom).toISOString()); }
  if (filters.openedTo) { where.push('i.opened_at<?'); params.push(new Date(filters.openedTo).toISOString()); }
  if (filters.assignedToMe === 'true' || filters.assignedToMe === true) { where.push('i.assigned_to_user_id=?'); params.push(user.id); }
  if (filters.search) {
    const q = `%${String(filters.search).trim()}%`;
    where.push('(i.incident_number LIKE ? OR i.title LIKE ? OR i.description LIKE ? OR a.internal_code LIKE ? OR a.description LIKE ?)');
    params.push(q, q, q, q, q);
  }
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = Number(db.prepare(`SELECT COUNT(*) AS n FROM incident i JOIN asset a ON a.id=i.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id JOIN user_account ru ON ru.id=i.reported_by_user_id JOIN person rp ON rp.id=ru.person_id ${whereSql}`).get(...params)?.n || 0);
  const orderSql = `ORDER BY CASE i.severity WHEN 'CRITICA' THEN 0 WHEN 'ALTA' THEN 1 WHEN 'MEDIA' THEN 2 ELSE 3 END,
    CASE i.status WHEN 'ABIERTO' THEN 0 WHEN 'EN_INVESTIGACION' THEN 1 WHEN 'RESUELTO' THEN 2 ELSE 3 END,i.opened_at DESC`;
  if (options.all === true) {
    const items = db.prepare(`${incidentSelect()} ${whereSql} ${orderSql}`).all(...params).map((row) => hydrateIncident(db, row));
    return { items, total, limit: total, offset: 0 };
  }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const items = db.prepare(`${incidentSelect()} ${whereSql} ${orderSql} LIMIT ? OFFSET ?`)
    .all(...params, limit, offset).map((row) => hydrateIncident(db, row));
  return { items, total, limit, offset };
}

function listIncidents(filters, user) {
  return listIncidentsPage(filters, user).items;
}

function addIncidentEvent(db, incidentId, eventType, fromStatus, toStatus, actorUserId, details, correlationId, metadata = null, now = new Date().toISOString()) {
  db.prepare(`INSERT INTO incident_event(id,incident_id,event_type,from_status,to_status,actor_user_id,details,metadata_json,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(), incidentId, eventType, fromStatus || null, toStatus || null, actorUserId || null,
      requiredString(details, 'details', { min: 3, max: 3000 }), metadata ? JSON.stringify(metadata) : null, now, correlationId, now);
}

function addCustodyEvent(db, custodyId, fromStatus, toStatus, actorUserId, reason, correlationId, now) {
  db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(randomUUID(), custodyId, fromStatus || null, toStatus, actorUserId || null, reason, now, correlationId, now);
}

function normalizeTarget(db, targetType, targetId) {
  if (targetType === 'PERSONA') {
    const row = db.prepare("SELECT id,full_name AS label FROM person WHERE id=? AND deleted_at IS NULL").get(targetId);
    if (!row) throw error(422, 'BLOCK_TARGET_INVALID', 'La persona indicada no existe.');
    return row;
  }
  if (targetType === 'ACTIVO') {
    const row = db.prepare(`SELECT a.id,a.internal_code AS label,a.location_id,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL`).get(targetId);
    if (!row) throw error(422, 'BLOCK_TARGET_INVALID', 'El bien indicado no existe.');
    return row;
  }
  if (targetType === 'CATEGORIA') {
    const row = db.prepare("SELECT id,name AS label FROM asset_category WHERE id=? AND deleted_at IS NULL").get(targetId);
    if (!row) throw error(422, 'BLOCK_TARGET_INVALID', 'La categoría indicada no existe.');
    return row;
  }
  throw error(422, 'BLOCK_TARGET_TYPE_INVALID', 'Tipo de objetivo de bloqueo inválido.');
}

function normalizeBlock(input, context, db, scopePermission = 'Blocks.Manage') {
  const targetType = String(input.targetType || '').toUpperCase();
  const targetId = requiredString(input.targetId, 'targetId', { min: 8, max: 80 });
  const target = normalizeTarget(db, targetType, targetId);
  const scopeType = String(input.scopeType || 'TOTAL').toUpperCase();
  if (!['TOTAL', 'SEDE', 'UBICACION', 'CATEGORIA', 'OPERACION'].includes(scopeType)) throw error(422, 'BLOCK_SCOPE_INVALID', 'Alcance de bloqueo inválido.');
  const siteId = input.siteId || null;
  const locationId = input.locationId || null;
  const categoryId = input.categoryId || null;
  const operationType = input.operationType ? String(input.operationType).toUpperCase() : null;
  if (scopeType === 'SEDE' && !db.prepare('SELECT 1 FROM site WHERE id=? AND active=1').get(siteId)) throw error(422, 'BLOCK_SITE_REQUIRED', 'La sede es obligatoria y debe estar activa.');
  if (scopeType === 'UBICACION' && !db.prepare('SELECT 1 FROM storage_location WHERE id=? AND active=1').get(locationId)) throw error(422, 'BLOCK_LOCATION_REQUIRED', 'La ubicación es obligatoria y debe estar activa.');
  if (scopeType === 'CATEGORIA' && !db.prepare('SELECT 1 FROM asset_category WHERE id=? AND active=1 AND deleted_at IS NULL').get(categoryId)) throw error(422, 'BLOCK_CATEGORY_REQUIRED', 'La categoría es obligatoria y debe estar activa.');
  if (scopeType === 'OPERACION' && !['RETIRO', 'RESERVA', 'TRANSFERENCIA'].includes(operationType)) throw error(422, 'BLOCK_OPERATION_REQUIRED', 'La operación es obligatoria.');
  const accessCandidate = {
    target_type: targetType, target_id: targetId, scope_type: scopeType,
    site_id: scopeType === 'SEDE' ? siteId : null,
    location_id: scopeType === 'UBICACION' ? locationId : null,
    category_id: scopeType === 'CATEGORIA' ? categoryId : null,
    operation_type: scopeType === 'OPERACION' ? operationType : null
  };
  assertBlockAccess(context.user, accessCandidate, scopePermission, 'manage', db);
  if (targetType === 'PERSONA' && ['SEDE', 'UBICACION'].includes(scopeType)) {
    const personScopes = personOperationalScopes(db, targetId);
    const selected = { siteId: scopeType === 'SEDE' ? siteId : db.prepare('SELECT site_id FROM storage_location WHERE id=?').get(locationId)?.site_id, locationId: scopeType === 'UBICACION' ? locationId : null };
    const creatorHasGlobal = permissionAssignments(context.user, scopePermission, db).some((assignment) => !assignment.site_id && !assignment.location_id);
    const related = personScopes.global || personScopes.scopes.some((scope) => {
      if (selected.locationId) return scope.locationId === selected.locationId || (!scope.locationId && scope.siteId === selected.siteId);
      return scope.siteId === selected.siteId;
    });
    if (!related && !creatorHasGlobal) throw error(403, 'BLOCK_TARGET_SCOPE_FORBIDDEN', 'La persona indicada no pertenece al alcance asignado.');
  }
  if (targetType === 'ACTIVO') {
    if (scopeType === 'SEDE' && siteId !== target.site_id) throw error(422, 'BLOCK_TARGET_SCOPE_MISMATCH', 'La sede del bloqueo no corresponde al bien seleccionado.');
    if (scopeType === 'UBICACION' && locationId !== target.location_id) throw error(422, 'BLOCK_TARGET_SCOPE_MISMATCH', 'La ubicación del bloqueo no corresponde al bien seleccionado.');
  }
  const startsAt = iso(input.startsAt || new Date().toISOString(), 'startsAt', { required: true });
  const expiresAt = iso(input.expiresAt, 'expiresAt');
  if (expiresAt && new Date(expiresAt) <= new Date(startsAt)) throw error(422, 'BLOCK_EXPIRY_INVALID', 'El vencimiento debe ser posterior al inicio.');
  const severity = String(input.severity || 'MEDIA').toUpperCase();
  if (!SEVERITIES.has(severity)) throw error(422, 'INCIDENT_SEVERITY_INVALID', 'Severidad inválida.');
  return {
    targetType, targetId, target, scopeType, siteId: scopeType === 'SEDE' ? siteId : null,
    locationId: scopeType === 'UBICACION' ? locationId : null, categoryId: scopeType === 'CATEGORIA' ? categoryId : null,
    operationType: scopeType === 'OPERACION' ? operationType : null,
    reason: requiredString(input.reason, 'reason', { min: 5, max: 2000 }), source: String(input.source || 'MANUAL').toUpperCase(),
    incidentId: input.incidentId || null, severity, startsAt, expiresAt
  };
}

function createBlockInDb(db, input, context, options = {}) {
  const data = normalizeBlock(input, context, db, options.scopePermission || 'Blocks.Manage');
  if (!['MANUAL', 'INCIDENTE', 'AUTOMATICO'].includes(data.source)) throw error(422, 'BLOCK_SOURCE_INVALID', 'Origen de bloqueo inválido.');
  if (data.incidentId && !db.prepare('SELECT 1 FROM incident WHERE id=?').get(data.incidentId)) throw error(422, 'INCIDENT_NOT_FOUND', 'Incidente asociado inexistente.');
  const existing = db.prepare(`SELECT * FROM operational_block WHERE target_type=? AND target_id=? AND scope_type=?
    AND ifnull(site_id,'')=ifnull(?,'') AND ifnull(location_id,'')=ifnull(?,'') AND ifnull(category_id,'')=ifnull(?,'')
    AND ifnull(operation_type,'')=ifnull(?,'') AND status='ACTIVO'`).get(data.targetType, data.targetId, data.scopeType, data.siteId, data.locationId, data.categoryId, data.operationType);
  if (existing) {
    if (options.returnExisting) return existing;
    throw error(409, 'BLOCK_ALREADY_ACTIVE', 'Ya existe un bloqueo activo con el mismo objetivo y alcance.');
  }
  const now = options.now || new Date().toISOString();
  const id = randomUUID();
  const number = nextNumber(db, 'operational_block', 'block_number', 'BLQ', new Date(now));
  db.prepare(`INSERT INTO operational_block(id,block_number,target_type,target_id,scope_type,site_id,location_id,category_id,operation_type,reason,source,incident_id,severity,status,starts_at,expires_at,created_by_user_id,approved_by_user_id,version,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'ACTIVO',?,?,?,?,1,?,?)`).run(id, number, data.targetType, data.targetId, data.scopeType, data.siteId, data.locationId,
      data.categoryId, data.operationType, data.reason, data.source, data.incidentId, data.severity, data.startsAt, data.expiresAt, context.user.id, context.user.id, now, now);
  if (data.targetType === 'ACTIVO') {
    db.prepare(`UPDATE asset SET status=CASE WHEN status IN ('PERDIDO','MANTENIMIENTO','BAJA','EN_CUSTODIA') THEN status ELSE 'BLOQUEADO' END,
      quantity_available=CASE WHEN status IN ('PERDIDO','MANTENIMIENTO','BAJA','RESERVADO') THEN quantity_available ELSE 0 END,version=version+1,updated_at=? WHERE id=?`).run(now, data.targetId);
  }
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'BLOCK.CREATE', entityType: 'operational_block', entityId: id,
    after: { blockNumber: number, ...data }, reason: data.reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
  return db.prepare('SELECT * FROM operational_block WHERE id=?').get(id);
}

function createBlock(input, context) {
  return transaction((db) => createBlockInDb(db, input, context));
}

function effectiveBlockStatus(row, now = Date.now()) {
  if (row.status !== 'ACTIVO') return row.status;
  return row.expires_at && new Date(row.expires_at).getTime() <= now ? 'EXPIRADO' : 'ACTIVO';
}

function scopedColumnPredicate(assignments, siteExpression, locationExpression) {
  if (!assignments.length) return { sql: '0=1', params: [] };
  if (assignments.some((item) => !item.site_id && !item.location_id)) return { sql: '1=1', params: [] };
  const siteIds = [...new Set(assignments.filter((item) => item.site_id && !item.location_id).map((item) => item.site_id))];
  const locationIds = [...new Set(assignments.filter((item) => item.location_id).map((item) => item.location_id))];
  const clauses = [];
  const params = [];
  if (siteIds.length) { clauses.push(`${siteExpression} IN (${siteIds.map(() => '?').join(',')})`); params.push(...siteIds); }
  if (locationIds.length) { clauses.push(`${locationExpression} IN (${locationIds.map(() => '?').join(',')})`); params.push(...locationIds); }
  return { sql: clauses.length ? `(${clauses.join(' OR ')})` : '0=1', params };
}

function blockReadScopeWhere(user, permission, db = getDb(), alias = 'ob') {
  const assignments = permissionAssignments(user, permission, db);
  if (!assignments.length) return { sql: '0=1', params: [] };
  if (assignments.some((item) => !item.site_id && !item.location_id)) return { sql: '1=1', params: [] };
  const siteIds = [...new Set(assignments.filter((item) => item.site_id && !item.location_id).map((item) => item.site_id))];
  const locationIds = [...new Set(assignments.filter((item) => item.location_id).map((item) => item.location_id))];
  const clauses = [];
  const params = [];
  if (siteIds.length) {
    clauses.push(`(${alias}.scope_type='SEDE' AND ${alias}.site_id IN (${siteIds.map(() => '?').join(',')}))`);
    params.push(...siteIds);
  }
  const locationClauses = [];
  if (locationIds.length) { locationClauses.push(`${alias}.location_id IN (${locationIds.map(() => '?').join(',')})`); params.push(...locationIds); }
  if (siteIds.length) { locationClauses.push(`EXISTS (SELECT 1 FROM storage_location bsl WHERE bsl.id=${alias}.location_id AND bsl.site_id IN (${siteIds.map(() => '?').join(',')}))`); params.push(...siteIds); }
  if (locationClauses.length) clauses.push(`(${alias}.scope_type='UBICACION' AND (${locationClauses.join(' OR ')}))`);

  const assetScope = scopedColumnPredicate(assignments, 'bas.site_id', 'ba.location_id');
  const personScopeParts = [];
  const personParams = [];
  const now = new Date().toISOString();
  personScopeParts.push(`EXISTS (SELECT 1 FROM user_account pua JOIN user_role_scope purs ON purs.user_id=pua.id JOIN role pr ON pr.id=purs.role_id
    WHERE pua.person_id=${alias}.target_id AND pua.active=1 AND pua.deleted_at IS NULL AND pr.active=1
      AND (purs.valid_from IS NULL OR purs.valid_from<=?) AND (purs.valid_to IS NULL OR purs.valid_to>=?)
      AND purs.site_id IS NULL AND purs.location_id IS NULL)`);
  personParams.push(now, now);
  if (siteIds.length) {
    personScopeParts.push(`EXISTS (SELECT 1 FROM user_account pua JOIN user_role_scope purs ON purs.user_id=pua.id JOIN role pr ON pr.id=purs.role_id
      WHERE pua.person_id=${alias}.target_id AND pua.active=1 AND pua.deleted_at IS NULL AND pr.active=1
        AND (purs.valid_from IS NULL OR purs.valid_from<=?) AND (purs.valid_to IS NULL OR purs.valid_to>=?)
        AND purs.site_id IN (${siteIds.map(() => '?').join(',')}))`);
    personParams.push(now, now, ...siteIds);
  }
  if (locationIds.length) {
    personScopeParts.push(`EXISTS (SELECT 1 FROM user_account pua JOIN user_role_scope purs ON purs.user_id=pua.id JOIN role pr ON pr.id=purs.role_id
      WHERE pua.person_id=${alias}.target_id AND pua.active=1 AND pua.deleted_at IS NULL AND pr.active=1
        AND (purs.valid_from IS NULL OR purs.valid_from<=?) AND (purs.valid_to IS NULL OR purs.valid_to>=?)
        AND purs.location_id IN (${locationIds.map(() => '?').join(',')}))`);
    personParams.push(now, now, ...locationIds);
  }
  const custodianScope = scopedColumnPredicate(assignments, 'csl.site_id', 'ca.location_id');
  personScopeParts.push(`EXISTS (SELECT 1 FROM asset ca JOIN storage_location csl ON csl.id=ca.location_id
    WHERE ca.custodian_person_id=${alias}.target_id AND ca.deleted_at IS NULL AND (${custodianScope.sql}))`);
  personParams.push(...custodianScope.params);
  const custodyScope = scopedColumnPredicate(assignments, 'csl2.site_id', 'ca2.location_id');
  personScopeParts.push(`EXISTS (SELECT 1 FROM custody cc JOIN asset ca2 ON ca2.id=cc.asset_id JOIN storage_location csl2 ON csl2.id=ca2.location_id
    WHERE cc.person_id=${alias}.target_id AND cc.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE') AND (${custodyScope.sql}))`);
  personParams.push(...custodyScope.params);

  const targetParts = [
    `(${alias}.target_type='ACTIVO' AND EXISTS (SELECT 1 FROM asset ba JOIN storage_location bas ON bas.id=ba.location_id WHERE ba.id=${alias}.target_id AND ba.deleted_at IS NULL AND (${assetScope.sql})))`,
    `(${alias}.target_type='PERSONA' AND (${personScopeParts.join(' OR ')}))`,
    `(${alias}.target_type='CATEGORIA')`
  ];
  clauses.push(`(${alias}.scope_type NOT IN ('SEDE','UBICACION') AND (${targetParts.join(' OR ')}))`);
  params.push(...assetScope.params, ...personParams);
  return { sql: clauses.length ? `(${clauses.join(' OR ')})` : '0=1', params };
}

function hydrateBlock(db, row, user = null) {
  if (!row) return null;
  let targetLabel = row.target_id;
  if (row.target_type === 'PERSONA') targetLabel = db.prepare('SELECT full_name AS label FROM person WHERE id=?').get(row.target_id)?.label || row.target_id;
  if (row.target_type === 'ACTIVO') targetLabel = db.prepare("SELECT internal_code || ' — ' || description AS label FROM asset WHERE id=?").get(row.target_id)?.label || row.target_id;
  if (row.target_type === 'CATEGORIA') targetLabel = db.prepare("SELECT code || ' — ' || name AS label FROM asset_category WHERE id=?").get(row.target_id)?.label || row.target_id;
  let exceptions = db.prepare(`SELECT be.*,p.full_name AS person_name,a.internal_code AS asset_code FROM block_exception be JOIN person p ON p.id=be.person_id
      LEFT JOIN asset a ON a.id=be.asset_id WHERE be.block_id=? ORDER BY be.created_at DESC`).all(row.id);
  if (user) exceptions = exceptions.filter((exception) => userCanAccessException(user, row, exception, 'Blocks.Read', 'read', db));
  return { ...row, target_label: targetLabel, effective_status: effectiveBlockStatus(row), exceptions };
}

function listBlocksPage(filters, user) {
  const where = [];
  const params = [];
  const db = getDb();
  const scope = blockReadScopeWhere(user, 'Blocks.Read', db, 'ob');
  where.push(`(${scope.sql})`); params.push(...scope.params);
  if (filters.status) {
    const status = String(filters.status).toUpperCase();
    if (status === 'ACTIVO') { where.push("ob.status='ACTIVO' AND (ob.expires_at IS NULL OR ob.expires_at>?)"); params.push(new Date().toISOString()); }
    else if (status === 'EXPIRADO') { where.push("ob.status='EXPIRADO' OR (ob.status='ACTIVO' AND ob.expires_at IS NOT NULL AND ob.expires_at<=?)"); params.push(new Date().toISOString()); }
    else { where.push('ob.status=?'); params.push(status); }
  }
  if (filters.targetType) { where.push('ob.target_type=?'); params.push(String(filters.targetType).toUpperCase()); }
  if (filters.source) { where.push('ob.source=?'); params.push(String(filters.source).toUpperCase()); }
  if (filters.search) { const q = `%${String(filters.search).trim()}%`; where.push('(ob.block_number LIKE ? OR ob.reason LIKE ? OR ob.target_id LIKE ?)'); params.push(q, q, q); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = Number(db.prepare(`SELECT COUNT(*) AS n FROM operational_block ob ${whereSql}`).get(...params)?.n || 0);
  const items = db.prepare(`SELECT ob.* FROM operational_block ob ${whereSql} ORDER BY ob.created_at DESC LIMIT ? OFFSET ?`).all(...params, limit, offset).map((row) => hydrateBlock(db, row, user));
  return { items, total, limit, offset };
}

function listBlocks(filters, user) {
  return listBlocksPage(filters, user).items;
}

function getBlock(id, user) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM operational_block WHERE id=?').get(id);
  if (!row) throw error(404, 'BLOCK_NOT_FOUND', 'Bloqueo no encontrado.');
  assertBlockAccess(user, row, 'Blocks.Read', 'read', db);
  return hydrateBlock(db, row, user);
}

function activeIncidentExists(db, assetId) {
  return Boolean(db.prepare("SELECT 1 FROM incident WHERE asset_id=? AND status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO') LIMIT 1").get(assetId));
}

function otherActiveBlockExists(db, assetId, exceptId, now) {
  return Boolean(db.prepare(`SELECT 1 FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND id<>? AND status='ACTIVO'
    AND starts_at<=? AND (expires_at IS NULL OR expires_at>?) LIMIT 1`).get(assetId, exceptId, now, now));
}

function liftBlock(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM operational_block WHERE id=?').get(id);
    if (!current) throw error(404, 'BLOCK_NOT_FOUND', 'Bloqueo no encontrado.');
    assertBlockAccess(context.user, current, 'Blocks.Manage', 'manage', db);
    if (current.target_type === 'ACTIVO') {
      throw error(409, 'ASSET_BLOCK_LIFT_REQUIRES_MANUAL_RELEASE', 'Los bloqueos aplicados a bienes no se levantan desde Bloqueos. Use Habilitar bien para conservar la trazabilidad completa.');
    }
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'El bloqueo fue modificado por otra operación.');
    if (effectiveBlockStatus(current) !== 'ACTIVO') throw error(409, 'BLOCK_NOT_ACTIVE', 'El bloqueo ya no está activo.');
    const reason = requiredString(input.reason, 'reason', { min: 10, max: 2000 });
    const now = new Date().toISOString();
    const changed = db.prepare(`UPDATE operational_block SET status='LEVANTADO',lifted_by_user_id=?,lifted_at=?,lift_reason=?,version=version+1,updated_at=?
      WHERE id=? AND version=? AND status='ACTIVO'`).run(context.user.id, now, reason, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al levantar bloqueo.');
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'BLOCK.LIFT', entityType: 'operational_block', entityId: id,
      before: current, after: { status: 'LEVANTADO', liftedAt: now }, reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return hydrateBlock(db, db.prepare('SELECT * FROM operational_block WHERE id=?').get(id), context.user);
  });
}

function scopeMatches(block, asset, operationType, siteId, locationId) {
  if (block.scope_type === 'TOTAL') return true;
  if (block.scope_type === 'SEDE') return block.site_id === siteId;
  if (block.scope_type === 'UBICACION') return block.location_id === locationId;
  if (block.scope_type === 'CATEGORIA') return block.category_id === asset.category_id;
  if (block.scope_type === 'OPERACION') return block.operation_type === operationType;
  return false;
}

function findActiveBlocks(db, personId, asset, operationType, siteId, locationId, now = new Date().toISOString()) {
  const candidates = db.prepare(`SELECT * FROM operational_block WHERE status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?)
    AND ((target_type='PERSONA' AND target_id=?) OR (target_type='ACTIVO' AND target_id=?) OR (target_type='CATEGORIA' AND target_id=?))`).all(now, now, personId, asset.id, asset.category_id);
  return candidates.filter((block) => scopeMatches(block, asset, operationType, siteId, locationId));
}

function validException(db, block, personId, assetId, operationType, requestId, now) {
  return db.prepare(`SELECT * FROM block_exception WHERE block_id=? AND person_id=? AND (asset_id IS NULL OR asset_id=?) AND operation_type=?
    AND ((status='APROBADA' AND (valid_from IS NULL OR valid_from<=?) AND (valid_until IS NULL OR valid_until>?))
      OR (status='CONSUMIDA' AND request_id=?)) ORDER BY CASE WHEN asset_id=? THEN 0 ELSE 1 END,created_at DESC LIMIT 1`)
    .get(block.id, personId, assetId, operationType, now, now, requestId || '__NONE__', assetId);
}

function evaluateOperationalBlocks(db, { personId, asset, operationType, siteId, locationId, requestId = null }) {
  const now = new Date().toISOString();
  const blocks = findActiveBlocks(db, personId, asset, operationType, siteId, locationId, now);
  const blocked = [];
  const exceptions = [];
  for (const block of blocks) {
    const exception = validException(db, block, personId, asset.id, operationType, requestId, now);
    if (exception) exceptions.push(exception);
    else blocked.push(block);
  }
  return { allowed: blocked.length === 0, blocked, exceptions };
}

function assertOperationAllowed(db, data) {
  const result = evaluateOperationalBlocks(db, data);
  if (!result.allowed) {
    const codes = result.blocked.map((block) => block.block_number).join(', ');
    throw error(409, 'OPERATION_BLOCKED', `La operación está bloqueada por ${codes}.`, result.blocked.map((block) => ({ field: 'block', message: `${block.block_number}: ${block.reason}` })));
  }
  return result;
}

function consumeExceptions(db, exceptionIds, requestId, now = new Date().toISOString()) {
  for (const id of new Set(exceptionIds || [])) {
    const exception = db.prepare("SELECT * FROM block_exception WHERE id=? AND status='APROBADA'").get(id);
    if (!exception) continue;
    if (exception.one_time) db.prepare("UPDATE block_exception SET status='CONSUMIDA',request_id=?,consumed_at=?,version=version+1,updated_at=? WHERE id=? AND status='APROBADA'").run(requestId, now, now, id);
    else db.prepare("UPDATE block_exception SET request_id=COALESCE(request_id,?),version=version+1,updated_at=? WHERE id=? AND status='APROBADA'").run(requestId, now, id);
  }
}

function openIncidentInDb(db, input, context, options = {}) {
  const clientIncidentId = input.clientIncidentId || options.clientIncidentId || null;
  if (clientIncidentId) {
    const existing = db.prepare('SELECT * FROM incident WHERE client_incident_id=?').get(clientIncidentId);
    if (existing) {
      if (input.assetId && existing.asset_id !== input.assetId) throw error(409, 'IDEMPOTENCY_KEY_REUSED', 'La clave de idempotencia pertenece a otro incidente.');
      return { incident: getIncidentFromDb(db, existing.id), idempotent: true };
    }
  }
  const assetId = requiredString(input.assetId, 'assetId', { min: 8, max: 80 });
  const asset = db.prepare(`SELECT a.*,ac.nature AS category_nature,sl.site_id FROM asset a JOIN asset_category ac ON ac.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
  if (!asset) throw error(422, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  const scopePermission = options.scopePermission || 'Incident.Create';
  requireScope(context.user, asset.site_id, asset.location_id, scopePermission, db);
  const custodyId = input.custodyId || options.custodyId || null;
  const custody = custodyId ? db.prepare('SELECT * FROM custody WHERE id=? AND asset_id=?').get(custodyId, assetId) : null;
  if (custodyId && !custody) throw error(422, 'INCIDENT_CUSTODY_INVALID', 'La custodia no corresponde al bien.');
  const inspectionId = input.inspectionId || options.inspectionId || null;
  if (inspectionId && !db.prepare('SELECT 1 FROM inspection WHERE id=? AND asset_id=?').get(inspectionId, assetId)) throw error(422, 'INCIDENT_INSPECTION_INVALID', 'La inspección no corresponde al bien.');
  const type = String(input.type || '').toUpperCase();
  const severity = String(input.severity || '').toUpperCase();
  if (!INCIDENT_TYPES.has(type)) throw error(422, 'INCIDENT_TYPE_INVALID', 'Tipo de incidente inválido.');
  if (!SEVERITIES.has(severity)) throw error(422, 'INCIDENT_SEVERITY_INVALID', 'Severidad inválida.');
  const now = options.now || new Date().toISOString();
  const occurredAt = iso(input.occurredAt, 'occurredAt');
  if (occurredAt && new Date(occurredAt).getTime() > Date.now() + 5 * 60_000) throw error(422, 'INCIDENT_OCCURRED_AT_INVALID', 'La fecha del incidente no puede ser futura.');
  const title = requiredString(input.title || `Incidente ${type} — ${asset.internal_code}`, 'title', { min: 5, max: 250 });
  const description = requiredString(input.description || input.notes, 'description', { min: 5, max: 4000 });
  const id = randomUUID();
  const number = nextNumber(db, 'incident', 'incident_number', 'INC', new Date(now));
  const snapshot = options.assetSnapshot || {
    status: asset.status, quantityAvailable: asset.quantity_available, quantityTotal: asset.quantity_total,
    custodianPersonId: asset.custodian_person_id, active: asset.active, version: asset.version
  };
  db.prepare(`INSERT INTO incident(id,incident_number,client_incident_id,asset_id,custody_id,inspection_id,type,severity,status,title,description,
    reported_by_user_id,opened_by_user_id,occurred_at,detected_at,opened_at,asset_snapshot_json,version,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?, 'ABIERTO',?,?,?,?,?,?,?,?,1,?,?)`).run(id, number, clientIncidentId, assetId, custodyId, inspectionId, type, severity, title, description,
      context.user.id, context.user.id, occurredAt, now, now, JSON.stringify(snapshot), now, now);
  const lost = ['PERDIDA', 'ROBO', 'FALTANTE'].includes(type);
  db.prepare(`UPDATE asset SET status=?,quantity_available=0,version=version+1,updated_at=? WHERE id=?`).run(lost ? 'PERDIDO' : 'BLOQUEADO', now, assetId);
  if (custody && OPEN_CUSTODY_STATUSES.has(custody.status) && custody.status !== 'INCIDENTE') {
    db.prepare("UPDATE custody SET status='INCIDENTE',version=version+1,updated_at=? WHERE id=?").run(now, custody.id);
    addCustodyEvent(db, custody.id, custody.status, 'INCIDENTE', context.user.id, `Incidente ${number}: ${description}`, context.correlationId, now);
  }
  addIncidentEvent(db, id, 'APERTURA', null, 'ABIERTO', context.user.id, description, context.correlationId, { type, severity, automatic: Boolean(options.automatic) }, now);
  createBlockInDb(db, { targetType: 'ACTIVO', targetId: assetId, scopeType: 'TOTAL', reason: `Bloqueo automático por ${number}: ${description}`,
    source: 'INCIDENTE', incidentId: id, severity }, context, { returnExisting: true, now, scopePermission });
  if (input.blockCustodian === true && custody?.person_id) {
    createBlockInDb(db, { targetType: 'PERSONA', targetId: custody.person_id, scopeType: input.personBlockScope || 'TOTAL', operationType: input.personBlockOperation,
      reason: `Bloqueo por investigación ${number}: ${description}`, source: 'INCIDENTE', incidentId: id, severity }, context, { returnExisting: true, now, scopePermission });
  }
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.OPEN', entityType: 'incident', entityId: id,
    after: { incidentNumber: number, assetId, custodyId, type, severity, status: 'ABIERTO' }, reason: description, correlationId: context.correlationId,
    ipAddress: context.ip, equipment: context.userAgent }, db);
  return { incident: getIncidentFromDb(db, id), idempotent: false };
}

function openIncident(input, context) {
  return transaction((db) => openIncidentInDb(db, input, context));
}

function checkIncidentVersion(current, input) {
  const version = Number(input.version);
  if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'El incidente fue modificado por otra operación.');
  return version;
}

function startInvestigation(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Investigate', db);
    const version = checkIncidentVersion(current, input);
    if (current.status !== 'ABIERTO') throw error(409, 'INCIDENT_START_NOT_ALLOWED', 'Solo un incidente abierto puede iniciar investigación.');
    const assignedToUserId = requiredString(input.assignedToUserId || context.user.id, 'assignedToUserId', { min: 8, max: 80 });
    if (!db.prepare('SELECT 1 FROM user_account WHERE id=? AND active=1 AND deleted_at IS NULL').get(assignedToUserId)) throw error(422, 'INVESTIGATOR_INVALID', 'Investigador inexistente o inactivo.');
    const plan = requiredString(input.plan, 'plan', { min: 10, max: 3000 });
    const now = new Date().toISOString();
    const changed = db.prepare(`UPDATE incident SET status='EN_INVESTIGACION',assigned_to_user_id=?,investigation_started_at=?,version=version+1,updated_at=?
      WHERE id=? AND version=? AND status='ABIERTO'`).run(assignedToUserId, now, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al iniciar investigación.');
    addIncidentEvent(db, id, 'ASIGNACION', 'ABIERTO', 'EN_INVESTIGACION', context.user.id, plan, context.correlationId, { assignedToUserId }, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.START_INVESTIGATION', entityType: 'incident', entityId: id,
      before: { status: 'ABIERTO' }, after: { status: 'EN_INVESTIGACION', assignedToUserId }, reason: plan, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return getIncidentFromDb(db, id);
  });
}

function addIncidentNote(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Investigate', db);
    const version = checkIncidentVersion(current, input);
    if (current.status === 'CERRADO') throw error(409, 'INCIDENT_CLOSED', 'El incidente cerrado no admite notas.');
    const note = requiredString(input.note, 'note', { min: 5, max: 3000 });
    const now = new Date().toISOString();
    const changed = db.prepare('UPDATE incident SET version=version+1,updated_at=? WHERE id=? AND version=?').run(now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al registrar nota.');
    addIncidentEvent(db, id, 'NOTA', current.status, current.status, context.user.id, note, context.correlationId, null, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.NOTE', entityType: 'incident', entityId: id,
      after: { note }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return getIncidentFromDb(db, id);
  });
}

function attachIncidentEvidenceInDb(db, id, input, context, suppliedEvidence = null) {
  const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
  if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
  requireScope(context.user, current.site_id, current.location_id, 'Incident.Evidence', db);
  const version = checkIncidentVersion(current, input);
  if (current.status === 'CERRADO') throw error(409, 'INCIDENT_CLOSED', 'El incidente cerrado no admite evidencias.');
  const evidenceType = String(input.evidenceType || 'OTRO').toUpperCase();
  if (!['FOTO', 'DOCUMENTO', 'DENUNCIA', 'INFORME', 'ACTA', 'OTRO'].includes(evidenceType)) throw error(422, 'INCIDENT_EVIDENCE_TYPE_INVALID', 'Tipo de evidencia inválido.');
  const description = optionalString(input.description, 'description', { max: 1000 });
  let evidence = suppliedEvidence;
  if (!evidence) {
    const evidenceId = requiredString(input.evidenceId, 'evidenceId', { min: 8, max: 80 });
    evidence = db.prepare('SELECT * FROM file_evidence WHERE id=?').get(evidenceId);
    if (!evidence) throw error(422, 'EVIDENCE_NOT_FOUND', 'Evidencia no encontrada.');
    if (evidence.lifecycle_state !== 'PENDING' || evidence.owner_type !== 'UNASSIGNED' || evidence.owner_id !== null) throw error(409, 'EVIDENCE_ALREADY_CLAIMED', 'La evidencia ya tiene propietario y no puede reutilizarse.');
    if (evidence.created_by_user_id !== context.user.id) throw error(403, 'EVIDENCE_CLAIM_FORBIDDEN', 'Solo el usuario que cargó la evidencia puede adjuntarla.');
    claimEvidence(evidenceId, { ownerType: 'INCIDENT', ownerId: id, purpose: evidenceType }, context, db);
  }
  const evidenceId = evidence.id;
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO incident_evidence(id,incident_id,evidence_id,evidence_type,description,added_by_user_id,created_at) VALUES (?,?,?,?,?,?,?)`)
    .run(randomUUID(), id, evidenceId, evidenceType, description, context.user.id, now);
  const changed = db.prepare('UPDATE incident SET version=version+1,updated_at=? WHERE id=? AND version=?').run(now, id, version);
  if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al adjuntar evidencia.');
  addIncidentEvent(db, id, 'EVIDENCIA', current.status, current.status, context.user.id, description || evidence.filename, context.correlationId,
    { evidenceId, evidenceType, sha256: evidence.sha256 }, now);
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.EVIDENCE', entityType: 'incident', entityId: id,
    after: { evidenceId, evidenceType, sha256: evidence.sha256 }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
  return getIncidentFromDb(db, id);
}

function attachIncidentEvidence(id, input, context) {
  if (input?.dataUrl) {
    const evidenceType = String(input.evidenceType || 'OTRO').toUpperCase();
    return saveOwnedEvidenceDataUrl(
      input,
      { ownerType: 'INCIDENT', ownerId: id, purpose: evidenceType },
      context,
      {},
      (db, evidence) => attachIncidentEvidenceInDb(db, id, input, context, evidence)
    );
  }
  return transaction((db) => attachIncidentEvidenceInDb(db, id, input, context));
}

function addInvestigationAction(id, input, context) {
  return transaction((db) => {
    const incident = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!incident) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, incident.site_id, incident.location_id, 'Incident.Investigate', db);
    if (!['ABIERTO', 'EN_INVESTIGACION'].includes(incident.status)) throw error(409, 'INCIDENT_ACTION_NOT_ALLOWED', 'El estado del incidente no admite acciones.');
    const actionType = String(input.actionType || '').toUpperCase();
    if (!ACTION_TYPES.has(actionType)) throw error(422, 'INVESTIGATION_ACTION_TYPE_INVALID', 'Tipo de acción inválido.');
    const assignedToUserId = input.assignedToUserId || null;
    if (assignedToUserId && !db.prepare('SELECT 1 FROM user_account WHERE id=? AND active=1 AND deleted_at IS NULL').get(assignedToUserId)) throw error(422, 'INVESTIGATOR_INVALID', 'Responsable inexistente o inactivo.');
    const dueAt = iso(input.dueAt, 'dueAt');
    const now = new Date().toISOString();
    if (dueAt && new Date(dueAt) <= new Date(now)) throw error(422, 'ACTION_DUE_AT_INVALID', 'El vencimiento de la acción debe ser futuro.');
    const actionId = randomUUID();
    const description = requiredString(input.description, 'description', { min: 5, max: 2000 });
    db.prepare(`INSERT INTO incident_investigation_action(id,incident_id,action_type,description,assigned_to_user_id,due_at,status,version,created_by_user_id,created_at,updated_at)
      VALUES (?,?,?,?,?,?,'PENDIENTE',1,?,?,?)`).run(actionId, id, actionType, description, assignedToUserId, dueAt, context.user.id, now, now);
    addIncidentEvent(db, id, 'NOTA', incident.status, incident.status, context.user.id, `Acción de investigación creada: ${description}`, context.correlationId,
      { actionId, actionType, assignedToUserId, dueAt }, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.ACTION_CREATE', entityType: 'incident_investigation_action', entityId: actionId,
      after: { incidentId: id, actionType, assignedToUserId, dueAt }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return db.prepare('SELECT * FROM incident_investigation_action WHERE id=?').get(actionId);
  });
}

function updateInvestigationAction(actionId, input, context) {
  return transaction((db) => {
    const current = db.prepare(`SELECT ia.*,i.status AS incident_status,a.location_id,sl.site_id FROM incident_investigation_action ia
      JOIN incident i ON i.id=ia.incident_id JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE ia.id=?`).get(actionId);
    if (!current) throw error(404, 'INVESTIGATION_ACTION_NOT_FOUND', 'Acción de investigación no encontrada.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Investigate', db);
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La acción fue modificada por otra operación.');
    if (current.incident_status === 'CERRADO') throw error(409, 'INCIDENT_CLOSED', 'El incidente cerrado no admite cambios.');
    const status = String(input.status || current.status).toUpperCase();
    if (!['PENDIENTE', 'EN_CURSO', 'COMPLETADA', 'CANCELADA'].includes(status)) throw error(422, 'INVESTIGATION_ACTION_STATUS_INVALID', 'Estado de acción inválido.');
    const result = optionalString(input.result, 'result', { max: 3000 });
    if (status === 'COMPLETADA' && !result) throw error(422, 'INVESTIGATION_ACTION_RESULT_REQUIRED', 'Una acción completada requiere resultado.');
    const now = new Date().toISOString();
    const changed = db.prepare(`UPDATE incident_investigation_action SET status=?,result=?,completed_at=?,version=version+1,updated_at=? WHERE id=? AND version=?`)
      .run(status, result, status === 'COMPLETADA' ? now : null, now, actionId, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al actualizar acción.');
    addIncidentEvent(db, current.incident_id, 'NOTA', current.incident_status, current.incident_status, context.user.id,
      `Acción ${actionId} cambió de ${current.status} a ${status}.${result ? ` Resultado: ${result}` : ''}`, context.correlationId, { actionId, status }, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.ACTION_UPDATE', entityType: 'incident_investigation_action', entityId: actionId,
      before: { status: current.status }, after: { status, result }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return db.prepare('SELECT * FROM incident_investigation_action WHERE id=?').get(actionId);
  });
}

function applyResolutionDisposition(db, incident, resolutionCode, recoveryCondition, now, context) {
  const asset = db.prepare(`SELECT a.*,ac.nature FROM asset a JOIN asset_category ac ON ac.id=a.category_id WHERE a.id=?`).get(incident.asset_id);
  const ownActiveBlocks = resolutionCode === 'RECUPERADO_CONFORME'
    ? db.prepare("SELECT * FROM operational_block WHERE incident_id=? AND target_type='ACTIVO' AND status='ACTIVO'").all(incident.id)
    : [];
  const otherActiveBlocks = resolutionCode === 'RECUPERADO_CONFORME'
    ? db.prepare(`SELECT * FROM operational_block
        WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO'
          AND (incident_id IS NULL OR incident_id<>?)
          AND starts_at<=? AND (expires_at IS NULL OR expires_at>?)`).all(incident.asset_id, incident.id, now, now)
    : [];
  let targetStatus;
  let available = 0;
  let active = asset.active;
  if (resolutionCode === 'RECUPERADO_CONFORME') {
    targetStatus = otherActiveBlocks.length ? 'BLOQUEADO' : 'DISPONIBLE';
    available = otherActiveBlocks.length ? 0 : (['SERIADO', 'KIT', 'VEHICULO'].includes(asset.nature) ? 1 : asset.quantity_total);
  } else if (resolutionCode === 'RECUPERADO_BLOQUEADO' || resolutionCode === 'SIN_RESPONSABILIDAD' || resolutionCode === 'OTRA') {
    targetStatus = 'BLOQUEADO';
    available = ['SERIADO', 'KIT', 'VEHICULO'].includes(asset.nature) ? 1 : asset.quantity_total;
  } else if (resolutionCode === 'REPARACION_REQUERIDA') targetStatus = 'MANTENIMIENTO';
  else if (resolutionCode === 'BAJA_DEFINITIVA') { targetStatus = 'BAJA'; active = 0; }
  else if (resolutionCode === 'SIN_RECUPERACION') targetStatus = 'PERDIDO';
  else targetStatus = ['PERDIDA', 'ROBO', 'FALTANTE'].includes(incident.type) ? 'PERDIDO' : 'BLOQUEADO';
  db.prepare('UPDATE asset SET status=?,quantity_available=?,custodian_person_id=NULL,active=?,version=version+1,updated_at=? WHERE id=?')
    .run(targetStatus, available, active, now, incident.asset_id);
  if (incident.custody_id) {
    const custody = db.prepare('SELECT * FROM custody WHERE id=?').get(incident.custody_id);
    if (custody && custody.status === 'INCIDENTE') {
      db.prepare("UPDATE custody SET status='CERRADA',closed_at=COALESCE(closed_at,?),version=version+1,updated_at=? WHERE id=? AND status='INCIDENTE'").run(now, now, custody.id);
      addCustodyEvent(db, custody.id, 'INCIDENTE', 'CERRADA', context.user.id, `Incidente resuelto: ${resolutionCode}.`, context.correlationId, now);
    }
  }
  if (resolutionCode === 'RECUPERADO_CONFORME') {
    for (const block of ownActiveBlocks) {
      db.prepare("UPDATE operational_block SET status='LEVANTADO',lifted_by_user_id=?,lifted_at=?,lift_reason=?,version=version+1,updated_at=? WHERE id=? AND status='ACTIVO'")
        .run(context.user.id, now, 'Levantamiento automático por recuperación conforme.', now, block.id);
    }
  }
  return {
    targetStatus,
    quantityAvailable: available,
    active: Boolean(active),
    recoveryCondition,
    liftedIncidentBlocks: ownActiveBlocks.length,
    preservedIndependentBlocks: otherActiveBlocks.length
  };
}

function resolveIncident(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Resolve', db);
    const version = checkIncidentVersion(current, input);
    if (!['ABIERTO', 'EN_INVESTIGACION'].includes(current.status)) throw error(409, 'INCIDENT_RESOLVE_NOT_ALLOWED', 'El incidente debe estar abierto o en investigación.');
    const resolutionCode = String(input.resolutionCode || '').toUpperCase();
    if (!RESOLUTION_CODES.has(resolutionCode)) throw error(422, 'INCIDENT_RESOLUTION_INVALID', 'Resolución inválida.');
    // F26 · Fase 10: causa raíz opcional; resolución obligatoria con cualquier texto no vacío.
    const rootCause = optionalString(input.rootCause, 'rootCause', { max: 3000 }) || null;
    const resolutionNotes = requiredString(input.resolutionNotes, 'resolutionNotes', { min: 1, max: 4000 });
    const recoveryRequired = ['RECUPERADO_CONFORME', 'RECUPERADO_BLOQUEADO'].includes(resolutionCode);
    const recoveredAt = recoveryRequired ? iso(input.recoveredAt || new Date().toISOString(), 'recoveredAt', { required: true }) : null;
    const recoveryCondition = recoveryRequired ? String(input.recoveryCondition || '').toUpperCase() : null;
    if (recoveryRequired && !RECOVERY_CONDITIONS.has(recoveryCondition)) throw error(422, 'RECOVERY_CONDITION_INVALID', 'Condición de recuperación inválida.');
    if (resolutionCode === 'RECUPERADO_CONFORME' && recoveryCondition !== 'CONFORME') throw error(422, 'RECOVERY_CONDITION_CONFLICT', 'La recuperación conforme requiere condición CONFORME.');
    if (resolutionCode === 'RECUPERADO_BLOQUEADO' && recoveryCondition === 'CONFORME') throw error(422, 'RECOVERY_CONDITION_CONFLICT', 'La recuperación bloqueada requiere una condición observada, dañada o incompleta.');
    const liabilityPersonId = input.liabilityPersonId || null;
    if (liabilityPersonId && !db.prepare('SELECT 1 FROM person WHERE id=? AND deleted_at IS NULL').get(liabilityPersonId)) throw error(422, 'LIABILITY_PERSON_INVALID', 'Persona responsable inexistente.');
    if (resolutionCode === 'RESPONSABILIDAD_DETERMINADA' && !liabilityPersonId) throw error(422, 'LIABILITY_PERSON_REQUIRED', 'La resolución requiere identificar a la persona responsable.');
    const estimatedCost = amount(input.estimatedCost, 'estimatedCost');
    const actualCost = amount(input.actualCost, 'actualCost');
    const now = new Date().toISOString();
    const disposition = applyResolutionDisposition(db, current, resolutionCode, recoveryCondition, now, context);
    const changed = db.prepare(`UPDATE incident SET status='RESUELTO',resolution_code=?,root_cause=?,resolution_notes=?,estimated_cost=?,actual_cost=?,
      recovered_at=?,recovery_condition=?,liability_person_id=?,resolved_at=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status IN ('ABIERTO','EN_INVESTIGACION')`)
      .run(resolutionCode, rootCause, resolutionNotes, estimatedCost, actualCost, recoveredAt, recoveryCondition, liabilityPersonId, now, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al resolver incidente.');
    addIncidentEvent(db, id, recoveryRequired ? 'RECUPERACION' : 'RESOLUCION', current.status, 'RESUELTO', context.user.id,
      resolutionNotes, context.correlationId, { resolutionCode, rootCause, estimatedCost, actualCost, liabilityPersonId, disposition }, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.RESOLVE', entityType: 'incident', entityId: id,
      before: { status: current.status, assetStatus: current.asset_status }, after: { status: 'RESUELTO', resolutionCode, disposition },
      reason: resolutionNotes, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return getIncidentFromDb(db, id);
  });
}

function closeIncident(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Close', db);
    const version = checkIncidentVersion(current, input);
    if (current.status !== 'RESUELTO') throw error(409, 'INCIDENT_CLOSE_NOT_ALLOWED', 'Solo un incidente resuelto puede cerrarse.');
    if (getSetting('incident.requireIndependentClosure', true) && ['ALTA', 'CRITICA'].includes(current.severity) && current.opened_by_user_id === context.user.id) {
      throw error(403, 'INDEPENDENT_CLOSURE_REQUIRED', 'Un incidente de severidad alta o crítica debe cerrarlo otra identidad autorizada.');
    }
    const reason = requiredString(input.reason, 'reason', { min: 10, max: 3000 });
    const now = new Date().toISOString();
    const changed = db.prepare("UPDATE incident SET status='CERRADO',closed_at=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status='RESUELTO'")
      .run(now, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al cerrar incidente.');
    addIncidentEvent(db, id, 'CIERRE', 'RESUELTO', 'CERRADO', context.user.id, reason, context.correlationId, null, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.CLOSE', entityType: 'incident', entityId: id,
      before: { status: 'RESUELTO' }, after: { status: 'CERRADO', closedAt: now }, reason, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return getIncidentFromDb(db, id);
  });
}

function reopenIncident(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${incidentSelect()} WHERE i.id=?`).get(id);
    if (!current) throw error(404, 'INCIDENT_NOT_FOUND', 'Incidente no encontrado.');
    requireScope(context.user, current.site_id, current.location_id, 'Incident.Resolve', db);
    const version = checkIncidentVersion(current, input);
    if (!['RESUELTO', 'CERRADO'].includes(current.status)) throw error(409, 'INCIDENT_REOPEN_NOT_ALLOWED', 'El incidente no admite reapertura.');
    const reason = requiredString(input.reason, 'reason', { min: 10, max: 3000 });
    const now = new Date().toISOString();
    const changed = db.prepare(`UPDATE incident SET status='EN_INVESTIGACION',closed_at=NULL,resolved_at=NULL,resolution_code=NULL,root_cause=NULL,resolution_notes=NULL,
      estimated_cost=NULL,actual_cost=NULL,recovered_at=NULL,recovery_condition=NULL,liability_person_id=NULL,
      version=version+1,updated_at=? WHERE id=? AND version=?`).run(now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al reabrir incidente.');
    db.prepare("UPDATE asset SET status='BLOQUEADO',quantity_available=0,version=version+1,updated_at=? WHERE id=? AND status='DISPONIBLE'").run(now, current.asset_id);
    createBlockInDb(db, { targetType: 'ACTIVO', targetId: current.asset_id, scopeType: 'TOTAL', reason: `Reapertura ${current.incident_number}: ${reason}`,
      source: 'INCIDENTE', incidentId: id, severity: current.severity }, context, { returnExisting: true, now, scopePermission: 'Incident.Resolve' });
    addIncidentEvent(db, id, 'REAPERTURA', current.status, 'EN_INVESTIGACION', context.user.id, reason, context.correlationId, null, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'INCIDENT.REOPEN', entityType: 'incident', entityId: id,
      before: { status: current.status }, after: { status: 'EN_INVESTIGACION' }, reason, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return getIncidentFromDb(db, id);
  });
}

function requireBlockExceptionScope(user, block, assetId, permission, db, mode = 'read') {
  const exception = { asset_id: assetId || null };
  assertExceptionAccess(user, block, exception, permission, mode, db);
}

function requestBlockException(blockId, input, context, allowAny = false) {
  return transaction((db) => {
    const block = db.prepare('SELECT * FROM operational_block WHERE id=?').get(blockId);
    if (!block) throw error(404, 'BLOCK_NOT_FOUND', 'Bloqueo no encontrado.');
    assertBlockAccess(context.user, block, 'Blocks.Exception.Request', 'read', db);
    if (effectiveBlockStatus(block) !== 'ACTIVO') throw error(409, 'BLOCK_NOT_ACTIVE', 'El bloqueo no está activo.');
    const personId = input.personId || context.user.personId;
    if (!allowAny && personId !== context.user.personId) throw error(403, 'EXCEPTION_PERSON_FORBIDDEN', 'Solo puede solicitar una excepción propia.');
    if (!db.prepare("SELECT 1 FROM person WHERE id=? AND status='ACTIVA' AND deleted_at IS NULL").get(personId)) throw error(422, 'EXCEPTION_PERSON_INVALID', 'Persona inexistente o inactiva.');
    const assetId = input.assetId || null;
    if (assetId && !db.prepare('SELECT 1 FROM asset WHERE id=? AND active=1 AND deleted_at IS NULL').get(assetId)) throw error(422, 'EXCEPTION_ASSET_INVALID', 'Bien inexistente o inactivo.');
    requireBlockExceptionScope(context.user, block, assetId, 'Blocks.Exception.Request', db, 'read');
    const operationType = String(input.operationType || '').toUpperCase();
    if (!['RETIRO', 'RESERVA', 'TRANSFERENCIA'].includes(operationType)) throw error(422, 'EXCEPTION_OPERATION_INVALID', 'Operación inválida.');
    const reason = requiredString(input.reason, 'reason', { min: 10, max: 2000 });
    const now = new Date().toISOString();
    const duplicate = db.prepare("SELECT 1 FROM block_exception WHERE block_id=? AND person_id=? AND ifnull(asset_id,'')=ifnull(?,'') AND operation_type=? AND status IN ('PENDIENTE','APROBADA')").get(blockId, personId, assetId, operationType);
    if (duplicate) throw error(409, 'EXCEPTION_ALREADY_OPEN', 'Ya existe una excepción pendiente o aprobada equivalente.');
    const id = randomUUID();
    db.prepare(`INSERT INTO block_exception(id,block_id,person_id,asset_id,operation_type,reason,status,requested_by_user_id,one_time,version,correlation_id,created_at,updated_at)
      VALUES (?,?,?,?,?,?,'PENDIENTE',?,1,1,?,?,?)`).run(id, blockId, personId, assetId, operationType, reason, context.user.id, context.correlationId, now, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'BLOCK.EXCEPTION_REQUEST', entityType: 'block_exception', entityId: id,
      after: { blockId, personId, assetId, operationType, status: 'PENDIENTE' }, reason, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return db.prepare('SELECT * FROM block_exception WHERE id=?').get(id);
  });
}

function decideBlockException(id, decision, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM block_exception WHERE id=?').get(id);
    if (!current) throw error(404, 'BLOCK_EXCEPTION_NOT_FOUND', 'Excepción no encontrada.');
    const block = db.prepare('SELECT * FROM operational_block WHERE id=?').get(current.block_id);
    if (!block) throw error(404, 'BLOCK_NOT_FOUND', 'Bloqueo no encontrado.');
    assertBlockAccess(context.user, block, 'Blocks.Exception.Decide', 'read', db);
    requireBlockExceptionScope(context.user, block, current.asset_id, 'Blocks.Exception.Decide', db, 'manage');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La excepción fue modificada por otra operación.');
    if (current.status !== 'PENDIENTE') throw error(409, 'BLOCK_EXCEPTION_NOT_PENDING', 'La excepción ya fue decidida.');
    if (getSetting('policy.segregationOfDuties', true) && current.requested_by_user_id === context.user.id) throw error(403, 'SELF_EXCEPTION_APPROVAL_FORBIDDEN', 'No puede decidir su propia excepción.');
    const normalized = String(decision).toUpperCase();
    if (!['APROBADA', 'RECHAZADA'].includes(normalized)) throw error(422, 'BLOCK_EXCEPTION_DECISION_INVALID', 'Decisión inválida.');
    const reason = requiredString(input.reason, 'reason', { min: 10, max: 2000 });
    const now = new Date().toISOString();
    let validFrom = null; let validUntil = null; let oneTime = 1;
    if (normalized === 'APROBADA') {
      validFrom = iso(input.validFrom || now, 'validFrom', { required: true });
      validUntil = iso(input.validUntil, 'validUntil', { required: true });
      if (new Date(validUntil) <= new Date(validFrom) || new Date(validUntil) <= new Date(now)) throw error(422, 'BLOCK_EXCEPTION_VALIDITY_INVALID', 'La vigencia de la excepción es inválida.');
      oneTime = parseBoolean(input.oneTime, true) ? 1 : 0;
    }
    const changed = db.prepare(`UPDATE block_exception SET status=?,decided_by_user_id=?,valid_from=?,valid_until=?,one_time=?,decision_reason=?,version=version+1,updated_at=?
      WHERE id=? AND version=? AND status='PENDIENTE'`).run(normalized, context.user.id, validFrom, validUntil, oneTime, reason, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al decidir excepción.');
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: `BLOCK.EXCEPTION_${normalized}`, entityType: 'block_exception', entityId: id,
      before: { status: 'PENDIENTE' }, after: { status: normalized, validFrom, validUntil, oneTime: Boolean(oneTime) }, reason,
      correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return db.prepare('SELECT * FROM block_exception WHERE id=?').get(id);
  });
}

function listBlockExceptionsPage(filters, user, allowAll = false) {
  const where = [];
  const params = [];
  if (!allowAll) { where.push('be.person_id=?'); params.push(user.personId); }
  if (filters.status) { where.push('be.status=?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.blockId) { where.push('be.block_id=?'); params.push(filters.blockId); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const db = getDb();
  const permission = allowAll ? 'Blocks.Exception.Decide' : 'Blocks.Exception.Request';
  const mode = allowAll ? 'manage' : 'read';
  const scope = blockReadScopeWhere(user, permission, db, 'ob');
  where.push(`(${scope.sql})`); params.push(...scope.params);
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const rows = db.prepare(`SELECT be.*,ob.block_number,ob.reason AS block_reason,ob.target_type,ob.target_id,ob.scope_type,ob.site_id,ob.location_id,
      ob.category_id,ob.operation_type,p.full_name AS person_name,a.internal_code AS asset_code
    FROM block_exception be JOIN operational_block ob ON ob.id=be.block_id JOIN person p ON p.id=be.person_id LEFT JOIN asset a ON a.id=be.asset_id
    ${whereSql} ORDER BY be.created_at DESC`).all(...params);
  const accessible = rows.filter((row) => userCanAccessException(user, row, row, permission, mode, db));
  return { items: accessible.slice(offset, offset + limit), total: accessible.length, limit, offset };
}

function listBlockExceptions(filters, user, allowAll = false) {
  return listBlockExceptionsPage(filters, user, allowAll).items;
}

function incidentReportCsv(filters, user) {
  const items = listIncidentsPage(filters, user, { all: true }).items;
  const columns = ['incident_number', 'type', 'severity', 'status', 'title', 'internal_code', 'asset_description', 'reporter_name', 'assigned_name', 'opened_at', 'resolved_at', 'closed_at', 'resolution_code', 'estimated_cost', 'actual_cost'];
  const escape = (value) => {
    if (value === null || value === undefined) return '';
    const text = String(value);
    return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  };
  return [columns.join(','), ...items.map((item) => columns.map((column) => escape(item[column])).join(','))].join('\r\n');
}

module.exports = {
  listIncidents, listIncidentsPage, getIncident, openIncident, openIncidentInDb, startInvestigation, addIncidentNote, attachIncidentEvidence,
  addInvestigationAction, updateInvestigationAction, resolveIncident, closeIncident, reopenIncident,
  listBlocks, listBlocksPage, getBlock, createBlock, createBlockInDb, liftBlock, requestBlockException, decideBlockException, listBlockExceptions, listBlockExceptionsPage,
  evaluateOperationalBlocks, assertOperationAllowed, consumeExceptions, incidentReportCsv, effectiveBlockStatus
};
