'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, parseBoolean, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { assertUserScope, assertLocationScope, assertAssetScope, userHasScope, scopeWhere } = require('../security/scope');
const { getKitOperationalStatus } = require('./kit-operational-control-service');
const { isAssetReservedByPersonalKit, closeActiveAssignmentForKitLifecycleInDb } = require('./kit-personal-service');

const ASSET_STATUSES = new Set(['DISPONIBLE', 'RESERVADO', 'EN_CUSTODIA', 'BLOQUEADO', 'MANTENIMIENTO', 'PERDIDO', 'BAJA']);
const MASTER_EDITABLE_STATUSES = new Set(['DISPONIBLE', 'BLOQUEADO', 'MANTENIMIENTO', 'PERDIDO', 'BAJA']);
const DOCUMENT_STATUSES = new Set(['VIGENTE', 'VENCIDO', 'ANULADO']);

function normalizeCode(value, field = 'internalCode') {
  return requiredString(value, field, { min: 2, max: 60, pattern: /^[A-Za-z0-9._/-]+$/ }).toUpperCase();
}

function normalizeNullableCode(value, field, max = 100) {
  const result = optionalString(value, field, { max });
  return result ? result.toUpperCase() : null;
}

function numeric(value, field, fallback = null) {
  if (value === null || value === undefined || value === '') return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) throw Object.assign(new Error(`Campo numérico inválido: ${field}.`), { status: 422, code: 'NUMBER_INVALID', fieldErrors: [{ field, message: 'Debe ser un número mayor o igual que cero.' }] });
  return number;
}

function getCategoryOrThrow(categoryId, db = getDb(), { activeRequired = true } = {}) {
  const category = db.prepare('SELECT * FROM asset_category WHERE id = ? AND deleted_at IS NULL').get(categoryId);
  if (!category || (activeRequired && !category.active)) throw Object.assign(new Error('Categoría inexistente o inactiva.'), { status: 422, code: 'CATEGORY_INVALID' });
  return category;
}

function getLocationOrThrow(locationId, db = getDb(), { activeRequired = true } = {}) {
  const location = db.prepare(`SELECT sl.*, s.code AS site_code, s.name AS site_name, s.active AS site_active
    FROM storage_location sl JOIN site s ON s.id = sl.site_id WHERE sl.id = ?`).get(locationId);
  if (!location || (activeRequired && (!location.active || !location.site_active))) throw Object.assign(new Error('Ubicación inexistente o inactiva.'), { status: 422, code: 'LOCATION_INVALID' });
  return location;
}

function categoryEnabledForSite(db, siteId, categoryId) {
  return Boolean(db.prepare(`SELECT 1 FROM site_asset_category
    WHERE site_id=? AND category_id=? AND active=1`).get(siteId, categoryId));
}

function normalizeAsset(input, current = null, db = getDb(), options = {}) {
  const categoryId = requiredString(input.categoryId ?? current?.category_id, 'categoryId', { min: 8, max: 80 });
  const locationId = requiredString(input.locationId ?? current?.location_id, 'locationId', { min: 8, max: 80 });
  const category = getCategoryOrThrow(categoryId, db, { activeRequired: !current || categoryId !== current.category_id });
  if (current && categoryId !== current.category_id) {
    const currentCategory = db.prepare('SELECT id, nature FROM asset_category WHERE id = ?').get(current.category_id);
    if (!currentCategory) throw Object.assign(new Error('La categoría actual del bien no existe.'), { status: 409, code: 'ASSET_CATEGORY_INTEGRITY_ERROR' });
    if (currentCategory.nature !== category.nature) {
      throw Object.assign(new Error('No puede cambiarse la naturaleza operativa de un bien. Reasignalo únicamente a una categoría de la misma naturaleza.'), { status: 409, code: 'ASSET_NATURE_CHANGE_FORBIDDEN' });
    }
  }
  const location = getLocationOrThrow(locationId, db, { activeRequired: true });
  const assignmentChanged = !current || categoryId !== current.category_id || locationId !== current.location_id;
  if (assignmentChanged && !categoryEnabledForSite(db, location.site_id, categoryId)) {
    throw Object.assign(new Error('La categoría seleccionada no está habilitada para la sede de la ubicación elegida.'), { status: 422, code: 'CATEGORY_NOT_ENABLED_FOR_SITE' });
  }
  const status = String(input.status ?? current?.status ?? 'DISPONIBLE').toUpperCase();
  if (!ASSET_STATUSES.has(status) || (!options.systemOperation && !MASTER_EDITABLE_STATUSES.has(status))) {
    throw Object.assign(new Error('Estado de bien inválido para administración de maestro.'), { status: 422, code: 'ASSET_STATUS_INVALID' });
  }
  const internalCode = normalizeCode(input.internalCode ?? current?.internal_code);
  const serialNumber = normalizeNullableCode(input.serialNumber ?? current?.serial_number, 'serialNumber', 120);
  const licensePlate = normalizeNullableCode(input.licensePlate ?? current?.license_plate, 'licensePlate', 30);
  const unit = optionalString(input.unitOfMeasure ?? current?.unit_of_measure ?? category.default_unit, 'unitOfMeasure', { max: 30 });
  let quantityTotal = numeric(input.quantityTotal ?? current?.quantity_total, 'quantityTotal', 1);
  let quantityAvailable = numeric(input.quantityAvailable ?? current?.quantity_available, 'quantityAvailable', quantityTotal);

  if (['SERIADO', 'KIT', 'VEHICULO'].includes(category.nature)) {
    quantityTotal = 1;
    quantityAvailable = status === 'DISPONIBLE' && (input.active ?? current?.active ?? true) ? 1 : 0;
  } else {
    if (!(quantityTotal > 0)) throw Object.assign(new Error('Los bienes por cantidad y consumibles requieren cantidad mayor que cero.'), { status: 422, code: 'QUANTITY_REQUIRED' });
    if (!unit) throw Object.assign(new Error('La unidad de medida es obligatoria.'), { status: 422, code: 'UNIT_REQUIRED' });
    if (quantityAvailable > quantityTotal) throw Object.assign(new Error('La cantidad disponible no puede superar la cantidad total.'), { status: 422, code: 'QUANTITY_INVALID' });
    if (status !== 'DISPONIBLE') quantityAvailable = Math.min(quantityAvailable, quantityTotal);
  }
  if (category.serialized && !serialNumber && !['VEHICULO', 'KIT'].includes(category.nature)) {
    throw Object.assign(new Error('El número de serie es obligatorio para esta categoría.'), { status: 422, code: 'SERIAL_REQUIRED' });
  }
  if (category.nature === 'VEHICULO' && !licensePlate) {
    throw Object.assign(new Error('La patente es obligatoria para vehículos.'), { status: 422, code: 'LICENSE_PLATE_REQUIRED' });
  }
  const active = parseBoolean(input.active, current ? Boolean(current.active) : status !== 'BAJA');
  const requiresWorkOrder = category.nature === 'VEHICULO'
    ? false
    : parseBoolean(input.requiresWorkOrder, current ? Boolean(current.requires_work_order) : false);
  return {
    categoryId,
    internalCode,
    serialNumber,
    description: requiredString(input.description ?? current?.description, 'description', { min: 2, max: 300 }),
    brand: optionalString(input.brand ?? current?.brand, 'brand', { max: 100 }),
    model: optionalString(input.model ?? current?.model, 'model', { max: 100 }),
    status: active ? status : 'BAJA',
    locationId,
    quantityTotal,
    quantityAvailable: active ? quantityAvailable : 0,
    unitOfMeasure: unit,
    licensePlate,
    odometer: numeric(input.odometer ?? current?.odometer, 'odometer', null),
    fuelType: optionalString(input.fuelType ?? current?.fuel_type, 'fuelType', { max: 80 }),
    notes: optionalString(input.notes ?? current?.notes, 'notes', { max: 3000 }),
    requiresWorkOrder,
    active,
    category
  };
}

function assetSelect() {
  return `SELECT a.*, c.code AS category_code, c.name AS category_name, c.nature AS category_nature,
    c.serialized AS category_serialized, c.requires_inspection, c.requires_return,
    sl.code AS location_code, sl.name AS location_name, sl.active AS location_active,
    s.id AS site_id, s.code AS site_code, s.name AS site_name, s.active AS site_active,
    EXISTS (SELECT 1 FROM site_asset_category sac WHERE sac.site_id=s.id AND sac.category_id=a.category_id AND sac.active=1) AS category_enabled_in_site
    FROM asset a JOIN asset_category c ON c.id = a.category_id
    JOIN storage_location sl ON sl.id = a.location_id JOIN site s ON s.id = sl.site_id`;
}

const OPEN_CUSTODY_STATUSES = ['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE'];
const ACTIVE_INCIDENT_STATUSES = ['ABIERTO', 'EN_INVESTIGACION'];

function availabilityBlocker(code, detail = null) { return { code, detail }; }

function diagnoseAssetRequestAvailabilityRow(db, asset) {
  const now = new Date().toISOString();
  const blockers = [];
  if (!asset.active || asset.deleted_at) blockers.push(availabilityBlocker('INACTIVE', 'El bien está inactivo o dado de baja.'));
  if (!asset.site_active) blockers.push(availabilityBlocker('SITE_DISABLED', 'La sede está inactiva.'));
  if (!asset.location_active) blockers.push(availabilityBlocker('LOCATION_DISABLED', 'La ubicación está inactiva.'));
  if (!asset.category_enabled_in_site) blockers.push(availabilityBlocker('CATEGORY_DISABLED', 'La categoría no está habilitada en la sede.'));
  if (asset.status !== 'DISPONIBLE') {
    const statusCode = ({ RESERVADO: 'RESERVED', EN_CUSTODIA: 'CUSTODY_ACTIVE', BLOQUEADO: 'OPERATIONAL_BLOCK', MANTENIMIENTO: 'MAINTENANCE', BAJA: 'INACTIVE' })[asset.status] || 'OTHER_REAL_REASON';
    blockers.push(availabilityBlocker(statusCode, `Estado maestro: ${asset.status}.`));
  }
  if (Number(asset.quantity_available) <= 0) {
    blockers.push(availabilityBlocker('QUANTITY_ZERO', 'No hay cantidad disponible para pedir.'));
    if (asset.status === 'DISPONIBLE' && asset.active && asset.source_import_batch_id) blockers.push(availabilityBlocker('PREVENTIVE_REVIEW_REQUIRED', 'Bien importado con disponibilidad cero: requiere confirmación física antes de habilitar pedidos.'));
  }
  // Un bien unitario se comporta como asignación exclusiva aunque su categoría sea CANTIDAD.
  // Esto evita ofrecer como disponible una herramienta única que todavía conserva una reserva o
  // custodia activa en bases históricas cuyo quantity_available quedó desalineado.
  const singletonAllocation = Number(asset.quantity_total) <= 1;
  const exclusiveAllocation = ['SERIADO', 'KIT', 'VEHICULO'].includes(asset.category_nature) || singletonAllocation;
  const quantityExhausted = Number(asset.quantity_available) <= 0;
  const reservation = db.prepare("SELECT id FROM asset_reservation WHERE asset_id=? AND status='ACTIVA' AND expires_at>? LIMIT 1").get(asset.id, now);
  if (reservation && (exclusiveAllocation || quantityExhausted)) blockers.push(availabilityBlocker('RESERVED', 'Tiene una reserva activa.'));
  const custody = db.prepare(`SELECT id FROM custody WHERE asset_id=? AND status IN (${OPEN_CUSTODY_STATUSES.map(() => '?').join(',')}) LIMIT 1`).get(asset.id, ...OPEN_CUSTODY_STATUSES);
  if (custody && (exclusiveAllocation || quantityExhausted)) blockers.push(availabilityBlocker('CUSTODY_ACTIVE', 'Tiene una custodia abierta.'));
  const block = db.prepare("SELECT block_number FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?) LIMIT 1").get(asset.id, now, now);
  if (block) blockers.push(availabilityBlocker('OPERATIONAL_BLOCK', `Bloqueo operativo ${block.block_number}.`));
  const maintenance = db.prepare("SELECT order_number FROM maintenance_order WHERE asset_id=? AND status='EN_PROGRESO' LIMIT 1").get(asset.id);
  if (maintenance) blockers.push(availabilityBlocker('MAINTENANCE', `Mantenimiento ${maintenance.order_number} en progreso.`));
  const incident = db.prepare(`SELECT incident_number FROM incident WHERE asset_id=? AND status IN (${ACTIVE_INCIDENT_STATUSES.map(() => '?').join(',')}) LIMIT 1`).get(asset.id, ...ACTIVE_INCIDENT_STATUSES);
  if (incident) blockers.push(availabilityBlocker('INCIDENT', `Incidente ${incident.incident_number} abierto.`));
  if (asset.category_nature === 'KIT' && !getKitOperationalStatus(db, asset.id).complete) blockers.push(availabilityBlocker('KIT_INCOMPLETE', 'El kit no está operativo porque su composición física está incompleta.'));
  if (asset.category_nature !== 'KIT' && isAssetReservedByPersonalKit(db, asset.id)) blockers.push(availabilityBlocker('PERSONAL_KIT', 'Está asignado como componente de un kit personal activo.'));
  const unique = blockers.filter((blocker, index, all) => all.findIndex((item) => item.code === blocker.code) === index);
  return {
    assetId: asset.id,
    code: asset.internal_code,
    physicalStatus: asset.status,
    quantityTotal: Number(asset.quantity_total),
    quantityAvailable: Number(asset.quantity_available),
    requestVisible: unique.length === 0,
    blockers: unique
  };
}

function getAssetAvailabilityDiagnosis(id, user = null, permission = 'Assets.Read') {
  const db = getDb();
  const asset = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(id);
  if (!asset) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  if (user && !userHasScope(user, asset.site_id, asset.location_id, permission)) throw Object.assign(new Error('La operación está fuera del alcance asignado.'), { status: 403, code: 'SCOPE_FORBIDDEN' });
  return diagnoseAssetRequestAvailabilityRow(db, asset);
}

function enableAvailabilityAfterPreventiveReview(input, context) {
  const assetIds = Array.isArray(input.assetIds) ? [...new Set(input.assetIds.map(String).filter(Boolean))] : [];
  if (!assetIds.length) throw Object.assign(new Error('Seleccione al menos un bien para revisar.'), { status: 422, code: 'ASSET_REVIEW_SELECTION_REQUIRED' });
  const reason = requiredString(input.reason, 'reason', { min: 10, max: 2000 });
  return transaction((db) => {
    const now = new Date().toISOString();
    const results = [];
    for (const id of assetIds) {
      assertAssetScope(context.user, id, 'Assets.Update', db);
      const asset = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(id);
      if (!asset) throw Object.assign(new Error(`Bien inexistente: ${id}.`), { status: 404, code: 'ASSET_NOT_FOUND' });
      const diagnosis = diagnoseAssetRequestAvailabilityRow(db, asset);
      const reviewableCodes = new Set(['QUANTITY_ZERO', 'PREVENTIVE_REVIEW_REQUIRED']);
      if (diagnosis.blockers.some((item) => !reviewableCodes.has(item.code))) {
        throw Object.assign(new Error(`No puede habilitarse ${asset.internal_code}: ${diagnosis.blockers.map((item) => item.code).join(', ')}.`), { status: 409, code: 'ASSET_AVAILABILITY_REAL_BLOCKER' });
      }
      if (!diagnosis.blockers.some((item) => item.code === 'QUANTITY_ZERO')) {
        throw Object.assign(new Error(`${asset.internal_code} ya tiene disponibilidad para pedidos.`), { status: 409, code: 'ASSET_AVAILABILITY_ALREADY_ENABLED' });
      }
      const releasedQuantity = ['SERIADO', 'KIT', 'VEHICULO'].includes(asset.category_nature) ? 1 : Number(asset.quantity_total);
      const changed = db.prepare("UPDATE asset SET quantity_available=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status='DISPONIBLE' AND active=1").run(releasedQuantity, now, id, asset.version);
      if (changed.changes !== 1) throw Object.assign(new Error(`Conflicto al habilitar ${asset.internal_code}.`), { status: 409, code: 'CONCURRENCY_CONFLICT' });
      const eventId = randomUUID();
      db.prepare('INSERT INTO asset_availability_review_event(id,asset_id,prior_status,prior_quantity_available,released_quantity_available,reason,source,actor_user_id,correlation_id,reviewed_at,created_at) VALUES (?,?,?,?,?,?,\'PREVENTIVE_IMPORT_REVIEW\',?,?,?,?)')
        .run(eventId, id, asset.status, Number(asset.quantity_available), releasedQuantity, reason, context.user.id, context.correlationId || null, now, now);
      const after = db.prepare(`${assetSelect()} WHERE a.id=?`).get(id);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.AVAILABILITY_PREVENTIVE_IMPORT_REVIEW', entityType: 'asset', entityId: id, before: { status: asset.status, quantityAvailable: asset.quantity_available, blockers: diagnosis.blockers }, after: { status: after.status, quantityAvailable: after.quantity_available, availabilityReviewEventId: eventId }, reason, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
      results.push({ asset: after, eventId });
    }
    return { items: results };
  });
}

function listAssets(filters = {}, user = null, permission = 'Assets.Read') {
  const where = ['a.deleted_at IS NULL'];
  const params = [];
  if (filters.active !== undefined) { where.push('a.active = ?'); params.push(filters.active ? 1 : 0); }
  if (filters.status) { where.push('a.status = ?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.categoryId) { where.push('a.category_id = ?'); params.push(filters.categoryId); }
  if (filters.nature) { where.push('c.nature = ?'); params.push(String(filters.nature).toUpperCase()); }
  if (filters.excludeNature) {
    const excluded = String(filters.excludeNature).split(',').map((item) => item.trim().toUpperCase()).filter(Boolean);
    if (excluded.length) { where.push(`c.nature NOT IN (${excluded.map(() => '?').join(',')})`); params.push(...excluded); }
  }
  if (filters.locationId) { where.push('a.location_id = ?'); params.push(filters.locationId); }
  if (filters.availableOnly) { where.push("a.active = 1 AND a.status = 'DISPONIBLE' AND a.quantity_available > 0"); }
  if (filters.search) {
    const terms = String(filters.search).trim().split(/\s+/).filter(Boolean).slice(0, 8);
    const searchableFields = [
      'a.internal_code', 'a.serial_number', 'a.description', 'a.brand', 'a.model', 'a.license_plate', 'a.notes',
      'c.code', 'c.name', 'sl.code', 'sl.name', 's.code', 's.name'
    ];
    for (const term of terms) {
      const search = `%${term}%`;
      where.push(`(${searchableFields.map((field) => `${field} LIKE ?`).join(' OR ')})`);
      params.push(...searchableFields.map(() => search));
    }
  }
  if (user) {
    const scoped = scopeWhere(user, permission, 's.id', 'sl.id');
    where.push(scoped.sql); params.push(...scoped.params);
  }
  const limit = safeInteger(filters.limit, 250, 1, 1000);
  const offset = safeInteger(filters.offset, 0, 0, 1_000_000);
  const db = getDb();
  const items = db.prepare(`${assetSelect()} WHERE ${where.join(' AND ')} ORDER BY a.internal_code COLLATE NOCASE LIMIT ? OFFSET ?`).all(...params, limit, offset);
  return filters.includeAvailabilityDiagnosis ? items.map((asset) => ({ ...asset, requestAvailability: diagnoseAssetRequestAvailabilityRow(db, asset) })) : items;
}

function getAsset(id, user = null, permission = 'Assets.Read') {
  const asset = getDb().prepare(`${assetSelect()} WHERE a.id = ? AND a.deleted_at IS NULL`).get(id);
  if (!asset) return null;
  if (user && !userHasScope(user, asset.site_id, asset.location_id, permission)) throw Object.assign(new Error('La operación está fuera del alcance asignado.'), { status: 403, code: 'SCOPE_FORBIDDEN' });
  asset.documents = listAssetDocuments(id);
  asset.manualReleaseHistory = getDb().prepare(`SELECT amr.*, ua.username AS actor_username, p.full_name AS actor_name
    FROM asset_manual_release_event amr JOIN user_account ua ON ua.id=amr.actor_user_id JOIN person p ON p.id=ua.person_id
    WHERE amr.asset_id=? ORDER BY amr.released_at DESC LIMIT 100`).all(id);
  asset.activeBlocks = getDb().prepare(`SELECT id,block_number,reason,source,severity,incident_id,starts_at,expires_at,created_by_user_id
    FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?)
    ORDER BY starts_at DESC`).all(id,new Date().toISOString(),new Date().toISOString());
  asset.activeIncidents = getDb().prepare(`SELECT id,incident_number,type,severity,status,title,opened_at FROM incident
    WHERE asset_id=? AND status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO') ORDER BY opened_at DESC`).all(id);
  return asset;
}

function insertAsset(db, data, metadata = {}) {
  const id = metadata.id || randomUUID();
  const now = metadata.now || new Date().toISOString();
  db.prepare(`INSERT INTO asset(id, category_id, internal_code, serial_number, description, brand, model, status, location_id, quantity_total, quantity_available, unit_of_measure, license_plate, odometer, fuel_type, notes, requires_work_order, source_import_batch_id, active, version, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`)
    .run(id, data.categoryId, data.internalCode, data.serialNumber, data.description, data.brand, data.model, data.status, data.locationId, data.quantityTotal, data.quantityAvailable, data.unitOfMeasure, data.licensePlate, data.odometer, data.fuelType, data.notes, data.requiresWorkOrder ? 1 : 0, metadata.sourceImportBatchId || null, data.active ? 1 : 0, now, now);
  return id;
}

function convertUniqueError(error) {
  const message = String(error.message);
  if (message.includes('ASSET_NATURE_CHANGE_FORBIDDEN')) {
    return Object.assign(new Error('No puede cambiarse la naturaleza operativa de un bien. Reasignalo únicamente a una categoría de la misma naturaleza.'), { status: 409, code: 'ASSET_NATURE_CHANGE_FORBIDDEN' });
  }
  if (message.includes('CATEGORY_NATURE_CHANGE_WITH_ASSETS_FORBIDDEN')) {
    return Object.assign(new Error('No puede cambiarse la naturaleza de una categoría que posee bienes asociados.'), { status: 409, code: 'CATEGORY_NATURE_LOCKED' });
  }
  if (!message.includes('UNIQUE')) return error;
  if (message.includes('internal_code')) return Object.assign(new Error('El código interno ya existe.'), { status: 409, code: 'ASSET_CODE_DUPLICATE' });
  if (message.includes('serial_number')) return Object.assign(new Error('El número de serie ya existe.'), { status: 409, code: 'ASSET_SERIAL_DUPLICATE' });
  if (message.includes('license_plate')) return Object.assign(new Error('La patente ya existe.'), { status: 409, code: 'ASSET_LICENSE_DUPLICATE' });
  return Object.assign(new Error('Existe un bien con datos únicos coincidentes.'), { status: 409, code: 'ASSET_DUPLICATE' });
}

function createAsset(input, context, metadata = {}) {
  return transaction((db) => {
    const data = normalizeAsset(input, null, db, metadata);
    if (['VEHICULO', 'KIT'].includes(data.category.nature) && metadata.allowSpecializedNature !== true) {
      throw Object.assign(new Error('Los vehículos y kits deben darse de alta mediante su flujo especializado completo.'), { status: 409, code: 'SPECIALIZED_ASSET_REGISTRATION_REQUIRED' });
    }
    assertLocationScope(context.user, data.locationId, 'Assets.Create', db);
    let id;
    try { id = insertAsset(db, data, metadata); } catch (error) { throw convertUniqueError(error); }
    const created = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(id);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: metadata.auditAction || 'ASSET.CREATE', entityType: 'asset', entityId: id, after: created, correlationId: context.correlationId, source: metadata.source || 'API', reason: metadata.reason, ipAddress: context.ip, equipment: context.userAgent }, db);
    return created;
  });
}

function updateAsset(id, input, context, metadata = {}) {
  const current = getDb().prepare('SELECT * FROM asset WHERE id = ? AND deleted_at IS NULL').get(id);
  if (!current) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  assertAssetScope(context.user, id, 'Assets.Update');
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error('La versión es obligatoria.'), { status: 422, code: 'VERSION_REQUIRED' });
  if (expectedVersion !== current.version) throw Object.assign(new Error('El bien fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
  if (Boolean(current.active) && input.locationId !== undefined && String(input.locationId) !== String(current.location_id) && metadata.allowDirectLocationChange !== true) {
    throw Object.assign(new Error('La ubicación de un bien activo sólo puede cambiarse mediante Mover a otra ubicación.'), { status: 409, code: 'ASSET_LOCATION_TRANSFER_REQUIRED' });
  }
  return transaction((db) => {
    const data = normalizeAsset(input, current, db, metadata);
    assertLocationScope(context.user, data.locationId, 'Assets.Update', db);
    if (data.status === 'DISPONIBLE' && current.status === 'BLOQUEADO' && metadata.allowBlockedRelease !== true) {
      throw Object.assign(new Error('Un bien bloqueado sólo puede volver a Disponible mediante Habilitar bien por un Super Administrador.'), { status: 403, code: 'ASSET_BLOCKED_RELEASE_REQUIRED' });
    }
    if (data.status === 'DISPONIBLE' && metadata.allowBlockedRelease !== true) {
      const activeBlock = db.prepare(`SELECT block_number FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?) LIMIT 1`).get(id,new Date().toISOString(),new Date().toISOString());
      if (activeBlock) throw Object.assign(new Error(`El bien posee un bloqueo operativo activo (${activeBlock.block_number}). Debe utilizar Habilitar bien.`), { status: 409, code: 'ASSET_ACTIVE_BLOCK_RELEASE_REQUIRED' });
    }
    try {
      const result = db.prepare(`UPDATE asset SET category_id = ?, internal_code = ?, serial_number = ?, description = ?, brand = ?, model = ?, status = ?, location_id = ?, quantity_total = ?, quantity_available = ?, unit_of_measure = ?, license_plate = ?, odometer = ?, fuel_type = ?, notes = ?, requires_work_order = ?, active = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ? AND deleted_at IS NULL`)
        .run(data.categoryId, data.internalCode, data.serialNumber, data.description, data.brand, data.model, data.status, data.locationId, data.quantityTotal, data.quantityAvailable, data.unitOfMeasure, data.licensePlate, data.odometer, data.fuelType, data.notes, data.requiresWorkOrder ? 1 : 0, data.active ? 1 : 0, new Date().toISOString(), id, expectedVersion);
      if (result.changes !== 1) throw Object.assign(new Error('El bien fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    } catch (error) { throw convertUniqueError(error); }
    let updated = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(id);
    if (typeof metadata.afterUpdateInDb === 'function') {
      metadata.afterUpdateInDb(db, { before: current, after: updated });
      updated = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(id);
    }
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: metadata.auditAction || 'ASSET.UPDATE', entityType: 'asset', entityId: id, before: current, after: updated, correlationId: context.correlationId, source: metadata.source || 'API', reason: metadata.reason, ipAddress: context.ip, equipment: context.userAgent }, db);
    return updated;
  });
}

function duplicateAsset(id, input, context) {
  const source = getAsset(id, context.user, 'Assets.Create');
  if (!source) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  if (['VEHICULO', 'KIT'].includes(source.category_nature)) {
    throw Object.assign(new Error('Los vehículos y kits requieren duplicación completa mediante su flujo especializado.'), { status: 409, code: 'SPECIALIZED_DUPLICATE_REQUIRED' });
  }
  const copy = {
    categoryId: source.category_id,
    internalCode: input.internalCode,
    serialNumber: input.serialNumber || null,
    description: input.description || `${source.description} (copia)`,
    brand: source.brand,
    model: source.model,
    status: 'DISPONIBLE',
    locationId: input.locationId || source.location_id,
    quantityTotal: source.quantity_total,
    quantityAvailable: source.quantity_total,
    unitOfMeasure: source.unit_of_measure,
    licensePlate: input.licensePlate || null,
    odometer: source.category_nature === 'VEHICULO' ? 0 : source.odometer,
    fuelType: source.fuel_type,
    notes: source.notes,
    requiresWorkOrder: Boolean(source.requires_work_order),
    active: true
  };
  return createAsset(copy, context, { auditAction: 'ASSET.DUPLICATE', reason: `Duplicado desde ${id}` });
}

function setAssetActive(id, active, input, context) {
  const current = getAsset(id, context.user, 'Assets.Update');
  if (!current) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  if (['EN_CUSTODIA', 'RESERVADO'].includes(current.status)) throw Object.assign(new Error('No puede inactivarse o reactivarse un bien con operación abierta.'), { status: 409, code: 'ASSET_OPERATION_OPEN' });
  const lifecycleMetadata = { auditAction: active ? 'ASSET.REACTIVATE' : 'ASSET.INACTIVATE' };
  if (current.category_nature === 'KIT') {
    lifecycleMetadata.afterUpdateInDb = (db) => closeActiveAssignmentForKitLifecycleInDb(
      db,
      id,
      context,
      active ? 'Cierre de asignación previa al reactivar kit' : 'Cierre automático al dar de baja el kit'
    );
  }
  return updateAsset(id, {
    ...current,
    version: Number(input.version),
    categoryId: current.category_id,
    internalCode: current.internal_code,
    serialNumber: current.serial_number,
    locationId: current.location_id,
    unitOfMeasure: current.unit_of_measure,
    licensePlate: current.license_plate,
    fuelType: current.fuel_type,
    active,
    status: active ? 'DISPONIBLE' : 'BAJA',
    quantityAvailable: active ? current.quantity_total : 0
  }, context, lifecycleMetadata);
}

function setAssetPhoto(id, input, context) {
  const current = getAsset(id, context.user, 'Assets.Documents');
  if (!current) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error('La versión es obligatoria.'), { status: 422, code: 'VERSION_REQUIRED' });
  if (expectedVersion !== current.version) throw Object.assign(new Error('El bien fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
  return saveOwnedEvidenceDataUrl(
    input,
    { ownerType: 'ASSET', ownerId: id, purpose: 'PHOTO' },
    context,
    { allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'], maxBytes: require('../config/runtime').maxImageBytes },
    (db, evidence) => {
      const result = db.prepare('UPDATE asset SET photo_evidence_id = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ? AND deleted_at IS NULL')
        .run(evidence.id, new Date().toISOString(), id, expectedVersion);
      if (result.changes !== 1) throw Object.assign(new Error('El bien fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
      const updated = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(id);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.PHOTO_UPDATE', entityType: 'asset', entityId: id, before: { photoEvidenceId: current.photo_evidence_id }, after: { photoEvidenceId: evidence.id }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
      return { asset: updated, evidence };
    }
  );
}

function listAssetDocuments(assetId, user = null, permission = 'Assets.Read') {
  if (user) assertAssetScope(user, assetId, permission);
  return getDb().prepare(`SELECT ad.*, fe.filename, fe.mime_type, fe.size, fe.sha256
    FROM asset_document ad JOIN file_evidence fe ON fe.id = ad.evidence_id
    WHERE ad.asset_id = ? AND ad.deleted_at IS NULL ORDER BY COALESCE(ad.expires_at, '9999-12-31'), ad.title`).all(assetId);
}

function addAssetDocument(assetId, input, context) {
  if (!getAsset(assetId, context.user, 'Assets.Documents')) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
  const type = requiredString(input.type, 'type', { min: 2, max: 60 }).toUpperCase();
  const title = requiredString(input.title, 'title', { min: 2, max: 160 });
  const status = String(input.status || 'VIGENTE').toUpperCase();
  if (!DOCUMENT_STATUSES.has(status)) throw Object.assign(new Error('Estado documental inválido.'), { status: 422, code: 'DOCUMENT_STATUS_INVALID' });
  return saveOwnedEvidenceDataUrl(
    input,
    { ownerType: 'ASSET', ownerId: assetId, purpose: `DOCUMENT:${type}` },
    context,
    { allowedMimeTypes: ['application/pdf', 'image/png', 'image/jpeg', 'image/webp', 'text/plain', 'text/csv'] },
    (db, evidence) => {
      const id = randomUUID();
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO asset_document(id, asset_id, type, title, evidence_id, issued_at, expires_at, status, notes, version, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`)
        .run(id, assetId, type, title, evidence.id, optionalString(input.issuedAt, 'issuedAt', { max: 40 }), optionalString(input.expiresAt, 'expiresAt', { max: 40 }), status, optionalString(input.notes, 'notes', { max: 2000 }), now, now);
      const created = listAssetDocuments(assetId).find((item) => item.id === id);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET_DOCUMENT.CREATE', entityType: 'asset_document', entityId: id, after: created, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
      return created;
    }
  );
}

function updateAssetDocument(assetId, documentId, input, context) {
  assertAssetScope(context.user, assetId, 'Assets.Documents');
  const current = getDb().prepare('SELECT * FROM asset_document WHERE id = ? AND asset_id = ? AND deleted_at IS NULL').get(documentId, assetId);
  if (!current) throw Object.assign(new Error('Documento no encontrado.'), { status: 404, code: 'ASSET_DOCUMENT_NOT_FOUND' });
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error('La versión es obligatoria.'), { status: 422, code: 'VERSION_REQUIRED' });
  if (expectedVersion !== current.version) throw Object.assign(new Error('El documento fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
  const status = String(input.status ?? current.status).toUpperCase();
  if (!DOCUMENT_STATUSES.has(status)) throw Object.assign(new Error('Estado documental inválido.'), { status: 422, code: 'DOCUMENT_STATUS_INVALID' });
  return transaction((db) => {
    const result = db.prepare(`UPDATE asset_document SET type = ?, title = ?, issued_at = ?, expires_at = ?, status = ?, notes = ?, version = version + 1, updated_at = ? WHERE id = ? AND asset_id = ? AND version = ? AND deleted_at IS NULL`)
      .run(requiredString(input.type ?? current.type, 'type', { min: 2, max: 60 }).toUpperCase(), requiredString(input.title ?? current.title, 'title', { min: 2, max: 160 }), optionalString(input.issuedAt ?? current.issued_at, 'issuedAt', { max: 40 }), optionalString(input.expiresAt ?? current.expires_at, 'expiresAt', { max: 40 }), status, optionalString(input.notes ?? current.notes, 'notes', { max: 2000 }), new Date().toISOString(), documentId, assetId, expectedVersion);
    if (result.changes !== 1) throw Object.assign(new Error('El documento fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    const updated = listAssetDocuments(assetId).find((item) => item.id === documentId);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET_DOCUMENT.UPDATE', entityType: 'asset_document', entityId: documentId, before: current, after: updated, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return updated;
  });
}

function removeAssetDocument(assetId, documentId, input, context) {
  assertAssetScope(context.user, assetId, 'Assets.Documents');
  const current = getDb().prepare('SELECT * FROM asset_document WHERE id = ? AND asset_id = ? AND deleted_at IS NULL').get(documentId, assetId);
  if (!current) throw Object.assign(new Error('Documento no encontrado.'), { status: 404, code: 'ASSET_DOCUMENT_NOT_FOUND' });
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error('La versión es obligatoria.'), { status: 422, code: 'VERSION_REQUIRED' });
  if (expectedVersion !== current.version) throw Object.assign(new Error('El documento fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
  return transaction((db) => {
    const now = new Date().toISOString();
    const result = db.prepare(`UPDATE asset_document SET status = 'ANULADO', deleted_at = ?, version = version + 1, updated_at = ? WHERE id = ? AND asset_id = ? AND version = ? AND deleted_at IS NULL`)
      .run(now, now, documentId, assetId, expectedVersion);
    if (result.changes !== 1) throw Object.assign(new Error('El documento fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET_DOCUMENT.REMOVE', entityType: 'asset_document', entityId: documentId, before: current, after: { status: 'ANULADO', deletedAt: now }, correlationId: context.correlationId, source: 'API', reason: optionalString(input.reason, 'reason', { max: 500 }), ipAddress: context.ip, equipment: context.userAgent }, db);
    return { removed: true, id: documentId };
  });
}


function assertSuperAdministrator(context) {
  if (!context?.user?.roleCodes?.includes('ADMIN_GENERAL')) {
    throw Object.assign(new Error('Sólo el Super Administrador puede habilitar manualmente un bien bloqueado.'), { status: 403, code: 'ASSET_RELEASE_SUPER_ADMIN_REQUIRED' });
  }
}

function manualReleaseBlockedAsset(id, input, context) {
  assertSuperAdministrator(context);
  assertAssetScope(context.user, id, 'Assets.ReleaseBlocked');
  const reason = requiredString(input.reason, 'reason', { min: 10, max: 2000 });
  const expectedVersion = Number(input.version);
  if (!Number.isInteger(expectedVersion)) throw Object.assign(new Error('La versión es obligatoria.'), { status: 422, code: 'VERSION_REQUIRED' });
  return transaction((db) => {
    const asset = db.prepare(`${assetSelect()} WHERE a.id=? AND a.deleted_at IS NULL`).get(id);
    if (!asset) throw Object.assign(new Error('Bien no encontrado.'), { status: 404, code: 'ASSET_NOT_FOUND' });
    if (asset.version !== expectedVersion) throw Object.assign(new Error('El bien fue modificado por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    if (!asset.active || asset.status !== 'BLOQUEADO') throw Object.assign(new Error('El bien no se encuentra bloqueado y activo.'), { status: 409, code: 'ASSET_NOT_BLOCKED' });
    const openPhysicalCustody = db.prepare(`SELECT id,status FROM custody WHERE asset_id=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE') LIMIT 1`).get(id);
    if (openPhysicalCustody) throw Object.assign(new Error('El bien mantiene una custodia física abierta y no puede habilitarse manualmente.'), { status: 409, code: 'ASSET_RELEASE_OPEN_CUSTODY' });
    const activeMaintenance = db.prepare(`SELECT id,order_number,status FROM maintenance_order WHERE asset_id=? AND status='EN_PROGRESO' LIMIT 1`).get(id);
    if (activeMaintenance) throw Object.assign(new Error('El bien tiene mantenimiento en progreso y no puede habilitarse manualmente.'), { status: 409, code: 'ASSET_RELEASE_MAINTENANCE_ACTIVE' });
    const now = new Date().toISOString();
    const blocks = db.prepare(`SELECT * FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO'`).all(id);
    const incidents = db.prepare(`SELECT id,incident_number,status FROM incident WHERE asset_id=? AND status IN ('ABIERTO','EN_INVESTIGACION','RESUELTO') ORDER BY opened_at`).all(id);
    const liftedBlockIds=[];
    for (const block of blocks) {
      const liftReason = `Habilitación manual por Super Administrador: ${reason}`;
      const changed=db.prepare(`UPDATE operational_block SET status='LEVANTADO',lifted_by_user_id=?,lifted_at=?,lift_reason=?,version=version+1,updated_at=? WHERE id=? AND status='ACTIVO'`).run(context.user.id,now,liftReason,now,block.id);
      if (changed.changes===1) liftedBlockIds.push(block.id);
    }
    const activeReserved = Number(db.prepare(`SELECT COALESCE(SUM(quantity),0) AS quantity FROM asset_reservation WHERE asset_id=? AND status='ACTIVA'`).get(id)?.quantity || 0);
    const quantityTotal = Math.max(0, Number(asset.quantity_total || 0));
    const quantity = Math.max(0, Math.min(quantityTotal, quantityTotal - activeReserved));
    const exclusiveAllocation = ['SERIADO','KIT','VEHICULO'].includes(asset.category_nature) || quantityTotal <= 1;
    const finalStatus = (activeReserved > 0 && (exclusiveAllocation || quantity <= 0)) ? 'RESERVADO' : 'DISPONIBLE';
    const changedAsset=db.prepare(`UPDATE asset SET status=?,quantity_available=?,custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=? AND version=? AND status='BLOQUEADO'`).run(finalStatus,quantity,now,id,expectedVersion);
    if (changedAsset.changes!==1) throw Object.assign(new Error('Conflicto al habilitar el bien.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    const eventId=randomUUID();
    db.prepare(`INSERT INTO asset_manual_release_event(id,asset_id,prior_status,prior_quantity_available,released_status,released_quantity_available,reason,lifted_block_ids_json,linked_incident_ids_json,active_incident_count,actor_user_id,actor_role_snapshot,correlation_id,released_at,created_at) VALUES (?,?,?,?, 'DISPONIBLE',?,?,?,?,?,?,?,?,?,?)`)
      .run(eventId,id,asset.status,Number(asset.quantity_available||0),quantity,reason,JSON.stringify(liftedBlockIds),JSON.stringify(incidents.map(x=>x.id)),incidents.length,context.user.id,context.user.roleCodes.join(','),context.correlationId,now,now);
    for (const incident of incidents) {
      db.prepare(`INSERT INTO incident_event(id,incident_id,event_type,from_status,to_status,actor_user_id,details,metadata_json,occurred_at,correlation_id,created_at) VALUES (?,?,'NOTA',?,?,?,?,?,?,?,?)`)
        .run(randomUUID(),incident.id,incident.status,incident.status,context.user.id,`Bien habilitado manualmente por Super Administrador. El incidente permanece ${incident.status}. Motivo: ${reason}`,JSON.stringify({assetManualReleaseEventId:eventId,liftedBlockIds}),now,context.correlationId,now);
    }
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.MANUAL_RELEASE', entityType: 'asset', entityId: id,
      before: { status: asset.status, quantityAvailable: asset.quantity_available, activeBlocks: blocks.map(x=>x.block_number), activeIncidents: incidents.map(x=>x.incident_number) },
      after: { status: finalStatus, quantityAvailable: quantity, activeReservedQuantity: activeReserved, manualReleaseEventId: eventId, liftedBlockIds, activeIncidentsRemainOpen: incidents.length },
      reason, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    const released=db.prepare(`${assetSelect()} WHERE a.id=?`).get(id);
    return { asset: released, event: db.prepare('SELECT * FROM asset_manual_release_event WHERE id=?').get(eventId), liftedBlocks: liftedBlockIds.length, activeIncidents: incidents.length };
  });
}

function listAssetManualReleaseHistory(id, user, permission='Assets.Read') {
  const asset=getAsset(id,user,permission);
  if (!asset) throw Object.assign(new Error('Bien no encontrado.'), { status:404, code:'ASSET_NOT_FOUND' });
  return asset.manualReleaseHistory || [];
}

module.exports = { diagnoseAssetRequestAvailabilityRow,
  ASSET_STATUSES,
  MASTER_EDITABLE_STATUSES,
  listAssets,
  getAsset,
  getAssetAvailabilityDiagnosis,
  enableAvailabilityAfterPreventiveReview,
  createAsset,
  updateAsset,
  duplicateAsset,
  setAssetActive,
  manualReleaseBlockedAsset,
  listAssetManualReleaseHistory,
  setAssetPhoto,
  listAssetDocuments,
  addAssetDocument,
  updateAssetDocument,
  removeAssetDocument,
  normalizeAsset,
  insertAsset,
  assetSelect,
  convertUniqueError
};
