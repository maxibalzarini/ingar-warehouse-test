'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { appendAudit } = require('./audit-service');
const { createXlsx, zipStore } = require('./spreadsheet-service');
const { buildPatrimonialReturnPdf, buildHrReleasePdf, sha256: clearanceSha256 } = require('./user-clearance-pdf-service');

const ACTIONS = new Set(['DISABLE', 'TERMINATE']);
const EXPORT_SCOPES = new Set(['REQUEST_HISTORY', 'PENDING_WAREHOUSE_RETURNS', 'ALL']);
const OPEN_CUSTODY_STATUSES = ['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE'];
const FINAL_REQUEST_STATUSES = ['CANCELADA', 'EXPIRADA', 'ENTREGADA'];

function error(status, code, message) { return Object.assign(new Error(message), { status, code }); }
function placeholders(values) { return values.map(() => '?').join(','); }
function safeFilenamePart(value) {
  return String(value || 'usuario').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'usuario';
}
function isoDateStamp(date = new Date()) { return date.toISOString().replace(/[:]/g, '').slice(0, 15).replace('T', '-'); }

function targetIdentity(db, userId, { includeTerminated = false } = {}) {
  const row = db.prepare(`SELECT ua.id,ua.person_id,ua.username,ua.active,ua.version,ua.deleted_at,ua.created_at AS user_created_at,
      p.full_name,p.status AS person_status,p.deleted_at AS person_deleted_at,p.document_type,p.document_number,p.email,p.phone,p.sector,p.cost_center,p.employee_number,p.supervisor_person_id,
      sup.full_name AS supervisor_name,supua.username AS supervisor_username
    FROM user_account ua JOIN person p ON p.id=ua.person_id
    LEFT JOIN person sup ON sup.id=p.supervisor_person_id
    LEFT JOIN user_account supua ON supua.person_id=sup.id AND supua.deleted_at IS NULL
    WHERE ua.id=?`).get(userId);
  if (!row || (!includeTerminated && row.deleted_at)) throw error(404, 'USER_NOT_FOUND', 'Usuario no encontrado o dado de baja.');
  return row;
}

function countSnapshot(db, personId) {
  const requestCount = Number(db.prepare('SELECT COUNT(*) AS n FROM request WHERE requester_person_id=?').get(personId)?.n || 0);
  const historicalRequestCount = Number(db.prepare('SELECT COUNT(*) AS n FROM request_history_snapshot WHERE requester_person_id=?').get(personId)?.n || 0);
  const activeRequestCount = Number(db.prepare(`SELECT COUNT(*) AS n FROM request WHERE requester_person_id=? AND status NOT IN (${placeholders(FINAL_REQUEST_STATUSES)})`).get(personId, ...FINAL_REQUEST_STATUSES)?.n || 0);
  const openCustodyCount = Number(db.prepare(`SELECT COUNT(*) AS n FROM custody WHERE person_id=? AND status IN (${placeholders(OPEN_CUSTODY_STATUSES)})`).get(personId, ...OPEN_CUSTODY_STATUSES)?.n || 0);
  const pendingWarehouseReturnCount = Number(db.prepare(`SELECT COUNT(*) AS n FROM custody c
    WHERE c.person_id=? AND c.status IN ('DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE')
      AND NOT EXISTS (SELECT 1 FROM custody_return_record rr WHERE rr.custody_id=c.id)`).get(personId)?.n || 0);
  return { requestCount, historicalRequestCount, activeRequestCount, openCustodyCount, pendingWarehouseReturnCount };
}


function clearanceCustodyRows(db, personId) {
  return db.prepare(`SELECT c.id AS custody_id,c.status,c.quantity,c.opened_at,c.due_at,
      a.id AS asset_id,a.internal_code,a.description,a.serial_number,a.license_plate,
      ac.code AS category_code,ac.name AS category_name,ac.nature AS category_nature,
      s.code AS site_code,s.name AS site_name,sl.code AS location_code,sl.name AS location_name,
      r.request_number
    FROM custody c
    JOIN request r ON r.id=c.request_id
    JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    JOIN site s ON s.id=r.site_id
    JOIN storage_location sl ON sl.id=r.location_id
    WHERE c.person_id=? AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)})
    ORDER BY ac.nature,a.internal_code`).all(personId, ...OPEN_CUSTODY_STATUSES);
}

function clearanceHistoricalSummary(db, personId) {
  const custody = db.prepare(`SELECT
      SUM(CASE WHEN ac.nature NOT IN ('VEHICULO','KIT') THEN 1 ELSE 0 END) AS tools_returned,
      SUM(CASE WHEN ac.nature='VEHICULO' THEN 1 ELSE 0 END) AS vehicles_returned
    FROM custody c
    JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    WHERE c.person_id=? AND c.status='CERRADA'`).get(personId) || {};
  const kits = db.prepare(`SELECT COUNT(*) AS n FROM kit_person_assignment WHERE person_id=? AND status='CLOSED'`).get(personId) || {};
  return {
    toolsReturned: Number(custody.tools_returned || 0),
    vehiclesReturned: Number(custody.vehicles_returned || 0),
    kitsReturned: Number(kits.n || 0)
  };
}

function clearanceKitRows(db, personId) {
  return db.prepare(`SELECT kpa.id AS assignment_id,kpa.assigned_at,kpa.assignment_notes,
      a.id AS asset_id,a.internal_code,a.description,a.serial_number,sl.name AS location_name,
      (SELECT COUNT(*) FROM kit_component kc WHERE kc.kit_asset_id=a.id AND kc.active=1) AS component_count
    FROM kit_person_assignment kpa
    JOIN asset a ON a.id=kpa.kit_asset_id
    LEFT JOIN storage_location sl ON sl.id=a.location_id
    WHERE kpa.person_id=? AND kpa.status='ACTIVE'
    ORDER BY a.internal_code`).all(personId);
}

function clearanceIncidentRows(db, personId) {
  return db.prepare(`SELECT i.id,i.incident_number,i.type,i.severity,i.status,i.title,i.description,
      a.internal_code AS asset_code,a.description AS asset_description
    FROM incident i
    JOIN asset a ON a.id=i.asset_id
    LEFT JOIN custody c ON c.id=i.custody_id
    WHERE i.status NOT IN ('CERRADO','RESUELTO')
      AND (c.person_id=? OR i.liability_person_id=?)
    ORDER BY CASE i.severity WHEN 'CRITICA' THEN 1 WHEN 'ALTA' THEN 2 WHEN 'MEDIA' THEN 3 ELSE 4 END,i.opened_at`).all(personId, personId);
}

function clearanceEmitter(db, userId) {
  return db.prepare(`SELECT ua.username,p.full_name FROM user_account ua JOIN person p ON p.id=ua.person_id WHERE ua.id=?`).get(userId) || {};
}

function clearanceSite(db, userId) {
  return db.prepare(`SELECT s.code,s.name
    FROM user_role_scope urs JOIN site s ON s.id=urs.site_id
    WHERE urs.user_id=? AND urs.site_id IS NOT NULL
      AND (urs.valid_from IS NULL OR urs.valid_from<=?) AND (urs.valid_to IS NULL OR urs.valid_to>=?)
    ORDER BY CASE WHEN s.is_primary=1 THEN 0 ELSE 1 END,s.name LIMIT 1`).get(userId, new Date().toISOString(), new Date().toISOString()) || null;
}

function buildClearanceSnapshot(db, target, eventId, context) {
  const generatedAt = new Date().toISOString();
  const custodies = clearanceCustodyRows(db, target.person_id);
  const tools = custodies.filter((row) => !['VEHICULO','KIT'].includes(String(row.category_nature || '').toUpperCase())).map((row) => ({
    custodyId: row.custody_id, assetId: row.asset_id, internalCode: row.internal_code, description: row.description,
    serialNumber: row.serial_number || null, quantity: Number(row.quantity || 0), status: row.status, dueAt: row.due_at || null,
    site: row.site_name || row.site_code || null, location: row.location_name || row.location_code || null, requestNumber: row.request_number
  }));
  const vehicles = custodies.filter((row) => String(row.category_nature || '').toUpperCase() === 'VEHICULO').map((row) => ({
    custodyId: row.custody_id, assetId: row.asset_id, internalCode: row.internal_code, description: row.description,
    serialNumber: row.serial_number || null, licensePlate: row.license_plate || null, status: row.status, dueAt: row.due_at || null,
    site: row.site_name || row.site_code || null, location: row.location_name || row.location_code || null, requestNumber: row.request_number
  }));
  const kits = clearanceKitRows(db, target.person_id).map((row) => ({
    assignmentId: row.assignment_id, assetId: row.asset_id, internalCode: row.internal_code, description: row.description,
    serialNumber: row.serial_number || null, componentCount: Number(row.component_count || 0), assignedAt: row.assigned_at,
    location: row.location_name || null, notes: row.assignment_notes || null
  }));
  const incidents = clearanceIncidentRows(db, target.person_id).map((row) => ({
    id: row.id, number: row.incident_number, assetCode: row.asset_code || null, assetDescription: row.asset_description || null,
    type: row.type, severity: row.severity, status: row.status, title: row.title, description: row.description
  }));
  const site = clearanceSite(db, target.id);
  const emitter = clearanceEmitter(db, context.user.id);
  const historical = clearanceHistoricalSummary(db, target.person_id);
  const eventShort = String(eventId || '').replace(/-/g, '').slice(0, 8).toUpperCase() || 'EVENTO';
  const stamp = generatedAt.replace(/[-:TZ.]/g, '').slice(0, 14);
  const clearanceReady = tools.length === 0 && kits.length === 0 && vehicles.length === 0;
  return {
    schema: 'INGAR_USER_CLEARANCE_V1', eventId, generatedAt,
    documents: { patrimonialReceipt: `RDP-${eventShort}-${stamp}`, hrRelease: `ARH-${eventShort}-${stamp}` },
    user: {
      id: target.id, personId: target.person_id, username: target.username, fullName: target.full_name,
      document: [target.document_type, target.document_number].filter(Boolean).join(' ') || null,
      employeeNumber: target.employee_number || null, sector: target.sector || null,
      costCenter: target.cost_center || null, site: site ? `${site.code} - ${site.name}` : null,
      accountActive: Boolean(target.active), personStatus: target.person_status || null
    },
    supervisor: { personId: target.supervisor_person_id || null, name: target.supervisor_name || null, username: target.supervisor_username || null },
    emitter: { userId: context.user.id, username: emitter.username || context.user.username || null, name: emitter.full_name || context.user.fullName || null },
    tools, kits, vehicles, incidents,
    status: {
      tools: tools.length ? 'PENDIENTE' : (historical.toolsReturned ? 'DEVUELTO' : 'SIN DEUDA'),
      kits: kits.length ? 'PENDIENTE' : (historical.kitsReturned ? 'DEVUELTO' : 'SIN ASIGNACIÓN'),
      vehicles: vehicles.length ? 'PENDIENTE' : (historical.vehiclesReturned ? 'DEVUELTO' : 'SIN ASIGNACIÓN')
    },
    historical,
    clearanceReady,
    pendingTotal: tools.length + kits.length + vehicles.length
  };
}

function assertTerminationClearance(db, target, input, context) {
  const snapshot = buildClearanceSnapshot(db, target, String(input?.lifecycleEventId || ''), context);
  if (snapshot.clearanceReady) return { snapshot, override: false };
  const pending = error(409, 'USER_CLEARANCE_PENDING', `No se puede cerrar la baja: existen ${snapshot.tools.length} herramienta(s)/equipo(s), ${snapshot.kits.length} kit(s) y ${snapshot.vehicles.length} vehículo(s) pendientes.`);
  pending.clearance = { tools: snapshot.tools.length, kits: snapshot.kits.length, vehicles: snapshot.vehicles.length, incidents: snapshot.incidents.length };
  throw pending;
}

function assertRequiredTerminationPdfs(db, eventId, userId) {
  const rows = db.prepare(`SELECT filename,mime_type FROM user_lifecycle_export
    WHERE lifecycle_event_id=? AND target_user_id=? AND mime_type='application/pdf'`).all(eventId, userId);
  const patrimonial = rows.some((row) => String(row.filename || '').startsWith('remito-devolucion-patrimonial-'));
  const hr = rows.some((row) => String(row.filename || '').startsWith('acta-liberacion-rrhh-'));
  if (!patrimonial || !hr) {
    const failure = error(409, 'USER_TERMINATION_PDFS_REQUIRED', 'Antes de aplicar la baja deben generarse el Remito patrimonial y el Acta de liberación RR.HH. en PDF.');
    failure.requiredDocuments = { patrimonialReceipt: !patrimonial, hrRelease: !hr };
    throw failure;
  }
  return { patrimonialReceipt: true, hrRelease: true };
}

function rolesForUser(db, userId) {
  return db.prepare(`SELECT r.code,r.name,urs.site_id,urs.location_id,urs.valid_from,urs.valid_to
    FROM user_role_scope urs JOIN role r ON r.id=urs.role_id WHERE urs.user_id=? ORDER BY r.code`).all(userId);
}

function expireOldPending(db, userId, action, now) {
  const cutoff = new Date(new Date(now).getTime() - 24 * 3600_000).toISOString();
  db.prepare(`UPDATE user_lifecycle_event SET status='EXPIRED'
    WHERE target_user_id=? AND action=? AND status='PENDING' AND requested_at<?`).run(userId, action, cutoff);
}

function createLifecyclePreflight(userId, actionValue, context) {
  const action = String(actionValue || '').toUpperCase();
  if (!ACTIONS.has(action)) throw error(422, 'USER_LIFECYCLE_ACTION_INVALID', 'Acción de usuario inválida.');
  if (userId === context.user.id) throw error(422, 'SELF_LIFECYCLE_FORBIDDEN', 'No puede aplicar esta acción sobre su propia cuenta.');
  return transaction((db) => {
    const target = targetIdentity(db, userId);
    if (action === 'DISABLE' && !target.active) throw error(409, 'USER_ALREADY_DISABLED', 'El usuario ya está deshabilitado.');
    const now = new Date().toISOString();
    expireOldPending(db, userId, action, now);
    // Un nuevo prechequeo invalida pendientes anteriores de la misma acción: sólo el más reciente puede aplicarse.
    db.prepare(`UPDATE user_lifecycle_event SET status='CANCELLED'
      WHERE target_user_id=? AND action=? AND status='PENDING'`).run(userId, action);
    const counts = countSnapshot(db, target.person_id);
    const id = randomUUID();
    db.prepare(`INSERT INTO user_lifecycle_event(
      id,target_user_id,target_person_id,target_username_snapshot,target_name_snapshot,action,status,
      requested_by_user_id,requested_at,target_user_version_snapshot,request_count_snapshot,historical_request_count_snapshot,
      active_request_count_snapshot,open_custody_count_snapshot,pending_warehouse_return_count_snapshot,correlation_id,created_at
    ) VALUES (?,?,?,?,?,?,'PENDING',?,?,?,?,?,?,?,?,?,?)`)
      .run(id,target.id,target.person_id,target.username,target.full_name,action,context.user.id,now,target.version,
        counts.requestCount,counts.historicalRequestCount,counts.activeRequestCount,counts.openCustodyCount,counts.pendingWarehouseReturnCount,
        context.correlationId,now);
    const clearance = buildClearanceSnapshot(db, target, id, context);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: `USER.${action}.PREFLIGHT`, entityType: 'user_lifecycle_event', entityId: id,
      after: { targetUserId: target.id, targetPersonId: target.person_id, targetUsername: target.username, ...counts, clearance: { tools: clearance.tools.length, kits: clearance.kits.length, vehicles: clearance.vehicles.length, incidents: clearance.incidents.length, ready: clearance.clearanceReady } }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return {
      eventId: id,
      action,
      target: { id: target.id, personId: target.person_id, username: target.username, fullName: target.full_name, active: Boolean(target.active), version: target.version, supervisorName: target.supervisor_name || null },
      summary: { ...counts, clearance: { tools: clearance.tools.length, kits: clearance.kits.length, vehicles: clearance.vehicles.length, incidents: clearance.incidents.length, ready: clearance.clearanceReady } },
      warning: !clearance.clearanceReady
        ? `Clearance pendiente: ${clearance.tools.length} herramienta(s)/equipo(s), ${clearance.kits.length} kit(s) y ${clearance.vehicles.length} vehículo(s) requieren resolución antes de la baja.`
        : counts.openCustodyCount > 0
          ? `El usuario mantiene ${counts.openCustodyCount} custodia(s) abierta(s). La acción no las elimina ni las reasigna.`
          : 'Clearance patrimonial sin pendientes.'
    };
  });
}

function getPendingLifecycleEvent(db, eventId, userId, action, actorUserId) {
  const event = db.prepare('SELECT * FROM user_lifecycle_event WHERE id=?').get(eventId);
  if (!event || event.target_user_id !== userId) throw error(409, 'USER_LIFECYCLE_PREFLIGHT_INVALID', 'El prechequeo ya no es válido para este usuario.');
  if (event.action !== action) throw error(409, 'USER_LIFECYCLE_ACTION_MISMATCH', 'El prechequeo corresponde a otra acción.');
  if (event.status !== 'PENDING') throw error(409, 'USER_LIFECYCLE_PREFLIGHT_CLOSED', 'El prechequeo ya fue utilizado, cancelado o venció.');
  if (event.requested_by_user_id !== actorUserId) throw error(403, 'USER_LIFECYCLE_ACTOR_MISMATCH', 'La acción debe ser confirmada por el mismo administrador que inició el prechequeo.');
  const ageMs = Date.now() - new Date(event.requested_at).getTime();
  if (!Number.isFinite(ageMs) || ageMs > 24 * 3600_000) {
    const expired = error(409, 'USER_LIFECYCLE_PREFLIGHT_EXPIRED', 'El prechequeo venció. Abra nuevamente la acción.');
    expired.lifecycleEventId = eventId;
    expired.lifecycleEventStatus = 'EXPIRED';
    throw expired;
  }
  return event;
}

function assertLifecycleReady(db, { eventId, userId, action, actorUserId }) {
  const event = getPendingLifecycleEvent(db, eventId, userId, action, actorUserId);
  const target = targetIdentity(db, userId);
  if (Number(target.version) !== Number(event.target_user_version_snapshot)) {
    const changedTarget = error(409, 'USER_LIFECYCLE_TARGET_CHANGED', 'El usuario cambió después del prechequeo. Abra nuevamente la acción para revisar datos actualizados.');
    changedTarget.lifecycleEventId = event.id;
    changedTarget.lifecycleEventStatus = 'CANCELLED';
    throw changedTarget;
  }
  const counts = countSnapshot(db, target.person_id);
  const changed = counts.requestCount !== Number(event.request_count_snapshot)
    || counts.historicalRequestCount !== Number(event.historical_request_count_snapshot)
    || counts.activeRequestCount !== Number(event.active_request_count_snapshot)
    || counts.openCustodyCount !== Number(event.open_custody_count_snapshot)
    || counts.pendingWarehouseReturnCount !== Number(event.pending_warehouse_return_count_snapshot);
  if (changed) {
    const changedRelated = error(409, 'USER_LIFECYCLE_RELATED_DATA_CHANGED', 'Pedidos o devoluciones cambiaron después del prechequeo. Abra nuevamente la acción para revisar los datos actuales.');
    changedRelated.lifecycleEventId = event.id;
    changedRelated.lifecycleEventStatus = 'CANCELLED';
    throw changedRelated;
  }
  return { event, target, counts };
}

function persistLifecycleFailure(failure) {
  const eventId = String(failure?.lifecycleEventId || '').trim();
  const status = String(failure?.lifecycleEventStatus || '').trim().toUpperCase();
  if (!eventId || !['CANCELLED', 'EXPIRED'].includes(status)) return false;
  const result = getDb().prepare("UPDATE user_lifecycle_event SET status=? WHERE id=? AND status='PENDING'").run(status, eventId);
  return Number(result?.changes || 0) > 0;
}

function requestHistoryRows(db, personId) {
  return db.prepare(`SELECT
      r.request_number,r.created_at,r.needed_at,r.due_at,r.operation_type,r.status,r.reason,
      COALESCE(rhs.site_code_snapshot,s.code) AS site_code,COALESCE(rhs.site_name_snapshot,s.name) AS site_name,
      COALESCE(rhs.location_code_snapshot,sl.code) AS location_code,COALESCE(rhs.location_name_snapshot,sl.name) AS location_name,
      COALESCE(rihs.internal_code_snapshot,a.internal_code) AS asset_code,
      COALESCE(rihs.description_snapshot,a.description) AS asset_description,
      COALESCE(rihs.serial_number_snapshot,a.serial_number) AS serial_number,
      COALESCE(rihs.license_plate_snapshot,a.license_plate) AS license_plate,
      COALESCE(rihs.category_code_snapshot,ac.code) AS category_code,
      COALESCE(rihs.category_name_snapshot,ac.name) AS category_name,
      COALESCE(rihs.work_order_required_snapshot,ri.work_order_required,0) AS work_order_required,
      COALESCE(rihs.work_order_reference_snapshot,ri.work_order_reference) AS work_order_reference,
      ri.quantity,ri.status AS item_status,c.id AS custody_id,c.status AS custody_status,c.opened_at,c.declared_return_at,c.closed_at,
      crd.condition AS declared_condition,crd.problem_reported,crd.notes AS declaration_notes,
      crr.received_at,crr.timing_status,crr.overdue_seconds,crr.condition AS received_condition,crr.notes AS reception_notes,
      rvw.source_mode AS reception_review_source,rvw.operator_comment AS warehouse_comment,rvw.comment_forced_observation,rvw.blocked_after_receipt,
      ctr.receipt_number
    FROM request r
    JOIN request_item ri ON ri.request_id=r.id
    LEFT JOIN request_history_snapshot rhs ON rhs.request_id=r.id
    LEFT JOIN request_item_history_snapshot rihs ON rihs.request_item_id=ri.id
    LEFT JOIN site s ON s.id=r.site_id LEFT JOIN storage_location sl ON sl.id=r.location_id
    LEFT JOIN asset a ON a.id=ri.asset_id LEFT JOIN asset_category ac ON ac.id=a.category_id
    LEFT JOIN custody c ON c.request_item_id=ri.id
    LEFT JOIN custody_return_declaration crd ON crd.custody_id=c.id
    LEFT JOIN custody_return_record crr ON crr.custody_id=c.id
    LEFT JOIN custody_reception_review rvw ON rvw.custody_id=c.id
    LEFT JOIN custody_return_receipt ctr ON ctr.custody_id=c.id
    WHERE r.requester_person_id=?
    ORDER BY r.created_at DESC,r.request_number,asset_code`).all(personId);
}

function pendingWarehouseRows(db, personId) {
  return db.prepare(`SELECT c.id AS custody_id,r.request_number,r.created_at AS request_created_at,c.opened_at,c.due_at,c.declared_return_at,c.status,
      a.internal_code,a.description,a.serial_number,a.license_plate,ac.code AS category_code,ac.name AS category_name,ac.nature AS category_nature,
      c.quantity,s.code AS site_code,s.name AS site_name,sl.code AS location_code,sl.name AS location_name,
      crd.condition AS declared_condition,crd.problem_reported,crd.notes AS declaration_notes,crd.declared_at
    FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id
    JOIN site s ON s.id=r.site_id JOIN storage_location sl ON sl.id=r.location_id
    LEFT JOIN custody_return_declaration crd ON crd.custody_id=c.id
    WHERE c.person_id=? AND c.status IN ('DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE')
      AND NOT EXISTS (SELECT 1 FROM custody_return_record rr WHERE rr.custody_id=c.id)
    ORDER BY COALESCE(c.declared_return_at,c.opened_at),r.request_number`).all(personId);
}

function allCustodyRows(db, personId) {
  return db.prepare(`SELECT c.id AS custody_id,r.request_number,c.status,c.quantity,c.opened_at,c.due_at,c.declared_return_at,c.closed_at,
      a.internal_code,a.description,a.serial_number,a.license_plate,ac.code AS category_code,ac.name AS category_name,ac.nature AS category_nature,
      s.name AS site_name,sl.name AS location_name,crd.condition AS declared_condition,crd.problem_reported,crd.notes AS declaration_notes,
      crr.received_at,crr.timing_status,crr.overdue_seconds,crr.condition AS received_condition,crr.notes AS reception_notes,
      rvw.source_mode AS reception_review_source,rvw.operator_comment AS warehouse_comment,rvw.comment_forced_observation,rvw.blocked_after_receipt,ctr.receipt_number
    FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id
    JOIN site s ON s.id=r.site_id JOIN storage_location sl ON sl.id=r.location_id
    LEFT JOIN custody_return_declaration crd ON crd.custody_id=c.id LEFT JOIN custody_return_record crr ON crr.custody_id=c.id
    LEFT JOIN custody_reception_review rvw ON rvw.custody_id=c.id
    LEFT JOIN custody_return_receipt ctr ON ctr.custody_id=c.id WHERE c.person_id=? ORDER BY c.opened_at DESC`).all(personId);
}

function supervisorRows(db, userId) {
  return db.prepare(`SELECT usa.effective_from,usa.effective_to,usa.reason,sup.username AS supervisor_username,p.full_name AS supervisor_name,
      actor.username AS assigned_by_username,ap.full_name AS assigned_by_name
    FROM user_supervisor_assignment usa JOIN user_account sup ON sup.id=usa.supervisor_user_id JOIN person p ON p.id=sup.person_id
    LEFT JOIN user_account actor ON actor.id=usa.assigned_by_user_id LEFT JOIN person ap ON ap.id=actor.person_id
    WHERE usa.user_id=? ORDER BY usa.effective_from`).all(userId);
}

function lifecycleRows(db, userId) {
  return db.prepare(`SELECT ule.action,ule.status,ule.requested_at,ule.applied_at,ule.reason,ule.request_count_snapshot,
      ule.active_request_count_snapshot,ule.open_custody_count_snapshot,ule.pending_warehouse_return_count_snapshot,
      ru.username AS requested_by_username,rp.full_name AS requested_by_name,au.username AS applied_by_username,ap.full_name AS applied_by_name
    FROM user_lifecycle_event ule JOIN user_account ru ON ru.id=ule.requested_by_user_id JOIN person rp ON rp.id=ru.person_id
    LEFT JOIN user_account au ON au.id=ule.applied_by_user_id LEFT JOIN person ap ON ap.id=au.person_id
    WHERE ule.target_user_id=? ORDER BY ule.requested_at`).all(userId);
}

function historyWorkbook(target, rows, generatedAt) {
  const matrix = [
    ['INGAR Warehouse — Historial de pedidos'],
    [`Usuario: ${target.full_name} (${target.username})`],
    [`Generado: ${generatedAt}`],
    [],
    ['Solicitud','Pedido','Necesidad','Devolución prevista','Operación','Estado solicitud','Motivo','Sede','Ubicación','Bien','Descripción','Serie','Patente','Categoría','OT requerida','OT','Cantidad','Estado ítem','Estado custodia','Entrega','Devolución declarada','Cierre','Condición declarada','Problema declarado','Comentario técnico','Recepción pañol','Término','Atraso seg.','Condición recibida','Nota histórica recepción','Comentario pañolero F22','Origen revisión','Comentario forzó observación','Bloqueado al recibir','Constancia']
  ];
  for (const r of rows) matrix.push([r.request_number,r.created_at,r.needed_at,r.due_at||'',r.operation_type,r.status,r.reason||'',`${r.site_code||''} ${r.site_name||''}`.trim(),`${r.location_code||''} ${r.location_name||''}`.trim(),r.asset_code||'',r.asset_description||'',r.serial_number||'',r.license_plate||'',`${r.category_code||''} ${r.category_name||''}`.trim(),Number(r.work_order_required||0)===1?'SI':'NO',r.work_order_reference||'',Number(r.quantity||0),r.item_status||'',r.custody_status||'',r.opened_at||'',r.declared_return_at||'',r.closed_at||'',r.declared_condition||'',Number(r.problem_reported||0)===1?'SI':'NO',r.declaration_notes||'',r.received_at||'',r.timing_status||'',Number(r.overdue_seconds||0),r.received_condition||'',r.reception_notes||'',r.warehouse_comment||'',r.reception_review_source||'',Number(r.comment_forced_observation||0)===1?'SI':'NO',Number(r.blocked_after_receipt||0)===1?'SI':'NO',r.receipt_number||'']);
  return createXlsx(matrix,{sheetName:'Historial pedidos',titleRow:1,metadataRows:[2,3],headerRow:5,freezeRow:6,autoFilter:true});
}

function pendingWorkbook(target, rows, generatedAt) {
  const matrix = [
    ['INGAR Warehouse — Devoluciones pendientes de recepción por pañol'],
    [`Usuario: ${target.full_name} (${target.username})`],
    [`Generado: ${generatedAt}`],
    [],
    ['Custodia','Solicitud','Pedido','Entrega','Vencimiento','Devolución declarada','Estado','Bien','Descripción','Serie','Patente','Categoría','Naturaleza','Cantidad','Sede','Ubicación','Condición declarada','Informó problema','Comentario','Fecha declaración']
  ];
  for (const r of rows) matrix.push([r.custody_id,r.request_number,r.request_created_at,r.opened_at,r.due_at||'',r.declared_return_at||'',r.status,r.internal_code||'',r.description||'',r.serial_number||'',r.license_plate||'',`${r.category_code||''} ${r.category_name||''}`.trim(),r.category_nature||'',Number(r.quantity||0),`${r.site_code||''} ${r.site_name||''}`.trim(),`${r.location_code||''} ${r.location_name||''}`.trim(),r.declared_condition||'',Number(r.problem_reported||0)===1?'SI':'NO',r.declaration_notes||'',r.declared_at||'']);
  return createXlsx(matrix,{sheetName:'Pendientes pañol',titleRow:1,metadataRows:[2,3],headerRow:5,freezeRow:6,autoFilter:true});
}

function custodyWorkbook(target, rows, generatedAt) {
  const matrix = [['INGAR Warehouse — Custodias y devoluciones'],[`Usuario: ${target.full_name} (${target.username})`],[`Generado: ${generatedAt}`],[],['Custodia','Solicitud','Estado','Cantidad','Entrega','Vencimiento','Devolución declarada','Cierre','Bien','Descripción','Serie','Patente','Categoría','Naturaleza','Sede','Ubicación','Condición declarada','Problema declarado','Comentario técnico','Recepción','Término','Atraso seg.','Condición recibida','Nota histórica recepción','Comentario pañolero F22','Origen revisión','Comentario forzó observación','Bloqueado al recibir','Constancia']];
  for (const r of rows) matrix.push([r.custody_id,r.request_number,r.status,Number(r.quantity||0),r.opened_at,r.due_at||'',r.declared_return_at||'',r.closed_at||'',r.internal_code||'',r.description||'',r.serial_number||'',r.license_plate||'',`${r.category_code||''} ${r.category_name||''}`.trim(),r.category_nature||'',r.site_name||'',r.location_name||'',r.declared_condition||'',Number(r.problem_reported||0)===1?'SI':'NO',r.declaration_notes||'',r.received_at||'',r.timing_status||'',Number(r.overdue_seconds||0),r.received_condition||'',r.reception_notes||'',r.warehouse_comment||'',r.reception_review_source||'',Number(r.comment_forced_observation||0)===1?'SI':'NO',Number(r.blocked_after_receipt||0)===1?'SI':'NO',r.receipt_number||'']);
  return createXlsx(matrix,{sheetName:'Custodias',titleRow:1,metadataRows:[2,3],headerRow:5,freezeRow:6,autoFilter:true});
}

function supervisionWorkbook(target, rows, generatedAt) {
  const matrix = [['INGAR Warehouse — Historial de supervisión'],[`Usuario: ${target.full_name} (${target.username})`],[`Generado: ${generatedAt}`],[],['Desde','Hasta','Supervisor','Usuario supervisor','Asignado por','Usuario actor','Motivo']];
  for (const r of rows) matrix.push([r.effective_from,r.effective_to||'',r.supervisor_name||'',r.supervisor_username||'',r.assigned_by_name||'',r.assigned_by_username||'',r.reason||'']);
  return createXlsx(matrix,{sheetName:'Supervision',titleRow:1,metadataRows:[2,3],headerRow:5,freezeRow:6,autoFilter:true});
}

function lifecycleWorkbook(target, rows, generatedAt) {
  const matrix = [['INGAR Warehouse — Ciclo de vida del usuario'],[`Usuario: ${target.full_name} (${target.username})`],[`Generado: ${generatedAt}`],[],['Acción','Estado','Solicitado','Aplicado','Motivo','Pedidos','Pedidos activos','Custodias abiertas','Pendientes pañol','Solicitado por','Usuario solicitud','Aplicado por','Usuario aplicación']];
  for (const r of rows) matrix.push([r.action,r.status,r.requested_at,r.applied_at||'',r.reason||'',Number(r.request_count_snapshot||0),Number(r.active_request_count_snapshot||0),Number(r.open_custody_count_snapshot||0),Number(r.pending_warehouse_return_count_snapshot||0),r.requested_by_name||'',r.requested_by_username||'',r.applied_by_name||'',r.applied_by_username||'']);
  return createXlsx(matrix,{sheetName:'Ciclo usuario',titleRow:1,metadataRows:[2,3],headerRow:5,freezeRow:6,autoFilter:true});
}

function summaryText(target, roles, counts, generatedAt) {
  return [
    'INGAR Warehouse — Expediente de usuario',
    `Generado: ${generatedAt}`,
    `Nombre: ${target.full_name}`,
    `Usuario: ${target.username}`,
    `User ID: ${target.id}`,
    `Person ID: ${target.person_id}`,
    `Estado cuenta: ${target.deleted_at ? 'BAJA' : target.active ? 'ACTIVO' : 'DESHABILITADO'}`,
    `Supervisor: ${target.supervisor_name || '—'}`,
    `Roles: ${roles.map((r) => r.code).join(', ') || '—'}`,
    `Pedidos: ${counts.requestCount}`,
    `Pedidos finalizados congelados: ${counts.historicalRequestCount}`,
    `Pedidos activos: ${counts.activeRequestCount}`,
    `Custodias abiertas: ${counts.openCustodyCount}`,
    `Devoluciones pendientes de pañol: ${counts.pendingWarehouseReturnCount}`,
    '',
    'La exportación es una copia de consulta. Los registros originales permanecen en la base de datos.'
  ].join('\r\n');
}

function generateLifecycleExport(userId, input, context) {
  const eventId = String(input.eventId || '').trim();
  const scope = String(input.scope || '').toUpperCase();
  if (!eventId) throw error(422, 'USER_LIFECYCLE_EVENT_REQUIRED', 'Falta el prechequeo de la acción.');
  if (!EXPORT_SCOPES.has(scope)) throw error(422, 'USER_LIFECYCLE_EXPORT_SCOPE_INVALID', 'Tipo de exportación inválido.');
  try {
    return transaction((db) => {
    const event = db.prepare('SELECT * FROM user_lifecycle_event WHERE id=?').get(eventId);
    if (!event || event.target_user_id !== userId || event.status !== 'PENDING') throw error(409, 'USER_LIFECYCLE_PREFLIGHT_INVALID', 'El prechequeo ya no está vigente.');
    const readiness = assertLifecycleReady(db, { eventId, userId, action: event.action, actorUserId: context.user.id });
    const target = readiness.target;
    const generatedAt = new Date().toISOString();
    const history = requestHistoryRows(db,target.person_id);
    const pending = pendingWarehouseRows(db,target.person_id);
    let bytes; let filename; let mimeType; let rowCount;
    if (scope === 'REQUEST_HISTORY') {
      bytes = historyWorkbook(target,history,generatedAt); filename=`historial-pedidos-${safeFilenamePart(target.username)}-${isoDateStamp()}.xlsx`; mimeType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; rowCount=history.length;
    } else if (scope === 'PENDING_WAREHOUSE_RETURNS') {
      bytes = pendingWorkbook(target,pending,generatedAt); filename=`devoluciones-pendientes-panio-${safeFilenamePart(target.username)}-${isoDateStamp()}.xlsx`; mimeType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; rowCount=pending.length;
    } else {
      const custodies=allCustodyRows(db,target.person_id); const supervisors=supervisorRows(db,target.id); const lifecycles=lifecycleRows(db,target.id); const roles=rolesForUser(db,target.id); const counts=countSnapshot(db,target.person_id);
      bytes=zipStore([
        ['00_RESUMEN.txt',Buffer.from(summaryText(target,roles,counts,generatedAt),'utf8')],
        ['01_HISTORIAL_PEDIDOS.xlsx',historyWorkbook(target,history,generatedAt)],
        ['02_DEVOLUCIONES_PENDIENTES_PANIO.xlsx',pendingWorkbook(target,pending,generatedAt)],
        ['03_CUSTODIAS_Y_DEVOLUCIONES.xlsx',custodyWorkbook(target,custodies,generatedAt)],
        ['04_HISTORIAL_SUPERVISION.xlsx',supervisionWorkbook(target,supervisors,generatedAt)],
        ['05_CICLO_USUARIO.xlsx',lifecycleWorkbook(target,lifecycles,generatedAt)]
      ]);
      filename=`expediente-completo-${safeFilenamePart(target.username)}-${isoDateStamp()}.zip`; mimeType='application/zip'; rowCount=history.length+pending.length+custodies.length+supervisors.length+lifecycles.length;
    }
    const sha256=createHash('sha256').update(bytes).digest('hex'); const exportId=randomUUID();
    db.prepare(`INSERT INTO user_lifecycle_export(id,lifecycle_event_id,target_user_id,export_scope,filename,mime_type,sha256,row_count,generated_by_user_id,generated_at,correlation_id,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(exportId,eventId,target.id,scope,filename,mimeType,sha256,rowCount,context.user.id,generatedAt,context.correlationId,generatedAt);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.LIFECYCLE_EXPORT', entityType: 'user_lifecycle_export', entityId: exportId,
      after: { eventId,targetUserId:target.id,scope,filename,sha256,rowCount }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return { bytes,filename,mimeType,sha256,rowCount,exportId };
    });
  } catch (failure) {
    persistLifecycleFailure(failure);
    throw failure;
  }
}


function generateLifecycleClearancePdf(userId, input, context) {
  const eventId = String(input?.eventId || '').trim();
  const kind = String(input?.kind || '').toUpperCase();
  if (!eventId) throw error(422, 'USER_LIFECYCLE_EVENT_REQUIRED', 'Falta el prechequeo de la baja.');
  if (!['PATRIMONIAL_RECEIPT','HR_RELEASE'].includes(kind)) throw error(422, 'USER_CLEARANCE_PDF_KIND_INVALID', 'Tipo de remito PDF inválido.');
  try {
    return transaction((db) => {
      const event = db.prepare('SELECT * FROM user_lifecycle_event WHERE id=?').get(eventId);
      if (!event || event.target_user_id !== userId || event.status !== 'PENDING' || event.action !== 'TERMINATE') throw error(409, 'USER_LIFECYCLE_PREFLIGHT_INVALID', 'El prechequeo de baja ya no está vigente.');
      const readiness = assertLifecycleReady(db, { eventId, userId, action: 'TERMINATE', actorUserId: context.user.id });
      const snapshot = buildClearanceSnapshot(db, readiness.target, eventId, context);
      const canonical = JSON.stringify(snapshot);
      snapshot.snapshotSha256 = clearanceSha256(Buffer.from(canonical, 'utf8'));
      const bytes = kind === 'PATRIMONIAL_RECEIPT' ? buildPatrimonialReturnPdf(snapshot) : buildHrReleasePdf(snapshot);
      const fileHash = createHash('sha256').update(bytes).digest('hex');
      const filename = `${kind === 'PATRIMONIAL_RECEIPT' ? 'remito-devolucion-patrimonial' : 'acta-liberacion-rrhh'}-${safeFilenamePart(readiness.target.username)}-${isoDateStamp()}.pdf`;
      const exportId = randomUUID(); const generatedAt = snapshot.generatedAt;
      db.prepare(`INSERT INTO user_lifecycle_export(id,lifecycle_event_id,target_user_id,export_scope,filename,mime_type,sha256,row_count,generated_by_user_id,generated_at,correlation_id,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(exportId,eventId,readiness.target.id,'ALL',filename,'application/pdf',fileHash,snapshot.pendingTotal,context.user.id,generatedAt,context.correlationId,generatedAt);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'USER.CLEARANCE_PDF_EXPORT', entityType: 'user_lifecycle_export', entityId: exportId,
        after: { kind, eventId, targetUserId: readiness.target.id, filename, pdfSha256: fileHash, snapshotSha256: snapshot.snapshotSha256, snapshot }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
      return { bytes, filename, mimeType: 'application/pdf', sha256: fileHash, snapshotSha256: snapshot.snapshotSha256, exportId, clearanceReady: snapshot.clearanceReady, pendingTotal: snapshot.pendingTotal };
    });
  } catch (failure) { persistLifecycleFailure(failure); throw failure; }
}

function finalizeLifecycleEventInDb(db, { eventId, userId, action, reason, context, result }) {
  const normalizedReason=String(reason||'').trim();
  if (normalizedReason.length<5 || normalizedReason.length>1500) throw error(422,'USER_LIFECYCLE_REASON_INVALID','Ingresá un motivo de entre 5 y 1500 caracteres.');
  const { event,target }=assertLifecycleReady(db,{eventId,userId,action,actorUserId:context.user.id});
  const now=new Date().toISOString();
  db.prepare(`UPDATE user_lifecycle_event SET status='APPLIED',applied_by_user_id=?,applied_at=?,reason=?,result_snapshot_json=? WHERE id=? AND status='PENDING'`)
    .run(context.user.id,now,normalizedReason,JSON.stringify(result||{}),event.id);
  return { event,target,now,reason:normalizedReason };
}

module.exports = {
  createLifecyclePreflight,
  generateLifecycleExport,
  generateLifecycleClearancePdf,
  finalizeLifecycleEventInDb,
  persistLifecycleFailure,
  assertLifecycleReady,
  assertTerminationClearance,
  assertRequiredTerminationPdfs,
  buildClearanceSnapshot,
  countSnapshot
};
