
'use strict';

const { getDb } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { scopeFromInput, normalizePeriod } = require('./management-service');
const { getSetting } = require('./settings-service');

const DEFAULT_TIME_ZONE = 'America/Argentina/Buenos_Aires';
const OPEN_CUSTODY_STATUSES = ['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE'];
const OPEN_INCIDENT_STATUSES = ['ABIERTO', 'EN_INVESTIGACION'];
const ENTITY_TYPES = ['PERSON', 'SECTOR', 'ASSET'];

function profileError(message, code = 'MANAGEMENT_PROFILE_INVALID', status = 422) {
  return Object.assign(new Error(message), { code, status });
}
function can(user, permission) { return Boolean(user && hasPermission(user, permission)); }
function placeholders(values) { return values.map(() => '?').join(','); }
function round(value, digits = 2) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return null;
  const factor = 10 ** digits;
  return Math.round(Number(value) * factor) / factor;
}
function percent(numerator, denominator) { return denominator > 0 ? round(numerator / denominator * 100) : null; }
function safeLimit(value, fallback = 60, max = 200) { return Math.min(max, Math.max(1, Number(value) || fallback)); }
function normalizeType(value) {
  const type = String(value || '').toUpperCase();
  if (!ENTITY_TYPES.includes(type)) throw profileError('Tipo de ficha inválido.', 'MANAGEMENT_PROFILE_TYPE_INVALID');
  return type;
}
function roleView(user) {
  const roles = new Set(user?.roleCodes || []);
  const admin = roles.has('ADMIN_GENERAL') || roles.has('ADMINISTRADOR');
  if (roles.has('PANOLERO') && !admin && !roles.has('SUPERVISOR')) {
    return { code: 'OPERATIVA', label: 'Vista del pañol', showCosts: can(user, 'Finance.Read'), showRanking: false };
  }
  if (roles.has('AUDITOR') && !admin && !roles.has('SUPERVISOR')) {
    return { code: 'AUDITORIA', label: 'Vista de auditoría', showCosts: can(user, 'Finance.Read'), showRanking: true };
  }
  return { code: 'GERENCIAL', label: 'Vista gerencial', showCosts: can(user, 'Finance.Read'), showRanking: true };
}
function scopeSql(scope, siteColumn, locationColumn) {
  if (scope.type === 'LOCATION') return { sql: `${locationColumn}=?`, params: [scope.locationId] };
  if (scope.type === 'SITE') return { sql: `${siteColumn}=?`, params: [scope.siteId] };
  return { sql: '1=1', params: [] };
}
function scopeAssignmentSql(scope) {
  if (scope.type === 'LOCATION') return {
    sql: `(urs.site_id IS NULL OR urs.location_id=? OR (urs.site_id=? AND urs.location_id IS NULL))`,
    params: [scope.locationId, scope.siteId]
  };
  if (scope.type === 'SITE') return { sql: `(urs.site_id IS NULL OR urs.site_id=?)`, params: [scope.siteId] };
  return { sql: '1=1', params: [] };
}
function profileContext(user, input, db, options = {}) {
  if (!can(user, 'Management.Read')) throw profileError('Permiso insuficiente.', 'FORBIDDEN', 403);
  const now = options.now instanceof Date ? options.now : new Date();
  const timeZone = String(getSetting('locale.timezone', DEFAULT_TIME_ZONE) || DEFAULT_TIME_ZONE);
  const scope = scopeFromInput(input, user, 'Management.Read', db);
  const period = normalizePeriod(input, now, timeZone);
  return { now, nowIso: now.toISOString(), timeZone, scope, period, view: roleView(user) };
}
function personCandidateSql(scope) {
  const requestScope = scopeSql(scope, 'r.site_id', 'r.location_id');
  const custodyScope = scopeSql(scope, 'r2.site_id', 'r2.location_id');
  const assignmentScope = scopeAssignmentSql(scope);
  return {
    sql: `WITH candidate_person AS (
      SELECT DISTINCT r.requester_person_id AS person_id FROM request r WHERE ${requestScope.sql}
      UNION
      SELECT DISTINCT c.person_id FROM custody c JOIN request r2 ON r2.id=c.request_id WHERE ${custodyScope.sql}
      UNION
      SELECT DISTINCT ua.person_id FROM user_account ua JOIN user_role_scope urs ON urs.user_id=ua.id
        WHERE ua.active=1 AND ua.deleted_at IS NULL AND ${assignmentScope.sql}
    )`,
    params: [...requestScope.params, ...custodyScope.params, ...assignmentScope.params]
  };
}
function personQuick(db, personId, context) {
  const requestScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const custodyScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const current = db.prepare(`SELECT COUNT(*) AS active_tools,
      SUM(CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 1 ELSE 0 END) AS overdue_tools
    FROM custody c JOIN request r ON r.id=c.request_id
    WHERE c.person_id=? AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND ${custodyScope.sql}`)
    .get(context.nowIso, personId, ...OPEN_CUSTODY_STATUSES, ...custodyScope.params);
  const requests = db.prepare(`SELECT COUNT(*) AS requests_count FROM request r
    WHERE r.requester_person_id=? AND r.created_at>=? AND r.created_at<? AND ${requestScope.sql}`)
    .get(personId, context.period.startUtc, context.period.endUtc, ...requestScope.params);
  return { activeTools: Number(current.active_tools || 0), overdueTools: Number(current.overdue_tools || 0), requests: Number(requests.requests_count || 0) };
}
function listPersons(db, context, input) {
  const candidate = personCandidateSql(context.scope);
  const search = String(input.search || '').trim();
  const params = [...candidate.params];
  let where = `p.deleted_at IS NULL AND p.status<>'ELIMINADA'`;
  if (search) { where += ` AND (p.full_name LIKE ? OR IFNULL(p.sector,'') LIKE ? OR IFNULL(p.employee_number,'') LIKE ?)`; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
  const rows = db.prepare(`${candidate.sql}
    SELECT p.id,p.full_name,p.sector,p.employee_number,p.status,ua.username,ua.active AS user_active
    FROM candidate_person cp JOIN person p ON p.id=cp.person_id LEFT JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
    WHERE ${where} ORDER BY p.full_name LIMIT ?`).all(...params, safeLimit(input.limit));
  return rows.map((row) => {
    const quick = personQuick(db, row.id, context);
    const tone = quick.overdueTools > 0 ? 'danger' : quick.activeTools > 0 ? 'warn' : 'ok';
    return { id: row.id, type: 'PERSON', label: row.full_name, subtitle: [row.sector || 'Sin sector', row.employee_number || row.username || ''].filter(Boolean).join(' · '), tone, metrics: quick };
  });
}
function sectorQuick(db, sector, context) {
  const requestScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const custodyScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const candidate = personCandidateSql(context.scope);
  const people = db.prepare(`${candidate.sql} SELECT COUNT(DISTINCT p.id) AS value
    FROM candidate_person cp JOIN person p ON p.id=cp.person_id
    WHERE p.deleted_at IS NULL AND p.status<>'ELIMINADA' AND TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE`)
    .get(...candidate.params, sector);
  const requests = db.prepare(`SELECT COUNT(*) AS value FROM request r JOIN person p ON p.id=r.requester_person_id
    WHERE TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE AND r.created_at>=? AND r.created_at<? AND ${requestScope.sql}`)
    .get(sector, context.period.startUtc, context.period.endUtc, ...requestScope.params);
  const custody = db.prepare(`SELECT COUNT(*) AS active_tools,SUM(CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 1 ELSE 0 END) AS overdue_tools
    FROM custody c JOIN request r ON r.id=c.request_id JOIN person p ON p.id=c.person_id
    WHERE TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND ${custodyScope.sql}`)
    .get(context.nowIso, sector, ...OPEN_CUSTODY_STATUSES, ...custodyScope.params);
  return { people: Number(people.value || 0), requests: Number(requests.value || 0), activeTools: Number(custody.active_tools || 0), overdueTools: Number(custody.overdue_tools || 0) };
}
function listSectors(db, context, input) {
  const candidate = personCandidateSql(context.scope);
  const search = String(input.search || '').trim();
  const params = [...candidate.params];
  let where = `p.deleted_at IS NULL AND p.status<>'ELIMINADA' AND TRIM(IFNULL(p.sector,''))<>''`;
  if (search) { where += ` AND p.sector LIKE ?`; params.push(`%${search}%`); }
  const rows = db.prepare(`${candidate.sql}
    SELECT TRIM(p.sector) AS sector FROM candidate_person cp JOIN person p ON p.id=cp.person_id
    WHERE ${where} GROUP BY TRIM(p.sector) COLLATE NOCASE ORDER BY TRIM(p.sector) LIMIT ?`).all(...params, safeLimit(input.limit));
  return rows.map((row) => {
    const quick = sectorQuick(db, row.sector, context);
    const tone = quick.overdueTools > 0 ? 'danger' : quick.activeTools > 0 ? 'warn' : 'ok';
    return { id: row.sector, type: 'SECTOR', label: row.sector, subtitle: `${quick.people} persona${quick.people === 1 ? '' : 's'}`, tone, metrics: quick };
  });
}
function listAssets(db, context, input) {
  const scope = scopeSql(context.scope, 'sl.site_id', 'a.location_id');
  const params = [...scope.params];
  let where = `a.deleted_at IS NULL AND a.active=1 AND ${scope.sql}`;
  const search = String(input.search || '').trim();
  if (search) { where += ` AND (a.internal_code LIKE ? OR a.description LIKE ? OR IFNULL(a.serial_number,'') LIKE ? OR IFNULL(a.brand,'') LIKE ?)`; params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`); }
  const rows = db.prepare(`SELECT a.id,a.internal_code,a.description,a.serial_number,a.brand,a.model,a.status,ac.name AS category_name,ac.nature,sl.name AS location_name,
      (SELECT COUNT(*) FROM custody c WHERE c.asset_id=a.id AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)})) AS active_custodies,
      (SELECT COUNT(*) FROM custody c WHERE c.asset_id=a.id AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND c.due_at IS NOT NULL AND c.due_at<?) AS overdue_custodies,
      (SELECT COUNT(*) FROM incident i WHERE i.asset_id=a.id AND i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)})) AS open_incidents
    FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE ${where} ORDER BY CASE a.status WHEN 'BLOQUEADO' THEN 0 WHEN 'MANTENIMIENTO' THEN 1 WHEN 'EN_CUSTODIA' THEN 2 ELSE 3 END,a.internal_code LIMIT ?`)
    .all(...OPEN_CUSTODY_STATUSES, ...OPEN_CUSTODY_STATUSES, context.nowIso, ...OPEN_INCIDENT_STATUSES, ...params, safeLimit(input.limit));
  return rows.map((row) => {
    const tone = Number(row.overdue_custodies) > 0 || Number(row.open_incidents) > 0 || ['BLOQUEADO','PERDIDO'].includes(row.status) ? 'danger' : ['MANTENIMIENTO','EN_CUSTODIA','RESERVADO'].includes(row.status) ? 'warn' : 'ok';
    return { id: row.id, type: 'ASSET', label: `${row.internal_code} · ${row.description}`, subtitle: `${row.category_name} · ${row.location_name}`, tone, status: row.status,
      metrics: { activeCustodies: Number(row.active_custodies || 0), overdueCustodies: Number(row.overdue_custodies || 0), openIncidents: Number(row.open_incidents || 0) } };
  });
}
function listManagementEntities(user, input = {}, options = {}) {
  const db = options.db || getDb();
  const context = profileContext(user, input, db, options);
  const type = normalizeType(input.type || 'PERSON');
  const items = type === 'PERSON' ? listPersons(db, context, input) : type === 'SECTOR' ? listSectors(db, context, input) : listAssets(db, context, input);
  return { generatedAt: context.nowIso, timeZone: context.timeZone, scope: context.scope, period: context.period, view: context.view, type, total: items.length, items };
}
function assertPersonInScope(db, personId, context) {
  const candidate = personCandidateSql(context.scope);
  const row = db.prepare(`${candidate.sql} SELECT p.* FROM candidate_person cp JOIN person p ON p.id=cp.person_id WHERE p.id=? AND p.deleted_at IS NULL`).get(...candidate.params, personId);
  if (!row) throw profileError('Persona inexistente o fuera del alcance.', 'MANAGEMENT_PROFILE_PERSON_NOT_FOUND', 404);
  return row;
}
function assertSectorInScope(db, sector, context) {
  const candidate = personCandidateSql(context.scope);
  const row = db.prepare(`${candidate.sql} SELECT TRIM(p.sector) AS sector FROM candidate_person cp JOIN person p ON p.id=cp.person_id
    WHERE TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE AND p.deleted_at IS NULL LIMIT 1`).get(...candidate.params, sector);
  if (!row) throw profileError('Sector inexistente o fuera del alcance.', 'MANAGEMENT_PROFILE_SECTOR_NOT_FOUND', 404);
  return row.sector;
}
function assertAssetInScope(db, assetId, context) {
  const scope = scopeSql(context.scope, 'sl.site_id', 'a.location_id');
  const row = db.prepare(`SELECT a.*,ac.name AS category_name,ac.nature,ac.requires_return,ac.serialized,sl.name AS location_name,sl.site_id,s.name AS site_name
    FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id
    WHERE a.id=? AND a.deleted_at IS NULL AND ${scope.sql}`).get(assetId, ...scope.params);
  if (!row) throw profileError('Herramienta inexistente o fuera del alcance.', 'MANAGEMENT_PROFILE_ASSET_NOT_FOUND', 404);
  return row;
}
function summaryItem(key, label, value, unit = 'COUNT', tone = 'neutral', help = '') { return { key, label, value, unit, tone, help }; }
function personProfile(db, personId, context) {
  const person = assertPersonInScope(db, personId, context);
  const requestScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const custodyScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const currentTools = db.prepare(`SELECT c.id AS custody_id,a.id AS asset_id,a.internal_code,a.description,c.quantity,c.opened_at,c.due_at,c.status,
      CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN CAST((julianday(?) - julianday(c.due_at)) AS INTEGER) ELSE 0 END AS overdue_days
    FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id
    WHERE c.person_id=? AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND ${custodyScope.sql}
    ORDER BY CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN 0 ELSE 1 END,c.due_at,a.internal_code LIMIT 100`)
    .all(context.nowIso, context.nowIso, personId, ...OPEN_CUSTODY_STATUSES, ...custodyScope.params, context.nowIso);
  const requestStats = db.prepare(`SELECT COUNT(DISTINCT r.id) AS requested,
      COUNT(DISTINCT CASE WHEN h.id IS NOT NULL THEN r.id END) AS delivered
    FROM request r LEFT JOIN handover h ON h.request_id=r.id AND h.type='ENTREGA' AND h.occurred_at>=? AND h.occurred_at<?
    WHERE r.requester_person_id=? AND r.created_at>=? AND r.created_at<? AND ${requestScope.sql}`)
    .get(context.period.startUtc, context.period.endUtc, personId, context.period.startUtc, context.period.endUtc, ...requestScope.params);
  const returnStats = db.prepare(`SELECT COUNT(*) AS total,SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END) AS on_time,
      SUM(CASE WHEN crr.condition<>'CONFORME' THEN 1 ELSE 0 END) AS issues
    FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id
    WHERE c.person_id=? AND crr.received_at>=? AND crr.received_at<? AND ${custodyScope.sql}`)
    .get(personId, context.period.startUtc, context.period.endUtc, ...custodyScope.params);
  const incidentStats = db.prepare(`SELECT COUNT(DISTINCT i.id) AS total,SUM(CASE WHEN i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)}) THEN 1 ELSE 0 END) AS open,
      SUM(COALESCE(i.actual_cost,i.estimated_cost,0)) AS cost
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN custody c ON c.id=i.custody_id
    WHERE (i.liability_person_id=? OR c.person_id=?) AND i.detected_at>=? AND i.detected_at<? AND ${scopeSql(context.scope,'sl.site_id','a.location_id').sql}`)
    .get(...OPEN_INCIDENT_STATUSES, personId, personId, context.period.startUtc, context.period.endUtc, ...scopeSql(context.scope,'sl.site_id','a.location_id').params);
  const recentReturns = db.prepare(`SELECT a.internal_code,a.description,crr.received_at,crr.timing_status,crr.condition,crr.overdue_seconds,crr.notes
    FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id
    WHERE c.person_id=? AND crr.received_at>=? AND crr.received_at<? AND ${custodyScope.sql} ORDER BY crr.received_at DESC LIMIT 30`)
    .all(personId, context.period.startUtc, context.period.endUtc, ...custodyScope.params);
  const incidents = db.prepare(`SELECT i.id,i.incident_number,a.internal_code,a.description,i.type,i.severity,i.status,i.title,i.detected_at,i.estimated_cost,i.actual_cost
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN custody c ON c.id=i.custody_id
    WHERE (i.liability_person_id=? OR c.person_id=?) AND i.detected_at>=? AND i.detected_at<? AND ${scopeSql(context.scope,'sl.site_id','a.location_id').sql}
    ORDER BY i.detected_at DESC LIMIT 30`).all(personId, personId, context.period.startUtc, context.period.endUtc, ...scopeSql(context.scope,'sl.site_id','a.location_id').params);
  const activeTools = currentTools.length;
  const overdueTools = currentTools.filter((item) => Number(item.overdue_days) > 0).length;
  const returnsTotal = Number(returnStats.total || 0); const onTime = Number(returnStats.on_time || 0); const issues = Number(returnStats.issues || 0);
  const summary = [
    summaryItem('CURRENT_TOOLS','Herramientas actuales',activeTools,'COUNT',overdueTools ? 'danger' : activeTools ? 'warn' : 'ok'),
    summaryItem('OVERDUE_TOOLS','Devoluciones atrasadas',overdueTools,'COUNT',overdueTools ? 'danger' : 'ok'),
    summaryItem('REQUESTS','Pedidos del período',Number(requestStats.requested || 0)),
    summaryItem('DELIVERED','Pedidos entregados',Number(requestStats.delivered || 0)),
    summaryItem('RETURN_COMPLIANCE','Devoluciones a tiempo',percent(onTime,returnsTotal),'PERCENT',returnsTotal && onTime < returnsTotal ? 'warn' : returnsTotal ? 'ok' : 'neutral'),
    summaryItem('RETURN_ISSUES','Devoluciones con problemas',issues,'COUNT',issues ? 'danger' : 'ok'),
    summaryItem('INCIDENTS','Problemas registrados',Number(incidentStats.total || 0),'COUNT',Number(incidentStats.open || 0) ? 'danger' : Number(incidentStats.total || 0) ? 'warn' : 'ok')
  ];
  if (context.view.showCosts) summary.push(summaryItem('INCIDENT_COST','Costo registrado en problemas',round(incidentStats.cost || 0),'CURRENCY',Number(incidentStats.cost || 0) ? 'warn' : 'neutral','Solo costos registrados en incidentes.'));
  return { type:'PERSON',id:person.id,title:person.full_name,subtitle:[person.sector||'Sin sector',person.employee_number||'',person.cost_center||''].filter(Boolean).join(' · '),status:person.status,
    period:context.period,scope:context.scope,view:context.view,costCoverage:context.view.showCosts?'INCIDENTS_ONLY':'HIDDEN',summary,
    sections:[
      { code:'CURRENT_TOOLS',title:'Herramientas que tiene ahora',empty:'No tiene herramientas entregadas.',columns:[['internal_code','Código'],['description','Herramienta'],['opened_at','Entregada'],['due_at','Devolver'],['status','Estado'],['overdue_days','Días de atraso']],rows:currentTools },
      { code:'RETURNS',title:'Devoluciones del período',empty:'No hay devoluciones en el período.',columns:[['internal_code','Código'],['description','Herramienta'],['received_at','Devuelta'],['timing_status','Plazo'],['condition','Condición'],['overdue_seconds','Atraso (s)']],rows:recentReturns },
      { code:'INCIDENTS',title:'Problemas relacionados',empty:'No hay problemas relacionados.',columns:[['incident_number','N.º'],['internal_code','Herramienta'],['title','Problema'],['severity','Gravedad'],['status','Estado'],['detected_at','Fecha']],rows:incidents }
    ] };
}
function sectorProfile(db, sectorInput, context) {
  const sector = assertSectorInScope(db, sectorInput, context);
  const requestScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const custodyScope = scopeSql(context.scope, 'r.site_id', 'r.location_id');
  const assetScope = scopeSql(context.scope, 'sl.site_id', 'a.location_id');
  const quick = sectorQuick(db, sector, context);
  const returnStats = db.prepare(`SELECT COUNT(*) AS total,SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END) AS on_time,
      SUM(CASE WHEN crr.condition<>'CONFORME' THEN 1 ELSE 0 END) AS issues
    FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id JOIN person p ON p.id=c.person_id
    WHERE TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE AND crr.received_at>=? AND crr.received_at<? AND ${custodyScope.sql}`)
    .get(sector, context.period.startUtc, context.period.endUtc, ...custodyScope.params);
  const incidentStats = db.prepare(`SELECT COUNT(DISTINCT i.id) AS total,SUM(CASE WHEN i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)}) THEN 1 ELSE 0 END) AS open,
      SUM(COALESCE(i.actual_cost,i.estimated_cost,0)) AS cost
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN custody c ON c.id=i.custody_id
    LEFT JOIN person responsible ON responsible.id=COALESCE(i.liability_person_id,c.person_id)
    WHERE TRIM(IFNULL(responsible.sector,''))=? COLLATE NOCASE AND i.detected_at>=? AND i.detected_at<? AND ${assetScope.sql}`)
    .get(...OPEN_INCIDENT_STATUSES, sector, context.period.startUtc, context.period.endUtc, ...assetScope.params);
  const candidate = personCandidateSql(context.scope);
  const peopleRows = db.prepare(`${candidate.sql}
    SELECT DISTINCT p.id AS person_id,p.full_name
    FROM candidate_person cp JOIN person p ON p.id=cp.person_id
    WHERE p.deleted_at IS NULL AND p.status<>'ELIMINADA' AND TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE
    ORDER BY p.full_name LIMIT 100`).all(...candidate.params, sector).map((row) => {
      const quickPerson = personQuick(db, row.person_id, context);
      return { person_id: row.person_id, full_name: row.full_name, active_tools: quickPerson.activeTools, overdue_tools: quickPerson.overdueTools, requests: quickPerson.requests };
    }).sort((a,b)=>b.overdue_tools-a.overdue_tools||b.active_tools-a.active_tools||a.full_name.localeCompare(b.full_name)).slice(0,50);
  const topAssets = db.prepare(`SELECT a.id AS asset_id,a.internal_code,a.description,
      COUNT(DISTINCT h.id) AS deliveries,SUM(hi.quantity) AS delivered_quantity,
      (SELECT COUNT(*) FROM incident ix WHERE ix.asset_id=a.id AND ix.detected_at>=? AND ix.detected_at<?) AS incidents
    FROM handover h JOIN person p ON p.id=h.person_id JOIN handover_item hi ON hi.handover_id=h.id
    JOIN asset a ON a.id=hi.asset_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE h.type='ENTREGA' AND TRIM(IFNULL(p.sector,''))=? COLLATE NOCASE
      AND h.occurred_at>=? AND h.occurred_at<? AND ${assetScope.sql}
    GROUP BY a.id ORDER BY deliveries DESC,incidents DESC,a.internal_code LIMIT 30`)
    .all(context.period.startUtc,context.period.endUtc,sector,context.period.startUtc,context.period.endUtc,...assetScope.params);
  const incidents = db.prepare(`SELECT i.incident_number,a.internal_code,a.description,i.title,i.severity,i.status,i.detected_at,COALESCE(i.actual_cost,i.estimated_cost,0) AS registered_cost
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id LEFT JOIN custody c ON c.id=i.custody_id
    LEFT JOIN person responsible ON responsible.id=COALESCE(i.liability_person_id,c.person_id)
    WHERE TRIM(IFNULL(responsible.sector,''))=? COLLATE NOCASE AND i.detected_at>=? AND i.detected_at<? AND ${assetScope.sql}
    ORDER BY i.detected_at DESC LIMIT 30`).all(sector,context.period.startUtc,context.period.endUtc,...assetScope.params);
  const economicCosts = context.view.showCosts ? db.prepare(`SELECT c.occurred_on,c.description,c.cost_type,c.currency_code,
      (c.sign*c.amount_minor)/(CASE cur.minor_units WHEN 0 THEN 1 WHEN 1 THEN 10 WHEN 2 THEN 100 WHEN 3 THEN 1000 ELSE 100 END) AS amount,
      c.provider,c.document_reference,c.status
    FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code
    WHERE TRIM(IFNULL(c.sector,''))=? COLLATE NOCASE AND c.occurred_on>=? AND c.occurred_on<?
      AND c.status IN ('EJECUTADO','REVERSADO') AND ${scopeSql(context.scope,'c.site_id','c.location_id').sql}
    ORDER BY c.occurred_on DESC,c.created_at DESC LIMIT 60`).all(sector,context.period.startUtc,context.period.endUtc,...scopeSql(context.scope,'c.site_id','c.location_id').params) : [];
  const economicTotals = context.view.showCosts ? db.prepare(`SELECT c.currency_code,cur.minor_units,SUM(c.sign*c.amount_minor) AS amount_minor
    FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code
    WHERE TRIM(IFNULL(c.sector,''))=? COLLATE NOCASE AND c.occurred_on>=? AND c.occurred_on<?
      AND c.status IN ('EJECUTADO','REVERSADO') AND ${scopeSql(context.scope,'c.site_id','c.location_id').sql}
    GROUP BY c.currency_code,cur.minor_units ORDER BY c.currency_code`).all(sector,context.period.startUtc,context.period.endUtc,...scopeSql(context.scope,'c.site_id','c.location_id').params) : [];
  const returnsTotal=Number(returnStats.total||0), onTime=Number(returnStats.on_time||0), issues=Number(returnStats.issues||0);
  const summary=[
    summaryItem('PEOPLE','Personas',quick.people),summaryItem('REQUESTS','Pedidos del período',quick.requests),
    summaryItem('CURRENT_TOOLS','Herramientas en uso',quick.activeTools,'COUNT',quick.overdueTools?'danger':quick.activeTools?'warn':'ok'),
    summaryItem('OVERDUE_TOOLS','Devoluciones atrasadas',quick.overdueTools,'COUNT',quick.overdueTools?'danger':'ok'),
    summaryItem('RETURN_COMPLIANCE','Devoluciones a tiempo',percent(onTime,returnsTotal),'PERCENT',returnsTotal&&onTime<returnsTotal?'warn':returnsTotal?'ok':'neutral'),
    summaryItem('RETURN_ISSUES','Devoluciones con problemas',issues,'COUNT',issues?'danger':'ok'),
    summaryItem('INCIDENTS','Problemas registrados',Number(incidentStats.total||0),'COUNT',Number(incidentStats.open||0)?'danger':Number(incidentStats.total||0)?'warn':'ok')
  ];
  if(context.view.showCosts) {
    for (const total of economicTotals) {
      const divisor = 10 ** Number(total.minor_units || 0);
      summary.push(summaryItem(`ECONOMIC_COST_${total.currency_code}`,`Costo económico ${total.currency_code}`,`${round(Number(total.amount_minor || 0) / divisor)} ${total.currency_code}`,'TEXT',Number(total.amount_minor || 0)?'warn':'neutral','Incluye costos, compras ejecutadas, mantenimiento, reparación e incidentes registrados en Costos y Presupuesto.'));
    }
  }
  return {type:'SECTOR',id:sector,title:sector,subtitle:`${quick.people} persona${quick.people===1?'':'s'} en el sector`,status:quick.overdueTools?'URGENTE':'ACTIVO',period:context.period,scope:context.scope,view:context.view,costCoverage:context.view.showCosts?'ECONOMIC_COMPLETE':'HIDDEN',summary,
    sections:[
      {code:'PEOPLE',title:'Personas del sector',empty:'No hay personas con actividad.',columns:[['full_name','Persona'],['active_tools','Herramientas actuales'],['overdue_tools','Atrasadas'],['requests','Pedidos']],rows:peopleRows},
      {code:'TOP_ASSETS',title:'Herramientas más utilizadas',empty:'No hay entregas en el período.',columns:[['internal_code','Código'],['description','Herramienta'],['deliveries','Entregas'],['delivered_quantity','Cantidad'],['incidents','Problemas']],rows:topAssets},
      {code:'INCIDENTS',title:'Problemas del sector',empty:'No hay problemas en el período.',
        columns:[['incident_number','N.º'],['internal_code','Código'],['title','Problema'],['severity','Gravedad'],['status','Estado'],['detected_at','Fecha']],
        rows:incidents.map(({registered_cost,...row})=>row)},
      ...(context.view.showCosts?[{code:'ECONOMIC_COSTS',title:'Costos económicos del sector',empty:'No hay costos económicos en el período.',columns:[['occurred_on','Fecha'],['description','Descripción'],['cost_type','Tipo'],['currency_code','Moneda'],['amount','Importe'],['provider','Proveedor'],['status','Estado']],rows:economicCosts}]:[])
    ]};
}
function custodyOverlapHours(db, assetId, period, scope) {
  const scopeFilter=scopeSql(scope,'r.site_id','r.location_id');
  const row=db.prepare(`SELECT SUM(MAX(0,(julianday(CASE WHEN COALESCE(c.closed_at,?)<? THEN COALESCE(c.closed_at,?) ELSE ? END)-
      julianday(CASE WHEN c.opened_at>? THEN c.opened_at ELSE ? END))*24)) AS hours
    FROM custody c JOIN request r ON r.id=c.request_id WHERE c.asset_id=? AND c.opened_at<? AND COALESCE(c.closed_at,?)>? AND ${scopeFilter.sql}`)
    .get(period.endUtc,period.endUtc,period.endUtc,period.endUtc,period.startUtc,period.startUtc,assetId,period.endUtc,period.endUtc,period.startUtc,...scopeFilter.params);
  return round(row.hours||0);
}
function assetProfile(db, assetId, context) {
  const asset=assertAssetInScope(db,assetId,context);
  const custodyScope=scopeSql(context.scope,'r.site_id','r.location_id');
  const assetScope=scopeSql(context.scope,'sl.site_id','a.location_id');
  const currentCustodies=db.prepare(`SELECT c.id AS custody_id,p.full_name,p.sector,c.quantity,c.opened_at,c.due_at,c.status,
      CASE WHEN c.due_at IS NOT NULL AND c.due_at<? THEN CAST((julianday(?) - julianday(c.due_at)) AS INTEGER) ELSE 0 END AS overdue_days
    FROM custody c JOIN request r ON r.id=c.request_id JOIN person p ON p.id=c.person_id
    WHERE c.asset_id=? AND c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND ${custodyScope.sql} ORDER BY c.opened_at DESC`)
    .all(context.nowIso,context.nowIso,assetId,...OPEN_CUSTODY_STATUSES,...custodyScope.params);
  const deliveryStats=db.prepare(`SELECT COUNT(DISTINCT h.id) AS deliveries,SUM(hi.quantity) AS quantity
    FROM handover_item hi JOIN handover h ON h.id=hi.handover_id JOIN request r ON r.id=h.request_id
    WHERE hi.asset_id=? AND h.type='ENTREGA' AND h.occurred_at>=? AND h.occurred_at<? AND ${custodyScope.sql}`)
    .get(assetId,context.period.startUtc,context.period.endUtc,...custodyScope.params);
  const returnStats=db.prepare(`SELECT COUNT(*) AS total,SUM(CASE WHEN crr.timing_status='EN_TERMINO' THEN 1 ELSE 0 END) AS on_time,
      SUM(CASE WHEN crr.condition<>'CONFORME' THEN 1 ELSE 0 END) AS issues
    FROM custody_return_record crr JOIN custody c ON c.id=crr.custody_id JOIN request r ON r.id=c.request_id
    WHERE c.asset_id=? AND crr.received_at>=? AND crr.received_at<? AND ${custodyScope.sql}`)
    .get(assetId,context.period.startUtc,context.period.endUtc,...custodyScope.params);
  const incidentStats=db.prepare(`SELECT COUNT(*) AS total,SUM(CASE WHEN i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)}) THEN 1 ELSE 0 END) AS open,
      SUM(COALESCE(i.actual_cost,i.estimated_cost,0)) AS cost FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE i.asset_id=? AND i.detected_at>=? AND i.detected_at<? AND ${assetScope.sql}`)
    .get(...OPEN_INCIDENT_STATUSES,assetId,context.period.startUtc,context.period.endUtc,...assetScope.params);
  const maintenanceStats=db.prepare(`SELECT COUNT(*) AS total,SUM(CASE WHEN mo.status='COMPLETADA' THEN 1 ELSE 0 END) AS completed,
      SUM(CASE WHEN mo.status='VENCIDA' OR (mo.status IN ('PROGRAMADA','EN_PROGRESO') AND mo.due_at IS NOT NULL AND mo.due_at<?) THEN 1 ELSE 0 END) AS overdue,
      SUM(CASE WHEN mo.status='COMPLETADA' AND mo.due_at IS NOT NULL AND mo.completed_at<=mo.due_at THEN 1 ELSE 0 END) AS on_time
    FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE mo.asset_id=? AND mo.created_at>=? AND mo.created_at<? AND ${assetScope.sql}`)
    .get(context.nowIso,assetId,context.period.startUtc,context.period.endUtc,...assetScope.params);
  const incidents=db.prepare(`SELECT i.incident_number,i.title,i.type,i.severity,i.status,i.detected_at,i.resolved_at,i.estimated_cost,i.actual_cost
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE i.asset_id=? AND ${assetScope.sql}
    ORDER BY i.detected_at DESC LIMIT 30`).all(assetId,...assetScope.params);
  const maintenance=db.prepare(`SELECT mo.order_number,mo.maintenance_type,mo.priority,mo.status,mo.scheduled_at,mo.due_at,mo.completed_at,mo.result
    FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE mo.asset_id=? AND ${assetScope.sql}
    ORDER BY mo.created_at DESC LIMIT 30`).all(assetId,...assetScope.params);
  const economicCosts=context.view.showCosts?db.prepare(`SELECT c.occurred_on,c.description,c.cost_type,c.currency_code,
      (c.sign*c.amount_minor)/(CASE cur.minor_units WHEN 0 THEN 1 WHEN 1 THEN 10 WHEN 2 THEN 100 WHEN 3 THEN 1000 ELSE 100 END) AS amount,
      c.provider,c.document_reference,c.status
    FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code
    WHERE c.asset_id=? AND c.status IN ('EJECUTADO','REVERSADO') ORDER BY c.occurred_on DESC,c.created_at DESC LIMIT 60`).all(assetId):[];
  const economicTotals=context.view.showCosts?db.prepare(`SELECT c.currency_code,cur.minor_units,SUM(c.sign*c.amount_minor) AS amount_minor,
      SUM(CASE WHEN c.cost_type IN ('REPARACION','MANTENIMIENTO','REPUESTOS','SERVICIO_EXTERNO') THEN c.sign*c.amount_minor ELSE 0 END) AS repair_minor,
      COUNT(CASE WHEN c.entry_kind<>'REVERSA' AND c.cost_type IN ('REPARACION','MANTENIMIENTO') THEN 1 END) AS interventions
    FROM economic_cost_record c JOIN economic_currency cur ON cur.code=c.currency_code
    WHERE c.asset_id=? AND c.status IN ('EJECUTADO','REVERSADO') GROUP BY c.currency_code,cur.minor_units ORDER BY c.currency_code`).all(assetId):[];
  const economicProfile=context.view.showCosts?db.prepare(`SELECT aep.*,cur.minor_units FROM asset_economic_profile aep LEFT JOIN economic_currency cur ON cur.code=aep.currency_code WHERE aep.asset_id=?`).get(assetId):null;
  const custodyHistory=db.prepare(`SELECT p.full_name,p.sector,c.opened_at,c.due_at,c.closed_at,c.status,crr.timing_status,crr.condition
    FROM custody c JOIN request r ON r.id=c.request_id JOIN person p ON p.id=c.person_id LEFT JOIN custody_return_record crr ON crr.custody_id=c.id
    WHERE c.asset_id=? AND ${custodyScope.sql} ORDER BY c.opened_at DESC LIMIT 40`).all(assetId,...custodyScope.params);
  const overlapHours=custodyOverlapHours(db,assetId,context.period,context.scope);
  const periodHours=Math.max(1,(new Date(context.period.endUtc)-new Date(context.period.startUtc))/3600000);
  const utilizationPercent=asset.serialized||asset.requires_return?round(Math.min(100,overlapHours/periodHours*100)):null;
  const returnsTotal=Number(returnStats.total||0),onTime=Number(returnStats.on_time||0),issues=Number(returnStats.issues||0),incidentTotal=Number(incidentStats.total||0);
  const summary=[
    summaryItem('STATUS','Estado actual',asset.status,'TEXT',['BLOQUEADO','PERDIDO'].includes(asset.status)?'danger':['MANTENIMIENTO','EN_CUSTODIA'].includes(asset.status)?'warn':'ok'),
    summaryItem('DELIVERIES','Entregas del período',Number(deliveryStats.deliveries||0)),summaryItem('QUANTITY','Cantidad entregada',round(deliveryStats.quantity||0)),
    summaryItem('USE_HOURS','Horas en uso',overlapHours,'HOURS'),summaryItem('UTILIZATION','Utilización del período',utilizationPercent,'PERCENT',utilizationPercent!==null&&utilizationPercent>85?'warn':'neutral'),
    summaryItem('RETURN_COMPLIANCE','Devoluciones a tiempo',percent(onTime,returnsTotal),'PERCENT',returnsTotal&&onTime<returnsTotal?'warn':returnsTotal?'ok':'neutral'),
    summaryItem('RETURN_ISSUES','Devoluciones con problemas',issues,'COUNT',issues?'danger':'ok'),
    summaryItem('INCIDENTS','Problemas registrados',incidentTotal,'COUNT',Number(incidentStats.open||0)?'danger':incidentTotal>=2?'warn':'ok'),
    summaryItem('MAINTENANCE_OVERDUE','Mantenimientos atrasados',Number(maintenanceStats.overdue||0),'COUNT',Number(maintenanceStats.overdue||0)?'danger':'ok')
  ];
  if(context.view.showCosts) {
    summary.push(summaryItem('INCIDENT_COST','Costo registrado en problemas',round(incidentStats.cost || 0),'CURRENCY',Number(incidentStats.cost || 0)?'warn':'neutral','Solo costos registrados en incidentes.'));
    if(economicProfile?.currency_code) {
      const divisor=10**Number(economicProfile.minor_units||0);
      summary.push(summaryItem('ACQUISITION_VALUE','Valor de adquisición',economicProfile.acquisition_amount_minor===null?'Sin dato':`${round(Number(economicProfile.acquisition_amount_minor)/divisor)} ${economicProfile.currency_code}`,'TEXT','neutral'));
      summary.push(summaryItem('REPLACEMENT_VALUE','Valor de reposición',economicProfile.replacement_amount_minor===null?'Sin dato':`${round(Number(economicProfile.replacement_amount_minor)/divisor)} ${economicProfile.currency_code}`,'TEXT','neutral'));
    }
    for(const total of economicTotals){const divisor=10**Number(total.minor_units||0);summary.push(summaryItem(`ECONOMIC_COST_${total.currency_code}`,`Costo acumulado ${total.currency_code}`,`${round(Number(total.amount_minor||0)/divisor)} ${total.currency_code}`,'TEXT',Number(total.amount_minor||0)?'warn':'neutral',`${Number(total.interventions||0)} intervenciones de reparación o mantenimiento.`));}
  }
  return {type:'ASSET',id:asset.id,title:`${asset.internal_code} · ${asset.description}`,subtitle:[asset.category_name,asset.brand,asset.model,asset.location_name].filter(Boolean).join(' · '),status:asset.status,period:context.period,scope:context.scope,view:context.view,costCoverage:context.view.showCosts?'ECONOMIC_COMPLETE':'HIDDEN',summary,
    current:{custodian:currentCustodies.map((row)=>row.full_name).join(', ')||null,location:asset.location_name,site:asset.site_name,serialNumber:asset.serial_number,category:asset.category_name},
    sections:[
      {code:'CURRENT_CUSTODY',title:'Quién la tiene ahora',empty:'La herramienta no está entregada.',columns:[['full_name','Persona'],['sector','Sector'],['opened_at','Entregada'],['due_at','Devolver'],['status','Estado'],['overdue_days','Días de atraso']],rows:currentCustodies},
      {code:'HISTORY',title:'Historial de uso',empty:'No hay custodias registradas.',columns:[['full_name','Persona'],['sector','Sector'],['opened_at','Entrega'],['closed_at','Devolución'],['timing_status','Plazo'],['condition','Condición']],rows:custodyHistory},
      {code:'INCIDENTS',title:'Problemas de la herramienta',empty:'No hay problemas registrados.',
        columns:[['incident_number','N.º'],['title','Problema'],['severity','Gravedad'],['status','Estado'],['detected_at','Fecha']],
        rows:incidents.map(({estimated_cost,actual_cost,...row})=>row)},
      {code:'MAINTENANCE',title:'Mantenimiento',empty:'No hay órdenes de mantenimiento.',columns:[['order_number','Orden'],['maintenance_type','Tipo'],['priority','Prioridad'],['status','Estado'],['due_at','Vence'],['completed_at','Terminada'],['result','Resultado']],rows:maintenance},
      ...(context.view.showCosts?[{code:'ECONOMIC_COSTS',title:'Costos económicos de la herramienta',empty:'No hay costos económicos vinculados.',columns:[['occurred_on','Fecha'],['description','Descripción'],['cost_type','Tipo'],['currency_code','Moneda'],['amount','Importe'],['provider','Proveedor'],['status','Estado']],rows:economicCosts}]:[])
    ]};
}
function getManagementProfile(user,input={},options={}){
  const db=options.db||getDb();const context=profileContext(user,input,db,options);const type=normalizeType(input.type);
  if(type==='PERSON'){if(!input.id)throw profileError('Debe indicar la persona.','MANAGEMENT_PROFILE_ID_REQUIRED');return personProfile(db,String(input.id),context);}
  if(type==='SECTOR'){const sector=String(input.id||input.sector||'').trim();if(!sector)throw profileError('Debe indicar el sector.','MANAGEMENT_PROFILE_ID_REQUIRED');return sectorProfile(db,sector,context);}
  if(!input.id)throw profileError('Debe indicar la herramienta.','MANAGEMENT_PROFILE_ID_REQUIRED');return assetProfile(db,String(input.id),context);
}

module.exports={ENTITY_TYPES,listManagementEntities,getManagementProfile};
