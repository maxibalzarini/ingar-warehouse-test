'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { DEFAULT_SETTINGS } = require('../config/catalogs');
const { appendAudit } = require('./audit-service');

function seedSettings(db = getDb()) {
  const now = new Date().toISOString();
  const stmt = db.prepare(`INSERT OR IGNORE INTO system_setting(
    id, scope_type, scope_id, key, value_json, version, updated_by, created_at, updated_at
  ) VALUES (?, 'SYSTEM', 'GLOBAL', ?, ?, 1, NULL, ?, ?)`);
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    stmt.run(randomUUID(), key, JSON.stringify(value), now, now);
  }
}

function normalizeStoredSetting(key, value) {
  // FIRMA fue configurable históricamente, pero la UI actual de entrega no la implementa.
  // Bases antiguas deben continuar operando como confirmación explícita sin romper Configuración.
  if (key === 'custody.acceptanceMethod' && value === 'FIRMA') return 'EXPLICITA';
  return value;
}

function settingsFromDb(db) {
  seedSettings(db);
  const rows = db.prepare("SELECT key, value_json, version, updated_at FROM system_setting WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' ORDER BY key").all();
  return Object.fromEntries(rows.map((row) => [row.key, { value: normalizeStoredSetting(row.key, JSON.parse(row.value_json)), version: row.version, updatedAt: row.updated_at }]));
}

function listSettings() {
  return settingsFromDb(getDb());
}

function getSetting(key, fallback = undefined) {
  seedSettings();
  const row = getDb().prepare("SELECT value_json FROM system_setting WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' AND key = ?").get(key);
  return row ? normalizeStoredSetting(key, JSON.parse(row.value_json)) : fallback;
}

function validateSettingValue(key, value) {
  const numericRanges = {
    'security.sessionSeconds': [300, 2592000],
    'security.rememberSessionSeconds': [3600, 31536000],
    'security.maxFailedAttempts': [2, 20],
    'security.lockMinutes': [1, 1440],
    'security.passwordMinLength': [4, 8],
    'security.operationalCredentialMinLength': [4, 8],
    'security.operationalCredentialMaxLength': [4, 8],
    'security.tabletSessionSeconds': [300, 3600],
    'security.tabletIdleSeconds': [60, 900],
    'backup.intervalHours': [1, 720],
    'backup.rotationCount': [1, 365],
    'request.defaultReservationHours': [1, 8760],
    'request.maxItems': [1, 100],
    'custody.defaultDurationHours': [1, 8760],
    'block.defaultExceptionHours': [1, 720],
    'maintenance.schedulerIntervalSeconds': [60, 86400],
    'maintenance.defaultLeadDays': [0, 3650],
    'notification.retentionDays': [1, 3650],
    'notification.custodyOverdueMinutes': [0, 43200],
    'notification.custodyDueSoonMinutes': [0, 43200],
    'audit.retentionDays': [30, 3650],
    'audit.maxLiveEvents': [1000, 5000000],
    'audit.minimumLiveEvents': [100, 100000],
    'audit.archiveBatchSize': [100, 25000],
    'audit.maxSegmentsPerRun': [1, 100],
    'offline.maxDraftAgeHours': [1, 720],
    'economic.priceStaleDays': [1, 3650],
    'economic.repairReviewRatio': [0.01, 10],
    'economic.replaceReviewRatio': [0.01, 10]
  };
  const booleanKeys = new Set(['backup.enabled', 'mail.enabled', 'policy.segregationOfDuties', 'custody.blockOnObservation', 'incident.requireIndependentClosure', 'incident.autoBlockCustodianOnCritical', 'maintenance.blockWhenOverdue', 'vehicle.requireDriverAuthorization', 'vehicle.requireChecklist', 'kit.allowIncompleteByDefault', 'stock.allowConsumableReturn', 'inventory.requireIndependentClose', 'transfer.requireDistinctReceiver', 'scheduler.enabled', 'offline.enabled']);
  if (numericRanges[key]) {
    const [minimum, maximum] = numericRanges[key];
    if (!Number.isFinite(value) || value < minimum || value > maximum) throw Object.assign(new Error(`Valor fuera de rango para ${key}.`), { status: 422, code: 'SETTING_VALUE_INVALID' });
    if (key === 'economic.repairReviewRatio' || key === 'economic.replaceReviewRatio') return Math.round(value * 1000000) / 1000000;
    return Math.round(value);
  }
  if (booleanKeys.has(key)) {
    if (typeof value !== 'boolean') throw Object.assign(new Error(`Valor booleano requerido para ${key}.`), { status: 422, code: 'SETTING_VALUE_INVALID' });
    return value;
  }
  if (key === 'locale.currency') {
    const code = String(value || '').trim().toUpperCase();
    if (!/^[A-Z]{3}$/.test(code)) throw Object.assign(new Error('Moneda inválida. Use un código ISO de 3 letras, por ejemplo ARS, USD o EUR.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
    return code;
  }
  if (key === 'locale.timezone') {
    if (typeof value !== 'string' || !value.trim() || value.length > 80) throw Object.assign(new Error('Zona horaria inválida.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
    const candidate = value.trim();
    try { new Intl.DateTimeFormat('es-AR', { timeZone: candidate }).format(new Date()); }
    catch { throw Object.assign(new Error('Zona horaria inválida. Use un identificador IANA, por ejemplo America/Argentina/Buenos_Aires.'), { status: 422, code: 'SETTING_VALUE_INVALID' }); }
    return candidate;
  }
  if (key === 'economic.stockValuationMethod') {
    if (value !== 'LOTE') throw Object.assign(new Error('Método de valorización inválido.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
    return value;
  }
  if (key === 'custody.acceptanceMethod' && !['EXPLICITA', 'PIN'].includes(value)) throw Object.assign(new Error('Método de aceptación inválido.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
  if (key === 'qr.baseUrl' && value) {
    let parsed; try { parsed = new URL(value); } catch { throw Object.assign(new Error('URL base del QR inválida.'), { status: 422, code: 'SETTING_VALUE_INVALID' }); }
    if (parsed.protocol !== 'http:' || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) throw Object.assign(new Error('La URL base del QR debe contener únicamente protocolo, host y puerto.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
    const hostname = String(parsed.hostname || '').replace(/^\[|\]$/g, '').toLowerCase();
    if (['localhost', '127.0.0.1', '0.0.0.0', '::1', '::'].includes(hostname)) throw Object.assign(new Error('La URL base del QR debe ser accesible desde otros dispositivos de la red.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
    return parsed.origin;
  }
  if (value !== null && (typeof value !== 'string' || value.length > 500)) throw Object.assign(new Error(`Texto inválido para ${key}.`), { status: 422, code: 'SETTING_VALUE_INVALID' });
  return value;
}

function updateSettingsInDb(changes, context, db) {
  if (!changes || typeof changes !== 'object' || Array.isArray(changes)) throw Object.assign(new Error('Configuración inválida.'), { status: 422, code: 'SETTINGS_INVALID' });
  const allowed = new Set(Object.keys(DEFAULT_SETTINGS));
  const invalid = Object.keys(changes).filter((key) => !allowed.has(key));
  if (invalid.length) {
    const error = new Error(`Claves de configuración no permitidas: ${invalid.join(', ')}`);
    error.status = 422;
    error.code = 'SETTING_KEY_NOT_ALLOWED';
    throw error;
  }
  seedSettings(db);
  const currentOperationalMin = Number(JSON.parse(db.prepare("SELECT value_json FROM system_setting WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' AND key = 'security.operationalCredentialMinLength'").get()?.value_json || '4'));
  const currentOperationalMax = Number(JSON.parse(db.prepare("SELECT value_json FROM system_setting WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' AND key = 'security.operationalCredentialMaxLength'").get()?.value_json || '8'));
  const candidateOperationalMin = Object.prototype.hasOwnProperty.call(changes, 'security.operationalCredentialMinLength')
    ? validateSettingValue('security.operationalCredentialMinLength', changes['security.operationalCredentialMinLength'])
    : currentOperationalMin;
  const candidateOperationalMax = Object.prototype.hasOwnProperty.call(changes, 'security.operationalCredentialMaxLength')
    ? validateSettingValue('security.operationalCredentialMaxLength', changes['security.operationalCredentialMaxLength'])
    : currentOperationalMax;
  if (candidateOperationalMin > candidateOperationalMax) {
    throw Object.assign(new Error('La longitud mínima de la clave operativa no puede superar la máxima.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
  }
  const currentRepairReviewRatio = Number(JSON.parse(db.prepare("SELECT value_json FROM system_setting WHERE scope_type='SYSTEM' AND scope_id='GLOBAL' AND key='economic.repairReviewRatio'").get()?.value_json || '0.5'));
  const currentReplaceReviewRatio = Number(JSON.parse(db.prepare("SELECT value_json FROM system_setting WHERE scope_type='SYSTEM' AND scope_id='GLOBAL' AND key='economic.replaceReviewRatio'").get()?.value_json || '0.8'));
  const candidateRepairReviewRatio = Object.prototype.hasOwnProperty.call(changes, 'economic.repairReviewRatio') ? validateSettingValue('economic.repairReviewRatio', changes['economic.repairReviewRatio']) : currentRepairReviewRatio;
  const candidateReplaceReviewRatio = Object.prototype.hasOwnProperty.call(changes, 'economic.replaceReviewRatio') ? validateSettingValue('economic.replaceReviewRatio', changes['economic.replaceReviewRatio']) : currentReplaceReviewRatio;
  if (candidateRepairReviewRatio >= candidateReplaceReviewRatio) {
    throw Object.assign(new Error('El umbral de revisión de reparación debe ser menor que el umbral de evaluación de reemplazo.'), { status: 422, code: 'SETTING_VALUE_INVALID' });
  }
  const before = {};
  const after = {};
  const now = new Date().toISOString();
  for (const [key, rawValue] of Object.entries(changes)) {
    const value = validateSettingValue(key, rawValue);
    const current = db.prepare("SELECT id, value_json, version FROM system_setting WHERE scope_type = 'SYSTEM' AND scope_id = 'GLOBAL' AND key = ?").get(key);
    before[key] = JSON.parse(current.value_json);
    after[key] = value;
    db.prepare('UPDATE system_setting SET value_json = ?, version = version + 1, updated_by = ?, updated_at = ? WHERE id = ?')
      .run(JSON.stringify(value), context.user.id, now, current.id);
    if (key === 'organization.name') {
      const organizations = db.prepare('SELECT id, name FROM organization WHERE active=1 ORDER BY created_at').all();
      if (organizations.length === 1 && organizations[0].name !== value) {
        db.prepare('UPDATE organization SET name=?, version=version+1, updated_at=? WHERE id=?')
          .run(value || 'Organización', now, organizations[0].id);
      }
    }
    if (key === 'locale.currency') {
      const currencyTable = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='economic_currency'").get();
      if (currencyTable && !db.prepare('SELECT 1 FROM economic_currency WHERE code=? AND active=1').get(value)) {
        throw Object.assign(new Error(`La moneda ${value} no está habilitada en Finanzas.`), { status: 422, code: 'SETTING_VALUE_INVALID' });
      }
    }
    if (key === 'locale.timezone') {
      const organizations = db.prepare('SELECT id, timezone FROM organization WHERE active=1 ORDER BY created_at').all();
      if (organizations.length === 1 && organizations[0].timezone !== value) {
        db.prepare('UPDATE organization SET timezone=?, version=version+1, updated_at=? WHERE id=?')
          .run(value, now, organizations[0].id);
      }
    }
    if (key === 'maintenance.schedulerIntervalSeconds' && db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='scheduler_job'").get()) {
      db.prepare("UPDATE scheduler_job SET interval_seconds=?,next_run_at=?,version=version+1,updated_at=? WHERE code='MAINTENANCE_SCAN'")
        .run(value, new Date(Date.now() + value * 1000).toISOString(), now);
    }
  }
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action: 'CONFIG.UPDATE', entityType: 'system_setting', entityId: 'SYSTEM',
    before, after, correlationId: context.correlationId, ipAddress: context.ip,
    equipment: context.userAgent, result: 'SUCCESS'
  }, db);
  return settingsFromDb(db);
}

function updateSettings(changes, context) {
  return transaction((db) => updateSettingsInDb(changes, context, db));
}

module.exports = { seedSettings, listSettings, getSetting, updateSettings, updateSettingsInDb, validateSettingValue };
