'use strict';

function operationalError(status, code, message, details = null) {
  return Object.assign(new Error(message), { status, code, details });
}

function loadKitDefinition(db, kitAssetId) {
  const asset = db.prepare(`SELECT a.id,a.internal_code,a.description,a.active,a.status,a.quantity_available,c.nature AS category_nature
    FROM asset a JOIN asset_category c ON c.id=a.category_id
    WHERE a.id=? AND a.deleted_at IS NULL AND c.deleted_at IS NULL`).get(kitAssetId);
  if (!asset) throw operationalError(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  if (asset.category_nature !== 'KIT') throw operationalError(422, 'ASSET_NATURE_INVALID', 'La naturaleza del bien no corresponde a un kit.');
  const definition = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(kitAssetId);
  if (!definition) throw operationalError(409, 'KIT_DEFINITION_MISSING', 'Integridad inválida: el kit no posee definición.');
  const components = db.prepare(`SELECT kc.*,a.internal_code,a.description,a.active AS asset_active,a.status,a.quantity_available,a.deleted_at,
      c.nature AS component_nature,c.active AS category_active,c.deleted_at AS category_deleted_at
    FROM kit_component kc
    JOIN asset a ON a.id=kc.component_asset_id
    JOIN asset_category c ON c.id=a.category_id
    WHERE kc.kit_asset_id=? AND kc.active=1
    ORDER BY kc.sequence,a.internal_code`).all(kitAssetId);
  return { asset, definition, components };
}

function componentBaseAvailability(component) {
  const reasons = [];
  if (component.deleted_at || !component.asset_active) reasons.push('INACTIVO');
  if (component.category_deleted_at || !component.category_active) reasons.push('CATEGORIA_INACTIVA');
  if (component.status !== 'DISPONIBLE') reasons.push(`ESTADO_${component.status || 'DESCONOCIDO'}`);
  if (Number(component.quantity_available) < Number(component.required_quantity)) reasons.push('CANTIDAD_INSUFICIENTE');
  return reasons;
}

function cycleStatus(kitAssetId) {
  const issue = { component_asset_id: kitAssetId, internal_code: kitAssetId, mandatory: true, reasons: ['CICLO_DE_KITS'] };
  return {
    kitAssetId,
    configured: false,
    complete: false,
    available: false,
    components: [],
    missing: [issue],
    issues: [issue]
  };
}

function evaluateKitOperationalStatus(db, kitAssetId, context) {
  if (context.ancestry.has(kitAssetId)) return cycleStatus(kitAssetId);
  const ancestry = new Set(context.ancestry);
  ancestry.add(kitAssetId);
  const data = loadKitDefinition(db, kitAssetId);
  const evaluated = data.components.map((component) => {
    const reasons = componentBaseAvailability(component);
    if (context.seenAssets.has(component.component_asset_id)) reasons.push('COMPONENTE_REPETIDO_EN_JERARQUIA');
    else context.seenAssets.add(component.component_asset_id);
    let nested = null;
    if (!reasons.length && component.component_nature === 'KIT') {
      nested = evaluateKitOperationalStatus(db, component.component_asset_id, {
        ancestry,
        seenAssets: context.seenAssets
      });
      if (!nested.complete) reasons.push('KIT_ANIDADO_INCOMPLETO');
    }
    return {
      ...component,
      mandatory: Boolean(component.mandatory),
      allow_substitution: Boolean(component.allow_substitution),
      operationally_available: reasons.length === 0,
      reasons,
      nested
    };
  });
  const configured = evaluated.length > 0;
  const missing = evaluated.filter((component) => component.mandatory && !component.operationally_available);
  const localIssues = evaluated.filter((component) => component.reasons.includes('COMPONENTE_REPETIDO_EN_JERARQUIA'));
  const nestedIssues = evaluated.flatMap((component) => component.nested?.issues || []);
  const issues = [...localIssues, ...nestedIssues];
  const complete = configured && missing.length === 0 && issues.length === 0;
  return {
    kitAssetId,
    asset: data.asset,
    definition: data.definition,
    configured,
    complete,
    available: complete,
    components: evaluated,
    missing,
    issues
  };
}


function assertKitComponentHierarchyUnique(db, componentAssetIds, rootKitId = null) {
  const seenAssets = new Set();
  const rootAncestry = new Set(rootKitId ? [rootKitId] : []);

  function visit(assetId, ancestry) {
    if (ancestry.has(assetId)) throw operationalError(422, 'KIT_CYCLE', 'La composición genera un ciclo de kits.');
    if (seenAssets.has(assetId)) throw operationalError(422, 'KIT_COMPONENT_HIERARCHY_DUPLICATE', 'Un mismo bien no puede aparecer más de una vez dentro de la jerarquía del kit.');
    seenAssets.add(assetId);
    const asset = db.prepare(`SELECT a.id,c.nature AS category_nature FROM asset a JOIN asset_category c ON c.id=a.category_id
      WHERE a.id=? AND a.deleted_at IS NULL AND c.deleted_at IS NULL`).get(assetId);
    if (!asset) throw operationalError(422, 'KIT_COMPONENT_NOT_FOUND', 'Uno de los componentes de la jerarquía no existe.');
    if (asset.category_nature !== 'KIT') return;
    const nextAncestry = new Set(ancestry);
    nextAncestry.add(assetId);
    const children = db.prepare('SELECT component_asset_id FROM kit_component WHERE kit_asset_id=? AND active=1 ORDER BY sequence,id').all(assetId);
    for (const child of children) visit(child.component_asset_id, nextAncestry);
  }

  for (const assetId of componentAssetIds) visit(assetId, rootAncestry);
  return true;
}

function getKitOperationalStatus(db, kitAssetId) {
  return evaluateKitOperationalStatus(db, kitAssetId, { ancestry: new Set(), seenAssets: new Set() });
}

function assertKitOperationallyComplete(db, kitAssetId, operation = 'operación') {
  const status = getKitOperationalStatus(db, kitAssetId);
  if (!status.configured) {
    throw operationalError(409, 'KIT_NOT_CONFIGURED', `El kit ${status.asset?.internal_code || kitAssetId} no posee composición y no puede continuar con la ${operation}.`, status);
  }
  if (!status.complete) {
    const codes = [...status.missing, ...(status.issues || [])]
      .map((item) => item.internal_code || item.component_asset_id)
      .filter(Boolean);
    const uniqueCodes = [...new Set(codes)].join(', ');
    throw operationalError(409, 'KIT_INCOMPLETE_OPERATION_BLOCKED', `El kit ${status.asset?.internal_code || kitAssetId} está incompleto y no puede continuar con la ${operation}${uniqueCodes ? `: ${uniqueCodes}` : ''}.`, status);
  }
  return status;
}

module.exports = { getKitOperationalStatus, assertKitOperationallyComplete, assertKitComponentHierarchyUnique };
