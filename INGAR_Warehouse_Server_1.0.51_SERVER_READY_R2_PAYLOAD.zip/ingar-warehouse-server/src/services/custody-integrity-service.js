'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { appendAudit } = require('./audit-service');
const { userHasScope } = require('../security/scope');
const { enqueueNotification } = require('./notification-service');
const { warehouseOperatorsForScope, syncCustodyOperationalAlerts } = require('./custody-alert-service');

const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);

function anomalyKey(type, ...parts) { return [type, ...parts.filter(Boolean)].join(':'); }

function upsertAnomaly(db, input) {
  const now = new Date().toISOString();
  const existing = db.prepare('SELECT * FROM custody_integrity_anomaly WHERE anomaly_key=?').get(input.key);
  const details = JSON.stringify(input.details || {});
  if (existing) {
    db.prepare(`UPDATE custody_integrity_anomaly SET anomaly_type=?,status=?,request_id=?,request_item_id=?,custody_id=?,handover_id=?,asset_id=?,site_id=?,location_id=?,details_json=?,resolved_at=?,resolution=?,version=version+1,updated_at=? WHERE id=?`)
      .run(input.type, input.status, input.requestId || null, input.requestItemId || null, input.custodyId || null, input.handoverId || null,
        input.assetId || null, input.siteId || null, input.locationId || null, details,
        input.status === 'REPARADA' || input.status === 'DESCARTADA' ? now : null, input.resolution || null, now, existing.id);
    return db.prepare('SELECT * FROM custody_integrity_anomaly WHERE id=?').get(existing.id);
  }
  const id = randomUUID();
  db.prepare(`INSERT INTO custody_integrity_anomaly(id,anomaly_key,anomaly_type,status,request_id,request_item_id,custody_id,handover_id,asset_id,site_id,location_id,details_json,detected_at,resolved_at,resolution,version,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)`)
    .run(id, input.key, input.type, input.status, input.requestId || null, input.requestItemId || null, input.custodyId || null,
      input.handoverId || null, input.assetId || null, input.siteId || null, input.locationId || null, details, now,
      input.status === 'REPARADA' || input.status === 'DESCARTADA' ? now : null, input.resolution || null, now, now);
  return db.prepare('SELECT * FROM custody_integrity_anomaly WHERE id=?').get(id);
}

function notifyAnomaly(db, anomaly, message) {
  if (!anomaly.site_id || !anomaly.location_id) return 0;
  const operators = warehouseOperatorsForScope(db, anomaly.site_id, anomaly.location_id);
  let generated = 0;
  for (const operator of operators) {
    const result = enqueueNotification({
      recipientUserId: operator.id,
      recipientPersonId: operator.person_id,
      type: 'CUSTODIA_ANOMALIA',
      subject: 'Anomalía de devolución pendiente de revisión',
      body: message,
      entityType: 'custody_integrity_anomaly',
      entityId: anomaly.id,
      dedupKey: `custody-anomaly:${anomaly.anomaly_key}:${operator.id}`,
      reactivateCancelled: true
    }, db);
    if (!result.idempotent) generated += 1;
  }
  return generated;
}

function markAnomalyNotificationResolved(db, anomaly) {
  const now = new Date().toISOString();
  db.prepare(`UPDATE notification SET status='CANCELADA',updated_at=? WHERE entity_type='custody_integrity_anomaly' AND entity_id=? AND status IN ('PENDIENTE','ENVIADA','LEIDA','FALLIDA')`)
    .run(now, anomaly.id);
}

function eligibleMissingCustodies(db) {
  return db.prepare(`SELECT r.id AS request_id,r.request_number,r.requester_person_id,r.due_at,
      ri.id AS request_item_id,ri.quantity AS requested_quantity,
      h.id AS handover_id,h.person_id AS handover_person_id,h.occurred_at AS handover_at,
      hi.asset_id AS handed_asset_id,hi.quantity AS handed_quantity,
      a.internal_code,a.description,ac.nature AS category_nature,ac.requires_return,
      sl.id AS location_id,sl.site_id
    FROM request r
    JOIN request_item ri ON ri.request_id=r.id
    LEFT JOIN handover h ON h.id=(SELECT h2.id FROM handover h2 WHERE h2.request_id=r.id AND h2.type='ENTREGA' ORDER BY h2.occurred_at DESC LIMIT 1)
    LEFT JOIN handover_item hi ON hi.handover_id=h.id AND hi.request_item_id=ri.id
    LEFT JOIN asset a ON a.id=COALESCE(hi.asset_id,ri.asset_id)
    LEFT JOIN asset_category ac ON ac.id=a.category_id
    LEFT JOIN storage_location sl ON sl.id=a.location_id
    LEFT JOIN custody c ON c.request_item_id=ri.id
    WHERE r.status='ENTREGADA' AND ac.requires_return=1 AND c.id IS NULL
    ORDER BY r.created_at,ri.created_at`).all();
}

function repairMissingCustody(db, row, context) {
  const key = anomalyKey('ENTREGA_RETORNABLE_SIN_CUSTODIA', row.request_item_id);
  const missing = [];
  if (!row.handover_id) missing.push('handover');
  if (!row.handed_asset_id) missing.push('handover_item');
  if (!row.handover_person_id) missing.push('custodio');
  if (!row.handover_at) missing.push('fecha_entrega');
  if (!row.due_at) missing.push('fecha_vencimiento');
  if (!row.location_id || !row.site_id) missing.push('alcance');
  if (missing.length) {
    const anomaly = upsertAnomaly(db, {
      key, type: 'ENTREGA_RETORNABLE_SIN_CUSTODIA', status: 'REQUIERE_REVISION', requestId: row.request_id,
      requestItemId: row.request_item_id, handoverId: row.handover_id, assetId: row.handed_asset_id,
      siteId: row.site_id, locationId: row.location_id,
      details: { requestNumber: row.request_number, internalCode: row.internal_code, missing }
    });
    return { repaired: 0, review: 1, notified: notifyAnomaly(db, anomaly, `La solicitud ${row.request_number} contiene un bien retornable sin custodia y faltan datos: ${missing.join(', ')}.`) };
  }

  const now = new Date().toISOString();
  const custodyId = randomUUID();
  const quantity = Number(row.handed_quantity || row.requested_quantity);
  const exclusive = SERIAL_NATURES.has(row.category_nature) ? 1 : 0;
  db.prepare(`INSERT INTO custody(id,request_id,request_item_id,asset_id,person_id,quantity,exclusive_unit,opened_by_handover_id,opened_at,due_at,status,version,created_at,updated_at,work_order_reference_snapshot)
    VALUES (?,?,?,?,?,?,?,?,?,?,'ABIERTA',1,?,?,?)`)
    .run(custodyId, row.request_id, row.request_item_id, row.handed_asset_id, row.handover_person_id, quantity, exclusive,
      row.handover_id, row.handover_at, row.due_at, now, now, db.prepare('SELECT work_order_reference FROM request WHERE id=?').get(row.request_id)?.work_order_reference || null);
  db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
    VALUES (?,?,NULL,'ABIERTA',?,?,?,?,?)`)
    .run(randomUUID(), custodyId, context?.user?.id || null, 'Custodia reconstruida por control de integridad sobre entrega física existente.', now,
      context?.correlationId || `phase16-integrity:${custodyId}`, now);
  if (exclusive) {
    db.prepare(`UPDATE asset SET status=CASE WHEN status IN ('BLOQUEADO','PERDIDO','MANTENIMIENTO','BAJA') THEN status ELSE 'EN_CUSTODIA' END,
      custodian_person_id=?,quantity_available=CASE WHEN status IN ('BLOQUEADO','PERDIDO','MANTENIMIENTO','BAJA') THEN quantity_available ELSE 0 END,
      version=version+1,updated_at=? WHERE id=?`).run(row.handover_person_id, now, row.handed_asset_id);
  }
  const anomaly = upsertAnomaly(db, {
    key, type: 'ENTREGA_RETORNABLE_SIN_CUSTODIA', status: 'REPARADA', requestId: row.request_id,
    requestItemId: row.request_item_id, custodyId, handoverId: row.handover_id, assetId: row.handed_asset_id,
    siteId: row.site_id, locationId: row.location_id,
    details: { requestNumber: row.request_number, internalCode: row.internal_code },
    resolution: 'Custodia reconstruida usando solicitud, entrega y detalle físico existentes.'
  });
  markAnomalyNotificationResolved(db, anomaly);
  syncCustodyOperationalAlerts(db, custodyId);
  appendAudit({ actorUserId: context?.user?.id || null, actorRole: context?.user?.roleCodes?.join(',') || 'SYSTEM',
    action: 'CUSTODY.INTEGRITY_REPAIR', entityType: 'custody', entityId: custodyId,
    after: { requestId: row.request_id, requestItemId: row.request_item_id, handoverId: row.handover_id },
    correlationId: context?.correlationId || `phase16-integrity:${custodyId}`, source: context?.source || 'SCHEDULER',
    ipAddress: context?.ip || '127.0.0.1', equipment: context?.userAgent || 'IWC-CUSTODY-INTEGRITY' }, db);
  return { repaired: 1, review: 0, notified: 0 };
}

function detectExistingAnomalies(db) {
  const summary = { review: 0, notified: 0 };
  const noDue = db.prepare(`SELECT c.id AS custody_id,c.request_id,c.request_item_id,c.opened_by_handover_id AS handover_id,c.asset_id,
      a.internal_code,sl.id AS location_id,sl.site_id,r.request_number
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN storage_location sl ON sl.id=a.location_id JOIN request r ON r.id=c.request_id
    WHERE c.status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE') AND c.due_at IS NULL`).all();
  for (const row of noDue) {
    const anomaly = upsertAnomaly(db, {
      key: anomalyKey('CUSTODIA_SIN_VENCIMIENTO', row.custody_id), type: 'CUSTODIA_SIN_VENCIMIENTO', status: 'REQUIERE_REVISION',
      requestId: row.request_id, requestItemId: row.request_item_id, custodyId: row.custody_id, handoverId: row.handover_id,
      assetId: row.asset_id, siteId: row.site_id, locationId: row.location_id,
      details: { requestNumber: row.request_number, internalCode: row.internal_code }
    });
    summary.review += 1;
    summary.notified += notifyAnomaly(db, anomaly, `La custodia de ${row.internal_code}, solicitud ${row.request_number}, no tiene fecha de devolución.`);
  }
  const brokenHandover = db.prepare(`SELECT c.id AS custody_id,c.request_id,c.request_item_id,c.opened_by_handover_id AS handover_id,c.asset_id,
      a.internal_code,sl.id AS location_id,sl.site_id,r.request_number
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN storage_location sl ON sl.id=a.location_id JOIN request r ON r.id=c.request_id
    LEFT JOIN handover h ON h.id=c.opened_by_handover_id WHERE h.id IS NULL`).all();
  for (const row of brokenHandover) {
    const anomaly = upsertAnomaly(db, {
      key: anomalyKey('CUSTODIA_SIN_ENTREGA', row.custody_id), type: 'CUSTODIA_SIN_ENTREGA', status: 'REQUIERE_REVISION',
      requestId: row.request_id, requestItemId: row.request_item_id, custodyId: row.custody_id, handoverId: row.handover_id,
      assetId: row.asset_id, siteId: row.site_id, locationId: row.location_id,
      details: { requestNumber: row.request_number, internalCode: row.internal_code }
    });
    summary.review += 1;
    summary.notified += notifyAnomaly(db, anomaly, `La custodia de ${row.internal_code} no tiene una entrega física válida asociada.`);
  }
  return summary;
}

function reconcileCustodyIntegrity(db = getDb(), context = null) {
  const summary = { processed: 0, repaired: 0, reviewRequired: 0, notified: 0 };
  for (const row of eligibleMissingCustodies(db)) {
    if (context?.user && !userHasScope(context.user, row.site_id, row.location_id, 'Warehouse.Operate', db)) continue;
    summary.processed += 1;
    const result = repairMissingCustody(db, row, context);
    summary.repaired += result.repaired;
    summary.reviewRequired += result.review;
    summary.notified += result.notified;
  }
  const existing = detectExistingAnomalies(db);
  summary.reviewRequired += existing.review;
  summary.notified += existing.notified;
  return summary;
}

function runCustodyIntegrity(context = null) {
  return transaction((db) => reconcileCustodyIntegrity(db, context));
}

function listCustodyIntegrityAnomalies(filters = {}, user = null) {
  const where = [];
  const params = [];
  if (filters.status) { where.push('cia.status=?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.type) { where.push('cia.anomaly_type=?'); params.push(String(filters.type).toUpperCase()); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 200));
  const db = getDb();
  return db.prepare(`SELECT cia.*,r.request_number,a.internal_code,a.description,sl.name AS location_name,s.name AS site_name
    FROM custody_integrity_anomaly cia LEFT JOIN request r ON r.id=cia.request_id LEFT JOIN asset a ON a.id=cia.asset_id
    LEFT JOIN storage_location sl ON sl.id=cia.location_id LEFT JOIN site s ON s.id=cia.site_id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY CASE cia.status WHEN 'REQUIERE_REVISION' THEN 0 WHEN 'ABIERTA' THEN 1 ELSE 2 END,cia.detected_at DESC LIMIT ?`)
    .all(...params, limit)
    .filter((row) => !user || !row.site_id || userHasScope(user, row.site_id, row.location_id, 'Warehouse.Operate', db))
    .map((row) => ({ ...row, details: JSON.parse(row.details_json || '{}') }));
}

module.exports = { reconcileCustodyIntegrity, runCustodyIntegrity, listCustodyIntegrityAnomalies };
