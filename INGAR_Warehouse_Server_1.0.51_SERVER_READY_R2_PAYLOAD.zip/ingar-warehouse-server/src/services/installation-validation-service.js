'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const runtime = require('../config/runtime');
const { protectBuffer, readProtectedFile, atomicWrite } = require('../security/data-protection');
const { getNetworkStatus, isLocalMachineAddress } = require('./network-service');
const { svg } = require('./qr-code-service');

const PHASE = 'S7';
const EVIDENCE_SCHEMA = 'iwc-installation-validation-s7-v1';
const EVIDENCE_FILE = 'installation-validation-s7.iwcenc';
const EVIDENCE_PURPOSE = 'INSTALLATION_VALIDATION_S7';
const SESSION_TTL_MS = 15 * 60 * 1000;

let current = null;
let currentVersion = runtime.sourceVersion;
let currentInstallRoot = runtime.projectRoot;
let nowProvider = () => new Date();
let networkProvider = () => getNetworkStatus();
let localMachineAddressProvider = (address) => isLocalMachineAddress(address);
let dataDirProvider = () => runtime.evidenceDir;
let evidenceReadProvider = readPersistedEvidence;
let evidenceWriteProvider = persistEvidence;
let fingerprintProvider = readBuildFingerprint;
let tokenProvider = () => crypto.randomBytes(24).toString('base64url');
let challengeProvider = () => crypto.randomBytes(18).toString('base64url');
const events = new EventEmitter();

function error(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function nowDate() {
  return new Date(nowProvider());
}

function nowIso() {
  return nowDate().toISOString();
}

function normalizeRemoteAddress(value) {
  const address = String(value || '').trim().toLowerCase();
  return address.startsWith('::ffff:') ? address.slice(7) : address;
}

function isLoopback(value) {
  const address = normalizeRemoteAddress(value);
  return !address || address === '127.0.0.1' || address === '::1' || address === 'localhost';
}

function cleanText(value, maximum = 200) {
  return String(value || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, maximum) || null;
}

function boundedInteger(value, minimum, maximum) {
  const number = Number.parseInt(value, 10);
  return Number.isInteger(number) ? Math.min(maximum, Math.max(minimum, number)) : null;
}

function cleanDeviceEvidence(value) {
  const input = value && typeof value === 'object' ? value : {};
  return Object.freeze({
    screenWidth: boundedInteger(input.screenWidth, 0, 10000),
    screenHeight: boundedInteger(input.screenHeight, 0, 10000),
    viewportWidth: boundedInteger(input.viewportWidth, 0, 10000),
    viewportHeight: boundedInteger(input.viewportHeight, 0, 10000),
    maxTouchPoints: boundedInteger(input.maxTouchPoints, 0, 32) || 0,
    touchEvent: input.touchEvent === true,
    coarsePointer: input.coarsePointer === true,
    platform: cleanText(input.platform, 100),
    vendor: cleanText(input.vendor, 120),
    orientation: cleanText(input.orientation, 60)
  });
}

function classifyUserAgent(value) {
  const userAgent = cleanText(value, 300) || '';
  if (/android|iphone|ipad|ipod|windows phone|mobile/i.test(userAgent)) return 'MOBILE_LIKE';
  if (/windows nt|macintosh|x11|cros|linux x86_64/i.test(userAgent)) return 'DESKTOP_LIKE';
  return 'UNKNOWN';
}

function hasTouchSignals(evidence) {
  return Boolean(evidence && evidence.maxTouchPoints > 0 && (evidence.touchEvent || evidence.coarsePointer));
}

function classifyDevice(userAgent, evidence) {
  const userAgentClass = classifyUserAgent(userAgent);
  if (userAgentClass === 'MOBILE_LIKE') return userAgentClass;

  // Safari en iPad puede solicitar "sitio de escritorio" y presentarse como Macintosh.
  // Se acepta únicamente cuando además informa la plataforma Apple y señales táctiles
  // inequívocas; un portátil Windows táctil no puede reemplazar al celular de prueba.
  const platform = String(evidence?.platform || '').trim();
  if (/^(MacIntel|iPad)$/i.test(platform) && Number(evidence?.maxTouchPoints || 0) > 1 && hasTouchSignals(evidence)) {
    return 'MOBILE_LIKE';
  }
  return userAgentClass;
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left || ''), 'utf8');
  const b = Buffer.from(String(right || ''), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function hashValue(value) {
  return crypto.createHash('sha256').update(String(value || ''), 'utf8').digest('hex');
}

function readBuildFingerprint() {
  try {
    return fs.readFileSync(path.join(currentInstallRoot, 'BUILD_FINGERPRINT.txt'), 'utf8').trim() || null;
  } catch {
    return null;
  }
}

function evidencePath() {
  return path.join(dataDirProvider(), EVIDENCE_FILE);
}

function readPersistedEvidence() {
  const target = evidencePath();
  if (!fs.existsSync(target)) return null;
  const bytes = readProtectedFile(target, { purpose: EVIDENCE_PURPOSE });
  return JSON.parse(bytes.toString('utf8'));
}

function persistEvidence(payload) {
  const bytes = protectBuffer(Buffer.from(`${JSON.stringify(payload, null, 2)}\n`, 'utf8'), { purpose: EVIDENCE_PURPOSE });
  atomicWrite(evidencePath(), bytes);
  return { file: EVIDENCE_FILE, bytes: bytes.length };
}

function evidenceIsValid(evidence, fingerprint) {
  // S7 acredita la instalación física (PC + LAN + celular), no una versión de código.
  // S6 ya valida la integridad del build activo en cada arranque. Por eso una evidencia
  // S7 aprobada permanece válida entre actualizaciones del mismo Warehouse y sólo se
  // repite cuando el administrador inicia deliberadamente una nueva validación.
  // Se conservan applicationVersion/buildFingerprint como trazabilidad histórica.
  void fingerprint;
  return Boolean(
    evidence
    && evidence.schema === EVIDENCE_SCHEMA
    && evidence.phase === PHASE
    && evidence.result === 'PASSED'
    && evidence.checks
    && Object.values(evidence.checks).every((value) => value === true)
  );
}

function makeCheck(id, label, passed, detail) {
  return Object.freeze({ id, label, passed: Boolean(passed), detail: String(detail || ''), blocking: true });
}

function buildChecks(session) {
  const persisted = session.persistedEvidence === true;
  const secondDevice = persisted || Boolean(session.remoteAddress && !isLoopback(session.remoteAddress) && !localMachineAddressProvider(session.remoteAddress));
  const mobileSignals = persisted || (session.deviceClass === 'MOBILE_LIKE' && hasTouchSignals(session.deviceEvidence));
  return [
    makeCheck('S6_DEPLOYMENT_APPROVED', 'Despliegue automático S6', session.s6Approved, session.s6Approved ? 'Los controles locales del servidor están aprobados.' : 'S6 todavía no está aprobado.'),
    makeCheck('LAN_URL_READY', 'Dirección LAN del servidor', persisted || Boolean(session.networkBaseUrl), persisted ? 'Dirección LAN verificada en la aceptación S7 guardada.' : (session.networkBaseUrl ? `${session.networkBaseUrl}` : 'No existe una dirección LAN utilizable.')),
    makeCheck('QR_INSTALLATION_READY', 'QR de validación', persisted || session.qrReady, persisted ? 'QR validado en la aceptación S7 guardada.' : (session.qrReady ? 'El QR de instalación fue generado con la dirección LAN activa.' : 'No fue posible generar el QR de instalación.')),
    makeCheck('SECOND_DEVICE_CONNECTED', 'Segundo dispositivo conectado', persisted || (secondDevice && Boolean(session.connectedAt)), persisted ? 'Segundo dispositivo verificado en la aceptación S7 guardada.' : (session.connectedAt ? `Conexión recibida desde ${session.remoteAddress}.` : 'Esperando que el celular abra el QR.')),
    makeCheck('MOBILE_DEVICE_SIGNALS', 'Celular táctil verificado', mobileSignals, persisted ? 'Celular táctil verificado en la aceptación S7 guardada.' : (mobileSignals ? 'El navegador informó agente móvil y señales táctiles.' : 'Esperando señales técnicas compatibles con un celular.')),
    makeCheck('TEST_ORDER_RECEIVED', 'Pedido técnico recibido', Boolean(session.requestReceivedAt && session.requestId), session.requestReceivedAt ? `Pedido ${session.requestCode} recibido por el servidor.` : 'Esperando el pedido técnico automático del celular.'),
    makeCheck('SERVER_ACK_CONFIRMED', 'Respuesta servidor → celular', Boolean(session.ackConfirmedAt), session.ackConfirmedAt ? 'El celular confirmó que recibió la respuesta del servidor.' : 'Esperando confirmación de la respuesta enviada al celular.'),
    makeCheck('LOCAL_COMPUTER_OBSERVED', 'Retorno visible en la computadora', Boolean(session.localObservedAt), session.localObservedAt ? 'La computadora del servidor observó el pedido recibido.' : 'Esperando que la pantalla local observe el pedido.'),
    makeCheck('S7_EVIDENCE_PERSISTED', 'Evidencia de instalación', Boolean(session.evidencePersisted), session.evidencePersisted ? `Evidencia cifrada guardada en ${EVIDENCE_FILE}.` : 'La evidencia se guardará cuando finalice la validación.')
  ];
}

function corePassed(session) {
  return Boolean(
    session.s6Approved
    && session.networkBaseUrl
    && session.qrReady
    && session.connectedAt
    && session.remoteAddress
    && !isLoopback(session.remoteAddress)
    && !localMachineAddressProvider(session.remoteAddress)
    && session.deviceClass === 'MOBILE_LIKE'
    && hasTouchSignals(session.deviceEvidence)
    && session.requestReceivedAt
    && session.requestId
    && session.ackConfirmedAt
    && session.localObservedAt
  );
}

function deriveStatus(session) {
  if (session.passed) return 'PASSED';
  if (nowDate().getTime() > session.expiresAtMs) return 'EXPIRED';
  if (!session.s6Approved || !session.networkBaseUrl || !session.qrReady) return 'BLOCKED';
  if (session.ackConfirmedAt) return 'WAITING_LOCAL_OBSERVATION';
  if (session.requestReceivedAt) return 'WAITING_PHONE_ACK';
  if (session.connectedAt) return 'MOBILE_CONNECTED';
  return 'WAITING_SCAN';
}

function messageForStatus(status) {
  const messages = {
    NOT_INITIALIZED: 'La validación S7 todavía no fue iniciada.',
    BLOCKED: 'La validación móvil no puede comenzar hasta corregir los controles previos.',
    WAITING_SCAN: 'Escanee el QR con un celular conectado a la red del servidor.',
    MOBILE_CONNECTED: 'Celular detectado. Enviando el pedido técnico de prueba…',
    WAITING_PHONE_ACK: 'Pedido recibido. Confirmando la respuesta del servidor en el celular…',
    WAITING_LOCAL_OBSERVATION: 'La comunicación móvil está aprobada. Registrando el retorno en la computadora…',
    EXPIRED: 'La validación venció. Genere un nuevo QR.',
    PASSED: 'Validación S7 aprobada: celular, servidor y computadora se comunicaron correctamente.'
  };
  return messages[status] || messages.NOT_INITIALIZED;
}

function publicStatus(session = current) {
  if (!session) {
    return Object.freeze({
      phase: PHASE,
      status: 'NOT_INITIALIZED',
      ready: false,
      passed: false,
      message: messageForStatus('NOT_INITIALIZED'),
      checks: []
    });
  }
  const status = deriveStatus(session);
  const checks = buildChecks(session);
  return Object.freeze({
    phase: PHASE,
    applicationVersion: currentVersion,
    status,
    ready: status === 'PASSED',
    passed: status === 'PASSED',
    message: messageForStatus(status),
    validationId: session.id,
    createdAt: session.createdAt,
    expiresAt: session.expiresAt,
    networkAddress: session.networkAddress,
    networkBaseUrl: session.networkBaseUrl,
    interfaceName: session.interfaceName,
    port: session.port,
    qrAvailable: Boolean(session.qrReady && status !== 'EXPIRED' && status !== 'PASSED'),
    connectedAt: session.connectedAt,
    requestReceivedAt: session.requestReceivedAt,
    requestId: session.requestId,
    requestCode: session.requestCode,
    ackConfirmedAt: session.ackConfirmedAt,
    localObservedAt: session.localObservedAt,
    deviceClass: session.deviceClass,
    evidenceFile: session.evidenceFile,
    checks
  });
}

function evidencePayload(session) {
  const checks = {
    s6DeploymentApproved: Boolean(session.s6Approved),
    lanUrlReady: Boolean(session.networkBaseUrl),
    qrInstallationReady: Boolean(session.qrReady),
    secondDeviceConnected: Boolean(session.connectedAt && session.remoteAddress),
    mobileDeviceSignals: session.deviceClass === 'MOBILE_LIKE' && hasTouchSignals(session.deviceEvidence),
    testOrderReceived: Boolean(session.requestReceivedAt && session.requestId),
    serverAckConfirmedByPhone: Boolean(session.ackConfirmedAt),
    localComputerObservedReturn: Boolean(session.localObservedAt)
  };
  return {
    schema: EVIDENCE_SCHEMA,
    phase: PHASE,
    applicationVersion: currentVersion,
    buildFingerprint: fingerprintProvider(),
    generatedAt: nowIso(),
    result: Object.values(checks).every(Boolean) ? 'PASSED' : 'REJECTED',
    checks,
    network: {
      address: session.networkAddress,
      interfaceName: session.interfaceName,
      port: session.port,
      baseUrlHash: hashValue(session.networkBaseUrl)
    },
    mobile: {
      remoteAddressHash: hashValue(session.remoteAddress),
      userAgentHash: hashValue(session.userAgent),
      deviceClass: session.deviceClass,
      touchSignals: hasTouchSignals(session.deviceEvidence),
      platform: session.deviceEvidence?.platform || null,
      screen: session.deviceEvidence ? `${session.deviceEvidence.screenWidth || 0}x${session.deviceEvidence.screenHeight || 0}` : null
    },
    roundTrip: {
      validationId: session.id,
      requestId: session.requestId,
      requestCode: session.requestCode,
      connectedAt: session.connectedAt,
      requestReceivedAt: session.requestReceivedAt,
      ackIssuedAt: session.ackIssuedAt,
      ackConfirmedAt: session.ackConfirmedAt,
      localObservedAt: session.localObservedAt
    },
    security: {
      validationTokenPersisted: false,
      challengePersisted: false,
      acknowledgementTokenPersisted: false,
      rawRemoteAddressPersisted: false,
      rawUserAgentPersisted: false,
      productionBusinessDataModified: false
    }
  };
}

function finalizeIfReady(session) {
  if (session.passed || !corePassed(session)) return;
  const payload = evidencePayload(session);
  const saved = evidenceWriteProvider(payload);
  session.evidencePersisted = true;
  session.evidenceFile = saved?.file || EVIDENCE_FILE;
  session.passed = true;
  session.passedAt = nowIso();
  if (!session.passedEventEmitted) {
    session.passedEventEmitted = true;
    queueMicrotask(() => events.emit('passed', publicStatus(session)));
  }
}

function startSession({ s6Approved = true } = {}) {
  const network = networkProvider() || {};
  const createdAtMs = nowDate().getTime();
  const id = crypto.randomUUID();
  const token = tokenProvider();
  const challenge = challengeProvider();
  const requestCode = `S7-${id.slice(0, 8).toUpperCase()}`;
  const networkBaseUrl = network.available && network.baseUrl ? String(network.baseUrl) : null;
  const url = networkBaseUrl ? `${networkBaseUrl}/installation-validation-mobile.html?token=${encodeURIComponent(token)}` : null;
  let qrReady = false;
  if (url) {
    try { qrReady = /<svg\b/i.test(svg(url)); } catch { qrReady = false; }
  }
  current = {
    id,
    token,
    challenge,
    requestCode,
    s6Approved: Boolean(s6Approved),
    createdAtMs,
    expiresAtMs: createdAtMs + SESSION_TTL_MS,
    createdAt: new Date(createdAtMs).toISOString(),
    expiresAt: new Date(createdAtMs + SESSION_TTL_MS).toISOString(),
    networkAddress: network.address || null,
    networkBaseUrl,
    interfaceName: network.interfaceName || null,
    port: network.port || null,
    url,
    qrReady,
    remoteAddress: null,
    userAgent: null,
    deviceClass: 'UNKNOWN',
    deviceEvidence: null,
    connectedAt: null,
    requestReceivedAt: null,
    requestId: null,
    requestPayloadHash: null,
    ackId: null,
    ackIssuedAt: null,
    ackConfirmedAt: null,
    localObservedAt: null,
    evidencePersisted: false,
    evidenceFile: null,
    passed: false,
    passedAt: null,
    passedEventEmitted: false
  };
  return publicStatus(current);
}

function passedStateFromEvidence(evidence) {
  const generatedAt = evidence.generatedAt || nowIso();
  current = {
    id: evidence.roundTrip?.validationId || 'persisted',
    token: null,
    challenge: null,
    requestCode: evidence.roundTrip?.requestCode || null,
    s6Approved: true,
    createdAtMs: Date.parse(generatedAt) || nowDate().getTime(),
    expiresAtMs: Number.MAX_SAFE_INTEGER,
    createdAt: generatedAt,
    expiresAt: null,
    networkAddress: evidence.network?.address || null,
    networkBaseUrl: null,
    interfaceName: evidence.network?.interfaceName || null,
    port: evidence.network?.port || null,
    url: null,
    qrReady: true,
    remoteAddress: 'PERSISTED_SECOND_DEVICE',
    userAgent: 'PERSISTED',
    deviceClass: evidence.mobile?.deviceClass || 'MOBILE_LIKE',
    deviceEvidence: { maxTouchPoints: evidence.mobile?.touchSignals ? 1 : 0, touchEvent: Boolean(evidence.mobile?.touchSignals), coarsePointer: Boolean(evidence.mobile?.touchSignals) },
    connectedAt: evidence.roundTrip?.connectedAt || generatedAt,
    requestReceivedAt: evidence.roundTrip?.requestReceivedAt || generatedAt,
    requestId: evidence.roundTrip?.requestId || 'persisted',
    requestPayloadHash: null,
    ackId: null,
    ackIssuedAt: evidence.roundTrip?.ackIssuedAt || generatedAt,
    ackConfirmedAt: evidence.roundTrip?.ackConfirmedAt || generatedAt,
    localObservedAt: evidence.roundTrip?.localObservedAt || generatedAt,
    evidencePersisted: true,
    evidenceFile: EVIDENCE_FILE,
    passed: true,
    passedAt: generatedAt,
    passedEventEmitted: true,
    persistedEvidence: true
  };
  return publicStatus(current);
}

function initialize({ deploymentStatus, version = runtime.sourceVersion, installRoot = runtime.projectRoot } = {}) {
  currentVersion = String(version || runtime.sourceVersion);
  currentInstallRoot = installRoot || runtime.projectRoot;
  const s6Approved = deploymentStatus?.status === 'PASSED';
  if (!s6Approved) return startSession({ s6Approved: false });
  const fingerprint = fingerprintProvider();
  try {
    const evidence = evidenceReadProvider();
    if (evidenceIsValid(evidence, fingerprint)) return passedStateFromEvidence(evidence);
  } catch {
    // Evidencia ilegible o de otra instalación: se repite la validación física.
  }
  return startSession({ s6Approved: true });
}

function requireSessionToken(token, { allowPassed = false } = {}) {
  if (!current || !current.token) throw error(409, 'S7_SESSION_NOT_ACTIVE', 'No existe una validación S7 activa.');
  if (current.passed && !allowPassed) throw error(409, 'S7_SESSION_ALREADY_PASSED', 'La validación S7 ya fue aprobada.');
  if (nowDate().getTime() > current.expiresAtMs && !current.passed) throw error(410, 'S7_SESSION_EXPIRED', 'El QR de validación venció. Genere uno nuevo desde el servidor.');
  if (!safeEqual(token, current.token)) throw error(403, 'S7_TOKEN_INVALID', 'El QR de validación no es válido.');
  return current;
}

function requireSecondDevice(context) {
  const remoteAddress = normalizeRemoteAddress(context?.ip);
  if (isLoopback(remoteAddress) || localMachineAddressProvider(remoteAddress)) {
    throw error(409, 'S7_SECOND_DEVICE_REQUIRED', 'La validación debe abrirse desde un celular distinto de la computadora del servidor.');
  }
  return remoteAddress;
}

function bindRemote(session, context, deviceEvidence) {
  const remoteAddress = requireSecondDevice(context);
  if (session.remoteAddress && session.remoteAddress !== remoteAddress) {
    throw error(409, 'S7_DEVICE_CHANGED', 'La prueba debe completarse desde el mismo celular que abrió el QR.');
  }
  session.remoteAddress ||= remoteAddress;
  session.userAgent ||= cleanText(context?.userAgent, 300);
  session.deviceEvidence = cleanDeviceEvidence(deviceEvidence);
  session.deviceClass = classifyDevice(context?.userAgent, session.deviceEvidence);
  return remoteAddress;
}

function connectMobile(input = {}, context = {}) {
  const session = requireSessionToken(input.token);
  bindRemote(session, context, input.deviceEvidence);
  session.connectedAt ||= nowIso();
  return {
    validation: publicStatus(session),
    challenge: session.challenge,
    requestCode: session.requestCode
  };
}

function submitTestOrder(input = {}, context = {}) {
  const session = requireSessionToken(input.token);
  bindRemote(session, context, input.deviceEvidence || session.deviceEvidence);
  if (!session.connectedAt) throw error(409, 'S7_CONNECT_REQUIRED', 'Primero debe registrarse la conexión del celular.');
  if (session.deviceClass !== 'MOBILE_LIKE' || !hasTouchSignals(session.deviceEvidence)) {
    throw error(409, 'S7_MOBILE_SIGNALS_REQUIRED', 'El dispositivo no informó señales compatibles con un celular táctil.');
  }
  if (!safeEqual(input.challenge, session.challenge)) throw error(403, 'S7_CHALLENGE_INVALID', 'El desafío de validación no coincide.');
  if (!safeEqual(input.requestCode, session.requestCode)) throw error(409, 'S7_REQUEST_CODE_INVALID', 'El pedido técnico no corresponde a esta validación.');

  if (!session.requestId) {
    session.requestId = crypto.randomUUID();
    session.requestReceivedAt = nowIso();
    session.requestPayloadHash = hashValue(JSON.stringify({
      validationId: session.id,
      requestCode: session.requestCode,
      remoteAddress: session.remoteAddress,
      receivedAt: session.requestReceivedAt
    }));
    session.ackId = crypto.randomBytes(18).toString('base64url');
    session.ackIssuedAt = nowIso();
  }
  return {
    validation: publicStatus(session),
    acknowledgement: {
      ackId: session.ackId,
      requestId: session.requestId,
      requestCode: session.requestCode,
      receivedAt: session.requestReceivedAt,
      issuedAt: session.ackIssuedAt
    }
  };
}

function confirmPhoneReceivedAck(input = {}, context = {}) {
  const session = requireSessionToken(input.token);
  bindRemote(session, context, input.deviceEvidence || session.deviceEvidence);
  if (!session.requestId || !session.ackId) throw error(409, 'S7_TEST_ORDER_REQUIRED', 'El servidor todavía no recibió el pedido técnico.');
  if (!safeEqual(input.ackId, session.ackId)) throw error(403, 'S7_ACK_INVALID', 'La confirmación del servidor no coincide.');
  session.ackConfirmedAt ||= nowIso();
  return { validation: publicStatus(session) };
}

function recordLocalObservation() {
  if (!current || current.passed) return publicStatus(current);
  if (current.requestReceivedAt && current.ackConfirmedAt) current.localObservedAt ||= nowIso();
  finalizeIfReady(current);
  return publicStatus(current);
}

function getStatus({ observeLocal = false } = {}) {
  if (observeLocal) return recordLocalObservation();
  return publicStatus(current);
}

function getMobileStatus(token, context = {}) {
  const session = requireSessionToken(token, { allowPassed: true });
  bindRemote(session, context, session.deviceEvidence);
  return {
    phase: PHASE,
    status: deriveStatus(session),
    passed: Boolean(session.passed),
    message: messageForStatus(deriveStatus(session)),
    requestCode: session.requestCode,
    requestId: session.requestId,
    requestReceivedAt: session.requestReceivedAt,
    ackConfirmedAt: session.ackConfirmedAt,
    localObservedAt: session.localObservedAt
  };
}

function restart() {
  return startSession({ s6Approved: true });
}

function qrSvg() {
  if (!current?.url || !current.qrReady) throw error(409, 'S7_QR_NOT_READY', 'El QR S7 todavía no está disponible.');
  return svg(current.url);
}

function getEvidenceSummary() {
  if (!current?.passed) throw error(409, 'S7_NOT_PASSED', 'La validación S7 todavía no fue aprobada.');
  return evidencePayload(current);
}

function setTestProviders(providers = {}) {
  if (providers.now) nowProvider = providers.now;
  if (providers.network) networkProvider = providers.network;
  if (providers.isLocalMachineAddress) localMachineAddressProvider = providers.isLocalMachineAddress;
  if (providers.dataDir) dataDirProvider = providers.dataDir;
  if (providers.evidenceRead) evidenceReadProvider = providers.evidenceRead;
  if (providers.evidenceWrite) evidenceWriteProvider = providers.evidenceWrite;
  if (providers.fingerprint) fingerprintProvider = providers.fingerprint;
  if (providers.token) tokenProvider = providers.token;
  if (providers.challenge) challengeProvider = providers.challenge;
}

function resetForTests() {
  current = null;
  currentVersion = runtime.sourceVersion;
  currentInstallRoot = runtime.projectRoot;
  nowProvider = () => new Date();
  networkProvider = () => getNetworkStatus();
  localMachineAddressProvider = (address) => isLocalMachineAddress(address);
  dataDirProvider = () => runtime.evidenceDir;
  evidenceReadProvider = readPersistedEvidence;
  evidenceWriteProvider = persistEvidence;
  fingerprintProvider = readBuildFingerprint;
  tokenProvider = () => crypto.randomBytes(24).toString('base64url');
  challengeProvider = () => crypto.randomBytes(18).toString('base64url');
  events.removeAllListeners();
}

module.exports = {
  PHASE,
  SESSION_TTL_MS,
  events,
  initialize,
  restart,
  getStatus,
  getMobileStatus,
  connectMobile,
  submitTestOrder,
  confirmPhoneReceivedAck,
  recordLocalObservation,
  qrSvg,
  getEvidenceSummary,
  normalizeRemoteAddress,
  isLoopback,
  cleanDeviceEvidence,
  classifyUserAgent,
  classifyDevice,
  hasTouchSignals,
  setTestProviders,
  resetForTests
};
