'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { createRequest, userHasScope } = require('./request-service');
const { getCustody, declareReturn, receiveCustody } = require('./custody-service');
const { saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { syncCustodyOperationalAlerts } = require('./custody-alert-service');
const { syncRequestOperationalAlert } = require('./request-alert-service');
const { enqueueNotification } = require('./notification-service');
const { createBlockInDb } = require('./incident-service');
const runtime = require('../config/runtime');

const CHECK_KEYS = ['exterior','neumaticos','luces','interior','documentacion'];
const CHECK_LABELS = Object.freeze({ exterior:'Exterior', neumaticos:'Neumáticos', luces:'Luces', interior:'Interior', documentacion:'Documentación' });

function error(status, code, message) { return Object.assign(new Error(message), { status, code }); }
function nowIso() { return new Date().toISOString(); }
function normalizeChecklist(value) {
  const source = value && typeof value === 'object' ? value : {};
  const result = {};
  for (const key of CHECK_KEYS) {
    const item = String(source[key] || '').toUpperCase();
    if (!['OK','OBSERVACION'].includes(item)) throw error(422, 'VEHICLE_CHECKLIST_REQUIRED', 'Completá todo el checklist del vehículo.');
    result[key] = item;
  }
  return result;
}
function checklistObserved(checklist) { return CHECK_KEYS.some((key) => checklist[key] === 'OBSERVACION'); }
function normalizeSupervisorChecklistAssessments(snapshot, value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const rows = [];
  for (const key of CHECK_KEYS) {
    const raw = source[key] && typeof source[key] === 'object' ? source[key] : {};
    const supervisorValue = String(raw.value || raw.result || '').toUpperCase();
    if (!['OK','OBSERVACION'].includes(supervisorValue)) {
      throw error(422,'VEHICLE_SUPERVISOR_CHECKLIST_REQUIRED',`Completá la inspección del Supervisor para ${CHECK_LABELS[key]}.`);
    }
    const safety = raw.safety === true || raw.safety === 1 || String(raw.safety || '').toLowerCase() === 'true' || String(raw.safety || '').toUpperCase() === 'SI';
    const comment = String(raw.comment || '').trim() || null;
    if (supervisorValue === 'OBSERVACION' && (!comment || comment.length < 3)) {
      throw error(422,'VEHICLE_SUPERVISOR_CHECKLIST_COMMENT_REQUIRED',`La observación de ${CHECK_LABELS[key]} requiere un comentario del Supervisor.`);
    }
    if (safety && supervisorValue !== 'OBSERVACION') {
      throw error(422,'VEHICLE_SUPERVISOR_CHECKLIST_SAFETY_INVALID',`${CHECK_LABELS[key]} sólo puede marcarse como Seguridad si tiene una observación.`);
    }
    rows.push({
      key,
      label: CHECK_LABELS[key],
      technicianValue: String(snapshot?.[key] || 'OK').toUpperCase() === 'OBSERVACION' ? 'OBSERVACION' : 'OK',
      supervisorValue,
      safety,
      comment
    });
  }
  return rows;
}
function numberInRange(value, field, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) throw error(422, `VEHICLE_${field.toUpperCase()}_INVALID`, `${field} inválido.`);
  return n;
}
function requireVehicle(db, assetId) {
  const row = db.prepare(`SELECT a.*,ac.nature AS category_nature,sl.site_id,sl.name AS location_name
    FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE a.id=? AND a.deleted_at IS NULL`).get(assetId);
  if (!row || String(row.category_nature).toUpperCase() !== 'VEHICULO') throw error(404, 'VEHICLE_NOT_FOUND', 'Vehículo no disponible.');
  return row;
}
function assertScope(user, vehicle, permission) {
  if (!userHasScope(user, vehicle.site_id, vehicle.location_id, permission)) throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
}
function assignedSupervisorForRequester(db, userId, personId) {
  const person = db.prepare('SELECT id,supervisor_person_id FROM person WHERE id=? AND deleted_at IS NULL').get(personId);
  if (!person) throw error(409,'VEHICLE_RETURN_REQUESTER_INVALID','No se encontró la persona asociada al usuario.');
  const row = db.prepare(`SELECT usa.supervisor_user_id,sua.person_id AS supervisor_person_id,sp.full_name AS supervisor_name,sua.username AS supervisor_username
    FROM user_supervisor_assignment usa
    JOIN user_account sua ON sua.id=usa.supervisor_user_id
    JOIN person sp ON sp.id=sua.person_id
    WHERE usa.user_id=? AND usa.effective_to IS NULL AND usa.effective_from<=?
      AND sua.active=1 AND sua.deleted_at IS NULL AND sp.status='ACTIVA' AND sp.deleted_at IS NULL
    ORDER BY usa.effective_from DESC LIMIT 1`).get(userId, nowIso());
  if (!row) throw error(409,'VEHICLE_RETURN_SUPERVISOR_REQUIRED','El usuario debe tener un Supervisor activo asignado antes de iniciar la devolución del vehículo.');
  if (person.supervisor_person_id && String(person.supervisor_person_id) !== String(row.supervisor_person_id)) {
    throw error(409,'VEHICLE_RETURN_SUPERVISOR_INCONSISTENT','La asignación de Supervisor del usuario no es consistente. Revisala antes de iniciar la devolución.');
  }
  if (String(row.supervisor_user_id) === String(userId)) throw error(409,'VEHICLE_RETURN_SUPERVISOR_SELF','El usuario no puede supervisar su propia devolución.');
  return row;
}
function vehicleSupervisionRow(db, custodyId) {
  const row = db.prepare(`SELECT vrs.*,sp.full_name AS supervisor_name,rp.full_name AS requester_name,
      iu.username AS inspected_by_username,wu.username AS warehouse_received_by_username
    FROM vehicle_return_supervision vrs
    JOIN person sp ON sp.id=vrs.supervisor_person_id
    JOIN person rp ON rp.id=vrs.requester_person_id
    LEFT JOIN user_account iu ON iu.id=vrs.inspected_by_user_id
    LEFT JOIN user_account wu ON wu.id=vrs.warehouse_received_by_user_id
    WHERE vrs.custody_id=?`).get(custodyId);
  if (!row) return null;
  return { ...row, returnChecklist: JSON.parse(row.return_checklist_json || '{}'),
    checklistAssessments: db.prepare(`SELECT checklist_key,checklist_label_snapshot,technician_value_snapshot,supervisor_value,safety_observation,supervisor_comment,assessed_by_user_id,assessed_at
      FROM vehicle_return_checklist_assessment WHERE supervision_id=? ORDER BY CASE checklist_key WHEN 'exterior' THEN 1 WHEN 'neumaticos' THEN 2 WHEN 'luces' THEN 3 WHEN 'interior' THEN 4 WHEN 'documentacion' THEN 5 ELSE 99 END`).all(row.id),
    events: db.prepare(`SELECT e.*,ua.username,p.full_name AS actor_name
    FROM vehicle_return_supervision_event e JOIN user_account ua ON ua.id=e.actor_user_id JOIN person p ON p.id=ua.person_id
    WHERE e.supervision_id=? ORDER BY e.occurred_at`).all(row.id) };
}
function validateDriverIfConfigured(db, vehicle, personId, at) {
  const configured = Number(db.prepare(`SELECT COUNT(*) AS n FROM vehicle_driver_authorization
    WHERE status='VIGENTE' AND (vehicle_asset_id=? OR (vehicle_asset_id IS NULL AND category_id=?))`).get(vehicle.id, vehicle.category_id)?.n || 0);
  if (!configured) return;
  const auth = db.prepare(`SELECT 1 FROM vehicle_driver_authorization WHERE person_id=? AND status='VIGENTE' AND valid_from<=? AND valid_until>=?
    AND (vehicle_asset_id=? OR (vehicle_asset_id IS NULL AND category_id=?)) LIMIT 1`).get(personId, at, at, vehicle.id, vehicle.category_id);
  if (!auth) throw error(409, 'DRIVER_NOT_AUTHORIZED', 'El conductor no posee habilitación vigente para este vehículo.');
}
function getVehicleRequestDetail(requestId, user = null, permission = null) {
  const db = getDb();
  const row = db.prepare(`SELECT vrd.*,r.request_number,r.status,r.version AS request_version,r.requester_person_id,
      p.full_name AS driver_name,a.internal_code,a.description,a.license_plate,a.brand,a.model,
      sl.site_id,sl.name AS location_name
    FROM vehicle_request_detail vrd JOIN request r ON r.id=vrd.request_id
    JOIN person p ON p.id=vrd.driver_person_id JOIN asset a ON a.id=vrd.vehicle_asset_id
    JOIN storage_location sl ON sl.id=a.location_id WHERE vrd.request_id=?`).get(requestId);
  if (!row) throw error(404,'VEHICLE_REQUEST_DETAIL_NOT_FOUND','No se encontraron los datos del vehículo.');
  if (user) {
    if (permission) assertScope(user, { site_id: row.site_id, location_id: row.location_id }, permission);
    else if (row.requester_person_id !== user.personId) throw error(403,'REQUEST_FORBIDDEN','Ese pedido no es tuyo.');
  }
  return { ...row, departureChecklist: JSON.parse(row.departure_checklist_json || '{}') };
}
function getVehicleReturnDetail(custodyId, user = null, permission = null) {
  const db = getDb();
  const custody = db.prepare(`SELECT c.*,a.location_id,sl.site_id,a.internal_code,a.description,a.license_plate
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE c.id=?`).get(custodyId);
  if (!custody) throw error(404,'CUSTODY_NOT_FOUND','Custodia no encontrada.');
  if (user) {
    if (permission) assertScope(user, { site_id:custody.site_id, location_id:custody.location_id }, permission);
    else if (custody.person_id !== user.personId) throw error(403,'CUSTODY_FORBIDDEN','Ese vehículo no está a tu cargo.');
  }
  const request = db.prepare('SELECT * FROM vehicle_request_detail WHERE request_id=?').get(custody.request_id);
  const returned = db.prepare('SELECT * FROM vehicle_return_detail WHERE custody_id=?').get(custodyId);
  return {
    custody,
    request: request ? { ...request, departureChecklist: JSON.parse(request.departure_checklist_json || '{}') } : null,
    returnDetail: returned ? { ...returned, returnChecklist: JSON.parse(returned.return_checklist_json || '{}') } : null,
    supervision: vehicleSupervisionRow(db, custodyId)
  };
}
function createVehicleRequest(input, context) {
  const assetId = requiredString(input.assetId,'assetId',{min:8,max:80});
  const db = getDb();
  const vehicle = requireVehicle(db, assetId);
  assertScope(context.user, vehicle, 'Requests.Create');
  const driverPersonId = String(input.driverPersonId || context.user.personId || '').trim();
  const driver = db.prepare("SELECT id,full_name FROM person WHERE id=? AND status='ACTIVA' AND deleted_at IS NULL").get(driverPersonId);
  if (!driver) throw error(422,'DRIVER_INVALID','Conductor inválido.');
  const neededAtDate = new Date(input.neededAt || Date.now());
  if (!Number.isFinite(neededAtDate.getTime())) throw error(422,'VEHICLE_NEEDED_AT_INVALID','Fecha de salida inválida.');
  validateDriverIfConfigured(db, vehicle, driverPersonId, neededAtDate.toISOString());
  const dueDate = new Date(input.dueAt || '');
  if (!Number.isFinite(dueDate.getTime()) || dueDate.getTime() <= neededAtDate.getTime()) throw error(422,'VEHICLE_DUE_AT_INVALID','La devolución debe ser posterior a la salida.');
  const checklist = normalizeChecklist(input.checklist);
  const departureNotes = String(input.departureNotes || '').trim() || null;
  if (checklistObserved(checklist) && !departureNotes) throw error(422,'VEHICLE_OBSERVATION_REQUIRED','Si marcaste una observación, contanos brevemente qué viste.');
  const odometer = numberInRange(input.odometer,'odometer',0,100000000);
  const fuel = numberInRange(input.fuelLevelPercent,'fuel',0,100);
  const workOrderReference = String(input.workOrderReference || '').trim();
  if (!workOrderReference) throw error(422,'WORK_ORDER_REQUIRED','Ingresá la OT antes de enviar el pedido.');
  const destination = requiredString(input.destination || input.reason,'destination',{min:5,max:500});
  const reason = String(input.reason || destination).trim();
  if (!input.disclaimerAccepted) throw error(422,'VEHICLE_DISCLAIMER_REQUIRED','Aceptá la declaración de uso responsable.');
  const clientRequestId = String(input.clientRequestId || `vehicle-${randomUUID()}`);
  const companionName = String(input.companionName||'').trim() || null;
  const insertDetail = (tx, requestId, createdAt) => {
    tx.prepare(`INSERT OR IGNORE INTO vehicle_request_detail(request_id,vehicle_asset_id,driver_person_id,companion_name,destination,expected_return_at,
      departure_odometer,departure_fuel_percent,departure_condition,departure_checklist_json,departure_notes,disclaimer_accepted,created_by_user_id,created_at,updated_at,work_order_reference_snapshot)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        requestId, assetId, driverPersonId, companionName, destination, dueDate.toISOString(), odometer, fuel,
        checklistObserved(checklist) ? 'OBSERVADO' : 'CONFORME', JSON.stringify(checklist), departureNotes, 1, context.user.id, createdAt, createdAt, workOrderReference
      );
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'VEHICLE.REQUEST_DETAIL_CREATE',entityType:'request',entityId:requestId,
      after:{vehicleAssetId:assetId,driverPersonId,companionName,destination,odometer,fuelLevelPercent:fuel,checklist,disclaimerAccepted:true},
      correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent},tx);
  };
  const result = createRequest({
    operationType:'RETIRO', siteId:vehicle.site_id, locationId:vehicle.location_id,
    neededAt:neededAtDate.toISOString(), dueAt:dueDate.toISOString(), reason, workOrderReference,
    clientRequestId, items:[{assetId,quantity:1}]
  }, context, { afterCreate:(tx, meta) => insertDetail(tx, meta.id, meta.now) });
  const request = result.request;
  if (result.idempotent && !db.prepare('SELECT 1 FROM vehicle_request_detail WHERE request_id=?').get(request.id)) {
    transaction((tx) => insertDetail(tx, request.id, nowIso()));
  }
  return { ...result, vehicleDetail:getVehicleRequestDetail(request.id, context.user) };
}
function saveVehicleRequestPhoto(requestId,input,context) {
  getVehicleRequestDetail(requestId, context.user);
  return saveOwnedEvidenceDataUrl(input,{ownerType:'REQUEST',ownerId:requestId,purpose:'VEHICLE_REQUEST_PHOTO'},context,{allowedMimeTypes:['image/png','image/jpeg','image/webp'],maxBytes:runtime.maxImageBytes});
}
function quickHandoverVehicleRequest(requestId,input,context) {
  const idempotencyKey = requiredString(input.idempotencyKey,'idempotencyKey',{min:8,max:120,pattern:/^[A-Za-z0-9._:-]+$/});
  return transaction((db) => {
    const old = db.prepare("SELECT id,request_id FROM handover WHERE idempotency_key=? AND type='ENTREGA'").get(idempotencyKey);
    if (old) return { handoverId:old.id,idempotent:true,mode:'VEHICULO_DIRECTO' };
    const request = db.prepare(`SELECT r.*,sl.site_id FROM request r JOIN storage_location sl ON sl.id=r.location_id WHERE r.id=?`).get(requestId);
    if (!request) throw error(404,'REQUEST_NOT_FOUND','Solicitud no encontrada.');
    assertScope(context.user,{site_id:request.site_id,location_id:request.location_id},'Warehouse.Operate');
    if (request.status !== 'APROBADA') throw error(409,'VEHICLE_REQUEST_NOT_APPROVED','El pedido no está listo para entregar.');
    if (Number(input.version) !== Number(request.version)) throw error(409,'CONCURRENCY_CONFLICT','La solicitud fue modificada.');
    const detail = db.prepare('SELECT * FROM vehicle_request_detail WHERE request_id=?').get(requestId);
    if (!detail) throw error(409,'VEHICLE_DETAIL_REQUIRED','Faltan los datos del vehículo.');
    const vehicle = requireVehicle(db, detail.vehicle_asset_id);
    validateDriverIfConfigured(db, vehicle, detail.driver_person_id, nowIso());
    const item = db.prepare(`SELECT ri.id AS request_item_id,ri.quantity,ar.id AS reservation_id,ar.status AS reservation_status,ar.quantity AS reserved_quantity
      FROM request_item ri LEFT JOIN asset_reservation ar ON ar.request_item_id=ri.id AND ar.status='ACTIVA' WHERE ri.request_id=? AND ri.asset_id=?`).get(requestId,vehicle.id);
    if (!item || Number(item.quantity)!==1 || item.reservation_status!=='ACTIVA' || Number(item.reserved_quantity)!==1) throw error(409,'VEHICLE_RESERVATION_INVALID','La reserva del vehículo ya no está disponible.');
    const profile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(vehicle.id);
    const odometer = input.odometer === undefined || input.odometer === null ? Number(detail.departure_odometer) : numberInRange(input.odometer,'odometer',0,100000000);
    if (profile && odometer < Number(profile.current_odometer||0)) throw error(422,'VEHICLE_METER_ROLLBACK','El kilometraje no puede disminuir.');
    const fuel = input.fuelLevelPercent === undefined || input.fuelLevelPercent === null ? Number(detail.departure_fuel_percent) : numberInRange(input.fuelLevelPercent,'fuel',0,100);
    const checklist = JSON.parse(detail.departure_checklist_json||'{}');
    const notes = String(input.notes || detail.departure_notes || '').trim() || null;
    const condition = String(input.condition || detail.departure_condition || 'CONFORME').toUpperCase();
    const now = nowIso();
    const handoverId = randomUUID();
    const acceptanceHash = createHash('sha256').update(`${requestId}:VEHICULO:${now}`).digest('hex');
    db.prepare(`INSERT INTO handover(id,request_id,type,operator_user_id,person_id,occurred_at,observations,acceptance_method,acceptance_hash,acceptance_evidence_id,idempotency_key,correlation_id,created_at,work_order_reference_snapshot)
      VALUES (?,?, 'ENTREGA',?,?,?,?, 'EXPLICITA',?,NULL,?,?,?,?)`).run(handoverId,requestId,context.user.id,request.requester_person_id,now,notes,acceptanceHash,idempotencyKey,context.correlationId,now,request.work_order_reference);
    db.prepare(`INSERT INTO handover_item(id,handover_id,request_item_id,asset_id,quantity,condition,notes,created_at) VALUES (?,?,?,?,1,?,?,?)`)
      .run(randomUUID(),handoverId,item.request_item_id,vehicle.id,condition,notes,now);
    db.prepare(`INSERT INTO inspection(id,asset_id,custody_id,handover_id,inspector_user_id,phase,condition,result,notes,occurred_at,created_at)
      VALUES (?,?,NULL,?,?,'ENTREGA',?,'APROBADO',?,?,?)`).run(randomUUID(),vehicle.id,handoverId,context.user.id,condition,notes,now,now);
    const custodyId = randomUUID();
    db.prepare(`INSERT INTO custody(id,request_id,request_item_id,asset_id,person_id,quantity,exclusive_unit,opened_by_handover_id,opened_at,due_at,status,version,created_at,updated_at,work_order_reference_snapshot)
      VALUES (?,?,?,?,?,1,1,?,?,?,'ABIERTA',1,?,?,?)`).run(custodyId,requestId,item.request_item_id,vehicle.id,request.requester_person_id,handoverId,now,request.due_at,now,now,request.work_order_reference);
    db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
      VALUES (?,?,NULL,'ABIERTA',?,?,?,?,?)`).run(randomUUID(),custodyId,context.user.id,'Vehículo entregado físicamente.',now,context.correlationId,now);
    db.prepare(`INSERT INTO vehicle_operation(id,asset_id,custody_id,handover_id,driver_person_id,operation_type,odometer,hourmeter,fuel_level_percent,condition,checklist_json,notes,operator_user_id,occurred_at,correlation_id,created_at)
      VALUES (?,?,?,?,?,'ENTREGA',?,NULL,?,?,?,?,?,?,?,?)`).run(randomUUID(),vehicle.id,custodyId,handoverId,detail.driver_person_id,odometer,fuel,condition,
        JSON.stringify({ ...checklist, companionName:detail.companion_name||null, disclaimerAccepted:true }),notes,context.user.id,now,context.correlationId,now);
    db.prepare('UPDATE vehicle_profile SET current_odometer=?,version=version+1,updated_at=? WHERE asset_id=?').run(odometer,now,vehicle.id);
    db.prepare(`UPDATE asset SET odometer=?,quantity_available=0,status='EN_CUSTODIA',custodian_person_id=?,version=version+1,updated_at=? WHERE id=?`).run(odometer,request.requester_person_id,now,vehicle.id);
    db.prepare("UPDATE asset_reservation SET status='CONSUMIDA',release_reason='ENTREGA_F6_VEHICULO',updated_at=? WHERE id=? AND status='ACTIVA'").run(now,item.reservation_id);
    db.prepare("UPDATE request_item SET status='ENTREGADO',updated_at=? WHERE id=?").run(now,item.request_item_id);
    const changed = db.prepare("UPDATE request SET status='ENTREGADA',version=version+1,updated_at=? WHERE id=? AND version=? AND status='APROBADA'").run(now,requestId,input.version);
    if (changed.changes!==1) throw error(409,'CONCURRENCY_CONFLICT','Conflicto al entregar el vehículo.');
    syncCustodyOperationalAlerts(db,custodyId,new Date(now)); syncRequestOperationalAlert(db,requestId,new Date(now));
    db.prepare(`INSERT INTO request_status_event(id,request_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
      VALUES (?,?, 'APROBADA','ENTREGADA',?,?,?,?,?)`).run(randomUUID(),requestId,context.user.id,'Entrega física de vehículo confirmada.',now,context.correlationId,now);
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'WAREHOUSE.VEHICLE_HANDOVER',entityType:'request',entityId:requestId,
      before:{status:'APROBADA'},after:{status:'ENTREGADA',vehicleAssetId:vehicle.id,custodyId,odometer,fuelLevelPercent:fuel,condition},correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent},db);
    return { handoverId,custodyId,idempotent:false,mode:'VEHICULO_DIRECTO' };
  });
}
function declareVehicleReturn(custodyId,input,context) {
  const db = getDb();
  const custody = getCustody(custodyId,context.user,false);
  if (String(custody.category_nature||'').toUpperCase()!=='VEHICULO') throw error(409,'VEHICLE_RETURN_ONLY','Esta devolución no corresponde a un vehículo.');
  const requestDetail = db.prepare('SELECT * FROM vehicle_request_detail WHERE request_id=?').get(custody.request_id);
  if (!requestDetail) throw error(409,'VEHICLE_DETAIL_REQUIRED','Faltan los datos de salida del vehículo.');
  const supervisor = assignedSupervisorForRequester(db, context.user.id, context.user.personId);
  const checklist = normalizeChecklist(input.checklist);
  const problem = Boolean(input.problemReported) || checklistObserved(checklist);
  const notes = String(input.notes||'').trim() || null;
  if (problem && !notes) throw error(422,'VEHICLE_RETURN_NOTES_REQUIRED','Si hubo un problema, contanos brevemente qué pasó.');
  const odometer = numberInRange(input.odometer,'odometer',0,100000000);
  if (odometer < Number(requestDetail.departure_odometer||0)) throw error(422,'VEHICLE_METER_ROLLBACK','El kilometraje de devolución no puede ser menor al de salida.');
  const fuel = numberInRange(input.fuelLevelPercent,'fuel',0,100);
  const condition = String(input.condition || (problem ? 'OBSERVADO' : 'CONFORME')).toUpperCase();
  if (!['CONFORME','OBSERVADO','DANADO','INCOMPLETO'].includes(condition)) throw error(422,'VEHICLE_RETURN_CONDITION_INVALID','Condición de devolución vehicular inválida.');
  let supervisionId = null;
  const declared = declareReturn(custodyId,{version:Number(input.version),condition,problemReported:problem,notes,reason:notes || 'Solicitud de inspección de devolución vehicular.'},context,false,{
    afterDeclare:(tx,meta)=>{
      const existing = tx.prepare('SELECT id FROM vehicle_return_supervision WHERE custody_id=?').get(custodyId);
      if (existing) throw error(409,'VEHICLE_RETURN_SUPERVISION_EXISTS','La inspección de Supervisor ya fue solicitada.');
      const requestOt = tx.prepare('SELECT work_order_reference FROM request WHERE id=?').get(custody.request_id)?.work_order_reference || null;
      tx.prepare(`INSERT INTO vehicle_return_detail(custody_id,request_id,vehicle_asset_id,driver_person_id,return_odometer,return_fuel_percent,return_condition,return_checklist_json,problem_reported,notes,declared_by_user_id,declared_at,created_at,work_order_reference_snapshot)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(custodyId,custody.request_id,custody.asset_id,requestDetail.driver_person_id,odometer,fuel,condition,JSON.stringify(checklist),problem?1:0,notes,context.user.id,meta.now,meta.now,requestOt);
      supervisionId=randomUUID();
      tx.prepare(`INSERT INTO vehicle_return_supervision(
        id,custody_id,request_id,vehicle_asset_id,requester_user_id,requester_person_id,supervisor_user_id,supervisor_person_id,status,
        technician_condition_snapshot,technician_problem_reported_snapshot,technician_comment_snapshot,return_checklist_json,return_odometer_snapshot,return_fuel_percent_snapshot,
        supervisor_comment,safety_observation,security_block_id,requested_at,inspected_at,inspected_by_user_id,warehouse_authorized_at,warehouse_received_at,warehouse_received_by_user_id,warehouse_handover_id,
        request_correlation_id,decision_correlation_id,warehouse_correlation_id,version,created_at,updated_at
      ) VALUES (?,?,?,?,?,?,?,?,'PENDIENTE',?,?,?,?,?,?,NULL,0,NULL,?,NULL,NULL,NULL,NULL,NULL,NULL,?,NULL,NULL,1,?,?)`)
        .run(supervisionId,custodyId,custody.request_id,custody.asset_id,context.user.id,context.user.personId,supervisor.supervisor_user_id,supervisor.supervisor_person_id,
          condition,problem?1:0,notes,JSON.stringify(checklist),odometer,fuel,meta.now,context.correlationId,meta.now,meta.now);
      tx.prepare(`INSERT INTO vehicle_return_supervision_event(id,supervision_id,custody_id,event_type,actor_user_id,from_status,to_status,comment,safety_observation,block_id,correlation_id,occurred_at,created_at)
        VALUES (?,?,?,'SOLICITADA',?,NULL,'PENDIENTE',?,0,NULL,?,?,?)`)
        .run(randomUUID(),supervisionId,custodyId,context.user.id,notes,context.correlationId,meta.now,meta.now);
      enqueueNotification({
        recipientUserId:supervisor.supervisor_user_id,
        type:'VEHICLE_RETURN_SUPERVISION',channel:'IN_APP',
        subject:'Vehículo pendiente de inspección',
        body:`${custody.custodian_name} solicitó devolver ${custody.internal_code} · ${custody.description}. Revisá el vehículo y otorgá el V°B° para que el pañol reciba las llaves.`,
        entityType:'CUSTODY',entityId:custodyId,dedupKey:`vehicle-return-supervision:${custodyId}`
      },tx);
      appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'VEHICLE.RETURN_SUPERVISION_REQUEST',entityType:'vehicle_return_supervision',entityId:supervisionId,
        after:{custodyId,vehicleAssetId:custody.asset_id,supervisorUserId:supervisor.supervisor_user_id,supervisorPersonId:supervisor.supervisor_person_id,condition,problemReported:problem,notes},
        correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent},tx);
    }
  });
  return { custody:declared, vehicleReturn:getVehicleReturnDetail(custodyId,context.user).returnDetail, supervision:vehicleSupervisionRow(getDb(),custodyId) };
}

function superviseVehicleReturn(custodyId,input,context) {
  return transaction((db)=>{
    const row = db.prepare(`SELECT c.*,a.location_id,sl.site_id,a.internal_code,a.description,a.license_plate,ac.nature AS category_nature
      FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id WHERE c.id=?`).get(custodyId);
    if (!row) throw error(404,'CUSTODY_NOT_FOUND','Custodia no encontrada.');
    if (String(row.category_nature||'').toUpperCase()!=='VEHICULO') throw error(409,'VEHICLE_RETURN_ONLY','Esta inspección no corresponde a un vehículo.');
    assertScope(context.user,{site_id:row.site_id,location_id:row.location_id},'Vehicles.SuperviseReturn');
    if (row.status!=='DEVOLUCION_DECLARADA') throw error(409,'VEHICLE_RETURN_NOT_PENDING','La devolución vehicular ya no está pendiente de inspección.');
    const supervision=db.prepare('SELECT * FROM vehicle_return_supervision WHERE custody_id=?').get(custodyId);
    if (!supervision) throw error(409,'VEHICLE_RETURN_SUPERVISION_MISSING','Esta devolución fue iniciada antes del nuevo flujo de Supervisor y no posee una supervisión F24.');
    if (String(supervision.supervisor_user_id)!==String(context.user.id)) throw error(403,'VEHICLE_RETURN_ASSIGNED_SUPERVISOR_ONLY','Sólo el Supervisor asignado a este usuario puede inspeccionar esta devolución.');
    if (supervision.status!=='PENDIENTE') throw error(409,'VEHICLE_RETURN_ALREADY_SUPERVISED','El Supervisor ya emitió su V°B°.');
    const version=Number(input.version);
    if (!Number.isInteger(version)||version!==Number(supervision.version)) throw error(409,'CONCURRENCY_CONFLICT','La inspección fue modificada por otra operación.');
    const comment=optionalString(input.comment,'comment',{max:2000});
    const technicianChecklist=JSON.parse(supervision.return_checklist_json || '{}');
    const checklistAssessments=normalizeSupervisorChecklistAssessments(technicianChecklist,input.checklistAssessments);
    const checklistSafetyRows=checklistAssessments.filter((item)=>item.safety);
    // Compatibilidad de API F24: safetyObservation sólo se acepta como observación general fuera del checklist.
    const generalSafety=input.generalSafetyObservation===true || input.generalSafetyObservation===1 || String(input.generalSafetyObservation||'').toLowerCase()==='true'
      || input.safetyObservation===true || input.safetyObservation===1 || String(input.safetyObservation||'').toLowerCase()==='true';
    if (generalSafety && (!comment || comment.trim().length<3)) throw error(422,'VEHICLE_SAFETY_COMMENT_REQUIRED','Una observación general de Seguridad requiere un comentario del Supervisor.');
    const safety=generalSafety || checklistSafetyRows.length>0;
    const observedChecklistRows=checklistAssessments.filter((item)=>item.supervisorValue==='OBSERVACION');
    const checklistDecisionSummary=observedChecklistRows.map((item)=>`${item.label}${item.safety?' [SEGURIDAD]':''}: ${item.comment}`).join(' | ');
    const decisionSummary=[comment,checklistDecisionSummary].filter(Boolean).join(' | ') || 'Checklist inspeccionado sin observaciones.';
    const now=nowIso();
    let block=null;
    if (safety) {
      const checklistReason=checklistSafetyRows.map((item)=>`${item.label}: ${item.comment}`).join(' | ');
      const generalReason=generalSafety && comment ? `General: ${comment}` : '';
      const reason=`Observación de SEGURIDAD en devolución vehicular por Supervisor: ${[checklistReason,generalReason].filter(Boolean).join(' | ')}`;
      block=createBlockInDb(db,{targetType:'ACTIVO',targetId:row.asset_id,scopeType:'TOTAL',reason,source:'AUTOMATICO',severity:'ALTA'},context,{returnExisting:true,now,scopePermission:'Vehicles.SuperviseReturn'});
      // F25: el bloqueo deriva de al menos un ítem del checklist clasificado Seguridad o de una observación general de Seguridad.
      db.prepare("UPDATE asset SET status='BLOQUEADO',quantity_available=0,version=version+1,updated_at=? WHERE id=?").run(now,row.asset_id);
    }
    for (const item of checklistAssessments) {
      db.prepare(`INSERT INTO vehicle_return_checklist_assessment(id,supervision_id,custody_id,checklist_key,checklist_label_snapshot,technician_value_snapshot,supervisor_value,safety_observation,supervisor_comment,assessed_by_user_id,assessed_at,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(),supervision.id,custodyId,item.key,item.label,item.technicianValue,item.supervisorValue,item.safety?1:0,item.comment,context.user.id,now,now);
    }
    const changed=db.prepare(`UPDATE vehicle_return_supervision SET status='APROBADA',supervisor_comment=?,safety_observation=?,security_block_id=?,inspected_at=?,inspected_by_user_id=?,warehouse_authorized_at=?,decision_correlation_id=?,version=version+1,updated_at=?
      WHERE id=? AND version=? AND status='PENDIENTE'`).run(comment,safety?1:0,block?.id||null,now,context.user.id,now,context.correlationId,now,supervision.id,version);
    if (changed.changes!==1) throw error(409,'CONCURRENCY_CONFLICT','Conflicto al registrar el V°B° del Supervisor.');
    db.prepare(`INSERT INTO vehicle_return_supervision_event(id,supervision_id,custody_id,event_type,actor_user_id,from_status,to_status,comment,safety_observation,block_id,correlation_id,occurred_at,created_at)
      VALUES (?,?,?,?,?,'PENDIENTE','APROBADA',?,?,?,?,?,?)`).run(randomUUID(),supervision.id,custodyId,safety?'SEGURIDAD_BLOQUEADA':'VISTO_BUENO',context.user.id,decisionSummary,safety?1:0,block?.id||null,context.correlationId,now,now);
    db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
      VALUES (?,?, 'DEVOLUCION_DECLARADA','DEVOLUCION_DECLARADA',?,?,?,?,?)`).run(randomUUID(),custodyId,context.user.id,
        safety ? `V°B° de Supervisor con observación de SEGURIDAD. Vehículo bloqueado. ${decisionSummary}` : `V°B° de Supervisor. Habilitado para recepción de llaves por pañol. ${decisionSummary}`,
        now,context.correlationId,now);
    enqueueNotification({recipientUserId:supervision.requester_user_id,type:'VEHICLE_RETURN_SUPERVISION',channel:'IN_APP',
      subject:safety?'V°B° otorgado · vehículo bloqueado por Seguridad':'V°B° otorgado para devolución del vehículo',
      body:safety?`El Supervisor aprobó la entrega de llaves al pañol y clasificó una observación como Seguridad. El vehículo quedó bloqueado.`:`El Supervisor otorgó el V°B°. Entregá las llaves al pañol para finalizar la devolución.`,
      entityType:'CUSTODY',entityId:custodyId,dedupKey:`vehicle-return-supervision-decision:${custodyId}`},db);
    appendAudit({actorUserId:context.user.id,actorRole:context.user.roleCodes.join(','),action:'VEHICLE.RETURN_SUPERVISOR_APPROVE',entityType:'vehicle_return_supervision',entityId:supervision.id,
      before:{status:'PENDIENTE'},after:{status:'APROBADA',safetyObservation:safety,comment,checklistObserved:observedChecklistRows.length,checklistSafety:checklistSafetyRows.map((item)=>item.key),securityBlockId:block?.id||null,warehouseAuthorizedAt:now},
      correlationId:context.correlationId,ipAddress:context.ip,equipment:context.userAgent},db);
    return { supervision:vehicleSupervisionRow(db,custodyId), custody:getCustody(custodyId,context.user,true) };
  });
}

function saveVehicleReturnPhoto(custodyId,input,context) {
  const detail = getVehicleReturnDetail(custodyId,context.user);
  if (!detail.returnDetail) throw error(409,'VEHICLE_RETURN_NOT_DECLARED','Primero solicitá la devolución del vehículo.');
  return saveOwnedEvidenceDataUrl(input,{ownerType:'CUSTODY',ownerId:custodyId,purpose:'VEHICLE_RETURN_PHOTO'},context,{allowedMimeTypes:['image/png','image/jpeg','image/webp'],maxBytes:runtime.maxImageBytes});
}
function quickReceiveVehicleCustody(custodyId,input,context) {
  const details = getVehicleReturnDetail(custodyId,context.user,'Vehicles.ReceiveReturnKeys');
  const returned = details.returnDetail;
  if (!returned) throw error(409,'VEHICLE_RETURN_NOT_DECLARED','La persona debe iniciar la devolución antes de recibir el vehículo.');
  if (!details.supervision || details.supervision.status!=='APROBADA') throw error(409,'VEHICLE_SUPERVISOR_APPROVAL_REQUIRED','El Supervisor asignado debe dar el V°B° antes de que el pañol reciba las llaves.');
  const supervisorSafety = Number(details.supervision?.safety_observation||0)===1;
  const supervisorObserved = Boolean(String(details.supervision?.supervisor_comment || '').trim());
  const supervisorChecklistObserved = Array.isArray(details.supervision?.checklistAssessments) && details.supervision.checklistAssessments.some((item)=>String(item.supervisor_value||'').toUpperCase()==='OBSERVACION');
  const declaredObserved = Number(returned.problem_reported||0)===1 || String(returned.return_condition).toUpperCase()!=='CONFORME';
  // F25: una observación no-seguridad queda OBSERVADA; sólo la clasificación Seguridad bloquea.
  const condition = supervisorSafety || supervisorObserved || supervisorChecklistObserved || declaredObserved ? 'OBSERVADO' : 'CONFORME';
  // El comentario del técnico nunca se reutiliza como comentario del pañolero.
  const notes = String(input.notes || '').trim() || null;
  return receiveCustody(custodyId,{version:Number(input.version),receivedAt:input.receivedAt||nowIso(),condition,notes,idempotencyKey:input.idempotencyKey},context);
}
module.exports={createVehicleRequest,saveVehicleRequestPhoto,getVehicleRequestDetail,getVehicleReturnDetail,quickHandoverVehicleRequest,declareVehicleReturn,superviseVehicleReturn,saveVehicleReturnPhoto,quickReceiveVehicleCustody};
