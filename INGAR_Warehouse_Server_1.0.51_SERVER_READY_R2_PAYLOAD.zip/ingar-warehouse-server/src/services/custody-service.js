'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const { userHasScope } = require('./request-service');
const { scopeWhere } = require('../security/scope');
const { openIncidentInDb, assertOperationAllowed } = require('./incident-service');
const { syncCustodyOperationalAlerts, notifyCustodyIncidentToOperators } = require('./custody-alert-service');
const { requiresRequesterReturnInitiation, canWarehouseReceiveFromStatus } = require('../config/operational-model');
const { createReturnReceiptInDb, getReturnReceiptMetadata, getReturnReceiptBytes } = require('./return-receipt-service');
const { returnKitComponentsInDb } = require('./extended-modules-service');
const { evaluateReturnDeclarationPolicy, evaluateReceptionPolicy, strongestReturnCondition } = require('./return-reception-policy-service');
const { hasPermission } = require('./permission-service');

const OPEN_STATUSES = new Set(['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE']);
const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);

function error(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function requireScope(user, siteId, locationId, permission) {
  if (!userHasScope(user, siteId, locationId, permission)) throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
}

function iso(value, field, required = false) {
  if ((value === null || value === undefined || value === '') && !required) return null;
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) throw error(422, 'DATE_INVALID', `Fecha inválida: ${field}.`, [{ field, message: 'Fecha y hora inválidas.' }]);
  return date.toISOString();
}

function addCustodyEvent(db, custodyId, fromStatus, toStatus, actorUserId, reason, correlationId, now) {
  db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(randomUUID(), custodyId, fromStatus || null, toStatus, actorUserId || null, reason || null, now, correlationId, now);
}

function custodySelect() {
  return `SELECT c.*, a.internal_code, a.description, a.serial_number, a.license_plate, a.location_id, a.category_id, a.quantity_total, a.quantity_available, a.photo_evidence_id,
    a.status AS asset_status, a.version AS asset_version, a.active AS asset_active,
    ac.code AS category_code, ac.name AS category_name, ac.nature AS category_nature, ac.requires_inspection, ac.requires_return,
    p.full_name AS custodian_name, p.document_number AS custodian_document, r.request_number, s.id AS site_id, s.code AS site_code, s.name AS site_name,
    sl.code AS location_code, sl.name AS location_name
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN person p ON p.id=c.person_id
    JOIN request r ON r.id=c.request_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id`;
}

function hydrate(db, row) {
  if (!row) return null;
  const dueMs = row.due_at ? new Date(row.due_at).getTime() : null;
  const referenceMs = row.closed_at ? new Date(row.closed_at).getTime() : Date.now();
  const overdueSeconds = Number.isFinite(dueMs) ? Math.max(0, Math.floor((referenceMs - dueMs) / 1000)) : 0;
  const returnRecord = db.prepare('SELECT * FROM custody_return_record WHERE custody_id=?').get(row.id) || null;
  const returnPortions = db.prepare(`SELECT crp.*,ua.username AS recorded_by_username,p.full_name AS recorded_by_name
    FROM custody_return_portion crp
    JOIN user_account ua ON ua.id=crp.recorded_by_user_id
    JOIN person p ON p.id=ua.person_id
    WHERE crp.custody_id=? ORDER BY crp.received_at,crp.created_at`).all(row.id);
  const returnedQuantity = returnPortions.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const quantityOutstanding = Math.max(0, Number(row.quantity || 0) - returnedQuantity);
  const quantityReturnDeclarations = String(row.category_nature || '').toUpperCase() === 'CANTIDAD'
    ? db.prepare(`SELECT qrd.*,ua.username AS declared_by_username,p.full_name AS declared_by_name
      FROM custody_quantity_return_declaration qrd JOIN user_account ua ON ua.id=qrd.declared_by_user_id JOIN person p ON p.id=ua.person_id
      WHERE qrd.custody_id=? ORDER BY qrd.declared_at`).all(row.id)
    : [];
  const returnDeclaration = String(row.category_nature || '').toUpperCase() === 'CANTIDAD'
    ? (quantityReturnDeclarations.find((item) => item.status === 'PENDIENTE') || null)
    : (db.prepare('SELECT * FROM custody_return_declaration WHERE custody_id=?').get(row.id) || null);
  const receptionReview = db.prepare('SELECT * FROM custody_reception_review WHERE custody_id=?').get(row.id) || null;
  const vehicleReturnSupervision = String(row.category_nature || '').toUpperCase() === 'VEHICULO'
    ? (db.prepare(`SELECT vrs.*,sp.full_name AS supervisor_name,rp.full_name AS requester_name,
        ibu.username AS inspected_by_username,wbu.username AS warehouse_received_by_username
      FROM vehicle_return_supervision vrs
      JOIN person sp ON sp.id=vrs.supervisor_person_id
      JOIN person rp ON rp.id=vrs.requester_person_id
      LEFT JOIN user_account ibu ON ibu.id=vrs.inspected_by_user_id
      LEFT JOIN user_account wbu ON wbu.id=vrs.warehouse_received_by_user_id
      WHERE vrs.custody_id=?`).get(row.id) || null)
    : null;
  if (vehicleReturnSupervision) {
    vehicleReturnSupervision.returnChecklist = safeJsonObject(vehicleReturnSupervision.return_checklist_json);
    vehicleReturnSupervision.events = db.prepare(`SELECT vre.*,ua.username,p.full_name AS actor_name
      FROM vehicle_return_supervision_event vre JOIN user_account ua ON ua.id=vre.actor_user_id JOIN person p ON p.id=ua.person_id
      WHERE vre.supervision_id=? ORDER BY vre.occurred_at`).all(vehicleReturnSupervision.id);
  }
  const returnReceipt = getReturnReceiptMetadata(db, row.id);
  const returnEvidence = db.prepare(`SELECT id,filename,mime_type,size,created_at,purpose FROM file_evidence
    WHERE owner_type='CUSTODY' AND owner_id=? AND lifecycle_state='ACTIVE' AND purpose IN ('SERIALIZED_RETURN_PHOTO','VEHICLE_RETURN_PHOTO') ORDER BY created_at`).all(row.id);
  return {
    ...row,
    overdue: Boolean(row.due_at && row.status !== 'DEVOLUCION_DECLARADA' && OPEN_STATUSES.has(row.status) && dueMs < Date.now()),
    overdue_seconds: overdueSeconds,
    timing_status: returnRecord?.timing_status || (row.due_at ? (overdueSeconds > 0 ? 'FUERA_DE_TERMINO' : 'EN_TERMINO') : 'SIN_VENCIMIENTO'),
    returnRecord,
    returnPortions,
    returned_quantity: returnedQuantity,
    quantity_outstanding: quantityOutstanding,
    quantityReturnDeclarations,
    returnDeclaration,
    receptionReview,
    vehicleReturnSupervision,
    returnReceipt,
    returnEvidence,
    events: db.prepare(`SELECT ce.*, ua.username FROM custody_event ce LEFT JOIN user_account ua ON ua.id=ce.actor_user_id WHERE ce.custody_id=? ORDER BY ce.occurred_at`).all(row.id),
    inspections: db.prepare(`SELECT i.*, ua.username, p.full_name AS inspector_name FROM inspection i JOIN user_account ua ON ua.id=i.inspector_user_id JOIN person p ON p.id=ua.person_id WHERE i.custody_id=? ORDER BY i.occurred_at`).all(row.id),
    handovers: db.prepare(`SELECT h.* FROM handover h WHERE h.id IN (SELECT opened_by_handover_id FROM custody WHERE id=? UNION SELECT closed_by_handover_id FROM custody WHERE id=? AND closed_by_handover_id IS NOT NULL) ORDER BY h.occurred_at`).all(row.id, row.id),
    transfers: db.prepare(`SELECT ct.*, fp.full_name AS from_name, tp.full_name AS to_name FROM custody_transfer ct JOIN person fp ON fp.id=ct.from_person_id JOIN person tp ON tp.id=ct.to_person_id WHERE ct.custody_id=? ORDER BY ct.requested_at`).all(row.id),
    incidents: db.prepare('SELECT * FROM incident WHERE custody_id=? ORDER BY opened_at').all(row.id)
  };
}


function safeJsonObject(value) {
  if (value && typeof value === 'object') return value;
  try {
    const parsed = JSON.parse(String(value || '{}'));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function getCustody(id, user, allowAll = false) {
  const db = getDb();
  const row = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
  if (!row) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
  if (!allowAll && row.person_id !== user.personId) throw error(403, 'CUSTODY_FORBIDDEN', 'No puede consultar esta custodia.');
  requireScope(user, row.site_id, row.location_id, allowAll ? 'Custody.ReadAll' : 'Custody.ReadOwn');
  const custody = hydrate(db, row);
  const nature = String(row.category_nature || '').toUpperCase();
  if (nature === 'VEHICULO') {
    const request = db.prepare('SELECT * FROM vehicle_request_detail WHERE request_id=?').get(row.request_id) || null;
    const returned = db.prepare('SELECT * FROM vehicle_return_detail WHERE custody_id=?').get(id) || null;
    custody.vehicleRequestDetail = request ? { ...request, departureChecklist: safeJsonObject(request.departure_checklist_json) } : null;
    custody.vehicleReturnDetail = returned ? { ...returned, returnChecklist: safeJsonObject(returned.return_checklist_json) } : null;
  }
  if (nature === 'KIT') {
    custody.kitReturnComponents = db.prepare(`SELECT kcc.*,a.internal_code,a.description,ac.nature AS category_nature
      FROM kit_custody_component kcc JOIN asset a ON a.id=kcc.component_asset_id JOIN asset_category ac ON ac.id=a.category_id
      WHERE kcc.custody_id=? ORDER BY a.internal_code`).all(id);
  }
  return custody;
}

function listCustodiesPage(filters, user, allowAll = false) {
  const db = getDb();
  const where = [];
  const params = [];
  const permission = allowAll ? 'Custody.ReadAll' : 'Custody.ReadOwn';
  const scope = scopeWhere(user, permission, 's.id', 'a.location_id', db);
  where.push(`(${scope.sql})`); params.push(...scope.params);
  if (!allowAll) { where.push('c.person_id=?'); params.push(user.personId); }
  const statuses = String(filters.statuses || '').split(',').map((value) => value.trim().toUpperCase()).filter(Boolean);
  if (statuses.length) { where.push(`c.status IN (${statuses.map(() => '?').join(',')})`); params.push(...statuses); }
  else if (filters.status) { where.push('c.status=?'); params.push(String(filters.status).toUpperCase()); }
  if (filters.personId) { where.push('c.person_id=?'); params.push(filters.personId); }
  if (filters.siteId) { where.push('s.id=?'); params.push(filters.siteId); }
  if (filters.locationId) { where.push('a.location_id=?'); params.push(filters.locationId); }
  if (filters.overdue === 'true' || filters.overdue === true) { where.push("c.status IN ('ABIERTA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE') AND c.due_at IS NOT NULL AND c.due_at < ?"); params.push(new Date().toISOString()); }
  if (filters.dueFrom) { where.push('c.due_at>=?'); params.push(new Date(filters.dueFrom).toISOString()); }
  if (filters.dueTo) { where.push('c.due_at<?'); params.push(new Date(filters.dueTo).toISOString()); }
  if (filters.dueBefore) { where.push('c.due_at<?'); params.push(new Date(filters.dueBefore).toISOString()); }
  if (filters.openedFrom) { where.push('c.opened_at>=?'); params.push(new Date(filters.openedFrom).toISOString()); }
  if (filters.openedTo) { where.push('c.opened_at<?'); params.push(new Date(filters.openedTo).toISOString()); }
  if (filters.closedFrom) { where.push('c.closed_at>=?'); params.push(new Date(filters.closedFrom).toISOString()); }
  if (filters.closedTo) { where.push('c.closed_at<?'); params.push(new Date(filters.closedTo).toISOString()); }
  if (filters.search) { where.push('(a.internal_code LIKE ? OR a.description LIKE ? OR p.full_name LIKE ? OR r.request_number LIKE ?)'); const query = `%${String(filters.search).trim()}%`; params.push(query, query, query, query); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = Number(db.prepare(`SELECT COUNT(*) AS n FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN person p ON p.id=c.person_id JOIN request r ON r.id=c.request_id JOIN storage_location sl ON sl.id=a.location_id JOIN site s ON s.id=sl.site_id ${whereSql}`).get(...params)?.n || 0);
  const items = db.prepare(`${custodySelect()} ${whereSql} ORDER BY CASE WHEN c.status='INCIDENTE' THEN 0 ELSE 1 END, c.due_at, c.opened_at DESC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset).map((row) => hydrate(db, row));
  return { items, total, limit, offset };
}

function listCustodies(filters, user, allowAll = false) {
  return listCustodiesPage(filters, user, allowAll).items;
}

function declareReturn(id, input, context, allowAny = false, options = {}) {
  return transaction((db) => {
    const current = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
    if (!current) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
    const requesterInitiated = requiresRequesterReturnInitiation(current.category_nature);
    if (requesterInitiated && current.person_id !== context.user.personId) {
      throw error(403, 'RETURN_MUST_BE_INITIATED_BY_CUSTODIAN', 'La devolución debe iniciarla la persona que tiene el bien asignado.');
    }
    if (!allowAny && current.person_id !== context.user.personId) throw error(403, 'CUSTODY_FORBIDDEN', 'No puede declarar esta devolución.');
    requireScope(context.user, current.site_id, current.location_id, requesterInitiated ? 'Custody.ReturnOwn' : (allowAny ? 'Custody.ReturnAny' : 'Custody.ReturnOwn'));
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La custodia fue modificada por otra operación.');
    if (current.status !== 'ABIERTA') throw error(409, 'CUSTODY_RETURN_NOT_ALLOWED', 'La custodia no admite declaración de devolución.');
    const requestedDeclarationCondition = String(input.condition || 'CONFORME').toUpperCase();
    if (!['CONFORME', 'OBSERVADO', 'DANADO', 'INCOMPLETO'].includes(requestedDeclarationCondition)) throw error(422, 'RETURN_DECLARATION_CONDITION_INVALID', 'Indicá cómo devolvés el bien.');
    const notes = optionalString(input.notes, 'notes', { max: 1000 });
    // F22: la declaración del técnico y la recepción del pañol usan reglas separadas pero
    // consistentes. En bienes no vehiculares, escribir un comentario convierte como mínimo
    // la declaración en OBSERVADO. VEHICULO queda fuera: su seguridad se resolverá por Supervisor.
    const declarationPolicy = evaluateReturnDeclarationPolicy({
      nature: current.category_nature,
      condition: requestedDeclarationCondition,
      problemReported: input.problemReported,
      notes
    });
    const condition = declarationPolicy.effectiveCondition;
    const commentImpliesProblem = declarationPolicy.commentImpliesProblem;
    const problemReported = declarationPolicy.problemReported;
    if ((problemReported || condition !== 'CONFORME') && !notes) throw error(422, 'RETURN_DECLARATION_NOTES_REQUIRED', 'Contanos brevemente qué problema tiene el bien.');
    const requestedReason = String(input.reason || '').trim();
    let reason = requestedReason || notes || 'Devolución solicitada por la persona responsable.';
    if (reason.length < 5 && notes) reason = `Devolución informada. ${notes}`;
    if (reason.length < 5 || reason.length > 1000) throw error(422, 'RETURN_DECLARATION_REASON_INVALID', 'El comentario de devolución no es válido.');
    let quantityReturnRequest = null;
    const isQuantityReturn = String(current.category_nature || '').toUpperCase() === 'CANTIDAD' && Number(current.requires_return || 0) === 1;
    if (isQuantityReturn) {
      const prior = db.prepare('SELECT COALESCE(SUM(quantity),0) AS n FROM custody_return_portion WHERE custody_id=?').get(id);
      const outstanding = Math.max(0, Number(current.quantity || 0) - Number(prior?.n || 0));
      const requestedQuantity = input.returnQuantity === undefined || input.returnQuantity === null || input.returnQuantity === '' ? outstanding : Number(input.returnQuantity);
      if (!Number.isFinite(requestedQuantity) || requestedQuantity <= 0) throw error(422, 'RETURN_QUANTITY_INVALID', 'La cantidad a devolver debe ser mayor que cero.');
      if (requestedQuantity - outstanding > 1e-9) throw error(422, 'RETURN_QUANTITY_EXCEEDS_OUTSTANDING', `La cantidad a devolver supera el saldo pendiente (${outstanding}).`);
      quantityReturnRequest = { requestedQuantity, outstanding };
    }
    const now = new Date().toISOString();
    const changed = db.prepare(`UPDATE custody SET status='DEVOLUCION_DECLARADA',declared_return_at=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status='ABIERTA'`).run(now, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al declarar devolución.');
    addCustodyEvent(db, id, 'ABIERTA', 'DEVOLUCION_DECLARADA', context.user.id, reason, context.correlationId, now);
    if (requesterInitiated) {
      const requestOt = db.prepare('SELECT work_order_reference FROM request WHERE id=?').get(current.request_id)?.work_order_reference || null;
      if (isQuantityReturn) {
        db.prepare(`INSERT INTO custody_quantity_return_declaration(id,custody_id,declared_by_user_id,requested_quantity,condition,problem_reported,notes,status,declared_at,correlation_id,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,'PENDIENTE',?,?,?,?)`).run(randomUUID(), id, context.user.id, quantityReturnRequest.requestedQuantity, condition, problemReported ? 1 : 0, notes, now, context.correlationId, now, now);
      } else {
        db.prepare(`INSERT INTO custody_return_declaration(id,custody_id,declared_by_user_id,condition,problem_reported,notes,declared_at,correlation_id,created_at,work_order_reference_snapshot)
          VALUES (?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(), id, context.user.id, condition, problemReported ? 1 : 0, notes, now, context.correlationId, now, requestOt);
      }
    }
    if (typeof options.afterDeclare === 'function') {
      options.afterDeclare(db, { current, condition, problemReported, notes, now, requesterInitiated });
    }
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'CUSTODY.DECLARE_RETURN', entityType: 'custody', entityId: id,
      before: { status: 'ABIERTA' }, after: { status: 'DEVOLUCION_DECLARADA', declaredReturnAt: now, requestedCondition: requestedDeclarationCondition, condition, problemReported, notes, commentImpliesProblem, returnQuantity: quantityReturnRequest?.requestedQuantity || null }, reason, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    syncCustodyOperationalAlerts(db, id, new Date(now));
    return hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(id));
  });
}

function extendCustody(id, input, context) {
  return transaction((db) => {
    const current = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
    if (!current) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
    requireScope(context.user, current.site_id, current.location_id, 'Custody.Extend');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La custodia fue modificada por otra operación.');
    if (!['ABIERTA', 'DEVOLUCION_DECLARADA'].includes(current.status)) throw error(409, 'CUSTODY_EXTENSION_NOT_ALLOWED', 'La custodia no admite extensión.');
    const dueAt = iso(input.dueAt, 'dueAt', true);
    if (new Date(dueAt).getTime() <= Date.now()) throw error(422, 'CUSTODY_DUE_AT_INVALID', 'El nuevo vencimiento debe ser futuro.');
    if (current.due_at && new Date(dueAt).getTime() <= new Date(current.due_at).getTime()) throw error(422, 'CUSTODY_EXTENSION_INVALID', 'La extensión debe superar el vencimiento vigente.');
    const reason = requiredString(input.reason, 'reason', { min: 5, max: 1000 });
    const now = new Date().toISOString();
    const changed = db.prepare('UPDATE custody SET due_at=?,version=version+1,updated_at=? WHERE id=? AND version=?').run(dueAt, now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al extender custodia.');
    addCustodyEvent(db, id, current.status, current.status, context.user.id, `Vencimiento extendido. ${reason}`, context.correlationId, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'CUSTODY.EXTEND', entityType: 'custody', entityId: id,
      before: { dueAt: current.due_at }, after: { dueAt }, reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    syncCustodyOperationalAlerts(db, id, new Date(now));
    return hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(id));
  });
}

function returnDeclarationForReception(db, custodyId, nature) {
  const normalizedNature = String(nature || '').toUpperCase();
  if (normalizedNature === 'CANTIDAD') {
    return db.prepare(`SELECT id,condition,problem_reported,notes,declared_at,declared_by_user_id,requested_quantity,status
      FROM custody_quantity_return_declaration WHERE custody_id=? AND status='PENDIENTE' ORDER BY declared_at DESC LIMIT 1`).get(custodyId) || null;
  }
  const declaration = db.prepare('SELECT condition,problem_reported,notes,declared_at,declared_by_user_id FROM custody_return_declaration WHERE custody_id=?').get(custodyId);
  if (declaration) return declaration;
  if (normalizedNature !== 'VEHICULO') return null;
  const vehicle = db.prepare('SELECT return_condition AS condition,problem_reported,notes,declared_at,declared_by_user_id FROM vehicle_return_detail WHERE custody_id=?').get(custodyId);
  return vehicle || null;
}

function getKitReturnDetail(id, user, permission = 'Warehouse.Operate') {
  const db = getDb();
  const current = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
  if (!current) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
  if (String(current.category_nature || '').toUpperCase() !== 'KIT') throw error(422, 'KIT_CUSTODY_REQUIRED', 'La custodia seleccionada no corresponde a un kit.');
  requireScope(user, current.site_id, current.location_id, permission);
  const custody = hydrate(db, current);
  const components = db.prepare(`SELECT kcc.*,a.internal_code,a.description,ac.nature AS category_nature
    FROM kit_custody_component kcc JOIN asset a ON a.id=kcc.component_asset_id JOIN asset_category ac ON ac.id=a.category_id
    WHERE kcc.custody_id=? ORDER BY a.internal_code`).all(id);
  if (!components.length) throw error(404, 'KIT_CUSTODY_COMPONENTS_NOT_FOUND', 'No existen componentes entregados para esta custodia de kit.');
  return { custody, components };
}

function receiveCustody(id, input, context) {
  const idempotencyKey = requiredString(input.idempotencyKey, 'idempotencyKey', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ });
  return transaction((db) => {
    const existing = db.prepare("SELECT id FROM handover WHERE idempotency_key=? AND type='RECEPCION'").get(idempotencyKey);
    if (existing) {
      const linkedFinal = db.prepare('SELECT id FROM custody WHERE closed_by_handover_id=?').get(existing.id);
      const linkedPortion = db.prepare('SELECT custody_id FROM custody_return_portion WHERE handover_id=?').get(existing.id);
      const linkedCustodyId = linkedFinal?.id || linkedPortion?.custody_id || null;
      if (!linkedCustodyId || linkedCustodyId !== id) throw error(409, 'IDEMPOTENCY_KEY_REUSED', 'La clave de idempotencia pertenece a otra recepción.');
      const portion = linkedPortion ? db.prepare('SELECT * FROM custody_return_portion WHERE handover_id=?').get(existing.id) : null;
      return { custody: hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(id)), partialReturn: portion, idempotent: true };
    }
    const current = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
    if (!current) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
    requireScope(context.user, current.site_id, current.location_id, 'Warehouse.Operate');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La custodia fue modificada por otra operación.');
    if (!canWarehouseReceiveFromStatus(current.category_nature, current.status)) {
      if (requiresRequesterReturnInitiation(current.category_nature) && current.status === 'ABIERTA') {
        throw error(409, 'SERIAL_RETURN_NOT_DECLARED', 'La persona responsable debe iniciar la devolución antes de que el pañol pueda recibir físicamente este bien.');
      }
      throw error(409, 'CUSTODY_RECEIVE_NOT_ALLOWED', 'La custodia no admite recepción.');
    }
    const requestedCondition = String(input.condition || '').toUpperCase();
    if (!['CONFORME', 'OBSERVADO', 'DANADO', 'INCOMPLETO'].includes(requestedCondition)) throw error(422, 'INSPECTION_CONDITION_INVALID', 'Condición de recepción inválida.');
    const nature = String(current.category_nature || '').toUpperCase();
    const isQuantityReturn = nature === 'CANTIDAD' && Number(current.requires_return || 0) === 1;
    const priorPortions = isQuantityReturn
      ? db.prepare('SELECT * FROM custody_return_portion WHERE custody_id=? ORDER BY received_at,created_at').all(id)
      : [];
    const pendingQuantityDeclaration = isQuantityReturn
      ? db.prepare(`SELECT * FROM custody_quantity_return_declaration WHERE custody_id=? AND status='PENDIENTE' ORDER BY declared_at DESC LIMIT 1`).get(id)
      : null;
    if (isQuantityReturn && !pendingQuantityDeclaration) throw error(409, 'QUANTITY_RETURN_NOT_DECLARED', 'La persona responsable debe indicar la cantidad que va a devolver antes de la recepción física.');
    const alreadyReturned = priorPortions.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
    const remainingBefore = Math.max(0, Number(current.quantity || 0) - alreadyReturned);
    if (isQuantityReturn && remainingBefore <= 1e-9) throw error(409, 'CUSTODY_ALREADY_RETURNED', 'La cantidad entregada ya fue devuelta en su totalidad.');
    let receivedQuantity = Number(current.quantity || 0);
    if (isQuantityReturn) {
      receivedQuantity = input.returnQuantity === undefined || input.returnQuantity === null || input.returnQuantity === ''
        ? Number(pendingQuantityDeclaration.requested_quantity)
        : Number(input.returnQuantity);
      if (!Number.isFinite(receivedQuantity) || receivedQuantity <= 0) throw error(422, 'RETURN_QUANTITY_INVALID', 'La cantidad a recibir debe ser mayor que cero.');
      if (receivedQuantity - remainingBefore > 1e-9) throw error(422, 'RETURN_QUANTITY_EXCEEDS_OUTSTANDING', `La cantidad a recibir supera el saldo pendiente (${remainingBefore}).`);
      if (receivedQuantity - Number(pendingQuantityDeclaration.requested_quantity) > 1e-9) throw error(422, 'RETURN_QUANTITY_EXCEEDS_DECLARED', `La cantidad recibida supera la cantidad declarada (${pendingQuantityDeclaration.requested_quantity}).`);
      receivedQuantity = Math.min(receivedQuantity, remainingBefore);
    }
    const remainingAfter = isQuantityReturn ? Math.max(0, remainingBefore - receivedQuantity) : 0;
    const isFinalQuantityReturn = !isQuantityReturn || remainingAfter <= 1e-9;

    let vehicleSupervision = null;
    if (nature === 'VEHICULO') {
      if (!hasPermission(context.user, 'Vehicles.ReceiveReturnKeys')) {
        throw error(403, 'VEHICLE_KEYS_RECEIVE_FORBIDDEN', 'La recepción de llaves debe realizarla un usuario de pañol autorizado.');
      }
      vehicleSupervision = db.prepare('SELECT * FROM vehicle_return_supervision WHERE custody_id=?').get(id) || null;
      if (!vehicleSupervision || vehicleSupervision.status !== 'APROBADA') {
        throw error(409, 'VEHICLE_SUPERVISOR_APPROVAL_REQUIRED', 'El Supervisor asignado debe dar el V°B° antes de que el pañol reciba las llaves.');
      }
    }
    if (nature !== 'VEHICULO' && input.reviewConfirmed !== true) {
      throw error(422, 'WAREHOUSE_RECEPTION_REVIEW_REQUIRED', 'Antes de aceptar la devolución, el pañolero debe revisar el bien y confirmar la recepción.');
    }
    const explicitWarehouseComment = optionalString(input.warehouseComment, 'warehouseComment', { max: 2000 });
    const legacyWarehouseComment = nature !== 'VEHICULO' ? optionalString(input.notes, 'notes', { max: 2000 }) : null;
    const warehouseComment = explicitWarehouseComment || legacyWarehouseComment || null;
    const declaration = returnDeclarationForReception(db, id, current.category_nature);
    const declaredCondition = declaration
      ? (Number(declaration.problem_reported || 0) === 1 && String(declaration.condition || 'CONFORME').toUpperCase() === 'CONFORME' ? 'OBSERVADO' : String(declaration.condition || 'CONFORME').toUpperCase())
      : 'CONFORME';
    let vehicleReturn = null;
    if (nature === 'VEHICULO') {
      vehicleReturn = db.prepare('SELECT * FROM vehicle_return_detail WHERE custody_id=?').get(id) || null;
      if (!vehicleReturn) throw error(409, 'VEHICLE_RETURN_NOT_DECLARED', 'La persona debe declarar la devolución del vehículo antes de la recepción física.');
    }
    let kitReturn = null;
    if (nature === 'KIT') {
      kitReturn = returnKitComponentsInDb(db, id, {
        components: input.kitComponents,
        reason: input.notes || declaration?.notes || 'Recepción física del kit'
      }, context, { permission: 'Warehouse.Operate', finalReceipt: true });
    }
    const supervisorSafetyObservation = nature === 'VEHICULO' && Number(vehicleSupervision?.safety_observation || 0) === 1;
    const receptionPolicy = evaluateReceptionPolicy({ nature, requestedCondition, declaredCondition, kitCondition: kitReturn?.condition, warehouseComment, vehicleSafetyObservation: supervisorSafetyObservation });
    const commentForcesObservation = receptionPolicy.commentForcesObservation;
    const condition = receptionPolicy.effectiveCondition;
    const declarationNotes = optionalString(declaration?.notes, 'declarationNotes', { max: 2000 });
    const vehicleNotes = nature === 'VEHICULO' ? optionalString(input.notes, 'notes', { max: 2000 }) : null;
    const operatorNarrative = warehouseComment || vehicleNotes || null;
    const declarationReference = condition !== 'CONFORME' && declarationNotes
      ? 'Condición no conforme originada en la declaración previa del técnico; ver declaración de devolución.'
      : null;
    const supervisorSafetyReference = supervisorSafetyObservation
      ? `Observación de SEGURIDAD clasificada por el Supervisor: ${vehicleSupervision.supervisor_comment}`
      : null;
    const supervisorObservationReference = nature === 'VEHICULO' && !supervisorSafetyObservation && String(vehicleSupervision?.supervisor_comment || '').trim()
      ? `Observación NO SEGURIDAD registrada por el Supervisor: ${vehicleSupervision.supervisor_comment}`
      : null;
    const notes = operatorNarrative || supervisorSafetyReference || supervisorObservationReference || declarationReference;
    if (condition !== 'CONFORME' && !notes) throw error(422, 'INSPECTION_NOTES_REQUIRED', 'Una recepción observada requiere detalle.');
    const incidentNarrative = supervisorSafetyReference || operatorNarrative
      || (declarationNotes ? `Anomalía declarada previamente por el técnico: ${declarationNotes}` : null);
    const recordedAt = new Date().toISOString();
    const receivedAt = iso(input.receivedAt, 'receivedAt') || recordedAt;
    const receivedMs = new Date(receivedAt).getTime();
    if (receivedMs < new Date(current.opened_at).getTime()) throw error(422, 'RECEIVED_AT_BEFORE_HANDOVER', 'La devolución no puede ser anterior a la entrega.');
    if (receivedMs > Date.now() + 5 * 60_000) throw error(422, 'RECEIVED_AT_FUTURE', 'La devolución no puede registrarse con fecha futura.');
    const dueMs = current.due_at ? new Date(current.due_at).getTime() : null;
    const overdueSeconds = Number.isFinite(dueMs) ? Math.max(0, Math.floor((receivedMs - dueMs) / 1000)) : 0;
    const timingStatus = current.due_at ? (overdueSeconds > 0 ? 'FUERA_DE_TERMINO' : 'EN_TERMINO') : 'SIN_VENCIMIENTO';
    const handoverId = randomUUID();
    const requestOt = db.prepare('SELECT work_order_reference FROM request WHERE id=?').get(current.request_id)?.work_order_reference || null;
    db.prepare(`INSERT INTO handover(id,request_id,type,operator_user_id,person_id,occurred_at,observations,acceptance_method,acceptance_hash,acceptance_evidence_id,idempotency_key,correlation_id,created_at,work_order_reference_snapshot)
      VALUES (?,?, 'RECEPCION',?,?,?,?, 'NINGUNA',NULL,NULL,?,?,?,?)`).run(handoverId, current.request_id, context.user.id, current.person_id, receivedAt, operatorNarrative, idempotencyKey, context.correlationId, recordedAt, requestOt);
    db.prepare(`INSERT INTO handover_item(id,handover_id,request_item_id,asset_id,quantity,condition,notes,created_at) VALUES (?,?,?,?,?,?,?,?)`)
      .run(randomUUID(), handoverId, current.request_item_id, current.asset_id, receivedQuantity, condition, operatorNarrative, recordedAt);
    addCustodyEvent(db, id, current.status, 'RECEPCION_PENDIENTE', context.user.id,
      `${isQuantityReturn && !isFinalQuantityReturn ? `Recepción parcial de ${receivedQuantity}; saldo previo ${remainingBefore}. ` : 'Recepción física iniciada. '}${timingStatus === 'FUERA_DE_TERMINO' ? `Atraso: ${overdueSeconds} segundos.` : 'Dentro del período previsto.'}`,
      context.correlationId, receivedAt);
    const hasAnomaly = receptionPolicy.blocksAsset;
    const hasActiveOperationalBlock = Boolean(db.prepare(`SELECT 1 FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO' LIMIT 1`).get(current.asset_id));
    const blockedAfterReceipt = hasAnomaly || hasActiveOperationalBlock;
    const result = hasAnomaly ? 'INCIDENTE' : 'APROBADO';
    const inspectionId = randomUUID();
    db.prepare(`INSERT INTO inspection(id,asset_id,custody_id,handover_id,inspector_user_id,phase,condition,result,notes,occurred_at,created_at)
      VALUES (?,?,?,?,?,'RECEPCION',?,?,?,?,?)`).run(inspectionId, current.asset_id, id, handoverId, context.user.id, condition, result, notes, receivedAt, recordedAt);
    if (SERIAL_NATURES.has(current.category_nature)) {
      db.prepare(`UPDATE asset SET quantity_available=1,status=?,custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?`)
        .run(blockedAfterReceipt ? 'BLOQUEADO' : 'DISPONIBLE', recordedAt, current.asset_id);
    } else {
      const changedAsset = db.prepare(`UPDATE asset SET quantity_available=MIN(quantity_total,quantity_available+?),status=?,custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?`)
        .run(receivedQuantity, blockedAfterReceipt ? 'BLOQUEADO' : 'DISPONIBLE', recordedAt, current.asset_id);
      if (changedAsset.changes !== 1) throw error(409, 'ASSET_RETURN_CONFLICT', 'No fue posible reintegrar la cantidad recibida.');
    }
    if (vehicleReturn) {
      const existingVehicleReception = db.prepare("SELECT id FROM vehicle_operation WHERE custody_id=? AND operation_type='RECEPCION' ORDER BY created_at DESC LIMIT 1").get(id);
      if (!existingVehicleReception) {
        db.prepare(`INSERT INTO vehicle_operation(id,asset_id,custody_id,handover_id,driver_person_id,operation_type,odometer,hourmeter,fuel_level_percent,condition,checklist_json,notes,operator_user_id,occurred_at,correlation_id,created_at)
          VALUES (?,?,?,?,?,'RECEPCION',?,NULL,?,?,?,?,?,?,?,?)`)
          .run(randomUUID(), current.asset_id, id, handoverId, vehicleReturn.driver_person_id, vehicleReturn.return_odometer, vehicleReturn.return_fuel_percent, condition, vehicleReturn.return_checklist_json, notes, context.user.id, receivedAt, context.correlationId, recordedAt);
        db.prepare('UPDATE vehicle_profile SET current_odometer=?,version=version+1,updated_at=? WHERE asset_id=?')
          .run(vehicleReturn.return_odometer, recordedAt, current.asset_id);
        db.prepare('UPDATE asset SET odometer=?,version=version+1,updated_at=? WHERE id=?')
          .run(vehicleReturn.return_odometer, recordedAt, current.asset_id);
        appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.VEHICLE_RECEIVE', entityType: 'custody', entityId: id,
          after: { condition, odometer: vehicleReturn.return_odometer, fuelLevelPercent: vehicleReturn.return_fuel_percent, handoverId }, correlationId: context.correlationId,
          ipAddress: context.ip, equipment: context.userAgent }, db);
      }
    }
    let incident = null;
    if (hasAnomaly) {
      const type = condition === 'DANADO' ? 'DANO' : condition === 'INCOMPLETO' ? 'FALTANTE' : 'CONDICION_INSEGURA';
      const severity = condition === 'OBSERVADO' ? 'MEDIA' : 'ALTA';
      const opened = openIncidentInDb(db, {
        assetId: current.asset_id, custodyId: id, inspectionId, type, severity,
        title: `Anomalía de recepción — ${current.internal_code}`,
        description: incidentNarrative && incidentNarrative.length >= 5 ? incidentNarrative : `Recepción ${condition.toLowerCase()} detectada durante inspección.${operatorNarrative ? ` Comentario del pañolero: ${operatorNarrative}` : ''}`,
        clientIncidentId: `receive:${handoverId}`,
        occurredAt: receivedAt,
        blockCustodian: severity === 'CRITICA' && Boolean(getSetting('incident.autoBlockCustodianOnCritical', true))
      }, context, {
        automatic: true, now: recordedAt, scopePermission: 'Warehouse.Operate',
        assetSnapshot: { status: current.asset_status, quantityAvailable: current.quantity_available, quantityTotal: current.quantity_total,
          custodianPersonId: current.person_id, active: current.asset_active, version: current.asset_version }
      });
      incident = opened.incident;
      if (nature === 'VEHICULO' && vehicleSupervision?.security_block_id) {
        db.prepare(`UPDATE operational_block SET incident_id=COALESCE(incident_id,?),version=version+1,updated_at=? WHERE id=? AND status='ACTIVO'`)
          .run(incident.id, recordedAt, vehicleSupervision.security_block_id);
      }
    }

    let portion = null;
    if (isQuantityReturn) {
      const portionId = randomUUID();
      db.prepare(`INSERT INTO custody_return_portion(id,custody_id,handover_id,inspection_id,incident_id,quantity,remaining_after,is_final,condition,notes,received_at,recorded_by_user_id,correlation_id,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(portionId,id,handoverId,inspectionId,incident?.id||null,receivedQuantity,remainingAfter,isFinalQuantityReturn?1:0,condition,notes,receivedAt,context.user.id,context.correlationId,recordedAt);
      portion = db.prepare('SELECT * FROM custody_return_portion WHERE id=?').get(portionId);
      const declarationUpdate = db.prepare(`UPDATE custody_quantity_return_declaration SET status='ATENDIDA',actual_received_quantity=?,fulfilled_by_portion_id=?,fulfilled_at=?,updated_at=?
        WHERE id=? AND status='PENDIENTE'`).run(receivedQuantity, portionId, receivedAt, recordedAt, pendingQuantityDeclaration.id);
      if (declarationUpdate.changes !== 1) throw error(409, 'QUANTITY_RETURN_DECLARATION_CONFLICT', 'La declaración de devolución cuantitativa ya fue atendida o modificada.');
    }

    if (isQuantityReturn && !isFinalQuantityReturn) {
      const changed = db.prepare(`UPDATE custody SET status='ABIERTA',declared_return_at=NULL,version=version+1,updated_at=? WHERE id=? AND version=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA')`)
        .run(recordedAt,id,version);
      if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al registrar la devolución parcial.');
      addCustodyEvent(db, id, 'RECEPCION_PENDIENTE', 'ABIERTA', context.user.id,
        `Devolución parcial recibida: ${receivedQuantity}. Pendiente: ${remainingAfter}.`, context.correlationId, receivedAt);
      syncCustodyOperationalAlerts(db, id, new Date(recordedAt));
      if (incident) notifyCustodyIncidentToOperators(db, id, incident);
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.RECEIVE_PARTIAL', entityType: 'custody', entityId: id,
        before: { status: current.status, quantityOutstanding: remainingBefore },
        after: { status: 'ABIERTA', quantityReceived: receivedQuantity, quantityReturned: alreadyReturned + receivedQuantity, quantityOutstanding: remainingAfter, condition, inspectionId, incidentId: incident?.id || null },
        correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
      return { custody: hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(id)), partialReturn: portion, returnRecord: null, returnReceipt: null, kitReturn: null, idempotent: false };
    }

    const priorOpenIncident = isQuantityReturn ? db.prepare(`SELECT i.id FROM custody_return_portion crp JOIN incident i ON i.id=crp.incident_id
      WHERE crp.custody_id=? AND i.status NOT IN ('RESUELTO','CERRADO') ORDER BY crp.received_at DESC LIMIT 1`).get(id) : null;
    const target = (hasAnomaly || priorOpenIncident) ? 'INCIDENTE' : 'CERRADA';
    const changed = db.prepare(`UPDATE custody SET status=?,closed_by_handover_id=?,closed_at=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA')`)
      .run(target, handoverId, receivedAt, recordedAt, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al recibir custodia.');
    addCustodyEvent(db, id, 'RECEPCION_PENDIENTE', target, context.user.id,
      `${target === 'INCIDENTE' ? 'Recepción con anomalía; existe un incidente asociado.' : 'Recepción e inspección conformes.'} ${timingStatus === 'FUERA_DE_TERMINO' ? `Devolución fuera de término por ${overdueSeconds} segundos.` : 'Devolución en término.'}`,
      context.correlationId, receivedAt);
    if (nature === 'VEHICULO' && vehicleSupervision) {
      const receivedUpdate = db.prepare(`UPDATE vehicle_return_supervision SET warehouse_received_at=?,warehouse_received_by_user_id=?,warehouse_handover_id=?,warehouse_correlation_id=?,version=version+1,updated_at=?
        WHERE id=? AND status='APROBADA' AND warehouse_received_at IS NULL`).run(receivedAt, context.user.id, handoverId, context.correlationId, recordedAt, vehicleSupervision.id);
      if (receivedUpdate.changes !== 1) throw error(409, 'VEHICLE_WAREHOUSE_RECEIPT_CONFLICT', 'La recepción vehicular ya fue registrada o cambió durante la operación.');
      db.prepare(`INSERT INTO vehicle_return_supervision_event(id,supervision_id,custody_id,event_type,actor_user_id,from_status,to_status,comment,safety_observation,block_id,correlation_id,occurred_at,created_at)
        VALUES (?,?,?,'RECIBIDA_PANOL',?,'APROBADA','APROBADA',?,?,?,?,?,?)`).run(randomUUID(),vehicleSupervision.id,id,context.user.id,operatorNarrative,supervisorSafetyObservation?1:0,vehicleSupervision.security_block_id||null,context.correlationId,receivedAt,recordedAt);
    }
    const cumulativeCondition = isQuantityReturn
      ? strongestReturnCondition(...priorPortions.map((item) => item.condition), condition)
      : condition;
    const priorIncident = isQuantityReturn ? db.prepare(`SELECT incident_id FROM custody_return_portion WHERE custody_id=? AND incident_id IS NOT NULL ORDER BY received_at DESC LIMIT 1`).get(id) : null;
    const summaryIncidentId = incident?.id || priorIncident?.incident_id || null;
    const returnRecordId = randomUUID();
    db.prepare(`INSERT INTO custody_return_record(id,custody_id,handover_id,inspection_id,incident_id,due_at_snapshot,received_at,timing_status,overdue_seconds,condition,notes,recorded_by_user_id,correlation_id,created_at,work_order_reference_snapshot)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(returnRecordId, id, handoverId, inspectionId, summaryIncidentId, current.due_at || null, receivedAt,
        timingStatus, overdueSeconds, cumulativeCondition, notes, context.user.id, context.correlationId, recordedAt, requestOt);
    const receptionReviewId = randomUUID();
    db.prepare(`INSERT INTO custody_reception_review(
      id,custody_id,handover_id,return_record_id,asset_id,reviewer_user_id,source_mode,asset_nature_snapshot,declared_condition_snapshot,declared_problem_reported_snapshot,declared_comment_snapshot,
      operator_condition,operator_comment,effective_condition,comment_forced_observation,blocked_after_receipt,incident_id,correlation_id,reviewed_at,created_at,work_order_reference_snapshot
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      receptionReviewId,id,handoverId,returnRecordId,current.asset_id,context.user.id,'F22_REVIEW',nature,declaredCondition,
      Number(declaration?.problem_reported || 0) === 1 ? 1 : 0,declarationNotes,requestedCondition,warehouseComment,cumulativeCondition,
      commentForcesObservation ? 1 : 0,blockedAfterReceipt ? 1 : 0,summaryIncidentId,context.correlationId,receivedAt,recordedAt,requestOt
    );
    const returnReceipt = createReturnReceiptInDb(db, id, { handoverId, returnRecordId, context });
    syncCustodyOperationalAlerts(db, id, new Date(recordedAt));
    if (incident) notifyCustodyIncidentToOperators(db, id, incident);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.RECEIVE', entityType: 'custody', entityId: id,
      before: { status: current.status, quantityOutstanding: isQuantityReturn ? remainingBefore : undefined },
      after: { status: target, condition: cumulativeCondition, requestedCondition, declaredCondition, warehouseComment, commentForcesObservation, inspectionId, incidentId: summaryIncidentId, timingStatus, overdueSeconds, receivedAt, quantityReceived: receivedQuantity, quantityOutstanding: 0 }, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return { custody: hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(id)), returnRecord: db.prepare('SELECT * FROM custody_return_record WHERE id=?').get(returnRecordId), returnReceipt, partialReturn: portion, kitReturn, idempotent: false };
  });
}

function requestTransfer(id, input, context, allowAny = false) {
  return transaction((db) => {
    const current = db.prepare(`${custodySelect()} WHERE c.id=?`).get(id);
    if (!current) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
    if (!allowAny && current.person_id !== context.user.personId) throw error(403, 'CUSTODY_FORBIDDEN', 'No puede transferir esta custodia.');
    requireScope(context.user, current.site_id, current.location_id, allowAny ? 'Custody.TransferAny' : 'Custody.TransferOwn');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La custodia fue modificada por otra operación.');
    if (current.status !== 'ABIERTA') throw error(409, 'CUSTODY_TRANSFER_NOT_ALLOWED', 'La custodia no admite transferencia.');
    const toPersonId = requiredString(input.toPersonId, 'toPersonId', { min: 8, max: 80 });
    if (toPersonId === current.person_id) throw error(422, 'TRANSFER_SAME_PERSON', 'El nuevo custodio debe ser diferente.');
    const person = db.prepare("SELECT id, full_name FROM person WHERE id=? AND status='ACTIVA' AND deleted_at IS NULL").get(toPersonId);
    if (!person) throw error(422, 'TRANSFER_PERSON_INVALID', 'El nuevo custodio no está activo.');
    const asset = db.prepare('SELECT a.*,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=?').get(current.asset_id);
    assertOperationAllowed(db, { personId: current.person_id, asset, operationType: 'TRANSFERENCIA', siteId: current.site_id, locationId: current.location_id, requestId: current.request_id });
    assertOperationAllowed(db, { personId: toPersonId, asset, operationType: 'TRANSFERENCIA', siteId: current.site_id, locationId: current.location_id, requestId: null });
    const reason = requiredString(input.reason, 'reason', { min: 5, max: 1000 });
    const now = new Date().toISOString();
    const transferId = randomUUID();
    db.prepare(`INSERT INTO custody_transfer(id,custody_id,from_person_id,to_person_id,requested_by_user_id,status,reason,requested_at,version,correlation_id,created_at,updated_at)
      VALUES (?,?,?,?,?,'PENDIENTE',?,?,1,?,?,?)`).run(transferId, id, current.person_id, toPersonId, context.user.id, reason, now, context.correlationId, now, now);
    const changed = db.prepare(`UPDATE custody SET status='TRANSFERENCIA_PENDIENTE',version=version+1,updated_at=? WHERE id=? AND version=? AND status='ABIERTA'`).run(now, id, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al solicitar transferencia.');
    addCustodyEvent(db, id, 'ABIERTA', 'TRANSFERENCIA_PENDIENTE', context.user.id, reason, context.correlationId, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'CUSTODY.TRANSFER_REQUEST', entityType: 'custody_transfer', entityId: transferId,
      after: { custodyId: id, fromPersonId: current.person_id, toPersonId }, reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return db.prepare('SELECT * FROM custody_transfer WHERE id=?').get(transferId);
  });
}

function decideTransfer(transferId, decision, input, context, allowAny = false) {
  return transaction((db) => {
    const transfer = db.prepare('SELECT * FROM custody_transfer WHERE id=?').get(transferId);
    if (!transfer) throw error(404, 'TRANSFER_NOT_FOUND', 'Transferencia no encontrada.');
    const custody = db.prepare(`${custodySelect()} WHERE c.id=?`).get(transfer.custody_id);
    if (!custody) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
    requireScope(context.user, custody.site_id, custody.location_id, allowAny ? 'Custody.TransferAny' : 'Custody.TransferOwn');
    if (!allowAny && transfer.to_person_id !== context.user.personId) throw error(403, 'TRANSFER_FORBIDDEN', 'Solo el destinatario puede decidir esta transferencia.');
    const transferVersion = Number(input.transferVersion);
    const custodyVersion = Number(input.custodyVersion);
    if (!Number.isInteger(transferVersion) || transferVersion !== transfer.version || !Number.isInteger(custodyVersion) || custodyVersion !== custody.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La transferencia o custodia fue modificada.');
    if (transfer.status !== 'PENDIENTE' || custody.status !== 'TRANSFERENCIA_PENDIENTE') throw error(409, 'TRANSFER_NOT_PENDING', 'La transferencia ya no está pendiente.');
    const reason = requiredString(input.reason, 'reason', { min: 5, max: 1000 });
    const now = new Date().toISOString();
    let handoverId = null;
    if (decision === 'ACEPTADA') {
      if (input.acceptanceConfirmed !== true) throw error(422, 'ACCEPTANCE_REQUIRED', 'El nuevo custodio debe aceptar explícitamente.');
      const idempotencyKey = requiredString(input.idempotencyKey, 'idempotencyKey', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ });
      const reused = db.prepare('SELECT id FROM handover WHERE idempotency_key=?').get(idempotencyKey);
      if (reused) throw error(409, 'IDEMPOTENCY_KEY_REUSED', 'La clave de idempotencia ya fue utilizada.');
      handoverId = randomUUID();
      const acceptanceHash = createHash('sha256').update(`${transferId}:EXPLICITA:${now}`).digest('hex');
      const requestOt = db.prepare('SELECT work_order_reference FROM request WHERE id=?').get(custody.request_id)?.work_order_reference || null;
      db.prepare(`INSERT INTO handover(id,request_id,type,operator_user_id,person_id,occurred_at,observations,acceptance_method,acceptance_hash,acceptance_evidence_id,idempotency_key,correlation_id,created_at,work_order_reference_snapshot)
        VALUES (?,?, 'TRANSFERENCIA',?,?,?,?, 'EXPLICITA',?,NULL,?,?,?,?)`).run(handoverId, custody.request_id, context.user.id, transfer.to_person_id, now, reason, acceptanceHash, idempotencyKey, context.correlationId, now, requestOt);
      db.prepare(`INSERT INTO handover_item(id,handover_id,request_item_id,asset_id,quantity,condition,notes,created_at) VALUES (?,?,?,?,?,'CONFORME',?,?)`)
        .run(randomUUID(), handoverId, custody.request_item_id, custody.asset_id, custody.quantity, reason, now);
      db.prepare(`UPDATE custody SET person_id=?,status='ABIERTA',version=version+1,updated_at=? WHERE id=? AND version=?`).run(transfer.to_person_id, now, custody.id, custodyVersion);
      if (custody.exclusive_unit) db.prepare('UPDATE asset SET custodian_person_id=?,version=version+1,updated_at=? WHERE id=?').run(transfer.to_person_id, now, custody.asset_id);
      addCustodyEvent(db, custody.id, 'TRANSFERENCIA_PENDIENTE', 'ABIERTA', context.user.id, `Transferencia aceptada. ${reason}`, context.correlationId, now);
    } else {
      db.prepare(`UPDATE custody SET status='ABIERTA',version=version+1,updated_at=? WHERE id=? AND version=?`).run(now, custody.id, custodyVersion);
      addCustodyEvent(db, custody.id, 'TRANSFERENCIA_PENDIENTE', 'ABIERTA', context.user.id, `Transferencia rechazada. ${reason}`, context.correlationId, now);
    }
    const changed = db.prepare(`UPDATE custody_transfer SET status=?,accepted_by_user_id=?,decision_reason=?,decided_at=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status='PENDIENTE'`)
      .run(decision, context.user.id, reason, now, now, transferId, transferVersion);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al decidir transferencia.');
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: `CUSTODY.TRANSFER_${decision}`, entityType: 'custody_transfer', entityId: transferId,
      before: { status: 'PENDIENTE' }, after: { status: decision, handoverId }, reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return { transfer: db.prepare('SELECT * FROM custody_transfer WHERE id=?').get(transferId), custody: hydrate(db, db.prepare(`${custodySelect()} WHERE c.id=?`).get(custody.id)) };
  });
}

function listTransfersPage(filters, user, allowAll = false) {
  const db = getDb();
  const where = [];
  const params = [];
  const permission = allowAll ? 'Custody.TransferAny' : 'Custody.TransferOwn';
  const scope = scopeWhere(user, permission, 'sl.site_id', 'a.location_id', db);
  where.push(`(${scope.sql})`); params.push(...scope.params);
  if (!allowAll) { where.push('(ct.from_person_id=? OR ct.to_person_id=?)'); params.push(user.personId, user.personId); }
  if (filters.status) { where.push('ct.status=?'); params.push(String(filters.status).toUpperCase()); }
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 300));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const from = `FROM custody_transfer ct JOIN person fp ON fp.id=ct.from_person_id JOIN person tp ON tp.id=ct.to_person_id JOIN custody c ON c.id=ct.custody_id
    JOIN asset a ON a.id=c.asset_id JOIN storage_location sl ON sl.id=a.location_id`;
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = Number(db.prepare(`SELECT COUNT(*) AS n ${from} ${whereSql}`).get(...params)?.n || 0);
  const items = db.prepare(`SELECT ct.*, fp.full_name AS from_name, tp.full_name AS to_name, c.asset_id, c.version AS custody_version, c.status AS custody_status, a.internal_code, a.description, a.location_id, sl.site_id
    ${from} ${whereSql} ORDER BY ct.requested_at DESC LIMIT ? OFFSET ?`).all(...params, limit, offset);
  return { items, total, limit, offset };
}

function listTransfers(filters, user, allowAll = false) {
  return listTransfersPage(filters, user, allowAll).items;
}


function listEligiblePeople() {
  return getDb().prepare(`SELECT p.id, p.full_name, p.document_type, p.document_number, p.sector, p.employee_number
    FROM person p WHERE p.status='ACTIVA' AND p.deleted_at IS NULL ORDER BY p.full_name LIMIT 1000`).all();
}

function custodyDocument(id, user, allowAll = false) {
  const custody = getCustody(id, user, allowAll);
  const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  return `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Custodia ${escape(custody.id)}</title><style>body{font-family:Arial,sans-serif;color:#24313d;margin:32px}h1{font-size:20px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd5db;padding:8px;text-align:left}.sign{margin-top:48px;display:grid;grid-template-columns:1fr 1fr;gap:60px}.line{border-top:1px solid #24313d;padding-top:8px}</style></head><body><h1>INGAR Warehouse Controller · Constancia de custodia</h1><table><tr><th>Solicitud</th><td>${escape(custody.request_number)}</td><th>Estado</th><td>${escape(custody.status)}</td></tr><tr><th>Bien</th><td>${escape(custody.internal_code)} · ${escape(custody.description)}</td><th>Cantidad</th><td>${escape(custody.quantity)}</td></tr><tr><th>Custodio</th><td>${escape(custody.custodian_name)}</td><th>Documento</th><td>${escape(custody.custodian_document)}</td></tr><tr><th>Apertura</th><td>${escape(custody.opened_at)}</td><th>Vencimiento</th><td>${escape(custody.due_at || 'Sin vencimiento')}</td></tr><tr><th>Sede</th><td>${escape(custody.site_name)}</td><th>Ubicación</th><td>${escape(custody.location_name)}</td></tr></table><div class="sign"><div class="line">Custodio</div><div class="line">Pañolero</div></div></body></html>`;
}

module.exports = { listCustodies, listCustodiesPage, getCustody, getKitReturnDetail, declareReturn, extendCustody, receiveCustody, requestTransfer, decideTransfer, listTransfers, listTransfersPage, listEligiblePeople, custodyDocument, getReturnReceiptBytes };
