'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, requiredArray, parseBoolean, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { permissionAssignments, userHasScope, assertUserScope, scopeWhere, assertLocationScope, assertAssetScope } = require('../security/scope');
const { getKitOperationalStatus, assertKitComponentHierarchyUnique } = require('./kit-operational-control-service');
const { assertPersonalKitRequester, closeStaleInactiveKitAssignmentsForComponentsInDb } = require('./kit-personal-service');
const { syncKitComponentsInDb } = require('./kit-component-membership-service');

const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);
const STOCK_NATURES = new Set(['CANTIDAD', 'CONSUMIBLE']);

function error(status, code, message) {
  return Object.assign(new Error(message), { status, code });
}

function nowIso() { return new Date().toISOString(); }
function positive(value, field) {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) throw error(422, 'QUANTITY_INVALID', `${field} debe ser mayor que cero.`);
  return number;
}
function nonNegative(value, field, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) throw error(422, 'NUMBER_INVALID', `${field} debe ser mayor o igual que cero.`);
  return number;
}
function expectedVersion(input, current) {
  const version = Number(input.version);
  if (!Number.isInteger(version)) throw error(422, 'VERSION_REQUIRED', 'La versión es obligatoria.');
  if (version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'El registro fue modificado por otra operación.');
  return version;
}
function audit(db, context, action, entityType, entityId, before, after, reason = null) {
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action, entityType, entityId, before, after, reason, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
}
function getAssetOrThrow(id, db = getDb(), allowedNatures = null) {
  const row = db.prepare(`SELECT a.*, c.nature AS category_nature, c.code AS category_code, c.name AS category_name
    FROM asset a JOIN asset_category c ON c.id=a.category_id WHERE a.id=? AND a.deleted_at IS NULL`).get(id);
  if (!row) throw error(404, 'ASSET_NOT_FOUND', 'Bien no encontrado.');
  if (allowedNatures && !allowedNatures.has(row.category_nature)) throw error(422, 'ASSET_NATURE_INVALID', 'La naturaleza del bien no corresponde a esta operación.');
  return row;
}
function getLocationOrThrow(id, db = getDb()) {
  const row = db.prepare('SELECT * FROM storage_location WHERE id=? AND active=1').get(id);
  if (!row) throw error(422, 'LOCATION_INVALID', 'Ubicación inexistente o inactiva.');
  return row;
}
const NUMBER_QUERIES = Object.freeze({
  'stock_movement.movement_number': 'SELECT COUNT(*) AS n FROM stock_movement WHERE movement_number LIKE ?',
  'inventory_count.count_number': 'SELECT COUNT(*) AS n FROM inventory_count WHERE count_number LIKE ?',
  'inventory_transfer.transfer_number': 'SELECT COUNT(*) AS n FROM inventory_transfer WHERE transfer_number LIKE ?'
});
function nextNumber(db, table, column, prefix) {
  const query = NUMBER_QUERIES[`${table}.${column}`];
  if (!query) throw error(500, 'NUMBER_SEQUENCE_INVALID', 'Secuencia interna no autorizada.');
  const year = new Date().getUTCFullYear();
  const count = db.prepare(query).get(`${prefix}-${year}-%`).n + 1;
  return `${prefix}-${year}-${String(count).padStart(6, '0')}`;
}

function assertGlobalScope(user, permission, db = getDb()) {
  const scopes = permissionAssignments(user, permission, db);
  if (!scopes.some((scope) => !scope.site_id && !scope.location_id)) {
    throw error(403, 'SCOPE_FORBIDDEN', 'La operación requiere alcance global.');
  }
}
function assertCountScope(user, count, permission, db = getDb()) {
  if (!user) return;
  assertUserScope(user, count.site_id || null, count.location_id || null, permission, db);
}
function assertTransferScope(user, transfer, permission, mode = 'either', db = getDb()) {
  if (!user) return;
  const from = db.prepare('SELECT id AS location_id,site_id FROM storage_location WHERE id=?').get(transfer.from_location_id);
  const to = db.prepare('SELECT id AS location_id,site_id FROM storage_location WHERE id=?').get(transfer.to_location_id);
  const fromAllowed = from && userHasScope(user, from.site_id, from.location_id, permission, db);
  const toAllowed = to && userHasScope(user, to.site_id, to.location_id, permission, db);
  const allowed = mode === 'from' ? fromAllowed : mode === 'to' ? toAllowed : (fromAllowed || toAllowed);
  if (!allowed) throw error(403, 'SCOPE_FORBIDDEN', 'La transferencia está fuera del alcance asignado.');
}
function custodyKitAsset(db, custodyId) {
  return db.prepare(`SELECT c.asset_id FROM custody c JOIN asset a ON a.id=c.asset_id
    JOIN asset_category ac ON ac.id=a.category_id WHERE c.id=? AND ac.nature='KIT'`).get(custodyId);
}

// VEHÍCULOS
function vehicleProfileSelect() {
  return `SELECT vp.*, a.internal_code, a.description, a.license_plate, a.category_id, a.status AS asset_status,
    c.name AS category_name FROM vehicle_profile vp JOIN asset a ON a.id=vp.asset_id JOIN asset_category c ON c.id=a.category_id`;
}
function vehicleUsageUnit(value, fallback = 'KILOMETROS') {
  const unit = String(value || fallback).toUpperCase();
  if (!['KILOMETROS','HORAS'].includes(unit)) throw error(422, 'VEHICLE_USAGE_UNIT_INVALID', 'La unidad operativa debe ser kilómetros u horas.');
  return unit;
}
function vehicleKmPerHour(value, fallback = 50) {
  const factor = value === '' || value == null ? Number(fallback || 50) : Number(value);
  if (!Number.isFinite(factor) || factor <= 0 || factor > 1000) throw error(422, 'VEHICLE_CONVERSION_INVALID', 'La equivalencia de kilómetros por hora debe ser mayor que cero.');
  return factor;
}
function hasMeterInput(value) { return value !== '' && value !== null && value !== undefined && Number.isFinite(Number(value)); }
function normalizeVehicleMeters(input, current, asset) {
  const usageUnit = vehicleUsageUnit(input.usageUnit ?? current?.usage_unit, 'KILOMETROS');
  const kmPerHour = vehicleKmPerHour(input.kmPerHour ?? current?.km_per_hour, 50);
  const currentOdometer = Number(current?.current_odometer ?? asset.odometer ?? 0);
  const currentHourmeter = Number(current?.current_hourmeter ?? 0);
  let odometer = hasMeterInput(input.currentOdometer ?? input.odometer) ? Number(input.currentOdometer ?? input.odometer) : null;
  let hourmeter = hasMeterInput(input.currentHourmeter ?? input.hourmeter) ? Number(input.currentHourmeter ?? input.hourmeter) : null;
  if (usageUnit === 'KILOMETROS') {
    if (odometer === null) odometer = currentOdometer;
    if (hourmeter === null) hourmeter = currentHourmeter + Math.max(0, odometer - currentOdometer) / kmPerHour;
  } else {
    if (hourmeter === null) hourmeter = currentHourmeter;
    if (odometer === null) odometer = currentOdometer + Math.max(0, hourmeter - currentHourmeter) * kmPerHour;
  }
  odometer = nonNegative(odometer, 'currentOdometer', currentOdometer);
  hourmeter = nonNegative(hourmeter, 'currentHourmeter', currentHourmeter);
  return { usageUnit, kmPerHour, currentOdometer, currentHourmeter, odometer, hourmeter };
}
function getVehicleProfile(assetId, user = null, permission = 'Vehicles.Read') {
  const db = getDb();
  if (user) assertAssetScope(user, assetId, permission, db);
  getAssetOrThrow(assetId, db, new Set(['VEHICULO']));
  const profile = db.prepare(`${vehicleProfileSelect()} WHERE vp.asset_id=?`).get(assetId);
  if (!profile) throw error(409, 'VEHICLE_PROFILE_MISSING', 'Integridad inválida: el vehículo no posee perfil vehicular.');
  return profile;
}
function saveVehicleProfile(assetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, assetId, 'Vehicles.Manage', db);
    const asset = getAssetOrThrow(assetId, db, new Set(['VEHICULO']));
    const current = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=?').get(assetId);
    if (!current) throw error(409, 'VEHICLE_PROFILE_MISSING', 'Integridad inválida: el vehículo no posee perfil vehicular.');
    expectedVersion(input, current);
    const now = nowIso();
    const meters = normalizeVehicleMeters(input, current, asset);
    const data = {
      vin: optionalString(input.vin, 'vin', { max: 60 })?.toUpperCase() || null,
      chassisNumber: optionalString(input.chassisNumber, 'chassisNumber', { max: 80 })?.toUpperCase() || null,
      engineNumber: optionalString(input.engineNumber, 'engineNumber', { max: 80 })?.toUpperCase() || null,
      manufactureYear: input.manufactureYear === '' || input.manufactureYear == null ? null : Number(input.manufactureYear),
      vehicleClass: optionalString(input.vehicleClass, 'vehicleClass', { max: 80 }),
      currentOdometer: meters.odometer,
      currentHourmeter: meters.hourmeter,
      usageUnit: meters.usageUnit,
      kmPerHour: meters.kmPerHour,
      fuelType: optionalString(input.fuelType, 'fuelType', { max: 80 }) || asset.fuel_type,
      fuelCapacity: nonNegative(input.fuelCapacity, 'fuelCapacity', current?.fuel_capacity ?? null),
      requiredLicenseClass: optionalString(input.requiredLicenseClass, 'requiredLicenseClass', { max: 30 })?.toUpperCase() || null,
      active: parseBoolean(input.active, current ? Boolean(current.active) : true) ? 1 : 0
    };
    if (data.manufactureYear != null && (!Number.isInteger(data.manufactureYear) || data.manufactureYear < 1900 || data.manufactureYear > 2200)) throw error(422, 'YEAR_INVALID', 'Año de fabricación inválido.');
    if (data.currentOdometer < (current?.current_odometer ?? 0) || data.currentHourmeter < (current?.current_hourmeter ?? 0)) throw error(422, 'VEHICLE_METER_ROLLBACK', 'Odómetro y horómetro no pueden disminuir.');
    try {
      db.prepare(`UPDATE vehicle_profile SET vin=?,chassis_number=?,engine_number=?,manufacture_year=?,vehicle_class=?,current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,fuel_type=?,fuel_capacity=?,required_license_class=?,active=?,version=version+1,updated_at=? WHERE asset_id=? AND version=?`)
        .run(data.vin, data.chassisNumber, data.engineNumber, data.manufactureYear, data.vehicleClass, data.currentOdometer, data.currentHourmeter, data.usageUnit, data.kmPerHour, data.fuelType, data.fuelCapacity, data.requiredLicenseClass, data.active, now, assetId, current.version);
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw error(409, 'VEHICLE_IDENTIFIER_DUPLICATE', 'VIN o chasis ya asignado a otro vehículo.');
      throw e;
    }
    db.prepare('UPDATE asset SET odometer=?,fuel_type=?,version=version+1,updated_at=? WHERE id=?').run(data.currentOdometer, data.fuelType, now, assetId);
    const after = db.prepare(`${vehicleProfileSelect()} WHERE vp.asset_id=?`).get(assetId);
    audit(db, context, 'VEHICLE.PROFILE_UPDATE', 'vehicle_profile', assetId, current, after);
    return after;
  });
}
function listVehicleAuthorizations(filters = {}, user = null, permission = 'Vehicles.Read', db = getDb()) {
  const where = ['1=1']; const args = [];
  if (filters.personId) { where.push('vda.person_id=?'); args.push(filters.personId); }
  if (filters.vehicleAssetId) { where.push('(vda.vehicle_asset_id=? OR vda.vehicle_asset_id IS NULL)'); args.push(filters.vehicleAssetId); }
  if (filters.status) { where.push('vda.status=?'); args.push(String(filters.status).toUpperCase()); }
  const rows = db.prepare(`SELECT vda.*,p.full_name AS person_name,a.internal_code AS vehicle_code,a.location_id,sl.site_id,c.name AS category_name
    FROM vehicle_driver_authorization vda JOIN person p ON p.id=vda.person_id
    LEFT JOIN asset a ON a.id=vda.vehicle_asset_id LEFT JOIN storage_location sl ON sl.id=a.location_id
    LEFT JOIN asset_category c ON c.id=vda.category_id
    WHERE ${where.join(' AND ')} ORDER BY vda.valid_until DESC`).all(...args);
  if (!user) return rows;
  const hasGlobal = permissionAssignments(user, permission, db).some((scope) => !scope.site_id && !scope.location_id);
  return rows.filter((row) => row.vehicle_asset_id
    ? userHasScope(user, row.site_id, row.location_id, permission, db)
    : hasGlobal);
}
function createVehicleAuthorization(input, context) {
  return transaction((db) => {
    const personId = requiredString(input.personId, 'personId', { min: 8, max: 80 });
    if (!db.prepare('SELECT 1 FROM person WHERE id=? AND deleted_at IS NULL').get(personId)) throw error(422, 'PERSON_INVALID', 'Persona inexistente.');
    const vehicleAssetId = input.vehicleAssetId || null; const categoryId = input.categoryId || null;
    if (!vehicleAssetId && !categoryId) throw error(422, 'AUTHORIZATION_SCOPE_REQUIRED', 'Debe indicar vehículo o categoría.');
    if (vehicleAssetId) {
      assertAssetScope(context.user, vehicleAssetId, 'Vehicles.Manage', db);
      getAssetOrThrow(vehicleAssetId, db, new Set(['VEHICULO']));
    } else {
      assertGlobalScope(context.user, 'Vehicles.Manage', db);
    }
    if (categoryId && !db.prepare("SELECT 1 FROM asset_category WHERE id=? AND nature='VEHICULO' AND active=1").get(categoryId)) throw error(422, 'CATEGORY_INVALID', 'Categoría vehicular inválida.');
    const validFrom = new Date(input.validFrom || nowIso()).toISOString(); const validUntil = new Date(input.validUntil).toISOString();
    if (validUntil <= validFrom) throw error(422, 'AUTHORIZATION_DATES_INVALID', 'La vigencia de la habilitación es inválida.');
    const id = randomUUID(); const now = nowIso();
    db.prepare(`INSERT INTO vehicle_driver_authorization(id,person_id,vehicle_asset_id,category_id,license_number,license_class,valid_from,valid_until,status,notes,version,created_by_user_id,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?,?)`).run(id, personId, vehicleAssetId, categoryId, requiredString(input.licenseNumber, 'licenseNumber', { min: 3, max: 80 }).toUpperCase(), requiredString(input.licenseClass, 'licenseClass', { min: 1, max: 30 }).toUpperCase(), validFrom, validUntil, 'VIGENTE', optionalString(input.notes, 'notes', { max: 1000 }), context.user.id, now, now);
    const after = listVehicleAuthorizations({ personId }, null, 'Vehicles.Read', db).find((x) => x.id === id);
    audit(db, context, 'VEHICLE.AUTHORIZATION_CREATE', 'vehicle_driver_authorization', id, null, after);
    return after;
  });
}
function assertDriverAuthorized(db, asset, personId, at = nowIso()) {
  const profile = db.prepare('SELECT * FROM vehicle_profile WHERE asset_id=? AND active=1').get(asset.id);
  const auth = db.prepare(`SELECT * FROM vehicle_driver_authorization WHERE person_id=? AND status='VIGENTE' AND valid_from<=? AND valid_until>=?
    AND (vehicle_asset_id=? OR (vehicle_asset_id IS NULL AND category_id=?)) ORDER BY vehicle_asset_id IS NOT NULL DESC,valid_until DESC LIMIT 1`).get(personId, at, at, asset.id, asset.category_id);
  if (!auth) throw error(409, 'DRIVER_NOT_AUTHORIZED', 'El conductor no posee habilitación vigente para el vehículo.');
  if (profile?.required_license_class && profile.required_license_class !== auth.license_class) throw error(409, 'LICENSE_CLASS_MISMATCH', 'La clase de licencia no satisface el requisito del vehículo.');
  return { profile, authorization: auth };
}
function registerVehicleOperation(assetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, assetId, 'Vehicles.Operate', db);
    const asset = getAssetOrThrow(assetId, db, new Set(['VEHICULO']));
    const driverPersonId = requiredString(input.driverPersonId, 'driverPersonId', { min: 8, max: 80 });
    const { profile } = assertDriverAuthorized(db, asset, driverPersonId);
    const operationType = String(input.operationType || '').toUpperCase();
    if (!['ENTREGA','RECEPCION','CONTROL','AJUSTE'].includes(operationType)) throw error(422, 'VEHICLE_OPERATION_INVALID', 'Tipo de operación vehicular inválido.');
    const meters = normalizeVehicleMeters(input, profile, asset);
    const odometer = meters.odometer;
    const hourmeter = meters.hourmeter;
    if (odometer < meters.currentOdometer || hourmeter < meters.currentHourmeter) throw error(422, 'VEHICLE_METER_ROLLBACK', 'Odómetro y horómetro no pueden disminuir.');
    const fuel = nonNegative(input.fuelLevelPercent, 'fuelLevelPercent', null);
    if (fuel != null && fuel > 100) throw error(422, 'FUEL_LEVEL_INVALID', 'Nivel de combustible fuera de rango.');
    if (input.custodyId) {
      const custody = db.prepare('SELECT * FROM custody WHERE id=? AND asset_id=?').get(input.custodyId, assetId);
      if (!custody) throw error(422, 'CUSTODY_INVALID', 'Custodia vehicular inválida.');
    }
    const id = randomUUID(); const now = nowIso();
    db.prepare(`INSERT INTO vehicle_operation(id,asset_id,custody_id,handover_id,driver_person_id,operation_type,odometer,hourmeter,fuel_level_percent,condition,checklist_json,notes,operator_user_id,occurred_at,correlation_id,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, assetId, input.custodyId || null, input.handoverId || null, driverPersonId, operationType, odometer, hourmeter, fuel, String(input.condition || 'CONFORME').toUpperCase(), JSON.stringify(input.checklist || {}), optionalString(input.notes, 'notes', { max: 2000 }), context.user.id, new Date(input.occurredAt || now).toISOString(), context.correlationId, now);
    if (profile) db.prepare('UPDATE vehicle_profile SET current_odometer=?,current_hourmeter=?,usage_unit=?,km_per_hour=?,version=version+1,updated_at=? WHERE asset_id=?').run(odometer, hourmeter, meters.usageUnit, meters.kmPerHour, now, assetId);
    else db.prepare(`INSERT INTO vehicle_profile(asset_id,current_odometer,current_hourmeter,usage_unit,km_per_hour,fuel_type,active,version,created_at,updated_at) VALUES (?,?,?,?,?,?,1,1,?,?)`).run(assetId, odometer, hourmeter, meters.usageUnit, meters.kmPerHour, asset.fuel_type, now, now);
    db.prepare('UPDATE asset SET odometer=?,version=version+1,updated_at=? WHERE id=?').run(odometer, now, assetId);
    const after = db.prepare('SELECT * FROM vehicle_operation WHERE id=?').get(id);
    audit(db, context, 'VEHICLE.OPERATION', 'vehicle_operation', id, null, after, input.notes || operationType);
    return after;
  });
}
function listVehicleOperations(assetId, limit = 100, user = null, permission = 'Vehicles.Read') {
  const db = getDb();
  if (user) assertAssetScope(user, assetId, permission, db);
  return db.prepare(`SELECT vo.*,p.full_name AS driver_name,u.username AS operator_username FROM vehicle_operation vo JOIN person p ON p.id=vo.driver_person_id JOIN user_account u ON u.id=vo.operator_user_id WHERE vo.asset_id=? ORDER BY vo.occurred_at DESC LIMIT ?`).all(assetId, safeInteger(limit, 100, 1, 500)).map((x) => ({ ...x, checklist: JSON.parse(x.checklist_json || '{}') }));
}

// KITS
function getKitDefinition(kitAssetId, user = null, permission = 'Kits.Read', db = getDb()) {
  if (user) assertAssetScope(user, kitAssetId, permission, db);
  const asset = getAssetOrThrow(kitAssetId, db, new Set(['KIT']));
  const definition = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(kitAssetId);
  if (!definition) throw error(409, 'KIT_DEFINITION_MISSING', 'Integridad inválida: el kit no posee definición.');
  const components = db.prepare(`SELECT kc.*,a.internal_code,a.description,a.status,a.quantity_available,a.unit_of_measure,c.nature AS component_nature
    FROM kit_component kc JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE kc.kit_asset_id=? AND kc.active=1 ORDER BY kc.sequence,a.internal_code`).all(kitAssetId);
  const assignment = db.prepare(`SELECT kpa.*,p.full_name,p.employee_number,p.sector,ua.username
    FROM kit_person_assignment kpa JOIN person p ON p.id=kpa.person_id
    LEFT JOIN user_account ua ON ua.person_id=p.id AND ua.deleted_at IS NULL
    WHERE kpa.kit_asset_id=? AND kpa.status='ACTIVE' ORDER BY kpa.assigned_at DESC LIMIT 1`).get(kitAssetId) || null;
  return { asset, definition, components, assignment };
}
function hasKitPath(db, fromId, targetId, visited = new Set()) {
  if (fromId === targetId) return true;
  if (visited.has(fromId)) return false;
  visited.add(fromId);
  const children = db.prepare(`SELECT kc.component_asset_id FROM kit_component kc JOIN asset a ON a.id=kc.component_asset_id JOIN asset_category c ON c.id=a.category_id WHERE kc.kit_asset_id=? AND kc.active=1 AND c.nature='KIT'`).all(fromId);
  return children.some((row) => hasKitPath(db, row.component_asset_id, targetId, visited));
}
function saveKitDefinition(kitAssetId, input, context) {
  return transaction((db) => {
    assertAssetScope(context.user, kitAssetId, 'Kits.Manage', db);
    getAssetOrThrow(kitAssetId, db, new Set(['KIT']));
    const current = db.prepare('SELECT * FROM kit_definition WHERE kit_asset_id=?').get(kitAssetId);
    if (!current) throw error(409, 'KIT_DEFINITION_MISSING', 'Integridad inválida: el kit no posee definición.');
    expectedVersion(input, current);
    const components = requiredArray(input.components, 'components', 200);
    if (!components.length) throw error(422, 'KIT_COMPONENTS_REQUIRED', 'El kit debe contener al menos un componente.');
    const normalized = components.map((item, index) => ({
      componentAssetId: requiredString(item.componentAssetId, `components[${index}].componentAssetId`, { min: 8, max: 80 }),
      requiredQuantity: positive(item.requiredQuantity, `components[${index}].requiredQuantity`),
      mandatory: parseBoolean(item.mandatory, true), allowSubstitution: parseBoolean(item.allowSubstitution, false), sequence: Number(item.sequence || index + 1)
    }));
    if (new Set(normalized.map((x) => x.componentAssetId)).size !== normalized.length) throw error(422, 'KIT_COMPONENT_DUPLICATE', 'Un componente no puede repetirse dentro del kit.');
    for (const component of normalized) {
      assertAssetScope(context.user, component.componentAssetId, 'Kits.Manage', db);
      const asset = getAssetOrThrow(component.componentAssetId, db);
      if (asset.id === kitAssetId || (asset.category_nature === 'KIT' && hasKitPath(db, asset.id, kitAssetId))) throw error(422, 'KIT_CYCLE', 'La composición genera un ciclo de kits.');
      if (current.ownership_mode === 'PERSONAL' && asset.category_nature === 'KIT') throw error(422, 'KIT_PERSONAL_NESTED_FORBIDDEN', 'Un kit personal debe contener herramientas físicas, no otro kit.');
      if (SERIAL_NATURES.has(asset.category_nature) && component.requiredQuantity !== 1) throw error(422, 'KIT_SERIAL_QUANTITY_INVALID', 'Los componentes seriados requieren cantidad uno.');
    }
    assertKitComponentHierarchyUnique(db, normalized.map((component) => component.componentAssetId), kitAssetId);
    closeStaleInactiveKitAssignmentsForComponentsInDb(
      db,
      normalized.map((component) => component.componentAssetId),
      context,
      'Saneamiento previo a actualizar composición de kit'
    );
    const now = nowIso();
    db.prepare('UPDATE kit_definition SET allow_incomplete_with_authorization=?,notes=?,version=version+1,updated_at=? WHERE kit_asset_id=? AND version=?')
      .run(parseBoolean(input.allowIncompleteWithAuthorization, false) ? 1 : 0, optionalString(input.notes, 'notes', { max: 2000 }), now, kitAssetId, current.version);
    syncKitComponentsInDb(db, kitAssetId, normalized, context, 'Edición de composición de kit');
    const after = getKitDefinition(kitAssetId, null, 'Kits.Read', db);
    audit(db, context, 'KIT.UPDATE', 'kit_definition', kitAssetId, current, after);
    return after;
  });
}

function listKitComponentCandidates(filters = {}, user = null, permission = 'Kits.Read') {
  const db = getDb();
  const where = ["a.deleted_at IS NULL", "c.nature NOT IN ('KIT','VEHICULO')"];
  const params = [];
  const includeIds = [...new Set(String(filters.includeIds || '').split(',').map((item) => item.trim()).filter(Boolean))].slice(0, 200);
  const includeSql = includeIds.length ? `a.id IN (${includeIds.map(() => '?').join(',')})` : null;

  if (includeSql) {
    where.push(`(a.active=1 OR ${includeSql})`);
    params.push(...includeIds);
  } else {
    where.push('a.active=1');
  }

  if (filters.search) {
    const terms = String(filters.search).trim().split(/\s+/).filter(Boolean).slice(0, 8);
    const searchable = ['a.internal_code','a.serial_number','a.description','a.brand','a.model','c.code','c.name','sl.code','sl.name','s.code','s.name'];
    for (const term of terms) {
      const like = `%${term}%`;
      const matchSql = `(${searchable.map((field) => `${field} LIKE ?`).join(' OR ')})`;
      if (includeSql) {
        where.push(`(${matchSql} OR ${includeSql})`);
        params.push(...searchable.map(() => like), ...includeIds);
      } else {
        where.push(matchSql);
        params.push(...searchable.map(() => like));
      }
    }
  }

  if (user) {
    const scoped = scopeWhere(user, permission, 's.id', 'sl.id');
    where.push(scoped.sql);
    params.push(...scoped.params);
  }
  const limit = safeInteger(filters.limit, 200, 1, 500);
  return db.prepare(`SELECT a.id,a.internal_code,a.serial_number,a.description,a.brand,a.model,
      a.status,a.active,a.quantity_total,a.quantity_available,a.unit_of_measure,
      a.location_id,c.id AS category_id,c.code AS category_code,c.name AS category_name,
      c.nature AS category_nature,sl.code AS location_code,sl.name AS location_name,
      s.id AS site_id,s.code AS site_code,s.name AS site_name
    FROM asset a
    JOIN asset_category c ON c.id=a.category_id
    JOIN storage_location sl ON sl.id=a.location_id
    JOIN site s ON s.id=sl.site_id
    WHERE ${where.join(' AND ')}
    ORDER BY a.internal_code COLLATE NOCASE
    LIMIT ?`).all(...params, limit);
}

function validateKitAvailability(kitAssetId, user = null, permission = 'Kits.Read') {
  const db = getDb();
  if (user) assertAssetScope(user, kitAssetId, permission, db);
  const status = getKitOperationalStatus(db, kitAssetId);
  const assignment = db.prepare(`SELECT kpa.id,kpa.person_id,kpa.assigned_at,kpa.assignment_notes,p.full_name,p.employee_number,p.sector
    FROM kit_person_assignment kpa JOIN person p ON p.id=kpa.person_id
    WHERE kpa.kit_asset_id=? AND kpa.status='ACTIVE' ORDER BY kpa.assigned_at DESC LIMIT 1`).get(kitAssetId) || null;
  return {
    configured: status.configured,
    available: status.complete,
    complete: status.complete,
    missing: status.missing,
    components: status.components,
    assignment
  };
}
function buildRecursiveKitIssuePlan(db, kitAssetId, selections, context) {
  const definition = getKitDefinition(kitAssetId, null, 'Kits.Read', db);
  const byRequired = new Map(definition.components.map((component) => [component.id, component]));
  const selectedIds = new Set();
  const plan = [];
  const seenAssets = new Set();

  function appendRequirement(ownerKitId, requirement, actualId, quantity, ancestry, substitutedForAssetId = null) {
    if (ancestry.has(actualId)) throw error(422, 'KIT_CYCLE', 'La composición genera un ciclo de kits.');
    if (seenAssets.has(actualId)) throw error(409, 'KIT_COMPONENT_HIERARCHY_DUPLICATE', 'Un mismo bien aparece más de una vez dentro de la jerarquía del kit.');
    seenAssets.add(actualId);
    assertAssetScope(context.user, actualId, 'Kits.Operate', db);
    const actual = getAssetOrThrow(actualId, db);
    const qty = positive(quantity, 'quantity');
    if (SERIAL_NATURES.has(actual.category_nature) && qty !== 1) throw error(422, 'KIT_SERIAL_QUANTITY_INVALID', `El componente seriado ${actual.internal_code} requiere cantidad uno.`);
    if (actual.status !== 'DISPONIBLE' || actual.quantity_available < qty) throw error(409, 'KIT_COMPONENT_UNAVAILABLE', `El componente ${actual.internal_code} no está disponible.`);
    plan.push({ ownerKitId, requirement, actual, quantity: qty, substitutedForAssetId });
    if (plan.length > 200) throw error(422, 'KIT_COMPONENT_LIMIT_EXCEEDED', 'La jerarquía del kit supera el máximo operativo de 200 componentes.');

    if (actual.category_nature !== 'KIT') return;
    const nestedStatus = getKitOperationalStatus(db, actual.id);
    if (!nestedStatus.configured || !nestedStatus.complete) throw error(409, 'KIT_INCOMPLETE_OPERATION_BLOCKED', `El kit anidado ${actual.internal_code} está incompleto.`);
    const nextAncestry = new Set(ancestry);
    nextAncestry.add(actual.id);
    for (const nestedRequirement of nestedStatus.components) {
      if (!nestedRequirement.operationally_available) {
        if (nestedRequirement.mandatory) throw error(409, 'KIT_INCOMPLETE_OPERATION_BLOCKED', `El kit anidado ${actual.internal_code} posee componentes obligatorios no disponibles.`);
        continue;
      }
      appendRequirement(
        actual.id,
        nestedRequirement,
        nestedRequirement.component_asset_id,
        nestedRequirement.required_quantity,
        nextAncestry,
        null
      );
    }
  }

  for (const selection of selections) {
    const requirement = byRequired.get(selection.kitComponentId);
    if (!requirement) throw error(422, 'KIT_COMPONENT_INVALID', 'Componente de definición inexistente.');
    if (selectedIds.has(requirement.id)) throw error(422, 'KIT_COMPONENT_DUPLICATE', 'Un componente de definición no puede seleccionarse más de una vez.');
    selectedIds.add(requirement.id);
    const actualId = selection.componentAssetId || requirement.component_asset_id;
    if (actualId !== requirement.component_asset_id && !requirement.allow_substitution) throw error(422, 'KIT_SUBSTITUTION_FORBIDDEN', 'El componente no admite sustitución.');
    appendRequirement(
      kitAssetId,
      requirement,
      actualId,
      selection.quantity ?? requirement.required_quantity,
      new Set([kitAssetId]),
      actualId === requirement.component_asset_id ? null : requirement.component_asset_id
    );
  }

  const missingMandatory = definition.components.filter((component) => component.mandatory && !selectedIds.has(component.id));
  if (missingMandatory.length && !definition.definition.allow_incomplete_with_authorization) throw error(409, 'KIT_INCOMPLETE', 'Faltan componentes obligatorios del kit.');
  return { definition, plan, missingMandatory };
}

function issueKitComponentsInDb(db, kitAssetId, input, context) {
  assertAssetScope(context.user, kitAssetId, 'Kits.Operate', db);
  getAssetOrThrow(kitAssetId, db, new Set(['KIT']));
  const custody = db.prepare("SELECT * FROM custody WHERE id=? AND asset_id=? AND status IN ('ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE')").get(input.custodyId, kitAssetId);
  if (!custody) throw error(422, 'KIT_CUSTODY_INVALID', 'La custodia del kit no está abierta.');
  assertPersonalKitRequester(db, kitAssetId, custody.person_id);
  if (db.prepare('SELECT 1 FROM kit_custody_component WHERE custody_id=? LIMIT 1').get(custody.id)) throw error(409, 'KIT_ALREADY_ISSUED', 'Los componentes del kit ya fueron entregados.');
  const selections = requiredArray(input.components, 'components', 200);
  const { plan, missingMandatory } = buildRecursiveKitIssuePlan(db, kitAssetId, selections, context);
  const now = nowIso();
  const result = [];
  for (const item of plan) {
    const { actual, quantity, requirement, ownerKitId, substitutedForAssetId } = item;
    if (SERIAL_NATURES.has(actual.category_nature)) {
      const changed = db.prepare("UPDATE asset SET status='EN_CUSTODIA',quantity_available=0,custodian_person_id=?,version=version+1,updated_at=? WHERE id=? AND status='DISPONIBLE' AND quantity_available>=1").run(custody.person_id, now, actual.id);
      if (changed.changes !== 1) throw error(409, 'KIT_COMPONENT_UNAVAILABLE', `El componente ${actual.internal_code} dejó de estar disponible.`);
    } else {
      const changed = db.prepare("UPDATE asset SET quantity_available=quantity_available-?,status=CASE WHEN quantity_available-?>0 THEN 'DISPONIBLE' ELSE 'EN_CUSTODIA' END,version=version+1,updated_at=? WHERE id=? AND status='DISPONIBLE' AND quantity_available>=?").run(quantity, quantity, now, actual.id, quantity);
      if (changed.changes !== 1) throw error(409, 'KIT_COMPONENT_UNAVAILABLE', `El componente ${actual.internal_code} dejó de estar disponible.`);
    }
    const id = randomUUID();
    db.prepare(`INSERT INTO kit_custody_component(id,custody_id,kit_asset_id,component_asset_id,substituted_for_asset_id,issued_quantity,returned_quantity,missing_quantity,condition,status,version,created_at,updated_at) VALUES (?,?,?,?,?,?,0,0,'CONFORME','ENTREGADO',1,?,?)`)
      .run(id, custody.id, ownerKitId, actual.id, substitutedForAssetId, quantity, now, now);
    result.push(db.prepare('SELECT * FROM kit_custody_component WHERE id=?').get(id));
  }
  audit(db, context, 'KIT.ISSUE_COMPONENTS', 'custody', custody.id, null, result, input.reason || 'Entrega de componentes del kit');
  return { custodyId: custody.id, items: result, complete: missingMandatory.length === 0 };
}
function issueKitComponents(kitAssetId, input, context) {
  return transaction((db) => issueKitComponentsInDb(db, kitAssetId, input, context));
}

function returnKitComponentsInDb(db, custodyId, input, context, options = {}) {
  const custodyKit = custodyKitAsset(db, custodyId);
  if (!custodyKit) throw error(404, 'KIT_CUSTODY_COMPONENTS_NOT_FOUND', 'No existe una custodia de kit válida.');
  const permission = options.permission || 'Kits.Operate';
  assertAssetScope(context.user, custodyKit.asset_id, permission, db);
  const rows = db.prepare('SELECT * FROM kit_custody_component WHERE custody_id=?').all(custodyId);
  if (!rows.length) throw error(404, 'KIT_CUSTODY_COMPONENTS_NOT_FOUND', 'No existen componentes entregados para la custodia.');
  const updates = requiredArray(input.components, 'components', 200);
  if (options.finalReceipt && updates.length !== rows.length) {
    throw error(422, 'KIT_FINAL_RETURN_COMPONENTS_REQUIRED', 'La recepción física del kit debe revisar todos los componentes entregados.');
  }
  const updateIds = new Set();
  const now = nowIso();
  for (const item of updates) {
    const row = rows.find((x) => x.id === item.id);
    if (!row) throw error(422, 'KIT_COMPONENT_INVALID', 'Componente de custodia inválido.');
    if (updateIds.has(row.id)) throw error(422, 'KIT_COMPONENT_DUPLICATE', 'Un componente no puede informarse más de una vez.');
    updateIds.add(row.id);
    expectedVersion(item, row);
    const returned = nonNegative(item.returnedQuantity, 'returnedQuantity', 0);
    const missing = nonNegative(item.missingQuantity, 'missingQuantity', 0);
    const issued = Number(row.issued_quantity || 0);
    const accounted = returned + missing;
    if (accounted > issued + 1e-9) throw error(422, 'KIT_RETURN_QUANTITY_INVALID', 'La devolución y faltante superan la entrega.');
    if (options.finalReceipt && Math.abs(accounted - issued) > 1e-9) {
      throw error(422, 'KIT_FINAL_RETURN_QUANTITY_REQUIRED', 'Para recibir físicamente el kit, cada componente debe quedar completamente devuelto o declarado faltante.');
    }
    let condition = String(item.condition || (missing > 0 ? 'INCOMPLETO' : 'CONFORME')).toUpperCase();
    if (condition === 'FALTANTE') condition = 'INCOMPLETO';
    if (missing > 0 && condition === 'CONFORME') condition = 'INCOMPLETO';
    if (!['CONFORME','OBSERVADO','DANADO','INCOMPLETO'].includes(condition)) throw error(422, 'KIT_CONDITION_INVALID', 'Condición de componente de kit inválida.');
    const status = missing > 0 ? 'FALTANTE' : Math.abs(returned - issued) <= 1e-9 ? 'DEVUELTO' : returned > 0 ? 'PARCIALMENTE_DEVUELTO' : 'ENTREGADO';
    const deltaReturn = returned - Number(row.returned_quantity || 0);
    if (deltaReturn < -1e-9) throw error(422, 'KIT_RETURN_ROLLBACK', 'La cantidad devuelta no puede disminuir.');
    const asset = getAssetOrThrow(row.component_asset_id, db);
    if (deltaReturn > 1e-9) {
      if (SERIAL_NATURES.has(asset.category_nature)) {
        db.prepare("UPDATE asset SET status=?,quantity_available=1,custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?")
          .run(condition === 'CONFORME' ? 'DISPONIBLE' : 'BLOQUEADO', now, asset.id);
      } else {
        db.prepare("UPDATE asset SET quantity_available=MIN(quantity_total,quantity_available+?),status=CASE WHEN ?='CONFORME' THEN 'DISPONIBLE' ELSE 'BLOQUEADO' END,version=version+1,updated_at=? WHERE id=?")
          .run(deltaReturn, condition, now, asset.id);
      }
    } else if (status === 'DEVUELTO' && condition !== 'CONFORME') {
      db.prepare("UPDATE asset SET status='BLOQUEADO',custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?").run(now, asset.id);
    }
    const changed = db.prepare('UPDATE kit_custody_component SET returned_quantity=?,missing_quantity=?,condition=?,status=?,version=version+1,updated_at=? WHERE id=? AND version=?')
      .run(returned, missing, condition, status, now, row.id, row.version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Un componente del kit fue modificado durante la recepción.');
  }
  const all = db.prepare('SELECT * FROM kit_custody_component WHERE custody_id=?').all(custodyId);
  const nestedKitRows = db.prepare(`SELECT kcc.* FROM kit_custody_component kcc
    JOIN asset a ON a.id=kcc.component_asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE kcc.custody_id=? AND c.nature='KIT'`).all(custodyId);
  for (const nestedKitRow of nestedKitRows) {
    const descendants = all.filter((row) => row.kit_asset_id === nestedKitRow.component_asset_id);
    const descendantsComplete = descendants.every((row) => row.status === 'DEVUELTO' && row.condition === 'CONFORME');
    if (nestedKitRow.status === 'DEVUELTO' && !descendantsComplete) {
      db.prepare("UPDATE asset SET status='BLOQUEADO',quantity_available=0,custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?")
        .run(now, nestedKitRow.component_asset_id);
    }
  }
  const incomplete = all.some((row) => row.status !== 'DEVUELTO');
  const rank = { CONFORME: 0, OBSERVADO: 1, DANADO: 2, INCOMPLETO: 3 };
  let condition = incomplete ? 'INCOMPLETO' : 'CONFORME';
  for (const row of all) {
    const currentCondition = String(row.condition || 'CONFORME').toUpperCase();
    if ((rank[currentCondition] ?? 0) > (rank[condition] ?? 0)) condition = currentCondition;
  }
  if (condition !== 'CONFORME') {
    db.prepare("UPDATE asset SET status='BLOQUEADO',quantity_available=0,version=version+1,updated_at=? WHERE id=?").run(now, custodyKit.asset_id);
  }
  audit(db, context, 'KIT.RETURN_COMPONENTS', 'custody', custodyId, rows, all, input.reason || (options.finalReceipt ? 'Recepción física de componentes del kit' : 'Devolución parcial o total de componentes'));
  return { custodyId, complete: !incomplete, condition, hasObservation: condition !== 'CONFORME', items: all };
}

function returnKitComponents(custodyId, input, context) {
  return transaction((db) => returnKitComponentsInDb(db, custodyId, input, context));
}
function listKitCustodyComponents(custodyId, user = null, permission = 'Kits.Read') {
  const db = getDb();
  const custodyKit = custodyKitAsset(db, custodyId);
  if (!custodyKit) throw error(404, 'KIT_CUSTODY_COMPONENTS_NOT_FOUND', 'No existe una custodia de kit válida.');
  if (user) assertAssetScope(user, custodyKit.asset_id, permission, db);
  return db.prepare(`SELECT kcc.*,a.internal_code,a.description FROM kit_custody_component kcc JOIN asset a ON a.id=kcc.component_asset_id WHERE kcc.custody_id=? ORDER BY a.internal_code`).all(custodyId);
}

// STOCK Y CONSUMIBLES
function stockLotSelect() {
  return `SELECT sl.*,a.internal_code,a.description,a.unit_of_measure,c.nature AS category_nature,l.code AS location_code,l.name AS location_name,l.site_id,
    (sl.quantity_on_hand-sl.quantity_reserved) AS quantity_available FROM stock_lot sl JOIN asset a ON a.id=sl.asset_id JOIN asset_category c ON c.id=a.category_id JOIN storage_location l ON l.id=sl.location_id`;
}
function syncStockAsset(db, assetId, now = nowIso()) {
  const totals = db.prepare('SELECT COALESCE(SUM(quantity_on_hand),0) AS total,COALESCE(SUM(quantity_on_hand-quantity_reserved),0) AS available FROM stock_lot WHERE asset_id=? AND active=1').get(assetId);
  db.prepare(`UPDATE asset SET quantity_total=?,quantity_available=?,status=CASE WHEN active=0 THEN 'BAJA' WHEN ?>0 THEN 'DISPONIBLE' ELSE 'RESERVADO' END,version=version+1,updated_at=? WHERE id=?`)
    .run(totals.total, totals.available, totals.available, now, assetId);
  return totals;
}
function listStock(filters = {}, user = null, permission = 'Stock.Read') {
  const where = ['sl.active=1']; const args = [];
  if (filters.assetId) { where.push('sl.asset_id=?'); args.push(filters.assetId); }
  if (filters.locationId) { where.push('sl.location_id=?'); args.push(filters.locationId); }
  if (filters.nature) { where.push('c.nature=?'); args.push(String(filters.nature).toUpperCase()); }
  if (filters.expiringBefore) { where.push('sl.expires_at IS NOT NULL AND sl.expires_at<=?'); args.push(filters.expiringBefore); }
  if (filters.unavailable === 'true' || filters.unavailable === true) {
    where.push("a.active=1 AND a.deleted_at IS NULL AND c.active=1 AND c.deleted_at IS NULL AND c.nature IN ('CANTIDAD','CONSUMIBLE') AND (sl.quantity_on_hand-sl.quantity_reserved)<=0");
  }
  if (user) { const scoped = scopeWhere(user, permission, 'l.site_id', 'sl.location_id'); where.push(scoped.sql); args.push(...scoped.params); }
  return getDb().prepare(`${stockLotSelect()} WHERE ${where.join(' AND ')} ORDER BY a.internal_code,sl.expires_at,sl.lot_code LIMIT ?`).all(...args, safeInteger(filters.limit, 500, 1, 2000));
}
function createStockLot(input, context) {
  return transaction((db) => {
    const asset = getAssetOrThrow(input.assetId, db, STOCK_NATURES); const location = getLocationOrThrow(input.locationId || asset.location_id, db);
    assertAssetScope(context.user, asset.id, 'Stock.Operate', db);
    assertLocationScope(context.user, location.id, 'Stock.Operate', db);
    const id = randomUUID(); const now = nowIso(); const quantity = nonNegative(input.quantityOnHand, 'quantityOnHand', 0); const reserved = nonNegative(input.quantityReserved, 'quantityReserved', 0);
    if (reserved > quantity) throw error(422, 'STOCK_RESERVED_INVALID', 'La reserva no puede superar el stock físico.');
    try { db.prepare(`INSERT INTO stock_lot(id,asset_id,location_id,lot_code,expires_at,quantity_on_hand,quantity_reserved,active,version,created_at,updated_at) VALUES (?,?,?,?,?,?,?,1,1,?,?)`)
      .run(id, asset.id, location.id, requiredString(input.lotCode || 'GENERAL', 'lotCode', { min: 1, max: 80 }).toUpperCase(), input.expiresAt ? new Date(input.expiresAt).toISOString() : null, quantity, reserved, now, now); }
    catch (e) { if (String(e.message).includes('UNIQUE')) throw error(409, 'STOCK_LOT_DUPLICATE', 'El lote ya existe en la ubicación.'); throw e; }
    syncStockAsset(db, asset.id, now);
    const after = db.prepare(`${stockLotSelect()} WHERE sl.id=?`).get(id);
    audit(db, context, 'STOCK.LOT_CREATE', 'stock_lot', id, null, after);
    return after;
  });
}
function insertStockMovement(db, input, context, permissionOverride = null) {
  const lot = db.prepare(`${stockLotSelect()} WHERE sl.id=?`).get(input.lotId);
  if (!lot) throw error(404, 'STOCK_LOT_NOT_FOUND', 'Lote de stock no encontrado.');
  const asset = getAssetOrThrow(lot.asset_id, db, STOCK_NATURES);
  const scopePermission = permissionOverride || (String(input.movementType || '').toUpperCase().startsWith('AJUSTE_') ? 'Stock.Adjust' : 'Stock.Operate');
  assertLocationScope(context.user, lot.location_id, scopePermission, db);
  if (input.clientMovementId) {
    const existing = db.prepare('SELECT * FROM stock_movement WHERE client_movement_id=?').get(input.clientMovementId);
    if (existing) return { movement: existing, idempotent: true };
  }
  const type = String(input.movementType || '').toUpperCase(); const qty = positive(input.quantity, 'quantity');
  const valid = new Set(['ENTRADA','SALIDA','CONSUMO','DEVOLUCION','AJUSTE_POSITIVO','AJUSTE_NEGATIVO','RESERVA','LIBERACION','TRANSFERENCIA_SALIDA','TRANSFERENCIA_ENTRADA']);
  if (!valid.has(type)) throw error(422, 'STOCK_MOVEMENT_INVALID', 'Tipo de movimiento inválido.');
  if (asset.category_nature === 'CONSUMIBLE' && type === 'DEVOLUCION' && !input.allowConsumableReturn) throw error(422, 'CONSUMABLE_RETURN_FORBIDDEN', 'El consumible no admite devolución ordinaria.');
  let onHand = lot.quantity_on_hand; let reserved = lot.quantity_reserved;
  if (['ENTRADA','DEVOLUCION','AJUSTE_POSITIVO','TRANSFERENCIA_ENTRADA'].includes(type)) onHand += qty;
  if (['SALIDA','CONSUMO','AJUSTE_NEGATIVO','TRANSFERENCIA_SALIDA'].includes(type)) {
    if (onHand - reserved < qty) throw error(409, 'STOCK_INSUFFICIENT', 'Stock disponible insuficiente.');
    onHand -= qty;
  }
  if (type === 'RESERVA') { if (onHand - reserved < qty) throw error(409, 'STOCK_INSUFFICIENT', 'Stock disponible insuficiente para reservar.'); reserved += qty; }
  if (type === 'LIBERACION') { if (reserved < qty) throw error(409, 'STOCK_RESERVED_INSUFFICIENT', 'Reserva insuficiente para liberar.'); reserved -= qty; }
  if (reserved > onHand) throw error(409, 'STOCK_BALANCE_INVALID', 'El movimiento dejaría una reserva superior al stock.');
  const id = randomUUID(); const now = nowIso(); const number = nextNumber(db, 'stock_movement', 'movement_number', 'MOV');
  db.prepare('UPDATE stock_lot SET quantity_on_hand=?,quantity_reserved=?,version=version+1,updated_at=? WHERE id=? AND version=?').run(onHand, reserved, now, lot.id, lot.version);
  db.prepare(`INSERT INTO stock_movement(id,movement_number,client_movement_id,asset_id,lot_id,movement_type,quantity,quantity_before,quantity_after,reserved_before,reserved_after,reference_type,reference_id,reason,actor_user_id,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, number, input.clientMovementId || null, asset.id, lot.id, type, qty, lot.quantity_on_hand, onHand, lot.quantity_reserved, reserved, input.referenceType || null, input.referenceId || null, requiredString(input.reason, 'reason', { min: 3, max: 1500 }), context.user.id, new Date(input.occurredAt || now).toISOString(), context.correlationId, now);
  syncStockAsset(db, asset.id, now);
  const movement = db.prepare('SELECT * FROM stock_movement WHERE id=?').get(id);
  audit(db, context, 'STOCK.MOVEMENT', 'stock_movement', id, { quantity: lot.quantity_on_hand, reserved: lot.quantity_reserved }, { quantity: onHand, reserved, type, qty }, input.reason);
  return { movement, idempotent: false };
}
function createStockMovement(input, context) { return transaction((db) => insertStockMovement(db, input, context)); }
function listStockMovements(filters = {}, user = null, permission = 'Stock.Read') {
  const where = ['1=1']; const args = [];
  if (filters.assetId) { where.push('sm.asset_id=?'); args.push(filters.assetId); }
  if (filters.lotId) { where.push('sm.lot_id=?'); args.push(filters.lotId); }
  if (filters.movementType) { where.push('sm.movement_type=?'); args.push(String(filters.movementType).toUpperCase()); }
  if (filters.occurredFrom || filters.movementFrom) { where.push('sm.occurred_at>=?'); args.push(new Date(filters.occurredFrom || filters.movementFrom).toISOString()); }
  if (filters.occurredTo || filters.movementTo) { where.push('sm.occurred_at<?'); args.push(new Date(filters.occurredTo || filters.movementTo).toISOString()); }
  if (user) { const scoped = scopeWhere(user, permission, 'l.site_id', 'sl.location_id'); where.push(scoped.sql); args.push(...scoped.params); }
  return getDb().prepare(`SELECT sm.*,a.internal_code,a.description,sl.lot_code,l.code AS location_code,l.site_id,u.username AS actor_username FROM stock_movement sm JOIN asset a ON a.id=sm.asset_id JOIN stock_lot sl ON sl.id=sm.lot_id JOIN storage_location l ON l.id=sl.location_id JOIN user_account u ON u.id=sm.actor_user_id WHERE ${where.join(' AND ')} ORDER BY sm.occurred_at DESC LIMIT ?`).all(...args, safeInteger(filters.limit, 500, 1, 2000));
}

// INVENTARIOS
function inventoryCountDetail(id, db = getDb(), user = null, permission = 'Inventory.Read') {
  const count = db.prepare(`SELECT ic.*,s.name AS site_name,l.name AS location_name,c.name AS category_name,p.full_name AS responsible_name
    FROM inventory_count ic LEFT JOIN site s ON s.id=ic.site_id LEFT JOIN storage_location l ON l.id=ic.location_id LEFT JOIN asset_category c ON c.id=ic.category_id LEFT JOIN person p ON p.id=ic.responsible_person_id WHERE ic.id=?`).get(id);
  if (!count) throw error(404, 'INVENTORY_COUNT_NOT_FOUND', 'Inventario no encontrado.');
  assertCountScope(user, count, permission, db);
  count.items = db.prepare(`SELECT ici.*,a.internal_code,a.description,a.unit_of_measure,sl.lot_code,l.code AS location_code FROM inventory_count_item ici JOIN asset a ON a.id=ici.asset_id LEFT JOIN stock_lot sl ON sl.id=ici.lot_id LEFT JOIN storage_location l ON l.id=COALESCE(sl.location_id,a.location_id) WHERE ici.count_id=? ORDER BY a.internal_code,sl.lot_code`).all(id);
  return count;
}
function listInventoryCounts(filters = {}, user = null, permission = 'Inventory.Read') {
  const where = ['1=1']; const args = [];
  if (filters.status) { where.push('ic.status=?'); args.push(String(filters.status).toUpperCase()); }
  if (filters.locationId) { where.push('ic.location_id=?'); args.push(filters.locationId); }
  if (user) { const scoped = scopeWhere(user, permission, 'COALESCE(ic.site_id,sl.site_id)', 'ic.location_id'); where.push(scoped.sql); args.push(...scoped.params); }
  return getDb().prepare(`SELECT ic.*,sl.code AS location_code,sl.name AS location_name,s.code AS site_code,s.name AS site_name,c.code AS category_code,c.name AS category_name
    FROM inventory_count ic LEFT JOIN storage_location sl ON sl.id=ic.location_id LEFT JOIN site s ON s.id=COALESCE(ic.site_id,sl.site_id) LEFT JOIN asset_category c ON c.id=ic.category_id
    WHERE ${where.join(' AND ')} ORDER BY ic.planned_at DESC LIMIT ?`).all(...args, safeInteger(filters.limit, 250, 1, 1000));
}
function createInventoryCount(input, context) {
  return transaction((db) => {
    if (input.clientCountId) { const existing = db.prepare('SELECT id FROM inventory_count WHERE client_count_id=?').get(input.clientCountId); if (existing) return { ...inventoryCountDetail(existing.id, db, context.user, 'Inventory.Execute'), idempotent: true }; }
    const type = String(input.countType || '').toUpperCase(); if (!['TOTAL','PARCIAL','CICLICO','RESPONSABLE'].includes(type)) throw error(422, 'INVENTORY_TYPE_INVALID', 'Tipo de inventario inválido.');
    if (input.locationId) {
      getLocationOrThrow(input.locationId, db);
      assertLocationScope(context.user, input.locationId, 'Inventory.Execute', db);
    } else if (input.siteId) {
      assertUserScope(context.user, input.siteId, null, 'Inventory.Execute', db);
    } else {
      assertGlobalScope(context.user, 'Inventory.Execute', db);
    }
    const id = randomUUID(); const now = nowIso(); const number = nextNumber(db, 'inventory_count', 'count_number', 'INV');
    db.prepare(`INSERT INTO inventory_count(id,count_number,client_count_id,count_type,status,site_id,location_id,category_id,responsible_person_id,blind_count,notes,planned_at,created_by_user_id,version,created_at,updated_at)
      VALUES (?,?,?,?,'PLANIFICADO',?,?,?,?,?,?,?, ?,1,?,?)`).run(id, number, input.clientCountId || null, type, input.siteId || null, input.locationId || null, input.categoryId || null, input.responsiblePersonId || null, parseBoolean(input.blindCount, false) ? 1 : 0, optionalString(input.notes, 'notes', { max: 2000 }), new Date(input.plannedAt || now).toISOString(), context.user.id, now, now);
    const where = ['a.active=1','a.deleted_at IS NULL']; const args = [];
    if (input.locationId) { where.push('a.location_id=?'); args.push(input.locationId); }
    if (input.siteId) { where.push('asset_location.site_id=?'); args.push(input.siteId); }
    if (input.categoryId) { where.push('a.category_id=?'); args.push(input.categoryId); }
    if (input.responsiblePersonId) { where.push('a.custodian_person_id=?'); args.push(input.responsiblePersonId); }
    const assets = db.prepare(`SELECT a.*,c.nature AS category_nature FROM asset a JOIN asset_category c ON c.id=a.category_id JOIN storage_location asset_location ON asset_location.id=a.location_id WHERE ${where.join(' AND ')} ORDER BY a.internal_code`).all(...args);
    const insert = db.prepare(`INSERT INTO inventory_count_item(id,count_id,asset_id,lot_id,expected_quantity,status,version,created_at,updated_at) VALUES (?,?,?,?,?,'PENDIENTE',1,?,?)`);
    for (const asset of assets) {
      if (STOCK_NATURES.has(asset.category_nature)) {
        let lots = db.prepare('SELECT * FROM stock_lot WHERE asset_id=? AND active=1' + (input.locationId ? ' AND location_id=?' : '')).all(...(input.locationId ? [asset.id, input.locationId] : [asset.id]));
        if (!lots.length) {
          const lotId = randomUUID(); db.prepare(`INSERT INTO stock_lot(id,asset_id,location_id,lot_code,quantity_on_hand,quantity_reserved,active,version,created_at,updated_at) VALUES (?,?,?,'GENERAL',?,?,1,1,?,?)`).run(lotId, asset.id, asset.location_id, asset.quantity_total, Math.max(0, asset.quantity_total-asset.quantity_available), now, now);
          lots = db.prepare('SELECT * FROM stock_lot WHERE id=?').all(lotId);
        }
        for (const lot of lots) insert.run(randomUUID(), id, asset.id, lot.id, lot.quantity_on_hand, now, now);
      } else insert.run(randomUUID(), id, asset.id, null, asset.status === 'BAJA' ? 0 : 1, now, now);
    }
    const after = inventoryCountDetail(id, db); audit(db, context, 'INVENTORY.PLAN', 'inventory_count', id, null, after, input.notes);
    return { ...after, idempotent: false };
  });
}
function openInventoryCount(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM inventory_count WHERE id=?').get(id); if (!current) throw error(404, 'INVENTORY_COUNT_NOT_FOUND', 'Inventario no encontrado.'); assertCountScope(context.user, current, 'Inventory.Execute', db); expectedVersion(input, current);
    if (current.status !== 'PLANIFICADO') throw error(409, 'INVENTORY_OPEN_NOT_ALLOWED', 'Solo un inventario planificado puede abrirse.');
    const now = nowIso(); db.prepare("UPDATE inventory_count SET status='ABIERTO',opened_at=?,opened_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now, context.user.id, now, id, current.version);
    const after = inventoryCountDetail(id, db); audit(db, context, 'INVENTORY.OPEN', 'inventory_count', id, current, after, input.reason || 'Apertura de conteo'); return after;
  });
}
function recordInventoryCountItem(itemId, input, context) {
  return transaction((db) => {
    const item = db.prepare('SELECT ici.*,ic.status AS count_status,ic.id AS count_id,ic.version AS count_version,ic.site_id,ic.location_id FROM inventory_count_item ici JOIN inventory_count ic ON ic.id=ici.count_id WHERE ici.id=?').get(itemId);
    if (!item) throw error(404, 'INVENTORY_ITEM_NOT_FOUND', 'Ítem de inventario no encontrado.'); assertCountScope(context.user, item, 'Inventory.Execute', db); expectedVersion(input, item);
    if (!['ABIERTO','CONTEO'].includes(item.count_status)) throw error(409, 'INVENTORY_COUNT_NOT_OPEN', 'El inventario no admite conteos.');
    const counted = nonNegative(input.countedQuantity, 'countedQuantity', 0); const difference = counted - item.expected_quantity; const status = difference === 0 ? 'CONTADO' : 'DIFERENCIA'; const now = nowIso();
    db.prepare('UPDATE inventory_count_item SET counted_quantity=?,difference_quantity=?,status=?,counted_by_user_id=?,counted_at=?,version=version+1,updated_at=? WHERE id=? AND version=?').run(counted, difference, status, context.user.id, now, now, itemId, item.version);
    db.prepare("UPDATE inventory_count SET status='CONTEO',version=version+1,updated_at=? WHERE id=? AND status='ABIERTO'").run(now, item.count_id);
    const after = db.prepare('SELECT * FROM inventory_count_item WHERE id=?').get(itemId); audit(db, context, 'INVENTORY.COUNT_ITEM', 'inventory_count_item', itemId, item, after); return after;
  });
}
function reconcileInventoryItem(itemId, input, context, canAdjust = false) {
  return transaction((db) => {
    const item = db.prepare(`SELECT ici.*,ic.status AS count_status,ic.id AS count_id,ic.site_id,ic.location_id FROM inventory_count_item ici JOIN inventory_count ic ON ic.id=ici.count_id WHERE ici.id=?`).get(itemId);
    if (!item) throw error(404, 'INVENTORY_ITEM_NOT_FOUND', 'Ítem de inventario no encontrado.'); assertCountScope(context.user, item, 'Inventory.Reconcile', db); expectedVersion(input, item);
    if (!['CONTEO','CONCILIACION'].includes(item.count_status) || item.counted_quantity == null) throw error(409, 'INVENTORY_RECONCILE_NOT_ALLOWED', 'El ítem no está listo para conciliación.');
    const resolution = String(input.resolution || '').toUpperCase(); if (!['ACEPTAR_CONTEO','MANTENER_SISTEMA','AJUSTAR','INVESTIGAR'].includes(resolution)) throw error(422, 'INVENTORY_RESOLUTION_INVALID', 'Resolución inválida.');
    if (resolution === 'AJUSTAR' && !canAdjust) throw error(403, 'INVENTORY_ADJUST_FORBIDDEN', 'No posee permiso para ajustar stock.');
    const reason = requiredString(input.reason, 'reason', { min: 5, max: 1500 }); const now = nowIso(); let status = resolution === 'AJUSTAR' ? 'AJUSTADO' : resolution === 'INVESTIGAR' ? 'DIFERENCIA' : 'CONCILIADO';
    let adjustmentId = null;
    if (resolution === 'AJUSTAR' && item.difference_quantity !== 0) {
      const asset = getAssetOrThrow(item.asset_id, db); let movementId = null;
      if (STOCK_NATURES.has(asset.category_nature)) {
        if (!item.lot_id) throw error(409, 'STOCK_LOT_REQUIRED', 'El ajuste por cantidad requiere lote.');
        const result = insertStockMovement(db, { lotId: item.lot_id, movementType: item.difference_quantity > 0 ? 'AJUSTE_POSITIVO' : 'AJUSTE_NEGATIVO', quantity: Math.abs(item.difference_quantity), reason, referenceType: 'INVENTORY_COUNT_ITEM', referenceId: item.id }, context, 'Inventory.Adjust');
        movementId = result.movement.id;
      } else {
        const found = item.counted_quantity > 0;
        db.prepare('UPDATE asset SET status=?,quantity_available=?,version=version+1,updated_at=? WHERE id=?').run(found ? 'DISPONIBLE' : 'PERDIDO', found ? 1 : 0, now, asset.id);
      }
      adjustmentId = randomUUID(); db.prepare('INSERT INTO inventory_adjustment(id,count_item_id,asset_id,lot_id,quantity_delta,reason,approved_by_user_id,stock_movement_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(adjustmentId, item.id, item.asset_id, item.lot_id, item.difference_quantity, reason, context.user.id, movementId, now);
    }
    db.prepare('UPDATE inventory_count_item SET status=?,resolution=?,resolution_reason=?,reconciled_by_user_id=?,reconciled_at=?,version=version+1,updated_at=? WHERE id=? AND version=?').run(status, resolution, reason, context.user.id, now, now, item.id, item.version);
    db.prepare("UPDATE inventory_count SET status='CONCILIACION',version=version+1,updated_at=? WHERE id=? AND status IN ('ABIERTO','CONTEO')").run(now, item.count_id);
    const after = db.prepare('SELECT * FROM inventory_count_item WHERE id=?').get(item.id); audit(db, context, 'INVENTORY.RECONCILE_ITEM', 'inventory_count_item', item.id, item, { ...after, adjustmentId }, reason); return { ...after, adjustmentId };
  });
}
function closeInventoryCount(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM inventory_count WHERE id=?').get(id); if (!current) throw error(404, 'INVENTORY_COUNT_NOT_FOUND', 'Inventario no encontrado.'); assertCountScope(context.user, current, 'Inventory.Close', db); expectedVersion(input, current);
    if (!['CONTEO','CONCILIACION'].includes(current.status)) throw error(409, 'INVENTORY_CLOSE_NOT_ALLOWED', 'El inventario no está en etapa de cierre.');
    const unresolved = db.prepare("SELECT COUNT(*) AS n FROM inventory_count_item WHERE count_id=? AND status IN ('PENDIENTE','DIFERENCIA')").get(id).n;
    if (unresolved) throw error(422, 'INVENTORY_DIFFERENCES_UNRESOLVED', `Existen ${unresolved} ítems pendientes o con diferencias sin resolver.`);
    const now = nowIso(); db.prepare("UPDATE inventory_count SET status='CERRADO',closed_at=?,closed_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(now, context.user.id, now, id, current.version);
    const after = inventoryCountDetail(id, db); audit(db, context, 'INVENTORY.CLOSE', 'inventory_count', id, current, after, requiredString(input.reason, 'reason', { min: 5, max: 1500 })); return after;
  });
}

// TRANSFERENCIAS INTERNAS
function transferDetail(id, db = getDb(), user = null, permission = 'Transfers.Read', mode = 'either') {
  const transfer = db.prepare(`SELECT it.*,f.code AS from_code,f.name AS from_name,t.code AS to_code,t.name AS to_name FROM inventory_transfer it JOIN storage_location f ON f.id=it.from_location_id JOIN storage_location t ON t.id=it.to_location_id WHERE it.id=?`).get(id);
  if (!transfer) throw error(404, 'TRANSFER_NOT_FOUND', 'Transferencia no encontrada.');
  assertTransferScope(user, transfer, permission, mode, db);
  transfer.items = db.prepare(`SELECT iti.*,a.internal_code,a.description,c.nature AS category_nature,sl.lot_code AS source_lot_code FROM inventory_transfer_item iti JOIN asset a ON a.id=iti.asset_id JOIN asset_category c ON c.id=a.category_id LEFT JOIN stock_lot sl ON sl.id=iti.source_lot_id WHERE iti.transfer_id=? ORDER BY a.internal_code`).all(id).map((x) => ({ ...x, assetSnapshot: JSON.parse(x.asset_snapshot_json || '{}') }));
  return transfer;
}
function listInventoryTransfers(filters = {}, user = null, permission = 'Transfers.Read') {
  const where = ['1=1']; const args = [];
  if (filters.status) { where.push('it.status=?'); args.push(String(filters.status).toUpperCase()); }
  if (filters.locationId) { where.push('(it.from_location_id=? OR it.to_location_id=?)'); args.push(filters.locationId, filters.locationId); }
  if (user) {
    const fromScope = scopeWhere(user, permission, 'f.site_id', 'it.from_location_id');
    const toScope = scopeWhere(user, permission, 't.site_id', 'it.to_location_id');
    where.push(`((${fromScope.sql}) OR (${toScope.sql}))`); args.push(...fromScope.params, ...toScope.params);
  }
  return getDb().prepare(`SELECT it.*,f.code AS from_code,f.site_id AS from_site_id,t.code AS to_code,t.site_id AS to_site_id FROM inventory_transfer it JOIN storage_location f ON f.id=it.from_location_id JOIN storage_location t ON t.id=it.to_location_id WHERE ${where.join(' AND ')} ORDER BY it.created_at DESC LIMIT ?`).all(...args, safeInteger(filters.limit, 250, 1, 1000));
}
function createInventoryTransfer(input, context) {
  return transaction((db) => {
    if (input.clientTransferId) { const existing = db.prepare('SELECT id FROM inventory_transfer WHERE client_transfer_id=?').get(input.clientTransferId); if (existing) return { ...transferDetail(existing.id, db, context.user, 'Transfers.Create'), idempotent: true }; }
    const from = getLocationOrThrow(input.fromLocationId, db); const to = getLocationOrThrow(input.toLocationId, db);
    assertLocationScope(context.user, from.id, 'Transfers.Create', db);
    assertLocationScope(context.user, to.id, 'Transfers.Create', db); if (from.id === to.id) throw error(422, 'TRANSFER_SAME_LOCATION', 'Origen y destino deben ser diferentes.');
    const items = requiredArray(input.items, 'items', 200); if (!items.length) throw error(422, 'TRANSFER_ITEMS_REQUIRED', 'Debe incluir al menos un bien.');
    const id = randomUUID(); const now = nowIso(); const number = nextNumber(db, 'inventory_transfer', 'transfer_number', 'TRF');
    db.prepare(`INSERT INTO inventory_transfer(id,transfer_number,client_transfer_id,from_location_id,to_location_id,status,reason,created_by_user_id,version,correlation_id,created_at,updated_at) VALUES (?,?,?,?,?,'BORRADOR',?,?,1,?,?,?)`).run(id, number, input.clientTransferId || null, from.id, to.id, requiredString(input.reason, 'reason', { min: 5, max: 1500 }), context.user.id, context.correlationId, now, now);
    const insert = db.prepare(`INSERT INTO inventory_transfer_item(id,transfer_id,asset_id,source_lot_id,quantity,status,asset_snapshot_json,created_at,updated_at) VALUES (?,?,?,?,?,'PENDIENTE',?,?,?)`);
    const seen = new Set();
    for (const item of items) {
      const asset = getAssetOrThrow(item.assetId, db); const qty = positive(item.quantity, 'quantity'); const key = `${asset.id}:${item.sourceLotId || ''}`; if (seen.has(key)) throw error(422, 'TRANSFER_ITEM_DUPLICATE', 'Ítem de transferencia duplicado.'); seen.add(key);
      if (SERIAL_NATURES.has(asset.category_nature)) {
        if (asset.location_id !== from.id || asset.status !== 'DISPONIBLE' || qty !== 1) throw error(409, 'TRANSFER_ASSET_UNAVAILABLE', `El bien ${asset.internal_code} no está disponible en el origen.`);
        insert.run(randomUUID(), id, asset.id, null, 1, JSON.stringify({ locationId: asset.location_id, status: asset.status, version: asset.version }), now, now);
      } else {
        const lot = db.prepare('SELECT * FROM stock_lot WHERE id=? AND asset_id=? AND location_id=? AND active=1').get(item.sourceLotId, asset.id, from.id);
        if (!lot || lot.quantity_on_hand-lot.quantity_reserved < qty) throw error(409, 'TRANSFER_STOCK_UNAVAILABLE', `Stock insuficiente para ${asset.internal_code}.`);
        insert.run(randomUUID(), id, asset.id, lot.id, qty, JSON.stringify({ lotId: lot.id, quantity: lot.quantity_on_hand, reserved: lot.quantity_reserved, version: lot.version }), now, now);
      }
    }
    const after = transferDetail(id, db); audit(db, context, 'TRANSFER.CREATE', 'inventory_transfer', id, null, after, input.reason); return { ...after, idempotent: false };
  });
}
function dispatchInventoryTransfer(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM inventory_transfer WHERE id=?').get(id); if (!current) throw error(404, 'TRANSFER_NOT_FOUND', 'Transferencia no encontrada.'); assertTransferScope(context.user, current, 'Transfers.Dispatch', 'from', db); expectedVersion(input, current); if (current.status !== 'BORRADOR') throw error(409, 'TRANSFER_DISPATCH_NOT_ALLOWED', 'Solo una transferencia en borrador puede despacharse.');
    const items = db.prepare(`SELECT iti.*,a.category_id,c.nature AS category_nature,a.location_id,a.status,a.version AS asset_version FROM inventory_transfer_item iti JOIN asset a ON a.id=iti.asset_id JOIN asset_category c ON c.id=a.category_id WHERE iti.transfer_id=?`).all(id); const now = nowIso();
    for (const item of items) {
      if (SERIAL_NATURES.has(item.category_nature)) {
        const changed = db.prepare("UPDATE asset SET status='BLOQUEADO',quantity_available=0,version=version+1,updated_at=? WHERE id=? AND location_id=? AND status='DISPONIBLE' AND version=?").run(now, item.asset_id, current.from_location_id, item.asset_version);
        if (changed.changes !== 1) throw error(409, 'TRANSFER_ASSET_CONFLICT', 'Un bien dejó de estar disponible para despacho.');
      } else insertStockMovement(db, { lotId: item.source_lot_id, movementType: 'TRANSFERENCIA_SALIDA', quantity: item.quantity, reason: `Despacho ${current.transfer_number}`, referenceType: 'INVENTORY_TRANSFER', referenceId: id }, context, 'Transfers.Dispatch');
      db.prepare("UPDATE inventory_transfer_item SET status='DESPACHADO',updated_at=? WHERE id=?").run(now, item.id);
    }
    db.prepare("UPDATE inventory_transfer SET status='EN_TRANSITO',dispatched_by_user_id=?,dispatched_at=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(context.user.id, now, now, id, current.version);
    const after = transferDetail(id, db); audit(db, context, 'TRANSFER.DISPATCH', 'inventory_transfer', id, current, after, requiredString(input.reason, 'reason', { min: 5, max: 1500 })); return after;
  });
}
function receiveInventoryTransfer(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM inventory_transfer WHERE id=?').get(id); if (!current) throw error(404, 'TRANSFER_NOT_FOUND', 'Transferencia no encontrada.'); assertTransferScope(context.user, current, 'Transfers.Receive', 'to', db); expectedVersion(input, current); if (current.status !== 'EN_TRANSITO') throw error(409, 'TRANSFER_RECEIVE_NOT_ALLOWED', 'La transferencia no está en tránsito.');
    const items = db.prepare(`SELECT iti.*,c.nature AS category_nature,a.version AS asset_version FROM inventory_transfer_item iti JOIN asset a ON a.id=iti.asset_id JOIN asset_category c ON c.id=a.category_id WHERE iti.transfer_id=?`).all(id); const now = nowIso();
    for (const item of items) {
      if (SERIAL_NATURES.has(item.category_nature)) db.prepare("UPDATE asset SET location_id=?,status='DISPONIBLE',quantity_available=1,version=version+1,updated_at=? WHERE id=? AND status='BLOQUEADO'").run(current.to_location_id, now, item.asset_id);
      else {
        const source = db.prepare('SELECT * FROM stock_lot WHERE id=?').get(item.source_lot_id); const lotCode = source?.lot_code || 'GENERAL';
        let dest = db.prepare('SELECT * FROM stock_lot WHERE asset_id=? AND location_id=? AND lot_code=?').get(item.asset_id, current.to_location_id, lotCode);
        if (!dest) { const lotId = randomUUID(); db.prepare(`INSERT INTO stock_lot(id,asset_id,location_id,lot_code,expires_at,quantity_on_hand,quantity_reserved,active,version,created_at,updated_at) VALUES (?,?,?,?,?,0,0,1,1,?,?)`).run(lotId, item.asset_id, current.to_location_id, lotCode, source?.expires_at || null, now, now); dest = db.prepare('SELECT * FROM stock_lot WHERE id=?').get(lotId); }
        const movement = insertStockMovement(db, { lotId: dest.id, movementType: 'TRANSFERENCIA_ENTRADA', quantity: item.quantity, reason: `Recepción ${current.transfer_number}`, referenceType: 'INVENTORY_TRANSFER', referenceId: id }, context, 'Transfers.Receive');
        db.prepare('UPDATE inventory_transfer_item SET destination_lot_id=?,status=\'RECIBIDO\',updated_at=? WHERE id=?').run(movement.movement.lot_id, now, item.id);
      }
      if (SERIAL_NATURES.has(item.category_nature)) db.prepare("UPDATE inventory_transfer_item SET status='RECIBIDO',updated_at=? WHERE id=?").run(now, item.id);
    }
    db.prepare("UPDATE inventory_transfer SET status='RECIBIDA',received_by_user_id=?,received_at=?,version=version+1,updated_at=? WHERE id=? AND version=?").run(context.user.id, now, now, id, current.version);
    const after = transferDetail(id, db); audit(db, context, 'TRANSFER.RECEIVE', 'inventory_transfer', id, current, after, requiredString(input.reason, 'reason', { min: 5, max: 1500 })); return after;
  });
}
function cancelInventoryTransfer(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM inventory_transfer WHERE id=?').get(id); if (!current) throw error(404, 'TRANSFER_NOT_FOUND', 'Transferencia no encontrada.'); assertTransferScope(context.user, current, 'Transfers.Cancel', 'from', db); expectedVersion(input, current); if (current.status !== 'BORRADOR') throw error(409, 'TRANSFER_CANCEL_NOT_ALLOWED', 'Solo una transferencia no despachada puede cancelarse.');
    const now = nowIso(); db.prepare("UPDATE inventory_transfer SET status='CANCELADA',version=version+1,updated_at=? WHERE id=? AND version=?").run(now, id, current.version); db.prepare("UPDATE inventory_transfer_item SET status='CANCELADO',updated_at=? WHERE transfer_id=?").run(now, id);
    const after = transferDetail(id, db); audit(db, context, 'TRANSFER.CANCEL', 'inventory_transfer', id, current, after, requiredString(input.reason, 'reason', { min: 5, max: 1500 })); return after;
  });
}

module.exports = {
  getVehicleProfile, saveVehicleProfile, listVehicleAuthorizations, createVehicleAuthorization, registerVehicleOperation, listVehicleOperations,
  getKitDefinition, saveKitDefinition, listKitComponentCandidates, validateKitAvailability, issueKitComponents, issueKitComponentsInDb, returnKitComponents, returnKitComponentsInDb, listKitCustodyComponents,
  listStock, createStockLot, createStockMovement, listStockMovements,
  listInventoryCounts, createInventoryCount, inventoryCountDetail, openInventoryCount, recordInventoryCountItem, reconcileInventoryItem, closeInventoryCount,
  listInventoryTransfers, createInventoryTransfer, transferDetail, dispatchInventoryTransfer, receiveInventoryTransfer, cancelInventoryTransfer
};
