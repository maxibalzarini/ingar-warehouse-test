'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const http = require('node:http');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { EventEmitter } = require('node:events');
const runtime = require('../config/runtime');
const {
  getNetworkStatus,
  refreshNetworkStatus,
  isIpv4Private
} = require('./network-service');
const { svg } = require('./qr-code-service');

const FIREWALL_RULE_NAME = 'INGAR Warehouse Server - Acceso Web';
const MIN_WINDOWS_BUILD = 14393; // Windows Server 2016 / Windows 10 1607.
const DEFAULT_PORT = 4317;
const EVIDENCE_FILE = 'startup-deployment-s6.json';
const MANIFEST_FILE = 'MANIFIESTO_SHA256_EJECUTABLE.json';
const FIREWALL_MARKER_SCHEMA = 'INGAR_FIREWALL_PROVISION_V1';

let installRoot = null;
let serverStateProvider = () => ({ local: null, network: getNetworkStatus() });
let platformProvider = () => process.platform;
let archProvider = () => process.arch;
let releaseProvider = () => os.release();
let nowProvider = () => new Date();
let firewallProvider = inspectFirewallRule;
let networkRefreshProvider = refreshNetworkStatus;
let manifestProvider = verifyDistributionManifest;
let databaseProvider = inspectDatabase;
let endpointProvider = inspectOperationalEndpoints;
let dataDirProvider = () => runtime.dataDir;
let current = null;
let refreshInFlight = null;
const events = new EventEmitter();

function nowIso() {
  return nowProvider().toISOString();
}

function evidencePath() {
  return path.join(dataDirProvider(), EVIDENCE_FILE);
}

function parseBuildNumber(release = releaseProvider()) {
  const parts = String(release || '').split('.').map((part) => Number.parseInt(part, 10));
  const build = parts.length >= 3 && Number.isInteger(parts[2]) ? parts[2] : null;
  return { release: String(release || ''), build };
}

function makeCheck(id, label, passed, detail, repairable = false) {
  return Object.freeze({
    id,
    label,
    passed: Boolean(passed),
    detail: String(detail || ''),
    blocking: true,
    repairable: Boolean(repairable)
  });
}

function hashText(value) {
  return crypto.createHash('sha256').update(String(value || ''), 'utf8').digest('hex');
}

function hashFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function normalizedAbsolutePath(value) {
  const resolved = path.resolve(String(value || ''));
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
}

function inspectLauncherExecutable(target) {
  const result = {
    ok: false,
    detail: 'El lanzador no cumple el contrato PE x64.',
    size: null,
    machine: null,
    optionalMagic: null
  };

  try {
    const stat = fs.statSync(target);
    result.size = stat.size;
    // El empaquetado portable puede presentar un lanzador pequeño en ejecución
    // aunque la distribución original contenga el contenedor autocontenido grande.
    // La identidad del resto del paquete continúa protegida por SHA-256.
    if (!stat.isFile() || stat.size < 256 * 1024 || stat.size > 512 * 1024 * 1024) {
      result.detail = 'El lanzador está ausente, truncado o fuera del rango estructural permitido.';
      return result;
    }

    const descriptor = fs.openSync(target, 'r');
    try {
      const dosHeader = Buffer.alloc(64);
      if (fs.readSync(descriptor, dosHeader, 0, dosHeader.length, 0) !== dosHeader.length) {
        result.detail = 'No fue posible leer la cabecera DOS completa.';
        return result;
      }
      if (dosHeader[0] !== 0x4d || dosHeader[1] !== 0x5a) {
        result.detail = 'El lanzador no contiene la firma MZ.';
        return result;
      }

      const peOffset = dosHeader.readUInt32LE(0x3c);
      if (peOffset < 64 || peOffset > stat.size - 26) {
        result.detail = 'La ubicación de la cabecera PE es inválida.';
        return result;
      }

      const peHeader = Buffer.alloc(26);
      if (fs.readSync(descriptor, peHeader, 0, peHeader.length, peOffset) !== peHeader.length) {
        result.detail = 'No fue posible leer la cabecera PE completa.';
        return result;
      }
      if (peHeader[0] !== 0x50 || peHeader[1] !== 0x45 || peHeader[2] !== 0x00 || peHeader[3] !== 0x00) {
        result.detail = 'El lanzador no contiene la firma PE.';
        return result;
      }

      result.machine = peHeader.readUInt16LE(4);
      result.optionalMagic = peHeader.readUInt16LE(24);
      if (result.machine !== 0x8664 || result.optionalMagic !== 0x020b) {
        result.detail = `Arquitectura PE inválida: machine=0x${result.machine.toString(16)}, magic=0x${result.optionalMagic.toString(16)}.`;
        return result;
      }
    } finally {
      fs.closeSync(descriptor);
    }

    result.ok = true;
    result.detail = 'Lanzador validado estructuralmente como PE32+ x64.';
    return result;
  } catch (error) {
    result.detail = `No fue posible validar el lanzador: ${error.message}`;
    return result;
  }
}

async function verifyDistributionManifest() {
  const root = installRoot || path.dirname(process.execPath);
  const manifestPath = path.join(root, MANIFEST_FILE);
  if (!fs.existsSync(manifestPath)) {
    return { ok: false, code: 'MANIFEST_MISSING', detail: `Falta ${MANIFEST_FILE}.`, treeSha256: null, fileCount: 0 };
  }

  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (error) {
    return { ok: false, code: 'MANIFEST_INVALID', detail: `El manifiesto no es válido: ${error.message}`, treeSha256: null, fileCount: 0 };
  }

  const supportedManifestSchemas = new Set([2, 3]);
  if (!supportedManifestSchemas.has(Number(manifest.schemaVersion)) || !Array.isArray(manifest.files) || manifest.algorithm !== 'sha256' || manifest.manifestSelfExcluded !== true) {
    return {
      ok: false,
      code: 'MANIFEST_INVALID',
      detail: `El manifiesto no cumple el contrato SHA-256 soportado (schema 2/3; detectado ${manifest.schemaVersion ?? 'sin versión'}).`,
      treeSha256: manifest.treeSha256 || null,
      fileCount: 0
    };
  }

  const expectedVersion = current?.version || runtime.sourceVersion;
  if (manifest.applicationVersion !== expectedVersion) {
    return {
      ok: false,
      code: 'MANIFEST_VERSION_MISMATCH',
      detail: `El manifiesto corresponde a ${manifest.applicationVersion || 'otra versión'} y la aplicación a ${expectedVersion}.`,
      treeSha256: manifest.treeSha256 || null,
      fileCount: 0
    };
  }

  if (Number(manifest.fileCount) !== manifest.files.length || manifest.files.length < 1) {
    return { ok: false, code: 'MANIFEST_COUNT_MISMATCH', detail: 'La cantidad de archivos del manifiesto es inválida.', treeSha256: manifest.treeSha256 || null, fileCount: 0 };
  }

  const seen = new Set();
  let previousPath = null;
  for (const entry of manifest.files) {
    const relative = String(entry?.path || '').replaceAll('\\', '/');
    if (!relative || relative.startsWith('/') || relative.includes('../') || relative.includes('/..')) {
      return { ok: false, code: 'MANIFEST_PATH_INVALID', detail: `Ruta inválida en manifiesto: ${relative}`, treeSha256: manifest.treeSha256 || null, fileCount: 0 };
    }
    if (seen.has(relative) || (previousPath !== null && previousPath >= relative)) {
      return { ok: false, code: 'MANIFEST_ORDER_INVALID', detail: `Ruta duplicada o desordenada: ${relative}`, treeSha256: manifest.treeSha256 || null, fileCount: 0 };
    }
    seen.add(relative);
    previousPath = relative;
  }

  const canonicalTree = manifest.files.map((entry) => `${entry.path}\0${entry.size}\0${entry.sha256}\n`).join('');
  const calculatedTree = crypto.createHash('sha256').update(Buffer.from(canonicalTree, 'utf8')).digest('hex');
  if (calculatedTree !== String(manifest.treeSha256 || '').toLowerCase()) {
    return { ok: false, code: 'MANIFEST_TREE_MISMATCH', detail: 'La huella global del manifiesto no coincide con sus entradas.', treeSha256: manifest.treeSha256 || null, fileCount: 0 };
  }

  const resolvedRoot = path.resolve(root);
  let activeExecutableCompatibility = null;
  for (const entry of manifest.files) {
    const relative = String(entry.path).replaceAll('\\', '/');
    const target = path.resolve(resolvedRoot, ...relative.split('/'));
    if (!target.startsWith(`${resolvedRoot}${path.sep}`) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
      return { ok: false, code: 'MANIFEST_FILE_MISSING', detail: `Falta el archivo verificado: ${relative}`, treeSha256: manifest.treeSha256 || null, fileCount: 0 };
    }

    const stat = fs.statSync(target);
    const isLauncher = relative.toLowerCase() === 'ingar warehouse.exe';

    // El lanzador Electron portable puede materializarse con un tamaño distinto
    // al contenedor distribuido. Se valida siempre por estructura PE32+ x64 y no
    // bloquea por tamaño/hash. Todos los demás archivos conservan SHA-256 estricto.
    if (isLauncher) {
      const executable = inspectLauncherExecutable(target);
      if (!executable.ok) {
        return {
          ok: false,
          code: 'LAUNCHER_EXECUTABLE_INVALID',
          detail: `${relative}: ${executable.detail}`,
          treeSha256: manifest.treeSha256 || null,
          fileCount: 0
        };
      }
      if (stat.size !== Number(entry.size)) {
        activeExecutableCompatibility = executable;
        continue;
      }
      const launcherDigest = await hashFile(target);
      if (launcherDigest !== String(entry.sha256 || '').toLowerCase()) {
        activeExecutableCompatibility = executable;
      }
      continue;
    }

    if (stat.size !== Number(entry.size)) {
      return {
        ok: false,
        code: 'MANIFEST_SIZE_MISMATCH',
        detail: `Tamaño incorrecto: ${relative}; esperado ${entry.size} bytes, detectado ${stat.size} bytes.`,
        treeSha256: manifest.treeSha256 || null,
        fileCount: 0
      };
    }

    const digest = await hashFile(target);
    if (digest !== String(entry.sha256 || '').toLowerCase()) {
      return { ok: false, code: 'MANIFEST_HASH_MISMATCH', detail: `Integridad rechazada: ${relative}`, treeSha256: manifest.treeSha256 || null, fileCount: 0 };
    }
  }

  const shaVerified = manifest.files.length - (activeExecutableCompatibility ? 1 : 0);
  return {
    ok: true,
    code: activeExecutableCompatibility ? 'MANIFEST_OK_LAUNCHER_COMPATIBILITY' : 'MANIFEST_OK',
    detail: activeExecutableCompatibility
      ? `${shaVerified} archivos verificados por SHA-256 y lanzador PE32+ x64 validado.`
      : `${manifest.files.length} archivos verificados por SHA-256.`,
    treeSha256: manifest.treeSha256 || null,
    fileCount: manifest.files.length,
    activeExecutableCompatibility: Boolean(activeExecutableCompatibility)
  };
}

function powershellJson(script, timeoutMs = 10_000) {
  return new Promise((resolve, reject) => {
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], {
      windowsHide: true,
      timeout: timeoutMs,
      maxBuffer: 1024 * 1024
    }, (error, stdout, stderr) => {
      if (error) return reject(Object.assign(error, { stderr: String(stderr || '') }));
      try {
        const text = String(stdout || '').trim();
        resolve(text ? JSON.parse(text) : null);
      } catch (parseError) {
        reject(parseError);
      }
    });
  });
}


function firewallMarkerPath() {
  const programData = process.env.ProgramData || process.env.PROGRAMDATA || 'C:\\ProgramData';
  return path.join(programData, 'INGAR', 'Warehouse Server', 'firewall-4317.json');
}

function inspectFirewallProvisionMarker() {
  const markerPath = firewallMarkerPath();
  try {
    const marker = JSON.parse(fs.readFileSync(markerPath, 'utf8').replace(/^\uFEFF/, ''));
    const valid = marker?.schema === FIREWALL_MARKER_SCHEMA
      && marker?.ruleName === FIREWALL_RULE_NAME
      && Number(marker?.port) === DEFAULT_PORT
      && String(marker?.protocol || '').toUpperCase() === 'TCP'
      && marker?.enabled === true
      && (!Array.isArray(marker?.blockingRulesDetected) || marker.blockingRulesDetected.length === 0);
    if (!valid) return { status: 'UNVERIFIED', ready: false, detail: 'El comprobante administrativo del firewall es inválido.' };
    return {
      status: 'READY',
      ready: true,
      detail: `Regla entrante TCP ${DEFAULT_PORT} provisionada y comprobante administrativo válido.`,
      source: 'ADMIN_MARKER',
      markerPath
    };
  } catch (error) {
    return {
      status: 'UNVERIFIED',
      ready: false,
      detail: `La cuenta estándar no puede verificar el firewall y no existe un comprobante administrativo válido (${error.code || 'MARKER_MISSING'}).`
    };
  }
}

async function inspectFirewallRule() {
  if (platformProvider() !== 'win32') {
    return { status: 'NOT_REQUIRED', ready: true, detail: 'El firewall de Windows no aplica en este entorno.' };
  }

  const escapedName = FIREWALL_RULE_NAME.replace(/'/g, "''");
  const script = String.raw`
$ErrorActionPreference = 'Stop'
$rules = @(Get-NetFirewallRule -DisplayName '${escapedName}' -ErrorAction SilentlyContinue)
if (-not $rules -or $rules.Count -eq 0) {
  $rules = @(Get-NetFirewallRule -Direction Inbound -Action Allow -Enabled True -ErrorAction Stop)
}
$valid = $false
$details = @()
foreach ($rule in $rules) {
  $ports = @($rule | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue)
  foreach ($port in $ports) {
    $protocol = [string]$port.Protocol
    $localPort = [string]$port.LocalPort
    $isValid = ([string]$rule.Enabled -eq 'True' -and [string]$rule.Direction -eq 'Inbound' -and [string]$rule.Action -eq 'Allow' -and ($protocol -eq 'TCP' -or $protocol -eq '6') -and $localPort -eq '${DEFAULT_PORT}')
    if ($isValid) {
      $valid = $true
      $details += [pscustomobject]@{ displayName=[string]$rule.DisplayName; enabled=[string]$rule.Enabled; direction=[string]$rule.Direction; action=[string]$rule.Action; protocol=$protocol; localPort=$localPort; profile=[string]$rule.Profile }
    }
  }
}
[pscustomobject]@{ status=if($valid){'READY'}else{'MISSING'}; ready=$valid; detail=if($valid){'Regla entrante TCP ${DEFAULT_PORT} habilitada.'}else{'No existe una regla entrante activa que autorice TCP ${DEFAULT_PORT}.'}; rules=$details } | ConvertTo-Json -Compress -Depth 5
`;

  try {
    const result = await powershellJson(script);
    return result || { status: 'ERROR', ready: false, detail: 'No se obtuvo respuesta al verificar Windows Firewall.' };
  } catch (error) {
    const message = `${String(error?.message || error || 'Error desconocido')} ${String(error?.stderr || '')}`.trim();
    if (/access.*denied|acceso.*denegado|privilegio|unauthorized|0x80070005|requires? elevation|elevaci[oó]n/i.test(message)) {
      return inspectFirewallProvisionMarker();
    }
    return { status: 'ERROR', ready: false, detail: `No se pudo verificar Windows Firewall: ${message}` };
  }
}

async function provisionFirewall() {
  if (platformProvider() !== 'win32') return { ok: true, status: 'NOT_REQUIRED', detail: 'No requiere firewall de Windows.' };
  const root = installRoot || path.dirname(process.execPath);
  const scriptPath = path.join(root, 'resources', 'app', 'build', 'provisionar-firewall.ps1');
  if (!fs.existsSync(scriptPath)) return { ok: false, status: 'SCRIPT_MISSING', detail: 'Falta el componente automático de firewall.' };

  const escapedPath = scriptPath.replace(/'/g, "''");
  const innerScript = `& '${escapedPath}' -Puerto ${DEFAULT_PORT} -NombreRegla '${FIREWALL_RULE_NAME.replace(/'/g, "''")}'`;
  const innerEncoded = Buffer.from(innerScript, 'utf16le').toString('base64');
  const elevationScript = String.raw`
$ErrorActionPreference = 'Stop'
$arguments = @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand','${innerEncoded}')
$process = Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -Verb RunAs -Wait -PassThru
exit $process.ExitCode
`;
  const encoded = Buffer.from(elevationScript, 'utf16le').toString('base64');

  const execution = await new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], {
      windowsHide: true,
      timeout: 180_000,
      maxBuffer: 1024 * 1024
    }, (error, stdout, stderr) => {
      if (error) return resolve({ ok: false, status: 'ELEVATION_FAILED', detail: String(stderr || error.message || 'Autorización cancelada.') });
      resolve({ ok: true, status: 'EXECUTED', detail: String(stdout || '').trim() || 'Configuración ejecutada.' });
    });
  });

  const firewall = await inspectFirewallRule();
  process.env.IWC_FIREWALL_STATUS = firewall.status;
  if (current) await refresh({ forceManifest: false }).catch(() => {});
  return { ok: execution.ok && firewall.ready, status: firewall.status, detail: firewall.detail, execution };
}

function probeHttpEndpoint(targetUrl, { expectedStatus, bodyIncludes = null, timeoutMs = 2500 } = {}) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch {
      finish({ ok: false, statusCode: null, detail: `URL inválida: ${targetUrl}` });
      return;
    }

    const request = http.get({
      hostname: parsed.hostname,
      port: parsed.port || 80,
      path: `${parsed.pathname}${parsed.search}`,
      timeout: timeoutMs,
      headers: { Accept: 'text/html,application/json' }
    }, (response) => {
      const chunks = [];
      let total = 0;
      response.on('data', (chunk) => {
        total += chunk.length;
        if (total <= 256 * 1024) chunks.push(chunk);
      });
      response.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        const statusOk = response.statusCode === expectedStatus;
        const bodyOk = bodyIncludes ? body.includes(bodyIncludes) : true;
        finish({
          ok: statusOk && bodyOk,
          statusCode: response.statusCode,
          detail: statusOk && bodyOk
            ? `HTTP ${response.statusCode} confirmado en ${parsed.pathname}.`
            : `Respuesta inesperada en ${parsed.pathname}: HTTP ${response.statusCode || 'sin estado'}.`
        });
      });
    });
    request.on('timeout', () => request.destroy(new Error('ENDPOINT_TIMEOUT')));
    request.on('error', (error) => finish({ ok: false, statusCode: null, detail: `No responde ${parsed.pathname}: ${error.code || error.message}` }));
  });
}

async function inspectOperationalEndpoints(baseUrl) {
  if (!baseUrl) {
    return {
      ok: false,
      operationEntry: { ok: false, detail: 'No hay URL LAN para verificar Mi operación.' },
      operationApi: { ok: false, detail: 'No hay URL LAN para verificar la API operativa.' }
    };
  }
  const normalized = String(baseUrl).replace(/\/$/, '');
  const [operationEntry, operationApi] = await Promise.all([
    probeHttpEndpoint(`${normalized}/mi-operacion`, { expectedStatus: 302 }),
    probeHttpEndpoint(`${normalized}/api/v1/operation/bootstrap`, { expectedStatus: 401 })
  ]);
  return { ok: operationEntry.ok && operationApi.ok, operationEntry, operationApi };
}

async function inspectDatabase() {
  try {
    const { getDb } = require('../db/database');
    const db = getDb();
    const row = db.prepare('SELECT 1 AS ok').get();
    if (Number(row?.ok) !== 1) return { ok: false, detail: 'La base central no respondió correctamente.' };

    const requiredMigration = 28;
    const schemaVersion = Number(db.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migration').get()?.version || 0);
    const migration = db.prepare('SELECT version,name,applied_at FROM schema_migration WHERE version=?').get(requiredMigration) || null;
    const receiptTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='custody_return_receipt'").get() || null;
    const triggerNames = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='custody_return_receipt'").all().map((item) => item.name));
    const columns = new Set(db.prepare("PRAGMA table_info('custody_return_receipt')").all().map((item) => item.name));
    const requiredColumns = ['id','custody_id','handover_id','return_record_id','receipt_number','asset_nature','snapshot_json','snapshot_sha256','pdf_bytes','pdf_sha256','pdf_size','created_by_user_id','created_at'];
    const missingColumns = requiredColumns.filter((name) => !columns.has(name));
    const immutable = triggerNames.has('custody_return_receipt_immutable_update') && triggerNames.has('custody_return_receipt_immutable_delete');
    const receiptSchemaReady = schemaVersion >= requiredMigration && Boolean(migration) && Boolean(receiptTable) && immutable && missingColumns.length === 0;

    return {
      ok: receiptSchemaReady,
      schemaVersion,
      requiredMigration,
      receiptSchemaReady,
      detail: receiptSchemaReady
        ? `Base central abierta; migración ${requiredMigration} aplicada y constancia PDF inmutable disponible.`
        : `Base abierta pero esquema de devolución incompleto: versión=${schemaVersion}, migración028=${Boolean(migration)}, tabla=${Boolean(receiptTable)}, inmutabilidad=${immutable}, columnasFaltantes=${missingColumns.join(',') || 'ninguna'}.`
    };
  } catch (error) {
    return { ok: false, detail: `La base central no está disponible: ${error.message}` };
  }
}

function inspectQrGeneration(baseUrl) {
  if (!baseUrl) return { ok: false, detail: 'No hay URL LAN para validar el generador QR.', url: null, svg: null };
  // S6 NO publica un QR operativo. Su única responsabilidad es comprobar que el
  // motor QR puede codificar una URL móvil válida. El QR real se crea en S7,
  // donde existe un token de validación efímero y el usuario puede regenerarlo.
  const probeUrl = `${String(baseUrl).replace(/\/$/, '')}/installation-validation-mobile.html?token=S6-INTERNAL-PROBE`;
  try {
    const output = svg(probeUrl, { scale: 8, border: 4 });
    const ok = typeof output === 'string' && output.includes('<svg') && output.length > 500;
    return {
      ok,
      detail: ok ? 'Motor QR validado internamente; el QR real se generará en S7.' : 'El generador QR no produjo un SVG válido.',
      url: null,
      svg: null
    };
  } catch (error) {
    return { ok: false, detail: `No fue posible validar el generador QR: ${error.message}`, url: null, svg: null };
  }
}

function checkWritableDirectory(directory) {
  try {
    fs.mkdirSync(directory, { recursive: true });
    const testPath = path.join(directory, `.s6-write-${process.pid}-${Date.now()}.tmp`);
    fs.writeFileSync(testPath, 'ok', { encoding: 'utf8', flag: 'wx' });
    fs.unlinkSync(testPath);
    return { ok: true, detail: `Escritura confirmada en ${directory}` };
  } catch (error) {
    return { ok: false, detail: `Sin escritura en ${directory}: ${error.message}` };
  }
}

function atomicWriteJson(target, value) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const temporary = `${target}.tmp-${process.pid}`;
  fs.writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
  fs.renameSync(temporary, target);
}

function publicState(state = current) {
  if (!state) {
    return {
      phase: 'S6',
      status: 'NOT_INITIALIZED',
      ready: false,
      checks: [],
      qrAvailable: false,
      qrUrl: null,
      message: 'La verificación automática todavía no comenzó.'
    };
  }
  return {
    phase: 'S6',
    status: state.status,
    ready: state.ready,
    checks: state.checks,
    qrAvailable: false,
    qrUrl: null,
    networkAddress: state.networkAddress,
    interfaceName: state.interfaceName,
    interfaceType: state.interfaceType,
    port: state.port,
    firewallStatus: state.firewallStatus,
    startedAt: state.startedAt,
    verifiedAt: state.verifiedAt,
    message: state.message
  };
}

function buildFingerprint({ version, manifestTree, networkAddress, port, firewallStatus }) {
  return hashText(JSON.stringify({ version, manifestTree, networkAddress, port, firewallStatus }));
}

async function refresh({ forceManifest = false } = {}) {
  if (!current) throw new Error('STARTUP_DEPLOYMENT_NOT_INITIALIZED');
  if (refreshInFlight) return refreshInFlight;

  refreshInFlight = (async () => {
    const windows = platformProvider() === 'win32';
    const architecture = archProvider();
    const version = parseBuildNumber();
    const writable = checkWritableDirectory(dataDirProvider());
    const serverState = serverStateProvider() || {};
    const local = serverState.local || null;

    const network = await networkRefreshProvider().catch(() => getNetworkStatus());
    const firewall = await firewallProvider();
    process.env.IWC_FIREWALL_STATUS = firewall.status;
    const database = await databaseProvider();
    const endpoints = await endpointProvider(network?.baseUrl || null);
    const qr = inspectQrGeneration(network?.baseUrl || null);

    // F32R3: la integridad del paquete deja de formar parte de S6.
    // El manifiesto puede auditarse por separado, pero nunca debe impedir el arranque
    // por cambios legítimos en JS/CSS u otros archivos internos del paquete.
    const manifest = {
      ok: true,
      code: 'PACKAGE_INTEGRITY_NON_BLOCKING',
      detail: 'Control de integridad del paquete deshabilitado como condición de operación S6.',
      treeSha256: null,
      fileCount: 0,
      nonBlocking: true
    };

    const bindAddress = String(local?.address || '');
    const port = Number(local?.port || runtime.port || DEFAULT_PORT);
    const networkAddress = network?.address || null;

    const checks = [
      makeCheck('WINDOWS', 'Sistema operativo Windows', windows, windows ? 'Windows detectado.' : `Plataforma detectada: ${platformProvider()}`),
      makeCheck('ARCH_X64', 'Arquitectura x64', architecture === 'x64', `Arquitectura detectada: ${architecture}`),
      makeCheck('WINDOWS_BUILD', 'Windows Server 2016 o superior', windows && Number.isInteger(version.build) && version.build >= MIN_WINDOWS_BUILD, `Versión del sistema: ${version.release || 'no detectada'}; build mínimo ${MIN_WINDOWS_BUILD}.`),
      makeCheck('DATA_WRITABLE', 'Carpeta de datos con escritura', writable.ok, writable.detail),
      makeCheck('DATABASE_READY', 'Base central operativa', database?.ok === true, database?.detail || 'No verificada.'),
      makeCheck('LISTENER_ALL_INTERFACES', 'Servidor publicado en todas las interfaces', ['0.0.0.0', '::'].includes(bindAddress), `Listener: ${bindAddress || 'no iniciado'}:${port || '?'}`),
      makeCheck('PORT_4317', 'Puerto TCP 4317 activo', port === DEFAULT_PORT, `Puerto detectado: ${port || 'ninguno'}`),
      makeCheck('LAN_ADDRESS', 'Dirección IPv4 LAN válida', Boolean(networkAddress && isIpv4Private(networkAddress)), networkAddress ? `Dirección seleccionada: ${networkAddress}` : 'No se detectó una dirección LAN privada.'),
      makeCheck('LAN_SELF_PROBE', 'Respuesta por la IP de red', network?.available === true && network?.selfProbe === 'PASS', network?.available ? `Respuesta confirmada en ${network.baseUrl}` : (network?.userMessage || 'Sin respuesta por red.')),
      makeCheck('OPERATION_ENTRY_READY', 'Mi operación publicada', endpoints?.operationEntry?.ok === true, endpoints?.operationEntry?.detail || 'No verificada.'),
      makeCheck('OPERATION_API_READY', 'API operativa canónica publicada', endpoints?.operationApi?.ok === true, endpoints?.operationApi?.detail || 'No verificada.'),
      makeCheck('QR_GENERATION', 'Generador QR operativo', qr.ok === true, qr.detail || 'No verificado.'),
      makeCheck('FIREWALL', 'Firewall entrante habilitado', firewall?.ready === true, firewall?.detail || 'No verificado.', true)
    ];

    const ready = checks.every((check) => check.passed);
    const status = ready ? 'PASSED' : 'BLOCKED';
    const fingerprint = buildFingerprint({
      version: current.version,
      manifestTree: null,
      networkAddress,
      port,
      firewallStatus: firewall?.status || 'UNKNOWN'
    });

    const previousStatus = current.status;
    current = {
      ...current,
      status,
      ready,
      checks,
      networkAddress,
      interfaceName: network?.interfaceName || null,
      interfaceType: network?.interfaceType || null,
      port,
      firewallStatus: firewall?.status || 'UNKNOWN',
      manifest,
      qr,
      fingerprint,
      verifiedAt: ready ? nowIso() : null,
      message: ready
        ? 'Despliegue automático S6 aprobado. La aplicación se abrirá sin configuración manual.'
        : 'El servidor no habilitará la operación hasta corregir los controles rechazados.',
      refreshedAt: nowIso()
    };

    if (ready) {
      atomicWriteJson(evidencePath(), {
        schema: 'INGAR_STARTUP_DEPLOYMENT_S6_V1',
        phase: 'S6',
        status: 'PASSED',
        productVersion: current.version,
        generatedAt: current.verifiedAt,
        fingerprint: current.fingerprint,
        networkAddress: current.networkAddress,
        interfaceName: current.interfaceName,
        interfaceType: current.interfaceType,
        port: current.port,
        firewallStatus: current.firewallStatus,
        qrUrl: null,
        manifestTreeSha256: current.manifest?.treeSha256 || null,
        manifestFileCount: current.manifest?.fileCount || 0,
        checks: current.checks
      });
    }

    const publicResult = publicState(current);
    if (previousStatus !== 'PASSED' && current.status === 'PASSED') events.emit('passed', publicResult);
    events.emit('change', publicResult);
    return publicResult;
  })().finally(() => { refreshInFlight = null; });

  return refreshInFlight;
}

async function initialize(options = {}) {
  installRoot = path.resolve(options.installRoot || path.dirname(process.execPath));
  serverStateProvider = typeof options.serverStateProvider === 'function' ? options.serverStateProvider : serverStateProvider;
  current = {
    version: String(options.version || runtime.sourceVersion || ''),
    status: 'CHECKING',
    ready: false,
    checks: [],
    networkAddress: null,
    interfaceName: null,
    interfaceType: null,
    port: Number(runtime.port || DEFAULT_PORT),
    firewallStatus: 'UNKNOWN',
    manifest: null,
    qr: null,
    fingerprint: null,
    startedAt: nowIso(),
    verifiedAt: null,
    message: 'Ejecutando despliegue automático S6.'
  };
  return refresh({ forceManifest: true });
}

function qrSvg() {
  throw Object.assign(new Error('S6 no publica un QR. Complete S6 y utilice el QR tokenizado de S7.'), { status: 410, code: 'S6_QR_REMOVED' });
}

function resetForTests() {
  current = null;
  refreshInFlight = null;
  installRoot = null;
  serverStateProvider = () => ({ local: null, network: getNetworkStatus() });
  platformProvider = () => process.platform;
  archProvider = () => process.arch;
  releaseProvider = () => os.release();
  nowProvider = () => new Date();
  firewallProvider = inspectFirewallRule;
  networkRefreshProvider = refreshNetworkStatus;
  manifestProvider = verifyDistributionManifest;
  databaseProvider = inspectDatabase;
  endpointProvider = inspectOperationalEndpoints;
  dataDirProvider = () => runtime.dataDir;
  events.removeAllListeners();
}

function setTestProviders({ platform, arch, release, now, firewall, networkRefresh, manifest, database, endpoints, serverState, dataDir } = {}) {
  if (platform) platformProvider = platform;
  if (arch) archProvider = arch;
  if (release) releaseProvider = release;
  if (now) nowProvider = now;
  if (firewall) firewallProvider = firewall;
  if (networkRefresh) networkRefreshProvider = networkRefresh;
  if (manifest) manifestProvider = manifest;
  if (database) databaseProvider = database;
  if (endpoints) endpointProvider = endpoints;
  if (serverState) serverStateProvider = serverState;
  if (dataDir) dataDirProvider = dataDir;
}

module.exports = {
  FIREWALL_RULE_NAME,
  MIN_WINDOWS_BUILD,
  DEFAULT_PORT,
  initialize,
  refresh,
  publicState,
  qrSvg,
  inspectFirewallRule,
  provisionFirewall,
  verifyDistributionManifest,
  inspectDatabase,
  inspectOperationalEndpoints,
  inspectQrGeneration,
  probeHttpEndpoint,
  parseBuildNumber,
  setTestProviders,
  resetForTests,
  events
};
