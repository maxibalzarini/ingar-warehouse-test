'use strict';

const { listRequestsPage } = require('./request-service');
const { listCustodiesPage } = require('./custody-service');
const { listIncidentsPage } = require('./incident-service');
const { getSetting } = require('./settings-service');
const { hasPermission } = require('./permission-service');

const ACTIVE_REQUEST_STATUSES = 'PENDIENTE_AUTORIZACION,APROBADA,PREPARANDO,LISTA_PARA_ENTREGA';
const ACTIVE_CUSTODY_STATUSES = 'ABIERTA,DEVOLUCION_DECLARADA,RECEPCION_PENDIENTE,TRANSFERENCIA_PENDIENTE,INCIDENTE';
const ACTIVE_INCIDENT_STATUSES = 'ABIERTO,EN_INVESTIGACION';
const OUTSIDE_CUSTODY_STATUSES = new Set(['ABIERTA','DEVOLUCION_DECLARADA','TRANSFERENCIA_PENDIENTE']);
const DEFAULT_TIME_ZONE = 'America/Argentina/Buenos_Aires';
const MAX_FEED_ROWS = 5000;

function requestUsesSimpleFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (!items.length || String(request?.operation_type || '').toUpperCase() !== 'RETIRO') return false;
  return items.every((item) => ['CANTIDAD','CONSUMIBLE'].includes(String(item.category_nature || '').toUpperCase()));
}

function requestUsesVehicleFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  return items.length === 1 && String(request?.operation_type || '').toUpperCase() === 'RETIRO'
    && String(items[0]?.category_nature || '').toUpperCase() === 'VEHICULO' && Number(items[0]?.quantity || 0) === 1;
}

function requestUsesSerializedFlow(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (!items.length || String(request?.operation_type || '').toUpperCase() !== 'RETIRO') return false;
  return items.every((item) => String(item.category_nature || '').toUpperCase() === 'SERIADO' && Number(item.quantity || 0) === 1);
}

function custodyUsesSimpleFlow(custody) { return ['CANTIDAD','CONSUMIBLE'].includes(String(custody?.category_nature || '').toUpperCase()); }
function custodyUsesVehicleFlow(custody) { return String(custody?.category_nature || '').toUpperCase() === 'VEHICULO'; }
function custodyUsesSerializedFlow(custody) { return String(custody?.category_nature || '').toUpperCase() === 'SERIADO'; }
function custodyUsesKitFlow(custody) { return String(custody?.category_nature || '').toUpperCase() === 'KIT'; }

function requestKind(request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  if (requestUsesVehicleFlow(request)) return { code: 'VEHICULO', label: 'Vehículo' };
  if (requestUsesSerializedFlow(request)) return { code: 'SERIADO', label: 'Bien serializado' };
  if (items.length && items.every((item) => String(item.category_nature || '').toUpperCase() === 'KIT')) return { code: 'KIT', label: 'Kit' };
  if (requestUsesSimpleFlow(request)) {
    const consumable = (request.items || []).every((item) => String(item.category_nature || '').toUpperCase() === 'CONSUMIBLE');
    return consumable ? { code: 'CONSUMIBLE', label: 'Consumible' } : { code: 'HERRAMIENTA', label: 'Herramienta' };
  }
  return { code: 'PREPARACION', label: 'Pedido especial' };
}

function custodyKind(custody) {
  const nature = String(custody?.category_nature || '').toUpperCase();
  if (nature === 'VEHICULO') return { code: 'VEHICULO', label: 'Vehículo' };
  if (nature === 'SERIADO') return { code: 'SERIADO', label: 'Bien serializado' };
  if (nature === 'KIT') return { code: 'KIT', label: 'Kit' };
  if (nature === 'CONSUMIBLE') return { code: 'CONSUMIBLE', label: 'Consumible' };
  return { code: 'HERRAMIENTA', label: 'Herramienta' };
}

function safeTimeZone(value) {
  const candidate = String(value || DEFAULT_TIME_ZONE);
  try {
    new Intl.DateTimeFormat('es-AR', { timeZone: candidate }).format(new Date());
    return candidate;
  } catch {
    return DEFAULT_TIME_ZONE;
  }
}

function localDateKey(date, timeZone) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(date);
  const values = Object.fromEntries(parts.filter((part) => part.type !== 'literal').map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function isCurrentlyOutside(custody) {
  const status = String(custody?.status || '').toUpperCase();
  const nature = String(custody?.category_nature || '').toUpperCase();
  return OUTSIDE_CUSTODY_STATUSES.has(status) && nature !== 'CONSUMIBLE';
}

function loanedState(custody, now, timeZone) {
  const status = String(custody?.status || '').toUpperCase();
  const due = custody?.due_at ? new Date(custody.due_at) : null;
  const dueValid = due && Number.isFinite(due.getTime());
  // F8: una devolución ya declarada cambia la responsabilidad operativa: primero hay que recibirla.
  // El eventual fuera de término queda como dato secundario y nunca reemplaza 'Pendiente de recibir'.
  if (status === 'DEVOLUCION_DECLARADA') {
    if (custodyUsesVehicleFlow(custody) && custody?.vehicleReturnSupervision) {
      const supervision = custody.vehicleReturnSupervision;
      if (String(supervision.status || '').toUpperCase() === 'PENDIENTE') return { code: 'PENDIENTE_SUPERVISOR', label: 'Pendiente de Supervisor', tone: 'warning' };
      if (String(supervision.status || '').toUpperCase() === 'APROBADA' && Number(supervision.safety_observation || 0) === 1) return { code: 'VISTO_BUENO_SEGURIDAD', label: 'V°B° · bloqueado por Seguridad', tone: 'danger' };
      if (String(supervision.status || '').toUpperCase() === 'APROBADA') return { code: 'VISTO_BUENO', label: 'V°B° · entregar llaves', tone: 'information' };
    }
    return { code: 'DEVOLUCION_DECLARADA', label: 'Pendiente de recibir', tone: 'information' };
  }
  if (dueValid && due.getTime() < now.getTime()) return { code: 'ATRASADO', label: 'Atrasado', tone: 'danger' };
  if (status === 'TRANSFERENCIA_PENDIENTE') return { code: 'TRANSFERENCIA_PENDIENTE', label: 'Transferencia pendiente', tone: 'warning' };
  if (dueValid && localDateKey(due, timeZone) === localDateKey(now, timeZone)) return { code: 'VENCE_HOY', label: 'Vence hoy', tone: 'warning' };
  return { code: 'EN_USO', label: 'En uso', tone: 'success' };
}

function buildLoanedNow(custodies, now = new Date(), options = {}) {
  const timeZone = safeTimeZone(options.timeZone || getSetting('locale.timezone', DEFAULT_TIME_ZONE));
  const todayKey = localDateKey(now, timeZone);
  const items = (custodies || []).filter(isCurrentlyOutside).map((custody) => {
    const kind = custodyKind(custody);
    const due = custody?.due_at ? new Date(custody.due_at) : null;
    const dueValid = due && Number.isFinite(due.getTime());
    const state = loanedState(custody, now, timeZone);
    return {
      id: custody.id,
      custodyId: custody.id,
      assetId: custody.asset_id,
      kind,
      internalCode: custody.internal_code || null,
      description: custody.description || null,
      serialNumber: custody.serial_number || null,
      licensePlate: custody.license_plate || null,
      quantity: Number(custody.quantity || 1),
      personId: custody.person_id || null,
      custodianName: custody.custodian_name || null,
      custodianDocument: custody.custodian_document || null,
      requestNumber: custody.request_number || null,
      locationName: custody.location_name || null,
      openedAt: custody.opened_at || null,
      dueAt: custody.due_at || null,
      custodyStatus: custody.status || null,
      returnDeclaredAt: custody.declared_return_at || null,
      hasReturnProblem: isReturnProblem(custody),
      returnProblemNotes: custody?.returnDeclaration?.notes || null,
      overdue: state.code === 'ATRASADO',
      dueToday: Boolean(dueValid && localDateKey(due, timeZone) === todayKey),
      state
    };
  });
  const priority = { ATRASADO: 0, PENDIENTE_SUPERVISOR: 1, VISTO_BUENO_SEGURIDAD: 1, VISTO_BUENO: 1, DEVOLUCION_DECLARADA: 1, VENCE_HOY: 2, TRANSFERENCIA_PENDIENTE: 3, EN_USO: 4 };
  items.sort((a, b) => (priority[a.state.code] ?? 9) - (priority[b.state.code] ?? 9)
    || dateSort(a.dueAt) - dateSort(b.dueAt)
    || dateSort(a.openedAt) - dateSort(b.openedAt));
  const summary = {
    vehiclesOut: items.filter((item) => item.kind.code === 'VEHICULO').length,
    toolsLoaned: items.filter((item) => item.kind.code === 'HERRAMIENTA').length,
    serializedOut: items.filter((item) => ['SERIADO','KIT'].includes(item.kind.code)).length,
    dueToday: items.filter((item) => item.dueToday).length,
    overdue: items.filter((item) => item.overdue).length,
    totalOut: items.length
  };
  return { generatedAt: now.toISOString(), timeZone, summary, items, total: items.length };
}

function isReturnProblem(custody) {
  const declaration = custody?.returnDeclaration;
  return Boolean(custody?.status === 'INCIDENTE' || (declaration && (Number(declaration.problem_reported || 0) === 1 || String(declaration.condition || '').toUpperCase() !== 'CONFORME')));
}

function simpleCustodyDue(custody, now = new Date()) {
  if (!custodyUsesSimpleFlow(custody) || custody.status !== 'ABIERTA' || !custody.due_at) return false;
  const endToday = new Date(now); endToday.setHours(23, 59, 59, 999);
  return new Date(custody.due_at).getTime() <= endToday.getTime();
}

function dateSort(value) {
  const time = value ? new Date(value).getTime() : Number.MAX_SAFE_INTEGER;
  return Number.isFinite(time) ? time : Number.MAX_SAFE_INTEGER;
}

function task(entity, action, row, kind, dueAt) {
  return { entity, action, id: row.id, kind, dueAt: dueAt || null };
}

function buildWarehouseWorkbenchLanes(requests, custodies, incidents, now = new Date(), user = null) {
  const lanes = { scheduled: [], prepare: [], deliver: [], receive: [], problems: [] };
  const preparationLeadMinutes = Math.max(5, Math.min(1440, Number(getSetting('dashboard.upcomingMinutes', 120)) || 120));
  const preparationThreshold = now.getTime() + preparationLeadMinutes * 60_000;
  const isFutureScheduled = (request) => {
    const value = request?.needed_at ? new Date(request.needed_at).getTime() : NaN;
    return Number.isFinite(value) && value > preparationThreshold;
  };
  for (const request of requests || []) {
    const kind = requestKind(request);
    const scheduled = isFutureScheduled(request);
    if (scheduled) {
      if (request.status === 'PENDIENTE_AUTORIZACION') lanes.scheduled.push(task('request', 'approve', request, kind, request.needed_at));
      else if (request.status === 'APROBADA') {
        if (requestUsesSimpleFlow(request) || requestUsesSerializedFlow(request) || requestUsesVehicleFlow(request)) lanes.scheduled.push(task('request', 'view-request', request, kind, request.needed_at));
        else lanes.scheduled.push(task('request', 'prepare', request, kind, request.needed_at));
      } else if (request.status === 'PREPARANDO') lanes.scheduled.push(task('request', 'ready', request, kind, request.needed_at));
      else if (request.status === 'LISTA_PARA_ENTREGA') lanes.scheduled.push(task('request', 'view-request', request, kind, request.needed_at));
      continue;
    }
    if (request.status === 'PENDIENTE_AUTORIZACION') {
      lanes.prepare.push(task('request', 'approve', request, kind, request.needed_at));
    } else if (request.status === 'APROBADA') {
      if (requestUsesSimpleFlow(request)) lanes.deliver.push(task('request', 'quick-handover', request, kind, request.needed_at));
      else if (requestUsesSerializedFlow(request)) lanes.deliver.push(task('request', 'serialized-handover', request, kind, request.needed_at));
      else if (requestUsesVehicleFlow(request)) lanes.deliver.push(task('request', 'vehicle-handover', request, kind, request.needed_at));
      else lanes.prepare.push(task('request', 'prepare', request, kind, request.needed_at));
    } else if (request.status === 'PREPARANDO') {
      lanes.prepare.push(task('request', 'ready', request, kind, request.needed_at));
    } else if (request.status === 'LISTA_PARA_ENTREGA') {
      lanes.deliver.push(task('request', 'handover', request, kind, request.needed_at));
    }
  }

  const incidentCustodyIds = new Set((incidents || [])
    .filter((incident) => ['ABIERTO','EN_INVESTIGACION'].includes(String(incident.status || '').toUpperCase()))
    .map((incident) => incident.custody_id)
    .filter(Boolean));

  for (const custody of custodies || []) {
    const kind = custodyKind(custody);
    if (custody.status === 'DEVOLUCION_DECLARADA') {
      let action = 'receive';
      let visible = true;
      if (custodyUsesSimpleFlow(custody)) action = 'quick-receive';
      else if (custodyUsesSerializedFlow(custody)) action = 'serialized-quick-receive';
      else if (custodyUsesVehicleFlow(custody)) {
        const supervision = custody.vehicleReturnSupervision;
        if (supervision) {
          const status = String(supervision.status || '').toUpperCase();
          if (status === 'PENDIENTE') {
            action = 'vehicle-supervisor-inspect';
            visible = Boolean(!user || (String(supervision.supervisor_user_id) === String(user.id) && hasPermission(user, 'Vehicles.SuperviseReturn')));
          } else if (status === 'APROBADA') {
            action = 'vehicle-receive';
            visible = Boolean(!user || hasPermission(user, 'Vehicles.ReceiveReturnKeys'));
          } else visible = false;
        } else {
          // Regla estricta: sin supervisión registrada no existe recepción de llaves.
          // Los registros históricos quedan pendientes de regularización, nunca como recepción habilitada.
          visible = false;
        }
      }
      else if (custodyUsesKitFlow(custody)) action = 'kit-receive';
      if (visible) lanes.receive.push(task('custody', action, custody, kind, custody.due_at || custody.declared_return_at));
    } else if (isReturnProblem(custody) && !incidentCustodyIds.has(custody.id)) {
      // Sólo existe como problema visible cuando ya no queda una recepción física pendiente.
      // Si hay un incidente abierto asociado, ese incidente es la única tarjeta visible.
      lanes.problems.push(task('custody', 'review-custody', custody, kind, custody.due_at || custody.opened_at));
    }
  }

  for (const incident of incidents || []) {
    if (!['ABIERTO','EN_INVESTIGACION'].includes(String(incident.status || '').toUpperCase())) continue;
    lanes.problems.push(task('incident', 'incident-detail', incident, { code: 'INCIDENTE', label: 'Incidente' }, incident.opened_at));
  }

  for (const rows of Object.values(lanes)) rows.sort((a, b) => dateSort(a.dueAt) - dateSort(b.dueAt));
  return lanes;
}

function collectRequests(user) {
  const rows = []; let offset = 0; let total = 0;
  do {
    const page = listRequestsPage({ statuses: ACTIVE_REQUEST_STATUSES, limit: 300, offset }, user, true);
    rows.push(...page.items); total = page.total; offset += page.items.length;
    if (!page.items.length) break;
  } while (rows.length < total && rows.length < MAX_FEED_ROWS);
  return { rows: rows.slice(0, MAX_FEED_ROWS), total, truncated: total > MAX_FEED_ROWS };
}

function collectCustodies(user) {
  const rows = []; let offset = 0; let total = 0;
  do {
    const page = listCustodiesPage({ statuses: ACTIVE_CUSTODY_STATUSES, limit: 500, offset }, user, true);
    rows.push(...page.items); total = page.total; offset += page.items.length;
    if (!page.items.length) break;
  } while (rows.length < total && rows.length < MAX_FEED_ROWS);
  return { rows: rows.slice(0, MAX_FEED_ROWS), total, truncated: total > MAX_FEED_ROWS };
}

function collectIncidents(user) {
  const rows = []; let offset = 0; let total = 0;
  do {
    const page = listIncidentsPage({ statuses: ACTIVE_INCIDENT_STATUSES, limit: 500, offset }, user);
    rows.push(...page.items); total = page.total; offset += page.items.length;
    if (!page.items.length) break;
  } while (rows.length < total && rows.length < MAX_FEED_ROWS);
  return { rows: rows.slice(0, MAX_FEED_ROWS), total, truncated: total > MAX_FEED_ROWS };
}

function summarizeWarehouseWorkbenchLanes(lanes) {
  const prepare = lanes.prepare || [];
  const deliver = lanes.deliver || [];
  return {
    scheduled: (lanes.scheduled || []).length,
    pendingApproval: prepare.filter((item) => item.entity === 'request' && item.action === 'approve').length,
    approvedToPrepare: prepare.filter((item) => item.entity === 'request' && item.action === 'prepare').length,
    inPreparation: prepare.filter((item) => item.entity === 'request' && item.action === 'ready').length,
    readyForDelivery: deliver.filter((item) => item.entity === 'request').length,
    receive: (lanes.receive || []).length,
    problems: (lanes.problems || []).length
  };
}

function getWarehouseWorkbench(user, options = {}) {
  const now = options.now instanceof Date ? options.now : new Date();
  const requests = collectRequests(user);
  const custodies = collectCustodies(user);
  const incidents = collectIncidents(user);
  const lanes = buildWarehouseWorkbenchLanes(requests.rows, custodies.rows, incidents.rows, now, user);
  const loanedNow = buildLoanedNow(custodies.rows, now, options);
  return {
    generatedAt: now.toISOString(),
    requests: requests.rows,
    custodies: custodies.rows,
    incidents: incidents.rows,
    lanes,
    summary: summarizeWarehouseWorkbenchLanes(lanes),
    loanedNow,
    totals: { requests: requests.total, custodies: custodies.total, incidents: incidents.total, outside: loanedNow.total },
    truncated: Boolean(requests.truncated || custodies.truncated || incidents.truncated)
  };
}

module.exports = {
  getWarehouseWorkbench,
  buildWarehouseWorkbenchLanes,
  summarizeWarehouseWorkbenchLanes,
  buildLoanedNow,
  isCurrentlyOutside,
  loanedState,
  requestUsesSimpleFlow,
  requestUsesVehicleFlow,
  requestUsesSerializedFlow
};
