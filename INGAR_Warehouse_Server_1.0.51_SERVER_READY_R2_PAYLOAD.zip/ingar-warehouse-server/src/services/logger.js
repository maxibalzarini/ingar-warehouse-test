'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { redactForLog, redactText, scrubLogDirectory } = require('../security/log-redaction');
const runtime = require('../config/runtime');
const { getDb } = require('../db/database');

function redact(value) { return redactForLog(value); }
function sanitize(value) { return JSON.stringify(redactForLog(value ?? null)); }
function write(level, component, message, details = null, correlationId = null) {
  const occurredAt = new Date().toISOString();
  const safeDetails = details === null ? null : redactForLog(details);
  const record = { id: randomUUID(), occurredAt, level: redactText(level).slice(0, 20), component: redactText(component).slice(0, 100), message: redactText(message).slice(0, 2000), details: safeDetails, correlationId: redactText(correlationId || '').slice(0, 200) || null };
  try {
    fs.mkdirSync(runtime.logDir, { recursive: true });
    const file = path.join(runtime.logDir, `${occurredAt.slice(0, 10)}.jsonl`);
    fs.appendFileSync(file, `${JSON.stringify(record)}
`, 'utf8');
  } catch (error) { process.stderr.write(`LOGGER_FILE_ERROR ${redactText(error.message)}
`); }
  try {
    getDb().prepare(`INSERT INTO system_log(id, occurred_at, level, component, message, details_json, correlation_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(record.id, occurredAt, record.level, record.component, record.message, safeDetails === null ? null : JSON.stringify(safeDetails), record.correlationId, occurredAt);
  } catch (error) { process.stderr.write(`LOGGER_DB_ERROR ${redactText(error.message)}
`); }
  return record;
}
function scrubPersistedLogs() {
  const db = getDb();
  const rows = db.prepare('SELECT id, level, component, message, details_json, correlation_id FROM system_log').all();
  const update = db.prepare('UPDATE system_log SET level=?, component=?, message=?, details_json=?, correlation_id=? WHERE id=?');
  let databaseChanged = 0;
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const row of rows) {
      let details = null;
      try { details = row.details_json ? JSON.parse(row.details_json) : null; } catch { details = row.details_json; }
      const safe = redactForLog({ level: row.level, component: row.component, message: row.message, details, correlationId: row.correlation_id });
      const detailsJson = safe.details === null ? null : JSON.stringify(safe.details);
      if (safe.level !== row.level || safe.component !== row.component || safe.message !== row.message || detailsJson !== row.details_json || safe.correlationId !== row.correlation_id) {
        update.run(safe.level, safe.component, safe.message, detailsJson, safe.correlationId, row.id);
        databaseChanged += 1;
      }
    }
    db.exec('COMMIT');
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch {}
    throw error;
  }
  const files = scrubLogDirectory(runtime.logDir);
  return { databaseScanned: rows.length, databaseChanged, fileScanned: files.scanned, fileChanged: files.changed };
}

function queryLogs(filters = {}) {
  const where = []; const params = [];
  if (filters.level) { where.push('level = ?'); params.push(filters.level); }
  if (filters.component) { where.push('component LIKE ?'); params.push(`%${filters.component}%`); }
  if (filters.search) { where.push('(message LIKE ? OR details_json LIKE ?)'); params.push(`%${filters.search}%`, `%${filters.search}%`); }
  if (filters.from) { where.push('occurred_at >= ?'); params.push(filters.from); }
  if (filters.to) { where.push('occurred_at <= ?'); params.push(filters.to); }
  const limit = Math.min(1000, Math.max(1, Number(filters.limit) || 100)); const offset = Math.max(0, Number(filters.offset) || 0);
  return getDb().prepare(`SELECT * FROM system_log ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY occurred_at DESC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset).map((row) => {
      let details = null;
      try { details = row.details_json ? JSON.parse(row.details_json) : null; } catch { details = row.details_json; }
      const safe = redactForLog({ ...row, message: row.message, details });
      return { ...safe, details_json: safe.details === null ? null : JSON.stringify(safe.details) };
    });
}
module.exports = { info:(c,m,d,x)=>write('INFO',c,m,d,x), warn:(c,m,d,x)=>write('WARN',c,m,d,x), error:(c,m,d,x)=>write('ERROR',c,m,d,x), queryLogs, write, redact, sanitize, scrubPersistedLogs };
