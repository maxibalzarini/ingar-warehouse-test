'use strict';

const { createHash } = require('node:crypto');

const PAGE = Object.freeze({ width: 595, height: 842, left: 36, right: 559, top: 802, bottom: 46 });

function sha256(value) { return createHash('sha256').update(value).digest('hex'); }
function safeText(value) {
  return String(value ?? '')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/\u00B0/g, 'o')
    .replace(/[^\x20-\xFF]/g, '?');
}
function latinHex(value) { return Buffer.from(safeText(value), 'latin1').toString('hex').toUpperCase(); }
function txt(value, x, y, size = 9, bold = false) { return `BT /${bold ? 'F2' : 'F1'} ${size} Tf 1 0 0 1 ${x} ${y} Tm <${latinHex(value)}> Tj ET`; }
function line(x1, y1, x2, y2, w = 0.5) { return `${w} w ${x1} ${y1} m ${x2} ${y2} l S`; }
function fillRect(x, y, w, h, gray = 0.96) { return `${gray} g ${x} ${y} ${w} ${h} re f 0 g`; }
function strokeRect(x, y, w, h, width = 0.45) { return `0.75 G ${width} w ${x} ${y} ${w} ${h} re S 0 G`; }
function wrap(value, max = 82) {
  const words = safeText(value).replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
  const out = []; let current = '';
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > max && current) { out.push(current); current = word; }
    else current = next;
  }
  if (current) out.push(current);
  return out.length ? out : ['-'];
}
function formatDate(value) {
  if (!value) return '-';
  const d = new Date(value);
  if (!Number.isFinite(d.getTime())) return safeText(value);
  return new Intl.DateTimeFormat('es-AR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Argentina/Buenos_Aires' }).format(d);
}

function pdfFromPages(pages) {
  const objects = [null, '<< /Type /Catalog /Pages 2 0 R >>', null,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];
  const pageIds = [];
  for (const commands of pages) {
    const stream = Buffer.from(commands.join('\n'), 'binary');
    const pageId = objects.length; const contentId = pageId + 1; pageIds.push(pageId);
    objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE.width} ${PAGE.height}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`);
    objects.push(Buffer.concat([Buffer.from(`<< /Length ${stream.length} >>\nstream\n`, 'ascii'), stream, Buffer.from('\nendstream', 'ascii')]));
  }
  objects[2] = `<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] >>`;
  const header = Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n', 'binary'); const chunks = [header], offsets = [0]; let cursor = header.length;
  for (let i = 1; i < objects.length; i += 1) {
    offsets[i] = cursor; const body = Buffer.from(String(objects[i]), 'binary'); const pre = Buffer.from(`${i} 0 obj\n`, 'ascii'); const post = Buffer.from('\nendobj\n', 'ascii');
    chunks.push(pre, body, post); cursor += pre.length + body.length + post.length;
  }
  const xrefOffset = cursor; let xref = `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let i = 1; i < objects.length; i += 1) xref += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  xref += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`; chunks.push(Buffer.from(xref, 'ascii'));
  return Buffer.concat(chunks);
}

function documentBuilder({ title, documentNumber, subtitle, generatedAt }) {
  const pages = []; let commands = []; let y = PAGE.top;
  const pageHeader = () => {
    commands = [];
    commands.push(txt('INGAR CONSULTING', PAGE.left, 813, 9, true));
    commands.push(txt('Warehouse - Gestión integral de pañol y activos', PAGE.left, 798, 7));
    commands.push(txt(documentNumber, 430, 813, 7, true));
    commands.push(line(PAGE.left, 787, PAGE.right, 787, 0.8));
    commands.push(txt(title, PAGE.left, 762, 15, true));
    if (subtitle) commands.push(txt(subtitle, PAGE.left, 744, 8));
    commands.push(txt(`Emitido: ${formatDate(generatedAt)}`, 421, 744, 7));
    y = 714;
  };
  const newPage = () => { if (commands.length) pages.push(commands); pageHeader(); };
  const ensure = (need = 40) => { if (y - need < PAGE.bottom + 28) newPage(); };
  const section = (label) => { ensure(34); commands.push(fillRect(PAGE.left, y - 17, PAGE.right - PAGE.left, 22, 0.95)); commands.push(txt(label, PAGE.left + 8, y - 10, 9, true)); y -= 34; };
  const pair = (label, value, x, width = 245) => { commands.push(txt(label, x, y, 6.5, true)); commands.push(txt(value || '-', x, y - 13, 8.5)); commands.push(line(x, y - 18, x + width, y - 18, 0.32)); };
  const twoPairs = (aLabel, aValue, bLabel, bValue) => { ensure(44); pair(aLabel, aValue, PAGE.left, 244); pair(bLabel, bValue, 311, 248); y -= 42; };
  const paragraph = (value, options = {}) => {
    const lines = wrap(value, options.max || 92); const size = options.size || 8; const leading = options.leading || 12;
    ensure(lines.length * leading + 12);
    for (const item of lines) { commands.push(txt(item, options.x || PAGE.left, y, size, Boolean(options.bold))); y -= leading; }
    y -= options.after ?? 6;
  };
  const statusBox = (label, message) => {
    const lines = wrap(message, 80); const h = 32 + (lines.length - 1) * 11; ensure(h + 14);
    commands.push(fillRect(PAGE.left, y - h + 8, PAGE.right - PAGE.left, h, 0.94)); commands.push(strokeRect(PAGE.left, y - h + 8, PAGE.right - PAGE.left, h));
    commands.push(txt(label, PAGE.left + 10, y - 8, 10, true)); let sy = y - 22; for (const item of lines) { commands.push(txt(item, PAGE.left + 10, sy, 8)); sy -= 11; } y -= h + 9;
  };
  const table = (headers, rows, widths, options = {}) => {
    const left = options.left || PAGE.left; const rowH = options.rowH || 24; const headerH = 24; const totalW = widths.reduce((a, b) => a + b, 0);
    const drawHeader = () => {
      ensure(headerH + rowH + 4); commands.push(fillRect(left, y - headerH + 6, totalW, headerH, 0.92)); commands.push(strokeRect(left, y - headerH + 6, totalW, headerH));
      let x = left; headers.forEach((h, i) => { commands.push(txt(h, x + 4, y - 8, 6.8, true)); x += widths[i]; if (i < widths.length - 1) commands.push(line(x, y + 6, x, y - headerH + 6, 0.25)); }); y -= headerH;
    };
    drawHeader();
    for (const row of rows) {
      const wrapped = row.map((cell, i) => wrap(cell, Math.max(8, Math.floor(widths[i] / 5.2)))); const maxLines = Math.min(3, Math.max(...wrapped.map((r) => r.length))); const dynamicH = Math.max(rowH, 12 + maxLines * 10);
      if (y - dynamicH < PAGE.bottom + 38) { newPage(); drawHeader(); }
      commands.push(strokeRect(left, y - dynamicH + 6, totalW, dynamicH)); let x = left;
      row.forEach((cell, i) => { let cy = y - 8; for (const l of wrapped[i].slice(0, 3)) { commands.push(txt(l, x + 4, cy, 6.8)); cy -= 9; } x += widths[i]; if (i < widths.length - 1) commands.push(line(x, y + 6, x, y - dynamicH + 6, 0.22)); });
      y -= dynamicH;
    }
    y -= 8;
  };
  const signatures = (labels) => {
    if (y < 116) newPage();
    const gap = 18; const widths = labels.length === 3 ? [162, 162, 162] : [248, 248]; let x = PAGE.left;
    for (let i = 0; i < labels.length; i += 1) { const w = widths[i]; commands.push(line(x, y - 28, x + w, y - 28, 0.55)); commands.push(txt(labels[i], x, y - 42, 7, true)); commands.push(txt('Firma / aclaración / fecha', x, y - 54, 6.5)); x += w + gap; }
    y -= 68;
  };
  newPage();
  return { pages, get commands() { return commands; }, get y() { return y; }, set y(value) { y = value; }, newPage, ensure, section, twoPairs, paragraph, statusBox, table, signatures, finish() { if (commands.length) pages.push(commands); return pdfFromPages(pages); } };
}

function identification(doc, snapshot) {
  doc.section('IDENTIFICACIÓN');
  doc.twoPairs('Persona', snapshot.user.fullName, 'Usuario', snapshot.user.username);
  doc.twoPairs('Legajo / identificación', snapshot.user.employeeNumber || snapshot.user.document || '-', 'Sector / sede', [snapshot.user.sector, snapshot.user.site].filter(Boolean).join(' / ') || '-');
  doc.twoPairs('Centro de costo', snapshot.user.costCenter || '-', 'Estado de persona', snapshot.user.personStatus || '-');
  doc.twoPairs('Supervisor', snapshot.supervisor.name || 'Sin supervisor asignado', 'Emisor', snapshot.emitter.name || snapshot.emitter.username || '-');
}

function buildPatrimonialReturnPdf(snapshot) {
  const doc = documentBuilder({ title: 'REMITO DE DEVOLUCIÓN PATRIMONIAL', documentNumber: snapshot.documents.patrimonialReceipt, subtitle: 'Documento para cierre patrimonial previo a la baja', generatedAt: snapshot.generatedAt });
  identification(doc, snapshot);
  doc.section('HERRAMIENTAS Y EQUIPOS A DEVOLVER');
  if (!snapshot.tools.length) doc.statusBox('VISTO BUENO - SIN DEUDA CON PAÑOL', 'No existen herramientas o equipos en custodia pendientes de devolución para esta persona al momento de emisión.');
  else doc.table(['Código', 'Descripción', 'Cant.', 'Estado', 'Vencimiento'], snapshot.tools.map((r) => [r.internalCode, r.description, String(r.quantity), r.status, formatDate(r.dueAt)]), [82, 215, 48, 82, 96]);
  doc.section('KITS A CARGO');
  if (!snapshot.kits.length) doc.paragraph('Sin kits personales activos asignados.');
  else doc.table(['Kit', 'Descripción', 'Componentes', 'Asignado'], snapshot.kits.map((r) => [r.internalCode, r.description, String(r.componentCount), formatDate(r.assignedAt)]), [95, 255, 72, 101]);
  doc.section('VEHÍCULOS / EQUIPOS MÓVILES A DEVOLVER');
  if (!snapshot.vehicles.length) doc.paragraph('Sin vehículos o equipos móviles en custodia.');
  else doc.table(['Código / patente', 'Descripción', 'Estado', 'Vencimiento'], snapshot.vehicles.map((r) => [[r.licensePlate, r.internalCode].filter(Boolean).join(' / '), r.description, r.status, formatDate(r.dueAt)]), [120, 230, 82, 91]);
  doc.section('INCIDENCIAS / EXCEPCIONES ABIERTAS');
  if (!snapshot.incidents.length) doc.paragraph('Sin incidencias patrimoniales abiertas vinculadas a la persona.');
  else doc.table(['N°', 'Activo', 'Tipo', 'Estado'], snapshot.incidents.map((r) => [r.number, r.assetCode || '-', r.type, r.status]), [100, 150, 120, 153]);
  doc.section('OBSERVACIONES Y CONFORMIDAD');
  doc.paragraph('Observaciones: ________________________________________________________________________________________________');
  doc.paragraph('______________________________________________________________________________________________________________');
  doc.paragraph('Con la firma, Supervisor y Pañol dejan constancia del estado patrimonial consignado en este remito y de las devoluciones efectivamente verificadas.', { size: 7.2, max: 105 });
  doc.signatures(['Supervisor responsable', 'Responsable de Pañol']);
  doc.commands.push(txt(`Snapshot SHA-256: ${snapshot.snapshotSha256}`, PAGE.left, 28, 6));
  return doc.finish();
}

function buildHrReleasePdf(snapshot) {
  const doc = documentBuilder({ title: 'ACTA DE LIBERACIÓN PARA RECURSOS HUMANOS', documentNumber: snapshot.documents.hrRelease, subtitle: 'Presentar en Recursos Humanos para iniciar la liquidación final', generatedAt: snapshot.generatedAt });
  identification(doc, snapshot);
  doc.section('ESTADO PATRIMONIAL');
  doc.table(['Dominio', 'Resultado', 'Pendientes'], [
    ['Herramientas / equipos', snapshot.status.tools, String(snapshot.tools.length)],
    ['Kits', snapshot.status.kits, String(snapshot.kits.length)],
    ['Vehículos', snapshot.status.vehicles, String(snapshot.vehicles.length)]
  ], [205, 210, 108], { rowH: 28 });
  if (snapshot.incidents.length) {
    doc.section('INCIDENCIAS ABIERTAS RELEVANTES');
    doc.table(['N°', 'Activo', 'Estado'], snapshot.incidents.map((r) => [r.number, r.assetCode || '-', r.status]), [130, 230, 163]);
  }
  doc.section('RESULTADO PARA RR.HH.');
  if (snapshot.clearanceReady) doc.statusBox('APTO PARA INICIAR LIQUIDACIÓN FINAL', 'La verificación patrimonial no registra herramientas, kits ni vehículos pendientes de devolución al momento de emisión.');
  else doc.statusBox('NO LIBERADO - EXISTEN ELEMENTOS PENDIENTES', `Herramientas/equipos: ${snapshot.tools.length}; kits: ${snapshot.kits.length}; vehículos: ${snapshot.vehicles.length}. Resolver los pendientes antes de utilizar esta acta como liberación patrimonial.`);
  doc.section('OBSERVACIONES');
  doc.paragraph('______________________________________________________________________________________________________________');
  doc.paragraph('______________________________________________________________________________________________________________');
  doc.signatures(['Supervisor responsable', 'Responsable de Pañol', 'Recepción RR.HH.']);
  doc.commands.push(txt(`Snapshot SHA-256: ${snapshot.snapshotSha256}`, PAGE.left, 28, 6));
  return doc.finish();
}

module.exports = { buildPatrimonialReturnPdf, buildHrReleasePdf, sha256 };
