'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, parseBoolean, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');

function normalize(input, current = null) {
  const operationType = String(input.operationType ?? current?.operation_type ?? '').toUpperCase();
  if (!['RETIRO', 'RESERVA'].includes(operationType)) throw Object.assign(new Error('Operación de política inválida.'), { status: 422, code: 'POLICY_OPERATION_INVALID' });
  const numberOrNull = (value, field, integer = false) => {
    if (value === null || value === undefined || value === '') return null;
    const n = Number(value); if (!Number.isFinite(n) || n <= 0 || (integer && !Number.isInteger(n))) throw Object.assign(new Error(`Valor inválido: ${field}.`), { status: 422, code: 'POLICY_VALUE_INVALID' });
    return n;
  };
  return {
    siteId: input.siteId === undefined ? current?.site_id || null : (optionalString(input.siteId, 'siteId', { max: 80 }) || null),
    categoryId: input.categoryId === undefined ? current?.category_id || null : (optionalString(input.categoryId, 'categoryId', { max: 80 }) || null),
    operationType,
    name: requiredString(input.name ?? current?.name, 'name', { min: 3, max: 120 }),
    requiresApproval: parseBoolean(input.requiresApproval, current ? Boolean(current.requires_approval) : false),
    maxQuantity: numberOrNull(input.maxQuantity === undefined ? current?.max_quantity : input.maxQuantity, 'maxQuantity'),
    maxDurationHours: numberOrNull(input.maxDurationHours === undefined ? current?.max_duration_hours : input.maxDurationHours, 'maxDurationHours', true),
    priority: safeInteger(input.priority ?? current?.priority, 100, 1, 10000),
    active: parseBoolean(input.active, current ? Boolean(current.active) : true)
  };
}

function validateRefs(data, db) {
  if (data.siteId && !db.prepare('SELECT 1 FROM site WHERE id = ? AND active = 1').get(data.siteId)) throw Object.assign(new Error('Sede de política inválida.'), { status: 422, code: 'POLICY_SITE_INVALID' });
  if (data.categoryId && !db.prepare('SELECT 1 FROM asset_category WHERE id = ? AND active = 1 AND deleted_at IS NULL').get(data.categoryId)) throw Object.assign(new Error('Categoría de política inválida.'), { status: 422, code: 'POLICY_CATEGORY_INVALID' });
}

function listPolicies(filters = {}) {
  const where = ['rp.deleted_at IS NULL']; const params = [];
  if (filters.active !== undefined) { where.push('rp.active = ?'); params.push(filters.active ? 1 : 0); }
  if (filters.operationType) { where.push('rp.operation_type = ?'); params.push(String(filters.operationType).toUpperCase()); }
  return getDb().prepare(`SELECT rp.*, s.code AS site_code, s.name AS site_name, c.code AS category_code, c.name AS category_name
    FROM request_policy rp LEFT JOIN site s ON s.id = rp.site_id LEFT JOIN asset_category c ON c.id = rp.category_id
    WHERE ${where.join(' AND ')} ORDER BY rp.priority, rp.name`).all(...params);
}

function createPolicy(input, context) {
  const data = normalize(input);
  return transaction((db) => {
    validateRefs(data, db); const now = new Date().toISOString(); const id = randomUUID();
    db.prepare(`INSERT INTO request_policy(id, site_id, category_id, operation_type, name, requires_approval, max_quantity, max_duration_hours, priority, active, version, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`).run(id, data.siteId, data.categoryId, data.operationType, data.name, data.requiresApproval ? 1 : 0, data.maxQuantity, data.maxDurationHours, data.priority, data.active ? 1 : 0, now, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'REQUEST_POLICY.CREATE', entityType: 'request_policy', entityId: id, after: data, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return listPolicies().find((item) => item.id === id);
  });
}

function updatePolicy(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM request_policy WHERE id = ? AND deleted_at IS NULL').get(id);
    if (!current) throw Object.assign(new Error('Política no encontrada.'), { status: 404, code: 'POLICY_NOT_FOUND' });
    const version = Number(input.version); if (!Number.isInteger(version) || version !== current.version) throw Object.assign(new Error('La política fue modificada por otra operación.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    const data = normalize(input, current); validateRefs(data, db); const now = new Date().toISOString();
    const result = db.prepare(`UPDATE request_policy SET site_id=?, category_id=?, operation_type=?, name=?, requires_approval=?, max_quantity=?, max_duration_hours=?, priority=?, active=?, version=version+1, updated_at=? WHERE id=? AND version=?`)
      .run(data.siteId, data.categoryId, data.operationType, data.name, data.requiresApproval ? 1 : 0, data.maxQuantity, data.maxDurationHours, data.priority, data.active ? 1 : 0, now, id, version);
    if (result.changes !== 1) throw Object.assign(new Error('Conflicto de concurrencia en política.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'REQUEST_POLICY.UPDATE', entityType: 'request_policy', entityId: id, before: current, after: data, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return listPolicies().find((item) => item.id === id);
  });
}

function resolvePolicy(asset, operationType, siteId, db = getDb()) {
  return db.prepare(`SELECT * FROM request_policy WHERE deleted_at IS NULL AND active = 1 AND operation_type = ?
    AND (site_id IS NULL OR site_id = ?) AND (category_id IS NULL OR category_id = ?)
    ORDER BY (site_id IS NOT NULL) DESC, (category_id IS NOT NULL) DESC, priority ASC, created_at ASC LIMIT 1`)
    .get(operationType, siteId, asset.category_id) || null;
}

module.exports = { listPolicies, createPolicy, updatePolicy, resolvePolicy };
