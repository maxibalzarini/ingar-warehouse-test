'use strict';

const { getDb } = require('../db/database');
const { svg } = require('./qr-code-service');

function canonicalOperationUrl(baseUrl) {
  const normalized = String(baseUrl || '').trim().replace(/\/+$/, '');
  if (!normalized) {
    throw Object.assign(new Error('Acceso móvil no disponible. Conecte la computadora y el celular a la misma red.'), {
      status: 503,
      code: 'MOBILE_ACCESS_NETWORK_UNAVAILABLE'
    });
  }
  return `${normalized}/mi-operacion`;
}

function listMobileAccess(baseUrl) {
  const url = canonicalOperationUrl(baseUrl);
  return getDb().prepare(`SELECT id AS site_id, code AS site_code, name AS site_name
    FROM site WHERE active = 1 ORDER BY code`).all().map((site) => ({
      ...site,
      title: 'Mi operación',
      url
    }));
}

function mobileAccessQrSvg(siteId, baseUrl) {
  const site = getDb().prepare(`SELECT id AS site_id, code AS site_code, name AS site_name
    FROM site WHERE id = ? AND active = 1`).get(String(siteId || ''));
  if (!site) {
    throw Object.assign(new Error('Sede no encontrada o inactiva.'), { status: 404, code: 'SITE_NOT_FOUND' });
  }
  const url = canonicalOperationUrl(baseUrl);
  return { ...site, url, svg: svg(url) };
}

module.exports = { canonicalOperationUrl, listMobileAccess, mobileAccessQrSvg };
