'use strict';

const PAGE_SIZES = Object.freeze({
  PORTRAIT: { width: 595, height: 842 },
  LANDSCAPE: { width: 842, height: 595 }
});

function latinHex(value) {
  const safe = String(value ?? '')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/[^\x00-\xFF]/g, '?');
  return Buffer.from(safe, 'latin1').toString('hex').toUpperCase();
}

function textCommand(text, x, y, size = 8, bold = false) {
  return `BT /${bold ? 'F2' : 'F1'} ${size} Tf 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm <${latinHex(text)}> Tj ET`;
}

function lineCommand(x1, y1, x2, y2, width = 0.5) {
  return `${width} w ${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`;
}

function rectCommand(x, y, width, height, fillGray = null, stroke = true) {
  const parts = [];
  if (fillGray !== null) parts.push(`${fillGray} g ${x.toFixed(2)} ${y.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re f`, '0 g');
  if (stroke) parts.push(`0.6 G 0.4 w ${x.toFixed(2)} ${y.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re S`, '0 G');
  return parts.join('\n');
}

function truncate(value, maxChars) {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  if (text.length <= maxChars) return text;
  return `${text.slice(0, Math.max(1, maxChars - 3))}...`;
}

function columnWidths(columns, rows, availableWidth) {
  const samples = rows.slice(0, 100);
  const weights = columns.map((column) => {
    let max = Math.max(6, String(column.label || column.key).length);
    for (const row of samples) max = Math.max(max, Math.min(28, String(row[column.key] ?? '').replace(/\s+/g, ' ').length));
    return Math.min(24, max);
  });
  const total = weights.reduce((sum, value) => sum + value, 0) || 1;
  return weights.map((weight) => availableWidth * weight / total);
}

function buildPdf(objects) {
  const header = Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n', 'binary');
  const parts = [header];
  const offsets = [0];
  let cursor = header.length;
  for (let index = 1; index < objects.length; index += 1) {
    offsets[index] = cursor;
    const body = Buffer.isBuffer(objects[index]) ? objects[index] : Buffer.from(String(objects[index]), 'binary');
    const prefix = Buffer.from(`${index} 0 obj\n`, 'ascii');
    const suffix = Buffer.from('\nendobj\n', 'ascii');
    parts.push(prefix, body, suffix);
    cursor += prefix.length + body.length + suffix.length;
  }
  const xrefOffset = cursor;
  let xref = `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let index = 1; index < objects.length; index += 1) xref += `${String(offsets[index]).padStart(10, '0')} 00000 n \n`;
  xref += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  parts.push(Buffer.from(xref, 'ascii'));
  return Buffer.concat(parts);
}

function createReportPdf({ report, rows, metadata, orientation = 'AUTO' }) {
  const selectedOrientation = orientation === 'PORTRAIT' || orientation === 'LANDSCAPE'
    ? orientation
    : report.columns.length > 7 ? 'LANDSCAPE' : 'PORTRAIT';
  const page = PAGE_SIZES[selectedOrientation];
  const margin = 28;
  const tableWidth = page.width - margin * 2;
  const headerTop = page.height - margin;
  const tableTop = page.height - 126;
  const footerHeight = 24;
  const rowHeight = report.columns.length > 9 ? 16 : 18;
  const headerHeight = 22;
  const widths = columnWidths(report.columns, rows, tableWidth);
  const bodyFontSize = report.columns.length > 10 ? 5.7 : report.columns.length > 7 ? 6.4 : 7.2;
  const headerFontSize = Math.max(5.5, bodyFontSize);
  const rowsPerPage = Math.max(1, Math.floor((tableTop - margin - footerHeight - headerHeight) / rowHeight));
  const pageCount = Math.max(1, Math.ceil(rows.length / rowsPerPage));
  const pageStreams = [];

  for (let pageIndex = 0; pageIndex < pageCount; pageIndex += 1) {
    const commands = ['0 g', '0 G'];
    commands.push(textCommand('INGAR Warehouse Controller', margin, headerTop - 6, 15, true));
    commands.push(textCommand(report.name, margin, headerTop - 26, 11, true));
    commands.push(textCommand(`Código: ${report.code} · Categoría: ${metadata.categoryName || report.category}`, margin, headerTop - 41, 7));
    commands.push(textCommand(`Generado: ${metadata.generatedAtText} · Usuario: ${metadata.generatedBy}`, margin, headerTop - 53, 7));
    commands.push(textCommand(`Organización: ${metadata.organizationName || '—'} · Sede: ${metadata.siteName || 'Todas'} · Ubicación: ${metadata.locationName || 'Todas'}`, margin, headerTop - 65, 7));
    commands.push(textCommand(`Filtros: ${truncate(metadata.filtersText || 'Sin filtros', 145)}`, margin, headerTop - 77, 6.5));
    commands.push(textCommand(`Registros: ${rows.length}`, page.width - margin - 95, headerTop - 6, 8, true));

    let x = margin;
    const headerY = tableTop - headerHeight;
    for (let columnIndex = 0; columnIndex < report.columns.length; columnIndex += 1) {
      const width = widths[columnIndex];
      commands.push(rectCommand(x, headerY, width, headerHeight, 0.90, true));
      const maxChars = Math.max(3, Math.floor((width - 6) / (headerFontSize * 0.52)));
      commands.push(textCommand(truncate(report.columns[columnIndex].label, maxChars), x + 3, headerY + 7, headerFontSize, true));
      x += width;
    }

    const start = pageIndex * rowsPerPage;
    const pageRows = rows.slice(start, start + rowsPerPage);
    let y = headerY - rowHeight;
    for (let rowIndex = 0; rowIndex < pageRows.length; rowIndex += 1) {
      x = margin;
      const row = pageRows[rowIndex];
      for (let columnIndex = 0; columnIndex < report.columns.length; columnIndex += 1) {
        const column = report.columns[columnIndex];
        const width = widths[columnIndex];
        commands.push(rectCommand(x, y, width, rowHeight, rowIndex % 2 ? 0.975 : null, true));
        const maxChars = Math.max(3, Math.floor((width - 6) / (bodyFontSize * 0.52)));
        commands.push(textCommand(truncate(row[column.key], maxChars), x + 3, y + 5.5, bodyFontSize));
        x += width;
      }
      y -= rowHeight;
    }

    commands.push(lineCommand(margin, margin + 18, page.width - margin, margin + 18, 0.4));
    commands.push(textCommand(`Página ${pageIndex + 1} de ${pageCount}`, page.width - margin - 72, margin + 6, 7));
    commands.push(textCommand(`Exportación trazable · ${metadata.exportId || ''}`, margin, margin + 6, 6.5));
    pageStreams.push(Buffer.from(commands.join('\n'), 'ascii'));
  }

  const objects = [null, '<< /Type /Catalog /Pages 2 0 R >>', null,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];
  const pageIds = [];
  for (const stream of pageStreams) {
    const pageId = objects.length;
    const contentId = pageId + 1;
    pageIds.push(pageId);
    objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${page.width} ${page.height}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`);
    objects.push(Buffer.concat([Buffer.from(`<< /Length ${stream.length} >>\nstream\n`, 'ascii'), stream, Buffer.from('\nendstream', 'ascii')]));
  }
  objects[2] = `<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] >>`;
  return buildPdf(objects);
}

module.exports = { createReportPdf };
