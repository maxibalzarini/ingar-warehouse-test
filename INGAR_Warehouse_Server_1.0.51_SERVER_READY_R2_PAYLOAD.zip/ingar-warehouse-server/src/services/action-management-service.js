'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { appendAudit } = require('./audit-service');
const { permissionAssignments, userHasScope, scopeWhere } = require('../security/scope');
const { requiredString, optionalString, safeInteger } = require('../security/validation');
const { saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { enqueueNotification } = require('./notification-service');
const { getSetting } = require('./settings-service');
const { sha256, stableJson } = require('../security/tokens');

const ACTION_STATUSES = new Set(['PENDIENTE', 'EN_CURSO', 'CERRADA']);
const PRIORITIES = new Set(['BAJA', 'MEDIA', 'ALTA', 'URGENTE']);
const CAUSES = new Set(['OPERATIVA','FALTA_DISPONIBILIDAD','DEMORA_APROBACION','DEMORA_PREPARACION','DEMORA_USUARIO','FALTA_CAPACITACION','FALLA_ACTIVO','MANTENIMIENTO','COMPRA_REPOSICION','PLANIFICACION','OTRA','PENDIENTE_ANALISIS']);
const RELATION_TYPES = new Set(['INDICATOR','ASSET','TOOL','CONSUMABLE','PERSON','SECTOR','INCIDENT','MAINTENANCE','REQUEST','CUSTODY','BUDGET','PURCHASE','LOCATION','SITE','OTHER']);
const EVIDENCE_TYPES = new Set(['FILE','NOTE','REFERENCE','INTERNAL_LINK']);
const MEETING_TYPES = new Set(['SEMANAL','MENSUAL']);
const TOPIC_TYPES = new Set(['INFORMACION','DECISION_REQUERIDA','ACCION_REQUERIDA']);

function actionError(message, code = 'ACTION_INVALID', status = 422, fieldErrors = []) {
  return Object.assign(new Error(message), { code, status, fieldErrors });
}
function requirePermission(user, permission) {
  if (!user || !hasPermission(user, permission)) throw actionError('Permiso insuficiente.', 'FORBIDDEN', 403);
}
function nowIso() { return new Date().toISOString(); }
function todayKey(date = new Date()) {
  const candidate = String(getSetting('locale.timezone', 'America/Argentina/Buenos_Aires') || 'America/Argentina/Buenos_Aires');
  let timeZone = candidate;
  try { new Intl.DateTimeFormat('es-AR', { timeZone }).format(date); } catch { timeZone = 'America/Argentina/Buenos_Aires'; }
  return new Intl.DateTimeFormat('en-CA', { timeZone, year:'numeric', month:'2-digit', day:'2-digit' }).format(date);
}
function isoDate(value, field, fallback = null) {
  const raw = value || fallback;
  if (!raw || !/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(String(raw)) || Number.isNaN(new Date(raw).getTime())) {
    throw actionError(`Fecha inválida: ${field}.`, 'DATE_INVALID', 422, [{ field, message: 'Indique una fecha válida.' }]);
  }
  return String(raw).slice(0,10);
}
function pagination(input = {}) {
  const page = safeInteger(input.page, 1, 1, 100000);
  const pageSize = safeInteger(input.pageSize, 50, 1, 250);
  return { page, pageSize, offset:(page-1)*pageSize };
}
function audit(db, context, action, entityType, entityId, before, after, reason = null) {
  appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action, entityType, entityId, before, after, reason, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
}
function userPersonId(user, db = getDb()) {
  return user.personId || user.person_id || db.prepare('SELECT person_id FROM user_account WHERE id=?').get(user.id)?.person_id || null;
}
function organizationId(db, siteId = null) {
  if (siteId) {
    const row = db.prepare('SELECT organization_id FROM site WHERE id=? AND active=1').get(siteId);
    if (!row) throw actionError('Sede inexistente o inactiva.', 'SITE_INVALID');
    return row.organization_id;
  }
  const row = db.prepare('SELECT id FROM organization WHERE active=1 ORDER BY created_at LIMIT 1').get();
  if (!row) throw actionError('No existe una organización activa.', 'ORGANIZATION_INVALID');
  return row.id;
}
function normalizeScope(db, user, permission, siteId, locationId, allowGlobal = true) {
  if (!siteId) {
    const global = permissionAssignments(user, permission, db).some((item) => !item.site_id && !item.location_id);
    if (!allowGlobal || !global) throw actionError('La operación global está fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
    return { organizationId: organizationId(db), scopeType:'GLOBAL', siteId:null, locationId:null };
  }
  if (locationId) {
    const location = db.prepare('SELECT id,site_id FROM storage_location WHERE id=? AND active=1').get(locationId);
    if (!location || location.site_id !== siteId) throw actionError('La ubicación no pertenece a la sede indicada.', 'LOCATION_INVALID');
  }
  if (!userHasScope(user, siteId, locationId || null, permission, db)) throw actionError('La operación está fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
  return { organizationId:organizationId(db,siteId), scopeType:locationId?'LOCATION':'SITE', siteId, locationId:locationId||null };
}
function effectiveStatus(row, dateKey = todayKey()) {
  return row.status !== 'CERRADA' && row.target_date < dateKey ? 'VENCIDA' : row.status;
}
function daysRemaining(targetDate, dateKey = todayKey()) {
  return Math.round((Date.parse(`${targetDate}T00:00:00Z`) - Date.parse(`${dateKey}T00:00:00Z`))/86400000);
}
function mapAction(row, dateKey = todayKey()) {
  if (!row) return null;
  return { ...row, effective_status:effectiveStatus(row,dateKey), days_remaining: row.status==='CERRADA' ? null : daysRemaining(row.target_date,dateKey), overdue:effectiveStatus(row,dateKey)==='VENCIDA' };
}
function getActionRow(db, id) {
  return db.prepare(`SELECT a.*,s.name AS site_name,l.name AS location_name,ap.full_name AS assigned_person_name,r.name AS assigned_role_name,
    mp.full_name AS manager_name,vp.full_name AS verifier_name,cp.full_name AS created_by_name,up.full_name AS updated_by_name
    FROM management_action a LEFT JOIN site s ON s.id=a.site_id LEFT JOIN storage_location l ON l.id=a.location_id
    LEFT JOIN person ap ON ap.id=a.assigned_person_id LEFT JOIN role r ON r.id=a.assigned_role_id
    LEFT JOIN person mp ON mp.id=a.responsible_manager_person_id LEFT JOIN person vp ON vp.id=a.verifier_person_id
    LEFT JOIN user_account cu ON cu.id=a.created_by_user_id LEFT JOIN person cp ON cp.id=cu.person_id
    LEFT JOIN user_account uu ON uu.id=a.updated_by_user_id LEFT JOIN person up ON up.id=uu.person_id WHERE a.id=?`).get(id);
}
function hasActionScope(db, user, row, permission) {
  if (!row || !hasPermission(user, permission)) return false;
  if (row.scope_type === 'GLOBAL') return permissionAssignments(user, permission, db).some((item) => !item.site_id && !item.location_id);
  return userHasScope(user, row.site_id, row.location_id, permission, db);
}
function assertActionScope(db, user, row, permission = 'Actions.Read') {
  if (!row) throw actionError('Acción no encontrada.', 'ACTION_NOT_FOUND', 404);
  if (!hasActionScope(db, user, row, permission)) throw actionError('Acción fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
  return row;
}
function actionCode(db, date = new Date()) {
  const prefix = `ACC-${String(date.getUTCFullYear())}`;
  const count = Number(db.prepare('SELECT COUNT(*) AS n FROM management_action WHERE code LIKE ?').get(`${prefix}-%`).n || 0)+1;
  return `${prefix}-${String(count).padStart(5,'0')}`;
}
function event(db, actionId, type, context, details, fromStatus = null, toStatus = null, metadata = null) {
  const now = nowIso();
  db.prepare(`INSERT INTO management_action_event(id,action_id,event_type,from_status,to_status,details,metadata_json,actor_user_id,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(),actionId,type,fromStatus,toStatus,requiredString(details,'details',{min:2,max:2000}),metadata?JSON.stringify(metadata):null,context.user.id,now,context.correlationId||randomUUID(),now);
}

function decisionEvents(db, decisionId) {
  return db.prepare('SELECT * FROM management_meeting_decision_event WHERE decision_id=? ORDER BY occurred_at,rowid').all(decisionId);
}
function hydrateDecision(db, row) {
  if (!row) return null;
  const lifecycleEvents = decisionEvents(db, row.id);
  const latest = lifecycleEvents.at(-1) || null;
  const actionId = latest?.action_id || row.action_id || null;
  const actionCode = actionId ? db.prepare('SELECT code FROM management_action WHERE id=?').get(actionId)?.code || null : null;
  return {
    ...row,
    original_status: row.status,
    original_action_id: row.action_id,
    status: latest?.to_status || row.status,
    action_id: actionId,
    action_code: actionCode,
    resolved_at: latest && latest.to_status !== 'PENDIENTE' ? latest.occurred_at : row.resolved_at,
    resolved_by_user_id: latest && latest.to_status !== 'PENDIENTE' ? latest.actor_user_id : row.resolved_by_user_id,
    resolution_note: latest && latest.to_status !== 'PENDIENTE' ? latest.resolution_note : row.resolution_note,
    lifecycle_events: lifecycleEvents
  };
}
function appendDecisionLifecycleEvent(db, decision, eventType, toStatus, actionId, resolutionNote, context) {
  const meeting = db.prepare('SELECT id,status,integrity_hash FROM management_meeting WHERE id=?').get(decision.meeting_id);
  if (!meeting || meeting.status !== 'CERRADA' || !meeting.integrity_hash) throw actionError('El lifecycle posterior requiere un acta cerrada e íntegra.','MEETING_NOT_CLOSED',409);
  const current = hydrateDecision(db, decision);
  const latestMeetingEvent = db.prepare('SELECT event_hash FROM management_meeting_decision_event WHERE meeting_id=? ORDER BY occurred_at DESC,rowid DESC LIMIT 1').get(meeting.id);
  const previousHash = latestMeetingEvent?.event_hash || meeting.integrity_hash;
  const occurredAt = nowIso();
  const payload = {
    meetingId: meeting.id,
    decisionId: decision.id,
    eventType,
    fromStatus: current.status,
    toStatus,
    actionId: actionId || current.action_id || null,
    resolutionNote: resolutionNote || null,
    actorUserId: context.user.id,
    occurredAt,
    previousHash
  };
  const eventHash = sha256(stableJson(payload));
  const id = randomUUID();
  db.prepare(`INSERT INTO management_meeting_decision_event(
      id,meeting_id,decision_id,event_type,from_status,to_status,action_id,resolution_note,actor_user_id,occurred_at,previous_hash,event_hash
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id,meeting.id,decision.id,eventType,current.status,toStatus,payload.actionId,payload.resolutionNote,context.user.id,occurredAt,previousHash,eventHash);
  const created = db.prepare('SELECT * FROM management_meeting_decision_event WHERE id=?').get(id);
  audit(db,context,`MEETING.DECISION_${eventType}`,'management_meeting_decision_event',id,null,created,resolutionNote||null);
  return hydrateDecision(db, decision);
}
function getActionOptions(user) {
  requirePermission(user,'Actions.Read');
  const db=getDb();
  const scopes=permissionAssignments(user,'Actions.Read',db);
  const global=scopes.some((s)=>!s.site_id&&!s.location_id);
  const siteIds=new Set(scopes.filter((s)=>s.site_id).map((s)=>s.site_id));
  const locationIds=new Set(scopes.filter((s)=>s.location_id).map((s)=>s.location_id));
  for(const row of locationIds.size?db.prepare(`SELECT id,site_id FROM storage_location WHERE id IN (${[...locationIds].map(()=>'?').join(',')})`).all(...locationIds):[])siteIds.add(row.site_id);
  const sites=global?db.prepare('SELECT id,code,name FROM site WHERE active=1 ORDER BY code').all():siteIds.size?db.prepare(`SELECT id,code,name FROM site WHERE active=1 AND id IN (${[...siteIds].map(()=>'?').join(',')}) ORDER BY code`).all(...siteIds):[];
  const locations=global?db.prepare('SELECT id,site_id,code,name FROM storage_location WHERE active=1 ORDER BY code').all():locationIds.size?db.prepare(`SELECT id,site_id,code,name FROM storage_location WHERE active=1 AND id IN (${[...locationIds].map(()=>'?').join(',')}) ORDER BY code`).all(...locationIds):[];
  return { phase:30, allowGlobal:global, sites, locations,
    people:db.prepare("SELECT id,full_name,sector FROM person WHERE deleted_at IS NULL AND status='ACTIVA' ORDER BY full_name").all(),
    roles:db.prepare('SELECT id,code,name FROM role WHERE active=1 ORDER BY name').all(),
    sectors:db.prepare("SELECT DISTINCT TRIM(sector) AS value FROM person WHERE deleted_at IS NULL AND TRIM(IFNULL(sector,''))<>'' ORDER BY value").all().map((r)=>r.value),
    indicators:db.prepare('SELECT code,name,category FROM management_indicator_definition WHERE active=1 ORDER BY category,name').all(),
    causes:[...CAUSES], priorities:[...PRIORITIES], evidenceTypes:[...EVIDENCE_TYPES] };
}
function listActions(user, input = {}) {
  requirePermission(user,'Actions.Read'); const db=getDb(); const {page,pageSize,offset}=pagination(input);
  const where=['1=1']; const params=[]; const scope=scopeWhere(user,'Actions.Read','a.site_id','a.location_id',db);
  const globalAllowed=permissionAssignments(user,'Actions.Read',db).some((s)=>!s.site_id&&!s.location_id);
  where.push(globalAllowed?`(a.scope_type='GLOBAL' OR ${scope.sql})`:`(${scope.sql})`); params.push(...scope.params);
  if(input.siteId){where.push('a.site_id=?');params.push(input.siteId);} if(input.locationId){where.push('a.location_id=?');params.push(input.locationId);}
  if(input.priority){where.push('a.priority=?');params.push(String(input.priority).toUpperCase());}
  if(input.indicatorCode){where.push('a.indicator_code=?');params.push(input.indicatorCode);}
  if(input.assignedPersonId){where.push('a.assigned_person_id=?');params.push(input.assignedPersonId);}
  if(input.sector){where.push('a.assigned_sector=? COLLATE NOCASE');params.push(String(input.sector).trim());}
  if(input.mine===true||input.mine==='true'){const personId=userPersonId(user,db);where.push('(a.assigned_person_id=? OR a.created_by_user_id=?)');params.push(personId,user.id);}
  const requestedStatus=String(input.status||'').toUpperCase(); const dateKey=todayKey();
  if(requestedStatus==='VENCIDA'){where.push("a.status<>'CERRADA' AND a.target_date<?");params.push(dateKey);} else if(requestedStatus){where.push('a.status=?');params.push(requestedStatus);}
  if(input.search){where.push('(a.code LIKE ? OR a.title LIKE ? OR a.problem LIKE ? OR a.action_text LIKE ?)');const q=`%${String(input.search).trim()}%`;params.push(q,q,q,q);}
  const from=`FROM management_action a LEFT JOIN site s ON s.id=a.site_id LEFT JOIN storage_location l ON l.id=a.location_id LEFT JOIN person p ON p.id=a.assigned_person_id LEFT JOIN role r ON r.id=a.assigned_role_id`;
  const rows=db.prepare(`SELECT a.*,s.name AS site_name,l.name AS location_name,p.full_name AS assigned_person_name,r.name AS assigned_role_name ${from} WHERE ${where.join(' AND ')} ORDER BY CASE WHEN a.status<>'CERRADA' AND a.target_date<? THEN 0 ELSE 1 END,CASE a.priority WHEN 'URGENTE' THEN 1 WHEN 'ALTA' THEN 2 WHEN 'MEDIA' THEN 3 ELSE 4 END,a.target_date,a.created_at DESC LIMIT ? OFFSET ?`).all(...params,dateKey,pageSize,offset).map((r)=>mapAction(r,dateKey));
  const total=Number(db.prepare(`SELECT COUNT(*) AS n ${from} WHERE ${where.join(' AND ')}`).get(...params).n||0);
  return {page,pageSize,total,rows,timeZone:getSetting('locale.timezone','America/Argentina/Buenos_Aires'),today:dateKey};
}
function getAction(id,user){requirePermission(user,'Actions.Read');const db=getDb();const row=assertActionScope(db,user,getActionRow(db,id));return {...mapAction(row),relations:db.prepare('SELECT * FROM management_action_relation WHERE action_id=? ORDER BY created_at').all(id),evidence:db.prepare(`SELECT ae.*,fe.filename,fe.mime_type,fe.size,fe.sha256 FROM management_action_evidence ae LEFT JOIN file_evidence fe ON fe.id=ae.evidence_id WHERE ae.action_id=? ORDER BY ae.created_at`).all(id),events:db.prepare('SELECT * FROM management_action_event WHERE action_id=? ORDER BY occurred_at').all(id)};}
function normalizeAssignee(db,input,current={}){
  const assignedPersonId=input.assignedPersonId===undefined?(current.assigned_person_id||null):(input.assignedPersonId||null);
  const assignedRoleId=input.assignedRoleId===undefined?(current.assigned_role_id||null):(input.assignedRoleId||null);
  const assignedSector=input.assignedSector===undefined?(current.assigned_sector||null):optionalString(input.assignedSector,'assignedSector',{max:120});
  if(!assignedPersonId&&!assignedRoleId&&!assignedSector)throw actionError('La acción requiere una persona, rol o sector responsable.','ACTION_ASSIGNEE_REQUIRED');
  if(assignedPersonId&&!db.prepare("SELECT 1 FROM person WHERE id=? AND deleted_at IS NULL AND status='ACTIVA'").get(assignedPersonId))throw actionError('Persona responsable inexistente o inactiva.','PERSON_INVALID');
  if(assignedRoleId&&!db.prepare('SELECT 1 FROM role WHERE id=? AND active=1').get(assignedRoleId))throw actionError('Rol responsable inexistente o inactivo.','ROLE_INVALID');
  return {assignedPersonId,assignedRoleId,assignedSector};
}
function insertRelations(db,actionId,relations,userId,now){
  if(!Array.isArray(relations))return;
  const stmt=db.prepare('INSERT OR IGNORE INTO management_action_relation(id,action_id,entity_type,entity_id,label,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?)');
  for(const item of relations.slice(0,100)){
    const type=String(item.entityType||'OTHER').toUpperCase(); if(!RELATION_TYPES.has(type))throw actionError('Tipo de relación inválido.','ACTION_RELATION_INVALID');
    stmt.run(randomUUID(),actionId,type,item.entityId||null,requiredString(item.label||type,'relationLabel',{min:1,max:240}),userId,now);
  }
}
function createActionInDb(db,input,context){
  const scope=normalizeScope(db,context.user,'Actions.Create',input.siteId||null,input.locationId||null,true); const assignee=normalizeAssignee(db,input);
  const cause=String(input.causeCode||'PENDIENTE_ANALISIS').toUpperCase(); if(!CAUSES.has(cause))throw actionError('Causa inválida.','ACTION_CAUSE_INVALID');
  const priority=String(input.priority||'MEDIA').toUpperCase();if(!PRIORITIES.has(priority))throw actionError('Prioridad inválida.','ACTION_PRIORITY_INVALID');
  const indicator=input.indicatorCode||null;if(indicator&&!db.prepare('SELECT 1 FROM management_indicator_definition WHERE code=? AND active=1').get(indicator))throw actionError('Indicador inexistente.','INDICATOR_INVALID');
  const id=randomUUID(),now=nowIso(),code=actionCode(db);const targetDate=isoDate(input.targetDate,'targetDate');
  db.prepare(`INSERT INTO management_action(id,code,organization_id,scope_type,site_id,location_id,title,problem,cause_code,cause_detail,action_text,expected_result,indicator_code,priority,assigned_person_id,assigned_role_id,assigned_sector,responsible_manager_person_id,verifier_person_id,target_date,status,progress_percent,source_meeting_id,created_by_user_id,updated_by_user_id,version,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?,?,1,?,?)`).run(id,code,scope.organizationId,scope.scopeType,scope.siteId,scope.locationId,requiredString(input.title,'title',{min:3,max:180}),requiredString(input.problem,'problem',{min:3,max:2000}),cause,optionalString(input.causeDetail,'causeDetail',{max:2000}),requiredString(input.actionText,'actionText',{min:3,max:2000}),requiredString(input.expectedResult,'expectedResult',{min:3,max:2000}),indicator,priority,assignee.assignedPersonId,assignee.assignedRoleId,assignee.assignedSector,input.responsibleManagerPersonId||null,input.verifierPersonId||null,targetDate,'PENDIENTE',0,input.sourceMeetingId||null,context.user.id,context.user.id,now,now);
  const relations=[...(Array.isArray(input.relations)?input.relations:[])];if(indicator)relations.push({entityType:'INDICATOR',entityId:indicator,label:`Indicador ${indicator}`});insertRelations(db,id,relations,context.user.id,now);
  event(db,id,'CREACION',context,'Acción creada.',null,'PENDIENTE',{code});const after=getActionRow(db,id);audit(db,context,'ACTION.CREATE','management_action',id,null,after);return mapAction(after);
}
function createAction(input,context){requirePermission(context.user,'Actions.Create');return transaction((db)=>createActionInDb(db,input,context));}
function canEditOwnAction(user,row,db){if(!hasActionScope(db,user,row,'Actions.EditOwn'))return false;const personId=userPersonId(user,db);return row.created_by_user_id===user.id||row.assigned_person_id===personId;}
function updateAction(id,input,context){return transaction((db)=>{
  const current=getActionRow(db,id);if(!current)throw actionError('Acción no encontrada.','ACTION_NOT_FOUND',404);if(current.status==='CERRADA')throw actionError('Una acción cerrada no se edita. Registre una corrección o nueva acción.','ACTION_CLOSED',409);
  const expected=Number(input.version);if(!Number.isInteger(expected)||expected!==current.version)throw actionError('La acción fue modificada por otra operación.','CONCURRENCY_CONFLICT',409);
  const changingAssignment=input.assignedPersonId!==undefined||input.assignedRoleId!==undefined||input.assignedSector!==undefined;
  if(changingAssignment){requirePermission(context.user,'Actions.Assign');assertActionScope(db,context.user,current,'Actions.Assign');}
  else if(!hasActionScope(db,context.user,current,'Actions.Assign')){requirePermission(context.user,'Actions.EditOwn');assertActionScope(db,context.user,current,'Actions.EditOwn');if(!canEditOwnAction(context.user,current,db))throw actionError('No puede editar esta acción.','FORBIDDEN',403);}
  const assignee=normalizeAssignee(db,input,current);const status=String(input.status??current.status).toUpperCase();if(!ACTION_STATUSES.has(status)||status==='CERRADA')throw actionError('Use el cierre controlado para cerrar la acción.','ACTION_STATUS_INVALID');
  const priority=String(input.priority??current.priority).toUpperCase();if(!PRIORITIES.has(priority))throw actionError('Prioridad inválida.','ACTION_PRIORITY_INVALID');const cause=String(input.causeCode??current.cause_code).toUpperCase();if(!CAUSES.has(cause))throw actionError('Causa inválida.','ACTION_CAUSE_INVALID');
  const progress=safeInteger(input.progressPercent,current.progress_percent,0,99);const target=isoDate(input.targetDate??current.target_date,'targetDate');const now=nowIso();
  const result=db.prepare(`UPDATE management_action SET title=?,problem=?,cause_code=?,cause_detail=?,action_text=?,expected_result=?,priority=?,assigned_person_id=?,assigned_role_id=?,assigned_sector=?,responsible_manager_person_id=?,verifier_person_id=?,target_date=?,status=?,progress_percent=?,updated_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=?`).run(requiredString(input.title??current.title,'title',{min:3,max:180}),requiredString(input.problem??current.problem,'problem',{min:3,max:2000}),cause,optionalString(input.causeDetail??current.cause_detail,'causeDetail',{max:2000}),requiredString(input.actionText??current.action_text,'actionText',{min:3,max:2000}),requiredString(input.expectedResult??current.expected_result,'expectedResult',{min:3,max:2000}),priority,assignee.assignedPersonId,assignee.assignedRoleId,assignee.assignedSector,input.responsibleManagerPersonId===undefined?current.responsible_manager_person_id:(input.responsibleManagerPersonId||null),input.verifierPersonId===undefined?current.verifier_person_id:(input.verifierPersonId||null),target,status,progress,context.user.id,now,id,expected);
  if(result.changes!==1)throw actionError('Conflicto de concurrencia.','CONCURRENCY_CONFLICT',409);insertRelations(db,id,input.relations,context.user.id,now);event(db,id,changingAssignment?'ASIGNACION':status!==current.status?'CAMBIO_ESTADO':'ACTUALIZACION',context,changingAssignment?'Responsable actualizado.':'Acción actualizada.',current.status,status);const after=getActionRow(db,id);audit(db,context,'ACTION.UPDATE','management_action',id,current,after);return mapAction(after);
});}
function addActionEvidence(id,input,context){
  requirePermission(context.user,'Actions.EditOwn');
  const db=getDb();
  const row=assertActionScope(db,context.user,getActionRow(db,id),'Actions.EditOwn');
  if(row.status==='CERRADA')throw actionError('No se agrega evidencia a una acción cerrada.','ACTION_CLOSED',409);
  if(!canEditOwnAction(context.user,row,db))throw actionError('No puede agregar evidencia.','FORBIDDEN',403);
  const type=String(input.evidenceType||(input.dataUrl?'FILE':'NOTE')).toUpperCase();
  if(!EVIDENCE_TYPES.has(type))throw actionError('Tipo de evidencia inválido.','EVIDENCE_TYPE_INVALID');
  const persist=(tx,file=null)=>{
    const now=nowIso(),evidenceId=file?.id||null;
    const ref=type==='FILE'?null:requiredString(input.referenceValue,'referenceValue',{min:2,max:2000});
    const linkId=randomUUID();
    tx.prepare('INSERT INTO management_action_evidence(id,action_id,evidence_id,evidence_type,description,reference_value,added_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(linkId,id,evidenceId,type,optionalString(input.description,'description',{max:1000}),ref,context.user.id,now);
    event(tx,id,'EVIDENCIA',context,`Evidencia ${type} agregada.`,row.status,row.status,{evidenceId,linkId});
    audit(tx,context,'ACTION.EVIDENCE','management_action_evidence',linkId,null,{actionId:id,evidenceId,type,referenceValue:ref});
    return tx.prepare(`SELECT ae.*,fe.filename,fe.mime_type,fe.size,fe.sha256 FROM management_action_evidence ae LEFT JOIN file_evidence fe ON fe.id=ae.evidence_id WHERE ae.id=?`).get(linkId);
  };
  if(type==='FILE'){
    return saveOwnedEvidenceDataUrl(
      {dataUrl:input.dataUrl,originalFilename:input.originalFilename},
      {ownerType:'MANAGEMENT_ACTION',ownerId:id,purpose:'ACTION_EVIDENCE'},
      context,
      {allowedMimeTypes:['image/png','image/jpeg','image/webp','application/pdf','text/plain','text/csv','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']},
      persist
    );
  }
  return transaction((tx)=>persist(tx,null));
}
function closeAction(id,input,context){
  requirePermission(context.user,'Actions.Close');
  return transaction((db)=>{
    const current=assertActionScope(db,context.user,getActionRow(db,id),'Actions.Close');
    if(current.status==='CERRADA')return {...mapAction(current),idempotent:true};
    const expected=Number(input.version);
    if(!Number.isInteger(expected)||expected!==current.version)throw actionError('La acción fue modificada por otra operación.','CONCURRENCY_CONFLICT',409);
    const resultText=requiredString(input.actualResult,'actualResult',{min:3,max:3000});
    const evidenceCount=Number(db.prepare('SELECT COUNT(*) AS n FROM management_action_evidence WHERE action_id=?').get(id).n||0);
    const justification=optionalString(input.noEvidenceJustification,'noEvidenceJustification',{max:2000});
    if(!evidenceCount&&!justification)throw actionError('Para cerrar, adjunte evidencia o justifique por qué no existe.','ACTION_EVIDENCE_REQUIRED');
    if(current.verifier_person_id&&current.verifier_person_id!==userPersonId(context.user,db)&&!hasPermission(context.user,'Actions.VerifyClosure'))throw actionError('El cierre debe verificarlo la persona indicada o un usuario autorizado.','ACTION_VERIFIER_REQUIRED',403);
    const now=nowIso();
    const result=db.prepare(`UPDATE management_action SET status='CERRADA',progress_percent=100,actual_result=?,no_evidence_justification=?,closed_at=?,closed_by_user_id=?,updated_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status<>'CERRADA'`)
      .run(resultText,justification,now,context.user.id,context.user.id,now,id,expected);
    if(result.changes!==1)throw actionError('Conflicto al cerrar la acción.','CONCURRENCY_CONFLICT',409);
    event(db,id,'CIERRE',context,'Acción cerrada con resultado registrado.',current.status,'CERRADA',{evidenceCount,justification:Boolean(justification)});
    const linkedDecisions=db.prepare(`SELECT d.*,m.status AS meeting_status FROM management_meeting_decision d
      JOIN management_meeting m ON m.id=d.meeting_id
      WHERE d.action_id=?`).all(id).filter((decision)=>hydrateDecision(db,decision).status==='PENDIENTE');
    for(const decision of linkedDecisions){
      const note=`Acción ${current.code} cerrada con resultado verificado.`;
      if(decision.meeting_status==='CERRADA'){
        appendDecisionLifecycleEvent(db,decision,'EXECUTED','EJECUTADA',id,note,context);
      }else{
        const before={...decision};
        db.prepare("UPDATE management_meeting_decision SET status='EJECUTADA',resolved_at=?,resolved_by_user_id=?,resolution_note=?,updated_at=? WHERE id=? AND status='PENDIENTE'")
          .run(now,context.user.id,note,now,decision.id);
        const after=db.prepare('SELECT * FROM management_meeting_decision WHERE id=?').get(decision.id);
        audit(db,context,'MEETING.DECISION_EXECUTED','management_meeting_decision',decision.id,before,after,'Acción vinculada cerrada.');
      }
    }
    const after=getActionRow(db,id);
    audit(db,context,'ACTION.CLOSE','management_action',id,current,after);
    return mapAction(after);
  });
}
function createActionFromIndicator(input,context){const indicator=requiredString(input.indicatorCode,'indicatorCode',{min:2,max:100});return createAction({...input,indicatorCode:indicator,relations:[...(input.relations||[]),{entityType:'INDICATOR',entityId:indicator,label:`Indicador ${indicator}`} ]},context);}
function listActionAlerts(user,input={}){requirePermission(user,'Actions.Read');const result=listActions(user,{...input,pageSize:250});const upcomingDays=safeInteger(input.upcomingDays,3,0,30);const alerts=[];const db=getDb();for(const row of result.rows){let type=null;if(row.effective_status==='VENCIDA')type='VENCIDA';else if(row.status!=='CERRADA'&&row.days_remaining<=upcomingDays)type='PROXIMA';else if(!row.assigned_person_id&&!row.assigned_role_id&&!row.assigned_sector)type='SIN_RESPONSABLE';if(!type)continue;alerts.push({type,action:row});if(row.assigned_person_id){const recipient=db.prepare('SELECT id FROM user_account WHERE person_id=? AND active=1 AND deleted_at IS NULL').get(row.assigned_person_id);if(recipient)enqueueNotification({recipientUserId:recipient.id,type:'SISTEMA',subject:type==='VENCIDA'?'Acción vencida':'Acción próxima a vencer',body:`${row.code}: ${row.title}. Vence ${row.target_date}.`,entityType:'MANAGEMENT_ACTION',entityId:row.id,dedupKey:`ACTION:${row.id}:${type}:${row.target_date}`},db);}}
  return {generatedAt:nowIso(),upcomingDays,total:alerts.length,alerts};}
function agendaScopeWhere(db,user,permission,alias,input){const global=permissionAssignments(user,permission,db).some((s)=>!s.site_id&&!s.location_id);const scope=scopeWhere(user,permission,`${alias}.site_id`,`${alias}.location_id`,db);const clauses=[global?`(${alias}.site_id IS NULL OR ${scope.sql})`:`(${scope.sql})`];const params=[...scope.params];if(input.siteId){clauses.push(`${alias}.site_id=?`);params.push(input.siteId);}if(input.locationId){clauses.push(`${alias}.location_id=?`);params.push(input.locationId);}return {sql:clauses.join(' AND '),params};}
function weeklyAgenda(user,input={}){requirePermission(user,'Meetings.Create');const db=getDb();const dateTo=isoDate(input.dateTo||todayKey(),'dateTo');const dateFrom=isoDate(input.dateFrom||new Date(Date.parse(`${dateTo}T00:00:00Z`)-6*86400000).toISOString(),'dateFrom');const topics=[];const add=(topicType,sourceType,sourceId,title,detail)=>topics.push({topicType,sourceType,sourceId,title,detail,sortOrder:topics.length+1});
  // Indicadores: último snapshot por indicador y alcance.
  if(hasPermission(user,'Management.Read')){const sc=agendaScopeWhere(db,user,'Management.Read','x',input);const rows=db.prepare(`SELECT x.* FROM management_indicator_snapshot x JOIN (SELECT indicator_id,scope_type,IFNULL(site_id,'') s,IFNULL(location_id,'') l,MAX(measured_at) m FROM management_indicator_snapshot GROUP BY indicator_id,scope_type,IFNULL(site_id,''),IFNULL(location_id,'')) z ON z.indicator_id=x.indicator_id AND z.scope_type=x.scope_type AND z.s=IFNULL(x.site_id,'') AND z.l=IFNULL(x.location_id,'') AND z.m=x.measured_at WHERE (${sc.sql}) AND x.status IN ('ATENCION','URGENTE') ORDER BY CASE x.status WHEN 'URGENTE' THEN 1 ELSE 2 END`).all(...sc.params);for(const r of rows)add(r.status==='URGENTE'?'ACCION_REQUERIDA':'DECISION_REQUERIDA','INDICATOR',r.indicator_id,`Indicador ${r.status}`,`Valor ${r.value===null?'sin datos':r.value}; objetivo ${r.target_value}; período ${r.period_start} a ${r.period_end}.`);}
  if(hasPermission(user,'Requests.ReadAll')){const sc=agendaScopeWhere(db,user,'Requests.ReadAll','r',input);const rows=db.prepare(`SELECT id,request_number,status,needed_at FROM request r WHERE ${sc.sql} AND r.status NOT IN ('BORRADOR','EXPIRADA','CANCELADA','ENTREGADA') AND r.needed_at<? ORDER BY r.needed_at LIMIT 100`).all(...sc.params,`${dateTo}T23:59:59.999Z`);for(const r of rows)add('ACCION_REQUERIDA','REQUEST',r.id,`Solicitud atrasada ${r.request_number}`,`Estado ${r.status}; requerida ${r.needed_at}.`);}
  if(hasPermission(user,'Custody.ReadAll')){const scope=scopeWhere(user,'Custody.ReadAll','r.site_id','r.location_id',db);const extra=[];const params=[...scope.params,`${dateTo}T23:59:59.999Z`];if(input.siteId){extra.push('r.site_id=?');params.push(input.siteId);}if(input.locationId){extra.push('r.location_id=?');params.push(input.locationId);}const rows=db.prepare(`SELECT c.id,c.due_at,a.internal_code,p.full_name FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id WHERE (${scope.sql}) ${extra.length?'AND '+extra.join(' AND '):''} AND c.status NOT IN ('CERRADA','DEVOLUCION_DECLARADA') AND c.due_at IS NOT NULL AND c.due_at<? ORDER BY c.due_at LIMIT 100`).all(...params);for(const r of rows)add('ACCION_REQUERIDA','CUSTODY',r.id,`Devolución vencida ${r.internal_code}`,`${r.full_name}; venció ${r.due_at}.`);}
  if(hasPermission(user,'Incident.Read')){const scope=scopeWhere(user,'Incident.Read','sl.site_id','a.location_id',db);const extra=[];const params=[...scope.params];if(input.siteId){extra.push('sl.site_id=?');params.push(input.siteId);}if(input.locationId){extra.push('a.location_id=?');params.push(input.locationId);}const rows=db.prepare(`SELECT i.id,i.incident_number,i.title,i.severity,i.status FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE (${scope.sql}) ${extra.length?'AND '+extra.join(' AND '):''} AND i.status IN ('ABIERTO','EN_INVESTIGACION') ORDER BY CASE i.severity WHEN 'CRITICA' THEN 1 WHEN 'ALTA' THEN 2 ELSE 3 END LIMIT 100`).all(...params);for(const r of rows)add(r.severity==='CRITICA'||r.severity==='ALTA'?'ACCION_REQUERIDA':'DECISION_REQUERIDA','INCIDENT',r.id,`Incidente ${r.incident_number}`,`${r.title}; gravedad ${r.severity}; estado ${r.status}.`);}
  if(hasPermission(user,'Maintenance.Read')){const scope=scopeWhere(user,'Maintenance.Read','sl.site_id','a.location_id',db);const extra=[];const params=[...scope.params,`${dateTo}T23:59:59.999Z`];if(input.siteId){extra.push('sl.site_id=?');params.push(input.siteId);}if(input.locationId){extra.push('a.location_id=?');params.push(input.locationId);}const rows=db.prepare(`SELECT mo.id,mo.order_number,mo.status,mo.due_at,a.internal_code FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE (${scope.sql}) ${extra.length?'AND '+extra.join(' AND '):''} AND mo.status NOT IN ('COMPLETADA','CANCELADA') AND mo.due_at IS NOT NULL AND mo.due_at<? ORDER BY mo.due_at LIMIT 100`).all(...params);for(const r of rows)add('ACCION_REQUERIDA','MAINTENANCE',r.id,`Mantenimiento vencido ${r.order_number}`,`${r.internal_code}; vence/venció ${r.due_at}; estado ${r.status}.`);}
  if(hasPermission(user,'Stock.Read')){const scope=scopeWhere(user,'Stock.Read','sl.site_id','a.location_id',db);const extra=[];const params=[...scope.params];if(input.siteId){extra.push('sl.site_id=?');params.push(input.siteId);}if(input.locationId){extra.push('a.location_id=?');params.push(input.locationId);}const rows=db.prepare(`SELECT a.id,a.internal_code,a.description,a.quantity_available FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE (${scope.sql}) ${extra.length?'AND '+extra.join(' AND '):''} AND a.deleted_at IS NULL AND a.active=1 AND a.quantity_available<=0 ORDER BY a.internal_code LIMIT 100`).all(...params);for(const r of rows)add('ACCION_REQUERIDA','ASSET',r.id,`Stock crítico ${r.internal_code}`,`${r.description}; disponibilidad ${r.quantity_available}.`);}
  if(hasPermission(user,'Finance.Read')){const scope=scopeWhere(user,'Finance.Read','b.site_id','b.location_id',db);const extra=[];const extraParams=[];if(input.siteId){extra.push('b.site_id=?');extraParams.push(input.siteId);}if(input.locationId){extra.push('b.location_id=?');extraParams.push(input.locationId);}const rows=db.prepare(`SELECT b.id,b.name,b.currency_code,b.approved_amount_minor,COALESCE((SELECT SUM(c.sign*c.amount_minor) FROM economic_cost_record c WHERE c.budget_id=b.id AND c.status='EJECUTADO' AND c.occurred_on BETWEEN ? AND ?),0) executed FROM economic_budget b WHERE (${scope.sql}) ${extra.length?'AND '+extra.join(' AND '):''} AND b.status='ACTIVO'`).all(dateFrom,dateTo,...scope.params,...extraParams);for(const r of rows)if(r.approved_amount_minor>0&&r.executed>r.approved_amount_minor)add('DECISION_REQUERIDA','BUDGET',r.id,`Presupuesto desviado ${r.name}`,`Ejecutado supera aprobado en ${r.currency_code}.`);}
  const actionScope=agendaScopeWhere(db,user,'Actions.Read','a',input);const overdue=db.prepare(`SELECT id,code,title,target_date FROM management_action a WHERE ${actionScope.sql} AND a.status<>'CERRADA' AND a.target_date<? ORDER BY a.target_date LIMIT 100`).all(...actionScope.params,dateTo);for(const r of overdue)add('ACCION_REQUERIDA','ACTION',r.id,`Acción vencida ${r.code}`,`${r.title}; fecha objetivo ${r.target_date}.`);
  const decisionScope=agendaScopeWhere(db,user,'Meetings.Minutes.Read','m',input);const pending=db.prepare(`SELECT d.id,d.decision_text,d.target_date,m.code FROM management_meeting_decision d JOIN management_meeting m ON m.id=d.meeting_id WHERE ${decisionScope.sql} AND COALESCE((SELECT e.to_status FROM management_meeting_decision_event e WHERE e.decision_id=d.id ORDER BY e.occurred_at DESC,e.rowid DESC LIMIT 1),d.status)='PENDIENTE' ORDER BY COALESCE(d.target_date,'9999-12-31') LIMIT 100`).all(...decisionScope.params);for(const r of pending)add('DECISION_REQUERIDA','DECISION',r.id,`Decisión pendiente ${r.code}`,r.decision_text);
  return {generatedAt:nowIso(),meetingType:'SEMANAL',period:{dateFrom,dateTo},scope:{siteId:input.siteId||null,locationId:input.locationId||null},summary:{information:topics.filter((x)=>x.topicType==='INFORMACION').length,decisions:topics.filter((x)=>x.topicType==='DECISION_REQUERIDA').length,actions:topics.filter((x)=>x.topicType==='ACCION_REQUERIDA').length,total:topics.length},topics};
}
function monthlyAgenda(user,input={}){requirePermission(user,'Meetings.Create');const dateTo=isoDate(input.dateTo||todayKey(),'dateTo');const defaultFrom=`${dateTo.slice(0,7)}-01`;const base=weeklyAgenda(user,{...input,dateFrom:input.dateFrom||defaultFrom,dateTo});const db=getDb();const actionScope=agendaScopeWhere(db,user,'Actions.Read','a',input);const closed=db.prepare(`SELECT COUNT(*) AS n FROM management_action a WHERE ${actionScope.sql} AND a.status='CERRADA' AND substr(a.closed_at,1,10) BETWEEN ? AND ?`).get(...actionScope.params,base.period.dateFrom,base.period.dateTo).n;const open=db.prepare(`SELECT COUNT(*) AS n FROM management_action a WHERE ${actionScope.sql} AND a.status<>'CERRADA'`).get(...actionScope.params).n;const overdue=db.prepare(`SELECT COUNT(*) AS n FROM management_action a WHERE ${actionScope.sql} AND a.status<>'CERRADA' AND a.target_date<?`).get(...actionScope.params,dateTo).n;const previousEnd=new Date(Date.parse(`${base.period.dateFrom}T00:00:00Z`)-86400000).toISOString().slice(0,10);const days=Math.max(1,Math.round((Date.parse(`${base.period.dateTo}T00:00:00Z`)-Date.parse(`${base.period.dateFrom}T00:00:00Z`))/86400000)+1);const previousFrom=new Date(Date.parse(`${previousEnd}T00:00:00Z`)-(days-1)*86400000).toISOString().slice(0,10);const previousClosed=db.prepare(`SELECT COUNT(*) AS n FROM management_action a WHERE ${actionScope.sql} AND a.status='CERRADA' AND substr(a.closed_at,1,10) BETWEEN ? AND ?`).get(...actionScope.params,previousFrom,previousEnd).n;return {...base,meetingType:'MENSUAL',comparison:{current:{closed:Number(closed),open:Number(open),overdue:Number(overdue)},previous:{dateFrom:previousFrom,dateTo:previousEnd,closed:Number(previousClosed)},closedChange:Number(closed)-Number(previousClosed)},executiveSummary:`Acciones cerradas: ${closed}. Abiertas: ${open}. Vencidas: ${overdue}. Temas prioritarios: ${base.summary.total}.`};}
function meetingCode(db,type,date){const prefix=`${type==='SEMANAL'?'SEM':'MEN'}-${date.slice(0,4)}`;const count=Number(db.prepare('SELECT COUNT(*) AS n FROM management_meeting WHERE code LIKE ?').get(`${prefix}-%`).n||0)+1;return `${prefix}-${String(count).padStart(4,'0')}`;}
function getMeetingRow(db,id){return db.prepare(`SELECT m.*,s.name AS site_name,l.name AS location_name,cp.full_name AS created_by_name,xp.full_name AS closed_by_name FROM management_meeting m LEFT JOIN site s ON s.id=m.site_id LEFT JOIN storage_location l ON l.id=m.location_id LEFT JOIN user_account cu ON cu.id=m.created_by_user_id LEFT JOIN person cp ON cp.id=cu.person_id LEFT JOIN user_account xu ON xu.id=m.closed_by_user_id LEFT JOIN person xp ON xp.id=xu.person_id WHERE m.id=?`).get(id);}
function assertMeetingScope(db,user,row,permission='Meetings.Minutes.Read'){if(!row)throw actionError('Reunión no encontrada.','MEETING_NOT_FOUND',404);if(row.scope_type==='GLOBAL'){if(!permissionAssignments(user,permission,db).some((s)=>!s.site_id&&!s.location_id))throw actionError('Reunión fuera del alcance asignado.','SCOPE_FORBIDDEN',403);}else if(!userHasScope(user,row.site_id,row.location_id,permission,db))throw actionError('Reunión fuera del alcance asignado.','SCOPE_FORBIDDEN',403);return row;}
function listMeetings(user,input={}){requirePermission(user,'Meetings.Minutes.Read');const db=getDb(),{page,pageSize,offset}=pagination(input);const scope=scopeWhere(user,'Meetings.Minutes.Read','m.site_id','m.location_id',db);const global=permissionAssignments(user,'Meetings.Minutes.Read',db).some((s)=>!s.site_id&&!s.location_id);const where=[global?`(m.scope_type='GLOBAL' OR ${scope.sql})`:`(${scope.sql})`],params=[...scope.params];if(input.type){where.push('m.meeting_type=?');params.push(String(input.type).toUpperCase());}if(input.status){where.push('m.status=?');params.push(String(input.status).toUpperCase());}if(input.siteId){where.push('m.site_id=?');params.push(input.siteId);}if(input.locationId){where.push('m.location_id=?');params.push(input.locationId);}const rows=db.prepare(`SELECT m.*,s.name AS site_name,l.name AS location_name FROM management_meeting m LEFT JOIN site s ON s.id=m.site_id LEFT JOIN storage_location l ON l.id=m.location_id WHERE ${where.join(' AND ')} ORDER BY m.meeting_date DESC,m.created_at DESC LIMIT ? OFFSET ?`).all(...params,pageSize,offset);const total=db.prepare(`SELECT COUNT(*) AS n FROM management_meeting m WHERE ${where.join(' AND ')}`).get(...params).n;return{page,pageSize,total,rows};}
function addParticipantRows(db,meetingId,participants,userId,now){if(!Array.isArray(participants))return;const stmt=db.prepare('INSERT OR IGNORE INTO management_meeting_participant(id,meeting_id,person_id,display_name,role_in_meeting,attended,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?)');for(const p of participants.slice(0,100)){let name=p.displayName;if(p.personId){const person=db.prepare('SELECT full_name FROM person WHERE id=? AND deleted_at IS NULL').get(p.personId);if(!person)throw actionError('Participante inexistente.','PERSON_INVALID');name=name||person.full_name;}stmt.run(randomUUID(),meetingId,p.personId||null,requiredString(name,'displayName',{min:2,max:180}),optionalString(p.roleInMeeting,'roleInMeeting',{max:120}),p.attended===false?0:1,userId,now);}}
function addTopicRows(db,meetingId,topics,userId,now){if(!Array.isArray(topics))return;const stmt=db.prepare('INSERT INTO management_meeting_topic(id,meeting_id,topic_type,source_type,source_id,title,detail,sort_order,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)');let order=Number(db.prepare('SELECT COALESCE(MAX(sort_order),0) AS n FROM management_meeting_topic WHERE meeting_id=?').get(meetingId).n||0);for(const t of topics.slice(0,250)){const type=String(t.topicType||'INFORMACION').toUpperCase();if(!TOPIC_TYPES.has(type))throw actionError('Tipo de tema inválido.','MEETING_TOPIC_INVALID');order++;stmt.run(randomUUID(),meetingId,type,optionalString(t.sourceType,'sourceType',{max:80}),t.sourceId||null,requiredString(t.title,'topicTitle',{min:2,max:240}),requiredString(t.detail,'topicDetail',{min:2,max:3000}),Number.isInteger(t.sortOrder)?t.sortOrder:order,userId,now);}}
function createMeeting(input,context){requirePermission(context.user,'Meetings.Create');const type=String(input.meetingType||'SEMANAL').toUpperCase();if(!MEETING_TYPES.has(type))throw actionError('Tipo de reunión inválido.','MEETING_TYPE_INVALID');const agenda=type==='SEMANAL'?weeklyAgenda(context.user,input):monthlyAgenda(context.user,input);return transaction((db)=>{const scope=normalizeScope(db,context.user,'Meetings.Create',input.siteId||null,input.locationId||null,true);const date=isoDate(input.meetingDate||todayKey(),'meetingDate'),id=randomUUID(),now=nowIso(),code=meetingCode(db,type,date);db.prepare(`INSERT INTO management_meeting(id,code,organization_id,scope_type,site_id,location_id,meeting_type,title,meeting_date,period_from,period_to,status,executive_summary,observations,agenda_snapshot_json,created_by_user_id,updated_by_user_id,version,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,'BORRADOR',?,?,?,?,?,1,?,?)`).run(id,code,scope.organizationId,scope.scopeType,scope.siteId,scope.locationId,type,requiredString(input.title||`${type==='SEMANAL'?'Reunión semanal del pañol':'Revisión mensual de gestión'}`,'title',{min:3,max:180}),date,agenda.period.dateFrom,agenda.period.dateTo,optionalString(input.executiveSummary||agenda.executiveSummary,'executiveSummary',{max:5000}),optionalString(input.observations,'observations',{max:5000}),JSON.stringify(agenda),context.user.id,context.user.id,now,now);addParticipantRows(db,id,input.participants,context.user.id,now);const agendaTopics=(input.topics||agenda.topics||[]);addTopicRows(db,id,agendaTopics.length?agendaTopics:[{topicType:'INFORMACION',sourceType:'SYSTEM',title:'Sin desvíos pendientes',detail:'La agenda automática no encontró desvíos para el alcance y período seleccionados.'}],context.user.id,now);const after=getMeetingRow(db,id);audit(db,context,'MEETING.CREATE','management_meeting',id,null,after);return after;});}
function getMeeting(id,user){
  requirePermission(user,'Meetings.Minutes.Read');
  const db=getDb();
  const row=assertMeetingScope(db,user,getMeetingRow(db,id));
  const decisions=db.prepare(`SELECT d.*,p.full_name AS responsible_person_name,r.name AS responsible_role_name
    FROM management_meeting_decision d
    LEFT JOIN person p ON p.id=d.responsible_person_id
    LEFT JOIN role r ON r.id=d.responsible_role_id
    WHERE d.meeting_id=? ORDER BY d.created_at`).all(id).map((decision)=>hydrateDecision(db,decision));
  return{
    ...row,
    participants:db.prepare('SELECT * FROM management_meeting_participant WHERE meeting_id=? ORDER BY display_name,id').all(id),
    topics:db.prepare('SELECT * FROM management_meeting_topic WHERE meeting_id=? ORDER BY sort_order,created_at,id').all(id),
    decisions,
    corrections:db.prepare('SELECT * FROM management_meeting_correction WHERE meeting_id=? ORDER BY created_at').all(id)
  };
}
function updateMeeting(id,input,context){requirePermission(context.user,'Meetings.Create');return transaction((db)=>{const current=assertMeetingScope(db,context.user,getMeetingRow(db,id),'Meetings.Create');if(current.status==='CERRADA')throw actionError('El acta cerrada no puede editarse silenciosamente.','MEETING_CLOSED',409);const expected=Number(input.version);if(!Number.isInteger(expected)||expected!==current.version)throw actionError('La reunión fue modificada por otra operación.','CONCURRENCY_CONFLICT',409);const now=nowIso();db.prepare(`UPDATE management_meeting SET title=?,meeting_date=?,period_from=?,period_to=?,executive_summary=?,observations=?,updated_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=?`).run(requiredString(input.title??current.title,'title',{min:3,max:180}),isoDate(input.meetingDate??current.meeting_date,'meetingDate'),isoDate(input.periodFrom??current.period_from,'periodFrom'),isoDate(input.periodTo??current.period_to,'periodTo'),optionalString(input.executiveSummary??current.executive_summary,'executiveSummary',{max:5000}),optionalString(input.observations??current.observations,'observations',{max:5000}),context.user.id,now,id,expected);addParticipantRows(db,id,input.participants,context.user.id,now);addTopicRows(db,id,input.topics,context.user.id,now);const after=getMeetingRow(db,id);audit(db,context,'MEETING.UPDATE','management_meeting',id,current,after);return after;});}
function addMeetingDecision(id,input,context){requirePermission(context.user,'Meetings.Create');return transaction((db)=>{const meeting=assertMeetingScope(db,context.user,getMeetingRow(db,id),'Meetings.Create');if(meeting.status==='CERRADA')throw actionError('No se agregan decisiones a un acta cerrada.','MEETING_CLOSED',409);const person=input.responsiblePersonId||null,role=input.responsibleRoleId||null,sector=optionalString(input.responsibleSector,'responsibleSector',{max:120});if(!person&&!role&&!sector)throw actionError('La decisión requiere responsable.','DECISION_RESPONSIBLE_REQUIRED');const decisionId=randomUUID(),now=nowIso();db.prepare(`INSERT INTO management_meeting_decision(id,meeting_id,decision_text,responsible_person_id,responsible_role_id,responsible_sector,target_date,status,created_by_user_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,'PENDIENTE',?,?,?)`).run(decisionId,id,requiredString(input.decisionText,'decisionText',{min:3,max:3000}),person,role,sector,input.targetDate?isoDate(input.targetDate,'targetDate'):null,context.user.id,now,now);const after=db.prepare('SELECT * FROM management_meeting_decision WHERE id=?').get(decisionId);audit(db,context,'MEETING.DECISION_CREATE','management_meeting_decision',decisionId,null,after);return after;});}
function createActionFromDecision(meetingId,decisionId,input,context){requirePermission(context.user,'Actions.Create');return transaction((db)=>{const meeting=assertMeetingScope(db,context.user,getMeetingRow(db,meetingId),'Meetings.Create');if(meeting.status==='CERRADA')throw actionError('No se crean acciones nuevas modificando un acta cerrada.','MEETING_CLOSED',409);const decision=db.prepare('SELECT * FROM management_meeting_decision WHERE id=? AND meeting_id=?').get(decisionId,meetingId);if(!decision)throw actionError('Decisión no encontrada.','DECISION_NOT_FOUND',404);if(decision.action_id){const existing=assertActionScope(db,context.user,getActionRow(db,decision.action_id),'Actions.Read');return mapAction(existing);}const action=createActionInDb(db,{siteId:meeting.site_id,locationId:meeting.location_id,title:input.title||`Acción por ${meeting.code}`,problem:input.problem||decision.decision_text,causeCode:input.causeCode||'PENDIENTE_ANALISIS',actionText:input.actionText||decision.decision_text,expectedResult:input.expectedResult||'Decisión ejecutada y resultado verificado.',priority:input.priority||'MEDIA',assignedPersonId:input.assignedPersonId||decision.responsible_person_id,assignedRoleId:input.assignedRoleId||decision.responsible_role_id,assignedSector:input.assignedSector||decision.responsible_sector,targetDate:input.targetDate||decision.target_date||meeting.period_to,sourceMeetingId:meetingId,relations:[{entityType:'OTHER',entityId:decisionId,label:`Decisión ${meeting.code}`} ]},context);const changed=db.prepare('UPDATE management_meeting_decision SET action_id=?,updated_at=? WHERE id=? AND action_id IS NULL').run(action.id,nowIso(),decisionId);if(changed.changes!==1)throw actionError('La decisión ya fue vinculada por otra operación.','CONCURRENCY_CONFLICT',409);const after=db.prepare('SELECT * FROM management_meeting_decision WHERE id=?').get(decisionId);audit(db,context,'MEETING.DECISION_ACTION','management_meeting_decision',decisionId,decision,after);return action;});}
function resolveMeetingDecision(meetingId,decisionId,input,context){
  requirePermission(context.user,'Meetings.Close');
  return transaction((db)=>{
    const meeting=assertMeetingScope(db,context.user,getMeetingRow(db,meetingId),'Meetings.Close');
    const original=db.prepare('SELECT * FROM management_meeting_decision WHERE id=? AND meeting_id=?').get(decisionId,meetingId);
    if(!original)throw actionError('Decisión no encontrada.','DECISION_NOT_FOUND',404);
    const current=hydrateDecision(db,original);
    const status=String(input.status||'').toUpperCase();
    if(!['EJECUTADA','CANCELADA'].includes(status))throw actionError('Estado de resolución inválido.','DECISION_STATUS_INVALID');
    if(current.status===status)return{...current,idempotent:true};
    if(current.status!=='PENDIENTE')throw actionError('La decisión ya fue resuelta.','DECISION_ALREADY_RESOLVED',409);
    const note=requiredString(input.resolutionNote,'resolutionNote',{min:3,max:2000});
    if(status==='EJECUTADA'&&current.action_id){
      const linked=db.prepare('SELECT status FROM management_action WHERE id=?').get(current.action_id);
      if(!linked||linked.status!=='CERRADA')throw actionError('La acción vinculada debe estar cerrada antes de ejecutar la decisión.','DECISION_ACTION_OPEN',409);
    }
    if(meeting.status==='CERRADA'){
      return appendDecisionLifecycleEvent(db,original,status==='EJECUTADA'?'EXECUTED':'CANCELLED',status,current.action_id,note,context);
    }
    const now=nowIso();
    const changed=db.prepare("UPDATE management_meeting_decision SET status=?,resolved_at=?,resolved_by_user_id=?,resolution_note=?,updated_at=? WHERE id=? AND status='PENDIENTE'")
      .run(status,now,context.user.id,note,now,decisionId);
    if(changed.changes!==1)throw actionError('La decisión fue modificada por otra operación.','CONCURRENCY_CONFLICT',409);
    const after=db.prepare('SELECT * FROM management_meeting_decision WHERE id=?').get(decisionId);
    audit(db,context,status==='EJECUTADA'?'MEETING.DECISION_EXECUTED':'MEETING.DECISION_CANCELLED','management_meeting_decision',decisionId,original,after,note);
    return hydrateDecision(db,after);
  });
}
function meetingSnapshot(db,id,version=2,overrides={}){
  const meeting=getMeetingRow(db,id);
  if(Number(version)===1){
    const participants=db.prepare('SELECT person_id,display_name,role_in_meeting,attended FROM management_meeting_participant WHERE meeting_id=? ORDER BY display_name,id').all(id);
    const topics=db.prepare('SELECT topic_type,source_type,source_id,title,detail,sort_order FROM management_meeting_topic WHERE meeting_id=? ORDER BY sort_order,created_at,id').all(id);
    const decisions=db.prepare('SELECT decision_text,responsible_person_id,responsible_role_id,responsible_sector,target_date,status,action_id FROM management_meeting_decision WHERE meeting_id=? ORDER BY created_at,id').all(id);
    return{meeting:{id:meeting.id,code:meeting.code,meetingType:meeting.meeting_type,title:meeting.title,meetingDate:meeting.meeting_date,periodFrom:meeting.period_from,periodTo:meeting.period_to,executiveSummary:overrides.executiveSummary??meeting.executive_summary,observations:overrides.observations??meeting.observations,scopeType:meeting.scope_type,siteId:meeting.site_id,locationId:meeting.location_id},participants,topics,decisions};
  }
  const participants=db.prepare(`SELECT id,person_id,display_name,role_in_meeting,attended,created_by_user_id,created_at
    FROM management_meeting_participant WHERE meeting_id=? ORDER BY display_name,id`).all(id);
  const topics=db.prepare(`SELECT id,topic_type,source_type,source_id,title,detail,sort_order,created_by_user_id,created_at
    FROM management_meeting_topic WHERE meeting_id=? ORDER BY sort_order,created_at,id`).all(id);
  const decisions=db.prepare(`SELECT id,decision_text,responsible_person_id,responsible_role_id,responsible_sector,target_date,status,action_id,created_by_user_id,created_at
    FROM management_meeting_decision WHERE meeting_id=? ORDER BY created_at,id`).all(id);
  return{
    snapshotVersion:2,
    meeting:{
      id:meeting.id,code:meeting.code,organizationId:meeting.organization_id,scopeType:meeting.scope_type,
      siteId:meeting.site_id,locationId:meeting.location_id,meetingType:meeting.meeting_type,title:meeting.title,
      meetingDate:meeting.meeting_date,periodFrom:meeting.period_from,periodTo:meeting.period_to,
      status:overrides.status??meeting.status,executiveSummary:overrides.executiveSummary??meeting.executive_summary,
      observations:overrides.observations??meeting.observations,createdByUserId:meeting.created_by_user_id,
      createdAt:meeting.created_at,closedByUserId:overrides.closedByUserId??meeting.closed_by_user_id,
      closedAt:overrides.closedAt??meeting.closed_at
    },
    participants,topics,decisions
  };
}
function closeMeeting(id,input,context){
  requirePermission(context.user,'Meetings.Close');
  return transaction((db)=>{
    const current=assertMeetingScope(db,context.user,getMeetingRow(db,id),'Meetings.Close');
    if(current.status==='CERRADA')return{...current,idempotent:true};
    const expected=Number(input.version);
    if(!Number.isInteger(expected)||expected!==current.version)throw actionError('La reunión fue modificada por otra operación.','CONCURRENCY_CONFLICT',409);
    const participants=db.prepare('SELECT COUNT(*) AS n FROM management_meeting_participant WHERE meeting_id=?').get(id).n;
    const topics=db.prepare('SELECT COUNT(*) AS n FROM management_meeting_topic WHERE meeting_id=?').get(id).n;
    if(!participants||!topics)throw actionError('Para cerrar, registre participantes y temas revisados.','MEETING_INCOMPLETE');
    const finalSummary=optionalString(input.executiveSummary??current.executive_summary,'executiveSummary',{max:5000});
    const finalObservations=optionalString(input.observations??current.observations,'observations',{max:5000});
    const now=nowIso();
    const snapshot=meetingSnapshot(db,id,2,{executiveSummary:finalSummary,observations:finalObservations,status:'CERRADA',closedAt:now,closedByUserId:context.user.id});
    const snapshotJson=stableJson(snapshot);
    const hash=sha256(snapshotJson);
    const result=db.prepare(`UPDATE management_meeting SET status='CERRADA',executive_summary=?,observations=?,integrity_hash=?,integrity_snapshot_json=?,integrity_snapshot_version=2,closed_at=?,closed_by_user_id=?,updated_by_user_id=?,version=version+1,updated_at=? WHERE id=? AND version=? AND status='BORRADOR'`)
      .run(finalSummary,finalObservations,hash,snapshotJson,now,context.user.id,context.user.id,now,id,expected);
    if(result.changes!==1)throw actionError('Conflicto al cerrar la reunión.','CONCURRENCY_CONFLICT',409);
    const after=getMeetingRow(db,id);
    audit(db,context,'MEETING.CLOSE','management_meeting',id,current,after);
    return{...after,integrityVerified:after.integrity_hash===hash};
  });
}
function correctClosedMeeting(id,input,context){requirePermission(context.user,'Meetings.Close');return transaction((db)=>{const meeting=assertMeetingScope(db,context.user,getMeetingRow(db,id),'Meetings.Close');if(meeting.status!=='CERRADA'||!meeting.integrity_hash)throw actionError('Solo se corrigen actas cerradas.','MEETING_NOT_CLOSED');const reason=requiredString(input.reason,'reason',{min:3,max:1000}),text=requiredString(input.correctionText,'correctionText',{min:3,max:3000}),now=nowIso(),correctionId=randomUUID();const latest=db.prepare('SELECT correction_hash FROM management_meeting_correction WHERE meeting_id=? ORDER BY rowid DESC LIMIT 1').get(id);const previous=latest?.correction_hash||meeting.integrity_hash;const correctionHash=sha256(stableJson({meetingId:id,previousHash:previous,reason,correctionText:text,createdBy:context.user.id,createdAt:now}));db.prepare('INSERT INTO management_meeting_correction(id,meeting_id,reason,correction_text,previous_hash,correction_hash,created_by_user_id,created_at) VALUES (?,?,?,?,?,?,?,?)').run(correctionId,id,reason,text,previous,correctionHash,context.user.id,now);const after=db.prepare('SELECT * FROM management_meeting_correction WHERE id=?').get(correctionId);audit(db,context,'MEETING.CORRECTION','management_meeting_correction',correctionId,null,after,reason);return after;});}
function meetingMinutes(id,user){
  const data=getMeeting(id,user);
  const db=getDb();
  const snapshotVersion=Number(data.integrity_snapshot_version||1);
  let snapshotJson=data.integrity_snapshot_json||null;
  if(!snapshotJson)snapshotJson=stableJson(meetingSnapshot(db,id,snapshotVersion));
  let originalSnapshot=null,originalRecalculated=null,storedSnapshotVerified=null,liveRecalculated=null,liveContentVerified=null,originalVerified=null;
  try{
    originalSnapshot=JSON.parse(snapshotJson);
    originalRecalculated=sha256(snapshotJson);
    storedSnapshotVerified=data.status==='CERRADA'?data.integrity_hash===originalRecalculated:null;
    if(data.status==='CERRADA'&&snapshotVersion>=2){
      liveRecalculated=sha256(stableJson(meetingSnapshot(db,id,snapshotVersion)));
      liveContentVerified=data.integrity_hash===liveRecalculated;
    }
    originalVerified=data.status==='CERRADA'?Boolean(storedSnapshotVerified&&(snapshotVersion<2||liveContentVerified)):null;
  }catch{originalVerified=false;storedSnapshotVerified=false;if(snapshotVersion>=2)liveContentVerified=false;}
  let correctionPrevious=data.integrity_hash||null;
  const correctionChecks=[];
  for(const correction of data.corrections){
    const expected=sha256(stableJson({meetingId:id,previousHash:correctionPrevious,reason:correction.reason,correctionText:correction.correction_text,createdBy:correction.created_by_user_id,createdAt:correction.created_at}));
    const verified=correction.previous_hash===correctionPrevious&&correction.correction_hash===expected;
    correctionChecks.push({id:correction.id,previousHash:correction.previous_hash,expectedPreviousHash:correctionPrevious,storedHash:correction.correction_hash,recalculatedHash:expected,verified});
    correctionPrevious=correction.correction_hash;
  }
  const correctionsVerified=correctionChecks.every((item)=>item.verified);
  const lifecycleRows=db.prepare('SELECT * FROM management_meeting_decision_event WHERE meeting_id=? ORDER BY occurred_at,rowid').all(id);
  let lifecyclePrevious=data.integrity_hash||null;
  const lifecycleChecks=[];
  for(const item of lifecycleRows){
    const expected=sha256(stableJson({meetingId:item.meeting_id,decisionId:item.decision_id,eventType:item.event_type,fromStatus:item.from_status,toStatus:item.to_status,actionId:item.action_id,resolutionNote:item.resolution_note,actorUserId:item.actor_user_id,occurredAt:item.occurred_at,previousHash:lifecyclePrevious}));
    const verified=item.previous_hash===lifecyclePrevious&&item.event_hash===expected;
    lifecycleChecks.push({id:item.id,decisionId:item.decision_id,previousHash:item.previous_hash,expectedPreviousHash:lifecyclePrevious,storedHash:item.event_hash,recalculatedHash:expected,verified});
    lifecyclePrevious=item.event_hash;
  }
  const lifecycleVerified=lifecycleChecks.every((item)=>item.verified);
  const totalVerified=data.status==='CERRADA'?Boolean(originalVerified&&correctionsVerified&&lifecycleVerified):null;
  const decisionLifecycle=data.decisions.map((decision)=>({id:decision.id,decisionText:decision.decision_text,status:decision.status,actionId:decision.action_id,actionCode:decision.action_code,resolvedAt:decision.resolved_at,resolvedByUserId:decision.resolved_by_user_id,resolutionNote:decision.resolution_note,events:decision.lifecycle_events}));
  return{
    ...data,
    integrity:{
      scope:'ACTA_ORIGINAL_CORRECCIONES_Y_LIFECYCLE',
      lifecycleExcluded:false,
      storedHash:data.integrity_hash||null,
      recalculatedHash:originalRecalculated,
      verified:totalVerified,
      original:{snapshotVersion,storedHash:data.integrity_hash||null,recalculatedHash:originalRecalculated,storedSnapshotVerified,liveRecalculatedHash:liveRecalculated,liveContentVerified,verified:originalVerified,snapshotAvailable:Boolean(originalSnapshot)},
      corrections:{count:correctionChecks.length,verified:correctionsVerified,items:correctionChecks,effectiveHash:correctionPrevious},
      lifecycle:{count:lifecycleChecks.length,verified:lifecycleVerified,items:lifecycleChecks,effectiveHash:lifecyclePrevious},
      effectiveHash:sha256(stableJson({original:data.integrity_hash||null,corrections:correctionPrevious,lifecycle:lifecyclePrevious}))
    },
    decisionLifecycle,
    printable:{title:originalSnapshot?.meeting?.title||data.title,code:originalSnapshot?.meeting?.code||data.code,date:originalSnapshot?.meeting?.meetingDate||data.meeting_date,period:originalSnapshot?.meeting?`${originalSnapshot.meeting.periodFrom} a ${originalSnapshot.meeting.periodTo}`:`${data.period_from} a ${data.period_to}`,participants:originalSnapshot?.participants?.map((p)=>p.display_name)||data.participants.map((p)=>p.display_name),information:(originalSnapshot?.topics||data.topics).filter((t)=>(t.topic_type||t.topicType)==='INFORMACION'),decisions:originalSnapshot?.decisions||data.decisions,actions:(originalSnapshot?.topics||data.topics).filter((t)=>(t.topic_type||t.topicType)==='ACCION_REQUERIDA'),observations:originalSnapshot?.meeting?.observations??data.observations}
  };
}


module.exports={getActionOptions,listActions,getAction,createAction,updateAction,addActionEvidence,closeAction,createActionFromIndicator,listActionAlerts,weeklyAgenda,monthlyAgenda,listMeetings,createMeeting,getMeeting,updateMeeting,addMeetingDecision,createActionFromDecision,resolveMeetingDecision,closeMeeting,correctClosedMeeting,meetingMinutes,effectiveStatus};
