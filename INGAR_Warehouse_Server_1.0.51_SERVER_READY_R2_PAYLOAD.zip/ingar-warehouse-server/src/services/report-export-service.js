'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb } = require('../db/database');
const { appendAudit } = require('./audit-service');
const { hasPermission } = require('./permission-service');
const { createXlsx } = require('./spreadsheet-service');
const { createReportPdf } = require('./report-pdf-service');
const { reportForUser, normalizeRequest, recordExecution, CATEGORY_DEFINITIONS } = require('./report-service');

const FORMAT_CONFIG = Object.freeze({
  CSV: { permission: 'Reports.ExportCsv', extension: 'csv', mimeType: 'text/csv; charset=utf-8', maxRows: 50000 },
  XLSX: { permission: 'Reports.ExportExcel', extension: 'xlsx', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', maxRows: 25000 },
  PDF: { permission: 'Reports.ExportPdf', extension: 'pdf', mimeType: 'application/pdf', maxRows: 5000 }
});

function exportError(message, code = 'REPORT_EXPORT_INVALID', status = 422) {
  return Object.assign(new Error(message), { code, status });
}

function safeFilenamePart(value, max = 64) {
  return String(value || 'informe').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, max) || 'informe';
}

function csvCell(value) {
  let text = value === null || value === undefined ? '' : String(value);
  if (/^[\s]*[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

function formatDateTime(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat('es-AR', { dateStyle: 'short', timeStyle: 'medium', timeZone: 'UTC' }).format(date);
}

function formatCell(column, value) {
  if (value === null || value === undefined) return '';
  if (column.type === 'datetime') return formatDateTime(value);
  if (column.type === 'boolean') return value ? 'Sí' : 'No';
  if (column.type === 'number') return Number.isFinite(Number(value)) ? Number(value) : String(value);
  return String(value);
}

function filterDisplay(report, filters, db) {
  const values = [];
  for (const key of report.filters) {
    const value = filters[key];
    if (!value) continue;
    let display = value;
    if (key === 'dateFrom' || key === 'dateTo') display = String(value).slice(0, 10).split('-').reverse().join('/');
    if (key === 'siteId') display = db.prepare('SELECT code || \' · \' || name AS label FROM site WHERE id=?').get(value)?.label || value;
    if (key === 'locationId') display = db.prepare('SELECT code || \' · \' || name AS label FROM storage_location WHERE id=?').get(value)?.label || value;
    if (key === 'categoryId') display = db.prepare('SELECT code || \' · \' || name AS label FROM asset_category WHERE id=?').get(value)?.label || value;
    const label = ({ dateFrom: 'Desde', dateTo: 'Hasta', siteId: 'Sede', locationId: 'Ubicación', categoryId: 'Categoría', status: 'Estado', search: 'Buscar' })[key] || key;
    values.push(`${label}: ${display}`);
  }
  return values.join(' · ') || 'Sin filtros';
}

function exportMetadata(db, report, request, context, exportId, generatedAt) {
  const user = db.prepare('SELECT p.full_name, ua.username FROM user_account ua JOIN person p ON p.id=ua.person_id WHERE ua.id=?').get(context.user.id);
  const site = request.filters.siteId ? db.prepare('SELECT s.name, o.name AS organization_name FROM site s JOIN organization o ON o.id=s.organization_id WHERE s.id=?').get(request.filters.siteId) : null;
  const location = request.filters.locationId ? db.prepare('SELECT name FROM storage_location WHERE id=?').get(request.filters.locationId) : null;
  return {
    exportId,
    generatedAt,
    generatedAtText: formatDateTime(generatedAt),
    generatedBy: user?.full_name || user?.username || context.user.id,
    organizationName: site?.organization_name || null,
    siteName: site?.name || null,
    locationName: location?.name || null,
    categoryName: CATEGORY_DEFINITIONS.find((item) => item.code === report.category)?.name || report.category,
    filtersText: filterDisplay(report, request.filters, db)
  };
}

function collectRows(db, report, user, request, maxRows) {
  const first = report.execute(db, user, { ...request, page: 1, pageSize: 100 });
  if (first.total > maxRows) throw exportError(`El informe contiene ${first.total} registros y supera el máximo de ${maxRows} para este formato.`, 'REPORT_EXPORT_TOO_LARGE');
  const rows = [...first.rows];
  for (let page = 2; rows.length < first.total; page += 1) {
    const next = report.execute(db, user, { ...request, page, pageSize: 100 });
    rows.push(...next.rows);
    if (!next.rows.length) break;
  }
  return { rows, total: first.total };
}

function reportMatrix(report, rows, metadata) {
  const matrix = [
    ['INGAR Warehouse Controller'],
    ['Informe', report.name],
    ['Código', report.code],
    ['Categoría', metadata.categoryName],
    ['Generado', metadata.generatedAtText],
    ['Usuario', metadata.generatedBy],
    ['Organización', metadata.organizationName || '—'],
    ['Sede', metadata.siteName || 'Todas'],
    ['Ubicación', metadata.locationName || 'Todas'],
    ['Filtros', metadata.filtersText],
    ['Registros', rows.length],
    [],
    report.columns.map((column) => column.label)
  ];
  for (const row of rows) matrix.push(report.columns.map((column) => formatCell(column, row[column.key])));
  return matrix;
}

function createCsv(report, rows, metadata) {
  const matrix = reportMatrix(report, rows, metadata);
  const content = matrix.map((row) => row.map(csvCell).join(';')).join('\r\n');
  return Buffer.from(`\uFEFFsep=;\r\n${content}\r\n`, 'utf8');
}

function createWorkbook(report, rows, metadata) {
  const matrix = reportMatrix(report, rows, metadata);
  const headerRow = 13;
  return createXlsx(matrix, {
    sheetName: safeFilenamePart(report.name, 28),
    titleRow: 1,
    metadataRows: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    headerRow,
    freezeRow: headerRow,
    autoFilter: true,
    columnWidths: report.columns.map((column) => Math.min(42, Math.max(12, column.label.length + 4)))
  });
}

function recordExport(db, { id, executionId, report, request, context, format, filename, bytes, sha256, status, durationMs, errorCode = null }) {
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO report_export(id,report_execution_id,report_code,report_name,format,filename,mime_type,row_count,byte_size,sha256,generated_by_user_id,site_id,location_id,generated_at,status,duration_ms,error_code,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, executionId || null, report.code, report.name, format, filename || null, FORMAT_CONFIG[format].mimeType,
      bytes?.rowCount || 0, bytes?.length || 0, sha256 || null, context.user.id, request.filters.siteId || null, request.filters.locationId || null,
      now, status, durationMs, errorCode, context.correlationId || null, now);
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action: 'REPORT.EXPORT',
    entityType: 'report_export',
    entityId: id,
    after: { reportCode: report.code, format, filename, rowCount: bytes?.rowCount || 0, byteSize: bytes?.length || 0, sha256, filters: request.filters },
    correlationId: context.correlationId,
    ipAddress: context.ip,
    equipment: context.userAgent,
    result: status,
    durationMs,
    error: errorCode
  }, db);
}

function exportReport(code, formatInput, input, context) {
  const format = String(formatInput || '').toUpperCase();
  const config = FORMAT_CONFIG[format];
  if (!config) throw exportError('Formato de exportación no soportado.', 'REPORT_EXPORT_FORMAT_INVALID', 404);
  if (!hasPermission(context.user, config.permission)) throw exportError('Permiso insuficiente para exportar en este formato.', 'FORBIDDEN', 403);
  const report = reportForUser(code, context.user);
  const request = normalizeRequest({ filters: input?.filters || {}, page: 1, pageSize: 100 }, report.filters);
  const orientation = String(input?.options?.orientation || 'AUTO').toUpperCase();
  if (!['AUTO', 'PORTRAIT', 'LANDSCAPE'].includes(orientation)) throw exportError('Orientación PDF inválida.', 'REPORT_EXPORT_ORIENTATION_INVALID');
  const db = getDb();
  const started = Date.now();
  const exportId = randomUUID();
  const generatedAt = new Date().toISOString();
  let executionId = null;
  try {
    const collected = collectRows(db, report, context.user, request, config.maxRows);
    const executionResult = { rows: collected.rows, total: collected.total };
    executionId = recordExecution(db, { report, request, context, result: executionResult, status: 'SUCCESS', durationMs: Date.now() - started });
    const metadata = exportMetadata(db, report, request, context, exportId, generatedAt);
    let buffer;
    if (format === 'CSV') buffer = createCsv(report, collected.rows, metadata);
    else if (format === 'XLSX') buffer = createWorkbook(report, collected.rows, metadata);
    else buffer = createReportPdf({ report, rows: collected.rows.map((row) => Object.fromEntries(report.columns.map((column) => [column.key, formatCell(column, row[column.key])]))), metadata, orientation });
    const timestamp = generatedAt.replace(/[-:]/g, '').slice(0, 15).replace('T', '-');
    const filename = `ingar-${safeFilenamePart(report.code)}-${timestamp}.${config.extension}`;
    const sha256 = createHash('sha256').update(buffer).digest('hex');
    Object.defineProperties(buffer, { rowCount: { value: collected.rows.length }, exportId: { value: exportId }, executionId: { value: executionId }, filename: { value: filename }, mimeType: { value: config.mimeType }, sha256: { value: sha256 } });
    recordExport(db, { id: exportId, executionId, report, request, context, format, filename, bytes: buffer, sha256, status: 'SUCCESS', durationMs: Date.now() - started });
    return { bytes: buffer, filename, mimeType: config.mimeType, sha256, exportId, executionId, rowCount: collected.rows.length };
  } catch (error) {
    try {
      recordExport(db, { id: exportId, executionId, report, request, context, format, filename: null, bytes: null, sha256: null, status: 'FAILED', durationMs: Date.now() - started, errorCode: error.code || 'REPORT_EXPORT_FAILED' });
    } catch {}
    throw error;
  }
}

module.exports = { exportReport, FORMAT_CONFIG, createCsv, reportMatrix };
