'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, optionalString, requiredArray } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const { claimEvidence } = require('./evidence-service');
const { userHasScope } = require('./request-service');
const { assertOperationAllowed } = require('./incident-service');
const { syncCustodyOperationalAlerts } = require('./custody-alert-service');
const { syncRequestOperationalAlert } = require('./request-alert-service');
const { assertKitOperationallyComplete } = require('./kit-operational-control-service');
const { issueKitComponentsInDb } = require('./extended-modules-service');

const SERIAL_NATURES = new Set(['SERIADO', 'KIT', 'VEHICULO']);

function error(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function requireScope(user, siteId, locationId, permission) {
  if (!userHasScope(user, siteId, locationId, permission)) throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
}

function positive(value, field = 'quantity') {
  const number = Number(value);
  if (!Number.isFinite(number) || number <= 0) throw error(422, 'QUANTITY_INVALID', 'Cantidad inválida.', [{ field, message: 'Debe ser mayor que cero.' }]);
  return number;
}

function parseIso(value, field, required = false) {
  if ((value === null || value === undefined || value === '') && !required) return null;
  const parsed = new Date(value);
  if (!Number.isFinite(parsed.getTime())) throw error(422, 'DATE_INVALID', `Fecha inválida: ${field}.`, [{ field, message: 'Fecha y hora inválidas.' }]);
  return parsed.toISOString();
}

function addRequestEvent(db, requestId, fromStatus, toStatus, actorUserId, reason, correlationId, now) {
  db.prepare(`INSERT INTO request_status_event(id, request_id, from_status, to_status, actor_user_id, reason, occurred_at, correlation_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(randomUUID(), requestId, fromStatus, toStatus, actorUserId, reason || null, now, correlationId, now);
}

function loadRequest(db, id) {
  return db.prepare(`SELECT r.*, p.full_name AS requester_name, sl.site_id, sl.code AS location_code, s.code AS site_code
    FROM request r JOIN person p ON p.id=r.requester_person_id JOIN storage_location sl ON sl.id=r.location_id JOIN site s ON s.id=sl.site_id
    WHERE r.id=?`).get(id);
}

function loadRequestItems(db, requestId) {
  return db.prepare(`SELECT ri.*, a.category_id, a.internal_code, a.location_id, a.status AS asset_status, a.quantity_available,
      a.version AS asset_version, c.nature AS category_nature, c.requires_return, c.requires_inspection
    FROM request_item ri JOIN asset a ON a.id=ri.asset_id JOIN asset_category c ON c.id=a.category_id
    WHERE ri.request_id=? ORDER BY ri.created_at`).all(requestId);
}

function loadAsset(db, assetId) {
  return db.prepare(`SELECT a.*, c.nature AS category_nature, c.requires_return, c.requires_inspection, sl.site_id
    FROM asset a JOIN asset_category c ON c.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
    WHERE a.id=? AND a.deleted_at IS NULL AND c.deleted_at IS NULL`).get(assetId);
}

function restoreReservationAsset(db, reservation, asset, now) {
  if (SERIAL_NATURES.has(asset.category_nature)) {
    const changed = db.prepare(`UPDATE asset SET status='DISPONIBLE', quantity_available=1, version=version+1, updated_at=?
      WHERE id=? AND status='RESERVADO'`).run(now, asset.id);
    if (changed.changes !== 1) throw error(409, 'PREPARATION_RESERVATION_CONFLICT', `No fue posible liberar ${asset.internal_code}.`);
  } else {
    const changed = db.prepare(`UPDATE asset SET quantity_available=quantity_available+?, status='DISPONIBLE', version=version+1, updated_at=?
      WHERE id=? AND quantity_available+?<=quantity_total`).run(reservation.quantity, now, asset.id, reservation.quantity);
    if (changed.changes !== 1) throw error(409, 'PREPARATION_RESERVATION_CONFLICT', `No fue posible liberar stock de ${asset.internal_code}.`);
  }
}

function reserveReplacementAsset(db, asset, amount, now) {
  if (asset.category_nature === 'KIT') assertKitOperationallyComplete(db, asset.id, 'sustitución durante la preparación');
  if (!asset.active || asset.deleted_at || asset.status !== 'DISPONIBLE' || asset.quantity_available < amount) {
    throw error(409, 'SUBSTITUTE_NOT_AVAILABLE', `El bien sustituto ${asset.internal_code} no está disponible.`);
  }
  if (SERIAL_NATURES.has(asset.category_nature)) {
    if (amount !== 1) throw error(422, 'SERIAL_QUANTITY_INVALID', 'Un bien seriado requiere cantidad 1.');
    const changed = db.prepare(`UPDATE asset SET status='RESERVADO', quantity_available=0, version=version+1, updated_at=?
      WHERE id=? AND version=? AND status='DISPONIBLE' AND quantity_available>=1`).run(now, asset.id, asset.version);
    if (changed.changes !== 1) throw error(409, 'SUBSTITUTE_RESERVATION_CONFLICT', `Conflicto al reservar ${asset.internal_code}.`);
  } else {
    const remaining = asset.quantity_available - amount;
    const changed = db.prepare(`UPDATE asset SET quantity_available=?, status=?, version=version+1, updated_at=?
      WHERE id=? AND version=? AND status='DISPONIBLE' AND quantity_available>=?`).run(remaining, remaining > 0 ? 'DISPONIBLE' : 'RESERVADO', now, asset.id, asset.version, amount);
    if (changed.changes !== 1) throw error(409, 'SUBSTITUTE_RESERVATION_CONFLICT', `Conflicto al reservar ${asset.internal_code}.`);
  }
}

function getPreparation(requestId, user = null, permission = 'Warehouse.Prepare') {
  const db = getDb();
  if (user) { const request = loadRequest(db, requestId); if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.'); requireScope(user, request.site_id, request.location_id, permission); }
  const preparation = db.prepare(`SELECT rp.*, ua.username, p.full_name AS operator_name
    FROM request_preparation rp JOIN user_account ua ON ua.id=rp.operator_user_id JOIN person p ON p.id=ua.person_id
    WHERE rp.request_id=?`).get(requestId);
  if (!preparation) return null;
  return {
    ...preparation,
    items: db.prepare(`SELECT rpi.*, ria.internal_code AS requested_code, ria.description AS requested_description,
        pa.internal_code AS prepared_code, pa.description AS prepared_description, c.nature AS category_nature
      FROM request_preparation_item rpi
      JOIN asset ria ON ria.id=rpi.requested_asset_id JOIN asset pa ON pa.id=rpi.prepared_asset_id
      JOIN asset_category c ON c.id=pa.category_id
      WHERE rpi.preparation_id=? ORDER BY ria.internal_code`).all(preparation.id)
  };
}

function prepareRequest(requestId, input, context) {
  return transaction((db) => {
    const request = loadRequest(db, requestId);
    if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
    requireScope(context.user, request.site_id, request.location_id, 'Warehouse.Prepare');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== request.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La solicitud fue modificada por otra operación.');
    if (request.status !== 'APROBADA') throw error(409, 'REQUEST_NOT_PREPARABLE', 'La solicitud debe estar aprobada para prepararse.');
    if (db.prepare('SELECT 1 FROM request_preparation WHERE request_id=?').get(requestId)) throw error(409, 'PREPARATION_ALREADY_EXISTS', 'La solicitud ya posee preparación.');
    const requestItems = loadRequestItems(db, requestId);
    const supplied = requiredArray(input.items, 'items', 100);
    if (supplied.length !== requestItems.length) throw error(422, 'PREPARATION_ITEMS_INCOMPLETE', 'Debe preparar todos los ítems de la solicitud.');
    const suppliedById = new Map(supplied.map((item) => [requiredString(item.requestItemId, 'requestItemId', { min: 8, max: 80 }), item]));
    if (suppliedById.size !== supplied.length) throw error(422, 'PREPARATION_ITEM_DUPLICATE', 'Un ítem de solicitud no puede repetirse.');
    const now = new Date().toISOString();
    const preparationId = randomUUID();
    db.prepare(`INSERT INTO request_preparation(id,request_id,operator_user_id,status,observations,prepared_at,version,created_at,updated_at,work_order_reference_snapshot)
      VALUES (?,?,?,'EN_PREPARACION',?,?,1,?,?,?)`).run(preparationId, requestId, context.user.id, optionalString(input.observations, 'observations', 1500), now, now, now, request.work_order_reference);
    for (const requestItem of requestItems) {
      const selected = suppliedById.get(requestItem.id);
      if (!selected) throw error(422, 'PREPARATION_ITEM_MISSING', `Falta preparar ${requestItem.internal_code}.`);
      const amount = positive(selected.quantity ?? requestItem.quantity);
      if (amount !== requestItem.quantity) throw error(422, 'PREPARATION_QUANTITY_MISMATCH', `La cantidad preparada de ${requestItem.internal_code} debe coincidir con la solicitada.`);
      const reservation = db.prepare(`SELECT * FROM asset_reservation WHERE request_item_id=? AND status='ACTIVA'`).get(requestItem.id);
      if (!reservation) throw error(409, 'RESERVATION_NOT_ACTIVE', `La reserva de ${requestItem.internal_code} no está activa.`);
      const preparedAssetId = selected.preparedAssetId || requestItem.asset_id;
      let preparedAsset = loadAsset(db, preparedAssetId);
      if (!preparedAsset || preparedAsset.category_id !== requestItem.category_id || preparedAsset.location_id !== request.location_id) {
        throw error(422, 'SUBSTITUTE_NOT_EQUIVALENT', `El sustituto de ${requestItem.internal_code} debe pertenecer a la misma categoría y ubicación.`);
      }
      if (preparedAsset.category_nature === 'KIT') assertKitOperationallyComplete(db, preparedAsset.id, 'preparación');
      assertOperationAllowed(db, { personId: request.requester_person_id, asset: preparedAsset, operationType: request.operation_type,
        siteId: request.site_id, locationId: request.location_id, requestId });
      let status = 'PREPARADO';
      let substitutionReason = null;
      if (preparedAssetId !== requestItem.asset_id) {
        substitutionReason = requiredString(selected.substitutionReason, 'substitutionReason', { min: 5, max: 1000 });
        const requestedAsset = loadAsset(db, requestItem.asset_id);
        restoreReservationAsset(db, reservation, requestedAsset, now);
        reserveReplacementAsset(db, preparedAsset, amount, now);
        db.prepare('UPDATE asset_reservation SET asset_id=?, updated_at=? WHERE id=? AND status=\'ACTIVA\'').run(preparedAssetId, now, reservation.id);
        status = 'SUSTITUIDO';
        preparedAsset = loadAsset(db, preparedAssetId);
      }
      const condition = String(selected.condition || 'CONFORME').toUpperCase();
      if (!['CONFORME', 'OBSERVADO'].includes(condition)) throw error(422, 'PREPARATION_CONDITION_INVALID', 'Condición de preparación inválida.');
      const notes = optionalString(selected.notes, 'notes', 1500);
      if (condition === 'OBSERVADO' && !notes) throw error(422, 'PREPARATION_NOTES_REQUIRED', 'Una observación requiere detalle.');
      db.prepare(`INSERT INTO request_preparation_item(id,preparation_id,request_item_id,requested_asset_id,prepared_asset_id,quantity,status,condition,substitution_reason,notes,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(randomUUID(), preparationId, requestItem.id, requestItem.asset_id, preparedAsset.id, amount, status, condition, substitutionReason, notes, now, now);
    }
    const changed = db.prepare(`UPDATE request SET status='PREPARANDO',version=version+1,updated_at=? WHERE id=? AND version=? AND status='APROBADA'`).run(now, requestId, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al iniciar preparación.');
    addRequestEvent(db, requestId, 'APROBADA', 'PREPARANDO', context.user.id, 'Preparación física iniciada.', context.correlationId, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.PREPARE', entityType: 'request', entityId: requestId,
      before: { status: 'APROBADA' }, after: { status: 'PREPARANDO', itemCount: requestItems.length }, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return getPreparationFromDb(db, requestId);
  });
}

function getPreparationFromDb(db, requestId) {
  const preparation = db.prepare(`SELECT rp.*, ua.username, p.full_name AS operator_name
    FROM request_preparation rp JOIN user_account ua ON ua.id=rp.operator_user_id JOIN person p ON p.id=ua.person_id
    WHERE rp.request_id=?`).get(requestId);
  if (!preparation) return null;
  preparation.items = db.prepare(`SELECT rpi.*, ria.internal_code AS requested_code, ria.description AS requested_description,
      pa.internal_code AS prepared_code, pa.description AS prepared_description, c.nature AS category_nature
    FROM request_preparation_item rpi JOIN asset ria ON ria.id=rpi.requested_asset_id JOIN asset pa ON pa.id=rpi.prepared_asset_id
    JOIN asset_category c ON c.id=pa.category_id WHERE rpi.preparation_id=? ORDER BY ria.internal_code`).all(preparation.id);
  return preparation;
}

function markRequestReady(requestId, input, context) {
  return transaction((db) => {
    const request = loadRequest(db, requestId);
    if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
    requireScope(context.user, request.site_id, request.location_id, 'Warehouse.Prepare');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== request.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La solicitud fue modificada por otra operación.');
    if (request.status !== 'PREPARANDO') throw error(409, 'REQUEST_NOT_PREPARING', 'La solicitud no está en preparación.');
    const preparation = db.prepare('SELECT * FROM request_preparation WHERE request_id=?').get(requestId);
    if (!preparation || preparation.status !== 'EN_PREPARACION') throw error(409, 'PREPARATION_NOT_OPEN', 'La preparación no está abierta.');
    const preparationVersion = Number(input.preparationVersion);
    if (!Number.isInteger(preparationVersion) || preparationVersion !== preparation.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La preparación fue modificada por otra operación.');
    const expected = db.prepare('SELECT COUNT(*) AS n FROM request_item WHERE request_id=?').get(requestId).n;
    const prepared = db.prepare('SELECT COUNT(*) AS n FROM request_preparation_item WHERE preparation_id=?').get(preparation.id).n;
    if (expected !== prepared) throw error(422, 'PREPARATION_ITEMS_INCOMPLETE', 'La preparación no contiene todos los ítems.');
    const preparedAssets = db.prepare(`SELECT a.*,ac.nature AS category_nature,sl.site_id FROM request_preparation_item rpi
      JOIN asset a ON a.id=rpi.prepared_asset_id JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
      WHERE rpi.preparation_id=?`).all(preparation.id);
    for (const asset of preparedAssets) {
      if (asset.category_nature === 'KIT') assertKitOperationallyComplete(db, asset.id, 'cierre de preparación');
      assertOperationAllowed(db, { personId: request.requester_person_id, asset, operationType: request.operation_type,
        siteId: request.site_id, locationId: request.location_id, requestId });
    }
    const now = new Date().toISOString();
    db.prepare(`UPDATE request_preparation SET status='LISTA',ready_at=?,version=version+1,updated_at=? WHERE id=? AND version=?`).run(now, now, preparation.id, preparationVersion);
    const changed = db.prepare(`UPDATE request SET status='LISTA_PARA_ENTREGA',version=version+1,updated_at=? WHERE id=? AND version=? AND status='PREPARANDO'`).run(now, requestId, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al cerrar preparación.');
    addRequestEvent(db, requestId, 'PREPARANDO', 'LISTA_PARA_ENTREGA', context.user.id, requiredString(input.reason || 'Preparación completa y verificada.', 'reason', { min: 5, max: 1000 }), context.correlationId, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.READY', entityType: 'request', entityId: requestId,
      before: { status: 'PREPARANDO' }, after: { status: 'LISTA_PARA_ENTREGA' }, correlationId: context.correlationId, ipAddress: context.ip, equipment: context.userAgent }, db);
    return { requestId, status: 'LISTA_PARA_ENTREGA', version: version + 1, preparation: getPreparationFromDb(db, requestId) };
  });
}

function normalizeAcceptance(db, input, requestId, handoverId, context) {
  const method = String(input.acceptanceMethod || getSetting('custody.acceptanceMethod', 'EXPLICITA')).toUpperCase();
  if (!['EXPLICITA', 'PIN', 'FIRMA'].includes(method)) throw error(422, 'ACCEPTANCE_METHOD_INVALID', 'Método de aceptación inválido.');
  if (input.acceptanceConfirmed !== true) throw error(422, 'ACCEPTANCE_REQUIRED', 'La aceptación explícita del custodio es obligatoria.');
  let acceptanceHash = null;
  let evidenceId = null;
  if (method === 'PIN') {
    const value = requiredString(input.acceptanceValue, 'acceptanceValue', { min: 4, max: 32 });
    acceptanceHash = createHash('sha256').update(`${requestId}:${value}`).digest('hex');
  }
  if (method === 'FIRMA') {
    evidenceId = requiredString(input.acceptanceEvidenceId, 'acceptanceEvidenceId', { min: 8, max: 80 });
    const evidence = db.prepare('SELECT * FROM file_evidence WHERE id=?').get(evidenceId);
    if (!evidence) throw error(422, 'ACCEPTANCE_EVIDENCE_NOT_FOUND', 'La evidencia de firma no existe.');
    if (evidence.lifecycle_state === 'PENDING') {
      if (evidence.owner_type !== 'UNASSIGNED' || evidence.owner_id !== null || evidence.created_by_user_id !== context.user.id) {
        throw error(403, 'ACCEPTANCE_EVIDENCE_FORBIDDEN', 'La evidencia de firma pendiente pertenece a otro usuario u operación.');
      }
    } else if (evidence.lifecycle_state !== 'ACTIVE' || evidence.owner_type !== 'HANDOVER' || evidence.owner_id !== handoverId) {
      throw error(409, 'ACCEPTANCE_EVIDENCE_ALREADY_USED', 'La evidencia de firma pertenece a otra operación.');
    }
  }
  if (method === 'EXPLICITA') acceptanceHash = createHash('sha256').update(`${requestId}:EXPLICITA:${new Date().toISOString()}`).digest('hex');
  return { method, acceptanceHash, evidenceId };
}

function hydrateHandover(db, id) {
  const handover = db.prepare(`SELECT h.*, ua.username, p.full_name AS operator_name, cp.full_name AS person_name
    FROM handover h JOIN user_account ua ON ua.id=h.operator_user_id JOIN person p ON p.id=ua.person_id JOIN person cp ON cp.id=h.person_id WHERE h.id=?`).get(id);
  if (!handover) return null;
  handover.items = db.prepare(`SELECT hi.*, a.internal_code, a.description FROM handover_item hi JOIN asset a ON a.id=hi.asset_id WHERE hi.handover_id=? ORDER BY a.internal_code`).all(id);
  handover.inspections = db.prepare('SELECT * FROM inspection WHERE handover_id=? ORDER BY occurred_at').all(id);
  handover.custodies = db.prepare('SELECT * FROM custody WHERE opened_by_handover_id=? ORDER BY created_at').all(id);
  return handover;
}

function handoverRequest(requestId, input, context) {
  const idempotencyKey = requiredString(input.idempotencyKey, 'idempotencyKey', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ });
  return transaction((db) => {
    const existing = db.prepare('SELECT id, request_id, type FROM handover WHERE idempotency_key=?').get(idempotencyKey);
    if (existing) {
      if (existing.request_id !== requestId || existing.type !== 'ENTREGA') throw error(409, 'IDEMPOTENCY_KEY_REUSED', 'La clave de idempotencia pertenece a otra operación.');
      return { handover: hydrateHandover(db, existing.id), idempotent: true };
    }
    const request = loadRequest(db, requestId);
    if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
    requireScope(context.user, request.site_id, request.location_id, 'Warehouse.Operate');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== request.version) throw error(409, 'CONCURRENCY_CONFLICT', 'La solicitud fue modificada por otra operación.');
    if (request.status !== 'LISTA_PARA_ENTREGA') throw error(409, 'REQUEST_NOT_READY', 'La solicitud no está lista para entrega.');
    const preparation = db.prepare(`SELECT * FROM request_preparation WHERE request_id=? AND status='LISTA'`).get(requestId);
    if (!preparation) throw error(409, 'PREPARATION_NOT_READY', 'La preparación no está cerrada como lista.');
    const handoverId = randomUUID();
    const acceptance = normalizeAcceptance(db, input, requestId, handoverId, context);
    const now = new Date().toISOString();
    db.prepare(`INSERT INTO handover(id,request_id,type,operator_user_id,person_id,occurred_at,observations,acceptance_method,acceptance_hash,acceptance_evidence_id,idempotency_key,correlation_id,created_at,work_order_reference_snapshot)
      VALUES (?,?, 'ENTREGA',?,?,?,?,?,?,?,?,?,?,?)`).run(handoverId, requestId, context.user.id, request.requester_person_id, now,
      optionalString(input.observations, 'observations', 1500), acceptance.method, acceptance.acceptanceHash, acceptance.evidenceId, idempotencyKey, context.correlationId, now, request.work_order_reference);
    if (acceptance.method === 'FIRMA') {
      const evidence = db.prepare('SELECT lifecycle_state FROM file_evidence WHERE id=?').get(acceptance.evidenceId);
      if (evidence?.lifecycle_state === 'PENDING') {
        claimEvidence(acceptance.evidenceId, { ownerType: 'HANDOVER', ownerId: handoverId, purpose: 'ACCEPTANCE_SIGNATURE' }, context, db);
      }
    }
    const preparedItems = db.prepare(`SELECT rpi.*, ri.quantity AS requested_quantity, c.nature AS category_nature, c.requires_return, c.requires_inspection,
        a.internal_code, a.quantity_available, a.quantity_total
      FROM request_preparation_item rpi JOIN request_item ri ON ri.id=rpi.request_item_id JOIN asset a ON a.id=rpi.prepared_asset_id
      JOIN asset_category c ON c.id=a.category_id WHERE rpi.preparation_id=? ORDER BY rpi.created_at`).all(preparation.id);
    const conditionMap = new Map((Array.isArray(input.items) ? input.items : []).map((item) => [item.requestItemId, item]));
    const custodies = [];
    const requiredReturnCount = preparedItems.filter((item) => Boolean(item.requires_return)).length;
    for (const item of preparedItems) {
      const supplied = conditionMap.get(item.request_item_id) || {};
      const preparedAsset = loadAsset(db, item.prepared_asset_id);
      if (!preparedAsset) throw error(409, 'PREPARED_ASSET_NOT_FOUND', `El bien preparado ${item.internal_code} ya no existe.`);
      const kitOperationalStatus = item.category_nature === 'KIT'
        ? assertKitOperationallyComplete(db, preparedAsset.id, 'entrega')
        : null;
      assertOperationAllowed(db, { personId: request.requester_person_id, asset: preparedAsset, operationType: request.operation_type,
        siteId: request.site_id, locationId: request.location_id, requestId });
      const condition = String(supplied.condition || item.condition || 'CONFORME').toUpperCase();
      if (!['CONFORME', 'OBSERVADO'].includes(condition)) throw error(422, 'DELIVERY_CONDITION_INVALID', `Condición de entrega inválida para ${item.internal_code}.`);
      const notes = optionalString(supplied.notes ?? item.notes, 'notes', 1500);
      if (condition === 'OBSERVADO' && !notes) throw error(422, 'DELIVERY_NOTES_REQUIRED', `La observación de ${item.internal_code} requiere detalle.`);
      const reservation = db.prepare(`SELECT * FROM asset_reservation WHERE request_item_id=? AND asset_id=? AND status='ACTIVA'`).get(item.request_item_id, item.prepared_asset_id);
      if (!reservation || reservation.quantity !== item.quantity) throw error(409, 'RESERVATION_NOT_ACTIVE', `La reserva preparada de ${item.internal_code} no está activa.`);
      db.prepare(`INSERT INTO handover_item(id,handover_id,request_item_id,asset_id,quantity,condition,notes,created_at) VALUES (?,?,?,?,?,?,?,?)`)
        .run(randomUUID(), handoverId, item.request_item_id, item.prepared_asset_id, item.quantity, condition, notes, now);
      if (item.requires_inspection || condition !== 'CONFORME') {
        db.prepare(`INSERT INTO inspection(id,asset_id,custody_id,handover_id,inspector_user_id,phase,condition,result,notes,occurred_at,created_at)
          VALUES (?,?,NULL,?,?,'ENTREGA',?,'APROBADO',?,?,?)`).run(randomUUID(), item.prepared_asset_id, handoverId, context.user.id, condition, notes, now, now);
      }
      if (item.requires_return) {
        const custodyId = randomUUID();
        const dueAt = request.due_at || new Date(Date.now() + Number(getSetting('custody.defaultDurationHours', 24)) * 3600_000).toISOString();
        const exclusive = SERIAL_NATURES.has(item.category_nature) ? 1 : 0;
        db.prepare(`INSERT INTO custody(id,request_id,request_item_id,asset_id,person_id,quantity,exclusive_unit,opened_by_handover_id,opened_at,due_at,status,version,created_at,updated_at,work_order_reference_snapshot)
          VALUES (?,?,?,?,?,?,?,?,?,?,'ABIERTA',1,?,?,?)`).run(custodyId, requestId, item.request_item_id, item.prepared_asset_id, request.requester_person_id, item.quantity, exclusive, handoverId, now, dueAt, now, now, request.work_order_reference);
        db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
          VALUES (?,?,NULL,'ABIERTA',?,?,?,?,?)`).run(randomUUID(), custodyId, context.user.id, 'Entrega física confirmada y aceptada.', now, context.correlationId, now);
        if (exclusive) db.prepare(`UPDATE asset SET status='EN_CUSTODIA',custodian_person_id=?,quantity_available=0,version=version+1,updated_at=? WHERE id=?`).run(request.requester_person_id, now, item.prepared_asset_id);
        else db.prepare(`UPDATE asset SET status=CASE WHEN quantity_available>0 THEN 'DISPONIBLE' ELSE 'EN_CUSTODIA' END,version=version+1,updated_at=? WHERE id=?`).run(now, item.prepared_asset_id);
        if (kitOperationalStatus) {
          const selections = kitOperationalStatus.components
            .filter((component) => component.operationally_available)
            .map((component) => ({
              kitComponentId: component.id,
              componentAssetId: component.component_asset_id,
              quantity: component.required_quantity
            }));
          issueKitComponentsInDb(db, preparedAsset.id, {
            custodyId,
            components: selections,
            reason: `Entrega automática de componentes del kit en solicitud ${request.request_number}`
          }, context);
        }
        custodies.push(custodyId);
        syncCustodyOperationalAlerts(db, custodyId, new Date(now));
      } else {
        db.prepare(`UPDATE asset SET status='DISPONIBLE',custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?`).run(now, item.prepared_asset_id);
      }
      db.prepare(`UPDATE asset_reservation SET status='CONSUMIDA',release_reason='ENTREGA_CONFIRMADA',updated_at=? WHERE id=?`).run(now, reservation.id);
      db.prepare(`UPDATE request_item SET status='ENTREGADO',updated_at=? WHERE id=?`).run(now, item.request_item_id);
    }
    if (custodies.length !== requiredReturnCount) {
      throw error(409, 'CUSTODY_CREATION_INTEGRITY_FAILED', 'La entrega no puede cerrarse porque no se crearon todas las custodias requeridas.');
    }
    const persistedCustodies = db.prepare('SELECT COUNT(*) AS count FROM custody WHERE opened_by_handover_id=?').get(handoverId).count;
    if (persistedCustodies !== requiredReturnCount) {
      throw error(409, 'CUSTODY_PERSISTENCE_INTEGRITY_FAILED', 'La entrega no puede cerrarse porque la persistencia de custodias es incompleta.');
    }
    const changed = db.prepare(`UPDATE request SET status='ENTREGADA',version=version+1,updated_at=? WHERE id=? AND version=? AND status='LISTA_PARA_ENTREGA'`).run(now, requestId, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al confirmar entrega.');
    syncRequestOperationalAlert(db, requestId, new Date(now));
    addRequestEvent(db, requestId, 'LISTA_PARA_ENTREGA', 'ENTREGADA', context.user.id, 'Entrega física confirmada y aceptada.', context.correlationId, now);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'WAREHOUSE.HANDOVER', entityType: 'request', entityId: requestId,
      before: { status: 'LISTA_PARA_ENTREGA' }, after: { status: 'ENTREGADA', handoverId, custodyCount: custodies.length }, correlationId: context.correlationId,
      ipAddress: context.ip, equipment: context.userAgent }, db);
    return { handover: hydrateHandover(db, handoverId), idempotent: false };
  });
}

module.exports = { prepareRequest, markRequestReady, handoverRequest, getPreparation, hydrateHandover, parseIso };
