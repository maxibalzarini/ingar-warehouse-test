'use strict';

const { getDb } = require('../db/database');
const { hasPermission } = require('./permission-service');
const { scopeWhere } = require('../security/scope');
const { getSetting } = require('./settings-service');
const { getWarehouseWorkbench } = require('./warehouse-workbench-service');

const OPEN_CUSTODY_STATUSES = ['ABIERTA', 'DEVOLUCION_DECLARADA', 'RECEPCION_PENDIENTE', 'TRANSFERENCIA_PENDIENTE', 'INCIDENTE'];
const OPEN_INCIDENT_STATUSES = ['ABIERTO', 'EN_INVESTIGACION'];
const REQUEST_ACTION_STATUSES = ['PENDIENTE_AUTORIZACION', 'APROBADA', 'PREPARANDO', 'LISTA_PARA_ENTREGA'];
const DEFAULT_TIME_ZONE = 'America/Argentina/Buenos_Aires';
const DEFAULT_UPCOMING_MINUTES = 60;
const ATTENTION_LIMIT = 12;

function can(user, permission) {
  return Boolean(user && hasPermission(user, permission));
}

function placeholders(values) {
  return values.map(() => '?').join(',');
}

function safeTimeZone(value) {
  const candidate = String(value || DEFAULT_TIME_ZONE);
  try {
    new Intl.DateTimeFormat('es-AR', { timeZone: candidate }).format(new Date());
    return candidate;
  } catch {
    return DEFAULT_TIME_ZONE;
  }
}

function zonedParts(date, timeZone) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23'
  }).formatToParts(date);
  return Object.fromEntries(parts.filter((part) => part.type !== 'literal').map((part) => [part.type, Number(part.value)]));
}

function timeZoneOffsetMs(date, timeZone) {
  const parts = zonedParts(date, timeZone);
  const representedUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
  return representedUtc - Math.floor(date.getTime() / 1000) * 1000;
}

function localDateTimeToUtc(parts, timeZone) {
  const targetUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour || 0, parts.minute || 0, parts.second || 0, parts.millisecond || 0);
  let estimate = targetUtc;
  for (let iteration = 0; iteration < 3; iteration += 1) {
    estimate = targetUtc - timeZoneOffsetMs(new Date(estimate), timeZone);
  }
  return new Date(estimate);
}

function dateKeyFromParts(parts) {
  return `${String(parts.year).padStart(4, '0')}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
}

function localDateKey(date, timeZone) {
  return dateKeyFromParts(zonedParts(date, timeZone));
}

function parseDateKey(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) throw new Error(`Fecha local inválida: ${value}`);
  return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
}

function shiftDateKey(dateKey, days) {
  const parts = parseDateKey(dateKey);
  const shifted = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + days, 12));
  return shifted.toISOString().slice(0, 10);
}

function dayRange(date, timeZone) {
  const localKey = localDateKey(date, timeZone);
  const startParts = parseDateKey(localKey);
  const nextParts = parseDateKey(shiftDateKey(localKey, 1));
  const start = localDateTimeToUtc(startParts, timeZone);
  const end = localDateTimeToUtc(nextParts, timeZone);
  return { localDate: localKey, startUtc: start.toISOString(), endUtc: end.toISOString() };
}

function localDayLabel(dateKey) {
  const parts = parseDateKey(dateKey);
  return new Intl.DateTimeFormat('es-AR', { weekday: 'short', day: '2-digit', timeZone: 'UTC' })
    .format(new Date(Date.UTC(parts.year, parts.month - 1, parts.day, 12)))
    .replace('.', '');
}

function requestScope(db, user) {
  if (can(user, 'Requests.ReadAll')) {
    const scope = scopeWhere(user, 'Requests.ReadAll', 'r.site_id', 'r.location_id', db);
    return { sql: scope.sql, params: scope.params, own: false, permission: 'Requests.ReadAll' };
  }
  if (can(user, 'Requests.ReadOwn') && user.personId) {
    const scope = scopeWhere(user, 'Requests.ReadOwn', 'r.site_id', 'r.location_id', db);
    return { sql: `(${scope.sql}) AND r.requester_person_id=?`, params: [...scope.params, user.personId], own: true, permission: 'Requests.ReadOwn' };
  }
  return null;
}

function custodyScope(db, user) {
  if (can(user, 'Custody.ReadAll')) {
    const scope = scopeWhere(user, 'Custody.ReadAll', 'r.site_id', 'r.location_id', db);
    return { sql: scope.sql, params: scope.params, own: false, permission: 'Custody.ReadAll' };
  }
  if (can(user, 'Custody.ReadOwn') && user.personId) {
    const scope = scopeWhere(user, 'Custody.ReadOwn', 'r.site_id', 'r.location_id', db);
    return { sql: `(${scope.sql}) AND c.person_id=?`, params: [...scope.params, user.personId], own: true, permission: 'Custody.ReadOwn' };
  }
  return null;
}

function countQuery(db, fromSql, scope, whereSql = '1=1', params = []) {
  if (!scope) return null;
  return Number(db.prepare(`SELECT COUNT(*) AS total ${fromSql} WHERE (${scope.sql}) AND (${whereSql})`).get(...scope.params, ...params)?.total || 0);
}

function scalarQuery(db, sql, params = []) {
  return Number(db.prepare(sql).get(...params)?.total || 0);
}

function scopedCount(db, user, permission, fromSql, siteColumn, locationColumn, whereSql = '1=1', params = []) {
  if (!can(user, permission)) return null;
  const scope = scopeWhere(user, permission, siteColumn, locationColumn, db);
  return countQuery(db, fromSql, scope, whereSql, params);
}

function actionableRequestStatuses(user) {
  const statuses = [];
  if (can(user, 'Requests.Approve')) statuses.push('PENDIENTE_AUTORIZACION');
  if (can(user, 'Warehouse.Prepare')) statuses.push('APROBADA', 'PREPARANDO');
  if (can(user, 'Warehouse.Operate')) statuses.push('LISTA_PARA_ENTREGA');
  return [...new Set(statuses)];
}

function requestCount(db, user, whereSql, params = []) {
  return countQuery(db, 'FROM request r', requestScope(db, user), whereSql, params);
}

function custodyCount(db, user, whereSql, params = []) {
  return countQuery(db, 'FROM custody c JOIN request r ON r.id=c.request_id', custodyScope(db, user), whereSql, params);
}

function deliveredRequestCount(db, user, startUtc, endUtc) {
  const scope = requestScope(db, user);
  if (!scope) return null;
  return scalarQuery(db, `SELECT COUNT(DISTINCT h.request_id) AS total
    FROM handover h JOIN request r ON r.id=h.request_id
    WHERE (${scope.sql}) AND h.type='ENTREGA' AND h.occurred_at>=? AND h.occurred_at<?`, [...scope.params, startUtc, endUtc]);
}

function custodyEventQuantity(db, user, relationColumn, type, startUtc, endUtc) {
  const scope = requestScope(db, user);
  if (!scope) return null;
  return scalarQuery(db, `SELECT COUNT(*) AS total
    FROM custody c JOIN handover h ON h.id=c.${relationColumn} JOIN request r ON r.id=c.request_id
    WHERE (${scope.sql}) AND h.type=? AND h.occurred_at>=? AND h.occurred_at<?`, [...scope.params, type, startUtc, endUtc]);
}

function unavailableLotCount(db, user) {
  if (!can(user, 'Stock.Read')) return null;
  const scope = scopeWhere(user, 'Stock.Read', 'l.site_id', 'sl.location_id', db);
  return scalarQuery(db, `SELECT COUNT(*) AS total
    FROM stock_lot sl JOIN asset a ON a.id=sl.asset_id JOIN asset_category c ON c.id=a.category_id JOIN storage_location l ON l.id=sl.location_id
    WHERE (${scope.sql}) AND sl.active=1 AND a.active=1 AND a.deleted_at IS NULL AND c.active=1 AND c.deleted_at IS NULL
      AND c.nature IN ('CANTIDAD','CONSUMIBLE') AND (sl.quantity_on_hand-sl.quantity_reserved)<=0`, scope.params);
}

function metricSummary(db, user, now, timeZone) {
  const nowIso = now.toISOString();
  const today = dayRange(now, timeZone);
  const upcomingMinutes = Math.max(5, Math.min(1440, Number(getSetting('dashboard.upcomingMinutes', DEFAULT_UPCOMING_MINUTES)) || DEFAULT_UPCOMING_MINUTES));
  const upcomingEnd = new Date(now.getTime() + upcomingMinutes * 60_000).toISOString();
  const actionStatuses = actionableRequestStatuses(user);
  const actionPlaceholders = actionStatuses.length ? placeholders(actionStatuses) : '';
  const requestScopeInfo = requestScope(db, user);
  const custodyScopeInfo = custodyScope(db, user);
  const requestRange = (column) => `${column}>=? AND ${column}<?`;

  const warehouseSummary = can(user, 'Warehouse.Operate') ? getWarehouseWorkbench(user, { now }).summary : null;

  return {
    pendingApproval: can(user, 'Requests.Approve') ? requestCount(db, user, "r.status='PENDIENTE_AUTORIZACION'") : null,
    approvedToPrepare: can(user, 'Warehouse.Prepare') ? Number(warehouseSummary?.approvedToPrepare || 0) : null,
    inPreparation: can(user, 'Warehouse.Prepare') ? Number(warehouseSummary?.inPreparation || 0) : null,
    readyForDelivery: can(user, 'Warehouse.Operate') ? Number(warehouseSummary?.readyForDelivery || 0) : null,
    upcomingRequests: actionStatuses.length ? countQuery(db, 'FROM request r', requestScopeInfo, `r.status IN (${actionPlaceholders}) AND r.needed_at>=? AND r.needed_at<?`, [...actionStatuses, nowIso, upcomingEnd]) : null,
    overdueRequests: actionStatuses.length ? countQuery(db, 'FROM request r', requestScopeInfo, `r.status IN (${actionPlaceholders}) AND r.needed_at<?`, [...actionStatuses, nowIso]) : null,
    activeCustodies: custodyCount(db, user, `c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)})`, OPEN_CUSTODY_STATUSES),
    dueTodayCustodies: custodyCount(db, user, `c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND c.status<>'DEVOLUCION_DECLARADA' AND c.due_at>=? AND c.due_at<?`, [...OPEN_CUSTODY_STATUSES, today.startUtc, today.endUtc]),
    overdueCustodies: custodyCount(db, user, `c.status IN (${placeholders(OPEN_CUSTODY_STATUSES)}) AND c.status<>'DEVOLUCION_DECLARADA' AND c.due_at IS NOT NULL AND c.due_at<?`, [...OPEN_CUSTODY_STATUSES, nowIso]),
    pendingReceiveCustodies: can(user, 'Warehouse.Operate') ? Number(warehouseSummary?.receive || 0) : null,
    openIncidents: scopedCount(db, user, 'Incident.Read', 'FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location l ON l.id=a.location_id', 'l.site_id', 'a.location_id', `i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)})`, OPEN_INCIDENT_STATUSES),
    blockedAssets: scopedCount(db, user, 'Assets.Read', 'FROM asset a JOIN storage_location l ON l.id=a.location_id', 'l.site_id', 'a.location_id', "a.deleted_at IS NULL AND a.active=1 AND a.status='BLOQUEADO'"),
    overdueMaintenance: scopedCount(db, user, 'Maintenance.Read', 'FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location l ON l.id=a.location_id', 'l.site_id', 'a.location_id', "mo.status='VENCIDA' OR (mo.status IN ('PROGRAMADA','EN_PROGRESO') AND mo.due_at IS NOT NULL AND mo.due_at<?)", [nowIso]),
    unavailableLots: unavailableLotCount(db, user),
    requestsToday: requestCount(db, user, requestRange('r.created_at'), [today.startUtc, today.endUtc]),
    deliveriesToday: deliveredRequestCount(db, user, today.startUtc, today.endUtc),
    toolsDeliveredToday: custodyEventQuantity(db, user, 'opened_by_handover_id', 'ENTREGA', today.startUtc, today.endUtc),
    returnsToday: custodyCount(db, user, 'c.closed_at>=? AND c.closed_at<?', [today.startUtc, today.endUtc]),
    consumableMovementsToday: scopedCount(db, user, 'Stock.Read', 'FROM stock_movement sm JOIN stock_lot sl ON sl.id=sm.lot_id JOIN storage_location l ON l.id=sl.location_id', 'l.site_id', 'sl.location_id', requestRange('sm.occurred_at'), [today.startUtc, today.endUtc]),
    incidentsToday: scopedCount(db, user, 'Incident.Read', 'FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location l ON l.id=a.location_id', 'l.site_id', 'a.location_id', requestRange('i.opened_at'), [today.startUtc, today.endUtc]),
    _meta: { today, upcomingEnd, upcomingMinutes, requestScope: Boolean(requestScopeInfo), custodyScope: Boolean(custodyScopeInfo), actionStatuses }
  };
}

function card(key, label, value, section, tone, icon, view, filter, unit, requiredPermission = null) {
  if (value === null || value === undefined) return null;
  return { key, label, value: Number(value || 0), section, tone, icon, view, filter, unit, requiredPermission };
}

function metricCards(metrics, user, nowIso) {
  const { today, upcomingEnd, upcomingMinutes, actionStatuses } = metrics._meta;
  const openCustodyFilter = { statuses: OPEN_CUSTODY_STATUSES };
  const openIncidentFilter = { statuses: OPEN_INCIDENT_STATUSES };
  const cards = [
    card('pendingApproval', 'Esperan autorización', metrics.pendingApproval, 'attention', 'warning', 'pending', 'requests', { statuses: ['PENDIENTE_AUTORIZACION'] }, 'solicitudes', 'Requests.Approve'),
    card('approvedToPrepare', 'Para preparar', metrics.approvedToPrepare, 'attention', 'operation', 'prepare', 'workbench', { lane: 'prepare' }, 'tareas', 'Warehouse.Prepare'),
    card('inPreparation', 'Preparándose', metrics.inPreparation, 'attention', 'information', 'tools', 'workbench', { lane: 'prepare' }, 'tareas', 'Warehouse.Prepare'),
    card('readyForDelivery', 'Para entregar', metrics.readyForDelivery, 'attention', 'success', 'check', 'workbench', { lane: 'deliver' }, 'tareas', 'Warehouse.Operate'),
    card('upcomingRequests', `Empiezan en ${metrics._meta.upcomingMinutes} min`, metrics.upcomingRequests, 'attention', 'warning', 'clock', 'requests', { statuses: actionStatuses, neededFrom: nowIso, neededTo: upcomingEnd }, 'solicitudes'),
    card('overdueRequests', 'Pedidos demorados', metrics.overdueRequests, 'attention', 'danger', 'alert', 'requests', { statuses: actionStatuses, neededBefore: nowIso }, 'solicitudes'),
    card('pendingReceiveCustodies', 'Pendientes de recibir', metrics.pendingReceiveCustodies, 'attention', 'information', 'return', 'workbench', { lane: 'receive' }, 'devoluciones', 'Warehouse.Operate'),
    card('dueTodayCustodies', 'Se devuelven hoy', metrics.dueTodayCustodies, 'attention', 'custody', 'custody', 'custodies', { ...openCustodyFilter, dueFrom: today.startUtc, dueTo: today.endUtc }, 'herramientas'),
    card('overdueCustodies', 'Devoluciones atrasadas', metrics.overdueCustodies, 'attention', 'danger', 'alert', 'custodies', { ...openCustodyFilter, dueBefore: nowIso }, 'herramientas'),
    card('openIncidents', 'Problemas abiertos', metrics.openIncidents, 'attention', 'danger', 'incident', 'incidents', openIncidentFilter, 'incidentes'),

    card('activeCustodies', 'Herramientas prestadas', metrics.activeCustodies, 'status', 'custody', 'custody', 'custodies', openCustodyFilter, 'herramientas'),
    card('blockedAssets', 'Bienes bloqueados', metrics.blockedAssets, 'status', 'warning', 'block', 'assets', { status: 'BLOQUEADO' }, 'bienes'),
    card('overdueMaintenance', 'Mantenimientos atrasados', metrics.overdueMaintenance, 'status', 'violet', 'maintenance', 'maintenance', { overdue: true, dueBefore: nowIso }, 'órdenes'),
    card('unavailableLots', 'Lotes sin stock', metrics.unavailableLots, 'status', 'inventory', 'stock', 'stock', { unavailable: true, mode: 'lots' }, 'lotes'),

    card('requestsToday', 'Pedidos recibidos hoy', metrics.requestsToday, 'today', 'information', 'requests', 'requests', { createdFrom: today.startUtc, createdTo: today.endUtc }, 'solicitudes'),
    card('deliveriesToday', 'Pedidos entregados hoy', metrics.deliveriesToday, 'today', 'success', 'delivery', 'requests', { handoverType: 'ENTREGA', handoverFrom: today.startUtc, handoverTo: today.endUtc }, 'pedidos'),
    card('toolsDeliveredToday', 'Herramientas entregadas hoy', metrics.toolsDeliveredToday, 'today', 'operation', 'tools', 'custodies', { openedFrom: today.startUtc, openedTo: today.endUtc }, 'herramientas'),
    card('returnsToday', 'Herramientas devueltas hoy', metrics.returnsToday, 'today', 'custody', 'return', 'custodies', { closedFrom: today.startUtc, closedTo: today.endUtc }, 'herramientas'),
    card('consumableMovementsToday', 'Movimientos de consumibles hoy', metrics.consumableMovementsToday, 'today', 'steel', 'stock', 'stock', { movementFrom: today.startUtc, movementTo: today.endUtc, mode: 'movements' }, 'movimientos'),
    card('incidentsToday', 'Problemas informados hoy', metrics.incidentsToday, 'today', 'danger', 'incident', 'incidents', { openedFrom: today.startUtc, openedTo: today.endUtc }, 'incidentes')
  ].filter(Boolean);
  return cards.filter((item) => !item.requiredPermission || can(user, item.requiredPermission));
}

const PRIORITY_RANK = { CRITICA: 0, ALTA: 1, MEDIA: 2, BAJA: 3 };

function compareAttention(left, right) {
  return (PRIORITY_RANK[left.priority] ?? 9) - (PRIORITY_RANK[right.priority] ?? 9)
    || String(left.dueAt || '').localeCompare(String(right.dueAt || ''));
}

function addAttention(collector, item) {
  collector.visible.push(item);
  collector.visible.sort(compareAttention);
  if (collector.visible.length > collector.limit) collector.visible.length = collector.limit;
}

function addAttentionTotal(collector, db, sql, params) {
  collector.total += Number(db.prepare(sql).get(...params)?.total || 0);
}

function requestAttention(db, user, collector, now, upcomingEnd) {
  const statuses = actionableRequestStatuses(user);
  const scope = requestScope(db, user);
  if (!statuses.length || !scope) return;
  const statusParams = [...scope.params, ...statuses];
  const whereSql = `(${scope.sql}) AND r.status IN (${placeholders(statuses)})`;
  addAttentionTotal(collector, db, `SELECT COUNT(*) AS total FROM request r WHERE ${whereSql}`, statusParams);
  const rows = db.prepare(`SELECT r.id,r.request_number,r.status,r.needed_at,p.full_name
    FROM request r JOIN person p ON p.id=r.requester_person_id
    WHERE ${whereSql}
    ORDER BY CASE
      WHEN r.needed_at<? THEN 0
      WHEN r.needed_at<? THEN 1
      WHEN r.status='LISTA_PARA_ENTREGA' THEN 1
      ELSE 2
    END, r.needed_at ASC
    LIMIT ?`).iterate(...statusParams, now.toISOString(), upcomingEnd, collector.limit);
  const nowMs = now.getTime();
  const upcomingMs = new Date(upcomingEnd).getTime();
  for (const row of rows) {
    const neededMs = new Date(row.needed_at).getTime();
    let priority = 'MEDIA';
    let title = '';
    let action = '';
    if (row.status === 'PENDIENTE_AUTORIZACION') { title = `Autorizar ${row.request_number}`; action = 'Autorizar o rechazar'; }
    if (row.status === 'APROBADA') { title = `Preparar ${row.request_number}`; action = 'Iniciar preparación'; }
    if (row.status === 'PREPARANDO') { title = `Terminar preparación ${row.request_number}`; action = 'Marcar lista'; }
    if (row.status === 'LISTA_PARA_ENTREGA') { title = `Entregar ${row.request_number}`; action = 'Registrar entrega'; priority = 'ALTA'; }
    let type = row.status;
    let filter = { statuses: [row.status] };
    if (neededMs < nowMs) { title = `Demorada: ${row.request_number}`; priority = 'ALTA'; type = 'SOLICITUD_ATRASADA'; filter = { statuses: [row.status], neededBefore: now.toISOString() }; }
    else if (neededMs < upcomingMs) { title = `Empieza pronto: ${row.request_number}`; priority = 'ALTA'; type = 'SOLICITUD_PROXIMA'; filter = { statuses: [row.status], neededFrom: now.toISOString(), neededTo: upcomingEnd }; }
    addAttention(collector, {
      id: `request:${row.id}`, priority, type, title,
      detail: `${row.full_name} · ${action}`,
      dueAt: row.needed_at, view: 'requests', filter, entityType: 'request', entityId: row.id
    });
  }
}

function custodyAttention(db, user, collector, now, today) {
  const scope = custodyScope(db, user);
  if (!scope) return;

  // F8: primero devoluciones declaradas. Son recepciones pendientes aunque el vencimiento haya pasado.
  const declaredParams = [...scope.params];
  const declaredSql = `(${scope.sql}) AND c.status='DEVOLUCION_DECLARADA'`;
  addAttentionTotal(collector, db, `SELECT COUNT(*) AS total FROM custody c JOIN request r ON r.id=c.request_id WHERE ${declaredSql}`, declaredParams);
  const declaredRows = db.prepare(`SELECT c.id,c.due_at,c.declared_return_at,c.status,a.internal_code,a.description,p.full_name,r.request_number
    FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id
    WHERE ${declaredSql}
    ORDER BY COALESCE(c.declared_return_at,c.due_at,c.opened_at) ASC
    LIMIT ?`).iterate(...declaredParams, collector.limit);
  for (const row of declaredRows) addAttention(collector, {
    id: `custody-receive:${row.id}`, priority: 'ALTA', type: 'DEVOLUCION_DECLARADA',
    title: `Pendiente de recibir: ${row.internal_code}`,
    detail: `${row.full_name} · ${row.request_number} · ${row.description}`,
    dueAt: row.declared_return_at || row.due_at, view: 'workbench', filter: { lane: 'receive' }, entityType: 'custody', entityId: row.id
  });

  // Sólo custodias todavía no declaradas se clasifican como próximas/atrasadas.
  const dueStatuses = OPEN_CUSTODY_STATUSES.filter((status) => status !== 'DEVOLUCION_DECLARADA');
  const params = [...scope.params, ...dueStatuses, today.endUtc];
  const whereSql = `(${scope.sql}) AND c.status IN (${placeholders(dueStatuses)}) AND c.due_at IS NOT NULL AND c.due_at<?`;
  addAttentionTotal(collector, db, `SELECT COUNT(*) AS total FROM custody c JOIN request r ON r.id=c.request_id WHERE ${whereSql}`, params);
  const rows = db.prepare(`SELECT c.id,c.due_at,c.status,a.internal_code,a.description,p.full_name,r.request_number
    FROM custody c JOIN request r ON r.id=c.request_id JOIN asset a ON a.id=c.asset_id JOIN person p ON p.id=c.person_id
    WHERE ${whereSql}
    ORDER BY CASE WHEN c.due_at<? THEN 0 ELSE 1 END,c.due_at ASC
    LIMIT ?`).iterate(...params, now.toISOString(), collector.limit);
  const nowMs = now.getTime();
  for (const row of rows) {
    const overdue = new Date(row.due_at).getTime() < nowMs;
    addAttention(collector, {
      id: `custody:${row.id}`, priority: overdue ? 'CRITICA' : 'ALTA', type: overdue ? 'CUSTODIA_VENCIDA' : 'CUSTODIA_HOY',
      title: overdue ? `Devolución atrasada: ${row.internal_code}` : `Se devuelve hoy: ${row.internal_code}`,
      detail: `${row.full_name} · ${row.request_number} · ${row.description}`,
      dueAt: row.due_at, view: 'custodies', filter: { statuses: dueStatuses, dueBefore: overdue ? now.toISOString() : today.endUtc, ...(overdue ? {} : { dueFrom: today.startUtc }) }, entityType: 'custody', entityId: row.id
    });
  }
}

function incidentAttention(db, user, collector) {
  if (!can(user, 'Incident.Read')) return;
  const scope = scopeWhere(user, 'Incident.Read', 'l.site_id', 'a.location_id', db);
  const params = [...scope.params, ...OPEN_INCIDENT_STATUSES];
  const whereSql = `(${scope.sql}) AND i.status IN (${placeholders(OPEN_INCIDENT_STATUSES)}) AND i.severity IN ('CRITICA','ALTA')`;
  addAttentionTotal(collector, db, `SELECT COUNT(*) AS total FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location l ON l.id=a.location_id WHERE ${whereSql}`, params);
  const rows = db.prepare(`SELECT i.id,i.incident_number,i.title,i.severity,i.status,i.opened_at,a.internal_code
    FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location l ON l.id=a.location_id
    WHERE ${whereSql}
    ORDER BY CASE i.severity WHEN 'CRITICA' THEN 0 ELSE 1 END,i.opened_at ASC
    LIMIT ?`).iterate(...params, collector.limit);
  for (const row of rows) addAttention(collector, {
    id: `incident:${row.id}`, priority: row.severity, type: 'INCIDENTE', title: `${row.incident_number}: ${row.title}`,
    detail: `${row.internal_code} · ${row.status}`, dueAt: row.opened_at, view: 'incidents', filter: { statuses: OPEN_INCIDENT_STATUSES, severity: row.severity }, entityType: 'incident', entityId: row.id
  });
}

function maintenanceAttention(db, user, collector, nowIso) {
  if (!can(user, 'Maintenance.Read')) return;
  const scope = scopeWhere(user, 'Maintenance.Read', 'l.site_id', 'a.location_id', db);
  const whereSql = `(${scope.sql}) AND (mo.status='VENCIDA' OR (mo.status IN ('PROGRAMADA','EN_PROGRESO') AND mo.due_at IS NOT NULL AND mo.due_at<?))`;
  const params = [...scope.params, nowIso];
  addAttentionTotal(collector, db, `SELECT COUNT(*) AS total FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location l ON l.id=a.location_id WHERE ${whereSql}`, params);
  const rows = db.prepare(`SELECT mo.id,mo.order_number,mo.status,mo.due_at,mo.priority,a.internal_code,a.description
    FROM maintenance_order mo JOIN asset a ON a.id=mo.asset_id JOIN storage_location l ON l.id=a.location_id
    WHERE ${whereSql}
    ORDER BY CASE WHEN mo.priority='CRITICA' THEN 0 ELSE 1 END,mo.due_at ASC
    LIMIT ?`).iterate(...params, collector.limit);
  for (const row of rows) addAttention(collector, {
    id: `maintenance:${row.id}`, priority: row.priority === 'CRITICA' ? 'CRITICA' : 'ALTA', type: 'MANTENIMIENTO_VENCIDO',
    title: `Mantenimiento atrasado: ${row.order_number}`, detail: `${row.internal_code} · ${row.description}`,
    dueAt: row.due_at, view: 'maintenance', filter: { overdue: true, dueBefore: nowIso }, entityType: 'maintenance_order', entityId: row.id
  });
}

function attentionItems(db, user, now, timeZone, upcomingEnd) {
  const collector = { total: 0, visible: [], limit: ATTENTION_LIMIT };
  const today = dayRange(now, timeZone);
  requestAttention(db, user, collector, now, upcomingEnd);
  custodyAttention(db, user, collector, now, today);
  incidentAttention(db, user, collector);
  maintenanceAttention(db, user, collector, now.toISOString());
  collector.visible.sort(compareAttention);
  return collector;
}

function lastSevenLocalDays(now, timeZone) {
  const endKey = localDateKey(now, timeZone);
  const result = [];
  for (let offset = 6; offset >= 0; offset -= 1) result.push(shiftDateKey(endKey, -offset));
  return result;
}

function groupTimestamps(rows, timeZone) {
  const grouped = new Map();
  for (const row of rows) {
    const date = new Date(row.occurred_at);
    if (!Number.isFinite(date.getTime())) continue;
    const key = localDateKey(date, timeZone);
    grouped.set(key, (grouped.get(key) || 0) + Number(row.quantity || 1));
  }
  return grouped;
}

function activitySeries(db, user, now, timeZone) {
  const days = lastSevenLocalDays(now, timeZone);
  const firstParts = parseDateKey(days[0]);
  const lastNextParts = parseDateKey(shiftDateKey(days[days.length - 1], 1));
  const startUtc = localDateTimeToUtc(firstParts, timeZone).toISOString();
  const endUtc = localDateTimeToUtc(lastNextParts, timeZone).toISOString();
  const requestMap = new Map();
  const deliveryMap = new Map();
  const returnMap = new Map();
  const requestScopeInfo = requestScope(db, user);
  const custodyScopeInfo = custodyScope(db, user);

  if (requestScopeInfo) {
    const requestRows = db.prepare(`SELECT r.created_at AS occurred_at FROM request r WHERE (${requestScopeInfo.sql}) AND r.created_at>=? AND r.created_at<?`).iterate(...requestScopeInfo.params, startUtc, endUtc);
    groupTimestamps(requestRows, timeZone).forEach((value, key) => requestMap.set(key, value));
    const deliveryRows = db.prepare(`SELECT h.occurred_at FROM handover h JOIN request r ON r.id=h.request_id WHERE (${requestScopeInfo.sql}) AND h.type='ENTREGA' AND h.occurred_at>=? AND h.occurred_at<?`).iterate(...requestScopeInfo.params, startUtc, endUtc);
    groupTimestamps(deliveryRows, timeZone).forEach((value, key) => deliveryMap.set(key, value));
  }
  if (custodyScopeInfo) {
    const returnRows = db.prepare(`SELECT h.occurred_at FROM handover h JOIN request r ON r.id=h.request_id JOIN custody c ON c.closed_by_handover_id=h.id WHERE (${custodyScopeInfo.sql}) AND h.type='RECEPCION' AND h.occurred_at>=? AND h.occurred_at<?`).iterate(...custodyScopeInfo.params, startUtc, endUtc);
    groupTimestamps(returnRows, timeZone).forEach((value, key) => returnMap.set(key, value));
  }

  return days.map((day) => ({ day, label: localDayLabel(day), requests: requestMap.get(day) || 0, deliveries: deliveryMap.get(day) || 0, returns: returnMap.get(day) || 0 }));
}

function getOperationalDashboard(user, options = {}) {
  const db = options.db || getDb();
  const now = options.now instanceof Date ? options.now : new Date();
  const timeZone = safeTimeZone(options.timeZone || getSetting('locale.timezone', DEFAULT_TIME_ZONE));
  const metrics = metricSummary(db, user, now, timeZone);
  const cards = metricCards(metrics, user, now.toISOString());
  const attention = attentionItems(db, user, now, timeZone, metrics._meta.upcomingEnd);
  delete metrics._meta;
  return {
    generatedAt: now.toISOString(),
    timeZone,
    localDate: dayRange(now, timeZone).localDate,
    metrics,
    cards,
    attention: attention.visible,
    attentionTotal: attention.total,
    attentionLimit: attention.limit,
    activity: activitySeries(db, user, now, timeZone)
  };
}

module.exports = {
  getOperationalDashboard,
  dayRange,
  localDateKey,
  lastSevenLocalDays,
  actionableRequestStatuses,
  OPEN_CUSTODY_STATUSES,
  OPEN_INCIDENT_STATUSES,
  REQUEST_ACTION_STATUSES
};
