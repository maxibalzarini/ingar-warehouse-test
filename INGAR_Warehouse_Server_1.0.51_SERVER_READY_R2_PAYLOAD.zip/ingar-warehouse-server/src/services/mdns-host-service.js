'use strict';

const dgram = require('node:dgram');
const runtime = require('../config/runtime');
const logger = require('./logger');
const { getNetworkStatus, getLanAddresses, events: networkEvents } = require('./network-service');

const MDNS_GROUP = '224.0.0.251';
const MDNS_PORT = Number(runtime.mdnsPort || 5353);
const HOST_LABEL = String(runtime.mdnsHostName || 'ingar-warehouse.local').replace(/\.+$/, '').toLowerCase();
const HOST_FQDN = `${HOST_LABEL}.`;
const TTL_SECONDS = 30;

let socket = null;
let memberships = new Set();
let listenerAttached = false;
let state = Object.freeze({
  running: false,
  hostname: HOST_LABEL,
  port: MDNS_PORT,
  startedAt: null,
  queries: 0,
  answers: 0,
  lastQueryAt: null,
  lastAnswerAt: null,
  lastAddress: null,
  lastError: null
});

function updateState(patch) {
  state = Object.freeze({ ...state, ...patch });
  return getMdnsStatus();
}

function getMdnsStatus() { return { ...state, memberships: [...memberships] }; }

function encodeName(name) {
  const labels = String(name || '').replace(/\.+$/, '').split('.').filter(Boolean);
  const chunks = [];
  for (const label of labels) {
    const data = Buffer.from(label, 'utf8');
    if (!data.length || data.length > 63) throw new Error('MDNS_LABEL_INVALID');
    chunks.push(Buffer.from([data.length]), data);
  }
  chunks.push(Buffer.from([0]));
  return Buffer.concat(chunks);
}

function readName(buffer, start, depth = 0) {
  if (!Buffer.isBuffer(buffer) || depth > 8) return null;
  let offset = start;
  let nextOffset = start;
  let jumped = false;
  const labels = [];
  let guard = 0;
  while (offset < buffer.length && guard++ < 128) {
    const len = buffer[offset];
    if (len === 0) {
      if (!jumped) nextOffset = offset + 1;
      return { name: `${labels.join('.').toLowerCase()}.`, nextOffset };
    }
    if ((len & 0xc0) === 0xc0) {
      if (offset + 1 >= buffer.length) return null;
      const pointer = ((len & 0x3f) << 8) | buffer[offset + 1];
      if (!jumped) nextOffset = offset + 2;
      jumped = true;
      const pointed = readName(buffer, pointer, depth + 1);
      if (!pointed) return null;
      labels.push(...pointed.name.replace(/\.$/, '').split('.').filter(Boolean));
      return { name: `${labels.join('.').toLowerCase()}.`, nextOffset };
    }
    if (len > 63 || offset + 1 + len > buffer.length) return null;
    labels.push(buffer.subarray(offset + 1, offset + 1 + len).toString('utf8'));
    offset += 1 + len;
    if (!jumped) nextOffset = offset;
  }
  return null;
}

function parseQuestions(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) return [];
  const qdcount = buffer.readUInt16BE(4);
  if (qdcount < 1 || qdcount > 32) return [];
  let offset = 12;
  const out = [];
  for (let i = 0; i < qdcount; i += 1) {
    const parsed = readName(buffer, offset);
    if (!parsed || parsed.nextOffset + 4 > buffer.length) return [];
    offset = parsed.nextOffset;
    const type = buffer.readUInt16BE(offset);
    const rawClass = buffer.readUInt16BE(offset + 2);
    offset += 4;
    out.push({ name: parsed.name, type, classCode: rawClass & 0x7fff, unicastResponse: Boolean(rawClass & 0x8000) });
  }
  return out;
}

function ipv4Bytes(address) {
  const parts = String(address || '').split('.').map(Number);
  if (parts.length !== 4 || parts.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return Buffer.from(parts);
}

function buildAAnswer(address, { ttl = TTL_SECONDS } = {}) {
  const ip = ipv4Bytes(address);
  if (!ip) throw new Error('MDNS_ADDRESS_INVALID');
  const name = encodeName(HOST_FQDN);
  const header = Buffer.alloc(12);
  header.writeUInt16BE(0, 0);
  header.writeUInt16BE(0x8400, 2); // response + authoritative
  header.writeUInt16BE(0, 4);
  header.writeUInt16BE(1, 6);
  header.writeUInt16BE(0, 8);
  header.writeUInt16BE(0, 10);
  const rr = Buffer.alloc(10);
  rr.writeUInt16BE(1, 0); // A
  rr.writeUInt16BE(0x8001, 2); // cache flush + IN
  rr.writeUInt32BE(Math.max(1, Number(ttl) || TTL_SECONDS), 4);
  rr.writeUInt16BE(4, 8);
  return Buffer.concat([header, name, rr, ip]);
}

function buildAQuery({ unicastResponse = false } = {}) {
  const header = Buffer.alloc(12);
  header.writeUInt16BE(0, 0);
  header.writeUInt16BE(0, 2);
  header.writeUInt16BE(1, 4);
  const question = Buffer.alloc(4);
  question.writeUInt16BE(1, 0);
  question.writeUInt16BE(unicastResponse ? 0x8001 : 1, 2);
  return Buffer.concat([header, encodeName(HOST_FQDN), question]);
}

function currentAddress() {
  const status = getNetworkStatus();
  if (status?.available && ipv4Bytes(status.address)) return status.address;
  const candidate = getLanAddresses().find((item) => !item.virtual && ipv4Bytes(item.address));
  return candidate?.address || null;
}

function shouldAnswer(message) {
  return parseQuestions(message).some((q) => q.name === HOST_FQDN && q.classCode === 1 && (q.type === 1 || q.type === 255));
}

function refreshMemberships() {
  if (!socket) return;
  for (const candidate of getLanAddresses()) {
    if (candidate.virtual || !ipv4Bytes(candidate.address) || memberships.has(candidate.address)) continue;
    try {
      socket.addMembership(MDNS_GROUP, candidate.address);
      memberships.add(candidate.address);
    } catch (error) {
      logger.warn('MDNS', 'No se pudo unir mDNS a una interfaz LAN.', { address: candidate.address, code: error?.code || null });
    }
  }
}

function onNetworkChange() { refreshMemberships(); }

function onMessage(message, rinfo) {
  updateState({ queries: state.queries + 1, lastQueryAt: new Date().toISOString() });
  if (!shouldAnswer(message)) return;
  const address = currentAddress();
  if (!address || !socket) return;
  const answer = buildAAnswer(address);
  const query = parseQuestions(message).find((q) => q.name === HOST_FQDN && q.classCode === 1 && (q.type === 1 || q.type === 255));
  const targets = [{ address: String(rinfo?.address || ''), port: Number(rinfo?.port || MDNS_PORT) }];
  if (!query?.unicastResponse) targets.push({ address: MDNS_GROUP, port: MDNS_PORT });
  const unique = targets.filter((target, index, all) => target.address && all.findIndex((item) => item.address === target.address && item.port === target.port) === index);
  for (const target of unique) {
    socket.send(answer, target.port, target.address, (error) => {
      if (error) {
        updateState({ lastError: error.code || error.message || 'MDNS_SEND_ERROR' });
        return;
      }
      updateState({ answers: state.answers + 1, lastAnswerAt: new Date().toISOString(), lastAddress: address, lastError: null });
    });
  }
}

async function startMdnsHost({ port = MDNS_PORT, host = '0.0.0.0' } = {}) {
  if (socket) return getMdnsStatus();
  return new Promise((resolve, reject) => {
    const candidate = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    let settled = false;
    candidate.on('message', onMessage);
    candidate.on('error', (error) => {
      if (socket === candidate) socket = null;
      updateState({ running: false, lastError: error.code || error.message || 'MDNS_ERROR' });
      logger.warn('MDNS', 'No se pudo mantener el nombre fijo de Warehouse en la LAN.', { code: error?.code || null, port });
      if (!settled) {
        settled = true;
        try { candidate.close(); } catch {}
        reject(error);
      }
    });
    candidate.bind(Number(port), host, () => {
      socket = candidate;
      try { socket.setMulticastTTL(255); } catch {}
      try { socket.setMulticastLoopback(false); } catch {}
      refreshMemberships();
      if (!listenerAttached) {
        networkEvents.on('change', onNetworkChange);
        listenerAttached = true;
      }
      settled = true;
      updateState({ running: true, port: Number(port), startedAt: new Date().toISOString(), lastError: null });
      logger.info('MDNS', 'Nombre fijo de Warehouse disponible en la LAN.', { hostname: HOST_LABEL, port: Number(port) });
      resolve(getMdnsStatus());
    });
  });
}

async function stopMdnsHost() {
  if (listenerAttached) {
    networkEvents.off('change', onNetworkChange);
    listenerAttached = false;
  }
  const active = socket;
  socket = null;
  memberships = new Set();
  if (active) await new Promise((resolve) => { try { active.close(resolve); } catch { resolve(); } });
  updateState({ running: false, startedAt: null });
}

module.exports = {
  MDNS_GROUP,
  MDNS_PORT,
  HOST_LABEL,
  HOST_FQDN,
  encodeName,
  readName,
  parseQuestions,
  buildAAnswer,
  buildAQuery,
  shouldAnswer,
  getMdnsStatus,
  startMdnsHost,
  stopMdnsHost
};
