'use strict';

const dgram = require('node:dgram');
const runtime = require('../config/runtime');
const logger = require('./logger');
const { getNetworkStatus, normalizeIpAddress, isIpv4Private } = require('./network-service');
const { getServerIdentity } = require('./server-identity-service');

const DISCOVERY_PROTOCOL = 'IWC_DISCOVERY_V1';
const DISCOVERY_MAGIC = 'INGAR_WAREHOUSE_DISCOVERY';
const DISCOVERY_TYPE = 'DISCOVER';
const OFFER_TYPE = 'OFFER';
const MAX_DATAGRAM_BYTES = 768;
const RATE_WINDOW_MS = 5_000;
const RATE_MAX_PER_WINDOW = 20;
const ACCESS_CAPABILITY = 'FIRST_ACCESS_IDENTIFIER_OPTIONAL_V1';
const UNIFIED_OPERATION_CAPABILITY = 'WAREHOUSE_C2_UNIFIED_OPERATION_V1';
const SINGLE_SESSION_CAPABILITY = 'WAREHOUSE_C2_SINGLE_SESSION_V1';
const BUILD_REVISION = 'C4R1PER1';

let socket = null;
let currentState = Object.freeze({
  running: false,
  port: Number(runtime.discoveryPort),
  host: '0.0.0.0',
  startedAt: null,
  probesReceived: 0,
  offersSent: 0,
  rejectedPackets: 0,
  rateLimitedPackets: 0,
  lastProbeAt: null,
  lastOfferAt: null,
  lastError: null
});
const rateByAddress = new Map();

function nowIso() {
  return new Date().toISOString();
}

function setState(patch) {
  currentState = Object.freeze({ ...currentState, ...patch });
  return getLanDiscoveryStatus();
}

function getLanDiscoveryStatus() {
  return { ...currentState };
}

function isAllowedRemoteAddress(address) {
  const normalized = normalizeIpAddress(address);
  if (process.env.IWC_TEST_MODE === '1' && normalized === '127.0.0.1') return true;
  return isIpv4Private(normalized);
}

function validNonce(value) {
  return /^[A-Za-z0-9._:-]{8,96}$/.test(String(value || ''));
}

function parseDiscoveryProbe(message) {
  if (!Buffer.isBuffer(message) || message.length < 2 || message.length > MAX_DATAGRAM_BYTES) return null;
  let payload;
  try {
    payload = JSON.parse(message.toString('utf8'));
  } catch {
    return null;
  }
  if (payload?.magic !== DISCOVERY_MAGIC) return null;
  if (payload?.protocol !== DISCOVERY_PROTOCOL) return null;
  if (payload?.type !== DISCOVERY_TYPE) return null;
  if (!validNonce(payload?.nonce)) return null;
  return Object.freeze({ nonce: String(payload.nonce) });
}

function rateAllowed(address, now = Date.now()) {
  const key = normalizeIpAddress(address);
  const previous = rateByAddress.get(key);
  if (!previous || now - previous.startedAt >= RATE_WINDOW_MS) {
    rateByAddress.set(key, { startedAt: now, count: 1 });
    return true;
  }
  previous.count += 1;
  if (previous.count > RATE_MAX_PER_WINDOW) return false;
  return true;
}

function getDiscoveryIdentity() {
  const network = getNetworkStatus();
  const identity = getServerIdentity();
  const httpPort = Number(network?.port || runtime.port);
  return Object.freeze({
    status: network?.available === true ? 'READY' : 'DEGRADED',
    product: 'INGAR Warehouse',
    productCode: 'INGAR_WAREHOUSE',
    protocol: DISCOVERY_PROTOCOL,
    protocolVersion: 1,
    instanceId: identity.instanceId,
    identityPersistent: identity.persistent === true,
    version: runtime.sourceVersion,
    buildRevision: BUILD_REVISION,
    capabilities: [ACCESS_CAPABILITY, UNIFIED_OPERATION_CAPABILITY, SINGLE_SESSION_CAPABILITY],
    transport: 'HTTP',
    httpPort: Number.isInteger(httpPort) ? httpPort : Number(runtime.port),
    discoveryUdpPort: Number(runtime.discoveryPort),
    identityPath: '/api/v1/discovery/identity',
    healthPath: '/api/v1/health/live',
    // La entrada móvil canónica reutiliza el login general y conserva el destino solicitado.
    operationalEntryPath: '/mi-operacion'
  });
}

function buildOffer(nonce) {
  return {
    magic: DISCOVERY_MAGIC,
    protocol: DISCOVERY_PROTOCOL,
    type: OFFER_TYPE,
    nonce,
    ...getDiscoveryIdentity()
  };
}

function pruneRateMap(now = Date.now()) {
  if (rateByAddress.size < 128) return;
  for (const [address, item] of rateByAddress.entries()) {
    if (now - item.startedAt > RATE_WINDOW_MS * 2) rateByAddress.delete(address);
  }
  if (rateByAddress.size > 512) {
    const ordered = [...rateByAddress.entries()].sort((a, b) => a[1].startedAt - b[1].startedAt);
    for (const [address] of ordered.slice(0, rateByAddress.size - 512)) rateByAddress.delete(address);
  }
}

function onMessage(message, rinfo) {
  const receivedAt = nowIso();
  setState({ probesReceived: currentState.probesReceived + 1, lastProbeAt: receivedAt });
  if (!isAllowedRemoteAddress(rinfo?.address)) {
    setState({ rejectedPackets: currentState.rejectedPackets + 1 });
    return;
  }
  const probe = parseDiscoveryProbe(message);
  if (!probe) {
    setState({ rejectedPackets: currentState.rejectedPackets + 1 });
    return;
  }
  if (!rateAllowed(rinfo.address)) {
    setState({ rateLimitedPackets: currentState.rateLimitedPackets + 1 });
    return;
  }
  pruneRateMap();

  const identity = getDiscoveryIdentity();
  if (identity.status !== 'READY') return;
  const response = Buffer.from(JSON.stringify(buildOffer(probe.nonce)), 'utf8');
  if (response.length > 1024 || !socket) return;
  socket.send(response, 0, response.length, rinfo.port, rinfo.address, (error) => {
    if (error) {
      setState({ lastError: error.code || error.message || 'UDP_SEND_ERROR' });
      return;
    }
    setState({ offersSent: currentState.offersSent + 1, lastOfferAt: nowIso(), lastError: null });
  });
}

async function startLanDiscovery({ port = runtime.discoveryPort, host = '0.0.0.0' } = {}) {
  if (socket) return getLanDiscoveryStatus();
  const numericPort = Number(port);
  if (!Number.isInteger(numericPort) || numericPort < 1 || numericPort > 65535) throw new Error('DISCOVERY_PORT_INVALID');

  return new Promise((resolve, reject) => {
    const candidate = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    let settled = false;

    candidate.on('message', onMessage);
    candidate.on('error', (error) => {
      if (socket === candidate) socket = null;
      setState({ running: false, lastError: error.code || error.message || 'UDP_ERROR' });
      logger.warn('DISCOVERY', 'Fallo del descubrimiento LAN UDP.', { code: error.code || null, port: numericPort });
      if (!settled) {
        settled = true;
        try { candidate.close(); } catch {}
        reject(error);
      }
    });
    candidate.bind(numericPort, host, () => {
      socket = candidate;
      try { socket.setBroadcast(true); } catch {}
      settled = true;
      setState({
        running: true,
        port: numericPort,
        host,
        startedAt: nowIso(),
        lastError: null
      });
      logger.info('DISCOVERY', 'Descubrimiento LAN UDP disponible.', {
        protocol: DISCOVERY_PROTOCOL,
        port: numericPort,
        httpPort: getDiscoveryIdentity().httpPort
      });
      resolve(getLanDiscoveryStatus());
    });
  });
}

async function stopLanDiscovery() {
  const active = socket;
  socket = null;
  rateByAddress.clear();
  if (active) {
    await new Promise((resolve) => {
      try { active.close(resolve); } catch { resolve(); }
    });
  }
  setState({ running: false, startedAt: null });
}

function buildDiscoveryProbe(nonce) {
  if (!validNonce(nonce)) throw new Error('DISCOVERY_NONCE_INVALID');
  return Buffer.from(JSON.stringify({
    magic: DISCOVERY_MAGIC,
    protocol: DISCOVERY_PROTOCOL,
    type: DISCOVERY_TYPE,
    nonce
  }), 'utf8');
}

module.exports = {
  DISCOVERY_PROTOCOL,
  DISCOVERY_MAGIC,
  DISCOVERY_TYPE,
  OFFER_TYPE,
  MAX_DATAGRAM_BYTES,
  getDiscoveryIdentity,
  getLanDiscoveryStatus,
  parseDiscoveryProbe,
  buildDiscoveryProbe,
  buildOffer,
  startLanDiscovery,
  stopLanDiscovery
};
