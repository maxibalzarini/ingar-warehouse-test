'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb, transaction } = require('../db/database');
const { sha256 } = require('../security/tokens');
const { appendAudit } = require('./audit-service');
const { hasPermission } = require('./permission-service');
const { userHasScope, permissionAssignments } = require('../security/scope');
const { isProtectedBuffer, protectBuffer, unprotectBuffer, atomicWrite } = require('../security/data-protection');

const MIME_EXTENSIONS = Object.freeze({
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/webp': '.webp',
  'application/pdf': '.pdf',
  'text/csv': '.csv',
  'text/plain': '.txt',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx'
});
const OWNER_EXISTS_QUERIES = Object.freeze({
  MANAGEMENT_ACTION: 'SELECT 1 FROM management_action WHERE id=?',
  ASSET: 'SELECT 1 FROM asset WHERE id=? AND deleted_at IS NULL',
  INCIDENT: 'SELECT 1 FROM incident WHERE id=?',
  IMPORT_BATCH: 'SELECT 1 FROM import_batch WHERE id=?',
  PERSON: 'SELECT 1 FROM person WHERE id=? AND deleted_at IS NULL',
  HANDOVER: 'SELECT 1 FROM handover WHERE id=?',
  REQUEST: 'SELECT 1 FROM "request" WHERE id=?',
  CUSTODY: 'SELECT 1 FROM custody WHERE id=?',
  ORGANIZATION: 'SELECT 1 FROM organization WHERE id=? AND active=1'
});

function assertEvidenceOwnerExists(db, ownerType, ownerId) {
  const query = OWNER_EXISTS_QUERIES[ownerType];
  if (!query || !db.prepare(query).get(ownerId)) {
    throw evidenceError('El propietario de la evidencia no existe o no está habilitado.', 'EVIDENCE_OWNER_NOT_FOUND', 422);
  }
}


function evidenceError(message, code, status = 422) {
  return Object.assign(new Error(message), { code, status });
}

function sanitizeFilename(value, fallback) {
  const normalized = String(value || fallback || 'archivo').normalize('NFKC').replace(/[\\/:*?"<>|\u0000-\u001F]/g, '_').trim();
  return normalized.slice(0, 180) || fallback || 'archivo';
}

function parseDataUrl(dataUrl) {
  const match = String(dataUrl || '').match(/^data:([A-Za-z0-9.+/-]+);base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!match) throw evidenceError('Archivo inválido: se requiere contenido base64 en Data URL.', 'EVIDENCE_INVALID');
  const mimeType = match[1].toLowerCase();
  if (!MIME_EXTENSIONS[mimeType]) throw evidenceError('Tipo de archivo no admitido.', 'EVIDENCE_MIME_INVALID');
  const bytes = Buffer.from(match[2].replace(/\s/g, ''), 'base64');
  return { mimeType, bytes };
}

function validateEvidenceInput(input, options = {}) {
  const { mimeType, bytes } = parseDataUrl(input.dataUrl);
  const allowedMimeTypes = options.allowedMimeTypes || Object.keys(MIME_EXTENSIONS);
  if (!allowedMimeTypes.includes(mimeType)) throw evidenceError('Tipo de archivo no admitido para esta operación.', 'EVIDENCE_MIME_INVALID');
  const maxBytes = options.maxBytes || runtime.maxDocumentBytes;
  if (!bytes.length || bytes.length > maxBytes) throw evidenceError(`El archivo supera el límite de ${Math.floor(maxBytes / 1024)} KiB.`, 'EVIDENCE_TOO_LARGE', 413);
  return { mimeType, bytes };
}

function stageEvidenceDataUrl(input, options = {}) {
  const { mimeType, bytes } = validateEvidenceInput(input, options);
  const id = randomUUID();
  const extension = MIME_EXTENSIONS[mimeType];
  const storedName = `${id}${extension}.iwcenc`;
  const stagingDir = path.join(runtime.evidenceDir, '.staging');
  const stagingName = `${id}-${randomUUID()}.tmp`;
  const stagingPath = path.join(stagingDir, stagingName);
  const finalPath = path.join(runtime.evidenceDir, storedName);
  fs.mkdirSync(stagingDir, { recursive: true });
  fs.mkdirSync(runtime.evidenceDir, { recursive: true });
  fs.writeFileSync(stagingPath, protectBuffer(bytes, { purpose: 'EVIDENCE_FILE' }), { flag: 'wx', mode: 0o600 });
  return {
    id,
    bytes,
    mimeType,
    size: bytes.length,
    sha256: sha256(bytes),
    filename: sanitizeFilename(input.originalFilename, storedName),
    storedName,
    stagingPath,
    finalPath
  };
}

function cleanupStagedEvidence(staged) {
  if (!staged) return;
  fs.rmSync(staged.stagingPath, { force: true });
  fs.rmSync(staged.finalPath, { force: true });
}

function finalizeStagedEvidence(staged) {
  if (!fs.existsSync(staged.stagingPath)) throw evidenceError('El archivo temporal de evidencia no existe.', 'EVIDENCE_STAGING_MISSING', 500);
  fs.renameSync(staged.stagingPath, staged.finalPath);
}

function insertEvidenceRecord(db, staged, context, owner) {
  const state = owner.lifecycleState || 'ACTIVE';
  const ownerType = state === 'PENDING' ? 'UNASSIGNED' : String(owner.ownerType || '').toUpperCase();
  const ownerId = state === 'PENDING' ? null : owner.ownerId;
  if (state === 'ACTIVE' && (!ownerType || ownerType === 'UNASSIGNED' || !ownerId)) {
    throw evidenceError('El propietario interno de la evidencia es obligatorio.', 'EVIDENCE_OWNER_REQUIRED', 500);
  }
  const purpose = String(owner.purpose || (state === 'PENDING' ? 'PENDING_UPLOAD' : 'DOCUMENT')).slice(0, 120);
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO file_evidence(
      id, owner_type, owner_id, purpose, file_ref, filename, mime_type, size, sha256, created_at,
      created_by_user_id, lifecycle_state, original_owner_type, original_owner_id,
      claimed_by_user_id, claimed_at, activated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(
      staged.id, ownerType, ownerId, purpose, staged.storedName, staged.filename, staged.mimeType,
      staged.size, staged.sha256, now, context.user.id, state,
      state === 'ACTIVE' ? ownerType : null, state === 'ACTIVE' ? ownerId : null,
      state === 'ACTIVE' ? context.user.id : null, state === 'ACTIVE' ? now : null,
      state === 'ACTIVE' ? now : null
    );
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action: state === 'PENDING' ? 'EVIDENCE.UPLOAD_PENDING' : 'EVIDENCE.CREATE',
    entityType: 'file_evidence',
    entityId: staged.id,
    after: { ownerType, ownerId, purpose, lifecycleState: state, filename: staged.filename, mimeType: staged.mimeType, size: staged.size, sha256: staged.sha256 },
    correlationId: context.correlationId,
    source: 'API',
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
  return {
    id: staged.id,
    ownerType,
    ownerId,
    purpose,
    lifecycleState: state,
    filename: staged.filename,
    mimeType: staged.mimeType,
    size: staged.size,
    sha256: staged.sha256
  };
}

function withEvidenceTransaction(input, context, options, owner, work) {
  const staged = stageEvidenceDataUrl(input, options);
  let committed = false;
  try {
    const result = transaction((db) => {
      finalizeStagedEvidence(staged);
      const evidence = insertEvidenceRecord(db, staged, context, owner);
      return work ? work(db, evidence) : evidence;
    });
    committed = true;
    return result;
  } finally {
    if (!committed) cleanupStagedEvidence(staged);
  }
}

function saveEvidenceDataUrl(input, context, options = {}) {
  // La carga genérica nunca acepta propietario controlado por el cliente.
  return withEvidenceTransaction(input, context, options, { lifecycleState: 'PENDING', purpose: 'PENDING_UPLOAD' });
}

function saveImageDataUrl(input, context) {
  return saveEvidenceDataUrl(input, context, { allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp'], maxBytes: runtime.maxImageBytes });
}

function saveOwnedEvidenceDataUrl(input, owner, context, options = {}, work = null) {
  return withEvidenceTransaction(input, context, options, { ...owner, lifecycleState: 'ACTIVE' }, work);
}

function claimEvidence(id, destination, context, db = getDb()) {
  const row = db.prepare('SELECT * FROM file_evidence WHERE id=?').get(id);
  if (!row) throw evidenceError('Evidencia no encontrada.', 'EVIDENCE_NOT_FOUND', 404);
  if (row.lifecycle_state !== 'PENDING' || row.owner_type !== 'UNASSIGNED' || row.owner_id !== null) {
    throw evidenceError('La evidencia ya tiene propietario y no puede relocalizarse.', 'EVIDENCE_ALREADY_CLAIMED', 409);
  }
  if (!row.created_by_user_id || row.created_by_user_id !== context.user.id) {
    throw evidenceError('Solo el usuario que cargó la evidencia puede vincularla.', 'EVIDENCE_CLAIM_FORBIDDEN', 403);
  }
  const ownerType = String(destination.ownerType || '').toUpperCase();
  const ownerId = destination.ownerId;
  if (!ownerType || ownerType === 'UNASSIGNED' || !ownerId) throw evidenceError('Destino de evidencia inválido.', 'EVIDENCE_OWNER_REQUIRED');
  assertEvidenceOwnerExists(db, ownerType, ownerId);
  const purpose = String(destination.purpose || 'DOCUMENT').slice(0, 120);
  const now = new Date().toISOString();
  const changed = db.prepare(`UPDATE file_evidence SET
      owner_type=?, owner_id=?, purpose=?, lifecycle_state='ACTIVE',
      original_owner_type=?, original_owner_id=?, claimed_by_user_id=?, claimed_at=?, activated_at=?
    WHERE id=? AND lifecycle_state='PENDING' AND owner_type='UNASSIGNED' AND owner_id IS NULL AND created_by_user_id=?`)
    .run(ownerType, ownerId, purpose, ownerType, ownerId, context.user.id, now, now, id, context.user.id);
  if (changed.changes !== 1) throw evidenceError('La evidencia fue vinculada por otra operación.', 'EVIDENCE_CLAIM_CONFLICT', 409);
  const after = db.prepare('SELECT * FROM file_evidence WHERE id=?').get(id);
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes.join(','),
    action: 'EVIDENCE.CLAIM',
    entityType: 'file_evidence',
    entityId: id,
    before: { ownerType: row.owner_type, ownerId: row.owner_id, lifecycleState: row.lifecycle_state },
    after: { ownerType, ownerId, purpose, lifecycleState: 'ACTIVE' },
    correlationId: context.correlationId,
    source: 'API',
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
  return after;
}

function createEvidenceReference(id, destination, context, suppliedDb = null) {
  const perform = (db) => {
    const row = db.prepare("SELECT * FROM file_evidence WHERE id=? AND lifecycle_state='ACTIVE'").get(id);
    if (!row) throw evidenceError('Evidencia activa no encontrada.', 'EVIDENCE_NOT_FOUND', 404);
    authorizeEvidence(row, context.user, db);
    const ownerType = String(destination.ownerType || '').toUpperCase();
    const ownerId = destination.ownerId;
    if (!ownerType || ownerType === 'UNASSIGNED' || !ownerId) throw evidenceError('Destino de referencia inválido.', 'EVIDENCE_OWNER_REQUIRED');
    assertEvidenceOwnerExists(db, ownerType, ownerId);
    authorizeEvidence({ ...row, lifecycle_state: 'ACTIVE', owner_type: ownerType, owner_id: ownerId }, context.user, db);
    const referenceId = randomUUID();
    const now = new Date().toISOString();
    db.prepare(`INSERT INTO file_evidence_reference(id,evidence_id,owner_type,owner_id,purpose,created_by_user_id,created_at)
      VALUES (?,?,?,?,?,?,?)`).run(referenceId, id, ownerType, ownerId, String(destination.purpose || 'REFERENCE').slice(0, 120), context.user.id, now);
    appendAudit({
      actorUserId: context.user.id,
      actorRole: context.user.roleCodes.join(','),
      action: 'EVIDENCE.REFERENCE_CREATE',
      entityType: 'file_evidence_reference',
      entityId: referenceId,
      after: { evidenceId: id, ownerType, ownerId, purpose: destination.purpose },
      correlationId: context.correlationId,
      source: 'API',
      ipAddress: context.ip,
      equipment: context.userAgent
    }, db);
    return db.prepare('SELECT * FROM file_evidence_reference WHERE id=?').get(referenceId);
  };
  return suppliedDb ? perform(suppliedDb) : transaction(perform);
}

function evidenceForbidden() {
  return evidenceError('La evidencia está fuera del alcance asignado.', 'SCOPE_FORBIDDEN', 403);
}

function hasGlobalPermissionScope(user, permission, db) {
  return hasPermission(user, permission) && permissionAssignments(user, permission, db).some((scope) => !scope.site_id && !scope.location_id);
}

function userScopeIntersectsPerson(user, personId, permission, db) {
  if (hasGlobalPermissionScope(user, permission, db)) return true;
  const targetScopes = db.prepare(`SELECT urs.site_id,urs.location_id FROM user_account ua
    JOIN user_role_scope urs ON urs.user_id=ua.id
    WHERE ua.person_id=? AND ua.deleted_at IS NULL AND ua.active=1`).all(personId);
  return targetScopes.some((scope) => userHasScope(user, scope.site_id, scope.location_id, permission, db));
}

function authorizeEvidence(row, user, db) {
  if (!user || row.lifecycle_state !== 'ACTIVE') throw evidenceForbidden();
  if (row.owner_type === 'PERSON' && row.purpose === 'PHOTO' && row.owner_id === user.personId) return;
  switch (row.owner_type) {
    case 'MANAGEMENT_ACTION': {
      if (!hasPermission(user, 'Actions.Read')) throw evidenceForbidden();
      const action = db.prepare('SELECT scope_type,site_id,location_id FROM management_action WHERE id=?').get(row.owner_id);
      if (!action) throw evidenceForbidden();
      if (action.scope_type === 'GLOBAL') {
        if (!hasGlobalPermissionScope(user, 'Actions.Read', db)) throw evidenceForbidden();
      } else if (!userHasScope(user, action.site_id, action.location_id, 'Actions.Read', db)) throw evidenceForbidden();
      return;
    }
    case 'ASSET': {
      if (!hasPermission(user, 'Assets.Read')) throw evidenceForbidden();
      const asset = db.prepare('SELECT sl.site_id,a.location_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=? AND a.deleted_at IS NULL').get(row.owner_id);
      if (!asset || !userHasScope(user, asset.site_id, asset.location_id, 'Assets.Read', db)) throw evidenceForbidden();
      return;
    }
    case 'INCIDENT': {
      if (!hasPermission(user, 'Incident.Read')) throw evidenceForbidden();
      const incident = db.prepare('SELECT sl.site_id,a.location_id FROM incident i JOIN asset a ON a.id=i.asset_id JOIN storage_location sl ON sl.id=a.location_id WHERE i.id=?').get(row.owner_id);
      if (!incident || !userHasScope(user, incident.site_id, incident.location_id, 'Incident.Read', db)) throw evidenceForbidden();
      return;
    }
    case 'IMPORT_BATCH': {
      if (!hasPermission(user, 'Import.Read')) throw evidenceForbidden();
      const rows = db.prepare('SELECT normalized_json,before_json,resulting_entity_id FROM import_row WHERE batch_id=?').all(row.owner_id);
      if (!rows.length) throw evidenceForbidden();
      const allowed = rows.every((item) => {
        try {
          const normalized = item.normalized_json ? JSON.parse(item.normalized_json) : null;
          if (normalized?.siteId && normalized?.locationId) return userHasScope(user, normalized.siteId, normalized.locationId, 'Import.Read', db);
          if (normalized?.locationId) {
            const location = db.prepare('SELECT site_id FROM storage_location WHERE id=?').get(normalized.locationId);
            return Boolean(location && userHasScope(user, location.site_id, normalized.locationId, 'Import.Read', db));
          }
          const before = item.before_json ? JSON.parse(item.before_json) : null;
          const assetId = item.resulting_entity_id || before?.id;
          const asset = assetId ? db.prepare('SELECT sl.site_id,a.location_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=?').get(assetId) : null;
          return Boolean(asset && userHasScope(user, asset.site_id, asset.location_id, 'Import.Read', db));
        } catch { return false; }
      });
      if (!allowed) throw evidenceForbidden();
      return;
    }
    case 'PERSON':
      if (!hasPermission(user, 'Users.Read') || !userScopeIntersectsPerson(user, row.owner_id, 'Users.Read', db)) throw evidenceForbidden();
      return;
    case 'HANDOVER': {
      const handover = db.prepare(`SELECT r.site_id,r.location_id FROM handover h JOIN request r ON r.id=h.request_id WHERE h.id=?`).get(row.owner_id);
      if (!handover) throw evidenceForbidden();
      const permission = hasPermission(user, 'Custody.ReadAll') ? 'Custody.ReadAll' : hasPermission(user, 'Warehouse.Operate') ? 'Warehouse.Operate' : null;
      if (!permission || !userHasScope(user, handover.site_id, handover.location_id, permission, db)) throw evidenceForbidden();
      return;
    }
    case 'ORGANIZATION':
      if (!hasPermission(user, 'Config.Read') && !hasPermission(user, 'Users.Read')) throw evidenceForbidden();
      return;
    default:
      throw evidenceForbidden();
  }
}

function getEvidence(id, user) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM file_evidence WHERE id = ?').get(id);
  if (!row) return null;
  authorizeEvidence(row, user, db);
  const fullPath = path.resolve(runtime.evidenceDir, row.file_ref);
  if (!fullPath.startsWith(path.resolve(runtime.evidenceDir) + path.sep) || !fs.existsSync(fullPath)) return null;
  const stored = fs.readFileSync(fullPath);
  const bytes = isProtectedBuffer(stored)
    ? unprotectBuffer(stored, { purpose: 'EVIDENCE_FILE' }).bytes
    : stored;
  return { metadata: row, bytes };
}

// F29: lectura interna estricta por propietario. La autorización de negocio se
// realiza antes de llamar a esta función; aquí se impide que un ID de evidencia
// distinto pueda usarse para leer archivos de otro objeto.
function getOwnedEvidence(id, ownerType, ownerId, purpose = null) {
  const db = getDb();
  const row = db.prepare(`SELECT * FROM file_evidence
    WHERE id=? AND lifecycle_state='ACTIVE' AND owner_type=? AND owner_id=?`).get(id, String(ownerType || '').toUpperCase(), ownerId);
  if (!row) return null;
  if (purpose && row.purpose !== purpose) return null;
  const fullPath = path.resolve(runtime.evidenceDir, row.file_ref);
  if (!fullPath.startsWith(path.resolve(runtime.evidenceDir) + path.sep) || !fs.existsSync(fullPath)) return null;
  const stored = fs.readFileSync(fullPath);
  const bytes = isProtectedBuffer(stored)
    ? unprotectBuffer(stored, { purpose: 'EVIDENCE_FILE' }).bytes
    : stored;
  return { metadata: row, bytes };
}

function reconcileEvidenceStorage(context, options = {}) {
  const db = getDb();
  const quarantineDir = path.join(runtime.evidenceDir, '.quarantine');
  const stagingDir = path.join(runtime.evidenceDir, '.staging');
  fs.mkdirSync(runtime.evidenceDir, { recursive: true });
  fs.mkdirSync(quarantineDir, { recursive: true });
  fs.mkdirSync(stagingDir, { recursive: true });
  const pendingMaxAgeHours = Number.isFinite(Number(options.pendingMaxAgeHours)) ? Math.max(1, Number(options.pendingMaxAgeHours)) : 24;
  const cutoffMs = Date.now() - pendingMaxAgeHours * 3600_000;
  const pendingCutoff = new Date(cutoffMs).toISOString();
  const expiredPendingRows = db.prepare("SELECT id,file_ref FROM file_evidence WHERE lifecycle_state='PENDING' AND created_at<?").all(pendingCutoff);
  if (expiredPendingRows.length) {
    transaction((tx) => {
      for (const row of expiredPendingRows) tx.prepare("DELETE FROM file_evidence WHERE id=? AND lifecycle_state='PENDING'").run(row.id);
      if (context) appendAudit({
        actorUserId: context.user.id,
        actorRole: context.user.roleCodes.join(','),
        action: 'EVIDENCE.PENDING_EXPIRE',
        entityType: 'file_evidence',
        entityId: 'PENDING',
        after: { ids: expiredPendingRows.map((row) => row.id), pendingMaxAgeHours },
        correlationId: context.correlationId,
        source: 'SYSTEM',
        ipAddress: context.ip,
        equipment: context.userAgent
      }, tx);
    });
    for (const row of expiredPendingRows) fs.rmSync(path.join(runtime.evidenceDir, row.file_ref), { force: true });
  }
  const staleStaging = fs.readdirSync(stagingDir, { withFileTypes: true })
    .filter((entry) => entry.isFile())
    .filter((entry) => {
      try { return fs.statSync(path.join(stagingDir, entry.name)).mtimeMs < cutoffMs; } catch { return false; }
    })
    .map((entry) => entry.name);
  const known = new Map(db.prepare('SELECT id,file_ref,lifecycle_state FROM file_evidence').all().map((row) => [row.file_ref, row]));
  const dbMissingFiles = [];
  const encryptedLegacyFiles = [];
  const physicalOrphans = [];
  const entries = fs.readdirSync(runtime.evidenceDir, { withFileTypes: true })
    .filter((entry) => entry.isFile())
    .map((entry) => entry.name);
  for (const row of known.values()) {
    const fullPath = path.join(runtime.evidenceDir, row.file_ref);
    if (!fs.existsSync(fullPath)) {
      dbMissingFiles.push(row);
      continue;
    }
    const stored = fs.readFileSync(fullPath);
    if (!isProtectedBuffer(stored)) {
      atomicWrite(fullPath, protectBuffer(stored, { purpose: 'EVIDENCE_FILE' }));
      encryptedLegacyFiles.push(row.id);
    } else {
      unprotectBuffer(stored, { purpose: 'EVIDENCE_FILE' });
    }
  }
  for (const name of entries) if (!known.has(name)) physicalOrphans.push(name);
  if (options.quarantine !== false) {
    transaction((tx) => {
      const now = new Date().toISOString();
      for (const row of dbMissingFiles) {
        tx.prepare(`UPDATE file_evidence SET lifecycle_state='QUARANTINED',quarantined_at=?,quarantine_reason=? WHERE id=? AND lifecycle_state<>'QUARANTINED'`)
          .run(now, 'FILE_MISSING', row.id);
      }
      if (context) appendAudit({
        actorUserId: context.user.id,
        actorRole: context.user.roleCodes.join(','),
        action: 'EVIDENCE.RECONCILE',
        entityType: 'file_evidence',
        entityId: 'STORAGE',
        after: { dbMissingFiles: dbMissingFiles.map((row) => row.id), physicalOrphans, staleStaging, expiredPending: expiredPendingRows.map((row) => row.id) },
        correlationId: context.correlationId,
        source: 'SYSTEM',
        ipAddress: context.ip,
        equipment: context.userAgent
      }, tx);
    });
    for (const name of physicalOrphans) {
      const source = path.join(runtime.evidenceDir, name);
      const target = path.join(quarantineDir, `${new Date().toISOString().replace(/[:.]/g, '-')}-${name}`);
      if (fs.existsSync(source)) {
        const stored = fs.readFileSync(source);
        if (!isProtectedBuffer(stored)) atomicWrite(source, protectBuffer(stored, { purpose: 'QUARANTINED_FILE' }));
        fs.renameSync(source, target);
      }
    }
    for (const name of staleStaging) {
      const source = path.join(stagingDir, name);
      const target = path.join(quarantineDir, `${new Date().toISOString().replace(/[:.]/g, '-')}-staging-${sanitizeFilename(name, 'staging.tmp')}`);
      if (fs.existsSync(source)) fs.renameSync(source, target);
    }
  }
  return {
    dbMissingFiles: dbMissingFiles.map((row) => row.id),
    physicalOrphans,
    staleStaging,
    expiredPending: expiredPendingRows.map((row) => row.id),
    encryptedLegacyFiles,
    clean: !dbMissingFiles.length && !physicalOrphans.length && !staleStaging.length
  };
}

module.exports = {
  saveEvidenceDataUrl,
  saveImageDataUrl,
  saveOwnedEvidenceDataUrl,
  stageEvidenceDataUrl,
  withEvidenceTransaction,
  claimEvidence,
  createEvidenceReference,
  getEvidence,
  getOwnedEvidence,
  reconcileEvidenceStorage,
  parseDataUrl,
  sanitizeFilename
};
