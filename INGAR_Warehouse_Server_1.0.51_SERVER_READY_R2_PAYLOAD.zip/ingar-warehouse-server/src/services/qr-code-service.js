'use strict';

// QR Code Model 2, versión 5-L, modo byte. Implementación local sin dependencias.
const VERSION = 5;
const SIZE = 17 + VERSION * 4;
const DATA_CODEWORDS = 108;
const ECC_CODEWORDS = 26;

function gfMultiply(x, y) {
  let z = 0;
  for (let i = 7; i >= 0; i--) {
    z = (z << 1) ^ ((z >>> 7) * 0x11D);
    z ^= ((y >>> i) & 1) * x;
  }
  return z;
}

function reedSolomonDivisor(degree) {
  const result = new Uint8Array(degree); result[degree - 1] = 1;
  let root = 1;
  for (let i = 0; i < degree; i++) {
    for (let j = 0; j < result.length; j++) {
      result[j] = gfMultiply(result[j], root);
      if (j + 1 < result.length) result[j] ^= result[j + 1];
    }
    root = gfMultiply(root, 2);
  }
  return result;
}

function reedSolomonRemainder(data, divisor) {
  const result = new Uint8Array(divisor.length);
  for (const byte of data) {
    const factor = byte ^ result[0];
    result.copyWithin(0, 1); result[result.length - 1] = 0;
    for (let i = 0; i < result.length; i++) result[i] ^= gfMultiply(divisor[i], factor);
  }
  return result;
}

function appendBits(value, length, bits) {
  if (length < 0 || length > 31 || (value >>> length) !== 0) throw new RangeError('Bits QR inválidos.');
  for (let i = length - 1; i >= 0; i--) bits.push((value >>> i) & 1);
}

function encodeData(text) {
  const bytes = Buffer.from(String(text), 'utf8');
  if (bytes.length > 106) throw Object.assign(new Error('La URL supera la capacidad QR local.'), { status: 422, code: 'QR_URL_TOO_LONG' });
  const bits = [];
  appendBits(0x4, 4, bits); appendBits(bytes.length, 8, bits);
  for (const byte of bytes) appendBits(byte, 8, bits);
  const capacity = DATA_CODEWORDS * 8;
  appendBits(0, Math.min(4, capacity - bits.length), bits);
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(bits.slice(i, i + 8).reduce((a, b) => (a << 1) | b, 0));
  for (let pad = 0xEC; data.length < DATA_CODEWORDS; pad ^= 0xEC ^ 0x11) data.push(pad);
  const ecc = [...reedSolomonRemainder(Uint8Array.from(data), reedSolomonDivisor(ECC_CODEWORDS))];
  return Uint8Array.from([...data, ...ecc]);
}

function emptyMatrix() {
  return { modules: Array.from({ length: SIZE }, () => Array(SIZE).fill(false)), functionModules: Array.from({ length: SIZE }, () => Array(SIZE).fill(false)) };
}

function setFunction(m, x, y, dark) {
  if (x >= 0 && x < SIZE && y >= 0 && y < SIZE) { m.modules[y][x] = dark; m.functionModules[y][x] = true; }
}

function drawFinder(m, cx, cy) {
  for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
    const dist = Math.max(Math.abs(dx), Math.abs(dy));
    setFunction(m, cx + dx, cy + dy, dist !== 2 && dist !== 4);
  }
}

function drawAlignment(m, cx, cy) {
  for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setFunction(m, cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
}

function drawFunctionPatterns(m) {
  for (let i = 0; i < SIZE; i++) { setFunction(m, 6, i, i % 2 === 0); setFunction(m, i, 6, i % 2 === 0); }
  drawFinder(m, 3, 3); drawFinder(m, SIZE - 4, 3); drawFinder(m, 3, SIZE - 4);
  drawAlignment(m, 30, 30);
  for (let i = 0; i < 9; i++) { if (i !== 6) { setFunction(m, 8, i, false); setFunction(m, i, 8, false); } }
  for (let i = 0; i < 8; i++) { setFunction(m, SIZE - 1 - i, 8, false); setFunction(m, 8, SIZE - 1 - i, false); }
  setFunction(m, 8, SIZE - 8, true);
}

function maskBit(mask, x, y) {
  switch (mask) {
    case 0: return (x + y) % 2 === 0;
    case 1: return y % 2 === 0;
    case 2: return x % 3 === 0;
    case 3: return (x + y) % 3 === 0;
    case 4: return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
    case 5: return (x * y) % 2 + (x * y) % 3 === 0;
    case 6: return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
    case 7: return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
    default: throw new RangeError('Máscara QR inválida.');
  }
}

function drawCodewords(m, codewords, mask) {
  let bitIndex = 0;
  for (let right = SIZE - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < SIZE; vert++) {
      const y = ((right + 1) & 2) === 0 ? SIZE - 1 - vert : vert;
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        if (m.functionModules[y][x]) continue;
        const bit = bitIndex < codewords.length * 8 && ((codewords[bitIndex >>> 3] >>> (7 - (bitIndex & 7))) & 1) !== 0;
        m.modules[y][x] = bit !== maskBit(mask, x, y); bitIndex++;
      }
    }
  }
  if (bitIndex < codewords.length * 8) throw new Error('Longitud de datos QR insuficiente.');
}

function drawFormatBits(m, mask) {
  const data = (1 << 3) | mask; // Nivel L = 01
  let rem = data;
  for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
  const bits = ((data << 10) | rem) ^ 0x5412;
  const bit = (i) => ((bits >>> i) & 1) !== 0;
  for (let i = 0; i <= 5; i++) setFunction(m, 8, i, bit(i));
  setFunction(m, 8, 7, bit(6)); setFunction(m, 8, 8, bit(7)); setFunction(m, 7, 8, bit(8));
  for (let i = 9; i < 15; i++) setFunction(m, 14 - i, 8, bit(i));
  for (let i = 0; i < 8; i++) setFunction(m, SIZE - 1 - i, 8, bit(i));
  for (let i = 8; i < 15; i++) setFunction(m, 8, SIZE - 15 + i, bit(i));
  setFunction(m, 8, SIZE - 8, true);
}

function penalty(modules) {
  let score = 0;
  for (const row of modules) {
    let runColor = row[0], run = 1;
    for (let x = 1; x < SIZE; x++) { if (row[x] === runColor) run++; else { if (run >= 5) score += 3 + run - 5; runColor = row[x]; run = 1; } }
    if (run >= 5) score += 3 + run - 5;
  }
  for (let x = 0; x < SIZE; x++) {
    let runColor = modules[0][x], run = 1;
    for (let y = 1; y < SIZE; y++) { if (modules[y][x] === runColor) run++; else { if (run >= 5) score += 3 + run - 5; runColor = modules[y][x]; run = 1; } }
    if (run >= 5) score += 3 + run - 5;
  }
  for (let y = 0; y < SIZE - 1; y++) for (let x = 0; x < SIZE - 1; x++) {
    const c = modules[y][x]; if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) score += 3;
  }
  const pattern = '1011101';
  for (let y = 0; y < SIZE; y++) { const s = modules[y].map(Number).join(''); score += (s.includes(`0000${pattern}0`) || s.includes(`0${pattern}0000`)) ? 40 : 0; }
  for (let x = 0; x < SIZE; x++) { let s = ''; for (let y = 0; y < SIZE; y++) s += modules[y][x] ? '1' : '0'; score += (s.includes(`0000${pattern}0`) || s.includes(`0${pattern}0000`)) ? 40 : 0; }
  const dark = modules.flat().filter(Boolean).length; score += Math.floor(Math.abs(dark * 20 - SIZE * SIZE * 10) / (SIZE * SIZE)) * 10;
  return score;
}

function matrix(text) {
  const codewords = encodeData(text);
  let best = null;
  for (let mask = 0; mask < 8; mask++) {
    const m = emptyMatrix(); drawFunctionPatterns(m); drawCodewords(m, codewords, mask); drawFormatBits(m, mask);
    const score = penalty(m.modules); if (!best || score < best.score) best = { modules: m.modules, mask, score };
  }
  return best;
}

function svg(text, options = {}) {
  const result = matrix(text); const border = 4; const scale = Number(options.scale || 8); const total = (SIZE + border * 2) * scale;
  let path = '';
  for (let y = 0; y < SIZE; y++) for (let x = 0; x < SIZE; x++) if (result.modules[y][x]) path += `M${(x + border) * scale},${(y + border) * scale}h${scale}v${scale}h-${scale}z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${total}" height="${total}" viewBox="0 0 ${total} ${total}" role="img" aria-label="Código QR"><rect width="100%" height="100%" fill="#fff"/><path d="${path}" fill="#000"/></svg>`;
}

module.exports = { matrix, svg, VERSION, SIZE };
