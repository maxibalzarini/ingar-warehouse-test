'use strict';

const { randomUUID } = require('node:crypto');
const { appendAudit } = require('./audit-service');

const OPEN_CUSTODY_STATUSES = ['ABIERTA','DEVOLUCION_DECLARADA','RECEPCION_PENDIENTE','TRANSFERENCIA_PENDIENTE','INCIDENTE'];
const ACTIVE_INCIDENT_STATUSES = ['ABIERTO','EN_INVESTIGACION'];

function nowIso() { return new Date().toISOString(); }

function activePersonalAssignment(db, kitAssetId) {
  return db.prepare(`SELECT kpa.id,kpa.person_id
    FROM kit_person_assignment kpa
    JOIN asset ka ON ka.id=kpa.kit_asset_id
    WHERE kpa.kit_asset_id=? AND kpa.status='ACTIVE'
      AND ka.deleted_at IS NULL AND ka.active=1 AND ka.status<>'BAJA'
    ORDER BY kpa.assigned_at DESC LIMIT 1`).get(kitAssetId) || null;
}

function componentPhysicalState(db, componentAssetId) {
  return db.prepare(`SELECT a.id,a.internal_code,a.status,a.active,a.deleted_at,
      a.quantity_total,a.quantity_available,a.custodian_person_id
    FROM asset a WHERE a.id=?`).get(componentAssetId) || null;
}

function hasRealPhysicalBlocker(db, componentAssetId) {
  const now = nowIso();
  if (db.prepare("SELECT 1 FROM asset_reservation WHERE asset_id=? AND status='ACTIVA' AND expires_at>? LIMIT 1").get(componentAssetId, now)) return true;
  if (db.prepare(`SELECT 1 FROM custody WHERE asset_id=? AND status IN (${OPEN_CUSTODY_STATUSES.map(() => '?').join(',')}) LIMIT 1`).get(componentAssetId, ...OPEN_CUSTODY_STATUSES)) return true;
  if (db.prepare("SELECT 1 FROM operational_block WHERE target_type='ACTIVO' AND target_id=? AND status='ACTIVO' AND starts_at<=? AND (expires_at IS NULL OR expires_at>?) LIMIT 1").get(componentAssetId, now, now)) return true;
  if (db.prepare("SELECT 1 FROM maintenance_order WHERE asset_id=? AND status='EN_PROGRESO' LIMIT 1").get(componentAssetId)) return true;
  if (db.prepare(`SELECT 1 FROM incident WHERE asset_id=? AND status IN (${ACTIVE_INCIDENT_STATUSES.map(() => '?').join(',')}) LIMIT 1`).get(componentAssetId, ...ACTIVE_INCIDENT_STATUSES)) return true;
  return false;
}

function hasOtherActivePersonalKit(db, componentAssetId, excludedKitAssetId) {
  return Boolean(db.prepare(`SELECT 1
    FROM kit_component kc
    JOIN kit_person_assignment kpa
      ON kpa.kit_asset_id=kc.kit_asset_id AND kpa.status='ACTIVE'
    JOIN asset ka
      ON ka.id=kc.kit_asset_id AND ka.deleted_at IS NULL AND ka.active=1 AND ka.status<>'BAJA'
    WHERE kc.component_asset_id=? AND kc.active=1 AND kc.kit_asset_id<>?
    LIMIT 1`).get(componentAssetId, excludedKitAssetId));
}

function activeMembershipState(db, kitAssetId, componentAssetId) {
  return db.prepare(`SELECT * FROM kit_component_membership_state
    WHERE kit_asset_id=? AND component_asset_id=? AND active=1
    ORDER BY activated_at DESC LIMIT 1`).get(kitAssetId, componentAssetId) || null;
}

function captureMembershipInDb(db, kitAssetId, componentAssetId, at = nowIso()) {
  const existing = activeMembershipState(db, kitAssetId, componentAssetId);
  if (existing) return existing;
  const asset = componentPhysicalState(db, componentAssetId);
  if (!asset || asset.deleted_at) {
    const error = new Error('No puede registrarse la pertenencia de un componente inexistente.');
    error.status = 422; error.code = 'KIT_COMPONENT_NOT_FOUND';
    throw error;
  }
  const id = randomUUID();
  db.prepare(`INSERT INTO kit_component_membership_state(
    id,kit_asset_id,component_asset_id,baseline_quantity_available,baseline_status,
    baseline_custodian_person_id,active,activated_at,released_at,release_reason,
    version,created_at,updated_at
  ) VALUES (?,?,?,?,?,?,1,?,NULL,NULL,1,?,?)`).run(
    id, kitAssetId, componentAssetId, Number(asset.quantity_available), asset.status,
    asset.custodian_person_id || null, at, at, at
  );
  return activeMembershipState(db, kitAssetId, componentAssetId);
}

function auditReconciliation(db, context, kitAssetId, component, before, after, reason) {
  if (!context?.user?.id) return;
  appendAudit({
    actorUserId: context.user.id,
    actorRole: context.user.roleCodes?.join(',') || null,
    action: 'KIT.COMPONENT_PHYSICAL_STATE_RECONCILE',
    entityType: 'asset',
    entityId: component.id,
    before: { quantityAvailable: before, status: component.status, kitAssetId },
    after: { quantityAvailable: after, status: component.status, kitAssetId },
    reason,
    correlationId: context.correlationId,
    source: 'API',
    ipAddress: context.ip,
    equipment: context.userAgent
  }, db);
}

function reconcileActiveMembershipInDb(db, kitAssetId, componentAssetId, context, reason = 'Reconciliación de reserva lógica de kit') {
  const state = activeMembershipState(db, kitAssetId, componentAssetId);
  if (!state) return { reconciled: false, reason: 'NO_MEMBERSHIP_STATE' };
  const asset = componentPhysicalState(db, componentAssetId);
  if (!asset || asset.deleted_at || !asset.active) return { reconciled: false, reason: 'ASSET_INACTIVE' };
  if (asset.status !== 'DISPONIBLE') return { reconciled: false, reason: `STATUS_${asset.status}` };
  if (hasRealPhysicalBlocker(db, componentAssetId)) return { reconciled: false, reason: 'REAL_PHYSICAL_BLOCKER' };
  const baseline = Math.min(Number(asset.quantity_total), Number(state.baseline_quantity_available));
  const current = Number(asset.quantity_available);
  if (!(baseline > current)) return { reconciled: false, reason: 'NO_QUANTITY_DRIFT' };
  const at = nowIso();
  const changed = db.prepare(`UPDATE asset
    SET quantity_available=?,version=version+1,updated_at=?
    WHERE id=? AND version=(SELECT version FROM asset WHERE id=?)`).run(baseline, at, componentAssetId, componentAssetId);
  if (changed.changes === 1) {
    const updated = componentPhysicalState(db, componentAssetId);
    auditReconciliation(db, context, kitAssetId, asset, current, Number(updated.quantity_available), reason);
    return { reconciled: true, from: current, to: Number(updated.quantity_available) };
  }
  return { reconciled: false, reason: 'CONCURRENCY_CONFLICT' };
}

function releaseMembershipInDb(db, kitAssetId, componentAssetId, context, reason = 'Componente liberado del kit') {
  const state = activeMembershipState(db, kitAssetId, componentAssetId);
  if (!state) return { released: false, reconciled: false, reason: 'NO_MEMBERSHIP_STATE' };
  const at = nowIso();
  db.prepare(`UPDATE kit_component_membership_state
    SET active=0,released_at=?,release_reason=?,version=version+1,updated_at=?
    WHERE id=? AND active=1`).run(at, reason, at, state.id);

  const asset = componentPhysicalState(db, componentAssetId);
  if (!asset || asset.deleted_at || !asset.active) return { released: true, reconciled: false, reason: 'ASSET_INACTIVE' };
  if (asset.status !== 'DISPONIBLE') return { released: true, reconciled: false, reason: `STATUS_${asset.status}` };
  if (hasRealPhysicalBlocker(db, componentAssetId)) return { released: true, reconciled: false, reason: 'REAL_PHYSICAL_BLOCKER' };
  if (hasOtherActivePersonalKit(db, componentAssetId, kitAssetId)) return { released: true, reconciled: false, reason: 'OTHER_PERSONAL_KIT' };

  const baseline = Math.min(Number(asset.quantity_total), Number(state.baseline_quantity_available));
  const current = Number(asset.quantity_available);
  if (!(baseline > current)) return { released: true, reconciled: false, reason: 'NO_QUANTITY_DRIFT' };

  const changed = db.prepare(`UPDATE asset SET quantity_available=?,version=version+1,updated_at=?
    WHERE id=?`).run(baseline, at, componentAssetId);
  if (changed.changes === 1) {
    const updated = componentPhysicalState(db, componentAssetId);
    auditReconciliation(db, context, kitAssetId, asset, current, Number(updated.quantity_available), `${reason} · liberación`);
    return { released: true, reconciled: true, from: current, to: Number(updated.quantity_available) };
  }
  return { released: true, reconciled: false, reason: 'CONCURRENCY_CONFLICT' };
}

function activateKitMembershipsForAssignmentInDb(db, kitAssetId, context, reason = 'Asignación activa de kit personal') {
  const components = db.prepare(`SELECT component_asset_id FROM kit_component
    WHERE kit_asset_id=? AND active=1 ORDER BY sequence,id`).all(kitAssetId);
  const at = nowIso();
  const results = [];
  for (const row of components) {
    captureMembershipInDb(db, kitAssetId, row.component_asset_id, at);
    results.push({
      componentAssetId: row.component_asset_id,
      ...reconcileActiveMembershipInDb(db, kitAssetId, row.component_asset_id, context, reason)
    });
  }
  return results;
}

function releaseAllKitMembershipsInDb(db, kitAssetId, context, reason = 'Kit liberado') {
  const states = db.prepare(`SELECT component_asset_id FROM kit_component_membership_state
    WHERE kit_asset_id=? AND active=1 ORDER BY activated_at`).all(kitAssetId);
  return states.map((row) => ({
    componentAssetId: row.component_asset_id,
    ...releaseMembershipInDb(db, kitAssetId, row.component_asset_id, context, reason)
  }));
}

function syncKitComponentsInDb(db, kitAssetId, components, context, reason = 'Actualización de composición de kit') {
  const normalized = Array.isArray(components) ? components : [];
  const current = db.prepare(`SELECT component_asset_id FROM kit_component
    WHERE kit_asset_id=? AND active=1 ORDER BY sequence,id`).all(kitAssetId);
  const currentIds = new Set(current.map((row) => row.component_asset_id));
  const nextIds = new Set(normalized.map((row) => row.componentAssetId));
  const assigned = Boolean(activePersonalAssignment(db, kitAssetId));
  const at = nowIso();

  if (assigned) {
    for (const row of normalized) captureMembershipInDb(db, kitAssetId, row.componentAssetId, at);
  }

  db.prepare('UPDATE kit_component SET active=0,version=version+1,updated_at=? WHERE kit_asset_id=?').run(at, kitAssetId);
  const upsert = db.prepare(`INSERT INTO kit_component(
    id,kit_asset_id,component_asset_id,required_quantity,mandatory,allow_substitution,
    sequence,active,version,created_at,updated_at
  ) VALUES (?,?,?,?,?,?,?,1,1,?,?)
  ON CONFLICT(kit_asset_id,component_asset_id) DO UPDATE SET
    required_quantity=excluded.required_quantity,
    mandatory=excluded.mandatory,
    allow_substitution=excluded.allow_substitution,
    sequence=excluded.sequence,
    active=1,
    version=kit_component.version+1,
    updated_at=excluded.updated_at`);
  for (const item of normalized) {
    upsert.run(
      randomUUID(), kitAssetId, item.componentAssetId, item.requiredQuantity,
      item.mandatory ? 1 : 0, item.allowSubstitution ? 1 : 0, item.sequence, at, at
    );
  }

  const released = [];
  for (const componentAssetId of currentIds) {
    if (!nextIds.has(componentAssetId)) {
      released.push({ componentAssetId, ...releaseMembershipInDb(db, kitAssetId, componentAssetId, context, `${reason} · componente removido`) });
    }
  }

  let reconciled = [];
  if (assigned) {
    reconciled = normalized.map((row) => ({
      componentAssetId: row.componentAssetId,
      ...reconcileActiveMembershipInDb(db, kitAssetId, row.componentAssetId, context, `${reason} · reserva lógica`)
    }));
  } else {
    // Composition without an active personal assignment must not retain logical reservations.
    const stale = db.prepare(`SELECT component_asset_id FROM kit_component_membership_state
      WHERE kit_asset_id=? AND active=1`).all(kitAssetId);
    for (const row of stale) releaseMembershipInDb(db, kitAssetId, row.component_asset_id, context, `${reason} · kit sin asignación activa`);
  }

  return {
    added: [...nextIds].filter((id) => !currentIds.has(id)),
    removed: [...currentIds].filter((id) => !nextIds.has(id)),
    released,
    reconciled
  };
}

module.exports = {
  activePersonalAssignment,
  captureMembershipInDb,
  reconcileActiveMembershipInDb,
  releaseMembershipInDb,
  activateKitMembershipsForAssignmentInDb,
  releaseAllKitMembershipsInDb,
  syncKitComponentsInDb
};
