'use strict';

const {
  EXPERIENCE_CODES,
  EXPERIENCE_DEFINITIONS,
  ROLE_PRIORITY,
  ROLE_EXPERIENCE,
  ROLE_SCREEN_ENTITLEMENTS
} = require('../config/experience-model');

function normalizeRoleCodes(roleCodes) {
  return [...new Set((roleCodes || []).map((code) => String(code || '').trim().toUpperCase()).filter(Boolean))];
}

function highestPriorityRole(roleCodes) {
  const roles = new Set(normalizeRoleCodes(roleCodes));
  return ROLE_PRIORITY.find((role) => roles.has(role)) || null;
}

function resolveUserExperience(userOrRoleCodes) {
  const roleCodes = Array.isArray(userOrRoleCodes) ? userOrRoleCodes : (userOrRoleCodes?.roleCodes || []);
  const normalizedRoleCodes = normalizeRoleCodes(roleCodes);
  const primaryRole = highestPriorityRole(normalizedRoleCodes);
  const code = ROLE_EXPERIENCE[primaryRole] || EXPERIENCE_CODES.LIMITED;
  const definition = EXPERIENCE_DEFINITIONS[code];
  const screenRoutes = [...new Set(normalizedRoleCodes.flatMap((role) => ROLE_SCREEN_ENTITLEMENTS[role] || []))];
  const effectiveRoutes = screenRoutes.length ? screenRoutes : ['/acceso-limitado'];
  return {
    ...definition,
    primaryRole,
    roleCodes: normalizedRoleCodes,
    screenRoutes: effectiveRoutes,
    canOpenConfiguration: effectiveRoutes.includes('/gestion/config'),
    routingAuthority: 'SERVER',
    authorizationAuthority: 'BACKEND_RBAC'
  };
}

function canOpenScreen(userOrRoleCodes, route) {
  return resolveUserExperience(userOrRoleCodes).screenRoutes.includes(String(route || ''));
}

module.exports = { normalizeRoleCodes, highestPriorityRole, resolveUserExperience, canOpenScreen };
