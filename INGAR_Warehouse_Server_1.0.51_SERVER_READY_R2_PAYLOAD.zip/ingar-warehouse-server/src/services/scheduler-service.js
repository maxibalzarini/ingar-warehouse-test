'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { appendAudit, applyAuditRetention } = require('./audit-service');
const { enqueueNotification, deliverPendingNotifications, applyNotificationRetention } = require('./notification-service');
const { syncAllCustodyOperationalAlerts } = require('./custody-alert-service');
const { syncAllRequestOperationalAlerts } = require('./request-alert-service');
const { reconcileCustodyIntegrity } = require('./custody-integrity-service');
const { scanMaintenanceDue } = require('./maintenance-service');
const { evaluateConfiguredScopes } = require('./management-service');
const { safeInteger } = require('../security/validation');
const { getSetting } = require('./settings-service');
const logger = require('./logger');

let timer = null;
const JOBS = Object.freeze([
  { code: 'MAINTENANCE_SCAN', name: 'Evaluación de mantenimiento', intervalSeconds: 300 },
  { code: 'CUSTODY_ALERTS', name: 'Alertas operativas de custodias y devoluciones', intervalSeconds: 60 },
  { code: 'CUSTODY_INTEGRITY', name: 'Integridad entrega-custodia', intervalSeconds: 300 },
  { code: 'AUTHORIZATION_ALERTS', name: 'Alertas de habilitaciones', intervalSeconds: 300 },
  { code: 'NOTIFICATION_DELIVERY', name: 'Despacho de notificaciones', intervalSeconds: 60 },
  { code: 'AUDIT_MAINTENANCE', name: 'Archivo y control de auditoría', intervalSeconds: 21600 },
  { code: 'MANAGEMENT_INDICATORS', name: 'Cálculo diario de indicadores de gestión', intervalSeconds: 86400 }
]);

function error(status, code, message) { return Object.assign(new Error(message), { status, code }); }
function nowIso() { return new Date().toISOString(); }

function systemIdentity(db = getDb()) {
  const row = db.prepare(`SELECT ua.id,ua.person_id FROM user_account ua JOIN user_role_scope urs ON urs.user_id=ua.id JOIN role r ON r.id=urs.role_id
    WHERE ua.active=1 AND ua.deleted_at IS NULL AND r.code IN ('ADMIN_GENERAL','ADMINISTRADOR') ORDER BY CASE r.code WHEN 'ADMIN_GENERAL' THEN 0 ELSE 1 END LIMIT 1`).get();
  if (!row) throw error(503, 'SCHEDULER_IDENTITY_UNAVAILABLE', 'No existe identidad administrativa para el scheduler.');
  return { id: row.id, personId: row.person_id, roleCodes: ['SYSTEM_SCHEDULER'], permissions: ['*'], deniedPermissions: [] };
}

function systemContext(db = getDb(), correlationId = randomUUID()) {
  return { user: systemIdentity(db), correlationId, source: 'SCHEDULER', ip: '127.0.0.1', userAgent: 'IWC-SCHEDULER' };
}

function ensureSchedulerJobs(db = getDb()) {
  const now = nowIso();
  const stmt = db.prepare(`INSERT INTO scheduler_job(id,code,name,interval_seconds,enabled,last_run_at,next_run_at,last_status,last_error,version,created_at,updated_at)
    VALUES (?,?,?,?,1,NULL,?,NULL,NULL,1,?,?) ON CONFLICT(code) DO NOTHING`);
  for (const job of JOBS) {
    const interval = job.code === 'MAINTENANCE_SCAN'
      ? safeInteger(getSetting('maintenance.schedulerIntervalSeconds', job.intervalSeconds), job.intervalSeconds, 60, 86400)
      : job.intervalSeconds;
    stmt.run(randomUUID(), job.code, job.name, interval, now, now, now);
  }
  const legacyIntervals = { CUSTODY_ALERTS: 900, AUTHORIZATION_ALERTS: 3600 };
  for (const job of JOBS) {
    const legacy = legacyIntervals[job.code];
    if (!legacy) continue;
    db.prepare(`UPDATE scheduler_job SET interval_seconds=?,next_run_at=?,version=version+1,updated_at=? WHERE code=? AND interval_seconds=?`)
      .run(job.intervalSeconds, now, now, job.code, legacy);
  }
  return listSchedulerJobs({}, db);
}

function listSchedulerJobs(filters = {}, db = getDb()) {
  const rows = db.prepare('SELECT * FROM scheduler_job ORDER BY code').all();
  return rows.map((row) => ({
    ...row,
    recentRuns: filters.includeRuns === false ? undefined : db.prepare('SELECT * FROM scheduler_run WHERE job_id=? ORDER BY started_at DESC LIMIT 10').all(row.id)
      .map((run) => ({ ...run, details: JSON.parse(run.details_json || '{}') }))
  }));
}

function updateSchedulerJob(id, input, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM scheduler_job WHERE id=?').get(id);
    if (!current) throw error(404, 'SCHEDULER_JOB_NOT_FOUND', 'Trabajo programado no encontrado.');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== current.version) throw error(409, 'CONCURRENCY_CONFLICT', 'El trabajo fue modificado por otra operación.');
    const interval = safeInteger(input.intervalSeconds, current.interval_seconds, 60, 86400);
    const enabled = input.enabled === undefined ? current.enabled : (input.enabled ? 1 : 0);
    const now = nowIso();
    db.prepare('UPDATE scheduler_job SET interval_seconds=?,enabled=?,next_run_at=?,version=version+1,updated_at=? WHERE id=? AND version=?')
      .run(interval, enabled, enabled ? new Date(Date.now() + interval * 1000).toISOString() : null, now, id, current.version);
    const after = db.prepare('SELECT * FROM scheduler_job WHERE id=?').get(id);
    appendAudit({
      actorUserId: context.user.id,
      actorRole: context.user.roleCodes.join(','),
      action: 'SCHEDULER.JOB_UPDATE',
      entityType: 'scheduler_job',
      entityId: id,
      before: current,
      after,
      correlationId: context.correlationId,
      source: 'API',
      ipAddress: context.ip,
      equipment: context.userAgent
    }, db);
    return after;
  });
}

function custodyAlerts(db) {
  const now = new Date();
  const custodies = syncAllCustodyOperationalAlerts(db, now);
  const requests = syncAllRequestOperationalAlerts(db, now);
  return {
    processed: custodies.processed + requests.processed,
    generated: custodies.generated + requests.generated,
    reactivated: custodies.reactivated + requests.reactivated,
    cancelled: custodies.cancelled + requests.cancelled,
    missingOperators: custodies.missingOperators + requests.missingOperators,
    custodies,
    requests
  };
}

function custodyIntegrity(db, context) { return reconcileCustodyIntegrity(db, context); }

function authorizationAlerts(db) {
  const now = nowIso();
  const limit = new Date(Date.now() + 7 * 86400000).toISOString();
  const rows = db.prepare(`SELECT vda.id,vda.person_id,vda.valid_until,vda.license_number,p.full_name,ua.id AS user_id
    FROM vehicle_driver_authorization vda JOIN person p ON p.id=vda.person_id
    LEFT JOIN user_account ua ON ua.person_id=vda.person_id AND ua.active=1 AND ua.deleted_at IS NULL
    WHERE vda.status='VIGENTE' AND vda.valid_until BETWEEN ? AND ?`).all(now, limit);
  let generated = 0;
  for (const row of rows) {
    const result = enqueueNotification({
      recipientPersonId: row.person_id,
      recipientUserId: row.user_id,
      type: 'HABILITACION_PROXIMA',
      subject: 'Habilitación vehicular próxima a vencer',
      body: `La habilitación ${row.license_number} vence el ${row.valid_until}.`,
      entityType: 'vehicle_driver_authorization',
      entityId: row.id,
      dedupKey: `driver-auth:${row.id}:${row.valid_until}`
    }, db);
    if (!result.idempotent) generated += 1;
  }
  return { processed: rows.length, generated };
}

function executeJobLogic(code, db, context) {
  if (code === 'MAINTENANCE_SCAN') return scanMaintenanceDue(db, context);
  if (code === 'CUSTODY_ALERTS') return custodyAlerts(db);
  if (code === 'CUSTODY_INTEGRITY') return custodyIntegrity(db, context);
  if (code === 'AUTHORIZATION_ALERTS') return authorizationAlerts(db);
  if (code === 'NOTIFICATION_DELIVERY') {
    const delivery = deliverPendingNotifications(db);
    const retention = applyNotificationRetention(db);
    return { ...delivery, retentionDeleted: retention.deleted, retentionCutoff: retention.cutoff };
  }
  if (code === 'AUDIT_MAINTENANCE') return applyAuditRetention();
  if (code === 'MANAGEMENT_INDICATORS') return evaluateConfiguredScopes(db, context);
  throw error(422, 'SCHEDULER_JOB_UNKNOWN', 'Trabajo programado desconocido.');
}

function resultActivity(details = {}) {
  return ['generated', 'delivered', 'notified', 'repaired', 'reactivated', 'cancelled', 'retentionDeleted', 'archivedEvents']
    .reduce((sum, key) => sum + Math.max(0, Number(details[key] || 0)), 0);
}

function shouldAuditSchedulerRun(job, context, details) {
  if (context.source === 'API') return true;
  if (job.code === 'MANAGEMENT_INDICATORS') return true;
  return resultActivity(details) > 0 || details?.reconciliation?.missing?.length > 0;
}

function finalizeSuccessfulRun(db, job, runId, details, context, correlationId) {
  const finished = nowIso();
  const processed = Number(details.processed || details.remainingLiveEvents || 0);
  const generated = resultActivity(details);
  db.prepare("UPDATE scheduler_run SET finished_at=?,status='SUCCESS',processed_count=?,generated_count=?,details_json=?,error=NULL WHERE id=? AND status='RUNNING'")
    .run(finished, processed, generated, JSON.stringify(details), runId);
  db.prepare("UPDATE scheduler_job SET last_run_at=?,next_run_at=?,last_status='SUCCESS',last_error=NULL,version=version+1,updated_at=? WHERE id=?")
    .run(finished, new Date(Date.now() + job.interval_seconds * 1000).toISOString(), finished, job.id);
  if (shouldAuditSchedulerRun(job, context, details)) {
    appendAudit({
      actorUserId: context.user.id,
      actorRole: context.user.roleCodes.join(','),
      action: 'SCHEDULER.RUN',
      entityType: 'scheduler_job',
      entityId: job.id,
      after: { runId, code: job.code, details },
      correlationId,
      source: context.source || 'SCHEDULER',
      ipAddress: context.ip,
      equipment: context.userAgent
    }, db);
  }
  return { run: db.prepare('SELECT * FROM scheduler_run WHERE id=?').get(runId), details };
}

function runSchedulerJob(code, context = null) {
  ensureSchedulerJobs();
  const db = getDb();
  const job = db.prepare('SELECT * FROM scheduler_job WHERE code=?').get(String(code).toUpperCase());
  if (!job) throw error(404, 'SCHEDULER_JOB_NOT_FOUND', 'Trabajo programado no encontrado.');
  if (!job.enabled && context?.source !== 'API') return { skipped: true, reason: 'DISABLED' };
  const correlationId = context?.correlationId || randomUUID();
  const ctx = context || systemContext(db, correlationId);
  const runId = randomUUID();
  const started = nowIso();
  db.prepare("INSERT INTO scheduler_run(id,job_id,started_at,finished_at,status,processed_count,generated_count,details_json,error,correlation_id,created_at) VALUES (?,?,?,NULL,'RUNNING',0,0,'{}',NULL,?,?)")
    .run(runId, job.id, started, correlationId, started);
  db.prepare("UPDATE scheduler_job SET last_status='RUNNING',last_error=NULL,updated_at=? WHERE id=?").run(started, job.id);
  try {
    if (job.code === 'AUDIT_MAINTENANCE') {
      const details = executeJobLogic(job.code, db, ctx);
      return transaction((tx) => finalizeSuccessfulRun(tx, job, runId, details, ctx, correlationId));
    }
    return transaction((tx) => {
      const details = executeJobLogic(job.code, tx, ctx);
      return finalizeSuccessfulRun(tx, job, runId, details, ctx, correlationId);
    });
  } catch (caught) {
    const finished = nowIso();
    db.prepare("UPDATE scheduler_run SET finished_at=?,status='FAILED',error=? WHERE id=? AND status='RUNNING'")
      .run(finished, String(caught.message).slice(0, 2000), runId);
    db.prepare("UPDATE scheduler_job SET last_run_at=?,next_run_at=?,last_status='FAILED',last_error=?,version=version+1,updated_at=? WHERE id=?")
      .run(finished, new Date(Date.now() + job.interval_seconds * 1000).toISOString(), String(caught.message).slice(0, 2000), finished, job.id);
    throw caught;
  }
}

function runDueJobs() {
  ensureSchedulerJobs();
  if (!getSetting('scheduler.enabled', true)) return [];
  const now = nowIso();
  const due = getDb().prepare('SELECT code FROM scheduler_job WHERE enabled=1 AND (next_run_at IS NULL OR next_run_at<=?) ORDER BY code').all(now);
  const results = [];
  for (const row of due) {
    try { results.push({ code: row.code, ...runSchedulerJob(row.code) }); }
    catch (caught) { results.push({ code: row.code, error: caught.message }); }
  }
  return results;
}

function startScheduler() {
  if (timer) return;
  ensureSchedulerJobs();
  try { runDueJobs(); } catch (caught) { logger.error('SCHEDULER', 'Ejecución inicial fallida.', { error: caught.message }); }
  timer = setInterval(() => {
    try { runDueJobs(); } catch (caught) { logger.error('SCHEDULER', 'Ejecución periódica fallida.', { error: caught.message }); }
  }, 60000);
  timer.unref?.();
}

function stopScheduler() {
  if (timer) { clearInterval(timer); timer = null; }
}

module.exports = {
  ensureSchedulerJobs,
  listSchedulerJobs,
  updateSchedulerJob,
  runSchedulerJob,
  runDueJobs,
  startScheduler,
  stopScheduler,
  shouldAuditSchedulerRun
};
