'use strict';

const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb, transaction } = require('../db/database');
const { sha256 } = require('../security/tokens');
const { requiredString, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { parseDataUrl, saveOwnedEvidenceDataUrl } = require('./evidence-service');
const { parseCsv, parseXlsx, createXlsx, rowsToObjects } = require('./spreadsheet-service');
const { normalizeAsset, insertAsset, assetSelect, convertUniqueError } = require('./asset-service');
const { assertLocationScope, assertAssetScope, userHasScope } = require('../security/scope');
const { SPECIALIZED_KINDS, validateSpecializedImport, applySpecializedImport, reverseSpecializedImport, specializedTemplate } = require('./specialized-import-service');

const MODES = new Set(['CREATE_ONLY', 'UPDATE_ONLY', 'CREATE_OR_UPDATE']);
const TEMPLATE_HEADERS = Object.freeze([
  'codigo_interno', 'categoria_codigo', 'descripcion', 'ubicacion_codigo', 'sede_codigo',
  'numero_serie', 'marca', 'modelo', 'cantidad_total', 'cantidad_disponible',
  'unidad_medida', 'patente', 'kilometraje', 'combustible', 'estado', 'activo', 'observaciones'
]);
const FIELD_ALIASES = Object.freeze({
  internalCode: ['codigo_interno', 'código_interno', 'internal_code', 'codigo', 'code'],
  categoryCode: ['categoria_codigo', 'categoría_codigo', 'category_code', 'categoria'],
  description: ['descripcion', 'descripción', 'description', 'nombre', 'herramienta'],
  locationCode: ['ubicacion_codigo', 'ubicación_codigo', 'location_code', 'ubicacion'],
  siteCode: ['sede_codigo', 'site_code', 'sede'],
  serialNumber: ['numero_serie', 'número_serie', 'serial_number', 'serie'],
  brand: ['marca', 'brand'],
  model: ['modelo', 'model'],
  quantityTotal: ['cantidad_total', 'quantity_total', 'cantidad'],
  quantityAvailable: ['cantidad_disponible', 'quantity_available', 'disponible'],
  unitOfMeasure: ['unidad_medida', 'unit_of_measure', 'unidad'],
  licensePlate: ['patente', 'license_plate', 'matricula', 'matrícula'],
  odometer: ['kilometraje', 'odometer', 'odometro', 'odómetro'],
  fuelType: ['combustible', 'fuel_type'],
  status: ['estado', 'status'],
  active: ['activo', 'active'],
  notes: ['observaciones', 'notas', 'notes', 'anomalia', 'anomalía']
});

function normalizeHeader(value) {
  return String(value || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '_');
}

function resolveMapping(headers, requested = {}) {
  const normalizedHeaders = new Map(headers.map((header) => [normalizeHeader(header), header]));
  const result = {};
  for (const [field, aliases] of Object.entries(FIELD_ALIASES)) {
    const requestedHeader = requested[field];
    if (requestedHeader && headers.includes(requestedHeader)) { result[field] = requestedHeader; continue; }
    const found = aliases.map(normalizeHeader).find((alias) => normalizedHeaders.has(alias));
    if (found) result[field] = normalizedHeaders.get(found);
  }
  const requiredFields = ['internalCode', 'categoryCode', 'description', 'locationCode'];
  const missing = requiredFields.filter((field) => !result[field]);
  if (missing.length) {
    const labels = {
      internalCode: 'codigo_interno',
      categoryCode: 'categoria_codigo',
      description: 'descripcion',
      locationCode: 'ubicacion_codigo'
    };
    const detected = headers.map((header) => String(header || '').trim()).filter(Boolean);
    const error = new Error(`El archivo fue leído correctamente, pero no corresponde a la plantilla del maestro de bienes. Faltan columnas obligatorias: ${missing.map((field) => labels[field]).join(', ')}. Columnas detectadas: ${detected.join(', ') || 'ninguna'}.`);
    error.status = 422;
    error.code = 'IMPORT_MAPPING_INCOMPLETE';
    error.fieldErrors = missing.map((field) => ({ field, message: `Falta la columna ${labels[field]}.` }));
    error.details = { detectedHeaders: detected, missingColumns: missing.map((field) => labels[field]) };
    throw error;
  }
  return result;
}

function valueFrom(row, mapping, field) {
  const value = mapping[field] ? row[mapping[field]] : null;
  if (typeof value === 'string') return value.trim();
  return value;
}

function parseOptionalBoolean(value, field = 'activo') {
  if (value === '' || value === null || value === undefined) return undefined;
  if (typeof value === 'boolean') return value;
  const normalized = String(value).trim().toUpperCase();
  if (['1', 'SI', 'SÍ', 'TRUE', 'VERDADERO', 'YES'].includes(normalized)) return true;
  if (['0', 'NO', 'FALSE', 'FALSO'].includes(normalized)) return false;
  throw Object.assign(new Error(`${field} debe indicar SI o NO.`), { code: 'BOOLEAN_INVALID' });
}

function parseRows(filename, mimeType, bytes) {
  const lower = filename.toLowerCase();
  const isZip = bytes.length >= 4 && bytes.readUInt32LE(0) === 0x04034b50;
  if (lower.endsWith('.csv')) {
    if (isZip || !['text/csv', 'text/plain'].includes(mimeType)) throw Object.assign(new Error('El contenido no coincide con un archivo CSV.'), { status: 422, code: 'IMPORT_CONTENT_MISMATCH' });
    return parseCsv(bytes.toString('utf8'));
  }
  if (lower.endsWith('.xlsx')) {
    if (!isZip || mimeType !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') throw Object.assign(new Error('El contenido no coincide con un archivo XLSX.'), { status: 422, code: 'IMPORT_CONTENT_MISMATCH' });
    return parseXlsx(bytes);
  }
  throw Object.assign(new Error('La extensión debe ser .csv o .xlsx.'), { status: 422, code: 'IMPORT_FORMAT_INVALID' });
}

function resolveCategory(code, db) {
  return db.prepare('SELECT * FROM asset_category WHERE code = ? COLLATE NOCASE AND active = 1 AND deleted_at IS NULL').get(code);
}

function resolveLocation(locationCode, siteCode, db) {
  const params = [locationCode];
  let sql = `SELECT sl.*, s.code AS site_code, s.active AS site_active FROM storage_location sl JOIN site s ON s.id = sl.site_id
    WHERE sl.code = ? COLLATE NOCASE AND sl.active = 1 AND s.active = 1`;
  if (siteCode) { sql += ' AND s.code = ? COLLATE NOCASE'; params.push(siteCode); }
  const matches = db.prepare(sql).all(...params);
  if (matches.length === 1) return matches[0];
  if (!matches.length) return null;
  return { ambiguous: true };
}

function rowInput(row, mapping, db) {
  const categoryCode = String(valueFrom(row, mapping, 'categoryCode') || '').toUpperCase();
  const locationCode = String(valueFrom(row, mapping, 'locationCode') || '').toUpperCase();
  const siteCode = String(valueFrom(row, mapping, 'siteCode') || '').toUpperCase();
  const category = resolveCategory(categoryCode, db);
  const location = resolveLocation(locationCode, siteCode || null, db);
  if (!category) throw Object.assign(new Error(`Categoría inexistente o inactiva: ${categoryCode || 'vacía'}.`), { code: 'CATEGORY_INVALID' });
  if (!location) throw Object.assign(new Error(`Ubicación inexistente o inactiva: ${locationCode || 'vacía'}.`), { code: 'LOCATION_INVALID' });
  if (location.ambiguous) throw Object.assign(new Error(`Ubicación ambigua: ${locationCode}. Indique sede_codigo.`), { code: 'LOCATION_AMBIGUOUS' });
  return {
    internalCode: valueFrom(row, mapping, 'internalCode'),
    categoryId: category.id,
    description: valueFrom(row, mapping, 'description'),
    locationId: location.id,
    siteId: location.site_id,
    serialNumber: valueFrom(row, mapping, 'serialNumber') || undefined,
    brand: valueFrom(row, mapping, 'brand') || undefined,
    model: valueFrom(row, mapping, 'model') || undefined,
    quantityTotal: valueFrom(row, mapping, 'quantityTotal') || undefined,
    quantityAvailable: valueFrom(row, mapping, 'quantityAvailable') || undefined,
    unitOfMeasure: valueFrom(row, mapping, 'unitOfMeasure') || undefined,
    licensePlate: valueFrom(row, mapping, 'licensePlate') || undefined,
    odometer: valueFrom(row, mapping, 'odometer') === '' ? undefined : valueFrom(row, mapping, 'odometer'),
    fuelType: valueFrom(row, mapping, 'fuelType') || undefined,
    status: valueFrom(row, mapping, 'status') || undefined,
    notes: valueFrom(row, mapping, 'notes') || undefined,
    active: parseOptionalBoolean(valueFrom(row, mapping, 'active'))
  };
}

function validateRows(rows, mapping, mode, db, user) {
  const records = [];
  const seenCodes = new Set();
  const seenSerials = new Set();
  const seenPlates = new Set();
  for (let index = 1; index < rows.length; index += 1) {
    const raw = Object.fromEntries(rows[0].map((header, column) => [header, rows[index][column] ?? '']));
    if (!Object.values(raw).some((value) => String(value).trim() !== '')) continue;
    const errors = [];
    let normalized = null;
    let operation = null;
    let before = null;
    try {
      const input = rowInput(raw, mapping, db);
      const codeKey = String(input.internalCode || '').trim().toUpperCase();
      if (seenCodes.has(codeKey)) throw Object.assign(new Error(`Código interno duplicado dentro del archivo: ${codeKey}.`), { code: 'FILE_DUPLICATE_CODE' });
      const existing = db.prepare('SELECT * FROM asset WHERE internal_code = ? COLLATE NOCASE AND deleted_at IS NULL').get(input.internalCode);
      operation = existing ? 'UPDATE' : 'CREATE';
      assertLocationScope(user, input.locationId, 'Import.Create', db);
      if (existing) assertAssetScope(user, existing.id, 'Import.Create', db);
      if (mode === 'CREATE_ONLY' && existing) throw Object.assign(new Error(`El bien ${codeKey} ya existe y el lote es solo alta.`), { code: 'IMPORT_CREATE_ONLY_CONFLICT' });
      if (mode === 'UPDATE_ONLY' && !existing) throw Object.assign(new Error(`El bien ${codeKey} no existe y el lote es solo actualización.`), { code: 'IMPORT_UPDATE_ONLY_MISSING' });
      const inputCategory = db.prepare('SELECT nature FROM asset_category WHERE id=?').get(input.categoryId);
      if (inputCategory && ['VEHICULO','KIT'].includes(inputCategory.nature)) {
        const specializedTemplate = inputCategory.nature === 'KIT' ? "Kits con componentes" : "Vehículos completos";
        throw Object.assign(new Error(`La categoría ${inputCategory.nature} requiere su plantilla especializada. Use "${specializedTemplate}".`), { code: 'SPECIALIZED_IMPORT_REQUIRED' });
      }
      normalized = normalizeAsset(input, existing || null, db, { systemOperation: Boolean(existing && input.status === undefined) });
      const serialKey = normalized.serialNumber?.toUpperCase();
      const plateKey = normalized.licensePlate?.toUpperCase();
      if (serialKey && seenSerials.has(serialKey)) throw Object.assign(new Error(`Número de serie duplicado dentro del archivo: ${serialKey}.`), { code: 'FILE_DUPLICATE_SERIAL' });
      if (plateKey && seenPlates.has(plateKey)) throw Object.assign(new Error(`Patente duplicada dentro del archivo: ${plateKey}.`), { code: 'FILE_DUPLICATE_LICENSE' });
      const duplicateSerial = serialKey && db.prepare('SELECT id FROM asset WHERE serial_number = ? COLLATE NOCASE AND deleted_at IS NULL AND id <> COALESCE(?, \'\')').get(serialKey, existing?.id || null);
      if (duplicateSerial) throw Object.assign(new Error(`El número de serie ${serialKey} pertenece a otro bien.`), { code: 'ASSET_SERIAL_DUPLICATE' });
      const duplicatePlate = plateKey && db.prepare('SELECT id FROM asset WHERE license_plate = ? COLLATE NOCASE AND deleted_at IS NULL AND id <> COALESCE(?, \'\')').get(plateKey, existing?.id || null);
      if (duplicatePlate) throw Object.assign(new Error(`La patente ${plateKey} pertenece a otro bien.`), { code: 'ASSET_LICENSE_DUPLICATE' });
      seenCodes.add(codeKey);
      if (serialKey) seenSerials.add(serialKey);
      if (plateKey) seenPlates.add(plateKey);
      before = existing || null;
    } catch (error) {
      errors.push({ code: error.code || 'ROW_INVALID', message: error.message });
    }
    records.push({ rowNumber: index + 1, raw, normalized, operation, before, errors });
  }
  return records;
}

function validateAssetImport(input, context) {
  const kind = String(input.kind || 'ASSET').toUpperCase();
  if (SPECIALIZED_KINDS.has(kind)) {
    const id = validateSpecializedImport(input, context, kind);
    return getImportBatch(id);
  }
  if (kind !== 'ASSET') throw Object.assign(new Error('Tipo de importación inválido.'), { status: 422, code: 'IMPORT_KIND_INVALID' });
  const filename = requiredString(input.filename, 'filename', { min: 5, max: 180 });
  const mode = String(input.mode || 'CREATE_OR_UPDATE').toUpperCase();
  if (!MODES.has(mode)) throw Object.assign(new Error('Modo de importación inválido.'), { status: 422, code: 'IMPORT_MODE_INVALID' });
  const parsed = parseDataUrl(input.dataUrl);
  if (parsed.bytes.length > runtime.maxImportBytes) throw Object.assign(new Error('El archivo de importación supera 5 MiB.'), { status: 413, code: 'IMPORT_TOO_LARGE' });
  const rows = parseRows(filename, parsed.mimeType, parsed.bytes);
  if (rows.length < 2) throw Object.assign(new Error('El archivo no contiene filas de datos.'), { status: 422, code: 'IMPORT_EMPTY' });
  if (rows.length > 10_001) throw Object.assign(new Error('El lote supera 10.000 filas.'), { status: 422, code: 'IMPORT_TOO_MANY_ROWS' });
  const headers = rows[0].map((value) => String(value || '').trim());
  const mapping = resolveMapping(headers, input.mapping || {});
  const db = getDb();
  const records = validateRows(rows, mapping, mode, db, context.user);
  const validRows = records.filter((record) => !record.errors.length).length;
  const invalidRows = records.length - validRows;
  const id = randomUUID();
  return saveOwnedEvidenceDataUrl(
    { dataUrl: input.dataUrl, originalFilename: filename },
    { ownerType: 'IMPORT_BATCH', ownerId: id, purpose: 'SOURCE_FILE' },
    context,
    { allowedMimeTypes: ['text/csv', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'], maxBytes: runtime.maxImportBytes },
    (tx, evidence) => {
      const now = new Date().toISOString();
      const status = invalidRows ? 'VALIDADA_CON_ERRORES' : 'VALIDADA';
      tx.prepare(`INSERT INTO import_batch(id, type, filename, mime_type, file_evidence_id, sha256, status, mode, mapping_json, total_rows, valid_rows, invalid_rows, created_by, created_at, validated_at, version)
        VALUES (?, 'ASSET', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`)
        .run(id, filename, parsed.mimeType, evidence.id, sha256(parsed.bytes), status, mode, JSON.stringify({ ...mapping, __importKind: 'ASSET' }), records.length, validRows, invalidRows, context.user.id, now, now);
      const rowStmt = tx.prepare(`INSERT INTO import_row(id, batch_id, row_number, raw_json, normalized_json, operation, validation_status, errors_json, before_json, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      for (const record of records) {
        rowStmt.run(randomUUID(), id, record.rowNumber, JSON.stringify(record.raw), record.normalized ? JSON.stringify(record.normalized) : null, record.operation, record.errors.length ? 'INVALID' : 'VALID', JSON.stringify(record.errors), record.before ? JSON.stringify(record.before) : null, now, now);
      }
      appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'IMPORT.ASSET_VALIDATE', entityType: 'import_batch', entityId: id, after: { filename, sha256: sha256(parsed.bytes), status, mode, totalRows: records.length, validRows, invalidRows, mapping }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, tx);
      return getImportBatch(id);
    }
  );
}

function batchScopeAllowed(batchId, user, permission = 'Import.Read', db = getDb()) {
  if (!user) return true;
  const rows = db.prepare('SELECT normalized_json, before_json, resulting_entity_id FROM import_row WHERE batch_id = ?').all(batchId);
  if (!rows.length) return false;
  return rows.every((row) => {
    try {
      const normalized = row.normalized_json ? JSON.parse(row.normalized_json) : null;
      if (normalized?.siteId && normalized?.locationId) return userHasScope(user, normalized.siteId, normalized.locationId, permission, db);
      if (normalized?.locationId) {
        const location = db.prepare('SELECT site_id FROM storage_location WHERE id=?').get(normalized.locationId);
        return Boolean(location && userHasScope(user, location.site_id, normalized.locationId, permission, db));
      }
      const before = row.before_json ? JSON.parse(row.before_json) : null;
      const assetId = row.resulting_entity_id || before?.id;
      if (!assetId) return false;
      const asset = db.prepare('SELECT a.location_id,sl.site_id FROM asset a JOIN storage_location sl ON sl.id=a.location_id WHERE a.id=?').get(assetId);
      return Boolean(asset && userHasScope(user, asset.site_id, asset.location_id, permission, db));
    } catch { return false; }
  });
}

function listImportBatches(filters = {}, user = null, permission = 'Import.Read') {
  const where = ["type = 'ASSET'"];
  const params = [];
  if (filters.status) { where.push('status = ?'); params.push(String(filters.status).toUpperCase()); }
  const limit = safeInteger(filters.limit, 100, 1, 500);
  const rows = getDb().prepare(`SELECT ib.*, ua.username AS created_by_username FROM import_batch ib JOIN user_account ua ON ua.id = ib.created_by WHERE ${where.join(' AND ')} ORDER BY ib.created_at DESC LIMIT ?`).all(...params, limit)
    .map((row) => {
      try { return { ...row, import_kind: JSON.parse(row.mapping_json || '{}').__importKind || 'ASSET' }; }
      catch { return { ...row, import_kind: 'ASSET' }; }
    });
  return user ? rows.filter((row) => batchScopeAllowed(row.id, user, permission)) : rows;
}

function getImportBatch(id, user = null, permission = 'Import.Read', options = {}) {
  const batch = getDb().prepare(`SELECT ib.*, ua.username AS created_by_username FROM import_batch ib JOIN user_account ua ON ua.id = ib.created_by WHERE ib.id = ?`).get(id);
  if (!batch) return null;
  if (user && !batchScopeAllowed(id, user, permission)) throw Object.assign(new Error('La operación está fuera del alcance asignado.'), { status: 403, code: 'SCOPE_FORBIDDEN' });
  const limit = options.allRows ? 10_000 : safeInteger(options.limit, 200, 1, 500);
  const offset = safeInteger(options.offset, 0, 0, 1_000_000);
  batch.mapping = JSON.parse(batch.mapping_json || '{}');
  batch.importKind = batch.mapping.__importKind || 'ASSET';
  batch.rows = getDb().prepare('SELECT * FROM import_row WHERE batch_id = ? ORDER BY row_number LIMIT ? OFFSET ?').all(id, limit, offset).map((row) => ({
    ...row,
    raw: JSON.parse(row.raw_json || '{}'),
    normalized: row.normalized_json ? JSON.parse(row.normalized_json) : null,
    errors: JSON.parse(row.errors_json || '[]')
  }));
  batch.rowPage = {
    offset,
    limit,
    returned: batch.rows.length,
    total: batch.total_rows,
    hasPrevious: offset > 0,
    hasMore: offset + batch.rows.length < batch.total_rows
  };
  return batch;
}

function applyAssetImport(id, context) {
  const current = getImportBatch(id);
  if (current && SPECIALIZED_KINDS.has(String(current.importKind || '').toUpperCase())) {
    applySpecializedImport(id, context, String(current.importKind).toUpperCase());
    return getImportBatch(id);
  }
  if (!current) throw Object.assign(new Error('Lote no encontrado.'), { status: 404, code: 'IMPORT_NOT_FOUND' });
  if (current.status === 'APLICADA') return current;
  if (current.status !== 'VALIDADA' || current.invalid_rows !== 0) throw Object.assign(new Error('El lote debe estar validado sin errores antes de aplicar.'), { status: 409, code: 'IMPORT_NOT_APPLICABLE' });
  return transaction((db) => {
    const batch = db.prepare('SELECT * FROM import_batch WHERE id = ?').get(id);
    if (batch.status !== 'VALIDADA') throw Object.assign(new Error('El lote cambió de estado.'), { status: 409, code: 'IMPORT_STATE_CONFLICT' });
    const rows = db.prepare("SELECT * FROM import_row WHERE batch_id = ? AND validation_status = 'VALID' ORDER BY row_number").all(id);
    const now = new Date().toISOString();
    for (const row of rows) {
      const normalized = JSON.parse(row.normalized_json);
      assertLocationScope(context.user, normalized.locationId, 'Import.Apply', db);
      if (row.operation === 'CREATE') {
        let assetId;
        try { assetId = insertAsset(db, normalized, { sourceImportBatchId: id, now }); } catch (error) { throw convertUniqueError(error); }
        const created = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(assetId);
        appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.IMPORT_CREATE', entityType: 'asset', entityId: assetId, after: created, correlationId: context.correlationId, source: 'IMPORT', reason: `Lote ${id}, fila ${row.row_number}`, ipAddress: context.ip, equipment: context.userAgent }, db);
        db.prepare("UPDATE import_row SET validation_status = 'APPLIED', resulting_entity_id = ?, applied_entity_version = 1, updated_at = ? WHERE id = ?").run(assetId, now, row.id);
      } else {
        const before = JSON.parse(row.before_json);
        assertLocationScope(context.user, before.location_id, 'Import.Apply', db);
        const result = db.prepare(`UPDATE asset SET category_id = ?, internal_code = ?, serial_number = ?, description = ?, brand = ?, model = ?, status = ?, location_id = ?, quantity_total = ?, quantity_available = ?, unit_of_measure = ?, license_plate = ?, odometer = ?, fuel_type = ?, notes = ?, active = ?, source_import_batch_id = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ? AND deleted_at IS NULL`)
          .run(normalized.categoryId, normalized.internalCode, normalized.serialNumber, normalized.description, normalized.brand, normalized.model, normalized.status, normalized.locationId, normalized.quantityTotal, normalized.quantityAvailable, normalized.unitOfMeasure, normalized.licensePlate, normalized.odometer, normalized.fuelType, normalized.notes, normalized.active ? 1 : 0, id, now, before.id, before.version);
        if (result.changes !== 1) throw Object.assign(new Error(`Conflicto de concurrencia al aplicar fila ${row.row_number}.`), { status: 409, code: 'CONCURRENCY_CONFLICT' });
        const updated = db.prepare(`${assetSelect()} WHERE a.id = ?`).get(before.id);
        appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.IMPORT_UPDATE', entityType: 'asset', entityId: before.id, before, after: updated, correlationId: context.correlationId, source: 'IMPORT', reason: `Lote ${id}, fila ${row.row_number}`, ipAddress: context.ip, equipment: context.userAgent }, db);
        db.prepare("UPDATE import_row SET validation_status = 'APPLIED', resulting_entity_id = ?, applied_entity_version = ?, updated_at = ? WHERE id = ?").run(before.id, updated.version, now, row.id);
      }
    }
    db.prepare("UPDATE import_batch SET status = 'APLICADA', applied_at = ?, version = version + 1 WHERE id = ? AND status = 'VALIDADA'").run(now, id);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'IMPORT.ASSET_APPLY', entityType: 'import_batch', entityId: id, before: { status: 'VALIDADA' }, after: { status: 'APLICADA', appliedAt: now, rows: rows.length }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return getImportBatch(id);
  });
}

function reverseAssetImport(id, input, context) {
  const current = getImportBatch(id);
  if (current && SPECIALIZED_KINDS.has(String(current.importKind || '').toUpperCase())) {
    reverseSpecializedImport(id, input, context, String(current.importKind).toUpperCase());
    return getImportBatch(id);
  }
  if (!current) throw Object.assign(new Error('Lote no encontrado.'), { status: 404, code: 'IMPORT_NOT_FOUND' });
  if (current.status === 'REVERTIDA') return current;
  if (current.status !== 'APLICADA') throw Object.assign(new Error('Solo puede revertirse un lote aplicado.'), { status: 409, code: 'IMPORT_NOT_REVERSIBLE' });
  if (String(input.confirmation || '') !== `REVERTIR:${id}`) throw Object.assign(new Error('Confirmación de reversión inválida.'), { status: 422, code: 'IMPORT_CONFIRMATION_INVALID' });
  return transaction((db) => {
    const batch = db.prepare('SELECT * FROM import_batch WHERE id = ?').get(id);
    if (batch.status !== 'APLICADA') throw Object.assign(new Error('El lote cambió de estado.'), { status: 409, code: 'IMPORT_STATE_CONFLICT' });
    const rows = db.prepare("SELECT * FROM import_row WHERE batch_id = ? AND validation_status = 'APPLIED' ORDER BY row_number DESC").all(id);
    const now = new Date().toISOString();
    for (const row of rows) {
      const asset = db.prepare('SELECT * FROM asset WHERE id = ?').get(row.resulting_entity_id);
      if (!asset || asset.version !== row.applied_entity_version) throw Object.assign(new Error(`No puede revertirse la fila ${row.row_number}: el bien fue modificado después de la importación.`), { status: 409, code: 'IMPORT_REVERSE_CONFLICT' });
      assertAssetScope(context.user, asset.id, 'Import.Reverse', db);
      if (row.operation === 'CREATE') {
        const result = db.prepare("UPDATE asset SET active = 0, status = 'BAJA', quantity_available = 0, deleted_at = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ?").run(now, now, asset.id, asset.version);
        if (result.changes !== 1) throw Object.assign(new Error('Conflicto al revertir alta importada.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
        appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.IMPORT_REVERSE_CREATE', entityType: 'asset', entityId: asset.id, before: asset, after: { active: 0, status: 'BAJA', deletedAt: now }, correlationId: context.correlationId, source: 'IMPORT', reason: `Reversión lote ${id}`, ipAddress: context.ip, equipment: context.userAgent }, db);
      } else {
        const before = JSON.parse(row.before_json);
        assertAssetScope(context.user, before.id, 'Import.Apply', db);
        const result = db.prepare(`UPDATE asset SET category_id = ?, internal_code = ?, serial_number = ?, description = ?, brand = ?, model = ?, status = ?, location_id = ?, custodian_person_id = ?, quantity_total = ?, quantity_available = ?, unit_of_measure = ?, license_plate = ?, odometer = ?, fuel_type = ?, notes = ?, photo_evidence_id = ?, source_import_batch_id = ?, active = ?, deleted_at = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ?`)
          .run(before.category_id, before.internal_code, before.serial_number, before.description, before.brand, before.model, before.status, before.location_id, before.custodian_person_id, before.quantity_total, before.quantity_available, before.unit_of_measure, before.license_plate, before.odometer, before.fuel_type, before.notes, before.photo_evidence_id, before.source_import_batch_id, before.active, before.deleted_at, now, asset.id, asset.version);
        if (result.changes !== 1) throw Object.assign(new Error('Conflicto al revertir actualización importada.'), { status: 409, code: 'CONCURRENCY_CONFLICT' });
        appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'ASSET.IMPORT_REVERSE_UPDATE', entityType: 'asset', entityId: asset.id, before: asset, after: before, correlationId: context.correlationId, source: 'IMPORT', reason: `Reversión lote ${id}`, ipAddress: context.ip, equipment: context.userAgent }, db);
      }
      db.prepare("UPDATE import_row SET validation_status = 'REVERTED', updated_at = ? WHERE id = ?").run(now, row.id);
    }
    db.prepare("UPDATE import_batch SET status = 'REVERTIDA', reverted_at = ?, version = version + 1 WHERE id = ? AND status = 'APLICADA'").run(now, id);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'IMPORT.ASSET_REVERSE', entityType: 'import_batch', entityId: id, before: { status: 'APLICADA' }, after: { status: 'REVERTIDA', revertedAt: now, rows: rows.length }, correlationId: context.correlationId, source: 'API', reason: input.reason || null, ipAddress: context.ip, equipment: context.userAgent }, db);
    return getImportBatch(id);
  });
}

function template(format = 'csv', kind = 'ASSET') {
  const normalizedKind = String(kind || 'ASSET').toUpperCase();
  if (SPECIALIZED_KINDS.has(normalizedKind)) return specializedTemplate(normalizedKind, format);
  if (normalizedKind !== 'ASSET') throw Object.assign(new Error('Tipo de plantilla inválido.'), { status: 422, code: 'IMPORT_KIND_INVALID' });
  if (format === 'xlsx') return { bytes: createXlsx([TEMPLATE_HEADERS]), mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename: 'plantilla_bienes_ingar.xlsx' };
  const csv = `\uFEFF${TEMPLATE_HEADERS.join(';')}\r\n`;
  return { bytes: Buffer.from(csv, 'utf8'), mimeType: 'text/csv; charset=utf-8', filename: 'plantilla_bienes_ingar.csv' };
}

function importReportCsv(id, user = null, permission = 'Import.Read') {
  const batch = getImportBatch(id, user, permission, { allRows: true });
  if (!batch) throw Object.assign(new Error('Lote no encontrado.'), { status: 404, code: 'IMPORT_NOT_FOUND' });
  const headers = ['fila', 'operacion', 'estado', 'entidad_id', 'errores', 'datos'];
  const escape = (value) => {
    let safe = String(value ?? '');
    if (/^[=+\-@\t\r]/.test(safe)) safe = `'${safe}`;
    return `"${safe.replaceAll('"', '""')}"`;
  };
  const lines = [headers.join(';'), ...batch.rows.map((row) => [row.row_number, row.operation || '', row.validation_status, row.resulting_entity_id || '', row.errors.map((error) => `${error.code}: ${error.message}`).join(' | '), JSON.stringify(row.raw)].map(escape).join(';'))];
  return Buffer.from(`\uFEFF${lines.join('\r\n')}`, 'utf8');
}

module.exports = {
  TEMPLATE_HEADERS,
  FIELD_ALIASES,
  resolveMapping,
  validateAssetImport,
  listImportBatches,
  getImportBatch,
  applyAssetImport,
  reverseAssetImport,
  template,
  importReportCsv
};
