'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { seedAuthorizationCatalog } = require('./permission-service');
const { seedSettings } = require('./settings-service');
const { ensureSchedulerJobs } = require('./scheduler-service');
const { ensureManagementCatalog } = require('./management-service');

function seedBase() {
  return transaction((db) => {
    const now = new Date().toISOString();
    if (!db.prepare('SELECT 1 FROM organization LIMIT 1').get()) {
      const organizationId = randomUUID();
      const siteId = randomUUID();
      const locationId = randomUUID();
      db.prepare('INSERT INTO organization(id, name, timezone, active, version, created_at, updated_at) VALUES (?, ?, ?, 1, 1, ?, ?)')
        .run(organizationId, 'Organización', 'America/Argentina/Buenos_Aires', now, now);
      db.prepare('INSERT INTO site(id, organization_id, code, name, active, version, created_at, updated_at, is_primary) VALUES (?, ?, ?, ?, 1, 1, ?, ?, 1)')
        .run(siteId, organizationId, 'PRINCIPAL', 'Sede principal', now, now);
      db.prepare('INSERT INTO storage_location(id, site_id, code, name, type, active, version, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, 1, ?, ?)')
        .run(locationId, siteId, 'PANOL-01', 'Pañol principal', 'PANOL', now, now);
    }
    seedAuthorizationCatalog(db);
    seedSettings(db);
    ensureManagementCatalog(db);
    ensureSchedulerJobs(db);
    return true;
  });
}

function adminExists() {
  seedBase();
  return Boolean(getDb().prepare(`SELECT 1 FROM user_account ua
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL' AND ua.active = 1 AND ua.deleted_at IS NULL LIMIT 1`).get());
}

module.exports = { seedBase, adminExists };
