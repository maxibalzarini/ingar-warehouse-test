'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { randomUUID } = require('node:crypto');
const runtime = require('../config/runtime');
const { getDb, transaction } = require('../db/database');
const { sha256, stableJson } = require('../security/tokens');
const { isProtectedBuffer, protectBuffer, unprotectBuffer } = require('../security/data-protection');

const DEFAULT_POLICY = Object.freeze({
  retentionDays: 730,
  maxLiveEvents: 100000,
  minimumLiveEvents: 1000,
  archiveBatchSize: 5000,
  maxSegmentsPerRun: 10
});

const SENSITIVE_READ_PREFIXES = Object.freeze([
  '/api/v1/audit',
  '/api/v1/logs',
  '/api/v1/backups',
  '/api/v1/users',
  '/api/v1/roles',
  '/api/v1/permissions',
  '/api/v1/config'
]);

function parseSetting(db, key, fallback) {
  const table = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='system_setting'").get();
  if (!table) return fallback;
  const row = db.prepare("SELECT value_json FROM system_setting WHERE scope_type='SYSTEM' AND scope_id='GLOBAL' AND key=?").get(key);
  if (!row) return fallback;
  try { return JSON.parse(row.value_json); } catch { return fallback; }
}

function auditPolicy(db = getDb(), overrides = {}) {
  const retentionDays = Number(overrides.retentionDays ?? parseSetting(db, 'audit.retentionDays', DEFAULT_POLICY.retentionDays));
  const maxLiveEvents = Number(overrides.maxLiveEvents ?? parseSetting(db, 'audit.maxLiveEvents', DEFAULT_POLICY.maxLiveEvents));
  const minimumLiveEvents = Number(overrides.minimumLiveEvents ?? parseSetting(db, 'audit.minimumLiveEvents', DEFAULT_POLICY.minimumLiveEvents));
  const archiveBatchSize = Number(overrides.archiveBatchSize ?? parseSetting(db, 'audit.archiveBatchSize', DEFAULT_POLICY.archiveBatchSize));
  const maxSegmentsPerRun = Number(overrides.maxSegmentsPerRun ?? parseSetting(db, 'audit.maxSegmentsPerRun', DEFAULT_POLICY.maxSegmentsPerRun));
  return {
    retentionDays: Math.min(3650, Math.max(30, Math.round(retentionDays) || DEFAULT_POLICY.retentionDays)),
    maxLiveEvents: Math.min(5_000_000, Math.max(1000, Math.round(maxLiveEvents) || DEFAULT_POLICY.maxLiveEvents)),
    minimumLiveEvents: Math.min(100_000, Math.max(100, Math.round(minimumLiveEvents) || DEFAULT_POLICY.minimumLiveEvents)),
    archiveBatchSize: Math.min(25_000, Math.max(100, Math.round(archiveBatchSize) || DEFAULT_POLICY.archiveBatchSize)),
    maxSegmentsPerRun: Math.min(100, Math.max(1, Math.round(maxSegmentsPerRun) || DEFAULT_POLICY.maxSegmentsPerRun))
  };
}

function lastHash(db) {
  const live = db.prepare('SELECT evidence_hash FROM audit_event WHERE chain_sequence IS NOT NULL ORDER BY chain_sequence DESC LIMIT 1').get();
  if (live?.evidence_hash) return live.evidence_hash;
  return db.prepare('SELECT last_hash FROM audit_archive_segment ORDER BY sequence_no DESC LIMIT 1').get()?.last_hash || null;
}

function eventPayload(row) {
  return {
    occurredAt: row.occurred_at,
    actorUserId: row.actor_user_id,
    actorRole: row.actor_role,
    action: row.action,
    entityType: row.entity_type,
    entityId: row.entity_id,
    before: row.before_json ? JSON.parse(row.before_json) : null,
    after: row.after_json ? JSON.parse(row.after_json) : null,
    correlationId: row.correlation_id,
    source: row.source,
    reason: row.reason,
    previousHash: row.previous_hash,
    ipAddress: row.ip_address,
    equipment: row.equipment,
    result: row.result,
    durationMs: row.duration_ms,
    error: row.error
  };
}

function validateAuditRow(row, expectedPreviousHash) {
  if (row.previous_hash !== expectedPreviousHash) return { valid: false, id: row.id, reason: 'PREVIOUS_HASH_MISMATCH' };
  let payload;
  try { payload = eventPayload(row); } catch { return { valid: false, id: row.id, reason: 'PAYLOAD_JSON_INVALID' }; }
  if (sha256(stableJson(payload)) !== row.evidence_hash) return { valid: false, id: row.id, reason: 'HASH_MISMATCH' };
  return { valid: true, nextHash: row.evidence_hash };
}

function nextChainSequence(db) {
  const live = db.prepare('SELECT MAX(chain_sequence) AS sequence FROM audit_event WHERE chain_sequence IS NOT NULL').get();
  if (Number.isInteger(Number(live?.sequence)) && Number(live.sequence) > 0) return Number(live.sequence) + 1;
  const archived = Number(db.prepare("SELECT COALESCE(SUM(event_count),0) AS count FROM audit_archive_segment WHERE status='VERIFIED'").get()?.count || 0);
  return archived + 1;
}

function appendAudit(event, db = getDb()) {
  const occurredAt = event.occurredAt || new Date().toISOString();
  const previousHash = lastHash(db);
  const chainSequence = nextChainSequence(db);
  const payload = {
    occurredAt,
    actorUserId: event.actorUserId || null,
    actorRole: event.actorRole || null,
    action: event.action,
    entityType: event.entityType,
    entityId: event.entityId || null,
    before: event.before ?? null,
    after: event.after ?? null,
    correlationId: event.correlationId,
    source: event.source || 'API',
    reason: event.reason || null,
    previousHash,
    ipAddress: event.ipAddress || null,
    equipment: event.equipment || null,
    result: event.result || 'SUCCESS',
    durationMs: Number.isFinite(event.durationMs) ? Math.max(0, Math.round(event.durationMs)) : 0,
    error: event.error || null
  };
  const evidenceHash = sha256(stableJson(payload));
  const id = randomUUID();
  db.prepare(`INSERT INTO audit_event(
    id, occurred_at, actor_user_id, actor_role, action, entity_type, entity_id,
    before_json, after_json, correlation_id, source, reason, evidence_hash, previous_hash,
    ip_address, equipment, result, duration_ms, error, created_at, chain_sequence
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(
      id, occurredAt, payload.actorUserId, payload.actorRole, payload.action, payload.entityType,
      payload.entityId, payload.before === null ? null : stableJson(payload.before),
      payload.after === null ? null : stableJson(payload.after), payload.correlationId, payload.source,
      payload.reason, evidenceHash, previousHash, payload.ipAddress, payload.equipment, payload.result,
      payload.durationMs, payload.error, occurredAt, chainSequence
    );
  return { id, evidenceHash, previousHash, chainSequence };
}

function queryWhere(filters = {}) {
  const where = [];
  const params = [];
  if (filters.actorUserId) { where.push('actor_user_id = ?'); params.push(filters.actorUserId); }
  if (filters.action) { where.push('action LIKE ?'); params.push(`%${filters.action}%`); }
  if (filters.entityType) { where.push('entity_type = ?'); params.push(filters.entityType); }
  if (filters.result) { where.push('result = ?'); params.push(filters.result); }
  if (filters.from) { where.push('occurred_at >= ?'); params.push(filters.from); }
  if (filters.to) { where.push('occurred_at <= ?'); params.push(filters.to); }
  return { where, params };
}

function publicAuditRow(row, archived = false, segmentId = null) {
  return {
    ...row,
    before: row.before_json ? JSON.parse(row.before_json) : null,
    after: row.after_json ? JSON.parse(row.after_json) : null,
    archived,
    archive_segment_id: segmentId
  };
}

function rowMatchesFilters(row, filters = {}) {
  if (filters.actorUserId && row.actor_user_id !== filters.actorUserId) return false;
  if (filters.action && !String(row.action || '').toLowerCase().includes(String(filters.action).toLowerCase())) return false;
  if (filters.entityType && row.entity_type !== filters.entityType) return false;
  if (filters.result && row.result !== filters.result) return false;
  if (filters.from && row.occurred_at < filters.from) return false;
  if (filters.to && row.occurred_at > filters.to) return false;
  return true;
}

function archiveFilePath(segment) {
  const candidate = path.resolve(runtime.auditArchiveDir, segment.archive_ref);
  const root = `${path.resolve(runtime.auditArchiveDir)}${path.sep}`;
  if (!candidate.startsWith(root)) throw new Error('AUDIT_ARCHIVE_PATH_INVALID');
  return candidate;
}

function readArchiveRows(segment) {
  const filePath = archiveFilePath(segment);
  const stored = fs.readFileSync(filePath);
  let compressed;
  try {
    compressed = isProtectedBuffer(stored)
      ? unprotectBuffer(stored, { purpose: 'AUDIT_ARCHIVE' }).bytes
      : stored;
  } catch {
    throw Object.assign(new Error('AUDIT_ARCHIVE_SHA256_MISMATCH'), { segmentId: segment.id });
  }
  if (sha256(compressed) !== segment.archive_sha256) throw Object.assign(new Error('AUDIT_ARCHIVE_SHA256_MISMATCH'), { segmentId: segment.id });
  const text = zlib.gunzipSync(compressed).toString('utf8');
  return text.split('\n').filter(Boolean).map((line) => JSON.parse(line));
}


function *iterateAuditRows(filters = {}, options = {}) {
  const db = options.db || getDb();
  const direction = String(options.order || 'DESC').toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
  const includeArchived = String(filters.includeArchived ?? 'true').toLowerCase() !== 'false' && options.archived !== false;
  const includeLive = options.live !== false;
  const { where, params } = queryWhere(filters);
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const liveSql = `SELECT * FROM audit_event ${clause} ORDER BY occurred_at ${direction}, rowid ${direction}`;

  if (direction === 'ASC' && includeArchived) {
    const segments = db.prepare("SELECT * FROM audit_archive_segment WHERE status='VERIFIED' ORDER BY sequence_no ASC").iterate();
    for (const segment of segments) {
      for (const row of readArchiveRows(segment)) {
        if (rowMatchesFilters(row, filters)) yield publicAuditRow(row, true, segment.id);
      }
    }
  }

  if (includeLive) {
    for (const row of db.prepare(liveSql).iterate(...params)) yield publicAuditRow(row, false, null);
  }

  if (direction === 'DESC' && includeArchived) {
    const segments = db.prepare("SELECT * FROM audit_archive_segment WHERE status='VERIFIED' ORDER BY sequence_no DESC").iterate();
    for (const segment of segments) {
      const rows = readArchiveRows(segment);
      for (let index = rows.length - 1; index >= 0; index -= 1) {
        const row = rows[index];
        if (rowMatchesFilters(row, filters)) yield publicAuditRow(row, true, segment.id);
      }
    }
  }
}

function queryAudit(filters = {}) {
  const db = getDb();
  const limit = Math.min(500, Math.max(1, Number(filters.limit) || 100));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const { where, params } = queryWhere(filters);
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const liveCount = Number(db.prepare(`SELECT COUNT(*) AS n FROM audit_event ${clause}`).get(...params).n || 0);
  const items = [];
  let remainingOffset = offset;
  if (remainingOffset < liveCount) {
    const liveLimit = Math.min(limit, liveCount - remainingOffset);
    const rows = db.prepare(`SELECT * FROM audit_event ${clause} ORDER BY occurred_at DESC, rowid DESC LIMIT ? OFFSET ?`)
      .all(...params, liveLimit, remainingOffset);
    items.push(...rows.map((row) => publicAuditRow(row, false, null)));
    remainingOffset = 0;
  } else {
    remainingOffset -= liveCount;
  }
  if (items.length >= limit || String(filters.includeArchived || 'true').toLowerCase() === 'false') return items;
  const segments = db.prepare("SELECT * FROM audit_archive_segment WHERE status='VERIFIED' ORDER BY sequence_no DESC").all();
  for (const segment of segments) {
    const rows = readArchiveRows(segment).reverse();
    for (const row of rows) {
      if (!rowMatchesFilters(row, filters)) continue;
      if (remainingOffset > 0) { remainingOffset -= 1; continue; }
      items.push(publicAuditRow(row, true, segment.id));
      if (items.length >= limit) return items;
    }
  }
  return items;
}

function verifyAuditChain(options = {}) {
  const db = options.db || getDb();
  const verifyArchives = options.verifyArchives !== false;
  let expectedPreviousHash = null;
  let archivedCount = 0;
  let segmentCount = 0;
  if (verifyArchives) {
    const segments = db.prepare("SELECT * FROM audit_archive_segment WHERE status='VERIFIED' ORDER BY sequence_no ASC").all();
    let expectedSequence = 1;
    for (const segment of segments) {
      if (segment.sequence_no !== expectedSequence) return { valid: false, segmentId: segment.id, reason: 'ARCHIVE_SEQUENCE_GAP' };
      if (segment.first_previous_hash !== expectedPreviousHash) return { valid: false, segmentId: segment.id, reason: 'ARCHIVE_BOUNDARY_MISMATCH' };
      let rows;
      try { rows = readArchiveRows(segment); } catch (error) { return { valid: false, segmentId: segment.id, reason: error.message }; }
      if (rows.length !== segment.event_count) return { valid: false, segmentId: segment.id, reason: 'ARCHIVE_COUNT_MISMATCH' };
      if (!rows.length || rows[0].id !== segment.first_event_id || rows.at(-1).id !== segment.last_event_id) return { valid: false, segmentId: segment.id, reason: 'ARCHIVE_BOUNDARY_ID_MISMATCH' };
      for (const row of rows) {
        const expectedSequence = archivedCount + 1;
        if (row.chain_sequence !== undefined && row.chain_sequence !== null && Number(row.chain_sequence) !== expectedSequence) {
          return { valid: false, segmentId: segment.id, id: row.id, reason: 'CHAIN_SEQUENCE_GAP', expectedChainSequence: expectedSequence, actualChainSequence: row.chain_sequence };
        }
        const check = validateAuditRow(row, expectedPreviousHash);
        if (!check.valid) return { ...check, segmentId: segment.id };
        expectedPreviousHash = check.nextHash;
        archivedCount += 1;
      }
      if (expectedPreviousHash !== segment.last_hash) return { valid: false, segmentId: segment.id, reason: 'ARCHIVE_LAST_HASH_MISMATCH' };
      segmentCount += 1;
      expectedSequence += 1;
    }
  } else {
    const lastSegment = db.prepare("SELECT sequence_no,last_hash,event_count FROM audit_archive_segment WHERE status='VERIFIED' ORDER BY sequence_no DESC LIMIT 1").get();
    expectedPreviousHash = lastSegment?.last_hash || null;
    archivedCount = Number(db.prepare("SELECT COALESCE(SUM(event_count),0) AS n FROM audit_archive_segment WHERE status='VERIFIED'").get().n || 0);
    segmentCount = Number(lastSegment?.sequence_no || 0);
  }
  let liveCount = 0;
  let expectedChainSequence = archivedCount + 1;
  const statement = db.prepare('SELECT * FROM audit_event WHERE chain_sequence IS NOT NULL ORDER BY chain_sequence ASC');
  for (const row of statement.iterate()) {
    if (Number(row.chain_sequence) !== expectedChainSequence) return { valid: false, id: row.id, reason: 'CHAIN_SEQUENCE_GAP', expectedChainSequence, actualChainSequence: row.chain_sequence };
    const check = validateAuditRow(row, expectedPreviousHash);
    if (!check.valid) return check;
    expectedPreviousHash = check.nextHash;
    liveCount += 1;
    expectedChainSequence += 1;
  }
  return {
    valid: true,
    count: archivedCount + liveCount,
    archivedCount,
    liveCount,
    segments: segmentCount,
    lastHash: expectedPreviousHash,
    verificationMode: 'ARCHIVE_SEGMENTS_PLUS_CHAIN_SEQUENCE'
  };
}

function atomicWrite(filePath, bytes) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temp = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  const fd = fs.openSync(temp, 'wx', 0o600);
  try {
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  fs.renameSync(temp, filePath);
}

function archiveRows(rows, cutoffAt) {
  if (!rows.length) return null;
  const db = getDb();
  const previousSegment = db.prepare('SELECT sequence_no,last_hash FROM audit_archive_segment ORDER BY sequence_no DESC LIMIT 1').get();
  const sequenceNo = Number(previousSegment?.sequence_no || 0) + 1;
  const expectedPrevious = previousSegment?.last_hash || null;
  if (rows[0].previous_hash !== expectedPrevious) throw Object.assign(new Error('AUDIT_ARCHIVE_PREFIX_REQUIRED'), { code: 'AUDIT_ARCHIVE_PREFIX_REQUIRED' });
  let current = expectedPrevious;
  for (const row of rows) {
    const check = validateAuditRow(row, current);
    if (!check.valid) throw Object.assign(new Error(check.reason), { code: check.reason, eventId: check.id });
    current = check.nextHash;
  }
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  const body = Buffer.from(`${rows.map((row) => JSON.stringify(row)).join('\n')}\n`, 'utf8');
  const compressed = zlib.gzipSync(body, { level: 9 });
  const protectedBytes = protectBuffer(compressed, { purpose: 'AUDIT_ARCHIVE' });
  const archiveRef = `audit-segment-${String(sequenceNo).padStart(6, '0')}-${id}.jsonl.gz`;
  const filePath = path.join(runtime.auditArchiveDir, archiveRef);
  atomicWrite(filePath, protectedBytes);
  const metadata = {
    id,
    sequenceNo,
    createdAt,
    cutoffAt,
    first: rows[0],
    last: rows.at(-1),
    archiveRef,
    archiveSha256: sha256(compressed),
    compressedSize: compressed.length,
    uncompressedSize: body.length
  };
  try {
    transaction((tx) => {
      const persisted = tx.prepare(`SELECT id,evidence_hash FROM audit_event WHERE chain_sequence IS NOT NULL ORDER BY chain_sequence ASC LIMIT ?`).all(rows.length);
      if (persisted.length !== rows.length || persisted.some((row, index) => row.id !== rows[index].id || row.evidence_hash !== rows[index].evidence_hash)) {
        throw Object.assign(new Error('AUDIT_ARCHIVE_SOURCE_CHANGED'), { code: 'AUDIT_ARCHIVE_SOURCE_CHANGED' });
      }
      tx.prepare(`INSERT INTO audit_archive_segment(
        id,sequence_no,created_at,cutoff_at,first_event_id,first_occurred_at,first_previous_hash,first_hash,
        last_event_id,last_occurred_at,last_hash,event_count,archive_ref,archive_sha256,compressed_size,uncompressed_size,status,verified_at
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'VERIFIED',?)`).run(
        id, sequenceNo, createdAt, cutoffAt, metadata.first.id, metadata.first.occurred_at, metadata.first.previous_hash,
        metadata.first.evidence_hash, metadata.last.id, metadata.last.occurred_at, metadata.last.evidence_hash, rows.length,
        archiveRef, metadata.archiveSha256, compressed.length, body.length, createdAt
      );
      const authorize = tx.prepare('INSERT INTO audit_retention_authorization(event_id,segment_id,evidence_hash,authorized_at) VALUES (?,?,?,?)');
      const remove = tx.prepare('DELETE FROM audit_event WHERE id=?');
      for (const row of rows) {
        authorize.run(row.id, id, row.evidence_hash, createdAt);
        const deleted = remove.run(row.id);
        if (deleted.changes !== 1) throw Object.assign(new Error('AUDIT_ARCHIVE_DELETE_FAILED'), { code: 'AUDIT_ARCHIVE_DELETE_FAILED', eventId: row.id });
      }
    });
  } catch (error) {
    try { fs.unlinkSync(filePath); } catch {}
    throw error;
  }
  return {
    segmentId: id,
    sequenceNo,
    eventCount: rows.length,
    firstOccurredAt: rows[0].occurred_at,
    lastOccurredAt: rows.at(-1).occurred_at,
    archiveRef,
    archiveSha256: metadata.archiveSha256,
    compressedSize: compressed.length,
    uncompressedSize: body.length
  };
}

function reconcileAuditArchives(options = {}) {
  fs.mkdirSync(runtime.auditArchiveDir, { recursive: true });
  const db = options.db || getDb();
  const referenced = new Set(db.prepare('SELECT archive_ref FROM audit_archive_segment').all().map((row) => row.archive_ref));
  const missing = [...referenced].filter((name) => !fs.existsSync(path.join(runtime.auditArchiveDir, name)));
  const removed = [];
  const maxAgeMs = Number.isFinite(options.orphanMaxAgeMs) ? Math.max(0, options.orphanMaxAgeMs) : 60 * 60 * 1000;
  const now = Date.now();
  for (const name of fs.readdirSync(runtime.auditArchiveDir)) {
    const fullPath = path.join(runtime.auditArchiveDir, name);
    if (!fs.statSync(fullPath).isFile()) continue;
    const isTemporary = name.endsWith('.tmp');
    const isArchive = /^audit-segment-\d{6}-.+\.jsonl\.gz$/.test(name);
    if (isArchive) {
      const stored = fs.readFileSync(fullPath);
      if (!isProtectedBuffer(stored)) atomicWrite(fullPath, protectBuffer(stored, { purpose: 'AUDIT_ARCHIVE' }));
    }
    if (!isTemporary && (!isArchive || referenced.has(name))) continue;
    if (options.removeOrphans === false) continue;
    const age = now - fs.statSync(fullPath).mtimeMs;
    if (age < maxAgeMs) continue;
    fs.unlinkSync(fullPath);
    removed.push(name);
  }
  return { clean: missing.length === 0, missing, removed, referenced: referenced.size };
}

function applyAuditRetention(options = {}) {
  const db = getDb();
  const policy = auditPolicy(db, options);
  const now = options.now instanceof Date ? options.now : new Date(options.now || Date.now());
  const cutoffAt = new Date(now.getTime() - policy.retentionDays * 86_400_000).toISOString();
  const segments = [];
  reconcileAuditArchives({ db, orphanMaxAgeMs: options.orphanMaxAgeMs });
  for (let index = 0; index < policy.maxSegmentsPerRun; index += 1) {
    const total = Number(db.prepare('SELECT COUNT(*) AS n FROM audit_event').get().n || 0);
    const ageEligible = Number(db.prepare('SELECT COUNT(*) AS n FROM audit_event WHERE occurred_at<?').get(cutoffAt).n || 0);
    const excess = Math.max(0, total - policy.maxLiveEvents);
    const retainable = Math.max(0, total - policy.minimumLiveEvents);
    const target = Math.min(retainable, Math.max(ageEligible, excess));
    if (target <= 0) break;
    const batch = Math.min(target, policy.archiveBatchSize);
    const rows = db.prepare('SELECT * FROM audit_event WHERE chain_sequence IS NOT NULL ORDER BY chain_sequence ASC LIMIT ?').all(batch);
    if (!rows.length) break;
    segments.push(archiveRows(rows, cutoffAt));
  }
  const remaining = Number(db.prepare('SELECT COUNT(*) AS n FROM audit_event').get().n || 0);
  return {
    policy,
    cutoffAt,
    segments,
    archivedEvents: segments.reduce((sum, segment) => sum + segment.eventCount, 0),
    remainingLiveEvents: remaining,
    archiveDirectory: path.basename(runtime.auditArchiveDir),
    reconciliation: reconcileAuditArchives({ db, orphanMaxAgeMs: options.orphanMaxAgeMs })
  };
}

function fileSize(filePath) {
  try { return fs.statSync(filePath).size; } catch { return 0; }
}

function getAuditHealth(options = {}) {
  const db = options.db || getDb();
  const policy = auditPolicy(db, options);
  const live = db.prepare('SELECT COUNT(*) AS count,MIN(occurred_at) AS oldest,MAX(occurred_at) AS newest FROM audit_event').get();
  const archive = db.prepare("SELECT COUNT(*) AS segments,COALESCE(SUM(event_count),0) AS events,COALESCE(SUM(compressed_size),0) AS bytes,MIN(first_occurred_at) AS oldest,MAX(last_occurred_at) AS newest FROM audit_archive_segment WHERE status='VERIFIED'").get();
  const reconciliation = reconcileAuditArchives({ db, removeOrphans: false });
  const cutoffAt = new Date(Date.now() - policy.retentionDays * 86_400_000).toISOString();
  const warnings = [];
  if (Number(live.count) > policy.maxLiveEvents) warnings.push('LIVE_EVENT_LIMIT_EXCEEDED');
  if (live.oldest && live.oldest < cutoffAt && Number(live.count) > policy.minimumLiveEvents) warnings.push('RETENTION_DUE');
  if (reconciliation.missing.length) warnings.push('ARCHIVE_FILE_MISSING');
  const health = {
    status: warnings.length ? 'ATTENTION' : 'OK',
    checkedAt: new Date().toISOString(),
    policy,
    live: { count: Number(live.count || 0), oldest: live.oldest, newest: live.newest },
    archive: { segments: Number(archive.segments || 0), events: Number(archive.events || 0), compressedBytes: Number(archive.bytes || 0), oldest: archive.oldest, newest: archive.newest },
    storage: {
      sqliteBytes: fileSize(runtime.dbPath),
      walBytes: fileSize(`${runtime.dbPath}-wal`),
      archiveBytes: Number(archive.bytes || 0)
    },
    reconciliation,
    warnings
  };
  if (options.verify === true) health.chain = verifyAuditChain({ db });
  return health;
}

function shouldAuditHttpRequest(req, statusCode) {
  const status = Number(statusCode || 0);
  if (status >= 400) return true;
  const method = String(req?.method || 'GET').toUpperCase();
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) return true;
  let pathname = '';
  try { pathname = new URL(String(req?.url || '/'), 'http://local').pathname; } catch { pathname = String(req?.url || '').split('?')[0]; }
  return SENSITIVE_READ_PREFIXES.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`));
}

module.exports = {
  appendAudit,
  queryAudit,
  verifyAuditChain,
  getAuditHealth,
  applyAuditRetention,
  reconcileAuditArchives,
  shouldAuditHttpRequest,
  auditPolicy,
  iterateAuditRows
};
