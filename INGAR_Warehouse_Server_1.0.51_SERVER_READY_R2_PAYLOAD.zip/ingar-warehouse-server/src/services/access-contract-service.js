'use strict';

const {
  ROLE_DEFINITIONS,
  DEFAULT_ROLE_PERMISSIONS,
  MANDATORY_ROLE_PERMISSIONS
} = require('../config/catalogs');
const { resolveUserExperience } = require('./experience-service');

function roleAccessContract() {
  return ROLE_DEFINITIONS.map((role) => {
    const permissions = [...new Set(DEFAULT_ROLE_PERMISSIONS[role.code] || [])].sort();
    const mandatoryPermissions = [...new Set(MANDATORY_ROLE_PERMISSIONS[role.code] || [])].sort();
    return {
      code: role.code,
      name: role.name,
      experience: resolveUserExperience([role.code]),
      defaultPermissions: permissions,
      mandatoryPermissions
    };
  });
}

function permissionRoleIndex() {
  const roles = roleAccessContract();
  const permissions = new Map();
  for (const role of roles) {
    for (const permission of role.defaultPermissions) {
      if (!permissions.has(permission)) permissions.set(permission, []);
      permissions.get(permission).push(role.code);
    }
  }
  return [...permissions.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([permission, roleCodes]) => ({ permission, roleCodes }));
}

function getAccessContract() {
  return {
    schema: 'IWC_ACCESS_CONTRACT_V1',
    generatedFrom: 'src/config/catalogs.js + src/config/experience-model.js',
    routingDecision: 'SERVER',
    authorizationDecision: 'BACKEND_RBAC',
    roles: roleAccessContract(),
    permissionRoleIndex: permissionRoleIndex()
  };
}

module.exports = { roleAccessContract, permissionRoleIndex, getAccessContract };
