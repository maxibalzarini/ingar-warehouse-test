'use strict';

const { randomUUID, createHash } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');
const { userHasScope } = require('./request-service');
const { assertOperationAllowed } = require('./incident-service');
const { syncCustodyOperationalAlerts } = require('./custody-alert-service');
const { syncRequestOperationalAlert } = require('./request-alert-service');
const { hydrateHandover } = require('./warehouse-service');
const { receiveCustody } = require('./custody-service');

const SIMPLE_NATURES = new Set(['CANTIDAD', 'CONSUMIBLE']);

function error(status, code, message, fieldErrors = []) {
  return Object.assign(new Error(message), { status, code, fieldErrors });
}

function requireScope(user, siteId, locationId, permission) {
  if (!userHasScope(user, siteId, locationId, permission)) {
    throw error(403, 'SCOPE_FORBIDDEN', 'La operación está fuera del alcance asignado.');
  }
}

function addRequestEvent(db, requestId, fromStatus, toStatus, actorUserId, reason, correlationId, now) {
  db.prepare(`INSERT INTO request_status_event(id,request_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(randomUUID(), requestId, fromStatus, toStatus, actorUserId, reason || null, now, correlationId, now);
}

function loadRequest(db, requestId) {
  return db.prepare(`SELECT r.*, p.full_name AS requester_name, sl.site_id, sl.code AS location_code, s.code AS site_code
    FROM request r JOIN person p ON p.id=r.requester_person_id JOIN storage_location sl ON sl.id=r.location_id JOIN site s ON s.id=sl.site_id
    WHERE r.id=?`).get(requestId);
}

function loadSimpleItems(db, requestId) {
  return db.prepare(`SELECT ri.id AS request_item_id,ri.asset_id,ri.quantity,ri.status AS request_item_status,
      a.internal_code,a.description,a.location_id,a.status AS asset_status,a.quantity_available,a.quantity_total,a.category_id,
      ac.nature AS category_nature,ac.requires_return,ac.requires_inspection,
      ar.id AS reservation_id,ar.asset_id AS reserved_asset_id,ar.quantity AS reserved_quantity,ar.status AS reservation_status
    FROM request_item ri
    JOIN asset a ON a.id=ri.asset_id
    JOIN asset_category ac ON ac.id=a.category_id
    LEFT JOIN asset_reservation ar ON ar.request_item_id=ri.id AND ar.status='ACTIVA'
    WHERE ri.request_id=? ORDER BY ri.created_at`).all(requestId);
}

function simpleHandoverEligibility(request, items) {
  if (!request) return { eligible: false, reason: 'Solicitud inexistente.' };
  if (request.operation_type !== 'RETIRO') return { eligible: false, reason: 'Las reservas usan el circuito normal.' };
  if (request.status !== 'APROBADA') return { eligible: false, reason: 'La solicitud no está aprobada.' };
  if (!items.length) return { eligible: false, reason: 'La solicitud no tiene bienes.' };
  for (const item of items) {
    if (!SIMPLE_NATURES.has(String(item.category_nature || '').toUpperCase())) {
      return { eligible: false, reason: 'La solicitud contiene bienes serializados, kits o vehículos.' };
    }
    if (item.reservation_status !== 'ACTIVA' || !item.reservation_id || item.reserved_asset_id !== item.asset_id || Number(item.reserved_quantity) !== Number(item.quantity)) {
      return { eligible: false, reason: 'La reserva física ya no coincide con el pedido.' };
    }
  }
  return { eligible: true, reason: null };
}

function quickHandoverRequest(requestId, input, context) {
  const idempotencyKey = requiredString(input.idempotencyKey, 'idempotencyKey', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ });
  return transaction((db) => {
    const existing = db.prepare("SELECT id,request_id,type FROM handover WHERE idempotency_key=?").get(idempotencyKey);
    if (existing) {
      if (existing.request_id !== requestId || existing.type !== 'ENTREGA') {
        throw error(409, 'IDEMPOTENCY_KEY_REUSED', 'La clave de idempotencia pertenece a otra operación.');
      }
      return { handover: hydrateHandover(db, existing.id), idempotent: true, mode: 'DIRECTA' };
    }

    const request = loadRequest(db, requestId);
    if (!request) throw error(404, 'REQUEST_NOT_FOUND', 'Solicitud no encontrada.');
    requireScope(context.user, request.site_id, request.location_id, 'Warehouse.Operate');
    const version = Number(input.version);
    if (!Number.isInteger(version) || version !== request.version) {
      throw error(409, 'CONCURRENCY_CONFLICT', 'La solicitud fue modificada por otra operación.');
    }

    const items = loadSimpleItems(db, requestId);
    const eligibility = simpleHandoverEligibility(request, items);
    if (!eligibility.eligible) throw error(409, 'QUICK_HANDOVER_NOT_ALLOWED', eligibility.reason);

    const now = new Date().toISOString();
    for (const item of items) {
      const asset = db.prepare(`SELECT a.*,ac.nature AS category_nature,ac.requires_return,ac.requires_inspection,sl.site_id
        FROM asset a JOIN asset_category ac ON ac.id=a.category_id JOIN storage_location sl ON sl.id=a.location_id
        WHERE a.id=? AND a.deleted_at IS NULL`).get(item.asset_id);
      if (!asset) throw error(409, 'ASSET_NOT_FOUND', `El bien ${item.internal_code} ya no existe.`);
      assertOperationAllowed(db, {
        personId: request.requester_person_id,
        asset,
        operationType: request.operation_type,
        siteId: request.site_id,
        locationId: request.location_id,
        requestId
      });
    }

    const handoverId = randomUUID();
    const acceptanceHash = createHash('sha256').update(`${requestId}:EXPLICITA:${now}`).digest('hex');
    const observations = String(input.observations || '').trim() || null;
    db.prepare(`INSERT INTO handover(id,request_id,type,operator_user_id,person_id,occurred_at,observations,acceptance_method,acceptance_hash,acceptance_evidence_id,idempotency_key,correlation_id,created_at,work_order_reference_snapshot)
      VALUES (?,?, 'ENTREGA',?,?,?,?, 'EXPLICITA',?,NULL,?,?,?,?)`)
      .run(handoverId, requestId, context.user.id, request.requester_person_id, now, observations, acceptanceHash, idempotencyKey, context.correlationId, now, request.work_order_reference);

    const custodies = [];
    for (const item of items) {
      db.prepare(`INSERT INTO handover_item(id,handover_id,request_item_id,asset_id,quantity,condition,notes,created_at)
        VALUES (?,?,?,?,?,'CONFORME',NULL,?)`).run(randomUUID(), handoverId, item.request_item_id, item.asset_id, item.quantity, now);
      if (Number(item.requires_inspection || 0) === 1) {
        db.prepare(`INSERT INTO inspection(id,asset_id,custody_id,handover_id,inspector_user_id,phase,condition,result,notes,occurred_at,created_at)
          VALUES (?,?,NULL,?,?,'ENTREGA','CONFORME','APROBADO',NULL,?,?)`)
          .run(randomUUID(), item.asset_id, handoverId, context.user.id, now, now);
      }

      if (Number(item.requires_return || 0) === 1) {
        const custodyId = randomUUID();
        const dueAt = request.due_at || new Date(Date.now() + Number(getSetting('custody.defaultDurationHours', 24)) * 3600_000).toISOString();
        db.prepare(`INSERT INTO custody(id,request_id,request_item_id,asset_id,person_id,quantity,exclusive_unit,opened_by_handover_id,opened_at,due_at,status,version,created_at,updated_at,work_order_reference_snapshot)
          VALUES (?,?,?,?,?,?,0,?,?,?,'ABIERTA',1,?,?,?)`)
          .run(custodyId, requestId, item.request_item_id, item.asset_id, request.requester_person_id, item.quantity, handoverId, now, dueAt, now, now, request.work_order_reference);
        db.prepare(`INSERT INTO custody_event(id,custody_id,from_status,to_status,actor_user_id,reason,occurred_at,correlation_id,created_at)
          VALUES (?,?,NULL,'ABIERTA',?,?,?,?,?)`).run(randomUUID(), custodyId, context.user.id, 'Entrega directa confirmada por pañol.', now, context.correlationId, now);
        db.prepare(`UPDATE asset SET status=CASE WHEN quantity_available>0 THEN 'DISPONIBLE' ELSE 'EN_CUSTODIA' END,
          custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?`).run(now, item.asset_id);
        custodies.push(custodyId);
        syncCustodyOperationalAlerts(db, custodyId, new Date(now));
      } else {
        db.prepare(`UPDATE asset SET status='DISPONIBLE',custodian_person_id=NULL,version=version+1,updated_at=? WHERE id=?`).run(now, item.asset_id);
      }

      db.prepare(`UPDATE asset_reservation SET status='CONSUMIDA',release_reason='ENTREGA_DIRECTA_F4',updated_at=? WHERE id=? AND status='ACTIVA'`)
        .run(now, item.reservation_id);
      db.prepare(`UPDATE request_item SET status='ENTREGADO',updated_at=? WHERE id=?`).run(now, item.request_item_id);
    }

    const changed = db.prepare(`UPDATE request SET status='ENTREGADA',version=version+1,updated_at=?
      WHERE id=? AND version=? AND status='APROBADA'`).run(now, requestId, version);
    if (changed.changes !== 1) throw error(409, 'CONCURRENCY_CONFLICT', 'Conflicto al confirmar la entrega directa.');

    syncRequestOperationalAlert(db, requestId, new Date(now));
    addRequestEvent(db, requestId, 'APROBADA', 'ENTREGADA', context.user.id, 'Entrega directa de herramienta/consumible confirmada por pañol.', context.correlationId, now);
    appendAudit({
      actorUserId: context.user.id,
      actorRole: context.user.roleCodes.join(','),
      action: 'WAREHOUSE.QUICK_HANDOVER',
      entityType: 'request',
      entityId: requestId,
      before: { status: 'APROBADA' },
      after: { status: 'ENTREGADA', handoverId, custodyCount: custodies.length, mode: 'DIRECTA' },
      correlationId: context.correlationId,
      ipAddress: context.ip,
      equipment: context.userAgent
    }, db);

    return { handover: hydrateHandover(db, handoverId), idempotent: false, mode: 'DIRECTA' };
  });
}

function quickReceiveCustody(custodyId, input, context) {
  const db = getDb();
  const row = db.prepare(`SELECT c.id,c.version,c.status,ac.nature AS category_nature
    FROM custody c JOIN asset a ON a.id=c.asset_id JOIN asset_category ac ON ac.id=a.category_id WHERE c.id=?`).get(custodyId);
  if (!row) throw error(404, 'CUSTODY_NOT_FOUND', 'Custodia no encontrada.');
  if (!SIMPLE_NATURES.has(String(row.category_nature || '').toUpperCase())) {
    throw error(409, 'QUICK_RECEIVE_NOT_ALLOWED', 'Este bien requiere el circuito específico de devolución.');
  }
  // F22: la ruta rápida deja de ser un cierre ciego. Un cliente antiguo no puede
  // saltarse la revisión previa del pañolero.
  if (input.reviewConfirmed !== true) {
    throw error(422, 'WAREHOUSE_RECEPTION_REVIEW_REQUIRED', 'Antes de recibir, el pañolero debe revisar la devolución y confirmar si agrega un comentario.');
  }
  const condition = String(input.condition || 'CONFORME').toUpperCase();
  const warehouseComment = String(input.warehouseComment || '').trim() || null;
  return receiveCustody(custodyId, {
    version: Number.isInteger(Number(input.version)) ? Number(input.version) : row.version,
    condition,
    warehouseComment,
    reviewConfirmed: true,
    returnQuantity: input.returnQuantity,
    receivedAt: new Date().toISOString(),
    idempotencyKey: requiredString(input.idempotencyKey, 'idempotencyKey', { min: 8, max: 120, pattern: /^[A-Za-z0-9._:-]+$/ })
  }, context);
}

module.exports = {
  SIMPLE_NATURES,
  simpleHandoverEligibility,
  quickHandoverRequest,
  quickReceiveCustody
};
