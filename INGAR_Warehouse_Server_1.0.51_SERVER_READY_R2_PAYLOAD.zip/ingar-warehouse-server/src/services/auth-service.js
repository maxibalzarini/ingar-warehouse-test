'use strict';

const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { verifyPassword, hashPassword, validatePassword, validateOperationalCredential, DUMMY_HASH } = require('../security/password');
const { randomToken, hashToken } = require('../security/tokens');
const { checkLoginRateLimit, registerLoginFailure, clearLoginFailures } = require('../security/rate-limit');
const { effectiveAuthorization } = require('./permission-service');
const { getSetting } = require('./settings-service');
const { appendAudit } = require('./audit-service');
const logger = require('./logger');
const runtime = require('../config/runtime');
const { markInitialAccessCompleted } = require('./bootstrap-access-service');
const { usesSimpleOperationalCredential, canUseRequesterTablet } = require('../config/operational-model');
const { resolveUserExperience } = require('./experience-service');
const { technicalUsernameBase, requiredString } = require('../security/validation');

function publicUser(user, authz) {
  return {
    id: user.id,
    username: user.username,
    personId: user.person_id,
    fullName: user.full_name,
    email: user.email,
    photoEvidenceId: user.photo_evidence_id || null,
    mustChangePassword: Boolean(user.must_change_password),
    credentialSetupReason: user.credential_setup_reason || (user.must_change_password ? 'INITIAL_SETUP' : 'NONE'),
    lastLoginAt: user.last_login_at,
    roleCodes: authz.roleCodes,
    roles: authz.roles,
    permissions: authz.permissions,
    deniedPermissions: authz.deniedPermissions || [],
    experience: resolveUserExperience(authz.roleCodes)
  };
}

function baseIdentityQuery() {
  return `SELECT ua.*, p.full_name, p.email, p.employee_number, p.document_number, p.photo_evidence_id, p.status AS person_status
    FROM user_account ua JOIN person p ON p.id = ua.person_id`;
}

function getUserByUsername(username) {
  return getDb().prepare(`${baseIdentityQuery()}
    WHERE ua.username = ? COLLATE NOCASE AND ua.deleted_at IS NULL`).get(username);
}

function getUserById(id) {
  return getDb().prepare(`${baseIdentityQuery()}
    WHERE ua.id = ? AND ua.deleted_at IS NULL`).get(id);
}

function getUserByOperationalIdentifier(identifier) {
  const value = String(identifier || '').trim();
  if (!value) return null;
  const byUsername = getUserByUsername(value.toLowerCase());
  if (byUsername) return byUsername;
  const rows = getDb().prepare(`${baseIdentityQuery()}
    WHERE ua.deleted_at IS NULL AND (p.employee_number = ? COLLATE NOCASE OR p.document_number = ? COLLATE NOCASE)
    ORDER BY ua.created_at LIMIT 2`).all(value, value);
  return rows.length === 1 ? rows[0] : null;
}

function getPersonByOptionalIdentifier(identifier) {
  const value = String(identifier || '').trim();
  if (!value || value.length > 80) return null;
  const rows = getDb().prepare(`SELECT p.*
    FROM person p
    WHERE p.deleted_at IS NULL
      AND (p.employee_number = ? COLLATE NOCASE OR p.document_number = ? COLLATE NOCASE)
    ORDER BY p.created_at
    LIMIT 2`).all(value, value);
  return rows.length === 1 ? rows[0] : null;
}

function getUserByPersonId(personId) {
  if (!personId) return null;
  return getDb().prepare(`${baseIdentityQuery()}
    WHERE ua.person_id = ? AND ua.deleted_at IS NULL
    LIMIT 1`).get(personId);
}

function loginFailure(user, now, requestContext, started, { action = 'AUTH.LOGIN_FAILED', source = 'API' } = {}) {
  const maxAttempts = Number(getSetting('security.maxFailedAttempts', 5));
  const lockMinutes = Number(getSetting('security.lockMinutes', 15));
  registerLoginFailure(requestContext.ip);
  if (user) {
    transaction((db) => {
      const failed = Number(user.failed_attempts || 0) + 1;
      const lockUntil = failed >= maxAttempts ? new Date(now.getTime() + lockMinutes * 60_000).toISOString() : user.locked_until;
      db.prepare('UPDATE user_account SET failed_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(failed, lockUntil || null, now.toISOString(), user.id);
      appendAudit({ actorUserId: user.id, action, entityType: 'user_account', entityId: user.id, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'DENIED', durationMs: Date.now() - started, error: 'INVALID_CREDENTIALS' }, db);
    });
  } else {
    appendAudit({ action, entityType: 'user_account', correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'DENIED', durationMs: Date.now() - started, error: 'INVALID_CREDENTIALS' });
  }
}

async function createAuthenticatedSession({ user, password, remember = false, sessionSeconds, requestContext, auditPrefix = 'AUTH.LOGIN', source = 'API' }) {
  const started = Date.now();
  if (!checkLoginRateLimit(requestContext.ip)) {
    appendAudit({ action: `${auditPrefix}_RATE_LIMITED`, entityType: 'user_account', entityId: null, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'DENIED', durationMs: Date.now() - started });
    throw Object.assign(new Error('Demasiados intentos. Intente nuevamente más tarde.'), { status: 429, code: 'RATE_LIMITED' });
  }

  const valid = await verifyPassword(String(password || ''), user?.password_hash || DUMMY_HASH);
  const now = new Date();
  const locked = user?.locked_until && new Date(user.locked_until) > now;
  const allowed = Boolean(user && valid && !locked && user.active && user.person_status === 'ACTIVA');
  if (!allowed) {
    loginFailure(user, now, requestContext, started, { action: `${auditPrefix}_FAILED`, source });
    throw Object.assign(new Error('Credenciales inválidas o cuenta no disponible.'), { status: 401, code: 'INVALID_CREDENTIALS' });
  }

  const authz = effectiveAuthorization(user.id);

  clearLoginFailures(requestContext.ip);
  const sessionToken = randomToken(32);
  const csrfToken = randomToken(24);
  const seconds = Math.max(60, Number(sessionSeconds) || runtime.normalSessionSeconds);
  const expiresAt = new Date(now.getTime() + seconds * 1000).toISOString();
  const sessionId = randomUUID();
  transaction((db) => {
    db.prepare(`INSERT INTO user_session(id, user_id, token_hash, csrf_token_hash, created_at, last_seen_at, expires_at, remember, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(sessionId, user.id, hashToken(sessionToken), hashToken(csrfToken), now.toISOString(), now.toISOString(), expiresAt, remember ? 1 : 0, requestContext.ip, requestContext.userAgent);
    db.prepare('UPDATE user_account SET failed_attempts = 0, locked_until = NULL, last_login_at = ?, updated_at = ? WHERE id = ?')
      .run(now.toISOString(), now.toISOString(), user.id);
    appendAudit({ actorUserId: user.id, actorRole: authz.roleCodes.join(','), action: `${auditPrefix}_SUCCESS`, entityType: 'user_session', entityId: sessionId, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'SUCCESS', durationMs: Date.now() - started }, db);
  });
  const fresh = getUserById(user.id);
  logger.info('AUTH', 'Inicio de sesión correcto.', { userId: user.id }, requestContext.correlationId);
  return { sessionToken, csrfToken, expiresAt, user: publicUser(fresh, authz) };
}

async function login({ username, identifier, password, remember }, requestContext) {
  const normalized = String(identifier || username || '').trim();
  const user = normalized ? getUserByOperationalIdentifier(normalized) : null;
  if (user?.must_change_password) {
    if (user.credential_setup_reason === 'PASSWORD_RESET') {
      throw Object.assign(new Error('La contraseña fue blanqueada. Complete únicamente la nueva contraseña; su usuario no cambia.'), { status: 403, code: 'PASSWORD_RESET_REQUIRED' });
    }
    const authz = effectiveAuthorization(user.id);
    if (authz.roleCodes.includes('SOLICITANTE') && usesSimpleOperationalCredential(authz.roleCodes)) {
      throw Object.assign(new Error('Tu acceso todavía no está configurado. Elegí CREAR MI ACCESO y definí tu usuario y contraseña.'), { status: 403, code: 'FIRST_ACCESS_REQUIRED' });
    }
    throw Object.assign(new Error('El acceso inicial todavía no fue configurado. Completá Usuario, Contraseña y Repetir contraseña en la pantalla de primer ingreso.'), { status: 403, code: 'INITIAL_SETUP_REQUIRED' });
  }
  const seconds = remember
    ? Number(getSetting('security.rememberSessionSeconds', runtime.rememberSessionSeconds))
    : Number(getSetting('security.sessionSeconds', runtime.normalSessionSeconds));
  return createAuthenticatedSession({ user, password, remember: Boolean(remember), sessionSeconds: seconds, requestContext });
}

function operationalAccessState(identifier, requestContext, source = 'UNIFIED_AUTH') {
  const started = Date.now();
  const context = requestContext || { correlationId: null, ip: 'unknown', userAgent: '' };
  if (!checkLoginRateLimit(context.ip)) {
    appendAudit({ action: 'AUTH.ACCESS_STATE_RATE_LIMITED', entityType: 'user_account', correlationId: context.correlationId, source, ipAddress: context.ip, equipment: context.userAgent, result: 'DENIED', durationMs: Date.now() - started, error: 'RATE_LIMITED' });
    throw Object.assign(new Error('Demasiados intentos. Intente nuevamente más tarde.'), { status: 429, code: 'RATE_LIMITED' });
  }
  // Todo probe de access-state consume cuota, incluso si el identificador existe.
  // El login exitoso limpia la cuota de la IP compartida.
  registerLoginFailure(context.ip);

  const value = String(identifier || '').trim();
  if (!value || value.length > 80) {
    appendAudit({ action: 'AUTH.ACCESS_STATE_DENIED', entityType: 'user_account', correlationId: context.correlationId, source, ipAddress: context.ip, equipment: context.userAgent, result: 'DENIED', durationMs: Date.now() - started, error: 'IDENTIFIER_INVALID' });
    throw Object.assign(new Error('Ingresá tu usuario, legajo o DNI.'), { status: 422, code: 'IDENTIFIER_REQUIRED' });
  }

  const user = getUserByOperationalIdentifier(value);
  let authz = null;
  if (user && user.active && user.person_status === 'ACTIVA') authz = effectiveAuthorization(user.id);
  if (!user || !user.active || user.person_status !== 'ACTIVA' || !canUseRequesterTablet(authz?.roleCodes || [])) {
    appendAudit({ actorUserId: user?.id || null, actorRole: authz?.roleCodes?.join(',') || null, action: 'AUTH.ACCESS_STATE_DENIED', entityType: 'user_account', entityId: user?.id || null, correlationId: context.correlationId, source, ipAddress: context.ip, equipment: context.userAgent, result: 'DENIED', durationMs: Date.now() - started, error: 'ACCESS_NOT_AVAILABLE' });
    throw Object.assign(new Error('No encontramos una cuenta habilitada para continuar.'), { status: 404, code: 'ACCESS_NOT_AVAILABLE' });
  }

  appendAudit({ actorUserId: user.id, actorRole: authz.roleCodes.join(','), action: 'AUTH.ACCESS_STATE_ALLOWED', entityType: 'user_account', entityId: user.id, correlationId: context.correlationId, source, ipAddress: context.ip, equipment: context.userAgent, result: 'SUCCESS', durationMs: Date.now() - started });
  return {
    id: user.id,
    fullName: user.full_name,
    username: user.credential_setup_reason === 'PASSWORD_RESET' ? user.username : (user.must_change_password ? null : user.username),
    configured: !Boolean(user.must_change_password),
    setupMode: user.must_change_password ? (user.credential_setup_reason === 'PASSWORD_RESET' ? 'PASSWORD_RESET' : 'INITIAL_SETUP') : 'NONE',
    identifier: value
  };
}

function accessState(identifier, requestContext) { return operationalAccessState(identifier, requestContext, 'API'); }


function defaultAdministratorForSupervisor(db) {
  return db.prepare(`SELECT ua.id AS user_id, p.id AS person_id
    FROM user_account ua
    JOIN person p ON p.id = ua.person_id
    JOIN user_role_scope urs ON urs.user_id = ua.id
    JOIN role r ON r.id = urs.role_id
    WHERE r.code = 'ADMIN_GENERAL' AND r.active = 1
      AND ua.active = 1 AND ua.deleted_at IS NULL
      AND p.status = 'ACTIVA' AND p.deleted_at IS NULL
    ORDER BY ua.created_at, ua.id LIMIT 1`).get();
}

function ensureCurrentSupervisorAssignment(db, userId, personId, actorUserId = null, reason = 'FIRST_ACCESS') {
  let person = db.prepare('SELECT supervisor_person_id FROM person WHERE id = ? LIMIT 1').get(personId);
  let supervisorPersonId = person?.supervisor_person_id || null;
  if (!supervisorPersonId) {
    const administrator = defaultAdministratorForSupervisor(db);
    if (!administrator) throw Object.assign(new Error('No existe un Administrador General activo para asignar como supervisor.'), { status: 409, code: 'SUPERVISOR_ADMIN_REQUIRED' });
    if (administrator.person_id === personId) return null;
    supervisorPersonId = administrator.person_id;
    db.prepare('UPDATE person SET supervisor_person_id = ?, version = version + 1, updated_at = ? WHERE id = ?')
      .run(supervisorPersonId, new Date().toISOString(), personId);
  }
  const supervisorUser = db.prepare('SELECT id FROM user_account WHERE person_id = ? AND deleted_at IS NULL LIMIT 1').get(supervisorPersonId);
  if (!supervisorUser || supervisorUser.id === userId) return null;
  const active = db.prepare('SELECT id, supervisor_user_id FROM user_supervisor_assignment WHERE user_id = ? AND effective_to IS NULL LIMIT 1').get(userId);
  if (active?.supervisor_user_id === supervisorUser.id) return supervisorUser.id;
  const now = new Date().toISOString();
  if (active) db.prepare('UPDATE user_supervisor_assignment SET effective_to = ? WHERE id = ?').run(now, active.id);
  db.prepare(`INSERT INTO user_supervisor_assignment(
    id, user_id, supervisor_user_id, assigned_by_user_id, effective_from, effective_to, reason, created_at
  ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?)`)
    .run(randomUUID(), userId, supervisorUser.id, actorUserId, now, reason, now);
  return supervisorUser.id;
}

function allocateTechnicalUsername(db, fullName, excludeUserId = null) {
  const base = technicalUsernameBase(fullName);
  const exists = (candidate) => Boolean(db.prepare(`SELECT 1 FROM user_account
    WHERE username = ? COLLATE NOCASE AND deleted_at IS NULL AND (? IS NULL OR id <> ?) LIMIT 1`).get(candidate, excludeUserId, excludeUserId));
  if (!exists(base)) return base;
  for (let suffix = 2; suffix <= 9999; suffix += 1) {
    const candidate = `${base}.${suffix}`;
    if (!exists(candidate)) return candidate;
  }
  throw Object.assign(new Error('No se pudo generar un usuario técnico único para ese nombre.'), { status: 409, code: 'TECHNICAL_USERNAME_EXHAUSTED' });
}


async function operationalFirstAccess({ identifier, documentType, fullName, username, password, confirmPassword }, requestContext, source = 'UNIFIED_AUTH') {
  // El identificador se usa tanto para vincular una ficha existente como para persistir
  // una identidad real cuando se crea una nueva persona. No se fabrican documentos.
  const identity = requiredString(identifier, 'identifier', { min: 1, max: 60 });
  const suppliedDocumentType = requiredString(documentType, 'documentType', { min: 1, max: 30 }).toUpperCase();
  const desiredFullName = String(fullName || '').trim();
  // F18: el usuario técnico ya no se elige libremente; se deriva de nombre.apellido.
  void username;
  const credential = String(password || '');
  const confirmation = String(confirmPassword || '');
  if (!desiredFullName || desiredFullName.length < 2 || desiredFullName.length > 160) {
    throw Object.assign(new Error('Ingresá tu nombre.'), { status: 422, code: 'FIRST_ACCESS_NAME_REQUIRED' });
  }
  if (credential !== confirmation) throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'FIRST_ACCESS_PASSWORD_MISMATCH' });
  const errors = validateOperationalCredential(credential,
    Number(getSetting('security.operationalCredentialMinLength', runtime.operationalCredentialMinLength)),
    Number(getSetting('security.operationalCredentialMaxLength', runtime.operationalCredentialMaxLength)));
  if (errors.length) throw Object.assign(new Error(errors[0]), { status: 422, code: 'FIRST_ACCESS_PASSWORD_POLICY' });

  const db = getDb();

  const matchedPerson = identity ? getPersonByOptionalIdentifier(identity) : null;
  const linkedUser = matchedPerson ? getUserByPersonId(matchedPerson.id) : null;
  const desiredUsername = allocateTechnicalUsername(db, desiredFullName, linkedUser?.id || null);

  // Sólo se reaprovecha una cuenta preexistente cuando es un SOLICITANTE pendiente.
  // Si el identificador ya pertenece a otra cuenta o a una persona inactiva, se rechaza
  // el alta en lugar de duplicar identidad o convertir otro rol en SOLICITANTE.
  if (matchedPerson) {
    if (matchedPerson.status !== 'ACTIVA') {
      throw Object.assign(new Error('La identidad indicada corresponde a una persona no activa. Avisá al administrador.'), { status: 409, code: 'FIRST_ACCESS_IDENTITY_INACTIVE' });
    }
    if (linkedUser?.must_change_password && linkedUser.credential_setup_reason !== 'PASSWORD_RESET') {
      const authz = effectiveAuthorization(linkedUser.id);
      if (authz.roleCodes.includes('SOLICITANTE')) {
        const passwordHash = await hashPassword(credential);
        const now = new Date().toISOString();
        transaction((tx) => {
          tx.prepare(`UPDATE user_account SET username = ?, password_hash = ?, must_change_password = 0, credential_setup_reason = 'NONE',
            failed_attempts = 0, locked_until = NULL, last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?`)
            .run(desiredUsername, passwordHash, now, now, linkedUser.id);
          tx.prepare('UPDATE person SET full_name = ?, updated_at = ?, version = version + 1 WHERE id = ?')
            .run(desiredFullName, now, matchedPerson.id);
          ensureCurrentSupervisorAssignment(tx, linkedUser.id, matchedPerson.id, linkedUser.id, 'FIRST_ACCESS_SETUP');
          tx.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
            .run(randomUUID(), linkedUser.id, passwordHash, now);
          revokeAllUserSessions(linkedUser.id, 'FIRST_ACCESS_SETUP', null, tx);
          appendAudit({ actorUserId: linkedUser.id, actorRole: authz.roleCodes.join(','), action: 'AUTH.FIRST_ACCESS_SETUP', entityType: 'user_account', entityId: linkedUser.id, after: { username: desiredUsername, fullName: desiredFullName, linkedByIdentifier: true }, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'SUCCESS' }, tx);
        });
        return { configured: true, username: desiredUsername, created: false, linked: true };
      }
    }
    if (linkedUser) {
      throw Object.assign(new Error('La identidad indicada ya está asociada a otra cuenta. Avisá al administrador.'), { status: 409, code: 'FIRST_ACCESS_IDENTITY_ALREADY_LINKED' });
    }
  }

  const role = db.prepare("SELECT id FROM role WHERE code = 'SOLICITANTE' AND active = 1 LIMIT 1").get();
  if (!role) throw Object.assign(new Error('No está disponible el perfil de solicitante. Avisá al administrador.'), { status: 500, code: 'FIRST_ACCESS_REQUESTER_ROLE_MISSING' });
  const passwordHash = await hashPassword(credential);
  const now = new Date().toISOString();
  const userId = randomUUID();

  // Si existe una ficha activa sin cuenta, se vincula a esa ficha. En caso contrario
  // se crea una ficha SOLICITANTE con la identidad ingresada por el propio usuario.
  const canLinkPersonWithoutUser = Boolean(matchedPerson && matchedPerson.status === 'ACTIVA' && !linkedUser);
  const personId = canLinkPersonWithoutUser ? matchedPerson.id : randomUUID();

  transaction((tx) => {
    if (!canLinkPersonWithoutUser) {
      const administrator = defaultAdministratorForSupervisor(tx);
      if (!administrator) throw Object.assign(new Error('No existe un Administrador General activo para asignar como supervisor.'), { status: 409, code: 'SUPERVISOR_ADMIN_REQUIRED' });
      tx.prepare(`INSERT INTO person(
        id, document_type, document_number, full_name, supervisor_person_id, status, version, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'ACTIVA', 1, ?, ?)`)
        .run(personId, suppliedDocumentType, identity, desiredFullName, administrator.person_id, now, now);
    } else {
      tx.prepare('UPDATE person SET full_name = ?, updated_at = ?, version = version + 1 WHERE id = ?')
        .run(desiredFullName, now, personId);
    }
    tx.prepare(`INSERT INTO user_account(
      id, person_id, username, password_hash, failed_attempts, active, must_change_password, credential_setup_reason,
      last_password_change_at, version, created_at, updated_at
    ) VALUES (?, ?, ?, ?, 0, 1, 0, 'NONE', ?, 1, ?, ?)`)
      .run(userId, personId, desiredUsername, passwordHash, now, now, now);
    tx.prepare(`INSERT INTO user_role_scope(
      id, user_id, role_id, site_id, location_id, valid_from, valid_to, created_at, updated_at
    ) VALUES (?, ?, ?, NULL, NULL, ?, NULL, ?, ?)`)
      .run(randomUUID(), userId, role.id, now, now, now);
    ensureCurrentSupervisorAssignment(tx, userId, personId, userId, 'FIRST_ACCESS_SELF_REGISTER');
    tx.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), userId, passwordHash, now);
    appendAudit({ actorUserId: userId, actorRole: 'SOLICITANTE', action: 'AUTH.FIRST_ACCESS_SELF_REGISTER', entityType: 'user_account', entityId: userId, after: { username: desiredUsername, fullName: desiredFullName, documentType: suppliedDocumentType, identifierProvided: true, linkedExistingPerson: canLinkPersonWithoutUser }, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'SUCCESS' }, tx);
  });
  return { configured: true, username: desiredUsername, created: true, linked: canLinkPersonWithoutUser };
}

async function operationalCompletePasswordReset({ identifier, password, confirmPassword }, requestContext, source = 'UNIFIED_AUTH') {
  const user = getUserByOperationalIdentifier(identifier);
  if (!user || !user.active || user.person_status !== 'ACTIVA' || !user.must_change_password || user.credential_setup_reason !== 'PASSWORD_RESET') {
    throw Object.assign(new Error('No hay un blanqueo de contraseña pendiente para esta cuenta.'), { status: 409, code: 'PASSWORD_RESET_NOT_PENDING' });
  }
  if (String(password || '') !== String(confirmPassword || '')) throw Object.assign(new Error('Las contraseñas no coinciden.'), { status: 422, code: 'PASSWORD_MISMATCH' });
  const errors = validateOperationalCredential(String(password || ''), Number(getSetting('security.operationalCredentialMinLength', runtime.operationalCredentialMinLength)), Number(getSetting('security.operationalCredentialMaxLength', runtime.operationalCredentialMaxLength)));
  if (errors.length) throw Object.assign(new Error(errors[0]), { status: 422, code: 'PASSWORD_POLICY' });
  const hash = await hashPassword(String(password));
  transaction((db) => {
    const now = new Date().toISOString();
    db.prepare(`UPDATE user_account SET password_hash=?, must_change_password=0, credential_setup_reason='NONE', failed_attempts=0, locked_until=NULL, last_password_change_at=?, version=version+1, updated_at=? WHERE id=?`).run(hash, now, now, user.id);
    db.prepare('INSERT INTO password_history(id,user_id,password_hash,created_at) VALUES (?,?,?,?)').run(randomUUID(), user.id, hash, now);
    db.prepare(`UPDATE password_reset_event SET status='COMPLETED', completed_at=?, completion_source=? WHERE target_user_id=? AND status='PENDING'`).run(now, source, user.id);
    revokeAllUserSessions(user.id, 'PASSWORD_RESET_COMPLETED', null, db);
    appendAudit({ actorUserId:user.id, action:'AUTH.PASSWORD_RESET_COMPLETED', entityType:'user_account', entityId:user.id, after:{username:user.username, personId:user.person_id, identityPreserved:true}, correlationId:requestContext.correlationId, source, ipAddress:requestContext.ip, equipment:requestContext.userAgent, result:'SUCCESS' }, db);
  });
  return { completed:true, username:user.username, identityPreserved:true };
}

async function firstAccess(payload, requestContext) { return operationalFirstAccess(payload, requestContext, 'API'); }
async function completePasswordReset(payload, requestContext) { return operationalCompletePasswordReset(payload, requestContext, 'API'); }

function authenticateSessionInternal(sessionToken, requestContext = null) {
  if (!sessionToken) return null;
  const source = 'API';
  const tokenHash = hashToken(sessionToken);
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const row = getDb().prepare(`SELECT s.*, ua.username, ua.person_id, ua.active, ua.must_change_password, ua.last_login_at,
      p.full_name, p.email, p.photo_evidence_id, p.status AS person_status
    FROM user_session s
    JOIN user_account ua ON ua.id = s.user_id
    JOIN person p ON p.id = ua.person_id
    WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > ?
      AND ua.active = 1 AND ua.deleted_at IS NULL AND p.status = 'ACTIVA'`).get(tokenHash, now);
  if (!row) return null;

  if (requestContext?.userAgent && row.user_agent && row.user_agent !== requestContext.userAgent) {
    getDb().prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE id = ? AND revoked_at IS NULL')
      .run(now, 'USER_AGENT_MISMATCH', row.id);
    appendAudit({ actorUserId: row.user_id, action: 'AUTH.SESSION_FINGERPRINT_MISMATCH', entityType: 'user_session', entityId: row.id, correlationId: requestContext.correlationId || randomUUID(), source, ipAddress: requestContext.ip, equipment: requestContext.userAgent, result: 'DENIED', error: 'USER_AGENT_MISMATCH' });
    return null;
  }

  const authz = effectiveAuthorization(row.user_id);
  getDb().prepare('UPDATE user_session SET last_seen_at = ? WHERE id = ?').run(now, row.id);
  return {
    session: row,
    csrfTokenHash: row.csrf_token_hash,
    user: publicUser({ id: row.user_id, username: row.username, person_id: row.person_id, full_name: row.full_name, email: row.email, photo_evidence_id: row.photo_evidence_id, must_change_password: row.must_change_password, last_login_at: row.last_login_at }, authz)
  };
}

function authenticateSession(sessionToken, requestContext = null) {
  return authenticateSessionInternal(sessionToken, requestContext);
}


function rotateCsrfToken(auth) {
  if (!auth?.session?.id) return null;
  const csrfToken = randomToken(24);
  const now = new Date().toISOString();
  getDb().prepare('UPDATE user_session SET csrf_token_hash = ?, last_seen_at = ? WHERE id = ? AND revoked_at IS NULL')
    .run(hashToken(csrfToken), now, auth.session.id);
  auth.csrfTokenHash = hashToken(csrfToken);
  return csrfToken;
}

function validateCsrf(auth, csrfToken) {
  return Boolean(auth && csrfToken && hashToken(csrfToken) === auth.csrfTokenHash);
}

function logout(auth, requestContext, options = {}) {
  if (!auth) return;
  const source = options.source || 'API';
  const action = options.action || 'AUTH.LOGOUT';
  transaction((db) => {
    const now = new Date().toISOString();
    db.prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE id = ? AND revoked_at IS NULL')
      .run(now, options.reason || 'LOGOUT', auth.session.id);
    appendAudit({ actorUserId: auth.user.id, actorRole: auth.user.roleCodes.join(','), action, entityType: 'user_session', entityId: auth.session.id, correlationId: requestContext.correlationId, source, ipAddress: requestContext.ip, equipment: requestContext.userAgent }, db);
  });
}


async function changePassword(auth, currentPassword, newPassword, requestContext) {
  const user = getUserById(auth.user.id);
  if (!await verifyPassword(String(currentPassword || ''), user.password_hash)) {
    throw Object.assign(new Error('La contraseña actual no es correcta.'), { status: 422, code: 'CURRENT_PASSWORD_INVALID' });
  }
  const simple = usesSimpleOperationalCredential(auth.user.roleCodes);
  const errors = validatePassword(newPassword, 4, 8);
  if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 422, code: 'PASSWORD_POLICY' });
  const passwordHash = await hashPassword(newPassword);
  transaction((db) => {
    const now = new Date().toISOString();
    db.prepare("UPDATE user_account SET password_hash = ?, must_change_password = 0, credential_setup_reason = 'NONE', last_password_change_at = ?, version = version + 1, updated_at = ? WHERE id = ?")
      .run(passwordHash, now, now, user.id);
    db.prepare('INSERT INTO password_history(id, user_id, password_hash, created_at) VALUES (?, ?, ?, ?)')
      .run(randomUUID(), user.id, passwordHash, now);
    db.prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE user_id = ? AND id <> ? AND revoked_at IS NULL')
      .run(now, 'PASSWORD_CHANGED', user.id, auth.session.id);
    appendAudit({ actorUserId: user.id, actorRole: auth.user.roleCodes.join(','), action: 'AUTH.PASSWORD_CHANGED', entityType: 'user_account', entityId: user.id, correlationId: requestContext.correlationId, source: 'API', ipAddress: requestContext.ip, equipment: requestContext.userAgent }, db);
  });
  markInitialAccessCompleted(user.id, path.dirname(runtime.dataDir));
  return { changed: true, credentialType: simple ? 'OPERATIONAL_PIN' : 'PASSWORD' };
}

function revokeAllUserSessions(userId, reason, exceptSessionId = null, db = getDb()) {
  const now = new Date().toISOString();
  if (exceptSessionId) db.prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE user_id = ? AND id <> ? AND revoked_at IS NULL').run(now, reason, userId, exceptSessionId);
  else db.prepare('UPDATE user_session SET revoked_at = ?, revocation_reason = ? WHERE user_id = ? AND revoked_at IS NULL').run(now, reason, userId);
}

module.exports = {
  accessState,
  login,
  firstAccess,
  completePasswordReset,
  authenticateSession,
  validateCsrf,
  rotateCsrfToken,
  logout,
  changePassword,
  getUserById,
  getUserByOperationalIdentifier,
  revokeAllUserSessions
};
