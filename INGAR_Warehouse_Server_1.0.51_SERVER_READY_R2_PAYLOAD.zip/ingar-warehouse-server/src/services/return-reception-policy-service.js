'use strict';

const CONDITIONS = new Set(['CONFORME', 'OBSERVADO', 'DANADO', 'INCOMPLETO']);
const RANK = { CONFORME: 0, OBSERVADO: 1, DANADO: 2, INCOMPLETO: 3 };

function normalizeCondition(value, fallback = 'CONFORME') {
  const normalized = String(value || fallback).toUpperCase();
  return CONDITIONS.has(normalized) ? normalized : fallback;
}

function strongestReturnCondition(...values) {
  let result = 'CONFORME';
  for (const value of values) {
    const condition = normalizeCondition(value);
    if (RANK[condition] > RANK[result]) result = condition;
  }
  return result;
}


function booleanFlag(value) {
  return value === true || value === 1 || String(value || '').toLowerCase() === 'true';
}

function evaluateReturnDeclarationPolicy({ nature, condition, problemReported, notes }) {
  const normalizedNature = String(nature || '').toUpperCase();
  const requestedCondition = normalizeCondition(condition);
  const comment = String(notes || '').trim();
  const commentImpliesProblem = normalizedNature !== 'VEHICULO' && comment.length > 0;
  const hasProblem = booleanFlag(problemReported) || requestedCondition !== 'CONFORME' || commentImpliesProblem;
  const effectiveCondition = commentImpliesProblem && requestedCondition === 'CONFORME' ? 'OBSERVADO' : requestedCondition;
  return {
    nature: normalizedNature,
    requestedCondition,
    effectiveCondition,
    notes: comment || null,
    commentImpliesProblem,
    problemReported: hasProblem
  };
}

function evaluateReceptionPolicy({ nature, requestedCondition, declaredCondition, kitCondition, warehouseComment, vehicleSafetyObservation = false }) {
  const normalizedNature = String(nature || '').toUpperCase();
  const comment = String(warehouseComment || '').trim();
  const commentForcesObservation = normalizedNature !== 'VEHICULO' && comment.length > 0;
  const safetyObservation = normalizedNature === 'VEHICULO' && booleanFlag(vehicleSafetyObservation);
  const effectiveCondition = strongestReturnCondition(
    requestedCondition,
    declaredCondition,
    kitCondition,
    commentForcesObservation ? 'OBSERVADO' : 'CONFORME',
    safetyObservation ? 'OBSERVADO' : 'CONFORME'
  );
  return {
    nature: normalizedNature,
    requestedCondition: normalizeCondition(requestedCondition),
    declaredCondition: normalizeCondition(declaredCondition),
    kitCondition: normalizeCondition(kitCondition),
    warehouseComment: comment || null,
    commentForcesObservation,
    vehicleSafetyObservation: safetyObservation,
    effectiveCondition,
    // F24: un vehículo se bloquea exclusivamente por clasificación Seguridad del Supervisor.
    blocksAsset: normalizedNature === 'VEHICULO' ? safetyObservation : effectiveCondition !== 'CONFORME'
  };
}

module.exports = { CONDITIONS, normalizeCondition, strongestReturnCondition, evaluateReturnDeclarationPolicy, evaluateReceptionPolicy };
