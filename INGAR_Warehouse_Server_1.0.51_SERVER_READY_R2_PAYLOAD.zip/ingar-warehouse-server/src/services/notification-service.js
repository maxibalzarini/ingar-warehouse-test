'use strict';

const { randomUUID } = require('node:crypto');
const { getDb, transaction } = require('../db/database');
const { requiredString, safeInteger } = require('../security/validation');
const { appendAudit } = require('./audit-service');
const { getSetting } = require('./settings-service');

function error(status, code, message) { return Object.assign(new Error(message), { status, code }); }
function nowIso() { return new Date().toISOString(); }

function enqueueNotification(input, db = getDb()) {
  const now = nowIso();
  const recipientPersonId = input.recipientPersonId || null;
  const recipientUserId = input.recipientUserId || null;
  if (!recipientPersonId && !recipientUserId) throw error(422, 'NOTIFICATION_RECIPIENT_REQUIRED', 'La notificación requiere destinatario.');
  if (input.dedupKey) {
    const existing = db.prepare('SELECT * FROM notification WHERE dedup_key=?').get(String(input.dedupKey));
    if (existing) {
      if (input.reactivateCancelled === true && existing.status === 'CANCELADA') {
        db.prepare(`UPDATE notification SET recipient_person_id=?,recipient_user_id=?,type=?,channel=?,status='PENDIENTE',subject=?,body=?,entity_type=?,entity_id=?,scheduled_at=?,sent_at=NULL,read_at=NULL,attempts=0,last_error=NULL,updated_at=? WHERE id=?`)
          .run(recipientPersonId, recipientUserId, String(input.type || 'SISTEMA').toUpperCase(), String(input.channel || 'IN_APP').toUpperCase(),
            requiredString(input.subject, 'subject', { min: 3, max: 180 }), requiredString(input.body, 'body', { min: 3, max: 2000 }),
            input.entityType || null, input.entityId || null, input.scheduledAt ? new Date(input.scheduledAt).toISOString() : now, now, existing.id);
        return { notification: db.prepare('SELECT * FROM notification WHERE id=?').get(existing.id), idempotent: false, reactivated: true };
      }
      return { notification: existing, idempotent: true, reactivated: false };
    }
  }
  const id = randomUUID();
  db.prepare(`INSERT INTO notification(id,recipient_person_id,recipient_user_id,type,channel,status,subject,body,entity_type,entity_id,dedup_key,scheduled_at,sent_at,read_at,attempts,last_error,created_at,updated_at)
    VALUES (?,?,?,?,?,'PENDIENTE',?,?,?,?,?,?,NULL,NULL,0,NULL,?,?)`)
    .run(id, recipientPersonId, recipientUserId, String(input.type || 'SISTEMA').toUpperCase(), String(input.channel || 'IN_APP').toUpperCase(), requiredString(input.subject, 'subject', { min: 3, max: 180 }), requiredString(input.body, 'body', { min: 3, max: 2000 }), input.entityType || null, input.entityId || null, input.dedupKey || null, input.scheduledAt ? new Date(input.scheduledAt).toISOString() : now, now, now);
  return { notification: db.prepare('SELECT * FROM notification WHERE id=?').get(id), idempotent: false };
}

function listNotifications(user, filters = {}) {
  const where = ['(recipient_user_id=? OR recipient_person_id=?)'];
  const args = [user.id, user.personId];
  if (filters.status) { where.push('status=?'); args.push(String(filters.status).toUpperCase()); }
  if (filters.unread === true || filters.unread === 'true') where.push('read_at IS NULL');
  if (filters.type) { where.push('type=?'); args.push(String(filters.type).toUpperCase()); }
  const limit = safeInteger(filters.limit, 100, 1, 500);
  return getDb().prepare(`SELECT * FROM notification WHERE ${where.join(' AND ')} ORDER BY scheduled_at DESC,created_at DESC LIMIT ?`).all(...args, limit);
}

function markNotificationRead(id, user, context) {
  return transaction((db) => {
    const current = db.prepare('SELECT * FROM notification WHERE id=? AND (recipient_user_id=? OR recipient_person_id=?)').get(id, user.id, user.personId);
    if (!current) throw error(404, 'NOTIFICATION_NOT_FOUND', 'Notificación no encontrada.');
    if (current.read_at) return { ...current, idempotent: true };
    const now = nowIso();
    db.prepare("UPDATE notification SET status='LEIDA',read_at=?,updated_at=? WHERE id=? AND read_at IS NULL").run(now, now, id);
    const after = db.prepare('SELECT * FROM notification WHERE id=?').get(id);
    appendAudit({ actorUserId: user.id, actorRole: user.roleCodes.join(','), action: 'NOTIFICATION.READ', entityType: 'notification', entityId: id, before: current, after, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return after;
  });
}

function markAllNotificationsRead(user, context) {
  return transaction((db) => {
    const now = nowIso();
    const result = db.prepare("UPDATE notification SET status='LEIDA',read_at=?,updated_at=? WHERE read_at IS NULL AND (recipient_user_id=? OR recipient_person_id=?)").run(now, now, user.id, user.personId);
    appendAudit({ actorUserId: user.id, actorRole: user.roleCodes.join(','), action: 'NOTIFICATION.READ_ALL', entityType: 'notification', entityId: user.id, after: { count: result.changes }, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return { updated: result.changes };
  });
}

function deliverPendingNotifications(db = getDb(), limit = 500) {
  const now = nowIso();
  const rows = db.prepare("SELECT * FROM notification WHERE status='PENDIENTE' AND scheduled_at<=? ORDER BY scheduled_at LIMIT ?").all(now, limit);
  let delivered = 0; let failed = 0;
  for (const row of rows) {
    if (row.channel === 'IN_APP') {
      db.prepare("UPDATE notification SET status='ENVIADA',sent_at=?,attempts=attempts+1,last_error=NULL,updated_at=? WHERE id=? AND status='PENDIENTE'").run(now, now, row.id);
      delivered += 1;
    } else {
      db.prepare("UPDATE notification SET status='FALLIDA',attempts=attempts+1,last_error='MAIL_CHANNEL_DISABLED',updated_at=? WHERE id=? AND status='PENDIENTE'").run(now, now, row.id);
      failed += 1;
    }
  }
  return { processed: rows.length, delivered, failed };
}


function applyNotificationRetention(db = getDb(), now = new Date()) {
  const retentionDays = Math.max(1, Number(getSetting('notification.retentionDays', 180)) || 180);
  const cutoff = new Date(now.getTime() - retentionDays * 86400000).toISOString();
  const result = db.prepare("DELETE FROM notification WHERE created_at < ? AND status IN ('LEIDA','ENVIADA','CANCELADA','FALLIDA')").run(cutoff);
  return { deleted: result.changes, cutoff };
}

function createSystemNotification(input, context) {
  return transaction((db) => {
    const result = enqueueNotification(input, db);
    appendAudit({ actorUserId: context.user.id, actorRole: context.user.roleCodes.join(','), action: 'NOTIFICATION.CREATE', entityType: 'notification', entityId: result.notification.id, after: result.notification, correlationId: context.correlationId, source: 'API', ipAddress: context.ip, equipment: context.userAgent }, db);
    return result;
  });
}

module.exports = { enqueueNotification, listNotifications, markNotificationRead, markAllNotificationsRead, deliverPendingNotifications, applyNotificationRetention, createSystemNotification };
