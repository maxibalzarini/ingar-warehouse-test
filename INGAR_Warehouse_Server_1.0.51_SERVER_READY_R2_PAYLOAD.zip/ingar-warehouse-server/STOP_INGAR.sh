#!/usr/bin/env bash
set -euo pipefail
PID_FILE="$HOME/.ingar-warehouse-server.pid"
if [[ ! -f "$PID_FILE" ]]; then echo "INGAR Warehouse no está activo."; exit 0; fi
PID="$(cat "$PID_FILE")"
if kill -0 "$PID" 2>/dev/null; then kill "$PID"; for _ in {1..15}; do kill -0 "$PID" 2>/dev/null || break; sleep 1; done; fi
rm -f "$PID_FILE"
echo "INGAR Warehouse detenido."
